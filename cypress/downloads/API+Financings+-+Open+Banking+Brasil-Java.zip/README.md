
# Getting Started with API Financings - Open Banking Brasil

## Introduction

API de informações de operações de financiamentos do Open Banking Brasil – Fase 2.
API que retorna informações de operações de crédito do tipo financiamento, mantidas nas instituições transmissoras por seus clientes, incluindo dados como denominação, modalidade, número do contrato, tarifas, prazo, prestações, pagamentos, amortizações, garantias, encargos e taxas de juros remuneratórios.\
Não possui segregação entre pessoa natural e pessoa jurídica.\
Requer consentimento do cliente para todos os `endpoints`.

### Orientações

A `Role`  do diretório de participantes relacionada à presente API é a `DADOS`.\
Para todos os `endpoints` desta API é previsto o envio de um `token` através do header `Authorization`.\
Este token deverá estar relacionado ao consentimento (`consentId`) mantido na instituição transmissora dos dados, o qual permitirá a pesquisa e retorno, na API em questão, dos
dados relacionados ao `consentId` específico relacionado.\
Os dados serão devolvidos na consulta desde que o `consentId` relacionado corresponda a um consentimento válido e com o status `AUTHORISED`.\
É também necessário que o recurso em questão (conta, contrato, etc) esteja disponível na instituição transmissora (ou seja, sem boqueios de qualquer natureza e com todas as autorizações/consentimentos já autorizados).\
Além disso as `permissions` necessárias deverão ter sido solicitadas quando da criação do consentimento relacionado (`consentId`).\
Relacionamos a seguir as `permissions` necessárias para a consulta de dados em cada `endpoint` da presente API.

#### Observação

- No endpoint `/contracts/{contratId}/payments` a paginação ocorrerá sob os dados contidos no campo `releases` do tipo lista.

#### Permissions necessárias para a API Financings

Para cada um dos paths desta API, além dos escopos (`scopes`) indicados existem `permissions` que deverão ser observadas:

##### `/contracts`

- permissions:
  - GET: **FINANCINGS_READ**

##### `/contracts/{contractId}`

- permissions:
  - GET **FINANCINGS_READ**

##### `/contracts/{contractId}/warranties`

- permissions:
  - GET: **FINANCINGS_WARRANTIES_READ**

##### `/contracts/{contractId}/scheduled-instalments`

- permissions:
  - GET: **FINANCINGS_SCHEDULED_INSTALMENTS_READ**

##### `/contracts/{contractId}/payments`

- permissions:
  - GET: **FINANCINGS_PAYMENTS_READ**

## Building

The generated code uses a few Maven dependencies e.g., Jackson, OkHttp,
and Apache HttpClient. The reference to these dependencies is already
added in the pom.xml file will be installed automatically. Therefore,
you will need internet access for a successful build.

* In order to open the client library in Eclipse click on `File -> Import`.

![Importing SDK into Eclipse - Step 1](https://apidocs.io/illustration/java?workspaceFolder=API%20Financings%20-%20Open%20Banking%20Brasil-Java&workspaceName=APIFinancingsOpenBankingBrasil&projectName=APIFinancingsOpenBankingBrasilLib&rootNamespace=br.com.banco.api&groupId=APIFinancingsOpenBankingBrasilLib&artifactId=apifinancings-open-banking-brasil-lib&version=2.0.1&step=import0)

* In the import dialog, select `Existing Java Project` and click `Next`.

![Importing SDK into Eclipse - Step 2](https://apidocs.io/illustration/java?workspaceFolder=API%20Financings%20-%20Open%20Banking%20Brasil-Java&workspaceName=APIFinancingsOpenBankingBrasil&projectName=APIFinancingsOpenBankingBrasilLib&rootNamespace=br.com.banco.api&groupId=APIFinancingsOpenBankingBrasilLib&artifactId=apifinancings-open-banking-brasil-lib&version=2.0.1&step=import1)

* Browse to locate the folder containing the source code. Select the detected location of the project and click `Finish`.

![Importing SDK into Eclipse - Step 3](https://apidocs.io/illustration/java?workspaceFolder=API%20Financings%20-%20Open%20Banking%20Brasil-Java&workspaceName=APIFinancingsOpenBankingBrasil&projectName=APIFinancingsOpenBankingBrasilLib&rootNamespace=br.com.banco.api&groupId=APIFinancingsOpenBankingBrasilLib&artifactId=apifinancings-open-banking-brasil-lib&version=2.0.1&step=import2)

* Upon successful import, the project will be automatically built by Eclipse after automatically resolving the dependencies.

![Importing SDK into Eclipse - Step 4](https://apidocs.io/illustration/java?workspaceFolder=API%20Financings%20-%20Open%20Banking%20Brasil-Java&workspaceName=APIFinancingsOpenBankingBrasil&projectName=APIFinancingsOpenBankingBrasilLib&rootNamespace=br.com.banco.api&groupId=APIFinancingsOpenBankingBrasilLib&artifactId=apifinancings-open-banking-brasil-lib&version=2.0.1&step=import3)

## Installation

The following section explains how to use the APIFinancingsOpenBankingBrasilLib library in a new project.

### 1. Starting a new project

For starting a new project, click the menu command `File > New > Project`.

![Add a new project in Eclipse](https://apidocs.io/illustration/java?workspaceFolder=API%20Financings%20-%20Open%20Banking%20Brasil-Java&workspaceName=APIFinancingsOpenBankingBrasil&projectName=APIFinancingsOpenBankingBrasilLib&rootNamespace=br.com.banco.api&groupId=APIFinancingsOpenBankingBrasilLib&artifactId=apifinancings-open-banking-brasil-lib&version=2.0.1&step=createNewProject0)

Next, choose `Maven > Maven Project` and click `Next`.

![Create a new Maven Project - Step 1](https://apidocs.io/illustration/java?workspaceFolder=API%20Financings%20-%20Open%20Banking%20Brasil-Java&workspaceName=APIFinancingsOpenBankingBrasil&projectName=APIFinancingsOpenBankingBrasilLib&rootNamespace=br.com.banco.api&groupId=APIFinancingsOpenBankingBrasilLib&artifactId=apifinancings-open-banking-brasil-lib&version=2.0.1&step=createNewProject1)

Here, make sure to use the current workspace by choosing `Use default Workspace location`, as shown in the picture below and click `Next`.

![Create a new Maven Project - Step 2](https://apidocs.io/illustration/java?workspaceFolder=API%20Financings%20-%20Open%20Banking%20Brasil-Java&workspaceName=APIFinancingsOpenBankingBrasil&projectName=APIFinancingsOpenBankingBrasilLib&rootNamespace=br.com.banco.api&groupId=APIFinancingsOpenBankingBrasilLib&artifactId=apifinancings-open-banking-brasil-lib&version=2.0.1&step=createNewProject2)

Following this, select the *quick start* project type to create a simple project with an existing class and a `main` method. To do this, choose `maven-archetype-quickstart` item from the list and click `Next`.

![Create a new Maven Project - Step 3](https://apidocs.io/illustration/java?workspaceFolder=API%20Financings%20-%20Open%20Banking%20Brasil-Java&workspaceName=APIFinancingsOpenBankingBrasil&projectName=APIFinancingsOpenBankingBrasilLib&rootNamespace=br.com.banco.api&groupId=APIFinancingsOpenBankingBrasilLib&artifactId=apifinancings-open-banking-brasil-lib&version=2.0.1&step=createNewProject3)

In the last step, provide a `Group Id` and `Artifact Id` as shown in the picture below and click `Finish`.

![Create a new Maven Project - Step 4](https://apidocs.io/illustration/java?workspaceFolder=API%20Financings%20-%20Open%20Banking%20Brasil-Java&workspaceName=APIFinancingsOpenBankingBrasil&projectName=APIFinancingsOpenBankingBrasilLib&rootNamespace=br.com.banco.api&groupId=APIFinancingsOpenBankingBrasilLib&artifactId=apifinancings-open-banking-brasil-lib&version=2.0.1&step=createNewProject4)

### 2. Add reference of the library project

The created Maven project manages its dependencies using its `pom.xml` file. In order to add a dependency on the *APIFinancingsOpenBankingBrasilLib* client library, double click on the `pom.xml` file in the `Package Explorer`. Opening the `pom.xml` file will render a graphical view on the canvas. Here, switch to the `Dependencies` tab and click the `Add` button as shown in the picture below.

![Adding dependency to the client library - Step 1](https://apidocs.io/illustration/java?workspaceFolder=API%20Financings%20-%20Open%20Banking%20Brasil-Java&workspaceName=APIFinancingsOpenBankingBrasil&projectName=APIFinancingsOpenBankingBrasilLib&rootNamespace=br.com.banco.api&groupId=APIFinancingsOpenBankingBrasilLib&artifactId=apifinancings-open-banking-brasil-lib&version=2.0.1&step=testProject0)

Clicking the `Add` button will open a dialog where you need to specify APIFinancingsOpenBankingBrasilLib in `Group Id`, apifinancings-open-banking-brasil-lib in `Artifact Id` and 2.0.1 in the `Version` fields. Once added click `OK`. Save the `pom.xml` file.

![Adding dependency to the client library - Step 2](https://apidocs.io/illustration/java?workspaceFolder=API%20Financings%20-%20Open%20Banking%20Brasil-Java&workspaceName=APIFinancingsOpenBankingBrasil&projectName=APIFinancingsOpenBankingBrasilLib&rootNamespace=br.com.banco.api&groupId=APIFinancingsOpenBankingBrasilLib&artifactId=apifinancings-open-banking-brasil-lib&version=2.0.1&step=testProject1)

![Adding sample code](https://apidocs.io/illustration/java?workspaceFolder=API%20Financings%20-%20Open%20Banking%20Brasil-Java&workspaceName=APIFinancingsOpenBankingBrasil&projectName=APIFinancingsOpenBankingBrasilLib&rootNamespace=br.com.banco.api&groupId=APIFinancingsOpenBankingBrasilLib&artifactId=apifinancings-open-banking-brasil-lib&version=2.0.1&step=testProject2)

### 3. Write sample code

Once the `SimpleConsoleApp` is created, a file named `App.java` will be visible in the *Package Explorer* with a `main` method. This is the entry point for the execution of the created project.
Here, you can add code to initialize the client library and instantiate a *Controller* class. Sample code to initialize the client library and using controller methods is given in the subsequent sections.

## Initialize the API Client

**_Note:_** Documentation for the client can be found [here.](doc/client.md)

The following parameters are configurable for the API Client:

| Parameter | Type | Description |
|  --- | --- | --- |
| `environment` | Environment | The API environment. <br> **Default: `Environment.PRODUCTION`** |
| `httpClientConfig` | `ReadonlyHttpClientConfiguration` | Http Client Configuration instance. |
| `authorizationCodeClientId` | `String` | OAuth 2 Client ID |
| `authorizationCodeClientSecret` | `String` | OAuth 2 Client Secret |
| `authorizationCodeRedirectUri` | `String` | OAuth 2 Redirection endpoint or Callback Uri |
| `authorizationCodeToken` | `OAuthToken` | Object for storing information about the OAuth token |
| `authorizationCodeScopes` | `List<AuthorizationCodeScopeEnum>` |  |

The API client can be initialized as follows:

```java
APIFinancingsOpenBankingBrasilClient client = new APIFinancingsOpenBankingBrasilClient.Builder()
    .httpClientConfig(configBuilder -> configBuilder
            .timeout(0))
    .oAuthScopes(Arrays.asList(OAuthScopeEnum.OPENID, OAuthScopeEnum.FINANCINGS))
    .authorizationCodeAuthCredentials("AuthorizationCodeClientId", "AuthorizationCodeClientSecret", "AuthorizationCodeRedirectUri")
    .environment(Environment.PRODUCTION)
    .build();
```

## Environments

The SDK can be configured to use a different environment for making API calls. Available environments are:

### Fields

| Name | Description |
|  --- | --- |
| production | **Default** Servidor de Produção |
| environment2 | Servidor de Produção |
| environment3 | Servidor de Produção |
| environment4 | Servidor de Homologação |
| environment5 | Servidor de Homologação |
| environment6 | Servidor de Homologação |

## Authorization

This API uses `OAuth 2 Authorization Code Grant`.

## Authorization Code Grant

Your application must obtain user authorization before it can execute an endpoint call incase this SDK chooses to use *OAuth 2.0 Authorization Code Grant*. This authorization includes the following steps

### 1\. Obtain user consent

To obtain user's consent, you must redirect the user to the authorization page.The `buildAuthorizationUrl()` method creates the URL to the authorization page. You must pass the scopes for which you need permission to access.

```java
String authUrl = client.getAuthorizationCodeAuth().buildAuthorizationUrl(); // build auth url
httpServletResponse.sendRedirect(authUrl); // show user the auth page in a browser or by redirection
```

### 2\. Handle the OAuth server response

Once the user responds to the consent request, the OAuth 2.0 server responds to your application's access request by redirecting the user to the redirect URI specified set in `Configuration`.

If the user approves the request, the authorization code will be sent as the `code` query string:

```
https://example.com/oauth/callback?code=XXXXXXXXXXXXXXXXXXXXXXXXX
```

If the user does not approve the request, the response contains an `error` query string:

```
https://example.com/oauth/callback?error=access_denied
```

### 3\. Authorize the client using the code

After the server receives the code, it can exchange this for an *access token*. The access token is an object containing information for authorizing client requests and refreshing the token itself.

```java
try {
    OAuthToken token = client.getAuthorizationCodeAuth().fetchToken(authorizationCode);
    // re-instantiate the client with oauth token
    client = client.newBuilder().oAuthToken(token).build();
} catch (Throwable e) {
    // TODO Handle exception
}
```

### Scopes

Scopes enable your application to only request access to the resources it needs while enabling users to control the amount of access they grant to your application. Available scopes are defined in the `AuthorizationCodeScopeEnum` enumeration.

| Scope Name | Description |
|  --- | --- |
| `OPENID` |  |
| `FINANCINGS` | Escopo necessário para acesso à API Financings. O controle dos endpoints específicos é feito via permissions. |
| `CONSENTCONSENTID` |  |

### Refreshing the token

An access token may expire after sometime. To extend its lifetime, you must refresh the token.

```java
if (client.getAuthorizationCodeAuth().isTokenExpired()) {
    try {
        OAuthToken token = client.getAuthorizationCodeAuth().refreshToken();
        // re-instantiate the client with oauth token
        client = client.newBuilder().oAuthToken(token).build();
    } catch (Throwable e) {
        // TODO Handle exception
    }
}
```

If a token expires, an exception will be thrown before the next endpoint call requiring authentication.

### Storing an access token for reuse

It is recommended that you store the access token for reuse.

```java
// store token
httpSession.setAttribute("access_token", client.getAuthorizationCodeAuth().getOAuthToken());
```

### Creating a client from a stored token

To authorize a client from a stored access token, just set the access token in Configuration along with the other configuration parameters before creating the client:

```java
// load token later...
OAuthToken token = (OAuthToken) httpSession.getAttribute("access_token");

// re-instantiate the client with oauth token
client = client.newBuilder().oAuthToken(token).build();
```

### Complete example

In this example that uses the Spring framework, the `/callapi` route will first check if an access token is available for the user. If one is not set,
it redirects the user to `/authcallback` route which will obtain an access token and redirect the user back to the `/callapi` route.
Now that an access token is set, `/callapi` route can use the client to make authorized calls to the server.

#### `MainController.java`

```java
package com.example;

import br.com.banco.api.APIFinancingsOpenBankingBrasilClient;
import br.com.banco.api.models.OAuthScopeEnum;
import br.com.banco.api.models.OAuthToken;
import java.util.Arrays;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
@RequestMapping("/")
public class MainController {
    private APIFinancingsOpenBankingBrasilClient client;

    public MainController() {
        APIFinancingsOpenBankingBrasilClient client = new APIFinancingsOpenBankingBrasilClient.Builder()
            .httpClientConfig(configBuilder -> configBuilder
                    .timeout(0))
            .oAuthScopes(Arrays.asList(OAuthScopeEnum.OPENID, OAuthScopeEnum.FINANCINGS))
            .authorizationCodeAuthCredentials("AuthorizationCodeClientId", "AuthorizationCodeClientSecret", "AuthorizationCodeRedirectUri")
            .environment(Environment.PRODUCTION)
            .build();
        
        
    }

    @RequestMapping(value = "/callapi", method = RequestMethod.GET, produces = "application/json")
    public String callApi(HttpSession session, HttpServletResponse response) throws Throwable {
        // redirect if access token is not set
        if (session.getAttribute("access_token") == null) {
            response.sendRedirect("authcallback");
            return null;
        }

        synchronized (client) {
            client = client.newBuilder().oAuthToken((OAuthToken) session.getAttribute("access_token")).build();

            // refresh the token if it is expired
            if(client.getAuthorizationCodeAuth().isTokenExpired()) {
                try {
                    OAuthToken token = session.setAttribute("access_token", client.getAuthorizationCodeAuth().refreshToken());
                    // re-instantiate the client with oauth token
                    client = client.newBuilder().oAuthToken(token).build();
                } catch (Throwable e) {
                    // TODO Handle exception
                }
            }

            // now you can use client to make endpoint calls
            // client will automatically refresh the token when it expires
            return "someView";
        }
    }

    @RequestMapping(value = "/authcallback", method = RequestMethod.GET)
    public void authcallback(HttpSession session, @RequestParam(required = false) String code,
            HttpServletResponse response) throws Throwable {
        if (code == null) {
            String authUrl;
            
            synchronized (client) {
                authUrl = client.getAuthorizationCodeAuth().buildAuthorizationUrl();
            }
            
            // if authorization code is absent, redirect to authorization page
            response.sendRedirect(authUrl);
        } else {
            OAuthToken token;
            
            synchronized (client) {
                token = client.getAuthorizationCodeAuth().fetchToken(code);
                // re-instantiate the client with oauth token
                client = client.newBuilder().oAuthToken(token).build();
            }
            
            session.setAttribute("access_token", token);
            response.sendRedirect("callapi");
        }
    }
}
```

## List of APIs

* [O Auth Authorization](doc/controllers/o-auth-authorization.md)
* [Financings](doc/controllers/financings.md)

## Classes Documentation

* [Utility Classes](doc/utility-classes.md)
* [HttpRequest](doc/http-request.md)
* [HttpResponse](doc/http-response.md)
* [HttpStringResponse](doc/http-string-response.md)
* [HttpContext](doc/http-context.md)
* [HttpBodyRequest](doc/http-body-request.md)
* [Headers](doc/headers.md)
* [ApiException](doc/api-exception.md)
* [Configuration Interface](doc/configuration-interface.md)
* [HttpClientConfiguration](doc/http-client-configuration.md)
* [HttpClientConfiguration.Builder](doc/http-client-configuration-builder.md)

