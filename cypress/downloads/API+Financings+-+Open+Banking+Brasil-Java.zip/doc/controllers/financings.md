# Financings

```java
FinancingsController financingsController = client.getFinancingsController();
```

## Class Name

`FinancingsController`

## Methods

* [Financings Get Contracts](../../doc/controllers/financings.md#financings-get-contracts)
* [Financings Get Contracts Contract Id](../../doc/controllers/financings.md#financings-get-contracts-contract-id)
* [Financings Get Contracts Contract Id Warranties](../../doc/controllers/financings.md#financings-get-contracts-contract-id-warranties)
* [Financings Get Contracts Contract Id Scheduled Instalments](../../doc/controllers/financings.md#financings-get-contracts-contract-id-scheduled-instalments)
* [Financings Get Contracts Contract Id Payments](../../doc/controllers/financings.md#financings-get-contracts-contract-id-payments)


# Financings Get Contracts

Método para obter a lista de contratos de empréstimo mantidos pelo cliente na instituição transmissora e para os quais ele tenha fornecido consentimento

```java
CompletableFuture<ResponseFinancingsContractList> financingsGetContractsAsync(
    final String authorization,
    final String xFapiAuthDate,
    final String xFapiCustomerIpAddress,
    final String xFapiInteractionId,
    final String xCustomerUserAgent,
    final Integer page,
    final Integer pageSize,
    final String paginationKey)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `authorization` | `String` | Header, Required | Cabeçalho HTTP padrão. Permite que as credenciais sejam fornecidas dependendo do tipo de recurso solicitado<br>**Constraints**: *Maximum Length*: `2048`, *Pattern*: `[\w\W\s]*` |
| `xFapiAuthDate` | `String` | Header, Required | Data em que o usuário logou pela última vez com o receptor. Representada de acordo com a [RFC7231](https://tools.ietf.org/html/rfc7231).Exemplo: Sun, 10 Sep 2017 19:43:31 UTC<br>**Constraints**: *Minimum Length*: `29`, *Maximum Length*: `29`, *Pattern*: `^(Mon\|Tue\|Wed\|Thu\|Fri\|Sat\|Sun), \d{2} (Jan\|Feb\|Mar\|Apr\|May\|Jun\|Jul\|Aug\|Sep\|Oct\|Nov\|Dec) \d{4} \d{2}:\d{2}:\d{2} (GMT\|UTC)$` |
| `xFapiCustomerIpAddress` | `String` | Header, Optional | O endereço IP do usuário se estiver atualmente logado com o receptor.<br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `100`, *Pattern*: `[\w\W\s]*` |
| `xFapiInteractionId` | `String` | Header, Optional | Um UID [RFC4122](https://tools.ietf.org/html/rfc4122) usado como um ID de correlação. Se fornecido, o transmissor deve "reproduzir" esse valor no cabeçalho de resposta.<br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `100`, *Pattern*: `^[a-zA-Z0-9][a-zA-Z0-9\-]{0,99}$` |
| `xCustomerUserAgent` | `String` | Header, Optional | Indica o user-agent que o usuário utiliza.<br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `100`, *Pattern*: `[\w\W\s]*` |
| `page` | `Integer` | Query, Optional | Número da página que está sendo requisitada (o valor da primeira página é 1).<br>**Default**: `1`<br>**Constraints**: `>= 1`, `<= 2147483647` |
| `pageSize` | `Integer` | Query, Optional | Quantidade total de registros por páginas.<br>**Default**: `25`<br>**Constraints**: `>= 1`, `<= 1000` |
| `paginationKey` | `String` | Query, Optional | Identificador de rechamada, utilizado para evitar a contagem de chamadas ao endpoint durante a paginação.<br>**Constraints**: *Maximum Length*: `2048`, *Pattern*: `[\w\W\s]*` |

## Requires scope

`OPENID`

## Response Type

[`ResponseFinancingsContractList`](../../doc/models/response-financings-contract-list.md)

## Example Usage

```java
String authorization = "Authorization8";
String xFapiAuthDate = "x-fapi-auth-date0";
Integer page = 1;
Integer pageSize = 25;

financingsController.financingsGetContractsAsync(authorization, xFapiAuthDate, null, null, null, page, pageSize, null).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | A requisição foi malformada, omitindo atributos obrigatórios, seja no payload ou através de atributos na URL. | [`ResponseErrorWithAbleAdditionalPropertiesException`](../../doc/models/response-error-with-able-additional-properties-exception.md) |
| 401 | Cabeçalho de autenticação ausente/inválido ou token inválido | [`ResponseErrorWithAbleAdditionalPropertiesException`](../../doc/models/response-error-with-able-additional-properties-exception.md) |
| 403 | O token tem escopo incorreto ou uma política de segurança foi violada | [`ResponseErrorWithAbleAdditionalPropertiesException`](../../doc/models/response-error-with-able-additional-properties-exception.md) |
| 404 | O recurso solicitado não existe ou não foi implementado | [`ResponseErrorWithAbleAdditionalPropertiesException`](../../doc/models/response-error-with-able-additional-properties-exception.md) |
| 405 | O consumidor tentou acessar o recurso com um método não suportado | [`ResponseErrorWithAbleAdditionalPropertiesException`](../../doc/models/response-error-with-able-additional-properties-exception.md) |
| 406 | A solicitação continha um cabeçalho Accept diferente dos tipos de mídia permitidos ou um conjunto de caracteres diferente de UTF-8 | [`ResponseErrorWithAbleAdditionalPropertiesException`](../../doc/models/response-error-with-able-additional-properties-exception.md) |
| 422 | A sintaxe da requisição esta correta, mas não foi possível processar as instruções presentes. | [`ResponseErrorWithAbleAdditionalPropertiesException`](../../doc/models/response-error-with-able-additional-properties-exception.md) |
| 423 | Locked | [`ResponseErrorWithAbleAdditionalPropertiesException`](../../doc/models/response-error-with-able-additional-properties-exception.md) |
| 429 | A operação foi recusada, pois muitas solicitações foram feitas dentro de um determinado período ou o limite global de requisições concorrentes foi atingido | [`ResponseErrorWithAbleAdditionalPropertiesException`](../../doc/models/response-error-with-able-additional-properties-exception.md) |
| 500 | Ocorreu um erro no gateway da API ou no microsserviço | [`ResponseErrorWithAbleAdditionalPropertiesException`](../../doc/models/response-error-with-able-additional-properties-exception.md) |
| 504 | GATEWAY TIMEOUT - A requisição não foi atendida dentro do tempo limite estabelecido | [`ResponseErrorWithAbleAdditionalPropertiesException`](../../doc/models/response-error-with-able-additional-properties-exception.md) |
| 529 | O site está sobrecarregado e a operação foi recusada, pois foi atingido o limite máximo de TPS global, neste momento. | [`ResponseErrorWithAbleAdditionalPropertiesException`](../../doc/models/response-error-with-able-additional-properties-exception.md) |
| Default | Erro inesperado. | [`ResponseErrorWithAbleAdditionalPropertiesException`](../../doc/models/response-error-with-able-additional-properties-exception.md) |


# Financings Get Contracts Contract Id

Método para obter os dados do contrato de financiamento identificado por contractId mantido pelo cliente na instituição transmissora

```java
CompletableFuture<ResponseFinancingsContract> financingsGetContractsContractIdAsync(
    final String contractId,
    final String authorization,
    final String xFapiAuthDate,
    final String xFapiCustomerIpAddress,
    final String xFapiInteractionId,
    final String xCustomerUserAgent)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `contractId` | `String` | Template, Required | Identificador do contrato para todos os tipos de operação de crédito.<br>**Constraints**: *Maximum Length*: `100`, *Pattern*: `^[a-zA-Z0-9][a-zA-Z0-9-]{0,99}$` |
| `authorization` | `String` | Header, Required | Cabeçalho HTTP padrão. Permite que as credenciais sejam fornecidas dependendo do tipo de recurso solicitado<br>**Constraints**: *Maximum Length*: `2048`, *Pattern*: `[\w\W\s]*` |
| `xFapiAuthDate` | `String` | Header, Optional | Data em que o usuário logou pela última vez com o receptor. Representada de acordo com a [RFC7231](https://tools.ietf.org/html/rfc7231).Exemplo: Sun, 10 Sep 2017 19:43:31 UTC<br>**Constraints**: *Minimum Length*: `29`, *Maximum Length*: `29`, *Pattern*: `^(Mon\|Tue\|Wed\|Thu\|Fri\|Sat\|Sun), \d{2} (Jan\|Feb\|Mar\|Apr\|May\|Jun\|Jul\|Aug\|Sep\|Oct\|Nov\|Dec) \d{4} \d{2}:\d{2}:\d{2} (GMT\|UTC)$` |
| `xFapiCustomerIpAddress` | `String` | Header, Optional | O endereço IP do usuário se estiver atualmente logado com o receptor.<br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `100`, *Pattern*: `[\w\W\s]*` |
| `xFapiInteractionId` | `String` | Header, Optional | Um UID [RFC4122](https://tools.ietf.org/html/rfc4122) usado como um ID de correlação. Se fornecido, o transmissor deve "reproduzir" esse valor no cabeçalho de resposta.<br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `100`, *Pattern*: `^[a-zA-Z0-9][a-zA-Z0-9\-]{0,99}$` |
| `xCustomerUserAgent` | `String` | Header, Optional | Indica o user-agent que o usuário utiliza.<br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `100`, *Pattern*: `[\w\W\s]*` |

## Requires scope

`OPENID`

## Response Type

[`ResponseFinancingsContract`](../../doc/models/response-financings-contract.md)

## Example Usage

```java
String contractId = "contractId2";
String authorization = "Authorization8";

financingsController.financingsGetContractsContractIdAsync(contractId, authorization, null, null, null, null).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | A requisição foi malformada, omitindo atributos obrigatórios, seja no payload ou através de atributos na URL. | [`ResponseErrorWithAbleAdditionalPropertiesException`](../../doc/models/response-error-with-able-additional-properties-exception.md) |
| 401 | Cabeçalho de autenticação ausente/inválido ou token inválido | [`ResponseErrorWithAbleAdditionalPropertiesException`](../../doc/models/response-error-with-able-additional-properties-exception.md) |
| 403 | O token tem escopo incorreto ou uma política de segurança foi violada | [`ResponseErrorWithAbleAdditionalPropertiesException`](../../doc/models/response-error-with-able-additional-properties-exception.md) |
| 404 | O recurso solicitado não existe ou não foi implementado | [`ResponseErrorWithAbleAdditionalPropertiesException`](../../doc/models/response-error-with-able-additional-properties-exception.md) |
| 405 | O consumidor tentou acessar o recurso com um método não suportado | [`ResponseErrorWithAbleAdditionalPropertiesException`](../../doc/models/response-error-with-able-additional-properties-exception.md) |
| 406 | A solicitação continha um cabeçalho Accept diferente dos tipos de mídia permitidos ou um conjunto de caracteres diferente de UTF-8 | [`ResponseErrorWithAbleAdditionalPropertiesException`](../../doc/models/response-error-with-able-additional-properties-exception.md) |
| 422 | A sintaxe da requisição esta correta, mas não foi possível processar as instruções presentes. | [`ResponseErrorWithAbleAdditionalPropertiesException`](../../doc/models/response-error-with-able-additional-properties-exception.md) |
| 423 | Locked | [`ResponseErrorWithAbleAdditionalPropertiesException`](../../doc/models/response-error-with-able-additional-properties-exception.md) |
| 429 | A operação foi recusada, pois muitas solicitações foram feitas dentro de um determinado período ou o limite global de requisições concorrentes foi atingido | [`ResponseErrorWithAbleAdditionalPropertiesException`](../../doc/models/response-error-with-able-additional-properties-exception.md) |
| 500 | Ocorreu um erro no gateway da API ou no microsserviço | [`ResponseErrorWithAbleAdditionalPropertiesException`](../../doc/models/response-error-with-able-additional-properties-exception.md) |
| 504 | GATEWAY TIMEOUT - A requisição não foi atendida dentro do tempo limite estabelecido | [`ResponseErrorWithAbleAdditionalPropertiesException`](../../doc/models/response-error-with-able-additional-properties-exception.md) |
| 529 | O site está sobrecarregado e a operação foi recusada, pois foi atingido o limite máximo de TPS global, neste momento. | [`ResponseErrorWithAbleAdditionalPropertiesException`](../../doc/models/response-error-with-able-additional-properties-exception.md) |
| Default | Erro inesperado. | [`ResponseErrorWithAbleAdditionalPropertiesException`](../../doc/models/response-error-with-able-additional-properties-exception.md) |


# Financings Get Contracts Contract Id Warranties

Método para obter a lista de garantias vinculadas ao contrato de financiamento identificado por contractId mantido pelo cliente na instituição transmissora

```java
CompletableFuture<ResponseFinancingsWarranties> financingsGetContractsContractIdWarrantiesAsync(
    final String contractId,
    final String authorization,
    final Integer page,
    final Integer pageSize,
    final String xFapiAuthDate,
    final String xFapiCustomerIpAddress,
    final String xFapiInteractionId,
    final String xCustomerUserAgent,
    final String paginationKey)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `contractId` | `String` | Template, Required | Identificador do contrato para todos os tipos de operação de crédito.<br>**Constraints**: *Maximum Length*: `100`, *Pattern*: `^[a-zA-Z0-9][a-zA-Z0-9-]{0,99}$` |
| `authorization` | `String` | Header, Required | Cabeçalho HTTP padrão. Permite que as credenciais sejam fornecidas dependendo do tipo de recurso solicitado<br>**Constraints**: *Maximum Length*: `2048`, *Pattern*: `[\w\W\s]*` |
| `page` | `Integer` | Query, Optional | Número da página que está sendo requisitada (o valor da primeira página é 1).<br>**Default**: `1`<br>**Constraints**: `>= 1`, `<= 2147483647` |
| `pageSize` | `Integer` | Query, Optional | Quantidade total de registros por páginas.<br>**Default**: `25`<br>**Constraints**: `>= 1`, `<= 1000` |
| `xFapiAuthDate` | `String` | Header, Optional | Data em que o usuário logou pela última vez com o receptor. Representada de acordo com a [RFC7231](https://tools.ietf.org/html/rfc7231).Exemplo: Sun, 10 Sep 2017 19:43:31 UTC<br>**Constraints**: *Minimum Length*: `29`, *Maximum Length*: `29`, *Pattern*: `^(Mon\|Tue\|Wed\|Thu\|Fri\|Sat\|Sun), \d{2} (Jan\|Feb\|Mar\|Apr\|May\|Jun\|Jul\|Aug\|Sep\|Oct\|Nov\|Dec) \d{4} \d{2}:\d{2}:\d{2} (GMT\|UTC)$` |
| `xFapiCustomerIpAddress` | `String` | Header, Optional | O endereço IP do usuário se estiver atualmente logado com o receptor.<br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `100`, *Pattern*: `[\w\W\s]*` |
| `xFapiInteractionId` | `String` | Header, Optional | Um UID [RFC4122](https://tools.ietf.org/html/rfc4122) usado como um ID de correlação. Se fornecido, o transmissor deve "reproduzir" esse valor no cabeçalho de resposta.<br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `100`, *Pattern*: `^[a-zA-Z0-9][a-zA-Z0-9\-]{0,99}$` |
| `xCustomerUserAgent` | `String` | Header, Optional | Indica o user-agent que o usuário utiliza.<br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `100`, *Pattern*: `[\w\W\s]*` |
| `paginationKey` | `String` | Query, Optional | Identificador de rechamada, utilizado para evitar a contagem de chamadas ao endpoint durante a paginação.<br>**Constraints**: *Maximum Length*: `2048`, *Pattern*: `[\w\W\s]*` |

## Requires scope

`OPENID`

## Response Type

[`ResponseFinancingsWarranties`](../../doc/models/response-financings-warranties.md)

## Example Usage

```java
String contractId = "contractId2";
String authorization = "Authorization8";
Integer page = 1;
Integer pageSize = 25;

financingsController.financingsGetContractsContractIdWarrantiesAsync(contractId, authorization, page, pageSize, null, null, null, null, null).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | A requisição foi malformada, omitindo atributos obrigatórios, seja no payload ou através de atributos na URL. | [`ResponseErrorWithAbleAdditionalPropertiesException`](../../doc/models/response-error-with-able-additional-properties-exception.md) |
| 401 | Cabeçalho de autenticação ausente/inválido ou token inválido | [`ResponseErrorWithAbleAdditionalPropertiesException`](../../doc/models/response-error-with-able-additional-properties-exception.md) |
| 403 | O token tem escopo incorreto ou uma política de segurança foi violada | [`ResponseErrorWithAbleAdditionalPropertiesException`](../../doc/models/response-error-with-able-additional-properties-exception.md) |
| 404 | O recurso solicitado não existe ou não foi implementado | [`ResponseErrorWithAbleAdditionalPropertiesException`](../../doc/models/response-error-with-able-additional-properties-exception.md) |
| 405 | O consumidor tentou acessar o recurso com um método não suportado | [`ResponseErrorWithAbleAdditionalPropertiesException`](../../doc/models/response-error-with-able-additional-properties-exception.md) |
| 406 | A solicitação continha um cabeçalho Accept diferente dos tipos de mídia permitidos ou um conjunto de caracteres diferente de UTF-8 | [`ResponseErrorWithAbleAdditionalPropertiesException`](../../doc/models/response-error-with-able-additional-properties-exception.md) |
| 422 | A sintaxe da requisição esta correta, mas não foi possível processar as instruções presentes. | [`ResponseErrorWithAbleAdditionalPropertiesException`](../../doc/models/response-error-with-able-additional-properties-exception.md) |
| 423 | Locked | [`ResponseErrorWithAbleAdditionalPropertiesException`](../../doc/models/response-error-with-able-additional-properties-exception.md) |
| 429 | A operação foi recusada, pois muitas solicitações foram feitas dentro de um determinado período ou o limite global de requisições concorrentes foi atingido | [`ResponseErrorWithAbleAdditionalPropertiesException`](../../doc/models/response-error-with-able-additional-properties-exception.md) |
| 500 | Ocorreu um erro no gateway da API ou no microsserviço | [`ResponseErrorWithAbleAdditionalPropertiesException`](../../doc/models/response-error-with-able-additional-properties-exception.md) |
| 504 | GATEWAY TIMEOUT - A requisição não foi atendida dentro do tempo limite estabelecido | [`ResponseErrorWithAbleAdditionalPropertiesException`](../../doc/models/response-error-with-able-additional-properties-exception.md) |
| 529 | O site está sobrecarregado e a operação foi recusada, pois foi atingido o limite máximo de TPS global, neste momento. | [`ResponseErrorWithAbleAdditionalPropertiesException`](../../doc/models/response-error-with-able-additional-properties-exception.md) |
| Default | Erro inesperado. | [`ResponseErrorWithAbleAdditionalPropertiesException`](../../doc/models/response-error-with-able-additional-properties-exception.md) |


# Financings Get Contracts Contract Id Scheduled Instalments

Método para obter os dados do cronograma de parcelas do contrato de financiamento identificado por contractId mantido pelo cliente na instituição transmissora

```java
CompletableFuture<ResponseFinancingsInstalments> financingsGetContractsContractIdScheduledInstalmentsAsync(
    final String contractId,
    final String authorization,
    final Integer page,
    final Integer pageSize,
    final String xFapiAuthDate,
    final String xFapiCustomerIpAddress,
    final String xFapiInteractionId,
    final String xCustomerUserAgent,
    final String paginationKey)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `contractId` | `String` | Template, Required | Identificador do contrato para todos os tipos de operação de crédito.<br>**Constraints**: *Maximum Length*: `100`, *Pattern*: `^[a-zA-Z0-9][a-zA-Z0-9-]{0,99}$` |
| `authorization` | `String` | Header, Required | Cabeçalho HTTP padrão. Permite que as credenciais sejam fornecidas dependendo do tipo de recurso solicitado<br>**Constraints**: *Maximum Length*: `2048`, *Pattern*: `[\w\W\s]*` |
| `page` | `Integer` | Query, Optional | Número da página que está sendo requisitada (o valor da primeira página é 1).<br>**Default**: `1`<br>**Constraints**: `>= 1`, `<= 2147483647` |
| `pageSize` | `Integer` | Query, Optional | Quantidade total de registros por páginas.<br>**Default**: `25`<br>**Constraints**: `>= 1`, `<= 1000` |
| `xFapiAuthDate` | `String` | Header, Optional | Data em que o usuário logou pela última vez com o receptor. Representada de acordo com a [RFC7231](https://tools.ietf.org/html/rfc7231).Exemplo: Sun, 10 Sep 2017 19:43:31 UTC<br>**Constraints**: *Minimum Length*: `29`, *Maximum Length*: `29`, *Pattern*: `^(Mon\|Tue\|Wed\|Thu\|Fri\|Sat\|Sun), \d{2} (Jan\|Feb\|Mar\|Apr\|May\|Jun\|Jul\|Aug\|Sep\|Oct\|Nov\|Dec) \d{4} \d{2}:\d{2}:\d{2} (GMT\|UTC)$` |
| `xFapiCustomerIpAddress` | `String` | Header, Optional | O endereço IP do usuário se estiver atualmente logado com o receptor.<br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `100`, *Pattern*: `[\w\W\s]*` |
| `xFapiInteractionId` | `String` | Header, Optional | Um UID [RFC4122](https://tools.ietf.org/html/rfc4122) usado como um ID de correlação. Se fornecido, o transmissor deve "reproduzir" esse valor no cabeçalho de resposta.<br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `100`, *Pattern*: `^[a-zA-Z0-9][a-zA-Z0-9\-]{0,99}$` |
| `xCustomerUserAgent` | `String` | Header, Optional | Indica o user-agent que o usuário utiliza.<br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `100`, *Pattern*: `[\w\W\s]*` |
| `paginationKey` | `String` | Query, Optional | Identificador de rechamada, utilizado para evitar a contagem de chamadas ao endpoint durante a paginação.<br>**Constraints**: *Maximum Length*: `2048`, *Pattern*: `[\w\W\s]*` |

## Requires scope

`OPENID`

## Response Type

[`ResponseFinancingsInstalments`](../../doc/models/response-financings-instalments.md)

## Example Usage

```java
String contractId = "contractId2";
String authorization = "Authorization8";
Integer page = 1;
Integer pageSize = 25;

financingsController.financingsGetContractsContractIdScheduledInstalmentsAsync(contractId, authorization, page, pageSize, null, null, null, null, null).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | A requisição foi malformada, omitindo atributos obrigatórios, seja no payload ou através de atributos na URL. | [`ResponseErrorWithAbleAdditionalPropertiesException`](../../doc/models/response-error-with-able-additional-properties-exception.md) |
| 401 | Cabeçalho de autenticação ausente/inválido ou token inválido | [`ResponseErrorWithAbleAdditionalPropertiesException`](../../doc/models/response-error-with-able-additional-properties-exception.md) |
| 403 | O token tem escopo incorreto ou uma política de segurança foi violada | [`ResponseErrorWithAbleAdditionalPropertiesException`](../../doc/models/response-error-with-able-additional-properties-exception.md) |
| 404 | O recurso solicitado não existe ou não foi implementado | [`ResponseErrorWithAbleAdditionalPropertiesException`](../../doc/models/response-error-with-able-additional-properties-exception.md) |
| 405 | O consumidor tentou acessar o recurso com um método não suportado | [`ResponseErrorWithAbleAdditionalPropertiesException`](../../doc/models/response-error-with-able-additional-properties-exception.md) |
| 406 | A solicitação continha um cabeçalho Accept diferente dos tipos de mídia permitidos ou um conjunto de caracteres diferente de UTF-8 | [`ResponseErrorWithAbleAdditionalPropertiesException`](../../doc/models/response-error-with-able-additional-properties-exception.md) |
| 422 | A sintaxe da requisição esta correta, mas não foi possível processar as instruções presentes. | [`ResponseErrorWithAbleAdditionalPropertiesException`](../../doc/models/response-error-with-able-additional-properties-exception.md) |
| 423 | Locked | [`ResponseErrorWithAbleAdditionalPropertiesException`](../../doc/models/response-error-with-able-additional-properties-exception.md) |
| 429 | A operação foi recusada, pois muitas solicitações foram feitas dentro de um determinado período ou o limite global de requisições concorrentes foi atingido | [`ResponseErrorWithAbleAdditionalPropertiesException`](../../doc/models/response-error-with-able-additional-properties-exception.md) |
| 500 | Ocorreu um erro no gateway da API ou no microsserviço | [`ResponseErrorWithAbleAdditionalPropertiesException`](../../doc/models/response-error-with-able-additional-properties-exception.md) |
| 504 | GATEWAY TIMEOUT - A requisição não foi atendida dentro do tempo limite estabelecido | [`ResponseErrorWithAbleAdditionalPropertiesException`](../../doc/models/response-error-with-able-additional-properties-exception.md) |
| 529 | O site está sobrecarregado e a operação foi recusada, pois foi atingido o limite máximo de TPS global, neste momento. | [`ResponseErrorWithAbleAdditionalPropertiesException`](../../doc/models/response-error-with-able-additional-properties-exception.md) |
| Default | Erro inesperado. | [`ResponseErrorWithAbleAdditionalPropertiesException`](../../doc/models/response-error-with-able-additional-properties-exception.md) |


# Financings Get Contracts Contract Id Payments

Método para obter os dados de pagamentos do contrato de financiamento identificado por contractId mantido pelo cliente na instituição transmissora

```java
CompletableFuture<ResponseFinancingsPayments> financingsGetContractsContractIdPaymentsAsync(
    final String contractId,
    final String authorization,
    final Integer page,
    final Integer pageSize,
    final String xFapiAuthDate,
    final String xFapiCustomerIpAddress,
    final String xFapiInteractionId,
    final String xCustomerUserAgent,
    final String paginationKey)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `contractId` | `String` | Template, Required | Identificador do contrato para todos os tipos de operação de crédito.<br>**Constraints**: *Maximum Length*: `100`, *Pattern*: `^[a-zA-Z0-9][a-zA-Z0-9-]{0,99}$` |
| `authorization` | `String` | Header, Required | Cabeçalho HTTP padrão. Permite que as credenciais sejam fornecidas dependendo do tipo de recurso solicitado<br>**Constraints**: *Maximum Length*: `2048`, *Pattern*: `[\w\W\s]*` |
| `page` | `Integer` | Query, Optional | Número da página que está sendo requisitada (o valor da primeira página é 1).<br>**Default**: `1`<br>**Constraints**: `>= 1`, `<= 2147483647` |
| `pageSize` | `Integer` | Query, Optional | Quantidade total de registros por páginas.<br>**Default**: `25`<br>**Constraints**: `>= 1`, `<= 1000` |
| `xFapiAuthDate` | `String` | Header, Optional | Data em que o usuário logou pela última vez com o receptor. Representada de acordo com a [RFC7231](https://tools.ietf.org/html/rfc7231).Exemplo: Sun, 10 Sep 2017 19:43:31 UTC<br>**Constraints**: *Minimum Length*: `29`, *Maximum Length*: `29`, *Pattern*: `^(Mon\|Tue\|Wed\|Thu\|Fri\|Sat\|Sun), \d{2} (Jan\|Feb\|Mar\|Apr\|May\|Jun\|Jul\|Aug\|Sep\|Oct\|Nov\|Dec) \d{4} \d{2}:\d{2}:\d{2} (GMT\|UTC)$` |
| `xFapiCustomerIpAddress` | `String` | Header, Optional | O endereço IP do usuário se estiver atualmente logado com o receptor.<br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `100`, *Pattern*: `[\w\W\s]*` |
| `xFapiInteractionId` | `String` | Header, Optional | Um UID [RFC4122](https://tools.ietf.org/html/rfc4122) usado como um ID de correlação. Se fornecido, o transmissor deve "reproduzir" esse valor no cabeçalho de resposta.<br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `100`, *Pattern*: `^[a-zA-Z0-9][a-zA-Z0-9\-]{0,99}$` |
| `xCustomerUserAgent` | `String` | Header, Optional | Indica o user-agent que o usuário utiliza.<br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `100`, *Pattern*: `[\w\W\s]*` |
| `paginationKey` | `String` | Query, Optional | Identificador de rechamada, utilizado para evitar a contagem de chamadas ao endpoint durante a paginação.<br>**Constraints**: *Maximum Length*: `2048`, *Pattern*: `[\w\W\s]*` |

## Requires scope

`OPENID`

## Response Type

[`ResponseFinancingsPayments`](../../doc/models/response-financings-payments.md)

## Example Usage

```java
String contractId = "contractId2";
String authorization = "Authorization8";
Integer page = 1;
Integer pageSize = 25;

financingsController.financingsGetContractsContractIdPaymentsAsync(contractId, authorization, page, pageSize, null, null, null, null, null).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | A requisição foi malformada, omitindo atributos obrigatórios, seja no payload ou através de atributos na URL. | [`ResponseErrorWithAbleAdditionalPropertiesException`](../../doc/models/response-error-with-able-additional-properties-exception.md) |
| 401 | Cabeçalho de autenticação ausente/inválido ou token inválido | [`ResponseErrorWithAbleAdditionalPropertiesException`](../../doc/models/response-error-with-able-additional-properties-exception.md) |
| 403 | O token tem escopo incorreto ou uma política de segurança foi violada | [`ResponseErrorWithAbleAdditionalPropertiesException`](../../doc/models/response-error-with-able-additional-properties-exception.md) |
| 404 | O recurso solicitado não existe ou não foi implementado | [`ResponseErrorWithAbleAdditionalPropertiesException`](../../doc/models/response-error-with-able-additional-properties-exception.md) |
| 405 | O consumidor tentou acessar o recurso com um método não suportado | [`ResponseErrorWithAbleAdditionalPropertiesException`](../../doc/models/response-error-with-able-additional-properties-exception.md) |
| 406 | A solicitação continha um cabeçalho Accept diferente dos tipos de mídia permitidos ou um conjunto de caracteres diferente de UTF-8 | [`ResponseErrorWithAbleAdditionalPropertiesException`](../../doc/models/response-error-with-able-additional-properties-exception.md) |
| 422 | A sintaxe da requisição esta correta, mas não foi possível processar as instruções presentes. | [`ResponseErrorWithAbleAdditionalPropertiesException`](../../doc/models/response-error-with-able-additional-properties-exception.md) |
| 423 | Locked | [`ResponseErrorWithAbleAdditionalPropertiesException`](../../doc/models/response-error-with-able-additional-properties-exception.md) |
| 429 | A operação foi recusada, pois muitas solicitações foram feitas dentro de um determinado período ou o limite global de requisições concorrentes foi atingido | [`ResponseErrorWithAbleAdditionalPropertiesException`](../../doc/models/response-error-with-able-additional-properties-exception.md) |
| 500 | Ocorreu um erro no gateway da API ou no microsserviço | [`ResponseErrorWithAbleAdditionalPropertiesException`](../../doc/models/response-error-with-able-additional-properties-exception.md) |
| 504 | GATEWAY TIMEOUT - A requisição não foi atendida dentro do tempo limite estabelecido | [`ResponseErrorWithAbleAdditionalPropertiesException`](../../doc/models/response-error-with-able-additional-properties-exception.md) |
| 529 | O site está sobrecarregado e a operação foi recusada, pois foi atingido o limite máximo de TPS global, neste momento. | [`ResponseErrorWithAbleAdditionalPropertiesException`](../../doc/models/response-error-with-able-additional-properties-exception.md) |
| Default | Erro inesperado. | [`ResponseErrorWithAbleAdditionalPropertiesException`](../../doc/models/response-error-with-able-additional-properties-exception.md) |

