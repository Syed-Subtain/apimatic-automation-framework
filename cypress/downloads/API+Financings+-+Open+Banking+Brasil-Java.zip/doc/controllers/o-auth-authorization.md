# O Auth Authorization

```java
OAuthAuthorizationController oAuthAuthorizationController = client.getOAuthAuthorizationController();
```

## Class Name

`OAuthAuthorizationController`

## Methods

* [Authorization Code Auth Request Token](../../doc/controllers/o-auth-authorization.md#authorization-code-auth-request-token)
* [Authorization Code Auth Refresh Token](../../doc/controllers/o-auth-authorization.md#authorization-code-auth-refresh-token)


# Authorization Code Auth Request Token

Create a new OAuth 2 token for authorization code auth.

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<OAuthToken> authorizationCodeAuthRequestTokenAsync(
    final String authorization,
    final String code,
    final String redirectUri,
    final Map<String, Object> fieldParameters)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `authorization` | `String` | Header, Required | Authorization header in Basic auth format |
| `code` | `String` | Form, Required | Authorization Code |
| `redirectUri` | `String` | Form, Required | Redirect Uri |
| `fieldParameters` | `Map<String, Object>` | Optional | Pass additional field parameters. |

## Response Type

[`OAuthToken`](../../doc/models/o-auth-token.md)

## Example Usage

```java
String authorization = "Authorization8";
String code = "code8";
String redirectUri = "redirect_uri8";
LinkedHashMap<String, Object> fieldParameters = new LinkedHashMap<>();
fieldParameters.put("key0", "additionalFieldParams9");

oAuthAuthorizationController.authorizationCodeAuthRequestTokenAsync(authorization, code, redirectUri, fieldParameters).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | OAuth 2 provider returned an error. | [`OAuthProviderException`](../../doc/models/o-auth-provider-exception.md) |
| 401 | OAuth 2 provider says client authentication failed. | [`OAuthProviderException`](../../doc/models/o-auth-provider-exception.md) |


# Authorization Code Auth Refresh Token

Obtain a new access token using a refresh token for authorization code auth

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<OAuthToken> authorizationCodeAuthRefreshTokenAsync(
    final String authorization,
    final String refreshToken,
    final String scope,
    final Map<String, Object> fieldParameters)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `authorization` | `String` | Header, Required | Authorization header in Basic auth format |
| `refreshToken` | `String` | Form, Required | Refresh token |
| `scope` | `String` | Form, Optional | Requested scopes as a space-delimited list. |
| `fieldParameters` | `Map<String, Object>` | Optional | Pass additional field parameters. |

## Response Type

[`OAuthToken`](../../doc/models/o-auth-token.md)

## Example Usage

```java
String authorization = "Authorization8";
String refreshToken = "refresh_token0";
LinkedHashMap<String, Object> fieldParameters = new LinkedHashMap<>();
fieldParameters.put("key0", "additionalFieldParams9");

oAuthAuthorizationController.authorizationCodeAuthRefreshTokenAsync(authorization, refreshToken, null, fieldParameters).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | OAuth 2 provider returned an error. | [`OAuthProviderException`](../../doc/models/o-auth-provider-exception.md) |
| 401 | OAuth 2 provider says client authentication failed. | [`OAuthProviderException`](../../doc/models/o-auth-provider-exception.md) |

