
# Client Class Documentation

The following parameters are configurable for the API Client:

| Parameter | Type | Description |
|  --- | --- | --- |
| `environment` | Environment | The API environment. <br> **Default: `Environment.PRODUCTION`** |
| `httpClientConfig` | `ReadonlyHttpClientConfiguration` | Http Client Configuration instance. |
| `authorizationCodeClientId` | `String` | OAuth 2 Client ID |
| `authorizationCodeClientSecret` | `String` | OAuth 2 Client Secret |
| `authorizationCodeRedirectUri` | `String` | OAuth 2 Redirection endpoint or Callback Uri |
| `authorizationCodeToken` | `OAuthToken` | Object for storing information about the OAuth token |
| `authorizationCodeScopes` | `List<AuthorizationCodeScopeEnum>` |  |

The API client can be initialized as follows:

```java
APIFinancingsOpenBankingBrasilClient client = new APIFinancingsOpenBankingBrasilClient.Builder()
    .httpClientConfig(configBuilder -> configBuilder
            .timeout(0))
    .oAuthScopes(Arrays.asList(OAuthScopeEnum.OPENID, OAuthScopeEnum.FINANCINGS))
    .authorizationCodeAuthCredentials("AuthorizationCodeClientId", "AuthorizationCodeClientSecret", "AuthorizationCodeRedirectUri")
    .environment(Environment.PRODUCTION)
    .build();
```

## API Financings - Open Banking BrasilClient Class

The gateway for the SDK. This class acts as a factory for the Controllers and also holds the configuration of the SDK.

### Controllers

| Name | Description | Return Type |
|  --- | --- | --- |
| `getFinancingsController()` | Provides access to Financings controller. | `FinancingsController` |
| `getOAuthAuthorizationController()` | Provides access to OAuthAuthorization controller. | `OAuthAuthorizationController` |

### Methods

| Name | Description | Return Type |
|  --- | --- | --- |
| `shutdown()` | Shutdown the underlying HttpClient instance. | `void` |
| `getEnvironment()` | Current API environment. | `Environment` |
| `getHttpClient()` | The HTTP Client instance to use for making HTTP requests. | `HttpClient` |
| `getHttpClientConfig()` | Http Client Configuration instance. | `ReadonlyHttpClientConfiguration` |
| `getBaseUri(Server server)` | Get base URI by current environment | `String` |
| `getBaseUri()` | Get base URI by current environment | `String` |

