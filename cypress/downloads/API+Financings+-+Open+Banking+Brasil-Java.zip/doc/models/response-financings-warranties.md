
# Response Financings Warranties

## Structure

`ResponseFinancingsWarranties`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Data` | [`List<FinancingsWarranties>`](../../doc/models/financings-warranties.md) | Required | **Constraints**: *Minimum Items*: `0` | List<FinancingsWarranties> getData() | setData(List<FinancingsWarranties> data) |
| `Links` | [`Links`](../../doc/models/links.md) | Required | Referências para outros recusos da API requisitada. | Links getLinks() | setLinks(Links links) |
| `Meta` | [`Meta`](../../doc/models/meta.md) | Required | Meta informações referente à API requisitada. | Meta getMeta() | setMeta(Meta meta) |

## Example (as JSON)

```json
{
  "data": [
    {
      "currency": null,
      "warrantyType": "SEGUROS_ASSEMELHADOS",
      "warrantySubType": "FGPC_FUNDO_GARANTIA_PROMOCAO_COMPETIT",
      "warrantyAmount": null
    },
    {
      "currency": null,
      "warrantyType": "GARANTIA_FIDEJUSSORIA",
      "warrantySubType": "FGTS_FUNDO_GARANTIA_TEMPO_SERVICO",
      "warrantyAmount": null
    }
  ],
  "links": {
    "self": "self2",
    "first": null,
    "prev": null,
    "next": null,
    "last": null
  },
  "meta": {
    "totalRecords": 122,
    "totalPages": 52,
    "requestDateTime": "2016-03-13T12:52:32.123Z"
  }
}
```

