
# Meta 1

Meta informações referente à API requisitada.

## Structure

`Meta1`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `RequestDateTime` | `LocalDateTime` | Required | Data e hora da consulta, conforme especificação RFC-3339, formato UTC. | LocalDateTime getRequestDateTime() | setRequestDateTime(LocalDateTime requestDateTime) |

## Example (as JSON)

```json
{
  "requestDateTime": "2016-03-13T12:52:32.123Z"
}
```

