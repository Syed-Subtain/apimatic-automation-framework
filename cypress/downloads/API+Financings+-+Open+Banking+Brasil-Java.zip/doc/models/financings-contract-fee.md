
# Financings Contract Fee

Objeto que traz o conjunto de informações necessárias para demonstrar a composição das taxas de juros remuneratórios da Modalidade de crédito

## Structure

`FinancingsContractFee`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `FeeName` | `String` | Required | Denominação da Tarifa pactuada<br>**Constraints**: *Maximum Length*: `140`, *Pattern*: `[\w\W\s]*` | String getFeeName() | setFeeName(String feeName) |
| `FeeCode` | `String` | Required | Sigla identificadora da tarifa pactuada<br>**Constraints**: *Maximum Length*: `140`, *Pattern*: `[\w\W\s]*` | String getFeeCode() | setFeeCode(String feeCode) |
| `FeeChargeType` | [`FeeChargeTypeEnum`](../../doc/models/fee-charge-type-enum.md) | Required | Tipo de cobrança para a tarifa pactuada no contrato. | FeeChargeTypeEnum getFeeChargeType() | setFeeChargeType(FeeChargeTypeEnum feeChargeType) |
| `FeeCharge` | [`FeeChargeEnum`](../../doc/models/fee-charge-enum.md) | Required | "Forma de cobrança relativa a tarifa pactuada no contrato. (Vide Enum)<br><br>- Mínimo<br>- Máximo<br>- Fixo<br>- Percentual" | FeeChargeEnum getFeeCharge() | setFeeCharge(FeeChargeEnum feeCharge) |
| `FeeAmount` | `String` | Optional | Valor monetário da tarifa pactuada no contrato.<br><br>[Restrição] Preenchimento obrigatório quando a forma de cobrança for diferente de Percentual.<br>**Constraints**: *Minimum Length*: `4`, *Maximum Length*: `20`, *Pattern*: `^\d{1,15}\.\d{2,4}$` | String getFeeAmount() | setFeeAmount(String feeAmount) |
| `FeeRate` | `String` | Optional | É o valor da tarifa em percentual pactuada no contrato.<br><br>[Restrição] Preenchimento obrigatório quando a forma de cobrança for Percentual.<br>**Constraints**: *Minimum Length*: `8`, *Maximum Length*: `8`, *Pattern*: `^[01]\.\d{6}$` | String getFeeRate() | setFeeRate(String feeRate) |

## Example (as JSON)

```json
{
  "feeName": "feeName2",
  "feeCode": "feeCode8",
  "feeChargeType": "UNICA",
  "feeCharge": "FIXO",
  "feeAmount": null,
  "feeRate": null
}
```

