
# Response Financings Instalments

## Structure

`ResponseFinancingsInstalments`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Data` | [`FinancingsInstalments`](../../doc/models/financings-instalments.md) | Required | Conjunto de informações referentes às parcelas / prestações da operação de crédito de financiamentos contratada | FinancingsInstalments getData() | setData(FinancingsInstalments data) |
| `Links` | [`Links`](../../doc/models/links.md) | Required | Referências para outros recusos da API requisitada. | Links getLinks() | setLinks(Links links) |
| `Meta` | [`Meta`](../../doc/models/meta.md) | Required | Meta informações referente à API requisitada. | Meta getMeta() | setMeta(Meta meta) |

## Example (as JSON)

```json
{
  "data": {
    "typeNumberOfInstalments": "MES",
    "totalNumberOfInstalments": null,
    "typeContractRemaining": "SEM_PRAZO_REMANESCENTE",
    "contractRemainingNumber": null,
    "paidInstalments": 112.16,
    "dueInstalments": null,
    "pastDueInstalments": null,
    "balloonPayments": null
  },
  "links": {
    "self": "self2",
    "first": null,
    "prev": null,
    "next": null,
    "last": null
  },
  "meta": {
    "totalRecords": 122,
    "totalPages": 52,
    "requestDateTime": "2016-03-13T12:52:32.123Z"
  }
}
```

