
# Financings Releases

Lista dos pagamentos realizados no período

## Structure

`FinancingsReleases`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `PaymentId` | `String` | Optional | Identificador de pagamento de responsabilidade de cada Instituição transmissora.<br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `100`, *Pattern*: `^[a-zA-Z0-9][a-zA-Z0-9-]{0,99}$` | String getPaymentId() | setPaymentId(String paymentId) |
| `IsOverParcelPayment` | `boolean` | Required | Identifica se é um pagamento pactuado (false) ou avulso (true). | boolean getIsOverParcelPayment() | setIsOverParcelPayment(boolean isOverParcelPayment) |
| `InstalmentId` | `String` | Optional | Identificador de parcela, de responsabilidade de cada Instituição transmissora.  <br>[Restrição] Informação de envio obrigatório quando isOverParcelPayment tiver o valor FALSE.<br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `100`, *Pattern*: `^[a-zA-Z0-9][a-zA-Z0-9-]{0,99}$` | String getInstalmentId() | setInstalmentId(String instalmentId) |
| `PaidDate` | `LocalDate` | Required | Data efetiva do pagamento referente ao contrato da modalidade de crédito consultada, conforme especificação RFC-3339. p.ex. 2014-03-19 | LocalDate getPaidDate() | setPaidDate(LocalDate paidDate) |
| `Currency` | `String` | Required | Moeda referente ao valor monetário informado, segundo modelo ISO-4217. p.ex. 'BRL'.<br>Todos os valores monetários informados estão representados com a moeda vigente do Brasil.<br>**Constraints**: *Maximum Length*: `3`, *Pattern*: `^(\w{3}){1}$` | String getCurrency() | setCurrency(String currency) |
| `PaidAmount` | `String` | Required | Valor do pagamento referente ao  contrato da modalidade de crédito consultada.<br>Expresso em valor monetário com no mínimo 2 casas e no máximo 4 casas decimais.<br>**Constraints**: *Minimum Length*: `4`, *Maximum Length*: `20`, *Pattern*: `^\d{1,15}\.\d{2,4}$` | String getPaidAmount() | setPaidAmount(String paidAmount) |
| `OverParcel` | [`FinancingsOverParcel`](../../doc/models/financings-over-parcel.md) | Optional | Objeto das tarifas e encargos que foram pagos fora da parcela.<br><br>[Restrição] Informação deve ser enviada caso ela exista. | FinancingsOverParcel getOverParcel() | setOverParcel(FinancingsOverParcel overParcel) |

## Example (as JSON)

```json
{
  "paymentId": null,
  "isOverParcelPayment": false,
  "instalmentId": null,
  "paidDate": "2016-03-13",
  "currency": "currency0",
  "paidAmount": "paidAmount6",
  "overParcel": null
}
```

