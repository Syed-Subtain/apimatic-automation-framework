
# Referential Rate Indexer Type Enum

"Tipos de taxas referenciais ou indexadores, conforme Anexo 5: Taxa referencial ou Indexador (Indx), do Documento 3040"

## Enumeration

`ReferentialRateIndexerTypeEnum`

## Fields

| Name |
|  --- |
| `SEMTIPOINDEXADOR` |
| `PREFIXADO` |
| `POSFIXADO` |
| `FLUTUANTES` |
| `INDICESPRECOS` |
| `CREDITORURAL` |
| `OUTROSINDEXADORES` |

