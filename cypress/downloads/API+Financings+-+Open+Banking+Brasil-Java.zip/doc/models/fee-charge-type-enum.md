
# Fee Charge Type Enum

Tipo de cobrança para a tarifa pactuada no contrato.

## Enumeration

`FeeChargeTypeEnum`

## Fields

| Name |
|  --- |
| `UNICA` |
| `PORPARCELA` |

