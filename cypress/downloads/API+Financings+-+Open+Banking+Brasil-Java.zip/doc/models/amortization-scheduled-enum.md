
# Amortization Scheduled Enum

Sistema de amortização (Vide Enum):

- SAC (Sistema de Amortização Constante) - É aquele em que o valor da amortização permanece igual até o final. Os juros cobrados sobre o parcelamento não entram nesta conta.
- PRICE (Sistema Francês de Amortização) - As parcelas são fixas do início ao fim do contrato. Ou seja, todas as parcelas terão o mesmo valor, desde a primeira até a última. Nos primeiros pagamentos, a maior parte do valor da prestação corresponde aos juros. Ao longo do tempo, a taxa de juros vai decrescendo. Como o valor da prestação é fixo, com o passar das parcelas, o valor de amortização vai aumentando.
- SAM (Sistema de Amortização Misto) - Cada prestação (pagamento) é a média aritmética das prestações respectivas no Sistemas Price e no Sistema de Amortização Constante (SAC).
- SEM SISTEMA DE AMORTIZAÇÃO

## Enumeration

`AmortizationScheduledEnum`

## Fields

| Name |
|  --- |
| `SAC` |
| `PRICE` |
| `SAM` |
| `SEMSISTEMAAMORTIZACAO` |
| `OUTROS` |

