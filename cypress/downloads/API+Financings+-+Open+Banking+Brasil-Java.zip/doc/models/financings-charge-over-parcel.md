
# Financings Charge Over Parcel

## Structure

`FinancingsChargeOverParcel`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `ChargeType` | [`EnumContractFinanceChargeTypeEnum`](../../doc/models/enum-contract-finance-charge-type-enum.md) | Required | Tipo de encargo pactuado no contrato. | EnumContractFinanceChargeTypeEnum getChargeType() | setChargeType(EnumContractFinanceChargeTypeEnum chargeType) |
| `ChargeAmount` | `String` | Required | Valor do pagamento do encargo pago fora da parcela. Expresso em valor monetário com no mínimo 2 casas e no máximo 4 casas decimais.<br>**Constraints**: *Minimum Length*: `4`, *Maximum Length*: `20`, *Pattern*: `^\d{1,15}\.\d{2,4}$` | String getChargeAmount() | setChargeAmount(String chargeAmount) |
| `ChargeAdditionalInfo` | `String` | Optional | Campo livre para preenchimento das informações adicionais referente ao encargo.<br><br>[Restrição] Obrigatório quando chargeType for igual 'OUTROS'.<br>**Constraints**: *Maximum Length*: `140`, *Pattern*: `[\w\W\s]*` | String getChargeAdditionalInfo() | setChargeAdditionalInfo(String chargeAdditionalInfo) |

## Example (as JSON)

```json
{
  "chargeType": "IOF_CONTRATACAO",
  "chargeAmount": "chargeAmount0",
  "chargeAdditionalInfo": null
}
```

