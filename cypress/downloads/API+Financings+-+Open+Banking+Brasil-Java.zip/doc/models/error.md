
# Error

## Structure

`Error`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Code` | `String` | Required | Código de erro específico do endpoint<br>**Constraints**: *Maximum Length*: `255`, *Pattern*: `[\w\W\s]*` | String getCode() | setCode(String code) |
| `Title` | `String` | Required | Título legível por humanos deste erro específico<br>**Constraints**: *Maximum Length*: `255`, *Pattern*: `[\w\W\s]*` | String getTitle() | setTitle(String title) |
| `Detail` | `String` | Required | Descrição legível por humanos deste erro específico<br>**Constraints**: *Maximum Length*: `2048`, *Pattern*: `[\w\W\s]*` | String getDetail() | setDetail(String detail) |

## Example (as JSON)

```json
{
  "code": "code8",
  "title": "title4",
  "detail": "detail6"
}
```

