
# Financings List Contract

Conjunto de informações  de contratos de financiamento mantidos pelo cliente na instituição transmissora e para os quais ele tenha fornecido consentimento

## Structure

`FinancingsListContract`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `ContractId` | `String` | Required | Identifica de forma única o contrato da operação de crédito do cliente, mantendo as regras de imutabilidade dentro da instituição transmissora.<br>**Constraints**: *Maximum Length*: `100`, *Pattern*: `^[a-zA-Z0-9][a-zA-Z0-9-]{0,99}$` | String getContractId() | setContractId(String contractId) |
| `BrandName` | `String` | Required | Nome da Marca reportada pelo participante no Open Finance. Recomenda-se utilizar, sempre que possível, o mesmo nome de marca atribuído no campo do diretório Customer Friendly Server Name (Authorisation Server).<br>**Constraints**: *Maximum Length*: `80`, *Pattern*: `[\w\W\s]*` | String getBrandName() | setBrandName(String brandName) |
| `CompanyCnpj` | `String` | Required | Número completo do CNPJ da instituição responsável pelo Cadastro - o CNPJ corresponde ao número de inscrição no Cadastro de Pessoa Jurídica. Deve-se ter apenas os números do CNPJ, sem máscara.<br>**Constraints**: *Maximum Length*: `14`, *Pattern*: `^\d{14}$` | String getCompanyCnpj() | setCompanyCnpj(String companyCnpj) |
| `ProductType` | [`EnumProductTypeEnum`](../../doc/models/enum-product-type-enum.md) | Required | "Tipo da modalidade de crédito contratada, conforme  circular 4.015 e descrição do DOC3040 do SCR). (Vide Enum)<br>Financiamentos, Financiamentos rurais  e Financiamentos imobiliários" | EnumProductTypeEnum getProductType() | setProductType(EnumProductTypeEnum productType) |
| `ProductSubType` | [`EnumProductSubTypeEnum`](../../doc/models/enum-product-sub-type-enum.md) | Required | "Sub tipo da modalidades de crédito contratadas, conforme  circular 4.015 e descrição do DOC3040 do SCR). (Vide Enum)<br>Aquisição de bens veículos automotores, Aquisição de bens de outros bens, Microcrédito, Custeio, Investimento, Industrialização, Comercialização, Financiamento habitacional SFH e Financiamento habitacional exceto SFH" | EnumProductSubTypeEnum getProductSubType() | setProductSubType(EnumProductSubTypeEnum productSubType) |
| `IpocCode` | `String` | Required | Número padronizado do contrato - IPOC (Identificação Padronizada da Operação de Crédito). Segundo DOC 3040, composta por:<br><br>- **CNPJ da instituição:** 8 (oito) posições iniciais;<br>- **Modalidade da operação:** 4 (quatro) posições;<br>- **Tipo do cliente:** 1 (uma) posição( 1 = pessoa natural - CPF, 2= pessoa jurídica – CNPJ, 3 = pessoa física no exterior, 4 = pessoa jurídica no exterior, 5 = pessoa natural sem CPF e 6 = pessoa jurídica sem CNPJ);<br>- **Código do cliente:** O número de posições varia conforme o tipo do cliente:<br>  1. Para clientes pessoa física com CPF (tipo de cliente = 1), informar as 11 (onze) posições do CPF;<br>  2. Para clientes pessoa jurídica com CNPJ (tipo de cliente = 2), informar as 8 (oito) posições iniciais do CNPJ;<br>  3. Para os demais clientes (tipos de cliente 3, 4, 5 e 6), informar 14 (catorze) posições com complemento de zeros à esquerda se a identificação tiver tamanho inferior;<br>- **Código do contrato:** 1 (uma) até 40 (quarenta) posições, sem complemento de caracteres.<br>**Constraints**: *Minimum Length*: `22`, *Maximum Length*: `67`, *Pattern*: `^\d{22,67}$` | String getIpocCode() | setIpocCode(String ipocCode) |

## Example (as JSON)

```json
{
  "contractId": "contractId2",
  "brandName": "brandName4",
  "companyCnpj": "companyCnpj4",
  "productType": "FINANCIAMENTOS",
  "productSubType": "AQUISICAO_BENS_VEICULOS_AUTOMOTORES",
  "ipocCode": "ipocCode0"
}
```

