
# Meta

Meta informações referente à API requisitada.

## Structure

`Meta`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `TotalRecords` | `int` | Required | Número total de registros no resultado | int getTotalRecords() | setTotalRecords(int totalRecords) |
| `TotalPages` | `int` | Required | Número total de páginas no resultado | int getTotalPages() | setTotalPages(int totalPages) |
| `RequestDateTime` | `LocalDateTime` | Required | Data e hora da consulta, conforme especificação RFC-3339, formato UTC. | LocalDateTime getRequestDateTime() | setRequestDateTime(LocalDateTime requestDateTime) |

## Example (as JSON)

```json
{
  "totalRecords": 76,
  "totalPages": 98,
  "requestDateTime": "2016-03-13T12:52:32.123Z"
}
```

