
# Financings Finance Charge

Conjunto de informações referentes à identificação da operação de crédito

## Structure

`FinancingsFinanceCharge`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `ChargeType` | [`EnumContractFinanceChargeTypeEnum`](../../doc/models/enum-contract-finance-charge-type-enum.md) | Required | Tipo de encargo pactuado no contrato. | EnumContractFinanceChargeTypeEnum getChargeType() | setChargeType(EnumContractFinanceChargeTypeEnum chargeType) |
| `ChargeAdditionalInfo` | `String` | Optional | Campo para informações adicionais.<br><br>[Restrição] Obrigatório se selecionada a opção 'OUTROS' em Tipo de encargo pactuado no contrato.<br>**Constraints**: *Maximum Length*: `50`, *Pattern*: `[\w\W\s]*` | String getChargeAdditionalInfo() | setChargeAdditionalInfo(String chargeAdditionalInfo) |
| `ChargeRate` | `String` | Optional | Representa o valor do encargo em percentual pactuado no contrato.  <br>O preenchimento deve respeitar as 6 casas decimais, mesmo que venham preenchidas com zeros(representação de porcentagem p.ex: 0.150000.<br>Este valor representa 15%. O valor 1 representa 100%).<br>**Constraints**: *Minimum Length*: `8`, *Maximum Length*: `8`, *Pattern*: `^[01]\.\d{6}$` | String getChargeRate() | setChargeRate(String chargeRate) |

## Example (as JSON)

```json
{
  "chargeType": "IOF_CONTRATACAO",
  "chargeAdditionalInfo": null,
  "chargeRate": null
}
```

