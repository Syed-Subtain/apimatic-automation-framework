
# Type Contract Remaining Enum

Tipo de prazo remanescente do contrato referente à modalidade de crédito informada.

## Enumeration

`TypeContractRemainingEnum`

## Fields

| Name |
|  --- |
| `DIA` |
| `SEMANA` |
| `MES` |
| `ANO` |
| `SEMPRAZOREMANESCENTE` |

