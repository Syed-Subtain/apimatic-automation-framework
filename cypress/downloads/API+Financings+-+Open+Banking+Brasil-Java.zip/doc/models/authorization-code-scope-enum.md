
# Authorization Code Scope Enum

OAuth 2 scopes supported by the API

## Enumeration

`AuthorizationCodeScopeEnum`

## Fields

| Name | Description |
|  --- | --- |
| `Openid` |  |
| `Financings` | Escopo necessário para acesso à API Financings. O controle dos endpoints específicos é feito via permissions. |
| `ConsentconsentId` |  |

