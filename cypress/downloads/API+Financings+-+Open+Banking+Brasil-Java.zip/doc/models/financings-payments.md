
# Financings Payments

Conjunto de informações referentes aos pagamentos realizados de uma operação de crédito de adiantamento a depositantes

## Structure

`FinancingsPayments`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `PaidInstalments` | `Double` | Optional | Quantidade total de parcelas pagas do contrato referente à Modalidade de Crédito informada.<br><br>[Restrição] Obrigatório para modalidades que possuam parcelas.<br>**Constraints**: `<= 2147483647` | Double getPaidInstalments() | setPaidInstalments(Double paidInstalments) |
| `ContractOutstandingBalance` | `String` | Required | Valor necessario para o cliente liquidar a dívida.<br>**Constraints**: *Minimum Length*: `4`, *Maximum Length*: `20`, *Pattern*: `^\d{1,15}\.\d{2,4}$` | String getContractOutstandingBalance() | setContractOutstandingBalance(String contractOutstandingBalance) |
| `Releases` | [`List<FinancingsReleases>`](../../doc/models/financings-releases.md) | Required | Lista dos pagamentos realizados no período<br>**Constraints**: *Minimum Items*: `0` | List<FinancingsReleases> getReleases() | setReleases(List<FinancingsReleases> releases) |

## Example (as JSON)

```json
{
  "paidInstalments": null,
  "contractOutstandingBalance": "contractOutstandingBalance2",
  "releases": [
    {
      "paymentId": null,
      "isOverParcelPayment": false,
      "instalmentId": null,
      "paidDate": "2016-03-13",
      "currency": "currency2",
      "paidAmount": "paidAmount4",
      "overParcel": null
    }
  ]
}
```

