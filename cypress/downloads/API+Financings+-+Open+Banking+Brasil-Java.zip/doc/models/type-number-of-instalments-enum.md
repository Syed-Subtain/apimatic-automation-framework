
# Type Number of Instalments Enum

Tipo de prazo total do contrato referente à modalidade de crédito informada.

## Enumeration

`TypeNumberOfInstalmentsEnum`

## Fields

| Name |
|  --- |
| `DIA` |
| `SEMANA` |
| `MES` |
| `ANO` |
| `SEMPRAZOTOTAL` |

