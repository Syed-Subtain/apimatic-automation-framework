
# Response Error

## Structure

`ResponseError`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Errors` | [`List<Error>`](../../doc/models/error.md) | Required | **Constraints**: *Minimum Items*: `1`, *Maximum Items*: `13` | List<Error> getErrors() | setErrors(List<Error> errors) |
| `Meta` | [`Meta1`](../../doc/models/meta-1.md) | Optional | Meta informações referente à API requisitada. | Meta1 getMeta() | setMeta(Meta1 meta) |

## Example (as JSON)

```json
{
  "errors": [
    {
      "code": "code3",
      "title": "title1",
      "detail": "detail1"
    },
    {
      "code": "code4",
      "title": "title2",
      "detail": "detail2"
    },
    {
      "code": "code5",
      "title": "title3",
      "detail": "detail3"
    }
  ],
  "meta": null
}
```

