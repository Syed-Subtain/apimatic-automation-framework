
# Financings Over Parcel

Objeto das tarifas e encargos que foram pagos fora da parcela.

[Restrição] Informação deve ser enviada caso ela exista.

## Structure

`FinancingsOverParcel`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Fees` | [`List<FinancingsFeeOverParcel>`](../../doc/models/financings-fee-over-parcel.md) | Required | Lista das tarifas que foram pagas fora da parcela, só para pagamento avulso.<br>**Constraints**: *Minimum Items*: `0` | List<FinancingsFeeOverParcel> getFees() | setFees(List<FinancingsFeeOverParcel> fees) |
| `Charges` | [`List<FinancingsChargeOverParcel>`](../../doc/models/financings-charge-over-parcel.md) | Required | Lista dos encargos que foram pagos fora da parcela.<br>**Constraints**: *Minimum Items*: `0` | List<FinancingsChargeOverParcel> getCharges() | setCharges(List<FinancingsChargeOverParcel> charges) |

## Example (as JSON)

```json
{
  "fees": [
    {
      "feeName": "feeName7",
      "feeCode": "feeCode3",
      "feeAmount": "feeAmount1"
    },
    {
      "feeName": "feeName6",
      "feeCode": "feeCode2",
      "feeAmount": "feeAmount2"
    }
  ],
  "charges": [
    {
      "chargeType": "IOF_POR_ATRASO",
      "chargeAmount": "chargeAmount8",
      "chargeAdditionalInfo": null
    },
    {
      "chargeType": "IOF_CONTRATACAO",
      "chargeAmount": "chargeAmount9",
      "chargeAdditionalInfo": null
    }
  ]
}
```

