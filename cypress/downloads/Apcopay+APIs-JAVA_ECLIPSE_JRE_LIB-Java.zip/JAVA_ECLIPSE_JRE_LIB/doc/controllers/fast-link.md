# Fast Link

```java
FastLinkController fastLinkController = client.getFastLinkController();
```

## Class Name

`FastLinkController`


# Generate Fast Link

```java
CompletableFuture<Void> generateFastLinkAsync(
    final GenerateFastLinkRequest body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`GenerateFastLinkRequest`](../../doc/models/generate-fast-link-request.md) | Body, Required | - |

## Server

`Server.SERVER_2`

## Response Type

`void`

## Example Usage

```java
GenerateFastLinkRequest body = new GenerateFastLinkRequest();
body.setMchCode("1111");
body.setMerchnatPassword("MCHPASS");
body.setOrderRef("testFLGen");
body.setDescription("Testing");
body.setCurrency("EUR");
body.setAmount("19");
body.setValidUntil("2019/11/14");
body.setNotificationURL("");
body.setEXTRADATA("");
body.setActionType(1);
body.setName("tester");
body.setSurname("testing");
body.setEmail("test@test.com");
body.setMobileNumber("99887788");
body.setShowTermsAndConditions(true);

fastLinkController.generateFastLinkAsync(body).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

