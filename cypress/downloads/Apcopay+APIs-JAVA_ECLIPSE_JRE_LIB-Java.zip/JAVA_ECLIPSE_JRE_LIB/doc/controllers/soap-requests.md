# SOAP Requests

```java
SOAPRequestsController sOAPRequestsController = client.getSOAPRequestsController();
```

## Class Name

`SOAPRequestsController`

## Methods

* [Card Tokenization](../../doc/controllers/soap-requests.md#card-tokenization)
* [Do Transaction](../../doc/controllers/soap-requests.md#do-transaction)
* [Do 3 D Secure Transaction](../../doc/controllers/soap-requests.md#do-3-d-secure-transaction)
* [Get 3 DS Transaction Status](../../doc/controllers/soap-requests.md#get-3-ds-transaction-status)


# Card Tokenization

```java
CompletableFuture<Void> cardTokenizationAsync(
    final Envelope body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`Envelope`](../../doc/models/envelope.md) | Body, Required | - |

## Server

`Server.SERVER_1`

## Response Type

`void`

## Example Usage

```java
Envelope body = new Envelope();
body.setBody(new Body());
body.getBody().setPopulateTransactionData2(new PopulateTransactionData2());
body.getBody().getPopulateTransactionData2().setMerchID(5299);
body.getBody().getPopulateTransactionData2().setPassword(1234);
body.getBody().getPopulateTransactionData2().setCardType("VISA");
body.getBody().getPopulateTransactionData2().setCardNo(4711100000000000L);
body.getBody().getPopulateTransactionData2().setExpMonth("01");
body.getBody().getPopulateTransactionData2().setExpYear(2020);
body.getBody().getPopulateTransactionData2().setExt(123);
body.getBody().getPopulateTransactionData2().setCardHolderName("APCO TEST");
body.getBody().getPopulateTransactionData2().setCardHolderAddress("Malad Mindspace");
body.getBody().getPopulateTransactionData2().setCardIssueNum("");
body.getBody().getPopulateTransactionData2().setCardStartMonth("");
body.getBody().getPopulateTransactionData2().setCardStartYear("");
body.getBody().getPopulateTransactionData2().setPspID("");

sOAPRequestsController.cardTokenizationAsync(body).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```


# Do Transaction

```java
CompletableFuture<Void> doTransactionAsync(
    final Envelope2 body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`Envelope2`](../../doc/models/envelope-2.md) | Body, Required | - |

## Server

`Server.SERVER_1`

## Response Type

`void`

## Example Usage

```java
Envelope2 body = new Envelope2();
body.setBody(new Body2());
body.getBody().setDoTransaction(new DoTransaction());
body.getBody().getDoTransaction().setMerchID(7561);
body.getBody().getDoTransaction().setPass("testkey");
body.getBody().getDoTransaction().setTrType(1);
body.getBody().getDoTransaction().setCardNum(4444444444444444L);
body.getBody().getDoTransaction().setCVV2(512);
body.getBody().getDoTransaction().setExpDay("06");
body.getBody().getDoTransaction().setExpMonth("06");
body.getBody().getDoTransaction().setExpYear(2021);
body.getBody().getDoTransaction().setCardHName("Apco Test");
body.getBody().getDoTransaction().setAmount(17.88);
body.getBody().getDoTransaction().setCurrencyCode(978);
body.getBody().getDoTransaction().setAddr("1, main street, town, country, code");
body.getBody().getDoTransaction().setPostCode(3243224);
body.getBody().getDoTransaction().setTransID("string");
body.getBody().getDoTransaction().setUserIP("78.133.117.182");
body.getBody().getDoTransaction().setUDF1("string");
body.getBody().getDoTransaction().setUDF2("CT=TESTCARD");
body.getBody().getDoTransaction().setUDF3("<WS><Email>test@apco.com</Email>vL5yuV6X1UiHKC<CIP>1.1.1.1</CIP></WS>");
body.getBody().getDoTransaction().setOrderRef("string");

sOAPRequestsController.doTransactionAsync(body).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```


# Do 3 D Secure Transaction

```java
CompletableFuture<Void> do3DSecureTransactionAsync(
    final Envelope3 body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`Envelope3`](../../doc/models/envelope-3.md) | Body, Required | - |

## Server

`Server.SERVER_1`

## Response Type

`void`

## Example Usage

```java
Envelope3 body = new Envelope3();
body.setBody(new Body3());
body.getBody().setDo3DSTransaction(new Do3DSTransaction());
body.getBody().getDo3DSTransaction().setMerchID(7561);
body.getBody().getDo3DSTransaction().setMerchPassword("test key");
body.getBody().getDo3DSTransaction().setTrType(1);
body.getBody().getDo3DSTransaction().setCardNum(4444444444442228L);
body.getBody().getDo3DSTransaction().setCVV2(123);
body.getBody().getDo3DSTransaction().setExpDay("01");
body.getBody().getDo3DSTransaction().setExpMonth("01");
body.getBody().getDo3DSTransaction().setExpYear(2025);
body.getBody().getDo3DSTransaction().setCardHName("Apco Tesr");
body.getBody().getDo3DSTransaction().setAmount(49.94);
body.getBody().getDo3DSTransaction().setCurrencyCode(978);
body.getBody().getDo3DSTransaction().setAddr("string");
body.getBody().getDo3DSTransaction().setPostCode("string");
body.getBody().getDo3DSTransaction().setTransID("string");
body.getBody().getDo3DSTransaction().setUserIP("string");
body.getBody().getDo3DSTransaction().setUDF1("string");
body.getBody().getDo3DSTransaction().setUDF2("string");
body.getBody().getDo3DSTransaction().setUDF3("%3CWS%3E%3CForceBank%3EPTEST%3C%2FForceBank%3E%3C%2FWS%3E");
body.getBody().getDo3DSTransaction().setOrderRef("string");

sOAPRequestsController.do3DSecureTransactionAsync(body).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```


# Get 3 DS Transaction Status

```java
CompletableFuture<Void> get3DSTransactionStatusAsync(
    final Envelope1 body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`Envelope1`](../../doc/models/envelope-1.md) | Body, Required | - |

## Server

`Server.SERVER_1`

## Response Type

`void`

## Example Usage

```java
Envelope1 body = new Envelope1();
body.setBody(new Body1());
body.getBody().setGet3DSTransactionStatus(new Get3DSTransactionStatus());
body.getBody().getGet3DSTransactionStatus().setMCHCode(8493);
body.getBody().getGet3DSTransactionStatus().setMCHPass("testkey");
body.getBody().getGet3DSTransactionStatus().setTicket3D(UUID.fromString("f0b47e3a36444eed93f4811d99dd7f6b"));

sOAPRequestsController.get3DSTransactionStatusAsync(body).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

