# Wallet Payments

```java
WalletPaymentsController walletPaymentsController = client.getWalletPaymentsController();
```

## Class Name

`WalletPaymentsController`


# Google Pay API

Send ApcoPay the encrypted payment token from Google Pay for Payment Processing

```java
CompletableFuture<GooglePayDepositResponse> googlePayAPIAsync(
    final String contentType,
    final GooglePayDepositRequest body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `contentType` | `String` | Header, Required | - |
| `body` | [`GooglePayDepositRequest`](../../doc/models/google-pay-deposit-request.md) | Body, Required | - |

## Server

`Server.SERVER_2`

## Response Type

[`GooglePayDepositResponse`](../../doc/models/google-pay-deposit-response.md)

## Example Usage

```java
String contentType = "application/json";
GooglePayDepositRequest body = new GooglePayDepositRequest();
body.setMerchID("7561");
body.setRegName("John Doe");
body.setCurrencyCode("978");
body.setAmount("1.0");
body.setORef("OREF1");
body.setClientAcc("neil");
body.setAddress("street,city,state,zip");
body.setRegCountry("MT");
body.setWalletProvider("GOOGLEPAY");
body.setWalletToken("1234");
body.setUserIP("1.1.1.1");
body.setSignature("e0c806954dc75c9e6b801e9676181b9ad455f3a36a69fa672b162ead727962a4");
body.setRedirectionURL("https://mywebsite.com/return");
body.setStatusUrl("https://mywebsite.com/callback");

walletPaymentsController.googlePayAPIAsync(contentType, body).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

