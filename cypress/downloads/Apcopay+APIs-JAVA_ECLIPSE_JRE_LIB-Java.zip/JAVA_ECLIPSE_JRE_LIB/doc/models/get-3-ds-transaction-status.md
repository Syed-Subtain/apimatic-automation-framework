
# Get 3 DS Transaction Status

Get Status of 3DSecure Authentication

## Structure

`Get3DSTransactionStatus`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `MCHCode` | `int` | Required | APCOPAY Merchant ID | int getMCHCode() | setMCHCode(int mCHCode) |
| `MCHPass` | `String` | Required | APCOPAY Merchant Password | String getMCHPass() | setMCHPass(String mCHPass) |
| `Ticket3D` | `UUID` | Required | 3DSecure ID Returned | UUID getTicket3D() | setTicket3D(UUID ticket3D) |

## Example (as XML)

```xml
<get3DSTransactionStatus>
  <MCHCode>128</MCHCode>
  <MCHPass>MCHPass4</MCHPass>
  <Ticket3D>0000144a-0000-0000-0000-000000000000</Ticket3D>
</get3DSTransactionStatus>
```

