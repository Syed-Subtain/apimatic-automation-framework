
# Get Daily Transactions Request

Get a List of Daily Transactions

## Structure

`GetDailyTransactionsRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `MerchID` | `String` | Required | APCOPAY Merchant ID | String getMerchID() | setMerchID(String merchID) |
| `MerchPass` | `String` | Required | APCOPAY Merchant Password | String getMerchPass() | setMerchPass(String merchPass) |
| `Date` | `String` | Required | Date for Transaction Report | String getDate() | setDate(String date) |

## Example (as JSON)

```json
{
  "MerchID": "MerchID",
  "MerchPass": "MerchPass",
  "Date": "20201009"
}
```

