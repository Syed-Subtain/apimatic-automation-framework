
# Google Pay Deposit Response

## Structure

`GooglePayDepositResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Result` | `String` | Required | - | String getResult() | setResult(String result) |
| `ErrorCode` | `int` | Required | - | int getErrorCode() | setErrorCode(int errorCode) |
| `ErrorMessage` | `String` | Required | - | String getErrorMessage() | setErrorMessage(String errorMessage) |

## Example (as JSON)

```json
{
  "Result": "NOTOK",
  "ErrorCode": 1,
  "ErrorMessage": "Invalid Request"
}
```

