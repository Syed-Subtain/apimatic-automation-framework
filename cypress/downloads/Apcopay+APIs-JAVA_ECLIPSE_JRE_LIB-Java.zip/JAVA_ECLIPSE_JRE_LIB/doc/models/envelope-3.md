
# Envelope 3

## Structure

`Envelope3`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Body` | [`Body3`](../../doc/models/body-3.md) | Required | - | Body3 getBody() | setBody(Body3 body) |

## Example (as XML)

```xml
<soap:Envelope xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">
  <soap:Body xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">
    <Do3DSTransaction>
      <MerchID>60</MerchID>
      <MerchPassword>MerchPassword2</MerchPassword>
      <TrType>110</TrType>
      <CardNum>104</CardNum>
      <CVV2>32</CVV2>
      <ExpDay>ExpDay2</ExpDay>
      <ExpMonth>ExpMonth4</ExpMonth>
      <ExpYear>80</ExpYear>
      <CardHName>CardHName6</CardHName>
      <Amount>19.54</Amount>
      <CurrencyCode>216</CurrencyCode>
      <Addr>Addr6</Addr>
      <PostCode>PostCode6</PostCode>
      <TransID>TransID0</TransID>
      <UserIP>UserIP8</UserIP>
      <UDF1>UDF14</UDF1>
      <UDF2>UDF24</UDF2>
      <UDF3>UDF36</UDF3>
      <OrderRef>OrderRef8</OrderRef>
    </Do3DSTransaction>
  </soap:Body>
</soap:Envelope>
```

