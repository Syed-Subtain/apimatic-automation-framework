
# Compute Hash Request

Pass XML Request to get Hashed XML

## Structure

`ComputeHashRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `MerchID` | `String` | Required | APCOPAY Merchant ID | String getMerchID() | setMerchID(String merchID) |
| `MerchPass` | `String` | Required | APCOPAY Merchant Password | String getMerchPass() | setMerchPass(String merchPass) |
| `XMLParam` | `String` | Required | XML Document with Transaction Request for Hash Calculation | String getXMLParam() | setXMLParam(String xMLParam) |

## Example (as JSON)

```json
{
  "MerchID": "MerchID",
  "MerchPass": "MerchPass",
  "XMLParam": "<Transaction hash=\"password\"><ProfileID>A803B8D2A9F6F</ProfileID><ActionType>1</ActionType><Value>1.00</Value><Curr>978</Curr><Lang>en</Lang><ORef>TestReference01</ORef><Email>support@apcolabs.tech</Email><UDF1 /><UDF2 /><UDF3 /><RedirectionURL>https://www.apsp.biz/pay/PaymentOptionsTests/Redirect</RedirectionURL><status_url urlEncode=\"True\">https://www.apsp.biz/pay/TestFp/TestListener.aspx</status_url><ForceBank>PTESTv2</ForceBank><ForcePayment>MBKR</ForcePayment><TEST /><MainAcquirer>DIRECT</MainAcquirer></Transaction>"
}
```

