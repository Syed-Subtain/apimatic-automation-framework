
# Google Pay Deposit Request

Google Pay Deposit Payload Request

## Structure

`GooglePayDepositRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `MerchID` | `String` | Required | APCOPAY Merchant ID | String getMerchID() | setMerchID(String merchID) |
| `RegName` | `String` | Required | Card Holder Name | String getRegName() | setRegName(String regName) |
| `CurrencyCode` | `String` | Required | Transaction Currency Code 3 Digit ISO Code | String getCurrencyCode() | setCurrencyCode(String currencyCode) |
| `Amount` | `String` | Required | Transaction Value | String getAmount() | setAmount(String amount) |
| `ORef` | `String` | Required | Merchant Payment Reference | String getORef() | setORef(String oRef) |
| `ClientAcc` | `String` | Required | The user's registered account on website. The client account is mandatory if additional functionality such of restrictions of cards per account is used for the payment request. | String getClientAcc() | setClientAcc(String clientAcc) |
| `Address` | `String` | Required | The user's full address in the format of House No, Street, City,ZIP, State. Values to be separated by comma. All values must be filled in. | String getAddress() | setAddress(String address) |
| `RegCountry` | `String` | Required | The user's registration country. Use the 2 letter country code. | String getRegCountry() | setRegCountry(String regCountry) |
| `WalletProvider` | `String` | Required | Wallet Provider - GOOGLEPAY/APPLEPAY | String getWalletProvider() | setWalletProvider(String walletProvider) |
| `WalletToken` | `String` | Required | Encrypted Payment Token Received from Wallet Provider | String getWalletToken() | setWalletToken(String walletToken) |
| `UserIP` | `String` | Required | The user's IP Address | String getUserIP() | setUserIP(String userIP) |
| `Signature` | `String` | Required | Sha256 calculation of alphabetically sorted values of Address & Amount & ClientAcc & CurrencyCode & CardHName & MerchId &  ORef & UserIP & MerchPass | String getSignature() | setSignature(String signature) |
| `RedirectionURL` | `String` | Required | Redirection URL for the user to be redirected after 3DSecure Authentication | String getRedirectionURL() | setRedirectionURL(String redirectionURL) |
| `StatusUrl` | `String` | Required | Call back URL to receive asynchronous response for 3DSecure transactions after payment and authentication are completed | String getStatusUrl() | setStatusUrl(String statusUrl) |

## Example (as JSON)

```json
{
  "MerchID": "7561",
  "RegName": "John Doe",
  "CurrencyCode": "978",
  "Amount": "1.0",
  "ORef": "OREF1",
  "ClientAcc": "neil",
  "Address": "street,city,state,zip",
  "RegCountry": "MT",
  "WalletProvider": "GOOGLEPAY",
  "WalletToken": "1234",
  "UserIP": "1.1.1.1",
  "Status_url": "https://mywebsite.com/callback",
  "RedirectionURL": "https://mywebsite.com/return",
  "Signature": "e0c806954dc75c9e6b801e9676181b9ad455f3a36a69fa672b162ead727962a4"
}
```

