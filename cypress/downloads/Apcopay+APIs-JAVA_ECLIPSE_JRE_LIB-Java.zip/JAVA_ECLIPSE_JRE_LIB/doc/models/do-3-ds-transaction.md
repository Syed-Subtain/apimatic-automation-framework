
# Do 3 DS Transaction

## Structure

`Do3DSTransaction`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `MerchID` | `int` | Required | - | int getMerchID() | setMerchID(int merchID) |
| `MerchPassword` | `String` | Required | - | String getMerchPassword() | setMerchPassword(String merchPassword) |
| `TrType` | `int` | Required | - | int getTrType() | setTrType(int trType) |
| `CardNum` | `long` | Required | - | long getCardNum() | setCardNum(long cardNum) |
| `CVV2` | `int` | Required | - | int getCVV2() | setCVV2(int cVV2) |
| `ExpDay` | `String` | Required | - | String getExpDay() | setExpDay(String expDay) |
| `ExpMonth` | `String` | Required | - | String getExpMonth() | setExpMonth(String expMonth) |
| `ExpYear` | `int` | Required | - | int getExpYear() | setExpYear(int expYear) |
| `CardHName` | `String` | Required | - | String getCardHName() | setCardHName(String cardHName) |
| `Amount` | `double` | Required | - | double getAmount() | setAmount(double amount) |
| `CurrencyCode` | `int` | Required | - | int getCurrencyCode() | setCurrencyCode(int currencyCode) |
| `Addr` | `String` | Required | - | String getAddr() | setAddr(String addr) |
| `PostCode` | `String` | Required | - | String getPostCode() | setPostCode(String postCode) |
| `TransID` | `String` | Required | - | String getTransID() | setTransID(String transID) |
| `UserIP` | `String` | Required | - | String getUserIP() | setUserIP(String userIP) |
| `UDF1` | `String` | Required | - | String getUDF1() | setUDF1(String uDF1) |
| `UDF2` | `String` | Required | - | String getUDF2() | setUDF2(String uDF2) |
| `UDF3` | `String` | Required | - | String getUDF3() | setUDF3(String uDF3) |
| `OrderRef` | `String` | Required | - | String getOrderRef() | setOrderRef(String orderRef) |

## Example (as XML)

```xml
<Do3DSTransaction>
  <MerchID>122</MerchID>
  <MerchPassword>MerchPassword0</MerchPassword>
  <TrType>48</TrType>
  <CardNum>214</CardNum>
  <CVV2>226</CVV2>
  <ExpDay>ExpDay0</ExpDay>
  <ExpMonth>ExpMonth2</ExpMonth>
  <ExpYear>18</ExpYear>
  <CardHName>CardHName4</CardHName>
  <Amount>57.88</Amount>
  <CurrencyCode>22</CurrencyCode>
  <Addr>Addr4</Addr>
  <PostCode>PostCode4</PostCode>
  <TransID>TransID2</TransID>
  <UserIP>UserIP6</UserIP>
  <UDF1>UDF16</UDF1>
  <UDF2>UDF26</UDF2>
  <UDF3>UDF38</UDF3>
  <OrderRef>OrderRef0</OrderRef>
</Do3DSTransaction>
```

