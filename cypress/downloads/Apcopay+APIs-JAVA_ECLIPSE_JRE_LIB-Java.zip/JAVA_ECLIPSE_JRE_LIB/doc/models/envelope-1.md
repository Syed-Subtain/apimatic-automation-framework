
# Envelope 1

## Structure

`Envelope1`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Body` | [`Body1`](../../doc/models/body-1.md) | Required | - | Body1 getBody() | setBody(Body1 body) |

## Example (as XML)

```xml
<soap:Envelope xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">
  <soap:Body xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">
    <get3DSTransactionStatus>
      <MCHCode>4</MCHCode>
      <MCHPass>MCHPass4</MCHPass>
      <Ticket3D>00000e6e-0000-0000-0000-000000000000</Ticket3D>
    </get3DSTransactionStatus>
  </soap:Body>
</soap:Envelope>
```

