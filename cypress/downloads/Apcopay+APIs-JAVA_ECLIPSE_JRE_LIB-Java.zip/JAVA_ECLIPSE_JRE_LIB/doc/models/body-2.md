
# Body 2

## Structure

`Body2`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `DoTransaction` | [`DoTransaction`](../../doc/models/do-transaction.md) | Required | - | DoTransaction getDoTransaction() | setDoTransaction(DoTransaction doTransaction) |

## Example (as XML)

```xml
<soap:Body xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">
  <DoTransaction>
    <Amount>1</Amount>
    <CurrencyCode>978</CurrencyCode>
  </DoTransaction>
</soap:Body>
```

