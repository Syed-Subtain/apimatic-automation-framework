
# Get Transactions XML Response Request

Get XML Response sent to Listener URL for Merchant Order Reference

## Structure

`GetTransactionsXMLResponseRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `MerchID` | `String` | Required | APCOPAY Merchant ID | String getMerchID() | setMerchID(String merchID) |
| `MerchPass` | `String` | Required | APCOPAY Merchant Password | String getMerchPass() | setMerchPass(String merchPass) |
| `Oref` | `String` | Required | Merchant Order Reference | String getOref() | setOref(String oref) |

## Example (as JSON)

```json
{
  "MerchID": "7561",
  "MerchPass": "apcotest34",
  "Oref": "TestReference01"
}
```

