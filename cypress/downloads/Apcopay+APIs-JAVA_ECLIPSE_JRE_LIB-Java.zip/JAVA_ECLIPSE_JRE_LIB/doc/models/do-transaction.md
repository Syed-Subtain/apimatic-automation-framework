
# Do Transaction

## Structure

`DoTransaction`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `MerchID` | `int` | Required | APCOPAY Merchant ID | int getMerchID() | setMerchID(int merchID) |
| `Pass` | `String` | Required | APCOPAY Merchant Password | String getPass() | setPass(String pass) |
| `TrType` | `int` | Required | Transaction Type | int getTrType() | setTrType(int trType) |
| `CardNum` | `long` | Required | Card Number | long getCardNum() | setCardNum(long cardNum) |
| `CVV2` | `int` | Required | Card Verification Code (CVV) | int getCVV2() | setCVV2(int cVV2) |
| `ExpDay` | `String` | Required | Expiry Day | String getExpDay() | setExpDay(String expDay) |
| `ExpMonth` | `String` | Required | Expiry Month | String getExpMonth() | setExpMonth(String expMonth) |
| `ExpYear` | `int` | Required | Expiry Year | int getExpYear() | setExpYear(int expYear) |
| `CardHName` | `String` | Required | Card Holder Name | String getCardHName() | setCardHName(String cardHName) |
| `Amount` | `double` | Required | Transaction Amount | double getAmount() | setAmount(double amount) |
| `CurrencyCode` | `int` | Required | 3-Digit Currency Code | int getCurrencyCode() | setCurrencyCode(int currencyCode) |
| `Addr` | `String` | Required | Card Holder Address | String getAddr() | setAddr(String addr) |
| `PostCode` | `int` | Required | Address Post Code | int getPostCode() | setPostCode(int postCode) |
| `TransID` | `String` | Required | Transaction ID of Previous Deposit - To be used for action types for actions on previous transactions | String getTransID() | setTransID(String transID) |
| `UserIP` | `String` | Required | Card Holder IP Address | String getUserIP() | setUserIP(String userIP) |
| `UDF1` | `String` | Required | User Defined Field | String getUDF1() | setUDF1(String uDF1) |
| `UDF2` | `String` | Required | User Defined Field | String getUDF2() | setUDF2(String uDF2) |
| `UDF3` | `String` | Required | User Defined Field | String getUDF3() | setUDF3(String uDF3) |
| `OrderRef` | `String` | Required | Transaction Order Reference | String getOrderRef() | setOrderRef(String orderRef) |

## Example (as XML)

```xml
<DoTransaction>
  <Amount>1</Amount>
  <CurrencyCode>978</CurrencyCode>
</DoTransaction>
```

