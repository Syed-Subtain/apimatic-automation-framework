
# Get Transaction Status Request

## Structure

`GetTransactionStatusRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `MerchID` | `String` | Required | - | String getMerchID() | setMerchID(String merchID) |
| `MerchPass` | `String` | Required | - | String getMerchPass() | setMerchPass(String merchPass) |
| `Oref` | `String` | Required | - | String getOref() | setOref(String oref) |

## Example (as JSON)

```json
{
  "MerchID": "MerchID",
  "MerchPass": "MerhcPass",
  "Oref": "TestReference01"
}
```

