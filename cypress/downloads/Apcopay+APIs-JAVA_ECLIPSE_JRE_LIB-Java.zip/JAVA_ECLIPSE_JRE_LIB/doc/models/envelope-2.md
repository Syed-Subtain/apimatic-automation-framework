
# Envelope 2

## Structure

`Envelope2`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Body` | [`Body2`](../../doc/models/body-2.md) | Required | - | Body2 getBody() | setBody(Body2 body) |

## Example (as XML)

```xml
<soap:Envelope xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">
  <soap:Body xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">
    <DoTransaction>
      <Amount>1</Amount>
      <CurrencyCode>978</CurrencyCode>
    </DoTransaction>
  </soap:Body>
</soap:Envelope>
```

