
# Body 3

## Structure

`Body3`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Do3DSTransaction` | [`Do3DSTransaction`](../../doc/models/do-3-ds-transaction.md) | Required | - | Do3DSTransaction getDo3DSTransaction() | setDo3DSTransaction(Do3DSTransaction do3DSTransaction) |

## Example (as XML)

```xml
<soap:Body xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">
  <Do3DSTransaction>
    <MerchID>228</MerchID>
    <MerchPassword>MerchPassword8</MerchPassword>
    <TrType>198</TrType>
    <CardNum>192</CardNum>
    <CVV2>120</CVV2>
    <ExpDay>ExpDay8</ExpDay>
    <ExpMonth>ExpMonth0</ExpMonth>
    <ExpYear>168</ExpYear>
    <CardHName>CardHName2</CardHName>
    <Amount>104.9</Amount>
    <CurrencyCode>128</CurrencyCode>
    <Addr>Addr2</Addr>
    <PostCode>PostCode2</PostCode>
    <TransID>TransID6</TransID>
    <UserIP>UserIP4</UserIP>
    <UDF1>UDF18</UDF1>
    <UDF2>UDF22</UDF2>
    <UDF3>UDF30</UDF3>
    <OrderRef>OrderRef2</OrderRef>
  </Do3DSTransaction>
</soap:Body>
```

