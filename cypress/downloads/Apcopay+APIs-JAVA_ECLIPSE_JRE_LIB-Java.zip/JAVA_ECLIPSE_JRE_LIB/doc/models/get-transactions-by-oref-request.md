
# Get Transactions by Oref Request

Get Transaction Details of Merchant Order Reference Used in Transaction Request

## Structure

`GetTransactionsByOrefRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `MerchID` | `String` | Required | APCOPAY Merchant ID | String getMerchID() | setMerchID(String merchID) |
| `MerchPass` | `String` | Required | APCOPAY Merchant Password | String getMerchPass() | setMerchPass(String merchPass) |
| `Oref` | `String` | Required | Merchant Order Reference | String getOref() | setOref(String oref) |

## Example (as JSON)

```json
{
  "MerchID": "MerchID",
  "MerchPass": "MerchPass",
  "Oref": "TestReference01"
}
```

