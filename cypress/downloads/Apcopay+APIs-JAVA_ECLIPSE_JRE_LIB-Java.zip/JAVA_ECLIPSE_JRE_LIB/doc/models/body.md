
# Body

## Structure

`Body`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `PopulateTransactionData2` | [`PopulateTransactionData2`](../../doc/models/populate-transaction-data-2.md) | Required | - | PopulateTransactionData2 getPopulateTransactionData2() | setPopulateTransactionData2(PopulateTransactionData2 populateTransactionData2) |

## Example (as XML)

```xml
<soap:Body xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">
  <PopulateTransactionData2>
    <MerchID>26</MerchID>
    <Password>24</Password>
    <CardType>CardType8</CardType>
    <CardNo>236</CardNo>
    <ExpMonth>ExpMonth2</ExpMonth>
    <ExpYear>114</ExpYear>
    <Ext>104</Ext>
    <CardHolderName>CardHolderName2</CardHolderName>
    <CardHolderAddress>CardHolderAddress0</CardHolderAddress>
    <CardIssueNum>CardIssueNum0</CardIssueNum>
    <CardStartMonth>CardStartMonth4</CardStartMonth>
    <CardStartYear>CardStartYear2</CardStartYear>
    <PspID>PspID0</PspID>
  </PopulateTransactionData2>
</soap:Body>
```

