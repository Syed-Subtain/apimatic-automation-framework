
# Populate Transaction Data 2

Tokenize Card Request

## Structure

`PopulateTransactionData2`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `MerchID` | `int` | Required | APCOPAY Merchant ID | int getMerchID() | setMerchID(int merchID) |
| `Password` | `int` | Required | APCOPAY Merchant Password | int getPassword() | setPassword(int password) |
| `CardType` | `String` | Required | Card Type | String getCardType() | setCardType(String cardType) |
| `CardNo` | `long` | Required | Card Number | long getCardNo() | setCardNo(long cardNo) |
| `ExpMonth` | `String` | Required | Expiry Month | String getExpMonth() | setExpMonth(String expMonth) |
| `ExpYear` | `int` | Required | Expiry Year | int getExpYear() | setExpYear(int expYear) |
| `Ext` | `int` | Required | Card Verification Code (CVV) | int getExt() | setExt(int ext) |
| `CardHolderName` | `String` | Required | Card Holder Name | String getCardHolderName() | setCardHolderName(String cardHolderName) |
| `CardHolderAddress` | `String` | Required | Card Holder Address | String getCardHolderAddress() | setCardHolderAddress(String cardHolderAddress) |
| `CardIssueNum` | `String` | Required | - | String getCardIssueNum() | setCardIssueNum(String cardIssueNum) |
| `CardStartMonth` | `String` | Required | - | String getCardStartMonth() | setCardStartMonth(String cardStartMonth) |
| `CardStartYear` | `String` | Required | - | String getCardStartYear() | setCardStartYear(String cardStartYear) |
| `PspID` | `String` | Required | - | String getPspID() | setPspID(String pspID) |

## Example (as XML)

```xml
<PopulateTransactionData2>
  <MerchID>122</MerchID>
  <Password>184</Password>
  <CardType>CardType8</CardType>
  <CardNo>140</CardNo>
  <ExpMonth>ExpMonth2</ExpMonth>
  <ExpYear>18</ExpYear>
  <Ext>248</Ext>
  <CardHolderName>CardHolderName8</CardHolderName>
  <CardHolderAddress>CardHolderAddress0</CardHolderAddress>
  <CardIssueNum>CardIssueNum0</CardIssueNum>
  <CardStartMonth>CardStartMonth4</CardStartMonth>
  <CardStartYear>CardStartYear2</CardStartYear>
  <PspID>PspID0</PspID>
</PopulateTransactionData2>
```

