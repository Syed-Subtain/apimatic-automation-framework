
# Get Cards Used by Account Request

## Structure

`GetCardsUsedByAccountRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `MerchID` | `String` | Required | - | String getMerchID() | setMerchID(String merchID) |
| `MerchPass` | `String` | Required | - | String getMerchPass() | setMerchPass(String merchPass) |
| `ClientAccount` | `String` | Required | - | String getClientAccount() | setClientAccount(String clientAccount) |

## Example (as JSON)

```json
{
  "MerchID": "7561",
  "MerchPass": "testkey",
  "ClientAccount": "neil"
}
```

