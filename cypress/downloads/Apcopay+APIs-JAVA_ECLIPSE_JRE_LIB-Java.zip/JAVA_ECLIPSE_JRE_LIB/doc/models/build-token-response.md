
# Build Token Response

Returned Response of Build XML Token Request

## Structure

`BuildTokenResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Result` | `String` | Required | Return Result for the Build Payment Token | String getResult() | setResult(String result) |
| `BaseURL` | `String` | Required | Base URL for Payment Page | String getBaseURL() | setBaseURL(String baseURL) |
| `ErrorMsg` | `String` | Required | Error Message for Build Token | String getErrorMsg() | setErrorMsg(String errorMsg) |
| `Token` | `String` | Required | Token for the Transaction Request - Append to BaseURL and Return User to complete payment | String getToken() | setToken(String token) |

## Example (as JSON)

```json
{
  "Result": "OK",
  "ErrorMsg": "",
  "BaseURL": "https://www.apsp.biz/pay/FP6/Checkout.aspx?FPToken=",
  "Token": "3295BCEE70AC44B0AAFBC92947CD8E98"
}
```

