
# Build XML Token Request

## Structure

`BuildXMLTokenRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `MerchID` | `String` | Required | APCOPAY Merchant ID | String getMerchID() | setMerchID(String merchID) |
| `MerchPass` | `String` | Required | APCOPAY Merchant Password | String getMerchPass() | setMerchPass(String merchPass) |
| `XMLParam` | `String` | Required | <strong>XML Parameters</strong> to be used in Transaction Request: For full list and more details on XML Parameters, visit <em>https://www.apimatic.io/apidocs/apcopayapi/v/1_0#/http/payments/xml-parameters</em></td> <table width="771"> <thead> <tr> <td style="width: 119.75px;"> <p>Name</p> </td> <td style="width: 616.25px;"> <p>Description</p> </td> </tr> </thead> <tbody> <tr> <td style="width: 119.75px;"> <p><strong>hash</strong></p> <p><span style="color: #ff0000; font-size: 8pt;">REQUIRED</span></p> </td> <td style="width: 616.25px;"> <p>String</p> </td> </tr> <tr> <td style="width: 119.75px;"> <p><strong>ProfileID</strong></p> <p><span style="color: #ff0000; font-size: 8pt;">REQUIRED</span></p> </td> <td style="width: 616.25px;"> <p>String</p> <p>APCOPAY Merchant's Profile ID</p> </td> </tr> <tr> <td style="width: 119.75px;"> <p><strong>ActionType</strong></p> <p><span style="color: #ff0000; font-size: 8pt;">REQUIRED</span></p> </td> <td style="width: 616.25px;"> <p>Number</p> <p>Use one of the following Transaction Types for&nbsp;<strong>Deposits / Refunds / Captures / Voids</strong><br />1 - Purchase<br />4 - Authorization<br />5 - Capture<br />12 - Refund<br />13 - Original Credit [OCT]</p> </td> </tr> <tr> <td style="width: 119.75px;"> <p><strong>Value</strong></p> <p><span style="color: #ff0000; font-size: 8pt;">REQUIRED</span></p> </td> <td style="width: 616.25px;"> <p>Decimal</p> <p>Transaction Value</p> </td> </tr> <tr> <td style="width: 119.75px;"> <p><strong>Curr</strong></p> <p><span style="color: #ff0000; font-size: 8pt;">REQUIRED</span></p> </td> <td style="width: 616.25px;"> <p>Number</p> <p>Transaction Currency Code 3 Digit ISO Code</p> </td> </tr> <tr> <td style="width: 119.75px;"> <p><strong>Lang</strong></p> <p><span style="color: #ff0000; font-size: 8pt;">REQUIRED</span></p> </td> <td style="width: 616.25px;"> <p>String</p> <p>Payment Page Language Code in 2 letter code</p> </td> </tr> <tr> <td style="width: 119.75px;"> <p><strong>ORef</strong></p> <p><span style="color: #ff0000; font-size: 8pt;">REQUIRED</span></p> </td> <td style="width: 616.25px;"> <p>String</p> <p>Merchant Payment Reference</p> </td> </tr> <tr> <td style="width: 119.75px;"> <p><strong>UDF1</strong></p> <p><span style="color: #ff0000; font-size: 8pt;">REQUIRED</span></p> </td> <td style="width: 616.25px;"> <p>String</p> <p>Merchant Payment Extra Data</p> </td> </tr> <tr> <td style="width: 119.75px;"> <p><strong>UDF2</strong></p> <p><span style="color: #ff0000; font-size: 8pt;">REQUIRED</span></p> </td> <td style="width: 616.25px;"> <p>String</p> <p>Merchant Payment Extra Data</p> </td> </tr>   <tr> <td style="width: 119.75px;"> <p><strong>UDF3</strong></p> <p><span style="color: #ff0000; font-size: 8pt;">REQUIRED</span></p> </td> <td style="width: 616.25px;"> <p>String</p> <p>Merchant Payment Extra Data</p> </td> </tr> <tr> <td style="width: 119.75px;"> <p><strong>status_url</strong></p> <p><span style="color: #ff0000; font-size: 8pt;">REQUIRED</span></p> </td> <td style="width: 616.25px;"> <p>String</p> <p>URL For Payment Notifications. An attribute of urlEncode=true/false is required to specify if payment response sent is url Encoded.</p> </td> </tr>   <tr> <td style="width: 119.75px;"> <p><strong>RedirectionURL</strong></p> <p><span style="color: #ff0000; font-size: 8pt;">REQUIRED</span></p> </td> <td style="width: 616.25px;"> <p>String</p> <p>The Merchant Redirection URL for the user to be redirected to after payment success / pending state.</p> </td> </tr> </tbody> </table> | String getXMLParam() | setXMLParam(String xMLParam) |

## Example (as JSON)

```json
{
  "MerchID": "7561",
  "MerchPass": "apcotest",
  "XMLParam": "<Transaction hash=\"TestKey\"><ProfileID>F26C4BD40A454028A8F9E85806A6395C</ProfileID><Value>1.00</Value><Curr>978</Curr><Lang>en</Lang><ORef>30082021131002740</ORef><ClientAcc>Test</ClientAcc><MobileNo>03569988451</MobileNo><Email>joedoe@mail.com</Email><RedirectionURL>https://www.google.com/thankyoupage.html</RedirectionURL><UDF1 /><UDF2 /><UDF3 /><FastPay><ListAllCards>ALL</ListAllCards><NewCard1Try /><NewCardOnFail /><PromptCVV /><PromptExpiry /></FastPay><ActionType>4</ActionType><status_url urlEncode=\"true\">https://www.google.com</status_url><HideSSLLogo></HideSSLLogo><AntiFraud><Provider></Provider></AntiFraud><return_pspid></return_pspid><ForceBank>PTEST</ForceBank><ByPass3ds /><ForcePayment>TESTCARD</ForcePayment></Transaction>"
}
```

