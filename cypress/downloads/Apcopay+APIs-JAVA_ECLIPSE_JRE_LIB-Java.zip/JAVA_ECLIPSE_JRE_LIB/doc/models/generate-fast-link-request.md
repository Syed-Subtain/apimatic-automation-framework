
# Generate Fast Link Request

Generate Links for Fast Link Payment Solution

## Structure

`GenerateFastLinkRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `MchCode` | `String` | Required | APCOPAY Merchant ID | String getMchCode() | setMchCode(String mchCode) |
| `MerchnatPassword` | `String` | Required | APCOPAY Merchant Password | String getMerchnatPassword() | setMerchnatPassword(String merchnatPassword) |
| `OrderRef` | `String` | Required | Merchant Order Reference | String getOrderRef() | setOrderRef(String orderRef) |
| `Description` | `String` | Required | - | String getDescription() | setDescription(String description) |
| `Currency` | `String` | Required | Transaction Currency | String getCurrency() | setCurrency(String currency) |
| `Amount` | `String` | Required | Transaction Value | String getAmount() | setAmount(String amount) |
| `ValidUntil` | `String` | Required | Link Expiration Date | String getValidUntil() | setValidUntil(String validUntil) |
| `NotificationURL` | `String` | Required | - | String getNotificationURL() | setNotificationURL(String notificationURL) |
| `EXTRADATA` | `String` | Required | - | String getEXTRADATA() | setEXTRADATA(String eXTRADATA) |
| `ActionType` | `int` | Required | - | int getActionType() | setActionType(int actionType) |
| `Name` | `String` | Required | - | String getName() | setName(String name) |
| `Surname` | `String` | Required | - | String getSurname() | setSurname(String surname) |
| `Email` | `String` | Required | - | String getEmail() | setEmail(String email) |
| `MobileNumber` | `String` | Required | - | String getMobileNumber() | setMobileNumber(String mobileNumber) |
| `ShowTermsAndConditions` | `boolean` | Required | - | boolean getShowTermsAndConditions() | setShowTermsAndConditions(boolean showTermsAndConditions) |
| `Street1` | `String` | Optional | Client Address - Street 1 | String getStreet1() | setStreet1(String street1) |
| `Street2` | `String` | Optional | Client Address - Street 2 | String getStreet2() | setStreet2(String street2) |
| `City` | `String` | Optional | Client Address - City | String getCity() | setCity(String city) |
| `State` | `String` | Optional | Client Address - State | String getState() | setState(String state) |
| `RegCountry` | `String` | Optional | Client Address - RegCountry | String getRegCountry() | setRegCountry(String regCountry) |
| `ClientAcc` | `String` | Optional | The user's registered account on website. The client account is mandatory if additional functionality such of restrictions of cards per account is used for the payment request. | String getClientAcc() | setClientAcc(String clientAcc) |

## Example (as JSON)

```json
{
  "MchCode": "1111",
  "MerchnatPassword": "MCHPASS",
  "OrderRef": "testFLGen",
  "Description": "Testing",
  "Currency": "EUR",
  "Amount": "19",
  "ValidUntil": "2019/11/14",
  "NotificationURL": "",
  "EXTRADATA": "",
  "ActionType": 1,
  "Name": "tester",
  "Surname": "testing",
  "Email": "test@test.com",
  "MobileNumber": "99887788",
  "ShowTermsAndConditions": true
}
```

