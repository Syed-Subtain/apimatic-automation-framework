
# Get Last Card Numbers Request

Get List of Card Numbers used by Client Account

## Structure

`GetLastCardNumbersRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `MerchID` | `String` | Required | APCOPAY Merchant ID | String getMerchID() | setMerchID(String merchID) |
| `MerchPass` | `String` | Required | APCOPAY Merchant Password | String getMerchPass() | setMerchPass(String merchPass) |
| `ClientAccount` | `String` | Required | Registered Client Account | String getClientAccount() | setClientAccount(String clientAccount) |

## Example (as JSON)

```json
{
  "MerchID": "7561",
  "MerchPass": "testkey",
  "ClientAccount": "UserTesting"
}
```

