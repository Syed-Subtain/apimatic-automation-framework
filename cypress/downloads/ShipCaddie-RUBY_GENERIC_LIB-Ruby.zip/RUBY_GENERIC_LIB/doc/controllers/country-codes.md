# Country Codes

```ruby
country_codes_controller = client.country_codes
```

## Class Name

`CountryCodesController`


# Get Country Codes

Country information is needed for constructing addresses.

```ruby
def get_country_codes(input: nil)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `input` | [`CountryCodesRequestv21`](/doc/models/country-codes-requestv-21.md) | Body, Optional | - |

## Response Type

[`CountryCodesResponsev21`](/doc/models/country-codes-responsev-21.md)

## Example Usage

```ruby
input = CountryCodesRequestv21.new
input.access_token = '<YOUR ACCESS TOKEN>'
input.as_client_id = 14

result = country_codes_controller.get_country_codes(input: input)
```

## Example Response *(as JSON)*

```json
{
  "countryCodeList": [
    {
      "countryId": 10,
      "countryName": "Antarctica",
      "alpha2CountryCode": "AQ"
    },
    {
      "countryId": 840,
      "countryName": "United States",
      "alpha2CountryCode": "US"
    }
  ],
  "error": {
    "details": [],
    "hasError": false
  }
}
```

