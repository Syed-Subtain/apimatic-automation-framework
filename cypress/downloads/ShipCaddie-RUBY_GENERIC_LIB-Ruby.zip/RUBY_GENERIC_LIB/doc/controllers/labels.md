# Labels

```ruby
labels_controller = client.labels
```

## Class Name

`LabelsController`

## Methods

* [Get Labels by Shipping ID With Cost](/doc/controllers/labels.md#get-labels-by-shipping-id-with-cost)
* [Void Label](/doc/controllers/labels.md#void-label)
* [Get Shipping Labels by Shipping ID](/doc/controllers/labels.md#get-shipping-labels-by-shipping-id)
* [Get Shipping Labels](/doc/controllers/labels.md#get-shipping-labels)
* [Get Label With Cost](/doc/controllers/labels.md#get-label-with-cost)


# Get Labels by Shipping ID With Cost

The labels are represented by a base 64 string.

```ruby
def get_labels_by_shipping_id_with_cost(input: nil)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `input` | [`GetShippingLabelsByShippingIDRequestv21`](/doc/models/get-shipping-labels-by-shipping-id-requestv-21.md) | Body, Optional | - |

## Response Type

[`LabelInformationWithCost`](/doc/models/label-information-with-cost.md)

## Example Usage

```ruby
input = GetShippingLabelsByShippingIDRequestv21.new
input.access_token = '<YOUR ACCESS TOKEN>'
input.as_client_id = 12
input.shipment_id = 19
input.print_format = PrintFormatEnum::PNG_4X6
input.certify_test_override = CertifyTestOverrideEnum::CONTRACT

result = labels_controller.get_labels_by_shipping_id_with_cost(input: input)
```


# Void Label

In some conditions - such as already shipped parcels - the labels will not be voided.

```ruby
def void_label(input: nil)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `input` | [`VoidLabelRequestv21`](/doc/models/void-label-requestv-21.md) | Body, Optional | - |

## Response Type

[`VoidLabelResponsev21`](/doc/models/void-label-responsev-21.md)

## Example Usage

```ruby
input = VoidLabelRequestv21.new
input.access_token = '<YOUR ACCESS TOKEN>'
input.as_client_id = 12
input.label_key = '329058_340709_shp_dfc02221ff5e4b78a45558ef474b6713'

result = labels_controller.void_label(input: input)
```

## Example Response *(as JSON)*

```json
{
  "trackingNumber": "9405536895239111999004",
  "error": {
    "details": [],
    "hasError": false
  }
}
```


# Get Shipping Labels by Shipping ID

The labels are represented by a base 64 string.

```ruby
def get_shipping_labels_by_shipping_id(input: nil)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `input` | [`GetShippingLabelsByShippingIDRequestv21`](/doc/models/get-shipping-labels-by-shipping-id-requestv-21.md) | Body, Optional | - |

## Response Type

[`LabelInformation`](/doc/models/label-information.md)

## Example Usage

```ruby
input = GetShippingLabelsByShippingIDRequestv21.new
input.access_token = '<YOUR ACCESS TOKEN>'
input.as_client_id = 12
input.shipment_id = 19
input.print_format = PrintFormatEnum::PNG_4X6
input.certify_test_override = CertifyTestOverrideEnum::CONTRACT

result = labels_controller.get_shipping_labels_by_shipping_id(input: input)
```


# Get Shipping Labels

The labels are represented by a base 64 string.

```ruby
def get_shipping_labels(input: nil)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `input` | [`GetShippingLabelsRequestv21`](/doc/models/get-shipping-labels-requestv-21.md) | Body, Optional | - |

## Response Type

[`LabelInformation`](/doc/models/label-information.md)

## Example Usage

```ruby
input = GetShippingLabelsRequestv21.new
input.access_token = '<YOUR ACCESS TOKEN>'
input.as_client_id = 12
input.print_format = PrintFormatEnum::PNG_4X6
input.shipment = ShipmentInformation.new
input.shipment.order_reference_number = 'test order'
input.shipment.date_shipped = DateTimeHelper.from_rfc3339('2020-12-23T23:54:10.3117094Z')
input.shipment.options = ShippingOptions.new
input.shipment.options.is_apo_fpo_dpo_us_territory = false
input.shipment.options.is_international_shipment = false
input.shipment.options.billing = BillingOptions.new
input.shipment.options.billing.shipping_paid_by = ShippingPaidByEnum::NOT_APPLICABLE
input.shipment.options.billing.account_number = ''
input.shipment.options.billing.postal_code = ''
input.shipment.options.billing.country_alpha2_code = ''
input.shipment.options.billing.duties_paid_by = DutiesPaidByEnum::NOT_APPLICABLE
input.shipment.options.shipment_content_type = ShipmentContentTypeEnum::CONTENT_TYPE_SAMPLE
input.shipment.carrier_client_contract_id = 2404
input.shipment.carrier_service_level_id = 1115
input.shipment.address_from = ShipFromAddress.new
input.shipment.address_from.company_name = 'iDrive Logistics'
input.shipment.address_from.email = 'sales@idrivelogistics.com'
input.shipment.address_from.phone_number = '(888) 797-0929'
input.shipment.address_from.address1 = '2600 Executive Pkwy #160'
input.shipment.address_from.address2 = ''
input.shipment.address_from.city = 'Lehi'
input.shipment.address_from.state_or_province = 'UT'
input.shipment.address_from.postal_code = '84043'
input.shipment.address_from.country_code = 'US'
input.shipment.address_to = ShipToAddress.new
input.shipment.address_to.attention_of = 'Mr. Jones'
input.shipment.address_to.company_name = 'iDrive Logistics'
input.shipment.address_to.email = 'sales@idrivelogistics.com'
input.shipment.address_to.phone_number = '(888) 797-0929'
input.shipment.address_to.address1 = '2605 Executive Pkwy #160'
input.shipment.address_to.address2 = ''
input.shipment.address_to.is_residential = false
input.shipment.address_to.city = 'Lehi'
input.shipment.address_to.state_or_province = 'UT'
input.shipment.address_to.postal_code = '84043'
input.shipment.address_to.country_code = 'US'
input.shipment.parcels = []


input.shipment.parcels[0] = ParcelDetail.new
input.shipment.parcels[0].reference_field1 = '1'
input.shipment.parcels[0].reference_field2 = ''
input.shipment.parcels[0].reference_field3 = ''
input.shipment.parcels[0].parcel_id = '1'
input.shipment.parcels[0].packaging_id = ''
input.shipment.parcels[0].weight_in_pounds = 0.4
input.shipment.parcels[0].length_in_inches = 5
input.shipment.parcels[0].width_in_inches = 4
input.shipment.parcels[0].height_in_inches = 12
input.shipment.parcels[0].options = ParcelOptions.new
input.shipment.parcels[0].options.mreturn = ReturnEnum::NOT_APPLICABLE
input.shipment.parcels[0].options.insurance_amount = 0
input.shipment.parcels[0].options.signature = SignatureEnum::NOT_APPLICABLE
input.shipment.parcels[0].options.cod = CODOptions.new
input.shipment.parcels[0].options.cod.cod_type = CodTypeEnum::NOT_APPLICABLE
input.shipment.parcels[0].options.cod.cod_amount = 0
input.shipment.parcels[0].parcel_items = []


input.shipment.parcels[0].parcel_items[0] = ParcelContent.new
input.shipment.parcels[0].parcel_items[0].sku = 'none'
input.shipment.parcels[0].parcel_items[0].name = 'chocolate'
input.shipment.parcels[0].parcel_items[0].description = 'candy'
input.shipment.parcels[0].parcel_items[0].quantity = 7
input.shipment.parcels[0].parcel_items[0].price = 1.03
input.shipment.parcels[0].parcel_items[0].weight_in_pounds = 0.5
input.shipment.parcels[0].parcel_items[0].harmonize_code = ''
input.shipment.parcels[0].parcel_items[0].origin_country = 'US'


input.certify_test_override = CertifyTestOverrideEnum::CONTRACT
input.image_rotation = ImageRotationEnum::ROTATENONEFLIPNONE

result = labels_controller.get_shipping_labels(input: input)
```


# Get Label With Cost

The labels are represented by a base 64 string.

```ruby
def get_label_with_cost(input: nil)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `input` | [`GetShippingLabelsRequestv21`](/doc/models/get-shipping-labels-requestv-21.md) | Body, Optional | - |

## Response Type

[`LabelInformationWithCost`](/doc/models/label-information-with-cost.md)

## Example Usage

```ruby
input = GetShippingLabelsRequestv21.new
input.access_token = '<YOUR ACCESS TOKEN>'
input.as_client_id = 12
input.print_format = PrintFormatEnum::PNG_4X6
input.shipment = ShipmentInformation.new
input.shipment.order_reference_number = 'test order'
input.shipment.date_shipped = DateTimeHelper.from_rfc3339('2020-12-23T23:54:10.3117094Z')
input.shipment.options = ShippingOptions.new
input.shipment.options.is_apo_fpo_dpo_us_territory = false
input.shipment.options.is_international_shipment = false
input.shipment.options.billing = BillingOptions.new
input.shipment.options.billing.shipping_paid_by = ShippingPaidByEnum::NOT_APPLICABLE
input.shipment.options.billing.account_number = ''
input.shipment.options.billing.postal_code = ''
input.shipment.options.billing.country_alpha2_code = ''
input.shipment.options.billing.duties_paid_by = DutiesPaidByEnum::NOT_APPLICABLE
input.shipment.options.shipment_content_type = ShipmentContentTypeEnum::CONTENT_TYPE_SAMPLE
input.shipment.carrier_client_contract_id = 2404
input.shipment.carrier_service_level_id = 1115
input.shipment.address_from = ShipFromAddress.new
input.shipment.address_from.company_name = 'iDrive Logistics'
input.shipment.address_from.email = 'sales@idrivelogistics.com'
input.shipment.address_from.phone_number = '(888) 797-0929'
input.shipment.address_from.address1 = '2600 Executive Pkwy #160'
input.shipment.address_from.address2 = ''
input.shipment.address_from.city = 'Lehi'
input.shipment.address_from.state_or_province = 'UT'
input.shipment.address_from.postal_code = '84043'
input.shipment.address_from.country_code = 'US'
input.shipment.address_to = ShipToAddress.new
input.shipment.address_to.attention_of = 'Mr. Jones'
input.shipment.address_to.company_name = 'iDrive Logistics'
input.shipment.address_to.email = 'sales@idrivelogistics.com'
input.shipment.address_to.phone_number = '(888) 797-0929'
input.shipment.address_to.address1 = '2605 Executive Pkwy #160'
input.shipment.address_to.address2 = ''
input.shipment.address_to.is_residential = false
input.shipment.address_to.city = 'Lehi'
input.shipment.address_to.state_or_province = 'UT'
input.shipment.address_to.postal_code = '84043'
input.shipment.address_to.country_code = 'US'
input.shipment.parcels = []


input.shipment.parcels[0] = ParcelDetail.new
input.shipment.parcels[0].reference_field1 = '1'
input.shipment.parcels[0].reference_field2 = ''
input.shipment.parcels[0].reference_field3 = ''
input.shipment.parcels[0].parcel_id = '1'
input.shipment.parcels[0].packaging_id = ''
input.shipment.parcels[0].weight_in_pounds = 0.4
input.shipment.parcels[0].length_in_inches = 5
input.shipment.parcels[0].width_in_inches = 4
input.shipment.parcels[0].height_in_inches = 12
input.shipment.parcels[0].options = ParcelOptions.new
input.shipment.parcels[0].options.mreturn = ReturnEnum::NOT_APPLICABLE
input.shipment.parcels[0].options.insurance_amount = 0
input.shipment.parcels[0].options.signature = SignatureEnum::NOT_APPLICABLE
input.shipment.parcels[0].options.cod = CODOptions.new
input.shipment.parcels[0].options.cod.cod_type = CodTypeEnum::NOT_APPLICABLE
input.shipment.parcels[0].options.cod.cod_amount = 0
input.shipment.parcels[0].parcel_items = []


input.shipment.parcels[0].parcel_items[0] = ParcelContent.new
input.shipment.parcels[0].parcel_items[0].sku = 'none'
input.shipment.parcels[0].parcel_items[0].name = 'chocolate'
input.shipment.parcels[0].parcel_items[0].description = 'candy'
input.shipment.parcels[0].parcel_items[0].quantity = 7
input.shipment.parcels[0].parcel_items[0].price = 1.03
input.shipment.parcels[0].parcel_items[0].weight_in_pounds = 0.5
input.shipment.parcels[0].parcel_items[0].harmonize_code = ''
input.shipment.parcels[0].parcel_items[0].origin_country = 'US'


input.certify_test_override = CertifyTestOverrideEnum::CONTRACT
input.image_rotation = ImageRotationEnum::ROTATENONEFLIPNONE

result = labels_controller.get_label_with_cost(input: input)
```

