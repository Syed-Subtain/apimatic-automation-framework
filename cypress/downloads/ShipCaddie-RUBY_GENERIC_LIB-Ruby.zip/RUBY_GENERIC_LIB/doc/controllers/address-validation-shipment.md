# Address Validation Shipment

```ruby
address_validation_shipment_controller = client.address_validation_shipment
```

## Class Name

`AddressValidationShipmentController`


# Validate Shipment Address

Use this function to validate an address.

```ruby
def validate_shipment_address(input: nil)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `input` | [`ValidateShipmentAddressRequest`](/doc/models/validate-shipment-address-request.md) | Body, Optional | - |

## Response Type

[`AddressValidationResponseReturnModel`](/doc/models/address-validation-response-return-model.md)

## Example Usage

```ruby
input = ValidateShipmentAddressRequest.new
input.access_token = '<YOUR ACCESS TOKEN>'
input.as_client_id = 14
input.shipment_address_to_validate = AddressValidationRequestModel.new
input.shipment_address_to_validate.carrier_id = 4
input.shipment_address_to_validate.carrier_contract_id = 2324
input.shipment_address_to_validate.addresses = []


input.shipment_address_to_validate.addresses[0] = AddressValidationModel.new
input.shipment_address_to_validate.addresses[0].address1 = '2600 Executive Parkway'
input.shipment_address_to_validate.addresses[0].address2 = 'Suite 160'
input.shipment_address_to_validate.addresses[0].province_code = 'UT'
input.shipment_address_to_validate.addresses[0].city = 'Lehi'
input.shipment_address_to_validate.addresses[0].country_code = 'US'
input.shipment_address_to_validate.addresses[0].postal_code = '84043'
input.shipment_address_to_validate.addresses[0].address_type_id = AddressTypeIdEnum::COMMERCIAL
input.shipment_address_to_validate.addresses[0].company_name = 'iDrive Logistics'
input.shipment_address_to_validate.addresses[0].country_id = 0
input.shipment_address_to_validate.addresses[0].address_status = false


result = address_validation_shipment_controller.validate_shipment_address(input: input)
```

