# Authentication

```ruby
authentication_controller = client.authentication
```

## Class Name

`AuthenticationController`

## Methods

* [Get Token](/doc/controllers/authentication.md#get-token)
* [Refresh Token](/doc/controllers/authentication.md#refresh-token)


# Get Token

Token contains an expiration date, TokenExpirationDate, that expires in 30 days. When the token expires, use 'RefreshToken' endpoint to obtain a new token.

```ruby
def get_token(input: nil)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `input` | [`Credentials`](/doc/models/credentials.md) | Body, Optional | - |

## Response Type

[`SecurityToken`](/doc/models/security-token.md)

## Example Usage

```ruby
input = Credentials.new
input.user_name = '<Your UserName>'
input.password = '<Your Password>'

result = authentication_controller.get_token(input: input)
```

## Example Response *(as JSON)*

```json
{
  "accessToken": "C_SkR2QvI25BljqKgVpt1d... (Truncated)",
  "refreshToken": "0e842ea7c4a046ceab8b5e3283321a08",
  "refreshTokenExpirationDate": "2020-12-23T23:54:10.3273331Z",
  "accessTokenExpirationDate": "2020-12-23T23:54:10.3273331Z",
  "error": {
    "details": [],
    "hasError": false
  }
}
```


# Refresh Token

This method must be called before the refresh token expiration date, TokenExpirationDate. Token expires in 30 days.

```ruby
def refresh_token(input: nil)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `input` | [`SecurityTokenRequest`](/doc/models/security-token-request.md) | Body, Optional | - |

## Response Type

[`SecurityToken`](/doc/models/security-token.md)

## Example Usage

```ruby
input = SecurityTokenRequest.new
input.refresh_token = '<YOUR REFRESH TOKEN>'

result = authentication_controller.refresh_token(input: input)
```

## Example Response *(as JSON)*

```json
{
  "accessToken": "C_SkR2QvI25BljqKgVpt1d... (Truncated)",
  "refreshToken": "0e842ea7c4a046ceab8b5e3283321a08",
  "refreshTokenExpirationDate": "2020-12-23T23:54:10.3273331Z",
  "accessTokenExpirationDate": "2020-12-23T23:54:10.3273331Z",
  "error": {
    "details": [],
    "hasError": false
  }
}
```

