# Child Accounts

```ruby
child_accounts_controller = client.child_accounts
```

## Class Name

`ChildAccountsController`


# Get Child Accounts

Obtain child accounts which are associated with this account.

```ruby
def get_child_accounts(input: nil)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `input` | [`GetChildAccountsRequestv21`](/doc/models/get-child-accounts-requestv-21.md) | Body, Optional | - |

## Response Type

[`GetChildAccountsResponsev21`](/doc/models/get-child-accounts-responsev-21.md)

## Example Usage

```ruby
input = GetChildAccountsRequestv21.new
input.access_token = '<YOUR ACCESS TOKEN>'

result = child_accounts_controller.get_child_accounts(input: input)
```

## Example Response *(as JSON)*

```json
{
  "error": {
    "details": [],
    "hasError": false
  },
  "childAccounts": [
    {
      "clientId": 343,
      "name": "Company A",
      "isEnabled": true
    },
    {
      "clientId": 233,
      "name": "Company B",
      "isEnabled": false
    }
  ]
}
```

