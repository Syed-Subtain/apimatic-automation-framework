# Manifest

```ruby
manifest_controller = client.manifest
```

## Class Name

`ManifestController`

## Methods

* [Manifest](/doc/controllers/manifest.md#manifest)
* [Generate](/doc/controllers/manifest.md#generate)
* [Regenerate](/doc/controllers/manifest.md#regenerate)
* [Scan Form History](/doc/controllers/manifest.md#scan-form-history)
* [Available Shipments](/doc/controllers/manifest.md#available-shipments)
* [Scan Form Generate](/doc/controllers/manifest.md#scan-form-generate)


# Manifest

Manifest:    Create end-of-day Manifest / Scan Form (USPS).

```ruby
def manifest(input: nil)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `input` | [`ScanFormHistoryByIDRequestv21`](/doc/models/scan-form-history-by-id-requestv-21.md) | Body, Optional | - |

## Response Type

[`ScanFormHistoryByIDResponsev21`](/doc/models/scan-form-history-by-id-responsev-21.md)

## Example Usage

```ruby
input = ScanFormHistoryByIDRequestv21.new
input.access_token = '<YOUR ACCESS TOKEN>'
input.scan_form_id = 23

result = manifest_controller.manifest(input: input)
```

## Example Response *(as JSON)*

```json
{
  "error": {
    "details": [],
    "hasError": false
  },
  "scanFormInformation": {
    "id": 12,
    "scanFormId": "ScanFormID",
    "batchId": "BatchID",
    "clientId": 12,
    "shipmentClientAddressId": 747,
    "shipDate": "2020-12-23T23:54:10.3273331+00:00",
    "scanFormDataType": "imagePng",
    "carrierClientContractId": 2526,
    "carrierClientContractName": "Test",
    "shipmentClientAddressLine1": "",
    "shipmentClientAddressLine2": "",
    "shipmentClientAddressProvince": "",
    "shipmentClientAddressCity": "",
    "shipmentClientAddressPostalCode": "",
    "shippingSiteName": "",
    "dateCreated": "2020-12-23T23:54:10.3273331+00:00",
    "printJobs": [
      {
        "printTemplateType": "Template Type",
        "dataBlocks": []
      }
    ],
    "excludedItems": {}
  }
}
```


# Generate

Generate:    Obtain a ScanForm

```ruby
def generate(input: nil)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `input` | [`GenerateRequestv21`](/doc/models/generate-requestv-21.md) | Body, Optional | - |

## Response Type

[`GenerateResponsev21`](/doc/models/generate-responsev-21.md)

## Example Usage

```ruby
input = GenerateRequestv21.new
input.access_token = '<YOUR ACCESS TOKEN>'
input.scan_form_request = ScanFormModelRequest.new
input.scan_form_request.carrier_client_contract_id = 2526
input.scan_form_request.shipment_client_address_id = 747
input.scan_form_request.ship_date = DateTimeHelper.from_rfc3339('2017-11-29T00:00:00')
input.scan_form_request.key_list = []


input.scan_form_request.key_list[0] = KeyValues.new
input.scan_form_request.key_list[0].label_key = 'shp_810c212e2dcf4863a1bd8495f9a54d81'
input.scan_form_request.key_list[0].tracking_number = '9400136895239112753275'
input.scan_form_request.key_list[0].package_id = 366974

input.scan_form_request.recent_scan_form_id = 0

result = manifest_controller.generate(input: input)
```

## Example Response *(as JSON)*

```json
{
  "error": {
    "details": [],
    "hasError": false
  },
  "scanFormInformation": {
    "id": 12,
    "scanFormId": "ScanFormID",
    "batchId": "BatchID",
    "clientId": 12,
    "shipmentClientAddressId": 747,
    "shipDate": "2020-12-23T23:54:10.1867682+00:00",
    "scanFormDataType": "imagePng",
    "carrierClientContractId": 2526,
    "carrierClientContractName": "Test",
    "shipmentClientAddressLine1": "",
    "shipmentClientAddressLine2": "",
    "shipmentClientAddressProvince": "",
    "shipmentClientAddressCity": "",
    "shipmentClientAddressPostalCode": "",
    "shippingSiteName": "",
    "dateCreated": "2020-12-23T23:54:10.1867682+00:00",
    "printJobs": [
      {
        "printTemplateType": "Template Type",
        "dataBlocks": []
      }
    ],
    "excludedItems": {}
  }
}
```


# Regenerate

Regenerate:    Obtain a ScanForm

```ruby
def regenerate(input: nil)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `input` | [`RegenerateRequestv21`](/doc/models/regenerate-requestv-21.md) | Body, Optional | - |

## Response Type

[`RegenerateResponsev21`](/doc/models/regenerate-responsev-21.md)

## Example Usage

```ruby
input = RegenerateRequestv21.new
input.access_token = '<YOUR ACCESS TOKEN>'
input.is_regenerate = false
input.scan_form_request = ScanFormModelRequest.new
input.scan_form_request.carrier_client_contract_id = 2526
input.scan_form_request.shipment_client_address_id = 747
input.scan_form_request.ship_date = DateTimeHelper.from_rfc3339('2017-11-29T00:00:00')
input.scan_form_request.key_list = []


input.scan_form_request.key_list[0] = KeyValues.new
input.scan_form_request.key_list[0].label_key = 'shp_810c212e2dcf4863a1bd8495f9a54d81'
input.scan_form_request.key_list[0].tracking_number = '9400136895239112753275'
input.scan_form_request.key_list[0].package_id = 366974

input.scan_form_request.recent_scan_form_id = 0

result = manifest_controller.regenerate(input: input)
```

## Example Response *(as JSON)*

```json
{
  "error": {
    "details": [],
    "hasError": false
  },
  "scanFormInformation": {
    "id": 12,
    "scanFormId": "ScanFormID",
    "batchId": "BatchID",
    "clientId": 12,
    "shipmentClientAddressId": 747,
    "shipDate": "2020-12-23T23:54:10.3273331+00:00",
    "scanFormDataType": "imagePng",
    "carrierClientContractId": 2526,
    "carrierClientContractName": "Test",
    "shipmentClientAddressLine1": "",
    "shipmentClientAddressLine2": "",
    "shipmentClientAddressProvince": "",
    "shipmentClientAddressCity": "",
    "shipmentClientAddressPostalCode": "",
    "shippingSiteName": "",
    "dateCreated": "2020-12-23T23:54:10.3273331+00:00",
    "printJobs": [
      {
        "printTemplateType": "Template Type",
        "dataBlocks": []
      }
    ],
    "excludedItems": {}
  }
}
```


# Scan Form History

ScanForm_History:         Get the end-of-day Manifests / Scan Forms (USPS)

```ruby
def scan_form_history(input: nil)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `input` | [`ScanFormHistoryRequestv21`](/doc/models/scan-form-history-requestv-21.md) | Body, Optional | - |

## Response Type

[`ScanFormHistoryResponsev21`](/doc/models/scan-form-history-responsev-21.md)

## Example Usage

```ruby
input = ScanFormHistoryRequestv21.new
input.access_token = '<YOUR ACCESS TOKEN>'

result = manifest_controller.scan_form_history(input: input)
```

## Example Response *(as JSON)*

```json
{
  "error": {
    "details": [],
    "hasError": false
  },
  "scanFormList": [
    {
      "id": 12,
      "scanFormId": "ScanFormID",
      "batchId": "BatchID",
      "clientId": 12,
      "shipmentClientAddressId": 747,
      "shipDate": "2020-12-23T23:54:10.3585858+00:00",
      "scanFormDataType": "imagePng",
      "carrierClientContractId": 2526,
      "carrierClientContractName": "Test",
      "shipmentClientAddressLine1": "",
      "shipmentClientAddressLine2": "",
      "shipmentClientAddressProvince": "",
      "shipmentClientAddressCity": "",
      "shipmentClientAddressPostalCode": "",
      "shippingSiteName": "",
      "dateCreated": "2020-12-23T23:54:10.3585858+00:00",
      "printJobs": [
        {
          "printTemplateType": "Template Type",
          "dataBlocks": []
        }
      ],
      "excludedItems": {}
    }
  ]
}
```


# Available Shipments

AvailableShipments:    Gets Available Shipments

```ruby
def available_shipments(input: nil)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `input` | [`AvailableShipmentsRequestv21`](/doc/models/available-shipments-requestv-21.md) | Body, Optional | - |

## Response Type

[`AvailableShipmentsResponsev21`](/doc/models/available-shipments-responsev-21.md)

## Example Usage

```ruby
input = AvailableShipmentsRequestv21.new
input.access_token = '<YOUR ACCESS TOKEN>'
input.as_client_id = 12
input.carrier_client_contract_id = 34
input.address_id = 23
input.ship_date = DateTimeHelper.from_rfc3339('2020-12-23T23:54:10.1554517+00:00')

result = manifest_controller.available_shipments(input: input)
```

## Example Response *(as JSON)*

```json
{
  "error": {
    "details": [],
    "hasError": false
  },
  "availableShipments": [
    {
      "carrierClientContractId": 14,
      "shipmentId": 23,
      "packageId": 45,
      "shipmentClientAddressId": 52,
      "dateShipped": "2020-12-23T23:54:10.1554517+00:00",
      "fromShippingSiteName": "Shipping Site Name",
      "toAddressLine1": "564 Drury Lane",
      "toAddressLine2": "",
      "toPostalCode": "95654",
      "toProvince": "CA",
      "toCity": "LA",
      "accountAlias": "",
      "labelKey": "fds32y4rddaf",
      "trackingNumber": "565489079094"
    }
  ]
}
```


# Scan Form Generate

ScanForm_Generate:         Get Manifests / Scan Forms (USPS)

```ruby
def scan_form_generate(input: nil)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `input` | [`ScanFormGenerateRequestv21`](/doc/models/scan-form-generate-requestv-21.md) | Body, Optional | - |

## Response Type

[`ScanFormGenerateResponsev21`](/doc/models/scan-form-generate-responsev-21.md)

## Example Usage

```ruby
input = ScanFormGenerateRequestv21.new
input.access_token = '<YOUR ACCESS TOKEN>'
input.scan_form_request = ScanFormModelRequest.new
input.scan_form_request.carrier_client_contract_id = 2526
input.scan_form_request.shipment_client_address_id = 747
input.scan_form_request.ship_date = DateTimeHelper.from_rfc3339('2017-11-29T00:00:00')
input.scan_form_request.key_list = []


input.scan_form_request.key_list[0] = KeyValues.new
input.scan_form_request.key_list[0].label_key = 'shp_810c212e2dcf4863a1bd8495f9a54d81'
input.scan_form_request.key_list[0].tracking_number = '9400136895239112753275'
input.scan_form_request.key_list[0].package_id = 366974

input.scan_form_request.recent_scan_form_id = 0

result = manifest_controller.scan_form_generate(input: input)
```

## Example Response *(as JSON)*

```json
{
  "error": {
    "details": [],
    "hasError": false
  },
  "scanFormInformation": {
    "id": 12,
    "scanFormId": "ScanFormID",
    "batchId": "BatchID",
    "clientId": 12,
    "shipmentClientAddressId": 747,
    "shipDate": "2020-12-23T23:54:10.3585858+00:00",
    "scanFormDataType": "imagePng",
    "carrierClientContractId": 2526,
    "carrierClientContractName": "Test",
    "shipmentClientAddressLine1": "",
    "shipmentClientAddressLine2": "",
    "shipmentClientAddressProvince": "",
    "shipmentClientAddressCity": "",
    "shipmentClientAddressPostalCode": "",
    "shippingSiteName": "",
    "dateCreated": "2020-12-23T23:54:10.3585858+00:00",
    "printJobs": [
      {
        "printTemplateType": "Template Type",
        "dataBlocks": []
      }
    ],
    "excludedItems": {}
  }
}
```

