# Email Notifications

```ruby
email_notifications_controller = client.email_notifications
```

## Class Name

`EmailNotificationsController`


# Update Email Notification

Email notifications can be turned on or off for each carrier.

```ruby
def update_email_notification(input: nil)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `input` | [`UpdateEmailNotificationRequestv21`](/doc/models/update-email-notification-requestv-21.md) | Body, Optional | - |

## Response Type

[`UpdateEmailNotificationResponsev21`](/doc/models/update-email-notification-responsev-21.md)

## Example Usage

```ruby
input = UpdateEmailNotificationRequestv21.new
input.access_token = '<YOUR ACCESS TOKEN>'
input.as_client_id = 12
input.carrier_client_contract_id = 19
input.notify_by_email = true

result = email_notifications_controller.update_email_notification(input: input)
```

## Example Response *(as JSON)*

```json
{
  "successfullyUpdatedEmailNotification": true,
  "error": {
    "details": [],
    "hasError": false
  }
}
```

