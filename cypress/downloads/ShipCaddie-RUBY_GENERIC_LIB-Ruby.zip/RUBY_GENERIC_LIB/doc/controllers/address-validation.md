# Address Validation

```ruby
address_validation_controller = client.address_validation
```

## Class Name

`AddressValidationController`


# Validate Address

Use this function to validate an address.

```ruby
def validate_address(input: nil)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `input` | [`ValidateAddressRequestv21`](/doc/models/validate-address-requestv-21.md) | Body, Optional | - |

## Response Type

[`ValidateAddressResponsev21`](/doc/models/validate-address-responsev-21.md)

## Example Usage

```ruby
input = ValidateAddressRequestv21.new
input.access_token = '<YOUR ACCESS TOKEN>'
input.as_client_id = 14
input.address_to_validate = Addressv21.new
input.address_to_validate.address1 = '2600 Executive Parkway'
input.address_to_validate.address2 = 'Suite 160'
input.address_to_validate.city = 'Lehi'
input.address_to_validate.country_code = 'US'
input.address_to_validate.state_or_providence = 'UT'
input.address_to_validate.postal_code = '84043'
input.address_to_validate.is_residential = false
input.address_to_validate.attention_of = 'Mr. Jones'
input.address_to_validate.company_name = 'iDrive Logistics'
input.address_to_validate.email = 'sales@idrivelogistics.com'
input.address_to_validate.phone_number = '(888) 797-0929'

result = address_validation_controller.validate_address(input: input)
```

## Example Response *(as JSON)*

```json
{
  "addressIsValidated": true,
  "validationMessages": [
    {
      "code": "Default Match",
      "message": "Street address (directional or suffix only) was corrected to validate the address. Please check this correction prior to using address."
    }
  ],
  "validatedAddress": {
    "address1": "2600 W Executive Pkwy Ste 160",
    "address2": "",
    "city": "LEHI",
    "countryCode": "US",
    "stateOrProvidence": "UT",
    "postalCode": "84043-3987",
    "isResidential": false,
    "attentionOf": "Mr. Jones",
    "companyName": "iDrive Logistics",
    "email": "sales@idrivelogistics.com",
    "phoneNumber": "8887970929"
  },
  "error": {
    "details": [],
    "hasError": false
  }
}
```

