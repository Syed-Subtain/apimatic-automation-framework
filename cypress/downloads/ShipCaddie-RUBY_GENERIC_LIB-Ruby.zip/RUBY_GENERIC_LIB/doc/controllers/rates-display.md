# Rates Display

```ruby
rates_display_controller = client.rates_display
```

## Class Name

`RatesDisplayController`


# Get Rates With Display

Before creating a shipping label,
you can use this method to get a
break down of all shipping charges.
This allows you to determine
how much it would cost if you were to
actually send the parcels.

NOTE: HTTPS is Required to recieve a response.

```ruby
def get_rates_with_display(rate_request: nil)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `rate_request` | [`RateRequest`](/doc/models/rate-request.md) | Body, Optional | Shipping and parcel information<br>neccessary to calculate rates. |

## Response Type

[`RateResponse`](/doc/models/rate-response.md)

## Example Usage

```ruby
rate_request = RateRequest.new
rate_request.access_token = 'YOUR ACCESS TOKEN'
rate_request.shipping_info = ShippingInformation.new
rate_request.shipping_info.carrier_client_contract_id = 2526
rate_request.shipping_info.service_level_id = 0
rate_request.shipping_info.date_shipped = DateTimeHelper.from_rfc3339('2020-12-23T23:54:10.2649036Z')
rate_request.shipping_info.options = CustomsOptions.new
rate_request.shipping_info.options.is_apo_fpo_dpo_us_territory = false
rate_request.shipping_info.options.is_international_shipment = false
rate_request.shipping_info.options.shipment_content_type = ShipmentContentTypeEnum::CONTENT_TYPE_SAMPLE
rate_request.shipping_info.address_from = ShipFromAddress.new
rate_request.shipping_info.address_from.company_name = 'iDrive Logistics'
rate_request.shipping_info.address_from.email = 'sales@idrivelogistics.com'
rate_request.shipping_info.address_from.phone_number = '(888) 797-0929'
rate_request.shipping_info.address_from.address1 = '2600 Executive Pkwy #160'
rate_request.shipping_info.address_from.address2 = ''
rate_request.shipping_info.address_from.city = 'Lehi'
rate_request.shipping_info.address_from.state_or_province = 'UT'
rate_request.shipping_info.address_from.postal_code = '84043'
rate_request.shipping_info.address_from.country_code = 'US'
rate_request.shipping_info.address_to = ShipToAddress.new
rate_request.shipping_info.address_to.attention_of = 'Mr. Jones'
rate_request.shipping_info.address_to.company_name = 'iDrive Logistics'
rate_request.shipping_info.address_to.email = ''
rate_request.shipping_info.address_to.phone_number = ''
rate_request.shipping_info.address_to.address1 = '2605 Executive Pkwy #160'
rate_request.shipping_info.address_to.address2 = ''
rate_request.shipping_info.address_to.is_residential = false
rate_request.shipping_info.address_to.city = 'Lehi'
rate_request.shipping_info.address_to.state_or_province = 'UT'
rate_request.shipping_info.address_to.postal_code = '84043'
rate_request.shipping_info.address_to.country_code = 'US'
rate_request.shipping_info.parcels = []


rate_request.shipping_info.parcels[0] = ParcelInformation.new
rate_request.shipping_info.parcels[0].packaging_id = ''
rate_request.shipping_info.parcels[0].weight_in_pounds = 0.4
rate_request.shipping_info.parcels[0].length_in_inches = 5
rate_request.shipping_info.parcels[0].width_in_inches = 4
rate_request.shipping_info.parcels[0].height_in_inches = 12
rate_request.shipping_info.parcels[0].options = ParcelOptions.new
rate_request.shipping_info.parcels[0].options.mreturn = ReturnEnum::NOT_APPLICABLE
rate_request.shipping_info.parcels[0].options.insurance_amount = 0
rate_request.shipping_info.parcels[0].options.signature = SignatureEnum::NOT_APPLICABLE
rate_request.shipping_info.parcels[0].options.cod = CODOptions.new
rate_request.shipping_info.parcels[0].options.cod.cod_type = CodTypeEnum::NOT_APPLICABLE
rate_request.shipping_info.parcels[0].options.cod.cod_amount = 0
rate_request.shipping_info.parcels[0].options.machinable = true
rate_request.shipping_info.parcels[0].options.hold_for_pickup = false


result = rates_display_controller.get_rates_with_display(rate_request: rate_request)
```

