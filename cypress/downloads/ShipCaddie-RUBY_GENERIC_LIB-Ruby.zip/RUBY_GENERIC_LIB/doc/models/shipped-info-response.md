
# Shipped Info Response

## Structure

`ShippedInfoResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `shipment_id` | `Integer` | Optional | Id used to identify shipment. |
| `date_shipped` | `DateTime` | Optional | Specifies the date of shipment. |
| `from_address` | [`ShipFromAddress`](/doc/models/ship-from-address.md) | Optional | - |
| `to_address` | [`ShipToAddress`](/doc/models/ship-to-address.md) | Optional | - |
| `shipment_options` | [`ShippingOptions`](/doc/models/shipping-options.md) | Optional | Billing and Custom Declaration Options for Shipping. |
| `carrier` | [`ShippedInfoCarrier`](/doc/models/shipped-info-carrier.md) | Optional | - |
| `parcel_info` | [`Array<ShippedInfoParcel>`](/doc/models/shipped-info-parcel.md) | Optional | The information about the packages in the shipment. |
| `error` | [`RequestError`](/doc/models/request-error.md) | Required | This information can be used to determine if an error has occurred when a request was processed. |

## Example (as JSON)

```json
{
  "shipmentId": null,
  "dateShipped": null,
  "fromAddress": null,
  "toAddress": null,
  "shipmentOptions": null,
  "carrier": null,
  "parcelInfo": null,
  "error": {
    "details": null,
    "hasError": false
  }
}
```

