
# Data Block

## Structure

`DataBlock`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `data_source_name` | `String` | Optional | - |
| `type` | `String` | Optional | - |
| `data` | `String` | Optional | - |
| `data_uri` | `String` | Optional | - |

## Example (as JSON)

```json
{
  "dataSourceName": null,
  "type": null,
  "data": null,
  "dataURI": null
}
```

