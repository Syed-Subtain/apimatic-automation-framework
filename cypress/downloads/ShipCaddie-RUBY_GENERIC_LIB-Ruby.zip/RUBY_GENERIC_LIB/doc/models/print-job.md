
# Print Job

## Structure

`PrintJob`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `print_template_type` | `String` | Optional | - |
| `data_blocks` | [`Array<DataBlock>`](/doc/models/data-block.md) | Optional | - |

## Example (as JSON)

```json
{
  "printTemplateType": null,
  "dataBlocks": null
}
```

