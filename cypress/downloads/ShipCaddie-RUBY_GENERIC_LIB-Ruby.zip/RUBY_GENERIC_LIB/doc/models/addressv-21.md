
# Addressv 21

## Structure

`Addressv21`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `address_1` | `String` | Required | Required |
| `address_2` | `String` | Optional | Optional |
| `city` | `String` | Required | Required |
| `country_code` | `String` | Required | Required |
| `state_or_providence` | `String` | Required | Required - StateOrProvidence |
| `postal_code` | `String` | Required | Required - PostalCode |
| `is_residential` | `Boolean` | Optional | Optional - Is Residencial flag |
| `attention_of` | `String` | Optional | Optional - Attention of,<br>some Carriers will require this parameter to be set |
| `company_name` | `String` | Optional | Optional - Company Name,<br>some Carriers will require this parameter to be set |
| `email` | `String` | Optional | Optional - Email, some Carriers will require this parameter to be set |
| `phone_number` | `String` | Optional | Optional - Phone Number,<br>some Carriers will require this parameter to be set |

## Example (as JSON)

```json
{
  "address1": "address12",
  "address2": null,
  "city": "city0",
  "countryCode": "countryCode4",
  "stateOrProvidence": "stateOrProvidence4",
  "postalCode": "postalCode8",
  "isResidential": null,
  "attentionOf": null,
  "companyName": null,
  "email": null,
  "phoneNumber": null
}
```

