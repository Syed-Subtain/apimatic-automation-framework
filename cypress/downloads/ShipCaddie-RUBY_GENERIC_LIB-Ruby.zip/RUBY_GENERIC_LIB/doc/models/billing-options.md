
# Billing Options

Specifies how the shipping costs will be paid.

## Structure

`BillingOptions`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `shipping_paid_by` | [`ShippingPaidByEnum`](/doc/models/shipping-paid-by-enum.md) | Required | Indicates who will pay for the shipping Costs. |
| `account_number` | `String` | Optional | Optional Account Number.<br>This is the account number of the person or group which will pay the shipping charges. |
| `postal_code` | `String` | Optional | Optional Postal Code<br>This is the postal code of the person or group which will pay the shipping charges. |
| `country_alpha_2_code` | `String` | Optional | Optional Country<br>This is the country of the person or group which will pay the shipping charges. |
| `duties_paid_by` | [`DutiesPaidByEnum`](/doc/models/duties-paid-by-enum.md) | Required | Indicates who will pay for any applicable duties. |

## Example (as JSON)

```json
{
  "shippingPaidBy": "PAID_BY_RECIPIENT",
  "accountNumber": null,
  "postalCode": null,
  "country_Alpha2Code": null,
  "dutiesPaidBy": "PAID_BY_RECIPIENT"
}
```

