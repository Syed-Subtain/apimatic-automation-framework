
# User Register Modelv 21

## Structure

`UserRegisterModelv21`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `system_country_id` | `Integer` | Optional | Country of Origin |
| `name_first` | `String` | Optional | Required.<br>First Name<br>Max Length: 25 |
| `name_last` | `String` | Optional | Required.<br>Last Name<br>Max Length: 35 |
| `company_name` | `String` | Optional | Company Name<br>Max Length: 50 |
| `phone_number` | `String` | Optional | Phone Number |
| `user_name` | `String` | Optional | Required.<br>User name |
| `password` | `String` | Optional | Required.<br>Max Length: 100<br>Min Length: 8<br>Password |
| `password_verify` | `String` | Optional | Confirm password |
| `promo_code` | `String` | Optional | Promo Code |
| `subscription_tier_id` | `Integer` | Optional | Subscription Tier |
| `i_agree` | `String` | Optional | - |

## Example (as JSON)

```json
{
  "systemCountryId": null,
  "nameFirst": null,
  "nameLast": null,
  "companyName": null,
  "phoneNumber": null,
  "userName": null,
  "password": null,
  "passwordVerify": null,
  "promoCode": null,
  "subscriptionTierId": null,
  "iAgree": null
}
```

