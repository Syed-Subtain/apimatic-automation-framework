
# Address Validation Request Model

Address Validation request model

## Structure

`AddressValidationRequestModel`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `carrier_id` | `Integer` | Optional | The Id of the carrier |
| `carrier_contract_id` | `Integer` | Optional | Identifies the Carrier Client Contract on Shipcaddie |
| `addresses` | [`Array<AddressValidationModel>`](/doc/models/address-validation-model.md) | Optional | List of address validation models |

## Example (as JSON)

```json
{
  "carrierId": null,
  "carrierContractId": null,
  "addresses": null
}
```

