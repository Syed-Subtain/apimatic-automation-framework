
# Scan Form Model

## Structure

`ScanFormModel`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `Integer` | Optional | - |
| `scan_form_id` | `String` | Optional | - |
| `batch_id` | `String` | Optional | - |
| `client_id` | `Integer` | Optional | - |
| `shipment_client_address_id` | `Integer` | Optional | - |
| `ship_date` | `DateTime` | Optional | - |
| `scan_form_data_type` | [`ScanFormDataTypeEnum`](/doc/models/scan-form-data-type-enum.md) | Optional | - |
| `carrier_client_contract_id` | `Integer` | Optional | - |
| `carrier_client_contract_name` | `String` | Optional | - |
| `shipment_client_address_line_1` | `String` | Optional | - |
| `shipment_client_address_line_2` | `String` | Optional | - |
| `shipment_client_address_province` | `String` | Optional | - |
| `shipment_client_address_city` | `String` | Optional | - |
| `shipment_client_address_postal_code` | `String` | Optional | - |
| `shipping_site_name` | `String` | Optional | - |
| `date_created` | `DateTime` | Optional | - |
| `print_jobs` | [`Array<PrintJob>`](/doc/models/print-job.md) | Optional | - |
| `excluded_items` | `Hash` | Optional | This is the list of items that are ignored or already manifested by easypost. |

## Example (as JSON)

```json
{
  "id": null,
  "scanFormId": null,
  "batchId": null,
  "clientId": null,
  "shipmentClientAddressId": null,
  "shipDate": null,
  "scanFormDataType": null,
  "carrierClientContractId": null,
  "carrierClientContractName": null,
  "shipmentClientAddressLine1": null,
  "shipmentClientAddressLine2": null,
  "shipmentClientAddressProvince": null,
  "shipmentClientAddressCity": null,
  "shipmentClientAddressPostalCode": null,
  "shippingSiteName": null,
  "dateCreated": null,
  "printJobs": null,
  "excludedItems": null
}
```

