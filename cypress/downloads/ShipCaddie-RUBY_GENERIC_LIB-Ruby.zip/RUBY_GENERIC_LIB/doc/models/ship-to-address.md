
# Ship to Address

## Structure

`ShipToAddress`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `attention_of` | `String` | Optional | Attention of the person accepting the parcels.<br>This field is required by some Carriers. |
| `company_name` | `String` | Optional | Optional Company Name.<br>This field is required by some Carriers. |
| `email` | `String` | Optional | This field is required by some Carriers. |
| `phone_number` | `String` | Optional | This field is required by some Carriers. |
| `address_1` | `String` | Optional | Street Address |
| `address_2` | `String` | Optional | Optional additional Street Address. |
| `is_residential` | `Boolean` | Optional | Specifies if the address is a residential address. |
| `city` | `String` | Optional | City to which the parcels will be sent. |
| `state_or_province` | `String` | Optional | Use Province or other appropriate value<br>for international addresses. |
| `postal_code` | `String` | Optional | Zip Code if address in in the United States.<br>Postal Code if the address is international. |
| `country_code` | `String` | Optional | Code which indicates to which<br>country the parcels will be sent.<br>Obtained from GetContryCodes. |

## Example (as JSON)

```json
{
  "attentionOf": null,
  "companyName": null,
  "email": null,
  "phoneNumber": null,
  "address1": null,
  "address2": null,
  "isResidential": null,
  "city": null,
  "stateOrProvince": null,
  "postalCode": null,
  "countryCode": null
}
```

