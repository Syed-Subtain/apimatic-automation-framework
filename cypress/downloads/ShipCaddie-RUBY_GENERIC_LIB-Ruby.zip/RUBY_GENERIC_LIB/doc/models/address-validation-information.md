
# Address Validation Information

Informative Messages regarding Address Validation.

## Structure

`AddressValidationInformation`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `code` | `String` | Required | Message Code. |
| `message` | `String` | Required | Descriptive Message. |

## Example (as JSON)

```json
{
  "code": "code8",
  "message": "message0"
}
```

