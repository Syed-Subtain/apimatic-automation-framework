
# Parcel Detail

Details of parcels to send.

## Structure

`ParcelDetail`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `reference_field_1` | `String` | Optional | Optional - Reference Field 1 |
| `reference_field_2` | `String` | Optional | Optional - Reference Field 2 |
| `reference_field_3` | `String` | Optional | Optional - Reference Field 3 |
| `parcel_id` | `String` | Optional | A unique ID used to match<br>parcels with cost details.<br>This will be set automatically<br>if a value is not supplied. |
| `packaging_id` | `String` | Optional | - |
| `weight_in_pounds` | `Float` | Required | Parcel Weight in Pounds.<br>If the weight is a fraction of a pound<br>still use pounds - not ounces. |
| `length_in_inches` | `Float` | Required | Length of one side of parcel in inches. |
| `width_in_inches` | `Float` | Required | Width of one side of parcel in inches. |
| `height_in_inches` | `Float` | Required | Height of one side of parcel in inches. |
| `options` | [`ParcelOptions`](/doc/models/parcel-options.md) | Required | Specifies additional parcel options such as COD and required Signatures. |
| `parcel_items` | [`Array<ParcelContent>`](/doc/models/parcel-content.md) | Optional | Type of parcel contents.<br>This is required for some destinations. |

## Example (as JSON)

```json
{
  "referenceField1": null,
  "referenceField2": null,
  "referenceField3": null,
  "parcelID": null,
  "packagingId": null,
  "weightInPounds": 168.18,
  "lengthInInches": 230.9,
  "widthInInches": 117.18,
  "heightInInches": 176.28,
  "options": {
    "return": null,
    "insuranceAmount": null,
    "signature": null,
    "cod": null,
    "machinable": null,
    "holdForPickup": null
  },
  "parcelItems": null
}
```

