
# Country Code Data

Country information necessary to construct addresses.

## Structure

`CountryCodeData`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `country_id` | `Integer` | Required | Unique ID used to identify a country. |
| `country_name` | `String` | Required | Friendly Country name. |
| `alpha_2_country_code` | `String` | Required | Standardized Country Codes. |

## Example (as JSON)

```json
{
  "countryId": 8,
  "countryName": "countryName6",
  "alpha2CountryCode": "alpha2CountryCode6"
}
```

