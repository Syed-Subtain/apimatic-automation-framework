
# Parcel Content

Itemized packaging content used by customs.

## Structure

`ParcelContent`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `sku` | `String` | Optional | Product identifier. |
| `name` | `String` | Required | Descriptive item name. |
| `description` | `String` | Optional | Optional item description. |
| `quantity` | `Integer` | Required | Number of items. |
| `price` | `Float` | Required | Price of item. |
| `weight_in_pounds` | `Float` | Required | Weight of the item. |
| `harmonize_code` | `String` | Optional | Optional Harmonize code |
| `origin_country` | `String` | Required | Country where product was made. |

## Example (as JSON)

```json
{
  "sku": null,
  "name": "name0",
  "description": null,
  "quantity": 68,
  "price": 207.52,
  "weightInPounds": 168.18,
  "harmonizeCode": null,
  "originCountry": "originCountry4"
}
```

