
# Shipment Inventory by Sku Response

## Structure

`ShipmentInventoryBySkuResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `sku` | `String` | Optional | - |
| `name` | `String` | Optional | - |
| `qty` | `Integer` | Optional | - |
| `date_shipped` | `DateTime` | Optional | - |
| `order_reference_number` | `String` | Optional | - |
| `shipment_number` | `String` | Optional | - |

## Example (as JSON)

```json
{
  "sku": null,
  "name": null,
  "qty": null,
  "dateShipped": null,
  "orderReferenceNumber": null,
  "shipmentNumber": null
}
```

