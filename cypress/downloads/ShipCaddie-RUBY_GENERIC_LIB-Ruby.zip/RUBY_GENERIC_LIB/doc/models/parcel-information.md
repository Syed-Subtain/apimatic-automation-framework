
# Parcel Information

Details of parcels to send.

## Structure

`ParcelInformation`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `packaging_id` | `String` | Optional | - |
| `weight_in_pounds` | `Float` | Optional | Parcel Weight in Pounds.<br>If the weight is a fraction of a pound<br>still use pounds - not ounces. |
| `length_in_inches` | `Float` | Optional | Length of one side of parcel in inches. |
| `width_in_inches` | `Float` | Optional | Width of one side of parcel in inches. |
| `height_in_inches` | `Float` | Optional | Height of one side of parcel in inches. |
| `options` | [`ParcelOptions`](/doc/models/parcel-options.md) | Optional | Specifies additional parcel options such as COD and required Signatures. |

## Example (as JSON)

```json
{
  "packagingId": null,
  "weightInPounds": null,
  "lengthInInches": null,
  "widthInInches": null,
  "heightInInches": null,
  "options": null
}
```

