
# Shipping Cost Informationv 21

Cost details related to shipping.

## Structure

`ShippingCostInformationv21`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `shipment_id` | `Integer` | Optional | Internal shipment identifier.<br>Read Only. |
| `order_reference_number` | `String` | Optional | Optional order reference tag that was set when adding a shipment or getting rates. |
| `parcel_charge_details` | [`Array<ParcelChargeDetails>`](/doc/models/parcel-charge-details.md) | Optional | Shipping charges relating to individual parcels. |
| `shipping_charge_details` | [`Array<CostDetailv21>`](/doc/models/cost-detailv-21.md) | Optional | Shipping charges relating to a shipment as a whole. |
| `transit_days_min` | `Integer` | Optional | The Days in transit as defined by the carrier for the service level chosen.<br>The number may or may not include non-business days. |
| `transit_days_max` | `Integer` | Optional | The Days in transit as defined by the carrier for the service level chosen.<br>The number may or may not include non-business days. |
| `total_charge_amount` | `Float` | Optional | - |
| `total_charge_amount_3_pl` | `Float` | Optional | This is the sum of all accessorialCharges.chargeAmount3pl fields in all packages |
| `delivery_date_time` | `DateTime` | Optional | - |
| `is_delivery_guaranteed` | `Boolean` | Optional | - |

## Example (as JSON)

```json
{
  "shipmentId": null,
  "orderReferenceNumber": null,
  "parcelChargeDetails": null,
  "shippingChargeDetails": null,
  "transitDaysMin": null,
  "transitDaysMax": null,
  "totalChargeAmount": null,
  "totalChargeAmount3pl": null,
  "deliveryDateTime": null,
  "isDeliveryGuaranteed": null
}
```

