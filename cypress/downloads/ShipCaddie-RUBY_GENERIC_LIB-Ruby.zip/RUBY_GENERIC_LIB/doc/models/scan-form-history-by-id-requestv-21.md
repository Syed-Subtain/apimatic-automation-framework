
# Scan Form History by ID Requestv 21

## Structure

`ScanFormHistoryByIDRequestv21`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `access_token` | `String` | Required | Required.<br>An authorization token is necessary to call this method.<br><remarks><br>The token can be obtained by calling the GetToken or RefreshToken methods.<br></remarks> |
| `scan_form_id` | `Integer` | Required | ID of Scan form to retrieve. |
| `as_client_id` | `Integer` | Optional | Optional.<br>When empty or null, this field is ignored.<br>When set, actions will be taken for the client specified by the id. |

## Example (as JSON)

```json
{
  "accessToken": "<YOUR ACCESS TOKEN>",
  "scanFormId": 23
}
```

