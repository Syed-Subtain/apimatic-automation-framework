
# Shipping Paid by Enum

Indicates who will pay for the shipping Costs.

## Enumeration

`ShippingPaidByEnum`

## Fields

| Name |
|  --- |
| `NOT_APPLICABLE` |
| `PAID_BY_SHIPPER` |
| `PAID_BY_RECIPIENT` |
| `PAID_BY_THIRD_PARTY` |

