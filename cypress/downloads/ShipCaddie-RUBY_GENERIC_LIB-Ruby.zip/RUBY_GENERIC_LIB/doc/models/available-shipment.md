
# Available Shipment

## Structure

`AvailableShipment`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `carrier_client_contract_id` | `Integer` | Optional | - |
| `shipment_id` | `Integer` | Optional | - |
| `package_id` | `Integer` | Optional | - |
| `shipment_client_address_id` | `Integer` | Optional | - |
| `date_shipped` | `DateTime` | Optional | - |
| `from_shipping_site_name` | `String` | Optional | - |
| `to_address_line_1` | `String` | Optional | - |
| `to_address_line_2` | `String` | Optional | - |
| `to_postal_code` | `String` | Optional | - |
| `to_province` | `String` | Optional | - |
| `to_city` | `String` | Optional | - |
| `account_alias` | `String` | Optional | - |
| `label_key` | `String` | Optional | - |
| `tracking_number` | `String` | Optional | - |

## Example (as JSON)

```json
{
  "carrierClientContractId": null,
  "shipmentId": null,
  "packageId": null,
  "shipmentClientAddressId": null,
  "dateShipped": null,
  "fromShippingSiteName": null,
  "toAddressLine1": null,
  "toAddressLine2": null,
  "toPostalCode": null,
  "toProvince": null,
  "toCity": null,
  "accountAlias": null,
  "labelKey": null,
  "trackingNumber": null
}
```

