
# Parcel Charge Details

Break down of charges per parcel.

## Structure

`ParcelChargeDetails`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `parcel_id` | `String` | Optional | A unique ID used to match<br>parcels with cost details. |
| `cost_details` | [`Array<CostDetailv21>`](/doc/models/cost-detailv-21.md) | Optional | Detailed shipping charges. |

## Example (as JSON)

```json
{
  "parcelID": null,
  "costDetails": null
}
```

