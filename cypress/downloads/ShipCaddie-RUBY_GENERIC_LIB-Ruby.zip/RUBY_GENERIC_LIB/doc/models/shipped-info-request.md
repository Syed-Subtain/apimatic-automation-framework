
# Shipped Info Request

## Structure

`ShippedInfoRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `include_from_address` | `Boolean` | Optional | Include the from address information in result. Default false |
| `include_to_address` | `Boolean` | Optional | Include the to address information in the result. Default false |
| `include_carrier_info` | `Boolean` | Optional | Include the carrier information in the result. Default false |
| `include_shipment_options` | `Boolean` | Optional | Include the shipment options information in the result. Default false |
| `include_parcel_info` | `Boolean` | Optional | Include the parcel information in the result. Default false |
| `include_parcel_options` | `Boolean` | Optional | Include the parcel options information in the result. Default false |
| `include_parcel_items` | `Boolean` | Optional | Include the parcel items information in the result. Default false |
| `access_token` | `String` | Required | Required.<br>An authorization token is necessary to call this method.<br><remarks><br>The token can be obtained by calling the GetToken or RefreshToken methods.<br></remarks> |
| `as_client_id` | `Integer` | Optional | Optional.<br>When empty or null, this field is ignored.<br>When set, actions will be taken for the client specified by the id. |
| `shipment_id` | `Integer` | Optional | Id of an existing shipment. |

## Example (as JSON)

```json
{
  "includeFromAddress": null,
  "includeToAddress": null,
  "includeCarrierInfo": null,
  "includeShipmentOptions": null,
  "includeParcelInfo": null,
  "includeParcelOptions": null,
  "includeParcelItems": null,
  "accessToken": "accessToken2",
  "asClientId": null,
  "shipmentID": null
}
```

