
# Label Information With Cost

Information necessary to print labels.

## Structure

`LabelInformationWithCost`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `labels` | [`Array<PrintableLabel>`](/doc/models/printable-label.md) | Required | Printable labels. One for each parcel. |
| `shipment_id` | `Integer` | Required | ID which uniquely identifies this shipment.<br>This ID can be used in other API Methods. |
| `carrier` | `String` | Optional | Name of the Carrier. |
| `service_level` | `String` | Optional | Name of the selected Service Level |
| `total_amount` | `Float` | Optional | Total amount of the Shipment |
| `error` | [`RequestError`](/doc/models/request-error.md) | Required | This information can be used to determine if an error has occurred when a request was processed. |

## Example (as JSON)

```json
{
  "labels": [
    {
      "parcelIndex": 228,
      "printFormat": "ZPL_4x5",
      "base64Label": "base64Label6",
      "labelKey": "labelKey2",
      "trackingNumber": "trackingNumber2",
      "labelURL": "labelURL0"
    },
    {
      "parcelIndex": 227,
      "printFormat": "PNG_4x5",
      "base64Label": "base64Label5",
      "labelKey": "labelKey1",
      "trackingNumber": "trackingNumber3",
      "labelURL": "labelURL9"
    }
  ],
  "shipmentID": 34,
  "carrier": null,
  "serviceLevel": null,
  "totalAmount": null,
  "error": {
    "details": null,
    "hasError": false
  }
}
```

