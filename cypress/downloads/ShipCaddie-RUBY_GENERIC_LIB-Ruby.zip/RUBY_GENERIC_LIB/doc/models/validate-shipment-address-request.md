
# Validate Shipment Address Request

Validate Shipment Address Request Model

## Structure

`ValidateShipmentAddressRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `access_token` | `String` | Optional | Access Token |
| `as_client_id` | `Integer` | Optional | Client Id used in place of Client Id of signed in user. |
| `shipment_address_to_validate` | [`AddressValidationRequestModel`](/doc/models/address-validation-request-model.md) | Optional | Address Validation request model |

## Example (as JSON)

```json
{
  "accessToken": "<YOUR ACCESS TOKEN>",
  "asClientId": 14,
  "shipmentAddressToValidate": {
    "carrierId": 4,
    "carrierContractId": 2324,
    "addresses": [
      {
        "address1": "2600 Executive Parkway",
        "address2": "Suite 160",
        "provinceCode": "UT",
        "city": "Lehi",
        "countryCode": "US",
        "postalCode": "84043",
        "addressTypeId": "Commercial",
        "companyName": "iDrive Logistics",
        "countryId": 0,
        "addressStatus": false
      }
    ]
  }
}
```

