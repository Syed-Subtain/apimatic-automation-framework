
# Rate Response

## Structure

`RateResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `processing_time_in_seconds` | `Float` | Required | - |
| `carrier_name` | `String` | Optional | - |
| `carrier_client_contract_id` | `Integer` | Optional | - |
| `data` | [`Array<ShippingCostsPerCarrier>`](/doc/models/shipping-costs-per-carrier.md) | Optional | - |
| `error` | [`RequestError`](/doc/models/request-error.md) | Required | This information can be used to determine if an error has occurred when a request was processed. |

## Example (as JSON)

```json
{
  "processingTimeInSeconds": 50.3,
  "carrierName": null,
  "carrierClientContractId": null,
  "data": null,
  "error": {
    "details": null,
    "hasError": false
  }
}
```

