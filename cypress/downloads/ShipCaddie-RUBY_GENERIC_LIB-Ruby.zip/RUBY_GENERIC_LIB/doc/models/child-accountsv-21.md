
# Child Accountsv 21

## Structure

`ChildAccountsv21`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `client_id` | `Integer` | Optional | - |
| `name` | `String` | Optional | - |
| `is_enabled` | `Boolean` | Optional | - |

## Example (as JSON)

```json
{
  "clientId": null,
  "name": null,
  "isEnabled": null
}
```

