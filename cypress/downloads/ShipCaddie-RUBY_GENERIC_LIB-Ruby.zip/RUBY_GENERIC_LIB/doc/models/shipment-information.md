
# Shipment Information

All necessary shipping information

## Structure

`ShipmentInformation`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `order_reference_number` | `String` | Optional | Optional Reference number which can be used<br>to uniquely identify a shipment. |
| `date_shipped` | `DateTime` | Required | Specifies the date of shipment. |
| `options` | [`ShippingOptions`](/doc/models/shipping-options.md) | Optional | Billing and Custom Declaration Options for Shipping. |
| `carrier_client_contract_id` | `Integer` | Required | Indicates which Carrier to use.<br>Obtained from GetCarrierServiceInformation. |
| `carrier_service_level_id` | `Integer` | Required | Indicates which Carrier Service Level to use.<br>Obtained from GetCarrierServiceInformation. |
| `address_from` | [`ShipFromAddress`](/doc/models/ship-from-address.md) | Required | - |
| `address_to` | [`ShipToAddress`](/doc/models/ship-to-address.md) | Required | - |
| `parcels` | [`Array<ParcelDetail>`](/doc/models/parcel-detail.md) | Required | Details of parcels to send. |

## Example (as JSON)

```json
{
  "orderReferenceNumber": null,
  "dateShipped": "2016-03-13T12:52:32.123Z",
  "options": null,
  "carrierClientContractId": 190,
  "carrierServiceLevelId": 224,
  "addressFrom": {
    "companyName": null,
    "email": null,
    "phoneNumber": null,
    "address1": null,
    "address2": null,
    "city": null,
    "stateOrProvince": null,
    "postalCode": null,
    "countryCode": null
  },
  "addressTo": {
    "attentionOf": null,
    "companyName": null,
    "email": null,
    "phoneNumber": null,
    "address1": null,
    "address2": null,
    "isResidential": null,
    "city": null,
    "stateOrProvince": null,
    "postalCode": null,
    "countryCode": null
  },
  "parcels": [
    {
      "referenceField1": null,
      "referenceField2": null,
      "referenceField3": null,
      "parcelID": null,
      "packagingId": null,
      "weightInPounds": 202.52,
      "lengthInInches": 9.24,
      "widthInInches": 82.84,
      "heightInInches": 210.62,
      "options": {
        "return": null,
        "insuranceAmount": null,
        "signature": null,
        "cod": null,
        "machinable": null,
        "holdForPickup": null
      },
      "parcelItems": null
    },
    {
      "referenceField1": null,
      "referenceField2": null,
      "referenceField3": null,
      "parcelID": null,
      "packagingId": null,
      "weightInPounds": 202.53,
      "lengthInInches": 9.25,
      "widthInInches": 82.83,
      "heightInInches": 210.63,
      "options": {
        "return": null,
        "insuranceAmount": null,
        "signature": null,
        "cod": null,
        "machinable": null,
        "holdForPickup": null
      },
      "parcelItems": null
    }
  ]
}
```

