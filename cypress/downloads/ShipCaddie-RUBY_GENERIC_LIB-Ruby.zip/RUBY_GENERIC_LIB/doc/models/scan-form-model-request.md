
# Scan Form Model Request

## Structure

`ScanFormModelRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `carrier_client_contract_id` | `Integer` | Optional | - |
| `shipment_client_address_id` | `Integer` | Optional | - |
| `ship_date` | `DateTime` | Optional | - |
| `key_list` | [`Array<KeyValues>`](/doc/models/key-values.md) | Optional | - |
| `recent_scan_form_id` | `Integer` | Optional | - |

## Example (as JSON)

```json
{
  "carrierClientContractId": null,
  "shipmentClientAddressId": null,
  "shipDate": null,
  "keyList": null,
  "recentScanFormId": null
}
```

