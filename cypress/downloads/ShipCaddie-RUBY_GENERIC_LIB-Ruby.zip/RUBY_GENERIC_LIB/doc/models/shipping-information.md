
# Shipping Information

Shipment Information used to request a rate.

## Structure

`ShippingInformation`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `carrier_client_contract_id` | `Integer` | Optional | Specifies the Carrier for which to check rates. |
| `service_level_id` | `Integer` | Optional | Specifies the ServiceLevel to check. |
| `date_shipped` | `DateTime` | Optional | Specifies the date the packages will be shipped. |
| `options` | [`CustomsOptions`](/doc/models/customs-options.md) | Optional | - |
| `address_from` | [`ShipFromAddress`](/doc/models/ship-from-address.md) | Optional | - |
| `address_to` | [`ShipToAddress`](/doc/models/ship-to-address.md) | Optional | - |
| `parcels` | [`Array<ParcelInformation>`](/doc/models/parcel-information.md) | Optional | Details of parcels to send. |

## Example (as JSON)

```json
{
  "carrierClientContractId": null,
  "serviceLevelId": null,
  "dateShipped": null,
  "options": null,
  "addressFrom": null,
  "addressTo": null,
  "parcels": null
}
```

