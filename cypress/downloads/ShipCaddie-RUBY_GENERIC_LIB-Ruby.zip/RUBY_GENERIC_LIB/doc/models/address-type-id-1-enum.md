
# Address Type Id 1 Enum

Id of the address type

## Enumeration

`AddressTypeId1Enum`

## Fields

| Name |
|  --- |
| `NOTDEFINED` |
| `RESIDENTIAL` |
| `COMMERCIAL` |
| `NOTVERIFIED` |
| `INVALID` |
| `FAILEDADDRESS` |
| `USERVERIFIED` |
| `PROCESSING` |
| `MILITARY` |
| `INTERNATIONAL` |
| `USTERRITORY` |
| `POBOX` |

