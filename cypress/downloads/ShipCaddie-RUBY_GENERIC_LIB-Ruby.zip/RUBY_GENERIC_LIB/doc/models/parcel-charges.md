
# Parcel Charges

Break down of charges per parcel.

## Structure

`ParcelCharges`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `parcel_id` | `UUID \| String` | Required | A unique ID used to match<br>parcels with cost details. |
| `cost_details` | [`Array<CostDetail>`](/doc/models/cost-detail.md) | Optional | Detailed shipping charges. |
| `packaging_id` | `String` | Optional | - |

## Example (as JSON)

```json
{
  "parcelID": "00001f04-0000-0000-0000-000000000000",
  "costDetails": null,
  "packagingId": null
}
```

