
# Address Validation Model

Model for the address validation

## Structure

`AddressValidationModel`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `address_1` | `String` | Optional | Address Line 1 of the address |
| `address_2` | `String` | Optional | Address Line 2 of the address |
| `province` | `String` | Optional | Province for the address |
| `province_code` | `String` | Optional | Code of the Province provided |
| `city` | `String` | Optional | City |
| `country_code` | `String` | Optional | The code of the country whose address is provided |
| `postal_code` | `String` | Optional | Postal code |
| `countryname` | `String` | Optional | Name of the country |
| `address_type_id` | [`AddressTypeIdEnum`](/doc/models/address-type-id-enum.md) | Optional | Type of address<br>Values :<br>- NotDefined<br>- Residential<br>- Commercial<br>- NotVerified<br>- Invalid |
| `company_name` | `String` | Optional | Name of the organization/company |
| `country_id` | `Integer` | Optional | Id of the country specified. |
| `address_status` | `Boolean` | Optional | Status of the address |

## Example (as JSON)

```json
{
  "address1": null,
  "address2": null,
  "province": null,
  "provinceCode": null,
  "city": null,
  "countryCode": null,
  "postalCode": null,
  "countryname": null,
  "addressTypeId": null,
  "companyName": null,
  "countryId": null,
  "addressStatus": null
}
```

