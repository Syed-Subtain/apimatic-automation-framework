
# Shipping Options

Billing and Custom Declaration Options for Shipping.

## Structure

`ShippingOptions`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `is_apo_fpo_dpo_us_territory` | `Boolean` | Required | Set this to true if shipping to:<br><br>* Army Post Office<br>* Fleet Post Office<br>* Diplomatic Post Office<br>* US Territories<br><br>Default value is false. |
| `is_international_shipment` | `Boolean` | Required | Specifies if this shipment is an international shipment.<br><br>Default is false. |
| `billing` | [`BillingOptions`](/doc/models/billing-options.md) | Required | Specifies how the shipping costs will be paid. |
| `shipment_content_type` | [`ShipmentContentTypeEnum`](/doc/models/shipment-content-type-enum.md) | Optional | Indicates the type of content that is in the parcels.<br>Will be used for customs declarations if shipping internationally. |
| `customs_certify` | `Boolean` | Optional | TRUE means the customs information is certified to be correct and the CustomsSigner name is recommended<br><br>Default is null. |
| `customs_signer` | `String` | Optional | Name of person certifying that the customs information is correct.<br>This name prints on the customs form in place of a signature<br>if CustomsCertify is TRUE. Required if CustomsCertify is TRUE<br><br>Default is null. |
| `internal_transaction_number` | `String` | Optional | InternalTransactionNumber is required in case of international shipments and having customDeclarationValue &gt; 2500 |
| `contents_explanation` | `String` | Optional | If we have "CONTENT_TYPE_OTHER" as content type then<br>Then need to pass ContentsExplanation as value |

## Example (as JSON)

```json
{
  "isAPO_FPO_DPO_USTerritory": false,
  "isInternationalShipment": false,
  "billing": {
    "shippingPaidBy": "PAID_BY_RECIPIENT",
    "accountNumber": null,
    "postalCode": null,
    "country_Alpha2Code": null,
    "dutiesPaidBy": "PAID_BY_RECIPIENT"
  },
  "shipmentContentType": null,
  "customsCertify": null,
  "customsSigner": null,
  "internalTransactionNumber": null,
  "contentsExplanation": null
}
```

