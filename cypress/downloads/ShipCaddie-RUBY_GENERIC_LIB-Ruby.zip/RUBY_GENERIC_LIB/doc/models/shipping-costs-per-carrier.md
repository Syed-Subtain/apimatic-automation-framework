
# Shipping Costs Per Carrier

## Structure

`ShippingCostsPerCarrier`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `service_level_name` | `String` | Optional | - |
| `service_level_id` | `Integer` | Optional | - |
| `parcel_charge_details` | [`Array<ParcelCharges>`](/doc/models/parcel-charges.md) | Optional | Shipping charges relating to individual parcels. |
| `shipping_charge_details` | [`Array<CostDetail>`](/doc/models/cost-detail.md) | Optional | Shipping charges relating to a shipment as a whole. |
| `transit_days_min` | `Integer` | Optional | The Days in transit as defined by the carrier for the service level chosen.<br>The number may or may not include non-business days. |
| `transit_days_max` | `Integer` | Optional | The Days in transit as defined by the carrier for the service level chosen.<br>The number may or may not include non-business days. |
| `total_charge_amount` | `Float` | Optional | - |
| `total_charge_amount_3_pl` | `Float` | Optional | The total charge of this shipment.<br>This is the sum of all accessorialCharges.chargeAmount3pl fields in all packages |
| `delivery_date_time` | `String` | Optional | - |
| `is_delivery_guaranteed` | `Boolean` | Optional | - |
| `zone_name` | `String` | Optional | - |
| `total_charge_amount_display` | `Float` | Optional | Gets or Sets ZoneName |

## Example (as JSON)

```json
{
  "serviceLevelName": null,
  "serviceLevelID": null,
  "parcelChargeDetails": null,
  "shippingChargeDetails": null,
  "transitDaysMin": null,
  "transitDaysMax": null,
  "totalChargeAmount": null,
  "totalChargeAmount3pl": null,
  "deliveryDateTime": null,
  "isDeliveryGuaranteed": null,
  "zoneName": null,
  "TotalChargeAmountDisplay": null
}
```

