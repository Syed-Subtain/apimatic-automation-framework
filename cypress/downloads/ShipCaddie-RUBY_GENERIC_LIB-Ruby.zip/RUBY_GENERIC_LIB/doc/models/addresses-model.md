
# Addresses Model

Common model for Requested and Suggested Addresses

## Structure

`AddressesModel`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `address_1` | `String` | Optional | Address Line1 of the address |
| `address_2` | `String` | Optional | Address Line2 of the address |
| `address_type_id` | [`AddressTypeId1Enum`](/doc/models/address-type-id-1-enum.md) | Optional | Id of the address type |
| `city` | `String` | Optional | City |
| `company_name` | `String` | Optional | Name of the Company / Organisation |
| `country_code` | `String` | Optional | Code of the country provided in address |
| `country_id` | `Integer` | Optional | Id of the country specified. |
| `countryname` | `String` | Optional | Name of the country with which address relates |
| `postal_code` | `String` | Optional | Postal Code |
| `province` | `String` | Optional | Province / State |
| `province_code` | `String` | Optional | Code the Province |
| `row_key_hash` | `String` | Optional | Row Key Hash |
| `is_selected` | `Boolean` | Optional | Is Selected |

## Example (as JSON)

```json
{
  "address1": null,
  "address2": null,
  "addressTypeId": null,
  "city": null,
  "companyName": null,
  "countryCode": null,
  "countryId": null,
  "countryname": null,
  "postalCode": null,
  "province": null,
  "provinceCode": null,
  "rowKeyHash": null,
  "isSelected": null
}
```

