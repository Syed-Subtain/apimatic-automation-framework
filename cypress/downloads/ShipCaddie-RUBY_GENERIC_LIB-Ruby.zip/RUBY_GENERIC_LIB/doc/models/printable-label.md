
# Printable Label

Print Label information including a base 64 string label.

## Structure

`PrintableLabel`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `parcel_index` | `Integer` | Required | The parcel number in a multi-parcel shipment<br>The first index will be 1, then it will increment<br>(ie 1, 2, 3, etc.) |
| `print_format` | [`PrintFormat1Enum`](/doc/models/print-format-1-enum.md) | Required | Indicates the format of the Base64 Label |
| `base_64_label` | `String` | Required | This is a base 64 string which is to be decoded<br>into the Print Format specified by PrintFormat. |
| `label_key` | `String` | Required | Used with VoidLabel when voiding a label. |
| `tracking_number` | `String` | Required | Tracking Number of the parcel. |
| `label_url` | `String` | Required | URL of Printable Label |

## Example (as JSON)

```json
{
  "parcelIndex": 162,
  "printFormat": "PNG_4x5",
  "base64Label": "base64Label0",
  "labelKey": "labelKey6",
  "trackingNumber": "trackingNumber8",
  "labelURL": "labelURL4"
}
```

