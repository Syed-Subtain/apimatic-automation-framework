
# Packaging Detail

Carrier Packaging Specifications

## Structure

`PackagingDetail`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `parcel_id` | `String` | Optional | This ID can be used when specifing a Parcel type. |
| `name` | `String` | Optional | Parcel Type |
| `description` | `String` | Optional | Parcel Description |
| `length_in_inches` | `Float` | Optional | Length of one side of parcel in inches. |
| `width_in_inches` | `Float` | Optional | Width of one side of parcel in inches. |
| `height_in_inches` | `Float` | Optional | Height of one side of parcel in inches. |
| `weight_limit` | `Float` | Optional | Carrier Weight limit for the parcel |
| `packaging_weight` | `Float` | Optional | Container weight |

## Example (as JSON)

```json
{
  "parcelId": null,
  "name": null,
  "description": null,
  "lengthInInches": null,
  "widthInInches": null,
  "heightInInches": null,
  "weightLimit": null,
  "packagingWeight": null
}
```

