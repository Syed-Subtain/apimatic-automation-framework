
# Packages V21

## Structure

`PackagesV21`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `length` | `Float` | Optional | Required - Length |
| `width` | `Float` | Optional | Required - Width |
| `height` | `Float` | Optional | Required - Height |

## Example (as JSON)

```json
{
  "length": null,
  "width": null,
  "height": null
}
```

