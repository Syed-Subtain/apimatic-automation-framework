
# Key Values

## Structure

`KeyValues`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `label_key` | `String` | Optional | - |
| `tracking_number` | `String` | Optional | - |
| `package_id` | `Integer` | Optional | - |

## Example (as JSON)

```json
{
  "labelKey": null,
  "trackingNumber": null,
  "packageId": null
}
```

