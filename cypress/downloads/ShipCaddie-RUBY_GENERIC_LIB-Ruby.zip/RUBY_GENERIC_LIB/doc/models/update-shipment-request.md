
# Update Shipment Request

## Structure

`UpdateShipmentRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `access_token` | `String` | Required | Required.<br>An authorization token is necessary to call this method.<br><remarks><br>The token can be obtained by calling the GetToken or RefreshToken methods.<br></remarks> |
| `as_client_id` | `Integer` | Optional | Optional.<br>When empty or null, this field is ignored.<br>When set, actions will be taken for the client specified by the id. |
| `shipment_id` | `Integer` | Optional | Id of an existing shipment. |
| `shipment` | [`ShipmentInformation`](/doc/models/shipment-information.md) | Optional | All necessary shipping information |

## Example (as JSON)

```json
{
  "accessToken": "<YOUR ACCESS TOKEN>",
  "asClientId": 12,
  "shipmentId": 37,
  "shipment": {
    "orderReferenceNumber": "test order",
    "dateShipped": "2020-12-23T23:54:10.3585858Z",
    "options": {
      "isAPO_FPO_DPO_USTerritory": false,
      "isInternationalShipment": false,
      "billing": {
        "shippingPaidBy": "NOT_APPLICABLE",
        "accountNumber": "",
        "postalCode": "",
        "country_Alpha2Code": "",
        "dutiesPaidBy": "NOT_APPLICABLE"
      },
      "shipmentContentType": "CONTENT_TYPE_SAMPLE"
    },
    "carrierClientContractId": 2404,
    "carrierServiceLevelId": 1115,
    "addressFrom": {
      "companyName": "iDrive Logistics",
      "email": "sales@idrivelogistics.com",
      "phoneNumber": "(888) 797-0929",
      "address1": "2600 Executive Pkwy #160",
      "address2": "",
      "city": "Lehi",
      "stateOrProvince": "UT",
      "postalCode": "84043",
      "countryCode": "US"
    },
    "addressTo": {
      "attentionOf": "Mr. Jones",
      "companyName": "iDrive Logistics",
      "email": "sales@idrivelogistics.com",
      "phoneNumber": "(888) 797-0929",
      "address1": "2605 Executive Pkwy #160",
      "address2": "",
      "isResidential": false,
      "city": "Lehi",
      "stateOrProvince": "UT",
      "postalCode": "84043",
      "countryCode": "US"
    },
    "parcels": [
      {
        "referenceField1": "1",
        "referenceField2": "",
        "referenceField3": "",
        "parcelID": "1",
        "packagingId": "",
        "weightInPounds": 0.4,
        "lengthInInches": 5.0,
        "widthInInches": 4.0,
        "heightInInches": 12.0,
        "options": {
          "return": "NOT_APPLICABLE",
          "insuranceAmount": 0.0,
          "signature": "NOT_APPLICABLE",
          "cod": {
            "codType": "NOT_APPLICABLE",
            "codAmount": 0.0
          }
        },
        "parcelItems": [
          {
            "sku": "none",
            "name": "chocolate",
            "description": "candy",
            "quantity": 7,
            "price": 1.03,
            "weightInPounds": 0.5,
            "harmonizeCode": "",
            "originCountry": "US"
          }
        ]
      }
    ]
  }
}
```

