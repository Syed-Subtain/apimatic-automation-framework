
# Cost Detail

Specific break down of cost.

## Structure

`CostDetail`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `name` | `String` | Required | Name of a specific Charge. |
| `amount` | `Float` | Required | Cost in United States Currency. |
| `amount_display` | `Float` | Optional | Total Charge Amount Display |

## Example (as JSON)

```json
{
  "name": "name0",
  "amount": 56.78,
  "AmountDisplay": null
}
```

