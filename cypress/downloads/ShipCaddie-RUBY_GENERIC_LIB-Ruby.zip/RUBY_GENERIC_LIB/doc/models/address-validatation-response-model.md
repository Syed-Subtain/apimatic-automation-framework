
# Address Validatation Response Model

Address Validation Response Model

## Structure

`AddressValidatationResponseModel`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `errors` | [`Array<ErrorModel>`](/doc/models/error-model.md) | Optional | - |
| `is_validated` | `Boolean` | Optional | Flag indicates whether address is validated or not |
| `parsed_addresses` | [`Array<ParsedAddress>`](/doc/models/parsed-address.md) | Optional | List of parsed address |
| `reply_time_stamp` | `DateTime` | Optional | Reply time stamp |
| `status_code` | `String` | Optional | Status code |
| `status_description` | `String` | Optional | Decsription for the status |

## Example (as JSON)

```json
{
  "errors": null,
  "isValidated": null,
  "parsedAddresses": null,
  "replyTimeStamp": null,
  "statusCode": null,
  "statusDescription": null
}
```

