
# Verify Package Length Girth Limit Responsev 21

## Structure

`VerifyPackageLengthGirthLimitResponsev21`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `error` | [`RequestError`](/doc/models/request-error.md) | Optional | This information can be used to determine if an error has occurred when a request was processed. |
| `valid` | `Boolean` | Optional | - |

## Example (as JSON)

```json
{
  "error": null,
  "valid": null
}
```

