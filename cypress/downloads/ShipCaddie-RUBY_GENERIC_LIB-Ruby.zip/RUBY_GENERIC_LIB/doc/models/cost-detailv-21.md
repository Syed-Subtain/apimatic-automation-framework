
# Cost Detailv 21

Specific break down of cost.

## Structure

`CostDetailv21`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `name` | `String` | Optional | Name of a specific Charge. |
| `amount` | `Float` | Optional | Cost in United States Currency. |
| `amount_display` | `Float` | Optional | Total Charge Amount Display |

## Example (as JSON)

```json
{
  "name": null,
  "amount": null,
  "amountDisplay": null
}
```

