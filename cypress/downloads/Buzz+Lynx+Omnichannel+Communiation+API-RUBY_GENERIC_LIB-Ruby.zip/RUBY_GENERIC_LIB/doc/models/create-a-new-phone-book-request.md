
# Create a New Phone Book Request

## Structure

`CreateANewPhoneBookRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `name` | `String` | Required | The name of the phone book (segment) |
| `attribute_1` | `String` | Optional | This specification allows you to specify a name for a first extensible attribute for the segment |
| `attribute_2` | `String` | Optional | This specification allows you to specify a name for a second extensible attribute for the segment |
| `attribute_3` | `String` | Optional | This specification allows you to specify a name for a third extensible attribute for the segment |
| `attribute_4` | `String` | Optional | This specification allows you to specify a name for a fourth extensible attribute for the segment |
| `attribute_5` | `String` | Optional | This specification allows you to specify a name for a fifth extensible attribute for the segment |

## Example (as JSON)

```json
{
  "name": "Soccer Moms",
  "attribute_1": "ChildName",
  "attribute_2": "Team"
}
```

