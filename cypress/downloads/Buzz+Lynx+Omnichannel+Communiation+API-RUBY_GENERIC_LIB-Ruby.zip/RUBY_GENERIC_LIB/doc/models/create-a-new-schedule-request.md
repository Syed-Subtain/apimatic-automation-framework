
# Create a New Schedule Request

## Structure

`CreateANewScheduleRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `name` | `String` | Required | - |
| `type` | `String` | Required | - |
| `start_date` | `String` | Required | - |
| `end_date` | `String` | Required | - |
| `phone_book_id` | `String` | Required | - |
| `template_id` | `String` | Required | - |
| `interval_type` | `String` | Required | - |
| `interval` | `Integer` | Required | - |

## Example (as JSON)

```json
{
  "name": "Soccer Practice Reminder",
  "type": "recurring",
  "start_date": "2015-11-08 14:00",
  "end_date": "2015-11-20 14:00",
  "phone_book_id": "59196",
  "template_id": "8465",
  "interval_type": "days",
  "interval": 30
}
```

