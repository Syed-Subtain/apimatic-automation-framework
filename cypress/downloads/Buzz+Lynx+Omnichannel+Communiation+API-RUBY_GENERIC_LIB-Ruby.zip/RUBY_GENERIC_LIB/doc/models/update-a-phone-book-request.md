
# Update a Phone Book Request

## Structure

`UpdateAPhoneBookRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `name` | `String` | Required | - |
| `attribute_3` | `String` | Required | - |

## Example (as JSON)

```json
{
  "name": "Soccer Moms and Dads",
  "attribute_3": "ID"
}
```

