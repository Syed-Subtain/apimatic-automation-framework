
# Update Account Request

## Structure

`UpdateAccountRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `first_name` | `String` | Required | - |
| `last_name` | `String` | Required | - |
| `email` | `String` | Required | - |
| `mobile_number` | `String` | Required | - |
| `password` | `String` | Required | - |

## Example (as JSON)

```json
{
  "first_name": "Holly",
  "last_name": "Soccer practice will be on the 7th at 6.",
  "email": "holly.hunter@company.com",
  "mobile_number": "5557756235",
  "password": "hunter"
}
```

