
# Update Phone Book Entry Request

## Structure

`UpdatePhoneBookEntryRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `mobile_number` | `String` | Required | - |
| `title` | `String` | Required | - |
| `first_name` | `String` | Required | - |
| `last_name` | `String` | Required | - |
| `attribute_1` | `String` | Required | - |
| `attribute_2` | `String` | Required | - |

## Example (as JSON)

```json
{
  "mobile_number": "821838384234",
  "title": "Mrs",
  "first_name": "Holly",
  "last_name": "Hunter",
  "attribute_1": "Myron",
  "attribute_2": "Team B"
}
```

