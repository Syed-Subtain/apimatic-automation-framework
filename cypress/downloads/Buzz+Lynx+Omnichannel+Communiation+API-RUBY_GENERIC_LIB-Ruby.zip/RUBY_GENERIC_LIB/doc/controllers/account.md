# Account

The account resource provides an interface to update your Iwin account.

```ruby
account_controller = client.account
```

## Class Name

`AccountController`

## Methods

* [Get Account](../../doc/controllers/account.md#get-account)
* [Update Account](../../doc/controllers/account.md#update-account)


# Get Account

`GET /iwin/api/v1/account`

See your account details.

```ruby
def get_account(accept)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `accept` | `String` | Header, Required | - |

## Response Type

`void`

## Example Usage

```ruby
accept = 'application/json'

result = account_controller.get_account(accept)
```


# Update Account

`PUT /iwin/api/v1/account`

Update your account details.

```ruby
def update_account(content_type,
                   accept,
                   body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `content_type` | `String` | Header, Required | - |
| `accept` | `String` | Header, Required | - |
| `body` | [`UpdateAccountRequest`](../../doc/models/update-account-request.md) | Body, Required | - |

## Response Type

`void`

## Example Usage

```ruby
content_type = 'application/json'
accept = 'application/json'
body = UpdateAccountRequest.new
body.first_name = 'Holly'
body.last_name = 'Soccer practice will be on the 7th at 6.'
body.email = 'holly.hunter@company.com'
body.mobile_number = '5557756235'
body.password = 'hunter'

result = account_controller.update_account(content_type, accept, body)
```

