# Report Filters

```ruby
report_filters_controller = client.report_filters
```

## Class Name

`ReportFiltersController`


# Get a Report S Filters

`GET /iwin/api/v1/reports/{id}/filters`

Get a report's filters.

```ruby
def get_a_report_s_filters(accept,
                           id)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `accept` | `String` | Header, Required | - |
| `id` | `String` | Template, Required | - |

## Response Type

`void`

## Example Usage

```ruby
accept = 'application/json'
id = 'id0'

result = report_filters_controller.get_a_report_s_filters(accept, id)
```

