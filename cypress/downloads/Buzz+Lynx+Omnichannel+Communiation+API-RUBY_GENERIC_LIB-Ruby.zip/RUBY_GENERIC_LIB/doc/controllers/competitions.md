# Competitions

```ruby
competitions_controller = client.competitions
```

## Class Name

`CompetitionsController`


# Get Competitions

`GET /iwin-competition/api/v1/competitions`

Get all your competitions (registered premium rated SMSes). To learn more about our Short Codes, go to http://www.iwin.co.za/shortcodes/.

```ruby
def get_competitions(accept)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `accept` | `String` | Header, Required | - |

## Response Type

`void`

## Example Usage

```ruby
accept = 'application/json'

result = competitions_controller.get_competitions(accept)
```

