
# Getting Started with ChargeLogic Connect

## Building

The generated code uses the Newtonsoft Json.NET NuGet Package. If the automatic NuGet package restore is enabled, these dependencies will be installed automatically. Therefore, you will need internet access for build.

* Open the solution (ChargeLogicConnect.sln) file.

Invoke the build process using Ctrl + Shift + B shortcut key or using the Build menu as shown below.

The build process generates a portable class library, which can be used like a normal class library. The generated library is compatible with Windows Forms, Windows RT, Windows Phone 8, Silverlight 5, Xamarin iOS, Xamarin Android and Mono. More information on how to use can be found at the MSDN Portable Class Libraries documentation.

## Installation

The following section explains how to use the com.chargelogic.connect library in a new project.

### 1. Starting a new project

For starting a new project, right click on the current solution from the solution explorer and choose `Add -> New Project`.

![Add a new project in Visual Studio](https://apidocs.io/illustration/cs?workspaceFolder=ChargeLogicConnect-CSharp&workspaceName=ChargeLogicConnect&projectName=com.chargelogic.connect&rootNamespace=com.chargelogic.connect&step=addProject)

Next, choose `Console Application`, provide `TestConsoleProject` as the project name and click OK.

![Create a new Console Application in Visual Studio](https://apidocs.io/illustration/cs?workspaceFolder=ChargeLogicConnect-CSharp&workspaceName=ChargeLogicConnect&projectName=com.chargelogic.connect&rootNamespace=com.chargelogic.connect&step=createProject)

### 2. Set as startup project

The new console project is the entry point for the eventual execution. This requires us to set the `TestConsoleProject` as the start-up project. To do this, right-click on the `TestConsoleProject` and choose `Set as StartUp Project` form the context menu.

![Adding a project reference](https://apidocs.io/illustration/cs?workspaceFolder=ChargeLogicConnect-CSharp&workspaceName=ChargeLogicConnect&projectName=com.chargelogic.connect&rootNamespace=com.chargelogic.connect&step=setStartup)

### 3. Add reference of the library project

In order to use the Tester library in the new project, first we must add a project reference to the `TestConsoleProject`. First, right click on the `References` node in the solution explorer and click `Add Reference...`

![Adding a project reference](https://apidocs.io/illustration/cs?workspaceFolder=ChargeLogicConnect-CSharp&workspaceName=ChargeLogicConnect&projectName=com.chargelogic.connect&rootNamespace=com.chargelogic.connect&step=addReference)

Next, a window will be displayed where we must set the `checkbox` on `Tester.Tests` and click `OK`. By doing this, we have added a reference of the `Tester.Tests` project into the new `TestConsoleProject`.

![Creating a project reference](https://apidocs.io/illustration/cs?workspaceFolder=ChargeLogicConnect-CSharp&workspaceName=ChargeLogicConnect&projectName=com.chargelogic.connect&rootNamespace=com.chargelogic.connect&step=createReference)

### 4. Write sample code

Once the `TestConsoleProject` is created, a file named `Program.cs` will be visible in the solution explorer with an empty `Main` method. This is the entry point for the execution of the entire solution. Here, you can add code to initialize the client library and acquire the instance of a Controller class. Sample code to initialize the client library and using Controller methods is given in the subsequent sections.

![Adding a project reference](https://apidocs.io/illustration/cs?workspaceFolder=ChargeLogicConnect-CSharp&workspaceName=ChargeLogicConnect&projectName=com.chargelogic.connect&rootNamespace=com.chargelogic.connect&step=addCode)

## Initialize the API Client

**_Note:_** Documentation for the client can be found [here.](doc/client.md)

The following parameters are configurable for the API Client:

| Parameter | Type | Description |
|  --- | --- | --- |
| `DefaultServerUrl` | `string` | ChargeLogic Connect REST Endpoint<br>*Default*: `"replace.with.server.name"` |
| `Environment` | Environment | The API environment. <br> **Default: `Environment.ChargeLogicConnect`** |
| `Timeout` | `TimeSpan` | Http client timeout.<br>*Default*: `TimeSpan.FromSeconds(100)` |
| `BasicAuthUserName` | `string` | The username to use with basic authentication |
| `BasicAuthPassword` | `string` | The password to use with basic authentication |

The API client can be initialized as follows:

```csharp
com.chargelogic.connect.ChargeLogicConnectClient client = new com.chargelogic.connect.ChargeLogicConnectClient.Builder()
    .BasicAuthCredentials("BasicAuthUserName", "BasicAuthPassword")
    .Environment(com.chargelogic.connect.Environment.ChargeLogicConnect)
    .DefaultServerUrl("replace.with.server.name")
    .HttpClientConfig(config => config.NumberOfRetries(0))
    .Build();
```

## Authorization

This API uses `Basic Authentication`.

## List of APIs

* [Credit Card Transactions](doc/controllers/credit-card-transactions.md)
* [Gift Card Transactions](doc/controllers/gift-card-transactions.md)
* [Hosted Orders](doc/controllers/hosted-orders.md)
* [Check Transactions](doc/controllers/check-transactions.md)
* [Reporting](doc/controllers/reporting.md)

## Classes Documentation

* [Utility Classes](doc/utility-classes.md)
* [HttpRequest](doc/http-request.md)
* [HttpResponse](doc/http-response.md)
* [HttpStringResponse](doc/http-string-response.md)
* [HttpContext](doc/http-context.md)
* [HttpClientConfiguration](doc/http-client-configuration.md)
* [HttpClientConfiguration Builder](doc/http-client-configuration-builder.md)
* [IAuthManager](doc/i-auth-manager.md)
* [ApiException](doc/api-exception.md)

