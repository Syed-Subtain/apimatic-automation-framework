# Reporting

```csharp
ReportingController reportingController = client.ReportingController;
```

## Class Name

`ReportingController`


# Create Query Order

Return information about a Hosted Order.

```csharp
CreateQueryOrderAsync(
    Models.QueryOrderModel body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`Models.QueryOrderModel`](../../doc/models/query-order-model.md) | Body, Required | - |

## Response Type

[`Task<Models.QueryOrdersResultModel>`](../../doc/models/query-orders-result-model.md)

## Example Usage

```csharp
var body = new QueryOrderModel();
body.Credential = new Credential();
body.Credential.StoreNo = "YOUR_STORE_NO";
body.Credential.APIKey = "YOUR_API_KEY";
body.Credential.ApplicationNo = "YOUR_APPLICATION_NO";
body.Credential.ApplicationVersion = "1.0.0.0";
body.HostedPaymentID = "hostedPaymentID6";
body.Orders = new EFTOrders();
body.Orders.OrderCount = new List<string>();
body.Orders.OrderCount.Add("OrderCount7");
body.Orders.OrderCount.Add("OrderCount8");

try
{
    QueryOrdersResultModel result = await reportingController.CreateQueryOrderAsync(body);
}
catch (ApiException e){};
```

