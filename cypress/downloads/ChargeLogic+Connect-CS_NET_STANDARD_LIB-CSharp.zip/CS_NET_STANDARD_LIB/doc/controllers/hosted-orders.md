# Hosted Orders

```csharp
HostedOrdersController hostedOrdersController = client.HostedOrdersController;
```

## Class Name

`HostedOrdersController`

## Methods

* [Create Unfinalize Order](../../doc/controllers/hosted-orders.md#create-unfinalize-order)
* [Create Finalize Order](../../doc/controllers/hosted-orders.md#create-finalize-order)
* [Create Setup Hosted Order](../../doc/controllers/hosted-orders.md#create-setup-hosted-order)


# Create Unfinalize Order

Change the status of a hosted order from Finalized to Unfinalized, thereby preventing it from being retrieved by the accounting system. This can only succeed if the order has not already been retrieved.

```csharp
CreateUnfinalizeOrderAsync(
    Models.FinalizeOrderModel body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`Models.FinalizeOrderModel`](../../doc/models/finalize-order-model.md) | Body, Required | - |

## Response Type

[`Task<Models.SetupHostedPaymentResultModel>`](../../doc/models/setup-hosted-payment-result-model.md)

## Example Usage

```csharp
var body = new FinalizeOrderModel();
body.Credential = new Credential();
body.Credential.StoreNo = "YOUR_STORE_NO";
body.Credential.APIKey = "YOUR_API_KEY";
body.Credential.ApplicationNo = "YOUR_APPLICATION_NO";
body.Credential.ApplicationVersion = "1.0.0.0";
body.HostedPaymentID = new Guid("00000a7e-0000-0000-0000-000000000000");

try
{
    SetupHostedPaymentResultModel result = await hostedOrdersController.CreateUnfinalizeOrderAsync(body);
}
catch (ApiException e){};
```


# Create Finalize Order

Finalize an order started by a call to SetupHostedOrder; call this method after all transaction calls have completed.

```csharp
CreateFinalizeOrderAsync(
    Models.FinalizeOrderModel body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`Models.FinalizeOrderModel`](../../doc/models/finalize-order-model.md) | Body, Required | - |

## Response Type

`Task`

## Example Usage

```csharp
var body = new FinalizeOrderModel();
body.Credential = new Credential();
body.Credential.StoreNo = "YOUR_STORE_NO";
body.Credential.APIKey = "YOUR_API_KEY";
body.Credential.ApplicationNo = "YOUR_APPLICATION_NO";
body.Credential.ApplicationVersion = "1.0.0.0";
body.HostedPaymentID = new Guid("00000a7e-0000-0000-0000-000000000000");

try
{
    await hostedOrdersController.CreateFinalizeOrderAsync(body);
}
catch (ApiException e){};
```


# Create Setup Hosted Order

Create a hosted order that will be retrieved by the accounting system when finalized; when using this method, the hosted payment window is not used.

```csharp
CreateSetupHostedOrderAsync(
    Models.SetupHostedCreditCardTransactionModel body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`Models.SetupHostedCreditCardTransactionModel`](../../doc/models/setup-hosted-credit-card-transaction-model.md) | Body, Required | - |

## Response Type

[`Task<Models.TransactionResultModel>`](../../doc/models/transaction-result-model.md)

## Example Usage

```csharp
var body = new SetupHostedCreditCardTransactionModel();
body.Credential = new Credential();
body.Credential.StoreNo = "YOUR_STORE_NO";
body.Credential.APIKey = "YOUR_API_KEY";
body.Credential.ApplicationNo = "YOUR_APPLICATION_NO";
body.Credential.ApplicationVersion = "1.0.0.0";
body.Transaction = new Transaction();
body.Transaction.Amount = "1.00";
body.Transaction.ExternalReferenceNumber = "ORD12345678";
body.Transaction.Currency = "USD";
body.Transaction.ConfirmationID = new Guid("{12345678-abcd-1234-abcd-1234567890ab}");
body.BillingAddress = new Address();
body.ShippingAddress = new Address();
body.HostedPayment = new HostedPayment();
body.HostedPayment.RequireCVV = "Yes";
body.HostedPayment.ReturnURL = "https://www.example.com/returnfrompayment";
body.HostedPayment.ConfirmationID = new Guid("{12345678-abcd-1234-abcd-1234567890ab}");

try
{
    TransactionResultModel result = await hostedOrdersController.CreateSetupHostedOrderAsync(body);
}
catch (ApiException e){};
```

