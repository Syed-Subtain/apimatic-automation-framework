# Gift Card Transactions

```csharp
GiftCardTransactionsController giftCardTransactionsController = client.GiftCardTransactionsController;
```

## Class Name

`GiftCardTransactionsController`

## Methods

* [Create Gift Card Authorize](../../doc/controllers/gift-card-transactions.md#create-gift-card-authorize)
* [Create Gift Card Activate](../../doc/controllers/gift-card-transactions.md#create-gift-card-activate)
* [Create Gift Card Settle](../../doc/controllers/gift-card-transactions.md#create-gift-card-settle)
* [Create Gift Card Credit](../../doc/controllers/gift-card-transactions.md#create-gift-card-credit)
* [Create Gift Card Reverse](../../doc/controllers/gift-card-transactions.md#create-gift-card-reverse)
* [Create Gift Card Deactivate](../../doc/controllers/gift-card-transactions.md#create-gift-card-deactivate)
* [Create Gift Card Void](../../doc/controllers/gift-card-transactions.md#create-gift-card-void)
* [Create Gift Card Balance Inquiry](../../doc/controllers/gift-card-transactions.md#create-gift-card-balance-inquiry)
* [Create Gift Card Charge](../../doc/controllers/gift-card-transactions.md#create-gift-card-charge)
* [Create Gift Card Refund](../../doc/controllers/gift-card-transactions.md#create-gift-card-refund)
* [Create Gift Card Balance Increase](../../doc/controllers/gift-card-transactions.md#create-gift-card-balance-increase)


# Create Gift Card Authorize

Reserve funds on a gift card.

```csharp
CreateGiftCardAuthorizeAsync(
    Models.GiftCardTransactionModel body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`Models.GiftCardTransactionModel`](../../doc/models/gift-card-transaction-model.md) | Body, Required | - |

## Response Type

[`Task<Models.TransactionResultModel>`](../../doc/models/transaction-result-model.md)

## Example Usage

```csharp
var body = new GiftCardTransactionModel();
body.Credential = new Credential();
body.Credential.StoreNo = "YOUR_STORE_NO";
body.Credential.APIKey = "YOUR_API_KEY";
body.Credential.ApplicationNo = "YOUR_APPLICATION_NO";
body.Credential.ApplicationVersion = "1.0.0.0";
body.Card = new Card();
body.Transaction = new Transaction();
body.Transaction.Amount = "1.00";
body.Transaction.ExternalReferenceNumber = "ORD12345678";
body.Transaction.Currency = "USD";
body.Transaction.ConfirmationID = new Guid("{12345678-abcd-1234-abcd-1234567890ab}");

try
{
    TransactionResultModel result = await giftCardTransactionsController.CreateGiftCardAuthorizeAsync(body);
}
catch (ApiException e){};
```


# Create Gift Card Activate

Activate a gift card.

```csharp
CreateGiftCardActivateAsync(
    Models.GiftCardTransactionModel body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`Models.GiftCardTransactionModel`](../../doc/models/gift-card-transaction-model.md) | Body, Required | - |

## Response Type

[`Task<Models.TransactionResultModel>`](../../doc/models/transaction-result-model.md)

## Example Usage

```csharp
var body = new GiftCardTransactionModel();
body.Credential = new Credential();
body.Credential.StoreNo = "YOUR_STORE_NO";
body.Credential.APIKey = "YOUR_API_KEY";
body.Credential.ApplicationNo = "YOUR_APPLICATION_NO";
body.Credential.ApplicationVersion = "1.0.0.0";
body.Card = new Card();
body.Transaction = new Transaction();
body.Transaction.Amount = "1.00";
body.Transaction.ExternalReferenceNumber = "ORD12345678";
body.Transaction.Currency = "USD";
body.Transaction.ConfirmationID = new Guid("{12345678-abcd-1234-abcd-1234567890ab}");

try
{
    TransactionResultModel result = await giftCardTransactionsController.CreateGiftCardActivateAsync(body);
}
catch (ApiException e){};
```


# Create Gift Card Settle

Settle funds form a prior approved gift card authorization.

```csharp
CreateGiftCardSettleAsync(
    Models.ReferenceTransactionModel body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`Models.ReferenceTransactionModel`](../../doc/models/reference-transaction-model.md) | Body, Required | - |

## Response Type

[`Task<Models.TransactionResultModel>`](../../doc/models/transaction-result-model.md)

## Example Usage

```csharp
var body = new ReferenceTransactionModel();
body.Credential = new Credential();
body.Credential.StoreNo = "YOUR_STORE_NO";
body.Credential.APIKey = "YOUR_API_KEY";
body.Credential.ApplicationNo = "YOUR_APPLICATION_NO";
body.Credential.ApplicationVersion = "1.0.0.0";
body.ReferenceTransaction = new ReferenceTransaction();
body.ReferenceTransaction.OriginalReferenceNumber = "999000000001";
body.ReferenceTransaction.Amount = "1.00";

try
{
    TransactionResultModel result = await giftCardTransactionsController.CreateGiftCardSettleAsync(body);
}
catch (ApiException e){};
```


# Create Gift Card Credit

Return funds to an active gift card unrelated to a prior sale.

```csharp
CreateGiftCardCreditAsync(
    Models.GiftCardTransactionModel body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`Models.GiftCardTransactionModel`](../../doc/models/gift-card-transaction-model.md) | Body, Required | - |

## Response Type

[`Task<Models.TransactionResultModel>`](../../doc/models/transaction-result-model.md)

## Example Usage

```csharp
var body = new GiftCardTransactionModel();
body.Credential = new Credential();
body.Credential.StoreNo = "YOUR_STORE_NO";
body.Credential.APIKey = "YOUR_API_KEY";
body.Credential.ApplicationNo = "YOUR_APPLICATION_NO";
body.Credential.ApplicationVersion = "1.0.0.0";
body.Card = new Card();
body.Transaction = new Transaction();
body.Transaction.Amount = "1.00";
body.Transaction.ExternalReferenceNumber = "ORD12345678";
body.Transaction.Currency = "USD";
body.Transaction.ConfirmationID = new Guid("{12345678-abcd-1234-abcd-1234567890ab}");

try
{
    TransactionResultModel result = await giftCardTransactionsController.CreateGiftCardCreditAsync(body);
}
catch (ApiException e){};
```


# Create Gift Card Reverse

Release funds held by a gift card authorization.

```csharp
CreateGiftCardReverseAsync(
    Models.ReferenceTransactionModel body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`Models.ReferenceTransactionModel`](../../doc/models/reference-transaction-model.md) | Body, Required | - |

## Response Type

[`Task<Models.TransactionResultModel>`](../../doc/models/transaction-result-model.md)

## Example Usage

```csharp
var body = new ReferenceTransactionModel();
body.Credential = new Credential();
body.Credential.StoreNo = "YOUR_STORE_NO";
body.Credential.APIKey = "YOUR_API_KEY";
body.Credential.ApplicationNo = "YOUR_APPLICATION_NO";
body.Credential.ApplicationVersion = "1.0.0.0";
body.ReferenceTransaction = new ReferenceTransaction();
body.ReferenceTransaction.OriginalReferenceNumber = "999000000001";
body.ReferenceTransaction.Amount = "1.00";

try
{
    TransactionResultModel result = await giftCardTransactionsController.CreateGiftCardReverseAsync(body);
}
catch (ApiException e){};
```


# Create Gift Card Deactivate

Remove an active gift card from service.

```csharp
CreateGiftCardDeactivateAsync(
    Models.GiftCardTransactionModel body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`Models.GiftCardTransactionModel`](../../doc/models/gift-card-transaction-model.md) | Body, Required | - |

## Response Type

[`Task<Models.TransactionResultModel>`](../../doc/models/transaction-result-model.md)

## Example Usage

```csharp
var body = new GiftCardTransactionModel();
body.Credential = new Credential();
body.Credential.StoreNo = "YOUR_STORE_NO";
body.Credential.APIKey = "YOUR_API_KEY";
body.Credential.ApplicationNo = "YOUR_APPLICATION_NO";
body.Credential.ApplicationVersion = "1.0.0.0";
body.Card = new Card();
body.Transaction = new Transaction();
body.Transaction.Amount = "1.00";
body.Transaction.ExternalReferenceNumber = "ORD12345678";
body.Transaction.Currency = "USD";
body.Transaction.ConfirmationID = new Guid("{12345678-abcd-1234-abcd-1234567890ab}");

try
{
    TransactionResultModel result = await giftCardTransactionsController.CreateGiftCardDeactivateAsync(body);
}
catch (ApiException e){};
```


# Create Gift Card Void

Void a prior financial gift card transaction.

```csharp
CreateGiftCardVoidAsync(
    Models.ReferenceTransactionModel body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`Models.ReferenceTransactionModel`](../../doc/models/reference-transaction-model.md) | Body, Required | - |

## Response Type

[`Task<Models.TransactionResultModel>`](../../doc/models/transaction-result-model.md)

## Example Usage

```csharp
var body = new ReferenceTransactionModel();
body.Credential = new Credential();
body.Credential.StoreNo = "YOUR_STORE_NO";
body.Credential.APIKey = "YOUR_API_KEY";
body.Credential.ApplicationNo = "YOUR_APPLICATION_NO";
body.Credential.ApplicationVersion = "1.0.0.0";
body.ReferenceTransaction = new ReferenceTransaction();
body.ReferenceTransaction.OriginalReferenceNumber = "999000000001";
body.ReferenceTransaction.Amount = "1.00";

try
{
    TransactionResultModel result = await giftCardTransactionsController.CreateGiftCardVoidAsync(body);
}
catch (ApiException e){};
```


# Create Gift Card Balance Inquiry

Check the balance on an active gift card.

```csharp
CreateGiftCardBalanceInquiryAsync(
    Models.GiftCardBalanceModel body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`Models.GiftCardBalanceModel`](../../doc/models/gift-card-balance-model.md) | Body, Required | - |

## Response Type

[`Task<Models.TransactionResultModel>`](../../doc/models/transaction-result-model.md)

## Example Usage

```csharp
var body = new GiftCardBalanceModel();
body.Credential = new Credential();
body.Credential.StoreNo = "YOUR_STORE_NO";
body.Credential.APIKey = "YOUR_API_KEY";
body.Credential.ApplicationNo = "YOUR_APPLICATION_NO";
body.Credential.ApplicationVersion = "1.0.0.0";
body.Card = new Card();

try
{
    TransactionResultModel result = await giftCardTransactionsController.CreateGiftCardBalanceInquiryAsync(body);
}
catch (ApiException e){};
```


# Create Gift Card Charge

Redeem funds from an active gift card.

```csharp
CreateGiftCardChargeAsync(
    Models.GiftCardTransactionModel body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`Models.GiftCardTransactionModel`](../../doc/models/gift-card-transaction-model.md) | Body, Required | - |

## Response Type

[`Task<Models.TransactionResultModel>`](../../doc/models/transaction-result-model.md)

## Example Usage

```csharp
var body = new GiftCardTransactionModel();
body.Credential = new Credential();
body.Credential.StoreNo = "YOUR_STORE_NO";
body.Credential.APIKey = "YOUR_API_KEY";
body.Credential.ApplicationNo = "YOUR_APPLICATION_NO";
body.Credential.ApplicationVersion = "1.0.0.0";
body.Card = new Card();
body.Transaction = new Transaction();
body.Transaction.Amount = "1.00";
body.Transaction.ExternalReferenceNumber = "ORD12345678";
body.Transaction.Currency = "USD";
body.Transaction.ConfirmationID = new Guid("{12345678-abcd-1234-abcd-1234567890ab}");

try
{
    TransactionResultModel result = await giftCardTransactionsController.CreateGiftCardChargeAsync(body);
}
catch (ApiException e){};
```


# Create Gift Card Refund

Return funds to a gift card.

```csharp
CreateGiftCardRefundAsync(
    Models.ReferenceTransactionModel body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`Models.ReferenceTransactionModel`](../../doc/models/reference-transaction-model.md) | Body, Required | - |

## Response Type

[`Task<Models.TransactionResultModel>`](../../doc/models/transaction-result-model.md)

## Example Usage

```csharp
var body = new ReferenceTransactionModel();
body.Credential = new Credential();
body.Credential.StoreNo = "YOUR_STORE_NO";
body.Credential.APIKey = "YOUR_API_KEY";
body.Credential.ApplicationNo = "YOUR_APPLICATION_NO";
body.Credential.ApplicationVersion = "1.0.0.0";
body.ReferenceTransaction = new ReferenceTransaction();
body.ReferenceTransaction.OriginalReferenceNumber = "999000000001";
body.ReferenceTransaction.Amount = "1.00";

try
{
    TransactionResultModel result = await giftCardTransactionsController.CreateGiftCardRefundAsync(body);
}
catch (ApiException e){};
```


# Create Gift Card Balance Increase

Add value to an active gift card.

```csharp
CreateGiftCardBalanceIncreaseAsync(
    Models.GiftCardTransactionModel body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`Models.GiftCardTransactionModel`](../../doc/models/gift-card-transaction-model.md) | Body, Required | - |

## Response Type

[`Task<Models.TransactionResultModel>`](../../doc/models/transaction-result-model.md)

## Example Usage

```csharp
var body = new GiftCardTransactionModel();
body.Credential = new Credential();
body.Credential.StoreNo = "YOUR_STORE_NO";
body.Credential.APIKey = "YOUR_API_KEY";
body.Credential.ApplicationNo = "YOUR_APPLICATION_NO";
body.Credential.ApplicationVersion = "1.0.0.0";
body.Card = new Card();
body.Transaction = new Transaction();
body.Transaction.Amount = "1.00";
body.Transaction.ExternalReferenceNumber = "ORD12345678";
body.Transaction.Currency = "USD";
body.Transaction.ConfirmationID = new Guid("{12345678-abcd-1234-abcd-1234567890ab}");

try
{
    TransactionResultModel result = await giftCardTransactionsController.CreateGiftCardBalanceIncreaseAsync(body);
}
catch (ApiException e){};
```

