# Credit Card Transactions

```csharp
CreditCardTransactionsController creditCardTransactionsController = client.CreditCardTransactionsController;
```

## Class Name

`CreditCardTransactionsController`

## Methods

* [Create Setup Hosted Credit Card AVS](../../doc/controllers/credit-card-transactions.md#create-setup-hosted-credit-card-avs)
* [Create Credit Card Address Verify](../../doc/controllers/credit-card-transactions.md#create-credit-card-address-verify)
* [Create Credit Card Address Verify 2](../../doc/controllers/credit-card-transactions.md#create-credit-card-address-verify-2)
* [Create Credit Card Reverse](../../doc/controllers/credit-card-transactions.md#create-credit-card-reverse)
* [Create Setup Hosted Credit Card Authorize](../../doc/controllers/credit-card-transactions.md#create-setup-hosted-credit-card-authorize)
* [Create Credit Card Authorize](../../doc/controllers/credit-card-transactions.md#create-credit-card-authorize)


# Create Setup Hosted Credit Card AVS

Create a hosted payment record for a credit card address verification transaction.

```csharp
CreateSetupHostedCreditCardAVSAsync(
    Models.SetupHostedCreditCardTransactionModel body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`Models.SetupHostedCreditCardTransactionModel`](../../doc/models/setup-hosted-credit-card-transaction-model.md) | Body, Required | - |

## Response Type

[`Task<Models.TransactionResultModel>`](../../doc/models/transaction-result-model.md)

## Example Usage

```csharp
var body = new SetupHostedCreditCardTransactionModel();
body.Credential = new Credential();
body.Credential.StoreNo = "YOUR_STORE_NO";
body.Credential.APIKey = "YOUR_API_KEY";
body.Credential.ApplicationNo = "YOUR_APPLICATION_NO";
body.Credential.ApplicationVersion = "1.0.0.0";
body.Transaction = new Transaction();
body.Transaction.Amount = "1.00";
body.Transaction.ExternalReferenceNumber = "ORD12345678";
body.Transaction.Currency = "USD";
body.Transaction.ConfirmationID = new Guid("{12345678-abcd-1234-abcd-1234567890ab}");
body.BillingAddress = new Address();
body.ShippingAddress = new Address();
body.HostedPayment = new HostedPayment();
body.HostedPayment.RequireCVV = "Yes";
body.HostedPayment.ReturnURL = "https://www.example.com/returnfrompayment";
body.HostedPayment.ConfirmationID = new Guid("{12345678-abcd-1234-abcd-1234567890ab}");

try
{
    TransactionResultModel result = await creditCardTransactionsController.CreateSetupHostedCreditCardAVSAsync(body);
}
catch (ApiException e){};
```


# Create Credit Card Address Verify

Verify the validity of a credit card and billing address without a transaction parameter (this transaction will not be associated with an order).

```csharp
CreateCreditCardAddressVerifyAsync(
    Models.CreditCardVerifyTransactionModel body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`Models.CreditCardVerifyTransactionModel`](../../doc/models/credit-card-verify-transaction-model.md) | Body, Required | - |

## Response Type

[`Task<Models.TransactionResultModel>`](../../doc/models/transaction-result-model.md)

## Example Usage

```csharp
var body = new CreditCardVerifyTransactionModel();
body.Credential = new Credential();
body.Credential.StoreNo = "YOUR_STORE_NO";
body.Credential.APIKey = "YOUR_API_KEY";
body.Credential.ApplicationNo = "YOUR_APPLICATION_NO";
body.Credential.ApplicationVersion = "1.0.0.0";
body.Card = new Card();
body.BillingAddress = new Address();

try
{
    TransactionResultModel result = await creditCardTransactionsController.CreateCreditCardAddressVerifyAsync(body);
}
catch (ApiException e){};
```


# Create Credit Card Address Verify 2

Verify the validity of a credit card and billing address. Use this method instead of CreditCardAddressVerify if you want the Address Verify transaction to be imported into ChargeLogic Payments as a part of an order.

```csharp
CreateCreditCardAddressVerify2Async(
    Models.CreditCardTransactionModel body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`Models.CreditCardTransactionModel`](../../doc/models/credit-card-transaction-model.md) | Body, Required | - |

## Response Type

[`Task<Models.TransactionResultModel>`](../../doc/models/transaction-result-model.md)

## Example Usage

```csharp
var body = new CreditCardTransactionModel();
body.Credential = new Credential();
body.Credential.StoreNo = "YOUR_STORE_NO";
body.Credential.APIKey = "YOUR_API_KEY";
body.Credential.ApplicationNo = "YOUR_APPLICATION_NO";
body.Credential.ApplicationVersion = "1.0.0.0";
body.Card = new Card();
body.Transaction = new Transaction();
body.Transaction.Amount = "1.00";
body.Transaction.ExternalReferenceNumber = "ORD12345678";
body.Transaction.Currency = "USD";
body.Transaction.ConfirmationID = new Guid("{12345678-abcd-1234-abcd-1234567890ab}");
body.BillingAddress = new Address();

try
{
    TransactionResultModel result = await creditCardTransactionsController.CreateCreditCardAddressVerify2Async(body);
}
catch (ApiException e){};
```


# Create Credit Card Reverse

Attempts to release funds held by a prior credit card authorization.

```csharp
CreateCreditCardReverseAsync(
    Models.ReferenceTransactionModel body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`Models.ReferenceTransactionModel`](../../doc/models/reference-transaction-model.md) | Body, Required | - |

## Response Type

[`Task<Models.TransactionResultModel>`](../../doc/models/transaction-result-model.md)

## Example Usage

```csharp
var body = new ReferenceTransactionModel();
body.Credential = new Credential();
body.Credential.StoreNo = "YOUR_STORE_NO";
body.Credential.APIKey = "YOUR_API_KEY";
body.Credential.ApplicationNo = "YOUR_APPLICATION_NO";
body.Credential.ApplicationVersion = "1.0.0.0";
body.ReferenceTransaction = new ReferenceTransaction();
body.ReferenceTransaction.OriginalReferenceNumber = "999000000001";
body.ReferenceTransaction.Amount = "1.00";

try
{
    TransactionResultModel result = await creditCardTransactionsController.CreateCreditCardReverseAsync(body);
}
catch (ApiException e){};
```


# Create Setup Hosted Credit Card Authorize

Create a hosted payment record for a credit card authorize transaction.

```csharp
CreateSetupHostedCreditCardAuthorizeAsync(
    Models.SetupHostedCreditCardTransactionModel body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`Models.SetupHostedCreditCardTransactionModel`](../../doc/models/setup-hosted-credit-card-transaction-model.md) | Body, Required | - |

## Response Type

[`Task<Models.TransactionResultModel>`](../../doc/models/transaction-result-model.md)

## Example Usage

```csharp
var body = new SetupHostedCreditCardTransactionModel();
body.Credential = new Credential();
body.Credential.StoreNo = "YOUR_STORE_NO";
body.Credential.APIKey = "YOUR_API_KEY";
body.Credential.ApplicationNo = "YOUR_APPLICATION_NO";
body.Credential.ApplicationVersion = "1.0.0.0";
body.Transaction = new Transaction();
body.Transaction.Amount = "1.00";
body.Transaction.ExternalReferenceNumber = "ORD12345678";
body.Transaction.Currency = "USD";
body.Transaction.ConfirmationID = new Guid("{12345678-abcd-1234-abcd-1234567890ab}");
body.BillingAddress = new Address();
body.ShippingAddress = new Address();
body.HostedPayment = new HostedPayment();
body.HostedPayment.RequireCVV = "Yes";
body.HostedPayment.ReturnURL = "https://www.example.com/returnfrompayment";
body.HostedPayment.ConfirmationID = new Guid("{12345678-abcd-1234-abcd-1234567890ab}");

try
{
    TransactionResultModel result = await creditCardTransactionsController.CreateSetupHostedCreditCardAuthorizeAsync(body);
}
catch (ApiException e){};
```


# Create Credit Card Authorize

Authorize a credit card.

```csharp
CreateCreditCardAuthorizeAsync(
    Models.CreditCardTransactionModel body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`Models.CreditCardTransactionModel`](../../doc/models/credit-card-transaction-model.md) | Body, Required | - |

## Response Type

[`Task<Models.TransactionResultModel>`](../../doc/models/transaction-result-model.md)

## Example Usage

```csharp
var body = new CreditCardTransactionModel();
body.Credential = new Credential();
body.Credential.StoreNo = "YOUR_STORE_NO";
body.Credential.APIKey = "YOUR_API_KEY";
body.Credential.ApplicationNo = "YOUR_APPLICATION_NO";
body.Credential.ApplicationVersion = "1.0.0.0";
body.Card = new Card();
body.Transaction = new Transaction();
body.Transaction.Amount = "1.00";
body.Transaction.ExternalReferenceNumber = "ORD12345678";
body.Transaction.Currency = "USD";
body.Transaction.ConfirmationID = new Guid("{12345678-abcd-1234-abcd-1234567890ab}");
body.BillingAddress = new Address();

try
{
    TransactionResultModel result = await creditCardTransactionsController.CreateCreditCardAuthorizeAsync(body);
}
catch (ApiException e){};
```

