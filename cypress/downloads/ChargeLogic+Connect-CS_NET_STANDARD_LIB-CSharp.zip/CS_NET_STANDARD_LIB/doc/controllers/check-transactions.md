# Check Transactions

```csharp
CheckTransactionsController checkTransactionsController = client.CheckTransactionsController;
```

## Class Name

`CheckTransactionsController`

## Methods

* [Create Check Charge](../../doc/controllers/check-transactions.md#create-check-charge)
* [Create Setup Hosted Check Charge](../../doc/controllers/check-transactions.md#create-setup-hosted-check-charge)


# Create Check Charge

Deducts funds from a demand deposit account.

```csharp
CreateCheckChargeAsync(
    Models.CheckTransactionModel checkTransaction)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `checkTransaction` | [`Models.CheckTransactionModel`](../../doc/models/check-transaction-model.md) | Body, Required | - |

## Response Type

[`Task<Models.TransactionResultModel>`](../../doc/models/transaction-result-model.md)

## Example Usage

```csharp
var checkTransaction = new CheckTransactionModel();
checkTransaction.Credential = new Credential();
checkTransaction.Credential.StoreNo = "YOUR_STORE_NO";
checkTransaction.Credential.APIKey = "YOUR_API_KEY";
checkTransaction.Credential.ApplicationNo = "YOUR_APPLICATION_NO";
checkTransaction.Credential.ApplicationVersion = "1.0.0.0";
checkTransaction.DemandDepositAccount = new DemandDepositAccount();
checkTransaction.DemandDepositAccount.RoutingNumber = "123456780";
checkTransaction.DemandDepositAccount.AccountNumber = "987654321";
checkTransaction.DemandDepositAccount.CheckType = "Personal";
checkTransaction.DemandDepositAccount.AccountType = "Checking";
checkTransaction.Transaction = new Transaction();
checkTransaction.Transaction.Amount = "1.00";
checkTransaction.Transaction.ExternalReferenceNumber = "ORD12345678";
checkTransaction.Transaction.Currency = "USD";
checkTransaction.Transaction.ConfirmationID = new Guid("{12345678-abcd-1234-abcd-1234567890ab}");
checkTransaction.Identification = new Identification();
checkTransaction.BillingAddress = new Address();

try
{
    TransactionResultModel result = await checkTransactionsController.CreateCheckChargeAsync(checkTransaction);
}
catch (ApiException e){};
```


# Create Setup Hosted Check Charge

Create a hosted payment record for a check charge transaction.

```csharp
CreateSetupHostedCheckChargeAsync(
    Models.SetupHostedCheckTransactionModel body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`Models.SetupHostedCheckTransactionModel`](../../doc/models/setup-hosted-check-transaction-model.md) | Body, Required | - |

## Response Type

[`Task<Models.SetupHostedPaymentResultModel>`](../../doc/models/setup-hosted-payment-result-model.md)

## Example Usage

```csharp
var body = new SetupHostedCheckTransactionModel();
body.Credential = new Credential();
body.Credential.StoreNo = "YOUR_STORE_NO";
body.Credential.APIKey = "YOUR_API_KEY";
body.Credential.ApplicationNo = "YOUR_APPLICATION_NO";
body.Credential.ApplicationVersion = "1.0.0.0";
body.Transaction = new Transaction();
body.Transaction.Amount = "1.00";
body.Transaction.ExternalReferenceNumber = "ORD12345678";
body.Transaction.Currency = "USD";
body.Transaction.ConfirmationID = new Guid("{12345678-abcd-1234-abcd-1234567890ab}");
body.Identification = new Identification();
body.BillingAddress = new Address();
body.ShippingAddress = new Address();
body.HostedPayment = new HostedPayment();
body.HostedPayment.RequireCVV = "Yes";
body.HostedPayment.ReturnURL = "https://www.example.com/returnfrompayment";
body.HostedPayment.ConfirmationID = new Guid("{12345678-abcd-1234-abcd-1234567890ab}");

try
{
    SetupHostedPaymentResultModel result = await checkTransactionsController.CreateSetupHostedCheckChargeAsync(body);
}
catch (ApiException e){};
```

