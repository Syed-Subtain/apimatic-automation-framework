
# Check Reference Model

## Structure

`CheckReferenceModel`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Credential` | [`Models.Credential`](../../doc/models/credential.md) | Required | The ChargeLogic Connect credentials |
| `ReferenceTransaction` | [`Models.ReferenceTransactionModel`](../../doc/models/reference-transaction-model.md) | Required | Information about the original transaction |

## Example (as JSON)

```json
{
  "credential": {
    "StoreNo": "YOUR_STORE_NO",
    "APIKey": "YOUR_API_KEY",
    "ApplicationNo": "YOUR_APPLICATION_NO",
    "ApplicationVersion": "1.0.0.0"
  },
  "referenceTransaction": {
    "credential": {
      "StoreNo": "YOUR_STORE_NO",
      "APIKey": "YOUR_API_KEY",
      "ApplicationNo": "YOUR_APPLICATION_NO",
      "ApplicationVersion": "1.0.0.0"
    },
    "referenceTransaction": {
      "OriginalReferenceNumber": "999000000001",
      "Amount": "1.00"
    }
  }
}
```

