
# Extra Data

An ExtraData object allows you to pass additional custom fields to the ERP system using Name/Value pairs. Setups in the ERP system must be configured to match the ExtraData Name so that the import process can assign the Value to the correct field.

## Structure

`ExtraData`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Name` | `string` | Required | The custom field name. The maximum length is 20. |
| `MValue` | `string` | Required | The custom field value. The maximum length is 250. |

## Example (as JSON)

```json
{
  "Name": "COUPONCODE",
  "Value": "SPRINGSALE"
}
```

