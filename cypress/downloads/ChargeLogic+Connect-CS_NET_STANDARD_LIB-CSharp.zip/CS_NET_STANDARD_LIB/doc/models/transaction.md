
# Transaction

The Transaction object allows you to specify transaction-specific properties like the Amount and the External Reference Number.

## Structure

`Transaction`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Amount` | `string` | Required | The transaction amount. For AddressVerify transactions, this value must be 0. For all other transactions, this value must be positive. |
| `ExternalReferenceNumber` | `string` | Required | A reference number representing the merchant’s application order number. This value will be used by ChargeLogic Payments to retrieve the transaction later, so this value must be unique per order. You can supply the same ExternalReferenceNumber for transactions that are part of the same order and should be retrieved together. The maximum length is 20. |
| `Currency` | `string` | Required | The 3-character alphabetic ISO currency code<br>**Default**: `"USD"` |
| `FreightAmount` | `string` | Optional | The portion of Amount that represents freight charges |
| `TaxAmount` | `string` | Optional | The portion of Amount that represents tax |
| `PurchaseOrderNumber` | `string` | Optional | The customer’s purchase order number. The maximum length is 20. |
| `PurchaseOrderDate` | `string` | Optional | The customer’s purchase order date in MM/DD/YYYY format. |
| `ConfirmationID` | `Guid` | Required | A unique value representing this transaction |
| `LineItem` | [`List<Models.LineItem>`](../../doc/models/line-item.md) | Optional | Array of class LineItem representing the order details |

## Example (as JSON)

```json
{
  "Amount": "1.00",
  "ExternalReferenceNumber": "ORD12345678",
  "Currency": "USD",
  "ConfirmationID": "{12345678-abcd-1234-abcd-1234567890ab}"
}
```

