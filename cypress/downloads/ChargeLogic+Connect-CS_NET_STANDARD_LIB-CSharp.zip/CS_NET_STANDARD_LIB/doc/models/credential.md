
# Credential

The Credential object allows you to pass your ChargeLogic Connect credentials to the server. It is required in every request. The StoreNo and APIKey passed in the Credential object must match the request's HTTP Basic Authentication Username and Password.

## Structure

`Credential`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `StoreNo` | `string` | Required | The merchant’s ChargeLogic Connect-assigned account identifier; must match the HTTP Basic Authentication username |
| `APIKey` | `string` | Required | The merchant’s ChargeLogic Connect-assigned account password |
| `ApplicationNo` | `string` | Required | The external application’s ChargeLogic Connect-assigned identifier |
| `ApplicationVersion` | `string` | Required | The external application’s version number. This value can be supplied in a format of your choice, but it should change each time you update your ChargeLogic Connect integration. |

## Example (as JSON)

```json
{
  "StoreNo": "YOUR_STORE_NO",
  "APIKey": "YOUR_API_KEY",
  "ApplicationNo": "YOUR_APPLICATION_NO",
  "ApplicationVersion": "1.0.0.0"
}
```

