
# Reference Transaction

Reference transaction information

## Structure

`ReferenceTransaction`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `OriginalReferenceNumber` | `string` | Required | The Reference Number returned by a transaction request |
| `Amount` | `string` | Required | The amount of the new transaction |

## Example (as JSON)

```json
{
  "OriginalReferenceNumber": "999000000001",
  "Amount": "1.00"
}
```

