
# Reference Transaction Model

## Structure

`ReferenceTransactionModel`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Credential` | [`Models.Credential`](../../doc/models/credential.md) | Required | The ChargeLogic Connect credentials |
| `ReferenceTransaction` | [`Models.ReferenceTransaction`](../../doc/models/reference-transaction.md) | Required | The original transaction information |

## Example (as JSON)

```json
{
  "credential": {
    "StoreNo": "YOUR_STORE_NO",
    "APIKey": "YOUR_API_KEY",
    "ApplicationNo": "YOUR_APPLICATION_NO",
    "ApplicationVersion": "1.0.0.0"
  },
  "referenceTransaction": {
    "OriginalReferenceNumber": "999000000001",
    "Amount": "1.00"
  }
}
```

