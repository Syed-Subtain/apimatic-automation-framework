
# Line Item

A LineItem object represents a line from an order.

## Structure

`LineItem`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ProductCode` | `string` | Required | The Item No. from the ERP system. The maximum length is 20. |
| `Category` | `string` | Required | The type of LineItem ("Item", "Resource", "G/L Account", etc.). A blank value means Item. |
| `Description` | `string` | Required | The item’s description. The maximum length is 50. |
| `Quantity` | `string` | Required | The line quantity |
| `UnitOfMeasure` | `string` | Required | The standard unit of measure code<br>**Default**: `"PCE"` |
| `UnitPrice` | `string` | Required | The item’s unit price in the Currency Code of the transaction. |
| `LineTaxAmount` | `string` | Required | The tax amount of the line (note that this value can be used for credit card Level 2 data, but it will not be passed to the Order in the ERP system). |
| `LineDiscountAmount` | `string` | Required | The discount amount applied to the line |
| `LineAmount` | `string` | Required | The total line amount, including tax, after any discounts |
| `ExtraData` | [`List<Models.ExtraData>`](../../doc/models/extra-data.md) | Optional | An array of class ExtraDataField to be passed to the ERP system for populating Sales Line custom fields |

## Example (as JSON)

```json
{
  "ProductCode": "1000",
  "Category": "Item",
  "Description": "Bicycle",
  "Quantity": "5",
  "UnitOfMeasure": "PCE",
  "UnitPrice": "1.00",
  "LineTaxAmount": "0.05",
  "LineDiscountAmount": "0.00",
  "LineAmount": "5.05"
}
```

