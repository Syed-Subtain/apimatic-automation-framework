
# Identification

An Identification object describes a customer's identification attributes.

## Structure

`Identification`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `BirthDate` | `string` | Optional | The customer's birthday |
| `IdentificationNumber` | `string` | Optional | The government-issued identification number, such as a driver’s license number. The maximum length is 30. |
| `IdentificationState` | `string` | Optional | The state that issued the government-issued identification. The maximum length is 2. |
| `TaxIDNumber` | `string` | Optional | The business’s federal ID number. The maximum length is 30. |

## Example (as JSON)

```json
{
  "BirthDate": null,
  "IdentificationNumber": null,
  "IdentificationState": null,
  "TaxIDNumber": null
}
```

