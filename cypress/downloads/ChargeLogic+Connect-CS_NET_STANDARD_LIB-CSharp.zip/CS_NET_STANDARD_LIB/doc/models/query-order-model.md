
# Query Order Model

## Structure

`QueryOrderModel`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Credential` | [`Models.Credential`](../../doc/models/credential.md) | Required | The ChargeLogic Connect credentials |
| `HostedPaymentID` | `string` | Required | The Hosted Payment ID of the order to query |
| `Orders` | [`Models.EFTOrders`](../../doc/models/eft-orders.md) | Required | An Order object |

## Example (as JSON)

```json
{
  "credential": {
    "StoreNo": "YOUR_STORE_NO",
    "APIKey": "YOUR_API_KEY",
    "ApplicationNo": "YOUR_APPLICATION_NO",
    "ApplicationVersion": "1.0.0.0"
  },
  "hostedPaymentID": null,
  "orders": null
}
```

