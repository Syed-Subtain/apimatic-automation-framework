
# Response Model

The Response type is an output type. It must be supplied in the request, and it will be populated and returned in the response.

## Structure

`ResponseModel`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ResponseCode` | `string` | Optional, Constant | The value that represents the outcome of the transaction<br>**Default**: `"000"` |
| `HostResponseCode` | `string` | Optional, Constant | The value that represents the outcome of the transaction; passed through from the payment platform<br>**Default**: `"00"` |
| `Message` | `string` | Optional, Constant | The human-readable transaction results. This message should not be displayed to the cardholder.<br>**Default**: `"APPROVED"` |
| `ApprovalNumber` | `string` | Optional, Constant | The transaction’s approval number<br>**Default**: `"123"` |
| `ApprovedAmount` | `string` | Optional, Constant | The amount that was approved; in the case of a partial approval, this may be less than the Transaction Amount.<br>**Default**: `"1.00"` |
| `BalanceAmount` | `string` | Optional, Constant | The balance amount for prepaid accounts or gift cards<br>**Default**: `"0.00"` |
| `TransactionDate` | `string` | Optional, Constant | The date on which the transaction was processed in MM/DD/YY format<br>**Default**: `"12/31/2020"` |
| `TransactionTime` | `string` | Optional, Constant | The time at which the transaction was processed in HH:MM:SS XM format<br>**Default**: `"11:23:54 PM"` |
| `TransactionStatus` | `string` | Optional, Constant | The outcome of the transaction; must be one of “Batched”, ”Hold”, “Approved”, “Used”, “Declined”, “Void”, “Duplicate”, “Failed”, “Error”, “Referred”; Read the value of this field to determine how to handle the transaction response in your application. A TransactonStatus of "Approved" means that the transaction was successful.<br>**Default**: `"Approved"` |
| `AddressVerificationAlert` | `string` | Optional, Constant | An indicator to determine if an AVS Fraud Protection rule was violated (" ", "Mismatch", "Partial Match", "Unknown")<br>**Default**: `"Mismatch"` |
| `CardVerificationValueAlert` | `string` | Optional, Constant | An indicator to determine if a CVV Fraud Protection rule was violated ("", "Mismatch", "Unknown")<br>**Default**: `"Mismatch"` |
| `MaskedAccountNumber` | `string` | Optional, Constant | The AccountNumber, masked with “X” characters, except for the last four digits<br>**Default**: `"XXXXXXXXXXXXXX1234"` |
| `Token` | `string` | Optional, Constant | The ChargeLogic Connect-generated Secure Remote Storage token that represents the AccountNumber; can be used for future transactions<br>**Default**: `"ABCDEFA7998CF6914272A14D64B6"` |
| `ReturnValue` | `string` | Optional, Constant | The transaction Reference Number<br>**Default**: `"99900000001"` |
| `Success` | `bool` | Required, Constant | False, if an exception was raised. Otherwise, true. A value of true does not mean that the transaction was approved - it only means that an exception was not raised. If Success is true, check the Transaction Status for a value of Approved.<br>**Default**: `true` |
| `ErrorMessage` | `string` | Optional, Constant | Exception information<br>**Default**: `"Error"` |

## Example (as JSON)

```json
{
  "Success": true
}
```

