
# Query Orders Result Model

## Structure

`QueryOrdersResultModel`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Orders` | [`Models.EFTOrders`](../../doc/models/eft-orders.md) | Required | An array of Orders |

## Example (as JSON)

```json
{
  "orders": {
    "OrderCount": [
      "OrderCount9"
    ],
    "Order": null
  }
}
```

