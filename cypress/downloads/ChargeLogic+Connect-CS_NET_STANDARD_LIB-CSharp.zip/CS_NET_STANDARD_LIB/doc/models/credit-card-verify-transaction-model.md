
# Credit Card Verify Transaction Model

## Structure

`CreditCardVerifyTransactionModel`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Credential` | [`Models.Credential`](../../doc/models/credential.md) | Required | The ChargeLogic Connect credentials |
| `Card` | [`Models.Card`](../../doc/models/card.md) | Required | Information about the card to be processed |
| `BillingAddress` | [`Models.Address`](../../doc/models/address.md) | Required | The cardholder's billing address |

## Example (as JSON)

```json
{
  "credential": {
    "StoreNo": "YOUR_STORE_NO",
    "APIKey": "YOUR_API_KEY",
    "ApplicationNo": "YOUR_APPLICATION_NO",
    "ApplicationVersion": "1.0.0.0"
  },
  "card": null,
  "billingAddress": null
}
```

