
# EFT Orders

## Structure

`EFTOrders`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `OrderCount` | `List<string>` | Required | The number of orders in the response |
| `Order` | [`List<Models.Order>`](../../doc/models/order.md) | Optional | The array of orders |

## Example (as JSON)

```json
{
  "OrderCount": [
    "OrderCount3",
    "OrderCount4"
  ],
  "Order": null
}
```

