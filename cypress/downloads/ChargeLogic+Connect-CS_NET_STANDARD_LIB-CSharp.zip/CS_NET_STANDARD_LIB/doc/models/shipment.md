
# Shipment

A Shipment object represents a shipment that as been posted in the ERP system.

## Structure

`Shipment`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ShipmentNumber` | `string` | Required | The No. assigned to the shipment |
| `HostedPaymentID` | `Guid?` | Optional | The ID of the Hosted Payment |
| `ShipmentDate` | `string` | Optional | The posting date of the shipment |
| `ShippingAgent` | `string` | Optional | The Shipping Agent Code |
| `ShippingAgentService` | `string` | Optional | The Shipping Agent Service Code |
| `TrackingNumber` | `string` | Optional | The package tracking number |
| `LineItem` | [`List<Models.LineItem>`](../../doc/models/line-item.md) | Optional | Array of class LineItem representing the shipment details |

## Example (as JSON)

```json
{
  "ShipmentNumber": "ShipmentNumber0",
  "HostedPaymentID": null,
  "ShipmentDate": null,
  "ShippingAgent": null,
  "ShippingAgentService": null,
  "TrackingNumber": null,
  "LineItem": null
}
```

