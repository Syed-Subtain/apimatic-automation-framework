
# Order

An Order object represents an order that was sent to the ChargeLogic Connect server.

## Structure

`Order`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ID` | `string` | Required | The Hosted Payment ID of the Order |
| `BillToAddress` | `string` | Required | The first line of the billing street address |
| `BillToAddress2` | `string` | Required | The second line of the billing street address |
| `BillToCity` | `string` | Required | The billing city |
| `BillToCountry` | `string` | Required | The 3-character alphabetic ISO billing country code |
| `BillToEmail` | `string` | Required | The billing email address associated with the addressee |
| `BillToName` | `string` | Required | The billing addressee |
| `BillToPhoneNo` | `string` | Required | The billing phone number associated with the addressee |
| `BillToPostCode` | `string` | Required | The billing post code or ZIP code |
| `BillToCounty` | `string` | Required | The billing state or province |
| `ShipToAddress` | `string` | Required | The first line of the shipping street address |
| `ShipToAddress2` | `string` | Required | The second line of the shipping street address |
| `ShipToCity` | `string` | Required | The shipping city |
| `ShipToCountry` | `string` | Required | The 3-character alphabetic ISO shipping country code |
| `ShipToEmail` | `string` | Required | The shipping email address associated with the addressee |
| `ShipToName` | `string` | Required | The shipping addressee |
| `ShipToPhoneNo` | `string` | Required | The shipping phone number associated with the addressee |
| `ShipToPostCode` | `string` | Required | The shipping post code or ZIP code |
| `ShipToCounty` | `string` | Required | The shipping state or province |
| `Currency` | `string` | Required | The 3-character alphabetic ISO currency code |
| `ExternalReferenceNumber` | `string` | Required | A reference number representing the merchant’s application order number |
| `CreatedDateTime` | `string` | Required | The date and time the order was created |
| `Language` | `string` | Required | The three-character alphabetic ISO cardholder language code |
| `PurchaseOrderNumber` | `string` | Required | The customer’s purchase order number |
| `FreightAmount` | `string` | Required | The portion of Amount that represents freight charges |
| `ShippingAgent` | `string` | Required | The Shipping Agent Code |
| `ShippingAgentService` | `string` | Required | The Shipping Agent Service Code |
| `ExtraDataField` | [`List<Models.ExtraData>`](../../doc/models/extra-data.md) | Optional | An array of class ExtraDataField to be passed to NAV for populating Sales Header fields |
| `LineItem` | [`List<Models.LineItem>`](../../doc/models/line-item.md) | Optional | Array of class LineItem representing the order details |
| `Comment` | [`List<Models.Comment>`](../../doc/models/comment.md) | Optional | An array of comment lines |
| `Shipment` | [`List<Models.Shipment>`](../../doc/models/shipment.md) | Optional | Array of class Shipment representing individual shipments posted from this order |

## Example (as JSON)

```json
{
  "ID": "ID4",
  "BillToAddress": "BillToAddress2",
  "BillToAddress2": "BillToAddress22",
  "BillToCity": "BillToCity4",
  "BillToCountry": "BillToCountry2",
  "BillToEmail": "BillToEmail4",
  "BillToName": "BillToName0",
  "BillToPhoneNo": "BillToPhoneNo0",
  "BillToPostCode": "BillToPostCode8",
  "BillToCounty": "BillToCounty0",
  "ShipToAddress": "ShipToAddress2",
  "ShipToAddress2": "ShipToAddress26",
  "ShipToCity": "ShipToCity4",
  "ShipToCountry": "ShipToCountry6",
  "ShipToEmail": "ShipToEmail6",
  "ShipToName": "ShipToName0",
  "ShipToPhoneNo": "ShipToPhoneNo2",
  "ShipToPostCode": "ShipToPostCode0",
  "ShipToCounty": "ShipToCounty4",
  "Currency": "Currency8",
  "ExternalReferenceNumber": "ExternalReferenceNumber0",
  "CreatedDateTime": "CreatedDateTime2",
  "Language": "Language0",
  "PurchaseOrderNumber": "PurchaseOrderNumber0",
  "FreightAmount": "FreightAmount0",
  "ShippingAgent": "ShippingAgent0",
  "ShippingAgentService": "ShippingAgentService2",
  "ExtraDataField": null,
  "LineItem": null,
  "Comment": null,
  "Shipment": null
}
```

