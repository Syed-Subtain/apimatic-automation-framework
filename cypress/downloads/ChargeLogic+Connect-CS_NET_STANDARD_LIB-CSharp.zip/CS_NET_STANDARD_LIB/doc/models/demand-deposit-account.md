
# Demand Deposit Account

A DemandDepositAccount object describes a checking or savings bank account to be used for ACH payments.

## Structure

`DemandDepositAccount`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `RoutingNumber` | `string` | Required | The ABA routing number for US accounts or XXXXXYYY for Canadian accounts, where XXXXX is the Branch Number and YYY is the Institution Number |
| `AccountNumber` | `string` | Required | The demand deposit account number. The maximum length is 19. |
| `CheckType` | `string` | Required | The check type; must be one of “ ”, “Personal”, or “Business” |
| `AccountType` | `string` | Required | The demand deposit account type; must be one of “ ”, “Checking”, or “Savings” |
| `Token` | `string` | Optional | The ChargeLogic Connect-generated Secure Remote Storage token representing the AccountNumber |
| `CheckNumber` | `string` | Optional | The check number. The maximum length is 15. |

## Example (as JSON)

```json
{
  "RoutingNumber": "123456780",
  "AccountNumber": "987654321",
  "CheckType": "Personal",
  "AccountType": "Checking"
}
```

