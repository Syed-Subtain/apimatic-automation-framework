
# Transaction Result Model

## Structure

`TransactionResultModel`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `CreditCardAuthorizeResult` | [`Models.ResponseModel`](../../doc/models/response-model.md) | Optional | Response information for a CreditCardAuthorize transaction |
| `CreditCardAddressVerify2Result` | [`Models.ResponseModel`](../../doc/models/response-model.md) | Optional | Response information for a CreditCardAddressVerify2 transaction |
| `CreditCardAddressVerifyResult` | [`Models.ResponseModel`](../../doc/models/response-model.md) | Optional | Response information for a CreditCardAddressVerify transaction |
| `GiftCardBalanceIncreaseResult` | [`Models.ResponseModel`](../../doc/models/response-model.md) | Optional | Response information for a GiftCardBalanceIncrease transaction |
| `GiftCardBalanceInquiryResult` | [`Models.ResponseModel`](../../doc/models/response-model.md) | Optional | Response information for a GiftCardBalanceInquiry transaction |
| `GiftCardCreditResult` | [`Models.ResponseModel`](../../doc/models/response-model.md) | Optional | Response information for a GiftCardCredit transaction |
| `GiftCardDeactivateResult` | [`Models.ResponseModel`](../../doc/models/response-model.md) | Optional | Response information for a GiftCardDeactivate transaction |
| `GiftCardActivateResult` | [`Models.ResponseModel`](../../doc/models/response-model.md) | Optional | Response information for a GiftCardActivate transaction |
| `GiftCardAuthorizeResult` | [`Models.ResponseModel`](../../doc/models/response-model.md) | Optional | Response information for a GiftCardAuthorize transaction |
| `GiftCardChargeResult` | [`Models.ResponseModel`](../../doc/models/response-model.md) | Optional | Response information for a GiftCardCharge transaction |
| `CheckChargeResult` | [`Models.ResponseModel`](../../doc/models/response-model.md) | Optional | Response information for a CheckCharge transaction |
| `SetupHostedCheckChargeResult` | [`Models.SetupHostedPaymentResultModel`](../../doc/models/setup-hosted-payment-result-model.md) | Optional | Response information for a SetupHostedCheckCharge transaction |
| `SetupHostedCreditCardAuthorizeResult` | [`Models.SetupHostedPaymentResultModel`](../../doc/models/setup-hosted-payment-result-model.md) | Optional | Response information for a SetupHostedCreditCardAuthorize transaction |
| `SetupHostedOrderResult` | [`Models.SetupHostedPaymentResultModel`](../../doc/models/setup-hosted-payment-result-model.md) | Optional | Response information for a SetupHostedOrder transaction |

## Example (as JSON)

```json
{
  "CreditCardAuthorizeResult": null,
  "CreditCardAddressVerify2Result": null,
  "CreditCardAddressVerifyResult": null,
  "GiftCardBalanceIncreaseResult": null,
  "GiftCardBalanceInquiryResult": null,
  "GiftCardCreditResult": null,
  "GiftCardDeactivateResult": null,
  "GiftCardActivateResult": null,
  "GiftCardAuthorizeResult": null,
  "GiftCardChargeResult": null,
  "CheckChargeResult": null,
  "SetupHostedCheckChargeResult": null,
  "SetupHostedCreditCardAuthorizeResult": null,
  "SetupHostedOrderResult": null
}
```

