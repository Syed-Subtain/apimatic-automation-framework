
# Setup Hosted Check Transaction Model

## Structure

`SetupHostedCheckTransactionModel`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Credential` | [`Models.Credential`](../../doc/models/credential.md) | Required | The ChargeLogic Connect API credentials |
| `Transaction` | [`Models.Transaction`](../../doc/models/transaction.md) | Required | Information about the transaction |
| `Identification` | [`Models.Identification`](../../doc/models/identification.md) | Required | The customer's identification information |
| `BillingAddress` | [`Models.Address`](../../doc/models/address.md) | Required | The customer's billing address |
| `ShippingAddress` | [`Models.Address`](../../doc/models/address.md) | Required | The customer's shipping address |
| `HostedPayment` | [`Models.HostedPayment`](../../doc/models/hosted-payment.md) | Required | Information about the hosted payment |

## Example (as JSON)

```json
{
  "credential": {
    "StoreNo": "YOUR_STORE_NO",
    "APIKey": "YOUR_API_KEY",
    "ApplicationNo": "YOUR_APPLICATION_NO",
    "ApplicationVersion": "1.0.0.0"
  },
  "transaction": {
    "Amount": "1.00",
    "ExternalReferenceNumber": "ORD12345678",
    "Currency": "USD",
    "ConfirmationID": "{12345678-abcd-1234-abcd-1234567890ab}"
  },
  "identification": null,
  "billingAddress": null,
  "shippingAddress": null,
  "hostedPayment": {
    "RequireCVV": "Yes",
    "ReturnURL": "https://www.example.com/returnfrompayment",
    "ConfirmationID": "{12345678-abcd-1234-abcd-1234567890ab}"
  }
}
```

