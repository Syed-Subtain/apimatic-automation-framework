
# Address

The Address object describes an address like a billing address or a shipping address.

## Structure

`Address`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Name` | `string` | Optional | The addressee. The maximum length is 50. |
| `StreetAddress` | `string` | Optional | The first line of the street address. The maximum length is 50. |
| `StreetAddress2` | `string` | Optional | The second line of the street address. The maximum length is 50. |
| `City` | `string` | Optional | The city.  The maximum length is 30. |
| `State` | `string` | Optional | The state or province. The maximum length is 30. |
| `PostCode` | `string` | Optional | The post code or ZIP code. The maximum length is 30. |
| `Country` | `string` | Optional | The 3-character alphabetic ISO country code |
| `PhoneNumber` | `string` | Optional | The phone number associated with the addressee. The maximum length is 30. |
| `Email` | `string` | Optional | The email address associated with the addressee. The maximum length is 80. |

## Example (as JSON)

```json
{
  "Name": null,
  "StreetAddress": null,
  "StreetAddress2": null,
  "City": null,
  "State": null,
  "PostCode": null,
  "Country": null,
  "PhoneNumber": null,
  "Email": null
}
```

