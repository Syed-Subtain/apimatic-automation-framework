
# Gift Card Transaction Model

## Structure

`GiftCardTransactionModel`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Credential` | [`Models.Credential`](../../doc/models/credential.md) | Required | The ChargeLogic Connect credentials |
| `Card` | [`Models.Card`](../../doc/models/card.md) | Required | Information about the credit card |
| `Transaction` | [`Models.Transaction`](../../doc/models/transaction.md) | Required | Information about the transaction |

## Example (as JSON)

```json
{
  "credential": {
    "StoreNo": "YOUR_STORE_NO",
    "APIKey": "YOUR_API_KEY",
    "ApplicationNo": "YOUR_APPLICATION_NO",
    "ApplicationVersion": "1.0.0.0"
  },
  "card": null,
  "transaction": {
    "Amount": "1.00",
    "ExternalReferenceNumber": "ORD12345678",
    "Currency": "USD",
    "ConfirmationID": "{12345678-abcd-1234-abcd-1234567890ab}"
  }
}
```

