
# Card

The Card object represents a payment card. When supplied, you must populate either the AccountNumber or the Token field.

## Structure

`Card`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `CardholderName` | `string` | Optional | The cardholder’s name as it appears on the card. |
| `AccountNumber` | `string` | Optional | The credit card number. This field is required if a nether a Token nor Track2Data is supplied. The maximum length is 19. |
| `ExpirationMonth` | `string` | Optional | The two-digit expiration month. This field is required if Track2Data is not specified. The maximum length is 2. |
| `ExpirationYear` | `string` | Optional | The two-digit expiration year. This field is required if Track2Data is not specified. The maximum length is 2. |
| `Track2Data` | `string` | Optional | All data from Track 2 on the card’s magnetic stripe. This field is required if neither AccountNumber nor Token is specified. The maximum length is 40. |
| `Token` | `string` | Optional | The ChargeLogic Connect-generated Secure Remote Storage token representing the AccountNumber. This field is required if neither AccountNumber nor Track2Data is specified. The maximum length is 50. |
| `CardVerificationValue` | `string` | Optional | The CVV/CVV2/CID from the credit card. For American Express, this is a 4-digit value. For all other card types, it is a 3-digit value. The maximum length is 4. |
| `SetAsDefault` | `string` | Optional | When set to True, this card will be marked as Default when imported by ChargeLogic Payments |

## Example (as JSON)

```json
{
  "CardholderName": null,
  "AccountNumber": null,
  "ExpirationMonth": null,
  "ExpirationYear": null,
  "Track2Data": null,
  "Token": null,
  "CardVerificationValue": null,
  "SetAsDefault": null
}
```

