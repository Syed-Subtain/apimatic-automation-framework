
# Setup Hosted Payment Result Model

## Structure

`SetupHostedPaymentResultModel`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ReturnValue` | `Guid` | Required | The Hosted Payment ID for the Hosted Payment |
| `Success` | `bool` | Required | False, if an exception was raised. True if no exception was raised. |
| `ErrorMessage` | `string` | Required | Exception information |

## Example (as JSON)

```json
{
  "return_value": "{12345678-abcd-1234-abcd-1234567890ab}",
  "Success": true,
  "ErrorMessage": null
}
```

