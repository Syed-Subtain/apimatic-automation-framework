
# Comment

A Comment object represents a collection or order comment lines.

## Structure

`Comment`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `CommentLine` | `string` | Required | Comment lines, each with a maximum length of 80; these comment lines will appear as Sales Order comments |

## Example (as JSON)

```json
{
  "CommentLine": "CommentLine0"
}
```

