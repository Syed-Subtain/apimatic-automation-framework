
# Client Class Documentation

The following parameters are configurable for the API Client:

| Parameter | Type | Description |
|  --- | --- | --- |
| `DefaultServerUrl` | `string` | ChargeLogic Connect REST Endpoint<br>*Default*: `"replace.with.server.name"` |
| `Environment` | Environment | The API environment. <br> **Default: `Environment.ChargeLogicConnect`** |
| `Timeout` | `TimeSpan` | Http client timeout.<br>*Default*: `TimeSpan.FromSeconds(100)` |
| `BasicAuthUserName` | `string` | The username to use with basic authentication |
| `BasicAuthPassword` | `string` | The password to use with basic authentication |

The API client can be initialized as follows:

```csharp
com.chargelogic.connect.ChargeLogicConnectClient client = new com.chargelogic.connect.ChargeLogicConnectClient.Builder()
    .BasicAuthCredentials("BasicAuthUserName", "BasicAuthPassword")
    .Environment(com.chargelogic.connect.Environment.ChargeLogicConnect)
    .DefaultServerUrl("replace.with.server.name")
    .HttpClientConfig(config => config.NumberOfRetries(0))
    .Build();
```

## ChargeLogic ConnectClient Class

The gateway for the SDK. This class acts as a factory for the Controllers and also holds the configuration of the SDK.

### Controllers

| Name | Description |
|  --- | --- |
| CreditCardTransactionsController | Gets CreditCardTransactionsController controller. |
| GiftCardTransactionsController | Gets GiftCardTransactionsController controller. |
| HostedOrdersController | Gets HostedOrdersController controller. |
| ReportingController | Gets ReportingController controller. |
| CheckTransactionsController | Gets CheckTransactionsController controller. |

### Properties

| Name | Description | Type |
|  --- | --- | --- |
| HttpClientConfiguration | Gets the configuration of the Http Client associated with this client. | `IHttpClientConfiguration` |
| Timeout | Http client timeout. | `TimeSpan` |
| Environment | Current API environment. | `Environment` |
| DefaultServerUrl | ChargeLogic Connect REST Endpoint | `string` |

### Methods

| Name | Description | Return Type |
|  --- | --- | --- |
| `GetBaseUri(Server alias = Server.ChargeLogicConnectRESTEndpoint)` | Gets the URL for a particular alias in the current environment and appends it with template parameters. | `string` |
| `ToBuilder()` | Creates an object of the ChargeLogic ConnectClient using the values provided for the builder. | `Builder` |

## ChargeLogic ConnectClient Builder Class

Class to build instances of ChargeLogic ConnectClient.

### Methods

| Name | Description | Return Type |
|  --- | --- | --- |
| `HttpClientConfiguration(Action<HttpClientConfiguration.Builder> action)` | Gets the configuration of the Http Client associated with this client. | `Builder` |
| `Timeout(TimeSpan timeout)` | Http client timeout. | `Builder` |
| `Environment(Environment environment)` | Current API environment. | `Builder` |
| `DefaultServerUrl(string defaultServerUrl)` | ChargeLogic Connect REST Endpoint | `Builder` |

