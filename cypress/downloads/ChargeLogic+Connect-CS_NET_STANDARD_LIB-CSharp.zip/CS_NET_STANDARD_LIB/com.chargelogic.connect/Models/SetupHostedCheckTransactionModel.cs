// <copyright file="SetupHostedCheckTransactionModel.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace com.chargelogic.connect.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using com.chargelogic.connect;
    using com.chargelogic.connect.Utilities;

    /// <summary>
    /// SetupHostedCheckTransactionModel.
    /// </summary>
    public class SetupHostedCheckTransactionModel
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="SetupHostedCheckTransactionModel"/> class.
        /// </summary>
        public SetupHostedCheckTransactionModel()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="SetupHostedCheckTransactionModel"/> class.
        /// </summary>
        /// <param name="credential">credential.</param>
        /// <param name="transaction">transaction.</param>
        /// <param name="identification">identification.</param>
        /// <param name="billingAddress">billingAddress.</param>
        /// <param name="shippingAddress">shippingAddress.</param>
        /// <param name="hostedPayment">hostedPayment.</param>
        public SetupHostedCheckTransactionModel(
            Models.Credential credential,
            Models.Transaction transaction,
            Models.Identification identification,
            Models.Address billingAddress,
            Models.Address shippingAddress,
            Models.HostedPayment hostedPayment)
        {
            this.Credential = credential;
            this.Transaction = transaction;
            this.Identification = identification;
            this.BillingAddress = billingAddress;
            this.ShippingAddress = shippingAddress;
            this.HostedPayment = hostedPayment;
        }

        /// <summary>
        /// The ChargeLogic Connect API credentials
        /// </summary>
        [JsonProperty("credential")]
        public Models.Credential Credential { get; set; }

        /// <summary>
        /// Information about the transaction
        /// </summary>
        [JsonProperty("transaction")]
        public Models.Transaction Transaction { get; set; }

        /// <summary>
        /// The customer's identification information
        /// </summary>
        [JsonProperty("identification")]
        public Models.Identification Identification { get; set; }

        /// <summary>
        /// The customer's billing address
        /// </summary>
        [JsonProperty("billingAddress")]
        public Models.Address BillingAddress { get; set; }

        /// <summary>
        /// The customer's shipping address
        /// </summary>
        [JsonProperty("shippingAddress")]
        public Models.Address ShippingAddress { get; set; }

        /// <summary>
        /// Information about the hosted payment
        /// </summary>
        [JsonProperty("hostedPayment")]
        public Models.HostedPayment HostedPayment { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"SetupHostedCheckTransactionModel : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is SetupHostedCheckTransactionModel other &&
                ((this.Credential == null && other.Credential == null) || (this.Credential?.Equals(other.Credential) == true)) &&
                ((this.Transaction == null && other.Transaction == null) || (this.Transaction?.Equals(other.Transaction) == true)) &&
                ((this.Identification == null && other.Identification == null) || (this.Identification?.Equals(other.Identification) == true)) &&
                ((this.BillingAddress == null && other.BillingAddress == null) || (this.BillingAddress?.Equals(other.BillingAddress) == true)) &&
                ((this.ShippingAddress == null && other.ShippingAddress == null) || (this.ShippingAddress?.Equals(other.ShippingAddress) == true)) &&
                ((this.HostedPayment == null && other.HostedPayment == null) || (this.HostedPayment?.Equals(other.HostedPayment) == true));
        }
        

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.Credential = {(this.Credential == null ? "null" : this.Credential.ToString())}");
            toStringOutput.Add($"this.Transaction = {(this.Transaction == null ? "null" : this.Transaction.ToString())}");
            toStringOutput.Add($"this.Identification = {(this.Identification == null ? "null" : this.Identification.ToString())}");
            toStringOutput.Add($"this.BillingAddress = {(this.BillingAddress == null ? "null" : this.BillingAddress.ToString())}");
            toStringOutput.Add($"this.ShippingAddress = {(this.ShippingAddress == null ? "null" : this.ShippingAddress.ToString())}");
            toStringOutput.Add($"this.HostedPayment = {(this.HostedPayment == null ? "null" : this.HostedPayment.ToString())}");
        }
    }
}