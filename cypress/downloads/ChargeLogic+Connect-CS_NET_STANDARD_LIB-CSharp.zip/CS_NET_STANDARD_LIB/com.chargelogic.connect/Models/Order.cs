// <copyright file="Order.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace com.chargelogic.connect.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using com.chargelogic.connect;
    using com.chargelogic.connect.Utilities;

    /// <summary>
    /// Order.
    /// </summary>
    public class Order
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="Order"/> class.
        /// </summary>
        public Order()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="Order"/> class.
        /// </summary>
        /// <param name="iD">ID.</param>
        /// <param name="billToAddress">BillToAddress.</param>
        /// <param name="billToAddress2">BillToAddress2.</param>
        /// <param name="billToCity">BillToCity.</param>
        /// <param name="billToCountry">BillToCountry.</param>
        /// <param name="billToEmail">BillToEmail.</param>
        /// <param name="billToName">BillToName.</param>
        /// <param name="billToPhoneNo">BillToPhoneNo.</param>
        /// <param name="billToPostCode">BillToPostCode.</param>
        /// <param name="billToCounty">BillToCounty.</param>
        /// <param name="shipToAddress">ShipToAddress.</param>
        /// <param name="shipToAddress2">ShipToAddress2.</param>
        /// <param name="shipToCity">ShipToCity.</param>
        /// <param name="shipToCountry">ShipToCountry.</param>
        /// <param name="shipToEmail">ShipToEmail.</param>
        /// <param name="shipToName">ShipToName.</param>
        /// <param name="shipToPhoneNo">ShipToPhoneNo.</param>
        /// <param name="shipToPostCode">ShipToPostCode.</param>
        /// <param name="shipToCounty">ShipToCounty.</param>
        /// <param name="currency">Currency.</param>
        /// <param name="externalReferenceNumber">ExternalReferenceNumber.</param>
        /// <param name="createdDateTime">CreatedDateTime.</param>
        /// <param name="language">Language.</param>
        /// <param name="purchaseOrderNumber">PurchaseOrderNumber.</param>
        /// <param name="freightAmount">FreightAmount.</param>
        /// <param name="shippingAgent">ShippingAgent.</param>
        /// <param name="shippingAgentService">ShippingAgentService.</param>
        /// <param name="extraDataField">ExtraDataField.</param>
        /// <param name="lineItem">LineItem.</param>
        /// <param name="comment">Comment.</param>
        /// <param name="shipment">Shipment.</param>
        public Order(
            string iD,
            string billToAddress,
            string billToAddress2,
            string billToCity,
            string billToCountry,
            string billToEmail,
            string billToName,
            string billToPhoneNo,
            string billToPostCode,
            string billToCounty,
            string shipToAddress,
            string shipToAddress2,
            string shipToCity,
            string shipToCountry,
            string shipToEmail,
            string shipToName,
            string shipToPhoneNo,
            string shipToPostCode,
            string shipToCounty,
            string currency,
            string externalReferenceNumber,
            string createdDateTime,
            string language,
            string purchaseOrderNumber,
            string freightAmount,
            string shippingAgent,
            string shippingAgentService,
            List<Models.ExtraData> extraDataField = null,
            List<Models.LineItem> lineItem = null,
            List<Models.Comment> comment = null,
            List<Models.Shipment> shipment = null)
        {
            this.ID = iD;
            this.BillToAddress = billToAddress;
            this.BillToAddress2 = billToAddress2;
            this.BillToCity = billToCity;
            this.BillToCountry = billToCountry;
            this.BillToEmail = billToEmail;
            this.BillToName = billToName;
            this.BillToPhoneNo = billToPhoneNo;
            this.BillToPostCode = billToPostCode;
            this.BillToCounty = billToCounty;
            this.ShipToAddress = shipToAddress;
            this.ShipToAddress2 = shipToAddress2;
            this.ShipToCity = shipToCity;
            this.ShipToCountry = shipToCountry;
            this.ShipToEmail = shipToEmail;
            this.ShipToName = shipToName;
            this.ShipToPhoneNo = shipToPhoneNo;
            this.ShipToPostCode = shipToPostCode;
            this.ShipToCounty = shipToCounty;
            this.Currency = currency;
            this.ExternalReferenceNumber = externalReferenceNumber;
            this.CreatedDateTime = createdDateTime;
            this.Language = language;
            this.PurchaseOrderNumber = purchaseOrderNumber;
            this.FreightAmount = freightAmount;
            this.ShippingAgent = shippingAgent;
            this.ShippingAgentService = shippingAgentService;
            this.ExtraDataField = extraDataField;
            this.LineItem = lineItem;
            this.Comment = comment;
            this.Shipment = shipment;
        }

        /// <summary>
        /// The Hosted Payment ID of the Order
        /// </summary>
        [JsonProperty("ID")]
        public string ID { get; set; }

        /// <summary>
        /// The first line of the billing street address
        /// </summary>
        [JsonProperty("BillToAddress")]
        public string BillToAddress { get; set; }

        /// <summary>
        /// The second line of the billing street address
        /// </summary>
        [JsonProperty("BillToAddress2")]
        public string BillToAddress2 { get; set; }

        /// <summary>
        /// The billing city
        /// </summary>
        [JsonProperty("BillToCity")]
        public string BillToCity { get; set; }

        /// <summary>
        /// The 3-character alphabetic ISO billing country code
        /// </summary>
        [JsonProperty("BillToCountry")]
        public string BillToCountry { get; set; }

        /// <summary>
        /// The billing email address associated with the addressee
        /// </summary>
        [JsonProperty("BillToEmail")]
        public string BillToEmail { get; set; }

        /// <summary>
        /// The billing addressee
        /// </summary>
        [JsonProperty("BillToName")]
        public string BillToName { get; set; }

        /// <summary>
        /// The billing phone number associated with the addressee
        /// </summary>
        [JsonProperty("BillToPhoneNo")]
        public string BillToPhoneNo { get; set; }

        /// <summary>
        /// The billing post code or ZIP code
        /// </summary>
        [JsonProperty("BillToPostCode")]
        public string BillToPostCode { get; set; }

        /// <summary>
        /// The billing state or province
        /// </summary>
        [JsonProperty("BillToCounty")]
        public string BillToCounty { get; set; }

        /// <summary>
        /// The first line of the shipping street address
        /// </summary>
        [JsonProperty("ShipToAddress")]
        public string ShipToAddress { get; set; }

        /// <summary>
        /// The second line of the shipping street address
        /// </summary>
        [JsonProperty("ShipToAddress2")]
        public string ShipToAddress2 { get; set; }

        /// <summary>
        /// The shipping city
        /// </summary>
        [JsonProperty("ShipToCity")]
        public string ShipToCity { get; set; }

        /// <summary>
        /// The 3-character alphabetic ISO shipping country code
        /// </summary>
        [JsonProperty("ShipToCountry")]
        public string ShipToCountry { get; set; }

        /// <summary>
        /// The shipping email address associated with the addressee
        /// </summary>
        [JsonProperty("ShipToEmail")]
        public string ShipToEmail { get; set; }

        /// <summary>
        /// The shipping addressee
        /// </summary>
        [JsonProperty("ShipToName")]
        public string ShipToName { get; set; }

        /// <summary>
        /// The shipping phone number associated with the addressee
        /// </summary>
        [JsonProperty("ShipToPhoneNo")]
        public string ShipToPhoneNo { get; set; }

        /// <summary>
        /// The shipping post code or ZIP code
        /// </summary>
        [JsonProperty("ShipToPostCode")]
        public string ShipToPostCode { get; set; }

        /// <summary>
        /// The shipping state or province
        /// </summary>
        [JsonProperty("ShipToCounty")]
        public string ShipToCounty { get; set; }

        /// <summary>
        /// The 3-character alphabetic ISO currency code
        /// </summary>
        [JsonProperty("Currency")]
        public string Currency { get; set; }

        /// <summary>
        /// A reference number representing the merchant’s application order number
        /// </summary>
        [JsonProperty("ExternalReferenceNumber")]
        public string ExternalReferenceNumber { get; set; }

        /// <summary>
        /// The date and time the order was created
        /// </summary>
        [JsonProperty("CreatedDateTime")]
        public string CreatedDateTime { get; set; }

        /// <summary>
        /// The three-character alphabetic ISO cardholder language code
        /// </summary>
        [JsonProperty("Language")]
        public string Language { get; set; }

        /// <summary>
        /// The customer’s purchase order number
        /// </summary>
        [JsonProperty("PurchaseOrderNumber")]
        public string PurchaseOrderNumber { get; set; }

        /// <summary>
        /// The portion of Amount that represents freight charges
        /// </summary>
        [JsonProperty("FreightAmount")]
        public string FreightAmount { get; set; }

        /// <summary>
        /// The Shipping Agent Code
        /// </summary>
        [JsonProperty("ShippingAgent")]
        public string ShippingAgent { get; set; }

        /// <summary>
        /// The Shipping Agent Service Code
        /// </summary>
        [JsonProperty("ShippingAgentService")]
        public string ShippingAgentService { get; set; }

        /// <summary>
        /// An array of class ExtraDataField to be passed to NAV for populating Sales Header fields
        /// </summary>
        [JsonProperty("ExtraDataField", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.ExtraData> ExtraDataField { get; set; }

        /// <summary>
        /// Array of class LineItem representing the order details
        /// </summary>
        [JsonProperty("LineItem", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.LineItem> LineItem { get; set; }

        /// <summary>
        /// An array of comment lines
        /// </summary>
        [JsonProperty("Comment", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.Comment> Comment { get; set; }

        /// <summary>
        /// Array of class Shipment representing individual shipments posted from this order
        /// </summary>
        [JsonProperty("Shipment", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.Shipment> Shipment { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"Order : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is Order other &&
                ((this.ID == null && other.ID == null) || (this.ID?.Equals(other.ID) == true)) &&
                ((this.BillToAddress == null && other.BillToAddress == null) || (this.BillToAddress?.Equals(other.BillToAddress) == true)) &&
                ((this.BillToAddress2 == null && other.BillToAddress2 == null) || (this.BillToAddress2?.Equals(other.BillToAddress2) == true)) &&
                ((this.BillToCity == null && other.BillToCity == null) || (this.BillToCity?.Equals(other.BillToCity) == true)) &&
                ((this.BillToCountry == null && other.BillToCountry == null) || (this.BillToCountry?.Equals(other.BillToCountry) == true)) &&
                ((this.BillToEmail == null && other.BillToEmail == null) || (this.BillToEmail?.Equals(other.BillToEmail) == true)) &&
                ((this.BillToName == null && other.BillToName == null) || (this.BillToName?.Equals(other.BillToName) == true)) &&
                ((this.BillToPhoneNo == null && other.BillToPhoneNo == null) || (this.BillToPhoneNo?.Equals(other.BillToPhoneNo) == true)) &&
                ((this.BillToPostCode == null && other.BillToPostCode == null) || (this.BillToPostCode?.Equals(other.BillToPostCode) == true)) &&
                ((this.BillToCounty == null && other.BillToCounty == null) || (this.BillToCounty?.Equals(other.BillToCounty) == true)) &&
                ((this.ShipToAddress == null && other.ShipToAddress == null) || (this.ShipToAddress?.Equals(other.ShipToAddress) == true)) &&
                ((this.ShipToAddress2 == null && other.ShipToAddress2 == null) || (this.ShipToAddress2?.Equals(other.ShipToAddress2) == true)) &&
                ((this.ShipToCity == null && other.ShipToCity == null) || (this.ShipToCity?.Equals(other.ShipToCity) == true)) &&
                ((this.ShipToCountry == null && other.ShipToCountry == null) || (this.ShipToCountry?.Equals(other.ShipToCountry) == true)) &&
                ((this.ShipToEmail == null && other.ShipToEmail == null) || (this.ShipToEmail?.Equals(other.ShipToEmail) == true)) &&
                ((this.ShipToName == null && other.ShipToName == null) || (this.ShipToName?.Equals(other.ShipToName) == true)) &&
                ((this.ShipToPhoneNo == null && other.ShipToPhoneNo == null) || (this.ShipToPhoneNo?.Equals(other.ShipToPhoneNo) == true)) &&
                ((this.ShipToPostCode == null && other.ShipToPostCode == null) || (this.ShipToPostCode?.Equals(other.ShipToPostCode) == true)) &&
                ((this.ShipToCounty == null && other.ShipToCounty == null) || (this.ShipToCounty?.Equals(other.ShipToCounty) == true)) &&
                ((this.Currency == null && other.Currency == null) || (this.Currency?.Equals(other.Currency) == true)) &&
                ((this.ExternalReferenceNumber == null && other.ExternalReferenceNumber == null) || (this.ExternalReferenceNumber?.Equals(other.ExternalReferenceNumber) == true)) &&
                ((this.CreatedDateTime == null && other.CreatedDateTime == null) || (this.CreatedDateTime?.Equals(other.CreatedDateTime) == true)) &&
                ((this.Language == null && other.Language == null) || (this.Language?.Equals(other.Language) == true)) &&
                ((this.PurchaseOrderNumber == null && other.PurchaseOrderNumber == null) || (this.PurchaseOrderNumber?.Equals(other.PurchaseOrderNumber) == true)) &&
                ((this.FreightAmount == null && other.FreightAmount == null) || (this.FreightAmount?.Equals(other.FreightAmount) == true)) &&
                ((this.ShippingAgent == null && other.ShippingAgent == null) || (this.ShippingAgent?.Equals(other.ShippingAgent) == true)) &&
                ((this.ShippingAgentService == null && other.ShippingAgentService == null) || (this.ShippingAgentService?.Equals(other.ShippingAgentService) == true)) &&
                ((this.ExtraDataField == null && other.ExtraDataField == null) || (this.ExtraDataField?.Equals(other.ExtraDataField) == true)) &&
                ((this.LineItem == null && other.LineItem == null) || (this.LineItem?.Equals(other.LineItem) == true)) &&
                ((this.Comment == null && other.Comment == null) || (this.Comment?.Equals(other.Comment) == true)) &&
                ((this.Shipment == null && other.Shipment == null) || (this.Shipment?.Equals(other.Shipment) == true));
        }
        

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.ID = {(this.ID == null ? "null" : this.ID == string.Empty ? "" : this.ID)}");
            toStringOutput.Add($"this.BillToAddress = {(this.BillToAddress == null ? "null" : this.BillToAddress == string.Empty ? "" : this.BillToAddress)}");
            toStringOutput.Add($"this.BillToAddress2 = {(this.BillToAddress2 == null ? "null" : this.BillToAddress2 == string.Empty ? "" : this.BillToAddress2)}");
            toStringOutput.Add($"this.BillToCity = {(this.BillToCity == null ? "null" : this.BillToCity == string.Empty ? "" : this.BillToCity)}");
            toStringOutput.Add($"this.BillToCountry = {(this.BillToCountry == null ? "null" : this.BillToCountry == string.Empty ? "" : this.BillToCountry)}");
            toStringOutput.Add($"this.BillToEmail = {(this.BillToEmail == null ? "null" : this.BillToEmail == string.Empty ? "" : this.BillToEmail)}");
            toStringOutput.Add($"this.BillToName = {(this.BillToName == null ? "null" : this.BillToName == string.Empty ? "" : this.BillToName)}");
            toStringOutput.Add($"this.BillToPhoneNo = {(this.BillToPhoneNo == null ? "null" : this.BillToPhoneNo == string.Empty ? "" : this.BillToPhoneNo)}");
            toStringOutput.Add($"this.BillToPostCode = {(this.BillToPostCode == null ? "null" : this.BillToPostCode == string.Empty ? "" : this.BillToPostCode)}");
            toStringOutput.Add($"this.BillToCounty = {(this.BillToCounty == null ? "null" : this.BillToCounty == string.Empty ? "" : this.BillToCounty)}");
            toStringOutput.Add($"this.ShipToAddress = {(this.ShipToAddress == null ? "null" : this.ShipToAddress == string.Empty ? "" : this.ShipToAddress)}");
            toStringOutput.Add($"this.ShipToAddress2 = {(this.ShipToAddress2 == null ? "null" : this.ShipToAddress2 == string.Empty ? "" : this.ShipToAddress2)}");
            toStringOutput.Add($"this.ShipToCity = {(this.ShipToCity == null ? "null" : this.ShipToCity == string.Empty ? "" : this.ShipToCity)}");
            toStringOutput.Add($"this.ShipToCountry = {(this.ShipToCountry == null ? "null" : this.ShipToCountry == string.Empty ? "" : this.ShipToCountry)}");
            toStringOutput.Add($"this.ShipToEmail = {(this.ShipToEmail == null ? "null" : this.ShipToEmail == string.Empty ? "" : this.ShipToEmail)}");
            toStringOutput.Add($"this.ShipToName = {(this.ShipToName == null ? "null" : this.ShipToName == string.Empty ? "" : this.ShipToName)}");
            toStringOutput.Add($"this.ShipToPhoneNo = {(this.ShipToPhoneNo == null ? "null" : this.ShipToPhoneNo == string.Empty ? "" : this.ShipToPhoneNo)}");
            toStringOutput.Add($"this.ShipToPostCode = {(this.ShipToPostCode == null ? "null" : this.ShipToPostCode == string.Empty ? "" : this.ShipToPostCode)}");
            toStringOutput.Add($"this.ShipToCounty = {(this.ShipToCounty == null ? "null" : this.ShipToCounty == string.Empty ? "" : this.ShipToCounty)}");
            toStringOutput.Add($"this.Currency = {(this.Currency == null ? "null" : this.Currency == string.Empty ? "" : this.Currency)}");
            toStringOutput.Add($"this.ExternalReferenceNumber = {(this.ExternalReferenceNumber == null ? "null" : this.ExternalReferenceNumber == string.Empty ? "" : this.ExternalReferenceNumber)}");
            toStringOutput.Add($"this.CreatedDateTime = {(this.CreatedDateTime == null ? "null" : this.CreatedDateTime == string.Empty ? "" : this.CreatedDateTime)}");
            toStringOutput.Add($"this.Language = {(this.Language == null ? "null" : this.Language == string.Empty ? "" : this.Language)}");
            toStringOutput.Add($"this.PurchaseOrderNumber = {(this.PurchaseOrderNumber == null ? "null" : this.PurchaseOrderNumber == string.Empty ? "" : this.PurchaseOrderNumber)}");
            toStringOutput.Add($"this.FreightAmount = {(this.FreightAmount == null ? "null" : this.FreightAmount == string.Empty ? "" : this.FreightAmount)}");
            toStringOutput.Add($"this.ShippingAgent = {(this.ShippingAgent == null ? "null" : this.ShippingAgent == string.Empty ? "" : this.ShippingAgent)}");
            toStringOutput.Add($"this.ShippingAgentService = {(this.ShippingAgentService == null ? "null" : this.ShippingAgentService == string.Empty ? "" : this.ShippingAgentService)}");
            toStringOutput.Add($"this.ExtraDataField = {(this.ExtraDataField == null ? "null" : $"[{string.Join(", ", this.ExtraDataField)} ]")}");
            toStringOutput.Add($"this.LineItem = {(this.LineItem == null ? "null" : $"[{string.Join(", ", this.LineItem)} ]")}");
            toStringOutput.Add($"this.Comment = {(this.Comment == null ? "null" : $"[{string.Join(", ", this.Comment)} ]")}");
            toStringOutput.Add($"this.Shipment = {(this.Shipment == null ? "null" : $"[{string.Join(", ", this.Shipment)} ]")}");
        }
    }
}