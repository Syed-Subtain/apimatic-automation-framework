// <copyright file="CreditCardVerifyTransactionModel.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace com.chargelogic.connect.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using com.chargelogic.connect;
    using com.chargelogic.connect.Utilities;

    /// <summary>
    /// CreditCardVerifyTransactionModel.
    /// </summary>
    public class CreditCardVerifyTransactionModel
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="CreditCardVerifyTransactionModel"/> class.
        /// </summary>
        public CreditCardVerifyTransactionModel()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="CreditCardVerifyTransactionModel"/> class.
        /// </summary>
        /// <param name="credential">credential.</param>
        /// <param name="card">card.</param>
        /// <param name="billingAddress">billingAddress.</param>
        public CreditCardVerifyTransactionModel(
            Models.Credential credential,
            Models.Card card,
            Models.Address billingAddress)
        {
            this.Credential = credential;
            this.Card = card;
            this.BillingAddress = billingAddress;
        }

        /// <summary>
        /// The ChargeLogic Connect credentials
        /// </summary>
        [JsonProperty("credential")]
        public Models.Credential Credential { get; set; }

        /// <summary>
        /// Information about the card to be processed
        /// </summary>
        [JsonProperty("card")]
        public Models.Card Card { get; set; }

        /// <summary>
        /// The cardholder's billing address
        /// </summary>
        [JsonProperty("billingAddress")]
        public Models.Address BillingAddress { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"CreditCardVerifyTransactionModel : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is CreditCardVerifyTransactionModel other &&
                ((this.Credential == null && other.Credential == null) || (this.Credential?.Equals(other.Credential) == true)) &&
                ((this.Card == null && other.Card == null) || (this.Card?.Equals(other.Card) == true)) &&
                ((this.BillingAddress == null && other.BillingAddress == null) || (this.BillingAddress?.Equals(other.BillingAddress) == true));
        }
        

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.Credential = {(this.Credential == null ? "null" : this.Credential.ToString())}");
            toStringOutput.Add($"this.Card = {(this.Card == null ? "null" : this.Card.ToString())}");
            toStringOutput.Add($"this.BillingAddress = {(this.BillingAddress == null ? "null" : this.BillingAddress.ToString())}");
        }
    }
}