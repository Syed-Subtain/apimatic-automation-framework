// <copyright file="QueryOrdersResultModel.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace com.chargelogic.connect.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using com.chargelogic.connect;
    using com.chargelogic.connect.Utilities;

    /// <summary>
    /// QueryOrdersResultModel.
    /// </summary>
    public class QueryOrdersResultModel
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="QueryOrdersResultModel"/> class.
        /// </summary>
        public QueryOrdersResultModel()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="QueryOrdersResultModel"/> class.
        /// </summary>
        /// <param name="orders">orders.</param>
        public QueryOrdersResultModel(
            Models.EFTOrders orders)
        {
            this.Orders = orders;
        }

        /// <summary>
        /// An array of Orders
        /// </summary>
        [JsonProperty("orders")]
        public Models.EFTOrders Orders { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"QueryOrdersResultModel : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is QueryOrdersResultModel other &&
                ((this.Orders == null && other.Orders == null) || (this.Orders?.Equals(other.Orders) == true));
        }
        

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.Orders = {(this.Orders == null ? "null" : this.Orders.ToString())}");
        }
    }
}