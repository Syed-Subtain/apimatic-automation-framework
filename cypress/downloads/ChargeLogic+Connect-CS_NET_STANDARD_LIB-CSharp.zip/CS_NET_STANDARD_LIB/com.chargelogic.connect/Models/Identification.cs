// <copyright file="Identification.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace com.chargelogic.connect.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using com.chargelogic.connect;
    using com.chargelogic.connect.Utilities;

    /// <summary>
    /// Identification.
    /// </summary>
    public class Identification
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="Identification"/> class.
        /// </summary>
        public Identification()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="Identification"/> class.
        /// </summary>
        /// <param name="birthDate">BirthDate.</param>
        /// <param name="identificationNumber">IdentificationNumber.</param>
        /// <param name="identificationState">IdentificationState.</param>
        /// <param name="taxIDNumber">TaxIDNumber.</param>
        public Identification(
            string birthDate = null,
            string identificationNumber = null,
            string identificationState = null,
            string taxIDNumber = null)
        {
            this.BirthDate = birthDate;
            this.IdentificationNumber = identificationNumber;
            this.IdentificationState = identificationState;
            this.TaxIDNumber = taxIDNumber;
        }

        /// <summary>
        /// The customer's birthday
        /// </summary>
        [JsonProperty("BirthDate", NullValueHandling = NullValueHandling.Ignore)]
        public string BirthDate { get; set; }

        /// <summary>
        /// The government-issued identification number, such as a driver’s license number. The maximum length is 30.
        /// </summary>
        [JsonProperty("IdentificationNumber", NullValueHandling = NullValueHandling.Ignore)]
        public string IdentificationNumber { get; set; }

        /// <summary>
        /// The state that issued the government-issued identification. The maximum length is 2.
        /// </summary>
        [JsonProperty("IdentificationState", NullValueHandling = NullValueHandling.Ignore)]
        public string IdentificationState { get; set; }

        /// <summary>
        /// The business’s federal ID number. The maximum length is 30.
        /// </summary>
        [JsonProperty("TaxIDNumber", NullValueHandling = NullValueHandling.Ignore)]
        public string TaxIDNumber { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"Identification : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is Identification other &&
                ((this.BirthDate == null && other.BirthDate == null) || (this.BirthDate?.Equals(other.BirthDate) == true)) &&
                ((this.IdentificationNumber == null && other.IdentificationNumber == null) || (this.IdentificationNumber?.Equals(other.IdentificationNumber) == true)) &&
                ((this.IdentificationState == null && other.IdentificationState == null) || (this.IdentificationState?.Equals(other.IdentificationState) == true)) &&
                ((this.TaxIDNumber == null && other.TaxIDNumber == null) || (this.TaxIDNumber?.Equals(other.TaxIDNumber) == true));
        }
        

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.BirthDate = {(this.BirthDate == null ? "null" : this.BirthDate == string.Empty ? "" : this.BirthDate)}");
            toStringOutput.Add($"this.IdentificationNumber = {(this.IdentificationNumber == null ? "null" : this.IdentificationNumber == string.Empty ? "" : this.IdentificationNumber)}");
            toStringOutput.Add($"this.IdentificationState = {(this.IdentificationState == null ? "null" : this.IdentificationState == string.Empty ? "" : this.IdentificationState)}");
            toStringOutput.Add($"this.TaxIDNumber = {(this.TaxIDNumber == null ? "null" : this.TaxIDNumber == string.Empty ? "" : this.TaxIDNumber)}");
        }
    }
}