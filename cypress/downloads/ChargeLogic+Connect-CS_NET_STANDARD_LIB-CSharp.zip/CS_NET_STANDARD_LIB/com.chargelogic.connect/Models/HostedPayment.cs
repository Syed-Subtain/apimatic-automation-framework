// <copyright file="HostedPayment.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace com.chargelogic.connect.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using com.chargelogic.connect;
    using com.chargelogic.connect.Utilities;

    /// <summary>
    /// HostedPayment.
    /// </summary>
    public class HostedPayment
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="HostedPayment"/> class.
        /// </summary>
        public HostedPayment()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="HostedPayment"/> class.
        /// </summary>
        /// <param name="requireCVV">RequireCVV.</param>
        /// <param name="returnURL">ReturnURL.</param>
        /// <param name="confirmationID">ConfirmationID.</param>
        /// <param name="callbackURL">CallbackURL.</param>
        /// <param name="language">Language.</param>
        /// <param name="logoURL">LogoURL.</param>
        /// <param name="shippingAgent">ShippingAgent.</param>
        /// <param name="shippingAgentDescription">ShippingAgentDescription.</param>
        /// <param name="shippingAgentService">ShippingAgentService.</param>
        /// <param name="shippingAgentServiceDescription">ShippingAgentServiceDescription.</param>
        /// <param name="pageBackgroundColor">PageBackgroundColor.</param>
        /// <param name="buttonBackgroundColor">ButtonBackgroundColor.</param>
        /// <param name="headerFontColor">HeaderFontColor.</param>
        /// <param name="fieldLabelFontColor">FieldLabelFontColor.</param>
        /// <param name="borderColor">BorderColor.</param>
        /// <param name="errorColor">ErrorColor.</param>
        /// <param name="embedded">Embedded.</param>
        /// <param name="requireFinalize">RequireFinalize.</param>
        /// <param name="merchantResourceURL">MerchantResourceURL.</param>
        /// <param name="salesperson">Salesperson.</param>
        /// <param name="webPaymentGateway">WebPaymentGateway.</param>
        /// <param name="webPaymentTransactionID">WebPaymentTransactionID.</param>
        /// <param name="webPaymentAmount">WebPaymentAmount.</param>
        /// <param name="extraDataField">ExtraDataField.</param>
        /// <param name="comment">Comment.</param>
        public HostedPayment(
            string requireCVV,
            string returnURL,
            Guid confirmationID,
            string callbackURL = null,
            string language = null,
            string logoURL = null,
            string shippingAgent = null,
            string shippingAgentDescription = null,
            string shippingAgentService = null,
            string shippingAgentServiceDescription = null,
            string pageBackgroundColor = null,
            string buttonBackgroundColor = null,
            string headerFontColor = null,
            string fieldLabelFontColor = null,
            string borderColor = null,
            string errorColor = null,
            string embedded = null,
            string requireFinalize = null,
            string merchantResourceURL = null,
            string salesperson = null,
            string webPaymentGateway = null,
            string webPaymentTransactionID = null,
            string webPaymentAmount = null,
            List<Models.ExtraData> extraDataField = null,
            List<Models.Comment> comment = null)
        {
            this.RequireCVV = requireCVV;
            this.ReturnURL = returnURL;
            this.ConfirmationID = confirmationID;
            this.CallbackURL = callbackURL;
            this.Language = language;
            this.LogoURL = logoURL;
            this.ShippingAgent = shippingAgent;
            this.ShippingAgentDescription = shippingAgentDescription;
            this.ShippingAgentService = shippingAgentService;
            this.ShippingAgentServiceDescription = shippingAgentServiceDescription;
            this.PageBackgroundColor = pageBackgroundColor;
            this.ButtonBackgroundColor = buttonBackgroundColor;
            this.HeaderFontColor = headerFontColor;
            this.FieldLabelFontColor = fieldLabelFontColor;
            this.BorderColor = borderColor;
            this.ErrorColor = errorColor;
            this.Embedded = embedded;
            this.RequireFinalize = requireFinalize;
            this.MerchantResourceURL = merchantResourceURL;
            this.Salesperson = salesperson;
            this.WebPaymentGateway = webPaymentGateway;
            this.WebPaymentTransactionID = webPaymentTransactionID;
            this.WebPaymentAmount = webPaymentAmount;
            this.ExtraDataField = extraDataField;
            this.Comment = comment;
        }

        /// <summary>
        /// Indicates whether the hosted payment window should require that the cardholder enter the Card Verification Value; must be “Yes” or “No”
        /// </summary>
        [JsonProperty("RequireCVV")]
        public string RequireCVV { get; set; }

        /// <summary>
        /// The URL to which the cardholder should be redirected after the hosted payment has been completed or aborted. The format is ReturnURL?HostedPaymentID=HostedPaymentID&ConfirmationID=ConfirmationID&Action=Approve&MaskedAccountNumber=MaskedAccountNumber&Token=Token&ExpirationMonth=ExpirationMonth&ExpirationYear=ExpirationYear&AccountType=AccountType, where HostedPaymentID is the Hosted Payment ID passed into the hosted payment page, ConfirmationID is the Confirmation ID passed into the transaction setup method, MaskedAccountNumber is a masked version of the account number used for payment, Token is a 32 character alphanumeric token, ExpirationMonth is a two digit expiration month, ExpirationYear is a two digit expiration year, and AccountType is an account type (e.g., Visa, MasterCard, etc.). The Confirmation ID serves as verification that the transaction was truly approved, as only the merchant’s application and ChargeLogic Connect know the value. NOTE: When providing a CallbackURL, the parameters returned to the ReturnURL will be limited to HostedPaymentID and ConfirmationID. The maximum length is 100.
        /// </summary>
        [JsonProperty("ReturnURL")]
        public string ReturnURL { get; set; }

        /// <summary>
        /// The unique value generated by the merchant’s application that represents this hosted payment; will be returned to the merchant’s application upon completion of the payment
        /// </summary>
        [JsonProperty("ConfirmationID")]
        public Guid ConfirmationID { get; set; }

        /// <summary>
        /// Specify a URL for the ChargeLogic Connect server to send a GET request to when the payment has been approved. The format will be CallbackURL?HostedPaymentID=HostedPaymentID&ConfirmationID=ConfirmationID&Action=Approve&MaskedAccountNumber=MaskedAccountNumber&Token=Token&ExpirationMonth=ExpirationMonth&ExpirationYear=ExpirationYear&AccountType=AccountType, where HostedPaymentID is the Hosted Payment ID passed into the hosted payment page, ConfirmationID is the Confirmation ID passed into the transaction setup method, MaskedAccountNumber is a masked version of the account number used for payment, Token is a 32 character alphanumeric token, ExpirationMonth is a two digit expiration month, ExpirationYear is a two digit expiration year, and AccountType is an account type (e.g., Visa, MasterCard, etc.). The Confirmation ID serves as verification that the transaction was truly approved, as only the merchant’s application and ChargeLogic Connect know the value. The maximum length is 100.
        /// </summary>
        [JsonProperty("CallbackURL", NullValueHandling = NullValueHandling.Ignore)]
        public string CallbackURL { get; set; }

        /// <summary>
        /// The three-character alphabetic ISO cardholder language code
        /// </summary>
        [JsonProperty("Language", NullValueHandling = NullValueHandling.Ignore)]
        public string Language { get; set; }

        /// <summary>
        /// The URL of the merchant’s logo image to be displayed on the hosted payment page. The maximum length is 100.
        /// </summary>
        [JsonProperty("LogoURL", NullValueHandling = NullValueHandling.Ignore)]
        public string LogoURL { get; set; }

        /// <summary>
        /// The Shipping Agent Code that matches the Shipping Agent Code in the ERP system. The maximum length is 10.
        /// </summary>
        [JsonProperty("ShippingAgent", NullValueHandling = NullValueHandling.Ignore)]
        public string ShippingAgent { get; set; }

        /// <summary>
        /// The shipping agent description to be displayed on the web order confirmation for Hosted Orders. The maximum length is 50.
        /// </summary>
        [JsonProperty("ShippingAgentDescription", NullValueHandling = NullValueHandling.Ignore)]
        public string ShippingAgentDescription { get; set; }

        /// <summary>
        /// The Shipping Agent Service Code that matches the Code from the ERP system. The maximum length is 10.
        /// </summary>
        [JsonProperty("ShippingAgentService", NullValueHandling = NullValueHandling.Ignore)]
        public string ShippingAgentService { get; set; }

        /// <summary>
        /// The shipping agent service description to be displayed on the web order confirmation for Hosted Orders. The maximum length is 50.
        /// </summary>
        [JsonProperty("ShippingAgentServiceDescription", NullValueHandling = NullValueHandling.Ignore)]
        public string ShippingAgentServiceDescription { get; set; }

        /// <summary>
        /// The hex code for the hosted payment frame’s background color; has no effect if Embedded=No
        /// </summary>
        [JsonProperty("PageBackgroundColor", NullValueHandling = NullValueHandling.Ignore)]
        public string PageBackgroundColor { get; set; }

        /// <summary>
        /// The hex code for the hosted payment page’s buttons; has no effect if Embedded=Yes
        /// </summary>
        [JsonProperty("ButtonBackgroundColor", NullValueHandling = NullValueHandling.Ignore)]
        public string ButtonBackgroundColor { get; set; }

        /// <summary>
        /// The hex code for the header text on the hosted payment page; has no effect if Embedded=Yes
        /// </summary>
        [JsonProperty("HeaderFontColor", NullValueHandling = NullValueHandling.Ignore)]
        public string HeaderFontColor { get; set; }

        /// <summary>
        /// The hex code for the field labels on the hosted payment frame; has no effect if Embedded=No
        /// </summary>
        [JsonProperty("FieldLabelFontColor", NullValueHandling = NullValueHandling.Ignore)]
        public string FieldLabelFontColor { get; set; }

        /// <summary>
        /// The hex code for the borders on the hosted payment page; has no effect if Embedded=Yes
        /// </summary>
        [JsonProperty("BorderColor", NullValueHandling = NullValueHandling.Ignore)]
        public string BorderColor { get; set; }

        /// <summary>
        /// The hex color for errors displayed on the hosted payment page; has no effect if Embedded=Yes
        /// </summary>
        [JsonProperty("ErrorColor", NullValueHandling = NullValueHandling.Ignore)]
        public string ErrorColor { get; set; }

        /// <summary>
        /// Indicated whether ChargeLogic Connect should display the hosted payment frame; must be “Yes” or “No”
        /// </summary>
        [JsonProperty("Embedded", NullValueHandling = NullValueHandling.Ignore)]
        public string Embedded { get; set; }

        /// <summary>
        /// When a Hosted Payment Page or Hosted Payment Window transaction is approved, the system will normally finalize the Hosted Order, marking it ready for import. If you do not want the system to finalize the order automatically, set this value to "Yes". Valid values are "Yes" and "No".
        /// </summary>
        [JsonProperty("RequireFinalize", NullValueHandling = NullValueHandling.Ignore)]
        public string RequireFinalize { get; set; }

        /// <summary>
        /// The URL of the ChargeLogic Connect Merchant Resource file; must be in the same domain as the embedded frame’s parent. The maximum length is 100.
        /// </summary>
        [JsonProperty("MerchantResourceURL", NullValueHandling = NullValueHandling.Ignore)]
        public string MerchantResourceURL { get; set; }

        /// <summary>
        /// The name of the salesperson to be displayed on a web invoice. The maximum length is 50.
        /// </summary>
        [JsonProperty("Salesperson", NullValueHandling = NullValueHandling.Ignore)]
        public string Salesperson { get; set; }

        /// <summary>
        /// If the customer paid via a web payment method like PayPal, you can specify the ChargeLogic Payments Gateway No. of the web payment type.
        /// </summary>
        [JsonProperty("WebPaymentGateway", NullValueHandling = NullValueHandling.Ignore)]
        public string WebPaymentGateway { get; set; }

        /// <summary>
        /// The web payment transaction ID, if the customer paid via a web payment method like PayPal.
        /// </summary>
        [JsonProperty("WebPaymentTransactionID", NullValueHandling = NullValueHandling.Ignore)]
        public string WebPaymentTransactionID { get; set; }

        /// <summary>
        /// The amount of the web payment transaction that occurred via a web payment method like PayPal.
        /// </summary>
        [JsonProperty("WebPaymentAmount", NullValueHandling = NullValueHandling.Ignore)]
        public string WebPaymentAmount { get; set; }

        /// <summary>
        /// An array of class ExtraDataField to be passed to the ERP system for populating Sales Header fields
        /// </summary>
        [JsonProperty("ExtraDataField", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.ExtraData> ExtraDataField { get; set; }

        /// <summary>
        /// A Comment object
        /// </summary>
        [JsonProperty("Comment", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.Comment> Comment { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"HostedPayment : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is HostedPayment other &&
                ((this.RequireCVV == null && other.RequireCVV == null) || (this.RequireCVV?.Equals(other.RequireCVV) == true)) &&
                ((this.ReturnURL == null && other.ReturnURL == null) || (this.ReturnURL?.Equals(other.ReturnURL) == true)) &&
                this.ConfirmationID.Equals(other.ConfirmationID) &&
                ((this.CallbackURL == null && other.CallbackURL == null) || (this.CallbackURL?.Equals(other.CallbackURL) == true)) &&
                ((this.Language == null && other.Language == null) || (this.Language?.Equals(other.Language) == true)) &&
                ((this.LogoURL == null && other.LogoURL == null) || (this.LogoURL?.Equals(other.LogoURL) == true)) &&
                ((this.ShippingAgent == null && other.ShippingAgent == null) || (this.ShippingAgent?.Equals(other.ShippingAgent) == true)) &&
                ((this.ShippingAgentDescription == null && other.ShippingAgentDescription == null) || (this.ShippingAgentDescription?.Equals(other.ShippingAgentDescription) == true)) &&
                ((this.ShippingAgentService == null && other.ShippingAgentService == null) || (this.ShippingAgentService?.Equals(other.ShippingAgentService) == true)) &&
                ((this.ShippingAgentServiceDescription == null && other.ShippingAgentServiceDescription == null) || (this.ShippingAgentServiceDescription?.Equals(other.ShippingAgentServiceDescription) == true)) &&
                ((this.PageBackgroundColor == null && other.PageBackgroundColor == null) || (this.PageBackgroundColor?.Equals(other.PageBackgroundColor) == true)) &&
                ((this.ButtonBackgroundColor == null && other.ButtonBackgroundColor == null) || (this.ButtonBackgroundColor?.Equals(other.ButtonBackgroundColor) == true)) &&
                ((this.HeaderFontColor == null && other.HeaderFontColor == null) || (this.HeaderFontColor?.Equals(other.HeaderFontColor) == true)) &&
                ((this.FieldLabelFontColor == null && other.FieldLabelFontColor == null) || (this.FieldLabelFontColor?.Equals(other.FieldLabelFontColor) == true)) &&
                ((this.BorderColor == null && other.BorderColor == null) || (this.BorderColor?.Equals(other.BorderColor) == true)) &&
                ((this.ErrorColor == null && other.ErrorColor == null) || (this.ErrorColor?.Equals(other.ErrorColor) == true)) &&
                ((this.Embedded == null && other.Embedded == null) || (this.Embedded?.Equals(other.Embedded) == true)) &&
                ((this.RequireFinalize == null && other.RequireFinalize == null) || (this.RequireFinalize?.Equals(other.RequireFinalize) == true)) &&
                ((this.MerchantResourceURL == null && other.MerchantResourceURL == null) || (this.MerchantResourceURL?.Equals(other.MerchantResourceURL) == true)) &&
                ((this.Salesperson == null && other.Salesperson == null) || (this.Salesperson?.Equals(other.Salesperson) == true)) &&
                ((this.WebPaymentGateway == null && other.WebPaymentGateway == null) || (this.WebPaymentGateway?.Equals(other.WebPaymentGateway) == true)) &&
                ((this.WebPaymentTransactionID == null && other.WebPaymentTransactionID == null) || (this.WebPaymentTransactionID?.Equals(other.WebPaymentTransactionID) == true)) &&
                ((this.WebPaymentAmount == null && other.WebPaymentAmount == null) || (this.WebPaymentAmount?.Equals(other.WebPaymentAmount) == true)) &&
                ((this.ExtraDataField == null && other.ExtraDataField == null) || (this.ExtraDataField?.Equals(other.ExtraDataField) == true)) &&
                ((this.Comment == null && other.Comment == null) || (this.Comment?.Equals(other.Comment) == true));
        }
        

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.RequireCVV = {(this.RequireCVV == null ? "null" : this.RequireCVV == string.Empty ? "" : this.RequireCVV)}");
            toStringOutput.Add($"this.ReturnURL = {(this.ReturnURL == null ? "null" : this.ReturnURL == string.Empty ? "" : this.ReturnURL)}");
            toStringOutput.Add($"this.ConfirmationID = {this.ConfirmationID}");
            toStringOutput.Add($"this.CallbackURL = {(this.CallbackURL == null ? "null" : this.CallbackURL == string.Empty ? "" : this.CallbackURL)}");
            toStringOutput.Add($"this.Language = {(this.Language == null ? "null" : this.Language == string.Empty ? "" : this.Language)}");
            toStringOutput.Add($"this.LogoURL = {(this.LogoURL == null ? "null" : this.LogoURL == string.Empty ? "" : this.LogoURL)}");
            toStringOutput.Add($"this.ShippingAgent = {(this.ShippingAgent == null ? "null" : this.ShippingAgent == string.Empty ? "" : this.ShippingAgent)}");
            toStringOutput.Add($"this.ShippingAgentDescription = {(this.ShippingAgentDescription == null ? "null" : this.ShippingAgentDescription == string.Empty ? "" : this.ShippingAgentDescription)}");
            toStringOutput.Add($"this.ShippingAgentService = {(this.ShippingAgentService == null ? "null" : this.ShippingAgentService == string.Empty ? "" : this.ShippingAgentService)}");
            toStringOutput.Add($"this.ShippingAgentServiceDescription = {(this.ShippingAgentServiceDescription == null ? "null" : this.ShippingAgentServiceDescription == string.Empty ? "" : this.ShippingAgentServiceDescription)}");
            toStringOutput.Add($"this.PageBackgroundColor = {(this.PageBackgroundColor == null ? "null" : this.PageBackgroundColor == string.Empty ? "" : this.PageBackgroundColor)}");
            toStringOutput.Add($"this.ButtonBackgroundColor = {(this.ButtonBackgroundColor == null ? "null" : this.ButtonBackgroundColor == string.Empty ? "" : this.ButtonBackgroundColor)}");
            toStringOutput.Add($"this.HeaderFontColor = {(this.HeaderFontColor == null ? "null" : this.HeaderFontColor == string.Empty ? "" : this.HeaderFontColor)}");
            toStringOutput.Add($"this.FieldLabelFontColor = {(this.FieldLabelFontColor == null ? "null" : this.FieldLabelFontColor == string.Empty ? "" : this.FieldLabelFontColor)}");
            toStringOutput.Add($"this.BorderColor = {(this.BorderColor == null ? "null" : this.BorderColor == string.Empty ? "" : this.BorderColor)}");
            toStringOutput.Add($"this.ErrorColor = {(this.ErrorColor == null ? "null" : this.ErrorColor == string.Empty ? "" : this.ErrorColor)}");
            toStringOutput.Add($"this.Embedded = {(this.Embedded == null ? "null" : this.Embedded == string.Empty ? "" : this.Embedded)}");
            toStringOutput.Add($"this.RequireFinalize = {(this.RequireFinalize == null ? "null" : this.RequireFinalize == string.Empty ? "" : this.RequireFinalize)}");
            toStringOutput.Add($"this.MerchantResourceURL = {(this.MerchantResourceURL == null ? "null" : this.MerchantResourceURL == string.Empty ? "" : this.MerchantResourceURL)}");
            toStringOutput.Add($"this.Salesperson = {(this.Salesperson == null ? "null" : this.Salesperson == string.Empty ? "" : this.Salesperson)}");
            toStringOutput.Add($"this.WebPaymentGateway = {(this.WebPaymentGateway == null ? "null" : this.WebPaymentGateway == string.Empty ? "" : this.WebPaymentGateway)}");
            toStringOutput.Add($"this.WebPaymentTransactionID = {(this.WebPaymentTransactionID == null ? "null" : this.WebPaymentTransactionID == string.Empty ? "" : this.WebPaymentTransactionID)}");
            toStringOutput.Add($"this.WebPaymentAmount = {(this.WebPaymentAmount == null ? "null" : this.WebPaymentAmount == string.Empty ? "" : this.WebPaymentAmount)}");
            toStringOutput.Add($"this.ExtraDataField = {(this.ExtraDataField == null ? "null" : $"[{string.Join(", ", this.ExtraDataField)} ]")}");
            toStringOutput.Add($"this.Comment = {(this.Comment == null ? "null" : $"[{string.Join(", ", this.Comment)} ]")}");
        }
    }
}