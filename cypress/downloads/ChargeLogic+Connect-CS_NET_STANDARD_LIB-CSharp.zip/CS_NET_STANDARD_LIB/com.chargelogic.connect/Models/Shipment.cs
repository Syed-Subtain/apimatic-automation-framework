// <copyright file="Shipment.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace com.chargelogic.connect.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using com.chargelogic.connect;
    using com.chargelogic.connect.Utilities;

    /// <summary>
    /// Shipment.
    /// </summary>
    public class Shipment
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="Shipment"/> class.
        /// </summary>
        public Shipment()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="Shipment"/> class.
        /// </summary>
        /// <param name="shipmentNumber">ShipmentNumber.</param>
        /// <param name="hostedPaymentID">HostedPaymentID.</param>
        /// <param name="shipmentDate">ShipmentDate.</param>
        /// <param name="shippingAgent">ShippingAgent.</param>
        /// <param name="shippingAgentService">ShippingAgentService.</param>
        /// <param name="trackingNumber">TrackingNumber.</param>
        /// <param name="lineItem">LineItem.</param>
        public Shipment(
            string shipmentNumber,
            Guid? hostedPaymentID = null,
            string shipmentDate = null,
            string shippingAgent = null,
            string shippingAgentService = null,
            string trackingNumber = null,
            List<Models.LineItem> lineItem = null)
        {
            this.ShipmentNumber = shipmentNumber;
            this.HostedPaymentID = hostedPaymentID;
            this.ShipmentDate = shipmentDate;
            this.ShippingAgent = shippingAgent;
            this.ShippingAgentService = shippingAgentService;
            this.TrackingNumber = trackingNumber;
            this.LineItem = lineItem;
        }

        /// <summary>
        /// The No. assigned to the shipment
        /// </summary>
        [JsonProperty("ShipmentNumber")]
        public string ShipmentNumber { get; set; }

        /// <summary>
        /// The ID of the Hosted Payment
        /// </summary>
        [JsonProperty("HostedPaymentID", NullValueHandling = NullValueHandling.Ignore)]
        public Guid? HostedPaymentID { get; set; }

        /// <summary>
        /// The posting date of the shipment
        /// </summary>
        [JsonProperty("ShipmentDate", NullValueHandling = NullValueHandling.Ignore)]
        public string ShipmentDate { get; set; }

        /// <summary>
        /// The Shipping Agent Code
        /// </summary>
        [JsonProperty("ShippingAgent", NullValueHandling = NullValueHandling.Ignore)]
        public string ShippingAgent { get; set; }

        /// <summary>
        /// The Shipping Agent Service Code
        /// </summary>
        [JsonProperty("ShippingAgentService", NullValueHandling = NullValueHandling.Ignore)]
        public string ShippingAgentService { get; set; }

        /// <summary>
        /// The package tracking number
        /// </summary>
        [JsonProperty("TrackingNumber", NullValueHandling = NullValueHandling.Ignore)]
        public string TrackingNumber { get; set; }

        /// <summary>
        /// Array of class LineItem representing the shipment details
        /// </summary>
        [JsonProperty("LineItem", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.LineItem> LineItem { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"Shipment : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is Shipment other &&
                ((this.ShipmentNumber == null && other.ShipmentNumber == null) || (this.ShipmentNumber?.Equals(other.ShipmentNumber) == true)) &&
                ((this.HostedPaymentID == null && other.HostedPaymentID == null) || (this.HostedPaymentID?.Equals(other.HostedPaymentID) == true)) &&
                ((this.ShipmentDate == null && other.ShipmentDate == null) || (this.ShipmentDate?.Equals(other.ShipmentDate) == true)) &&
                ((this.ShippingAgent == null && other.ShippingAgent == null) || (this.ShippingAgent?.Equals(other.ShippingAgent) == true)) &&
                ((this.ShippingAgentService == null && other.ShippingAgentService == null) || (this.ShippingAgentService?.Equals(other.ShippingAgentService) == true)) &&
                ((this.TrackingNumber == null && other.TrackingNumber == null) || (this.TrackingNumber?.Equals(other.TrackingNumber) == true)) &&
                ((this.LineItem == null && other.LineItem == null) || (this.LineItem?.Equals(other.LineItem) == true));
        }
        

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.ShipmentNumber = {(this.ShipmentNumber == null ? "null" : this.ShipmentNumber == string.Empty ? "" : this.ShipmentNumber)}");
            toStringOutput.Add($"this.HostedPaymentID = {(this.HostedPaymentID == null ? "null" : this.HostedPaymentID.ToString())}");
            toStringOutput.Add($"this.ShipmentDate = {(this.ShipmentDate == null ? "null" : this.ShipmentDate == string.Empty ? "" : this.ShipmentDate)}");
            toStringOutput.Add($"this.ShippingAgent = {(this.ShippingAgent == null ? "null" : this.ShippingAgent == string.Empty ? "" : this.ShippingAgent)}");
            toStringOutput.Add($"this.ShippingAgentService = {(this.ShippingAgentService == null ? "null" : this.ShippingAgentService == string.Empty ? "" : this.ShippingAgentService)}");
            toStringOutput.Add($"this.TrackingNumber = {(this.TrackingNumber == null ? "null" : this.TrackingNumber == string.Empty ? "" : this.TrackingNumber)}");
            toStringOutput.Add($"this.LineItem = {(this.LineItem == null ? "null" : $"[{string.Join(", ", this.LineItem)} ]")}");
        }
    }
}