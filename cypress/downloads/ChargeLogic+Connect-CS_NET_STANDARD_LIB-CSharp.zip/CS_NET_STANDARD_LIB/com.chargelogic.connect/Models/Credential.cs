// <copyright file="Credential.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace com.chargelogic.connect.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using com.chargelogic.connect;
    using com.chargelogic.connect.Utilities;

    /// <summary>
    /// Credential.
    /// </summary>
    public class Credential
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="Credential"/> class.
        /// </summary>
        public Credential()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="Credential"/> class.
        /// </summary>
        /// <param name="storeNo">StoreNo.</param>
        /// <param name="aPIKey">APIKey.</param>
        /// <param name="applicationNo">ApplicationNo.</param>
        /// <param name="applicationVersion">ApplicationVersion.</param>
        public Credential(
            string storeNo,
            string aPIKey,
            string applicationNo,
            string applicationVersion)
        {
            this.StoreNo = storeNo;
            this.APIKey = aPIKey;
            this.ApplicationNo = applicationNo;
            this.ApplicationVersion = applicationVersion;
        }

        /// <summary>
        /// The merchant’s ChargeLogic Connect-assigned account identifier; must match the HTTP Basic Authentication username
        /// </summary>
        [JsonProperty("StoreNo")]
        public string StoreNo { get; set; }

        /// <summary>
        /// The merchant’s ChargeLogic Connect-assigned account password
        /// </summary>
        [JsonProperty("APIKey")]
        public string APIKey { get; set; }

        /// <summary>
        /// The external application’s ChargeLogic Connect-assigned identifier
        /// </summary>
        [JsonProperty("ApplicationNo")]
        public string ApplicationNo { get; set; }

        /// <summary>
        /// The external application’s version number. This value can be supplied in a format of your choice, but it should change each time you update your ChargeLogic Connect integration.
        /// </summary>
        [JsonProperty("ApplicationVersion")]
        public string ApplicationVersion { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"Credential : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is Credential other &&
                ((this.StoreNo == null && other.StoreNo == null) || (this.StoreNo?.Equals(other.StoreNo) == true)) &&
                ((this.APIKey == null && other.APIKey == null) || (this.APIKey?.Equals(other.APIKey) == true)) &&
                ((this.ApplicationNo == null && other.ApplicationNo == null) || (this.ApplicationNo?.Equals(other.ApplicationNo) == true)) &&
                ((this.ApplicationVersion == null && other.ApplicationVersion == null) || (this.ApplicationVersion?.Equals(other.ApplicationVersion) == true));
        }
        

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.StoreNo = {(this.StoreNo == null ? "null" : this.StoreNo == string.Empty ? "" : this.StoreNo)}");
            toStringOutput.Add($"this.APIKey = {(this.APIKey == null ? "null" : this.APIKey == string.Empty ? "" : this.APIKey)}");
            toStringOutput.Add($"this.ApplicationNo = {(this.ApplicationNo == null ? "null" : this.ApplicationNo == string.Empty ? "" : this.ApplicationNo)}");
            toStringOutput.Add($"this.ApplicationVersion = {(this.ApplicationVersion == null ? "null" : this.ApplicationVersion == string.Empty ? "" : this.ApplicationVersion)}");
        }
    }
}