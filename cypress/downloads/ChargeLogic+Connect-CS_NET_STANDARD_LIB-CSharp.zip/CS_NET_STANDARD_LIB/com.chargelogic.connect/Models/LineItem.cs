// <copyright file="LineItem.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace com.chargelogic.connect.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using com.chargelogic.connect;
    using com.chargelogic.connect.Utilities;

    /// <summary>
    /// LineItem.
    /// </summary>
    public class LineItem
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="LineItem"/> class.
        /// </summary>
        public LineItem()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="LineItem"/> class.
        /// </summary>
        /// <param name="productCode">ProductCode.</param>
        /// <param name="category">Category.</param>
        /// <param name="description">Description.</param>
        /// <param name="quantity">Quantity.</param>
        /// <param name="unitOfMeasure">UnitOfMeasure.</param>
        /// <param name="unitPrice">UnitPrice.</param>
        /// <param name="lineTaxAmount">LineTaxAmount.</param>
        /// <param name="lineDiscountAmount">LineDiscountAmount.</param>
        /// <param name="lineAmount">LineAmount.</param>
        /// <param name="extraData">ExtraData.</param>
        public LineItem(
            string productCode,
            string category,
            string description,
            string quantity,
            string unitOfMeasure,
            string unitPrice,
            string lineTaxAmount,
            string lineDiscountAmount,
            string lineAmount,
            List<Models.ExtraData> extraData = null)
        {
            this.ProductCode = productCode;
            this.Category = category;
            this.Description = description;
            this.Quantity = quantity;
            this.UnitOfMeasure = unitOfMeasure;
            this.UnitPrice = unitPrice;
            this.LineTaxAmount = lineTaxAmount;
            this.LineDiscountAmount = lineDiscountAmount;
            this.LineAmount = lineAmount;
            this.ExtraData = extraData;
        }

        /// <summary>
        /// The Item No. from the ERP system. The maximum length is 20.
        /// </summary>
        [JsonProperty("ProductCode")]
        public string ProductCode { get; set; }

        /// <summary>
        /// The type of LineItem ("Item", "Resource", "G/L Account", etc.). A blank value means Item.
        /// </summary>
        [JsonProperty("Category")]
        public string Category { get; set; }

        /// <summary>
        /// The item’s description. The maximum length is 50.
        /// </summary>
        [JsonProperty("Description")]
        public string Description { get; set; }

        /// <summary>
        /// The line quantity
        /// </summary>
        [JsonProperty("Quantity")]
        public string Quantity { get; set; }

        /// <summary>
        /// The standard unit of measure code
        /// </summary>
        [JsonProperty("UnitOfMeasure")]
        public string UnitOfMeasure { get; set; }

        /// <summary>
        /// The item’s unit price in the Currency Code of the transaction.
        /// </summary>
        [JsonProperty("UnitPrice")]
        public string UnitPrice { get; set; }

        /// <summary>
        /// The tax amount of the line (note that this value can be used for credit card Level 2 data, but it will not be passed to the Order in the ERP system).
        /// </summary>
        [JsonProperty("LineTaxAmount")]
        public string LineTaxAmount { get; set; }

        /// <summary>
        /// The discount amount applied to the line
        /// </summary>
        [JsonProperty("LineDiscountAmount")]
        public string LineDiscountAmount { get; set; }

        /// <summary>
        /// The total line amount, including tax, after any discounts
        /// </summary>
        [JsonProperty("LineAmount")]
        public string LineAmount { get; set; }

        /// <summary>
        /// An array of class ExtraDataField to be passed to the ERP system for populating Sales Line custom fields
        /// </summary>
        [JsonProperty("ExtraData", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.ExtraData> ExtraData { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"LineItem : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is LineItem other &&
                ((this.ProductCode == null && other.ProductCode == null) || (this.ProductCode?.Equals(other.ProductCode) == true)) &&
                ((this.Category == null && other.Category == null) || (this.Category?.Equals(other.Category) == true)) &&
                ((this.Description == null && other.Description == null) || (this.Description?.Equals(other.Description) == true)) &&
                ((this.Quantity == null && other.Quantity == null) || (this.Quantity?.Equals(other.Quantity) == true)) &&
                ((this.UnitOfMeasure == null && other.UnitOfMeasure == null) || (this.UnitOfMeasure?.Equals(other.UnitOfMeasure) == true)) &&
                ((this.UnitPrice == null && other.UnitPrice == null) || (this.UnitPrice?.Equals(other.UnitPrice) == true)) &&
                ((this.LineTaxAmount == null && other.LineTaxAmount == null) || (this.LineTaxAmount?.Equals(other.LineTaxAmount) == true)) &&
                ((this.LineDiscountAmount == null && other.LineDiscountAmount == null) || (this.LineDiscountAmount?.Equals(other.LineDiscountAmount) == true)) &&
                ((this.LineAmount == null && other.LineAmount == null) || (this.LineAmount?.Equals(other.LineAmount) == true)) &&
                ((this.ExtraData == null && other.ExtraData == null) || (this.ExtraData?.Equals(other.ExtraData) == true));
        }
        

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.ProductCode = {(this.ProductCode == null ? "null" : this.ProductCode == string.Empty ? "" : this.ProductCode)}");
            toStringOutput.Add($"this.Category = {(this.Category == null ? "null" : this.Category == string.Empty ? "" : this.Category)}");
            toStringOutput.Add($"this.Description = {(this.Description == null ? "null" : this.Description == string.Empty ? "" : this.Description)}");
            toStringOutput.Add($"this.Quantity = {(this.Quantity == null ? "null" : this.Quantity == string.Empty ? "" : this.Quantity)}");
            toStringOutput.Add($"this.UnitOfMeasure = {(this.UnitOfMeasure == null ? "null" : this.UnitOfMeasure == string.Empty ? "" : this.UnitOfMeasure)}");
            toStringOutput.Add($"this.UnitPrice = {(this.UnitPrice == null ? "null" : this.UnitPrice == string.Empty ? "" : this.UnitPrice)}");
            toStringOutput.Add($"this.LineTaxAmount = {(this.LineTaxAmount == null ? "null" : this.LineTaxAmount == string.Empty ? "" : this.LineTaxAmount)}");
            toStringOutput.Add($"this.LineDiscountAmount = {(this.LineDiscountAmount == null ? "null" : this.LineDiscountAmount == string.Empty ? "" : this.LineDiscountAmount)}");
            toStringOutput.Add($"this.LineAmount = {(this.LineAmount == null ? "null" : this.LineAmount == string.Empty ? "" : this.LineAmount)}");
            toStringOutput.Add($"this.ExtraData = {(this.ExtraData == null ? "null" : $"[{string.Join(", ", this.ExtraData)} ]")}");
        }
    }
}