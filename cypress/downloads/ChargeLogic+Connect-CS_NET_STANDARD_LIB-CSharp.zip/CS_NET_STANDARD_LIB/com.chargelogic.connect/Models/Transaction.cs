// <copyright file="Transaction.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace com.chargelogic.connect.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using com.chargelogic.connect;
    using com.chargelogic.connect.Utilities;

    /// <summary>
    /// Transaction.
    /// </summary>
    public class Transaction
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="Transaction"/> class.
        /// </summary>
        public Transaction()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="Transaction"/> class.
        /// </summary>
        /// <param name="amount">Amount.</param>
        /// <param name="externalReferenceNumber">ExternalReferenceNumber.</param>
        /// <param name="currency">Currency.</param>
        /// <param name="confirmationID">ConfirmationID.</param>
        /// <param name="freightAmount">FreightAmount.</param>
        /// <param name="taxAmount">TaxAmount.</param>
        /// <param name="purchaseOrderNumber">PurchaseOrderNumber.</param>
        /// <param name="purchaseOrderDate">PurchaseOrderDate.</param>
        /// <param name="lineItem">LineItem.</param>
        public Transaction(
            string amount,
            string externalReferenceNumber,
            string currency,
            Guid confirmationID,
            string freightAmount = null,
            string taxAmount = null,
            string purchaseOrderNumber = null,
            string purchaseOrderDate = null,
            List<Models.LineItem> lineItem = null)
        {
            this.Amount = amount;
            this.ExternalReferenceNumber = externalReferenceNumber;
            this.Currency = currency;
            this.FreightAmount = freightAmount;
            this.TaxAmount = taxAmount;
            this.PurchaseOrderNumber = purchaseOrderNumber;
            this.PurchaseOrderDate = purchaseOrderDate;
            this.ConfirmationID = confirmationID;
            this.LineItem = lineItem;
        }

        /// <summary>
        /// The transaction amount. For AddressVerify transactions, this value must be 0. For all other transactions, this value must be positive.
        /// </summary>
        [JsonProperty("Amount")]
        public string Amount { get; set; }

        /// <summary>
        /// A reference number representing the merchant’s application order number. This value will be used by ChargeLogic Payments to retrieve the transaction later, so this value must be unique per order. You can supply the same ExternalReferenceNumber for transactions that are part of the same order and should be retrieved together. The maximum length is 20.
        /// </summary>
        [JsonProperty("ExternalReferenceNumber")]
        public string ExternalReferenceNumber { get; set; }

        /// <summary>
        /// The 3-character alphabetic ISO currency code
        /// </summary>
        [JsonProperty("Currency")]
        public string Currency { get; set; }

        /// <summary>
        /// The portion of Amount that represents freight charges
        /// </summary>
        [JsonProperty("FreightAmount", NullValueHandling = NullValueHandling.Ignore)]
        public string FreightAmount { get; set; }

        /// <summary>
        /// The portion of Amount that represents tax
        /// </summary>
        [JsonProperty("TaxAmount", NullValueHandling = NullValueHandling.Ignore)]
        public string TaxAmount { get; set; }

        /// <summary>
        /// The customer’s purchase order number. The maximum length is 20.
        /// </summary>
        [JsonProperty("PurchaseOrderNumber", NullValueHandling = NullValueHandling.Ignore)]
        public string PurchaseOrderNumber { get; set; }

        /// <summary>
        /// The customer’s purchase order date in MM/DD/YYYY format.
        /// </summary>
        [JsonProperty("PurchaseOrderDate", NullValueHandling = NullValueHandling.Ignore)]
        public string PurchaseOrderDate { get; set; }

        /// <summary>
        /// A unique value representing this transaction
        /// </summary>
        [JsonProperty("ConfirmationID")]
        public Guid ConfirmationID { get; set; }

        /// <summary>
        /// Array of class LineItem representing the order details
        /// </summary>
        [JsonProperty("LineItem", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.LineItem> LineItem { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"Transaction : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is Transaction other &&
                ((this.Amount == null && other.Amount == null) || (this.Amount?.Equals(other.Amount) == true)) &&
                ((this.ExternalReferenceNumber == null && other.ExternalReferenceNumber == null) || (this.ExternalReferenceNumber?.Equals(other.ExternalReferenceNumber) == true)) &&
                ((this.Currency == null && other.Currency == null) || (this.Currency?.Equals(other.Currency) == true)) &&
                ((this.FreightAmount == null && other.FreightAmount == null) || (this.FreightAmount?.Equals(other.FreightAmount) == true)) &&
                ((this.TaxAmount == null && other.TaxAmount == null) || (this.TaxAmount?.Equals(other.TaxAmount) == true)) &&
                ((this.PurchaseOrderNumber == null && other.PurchaseOrderNumber == null) || (this.PurchaseOrderNumber?.Equals(other.PurchaseOrderNumber) == true)) &&
                ((this.PurchaseOrderDate == null && other.PurchaseOrderDate == null) || (this.PurchaseOrderDate?.Equals(other.PurchaseOrderDate) == true)) &&
                this.ConfirmationID.Equals(other.ConfirmationID) &&
                ((this.LineItem == null && other.LineItem == null) || (this.LineItem?.Equals(other.LineItem) == true));
        }
        

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.Amount = {(this.Amount == null ? "null" : this.Amount == string.Empty ? "" : this.Amount)}");
            toStringOutput.Add($"this.ExternalReferenceNumber = {(this.ExternalReferenceNumber == null ? "null" : this.ExternalReferenceNumber == string.Empty ? "" : this.ExternalReferenceNumber)}");
            toStringOutput.Add($"this.Currency = {(this.Currency == null ? "null" : this.Currency == string.Empty ? "" : this.Currency)}");
            toStringOutput.Add($"this.FreightAmount = {(this.FreightAmount == null ? "null" : this.FreightAmount == string.Empty ? "" : this.FreightAmount)}");
            toStringOutput.Add($"this.TaxAmount = {(this.TaxAmount == null ? "null" : this.TaxAmount == string.Empty ? "" : this.TaxAmount)}");
            toStringOutput.Add($"this.PurchaseOrderNumber = {(this.PurchaseOrderNumber == null ? "null" : this.PurchaseOrderNumber == string.Empty ? "" : this.PurchaseOrderNumber)}");
            toStringOutput.Add($"this.PurchaseOrderDate = {(this.PurchaseOrderDate == null ? "null" : this.PurchaseOrderDate == string.Empty ? "" : this.PurchaseOrderDate)}");
            toStringOutput.Add($"this.ConfirmationID = {this.ConfirmationID}");
            toStringOutput.Add($"this.LineItem = {(this.LineItem == null ? "null" : $"[{string.Join(", ", this.LineItem)} ]")}");
        }
    }
}