// <copyright file="ResponseModel.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace com.chargelogic.connect.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using com.chargelogic.connect;
    using com.chargelogic.connect.Utilities;

    /// <summary>
    /// ResponseModel.
    /// </summary>
    public class ResponseModel
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ResponseModel"/> class.
        /// </summary>
        public ResponseModel()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ResponseModel"/> class.
        /// </summary>
        /// <param name="success">Success.</param>
        /// <param name="responseCode">ResponseCode.</param>
        /// <param name="hostResponseCode">HostResponseCode.</param>
        /// <param name="message">Message.</param>
        /// <param name="approvalNumber">ApprovalNumber.</param>
        /// <param name="approvedAmount">ApprovedAmount.</param>
        /// <param name="balanceAmount">BalanceAmount.</param>
        /// <param name="transactionDate">TransactionDate.</param>
        /// <param name="transactionTime">TransactionTime.</param>
        /// <param name="transactionStatus">TransactionStatus.</param>
        /// <param name="addressVerificationAlert">AddressVerificationAlert.</param>
        /// <param name="cardVerificationValueAlert">CardVerificationValueAlert.</param>
        /// <param name="maskedAccountNumber">MaskedAccountNumber.</param>
        /// <param name="token">Token.</param>
        /// <param name="returnValue">return_value.</param>
        /// <param name="errorMessage">ErrorMessage.</param>
        public ResponseModel(
            bool success,
            string responseCode = "000",
            string hostResponseCode = "00",
            string message = "APPROVED",
            string approvalNumber = "123",
            string approvedAmount = "1.00",
            string balanceAmount = "0.00",
            string transactionDate = "12/31/2020",
            string transactionTime = "11:23:54 PM",
            string transactionStatus = "Approved",
            string addressVerificationAlert = "Mismatch",
            string cardVerificationValueAlert = "Mismatch",
            string maskedAccountNumber = "XXXXXXXXXXXXXX1234",
            string token = "ABCDEFA7998CF6914272A14D64B6",
            string returnValue = "99900000001",
            string errorMessage = "Error")
        {
            this.ResponseCode = responseCode;
            this.HostResponseCode = hostResponseCode;
            this.Message = message;
            this.ApprovalNumber = approvalNumber;
            this.ApprovedAmount = approvedAmount;
            this.BalanceAmount = balanceAmount;
            this.TransactionDate = transactionDate;
            this.TransactionTime = transactionTime;
            this.TransactionStatus = transactionStatus;
            this.AddressVerificationAlert = addressVerificationAlert;
            this.CardVerificationValueAlert = cardVerificationValueAlert;
            this.MaskedAccountNumber = maskedAccountNumber;
            this.Token = token;
            this.ReturnValue = returnValue;
            this.Success = success;
            this.ErrorMessage = errorMessage;
        }

        /// <summary>
        /// The value that represents the outcome of the transaction
        /// </summary>
        [JsonProperty("ResponseCode", NullValueHandling = NullValueHandling.Ignore)]
        public string ResponseCode { get; set; }

        /// <summary>
        /// The value that represents the outcome of the transaction; passed through from the payment platform
        /// </summary>
        [JsonProperty("HostResponseCode", NullValueHandling = NullValueHandling.Ignore)]
        public string HostResponseCode { get; set; }

        /// <summary>
        /// The human-readable transaction results. This message should not be displayed to the cardholder.
        /// </summary>
        [JsonProperty("Message", NullValueHandling = NullValueHandling.Ignore)]
        public string Message { get; set; }

        /// <summary>
        /// The transaction’s approval number
        /// </summary>
        [JsonProperty("ApprovalNumber", NullValueHandling = NullValueHandling.Ignore)]
        public string ApprovalNumber { get; set; }

        /// <summary>
        /// The amount that was approved; in the case of a partial approval, this may be less than the Transaction Amount.
        /// </summary>
        [JsonProperty("ApprovedAmount", NullValueHandling = NullValueHandling.Ignore)]
        public string ApprovedAmount { get; set; }

        /// <summary>
        /// The balance amount for prepaid accounts or gift cards
        /// </summary>
        [JsonProperty("BalanceAmount", NullValueHandling = NullValueHandling.Ignore)]
        public string BalanceAmount { get; set; }

        /// <summary>
        /// The date on which the transaction was processed in MM/DD/YY format
        /// </summary>
        [JsonProperty("TransactionDate", NullValueHandling = NullValueHandling.Ignore)]
        public string TransactionDate { get; set; }

        /// <summary>
        /// The time at which the transaction was processed in HH:MM:SS XM format
        /// </summary>
        [JsonProperty("TransactionTime", NullValueHandling = NullValueHandling.Ignore)]
        public string TransactionTime { get; set; }

        /// <summary>
        /// The outcome of the transaction; must be one of “Batched”, ”Hold”, “Approved”, “Used”, “Declined”, “Void”, “Duplicate”, “Failed”, “Error”, “Referred”; Read the value of this field to determine how to handle the transaction response in your application. A TransactonStatus of "Approved" means that the transaction was successful.
        /// </summary>
        [JsonProperty("TransactionStatus", NullValueHandling = NullValueHandling.Ignore)]
        public string TransactionStatus { get; set; }

        /// <summary>
        /// An indicator to determine if an AVS Fraud Protection rule was violated (" ", "Mismatch", "Partial Match", "Unknown")
        /// </summary>
        [JsonProperty("AddressVerificationAlert", NullValueHandling = NullValueHandling.Ignore)]
        public string AddressVerificationAlert { get; set; }

        /// <summary>
        /// An indicator to determine if a CVV Fraud Protection rule was violated ("", "Mismatch", "Unknown")
        /// </summary>
        [JsonProperty("CardVerificationValueAlert", NullValueHandling = NullValueHandling.Ignore)]
        public string CardVerificationValueAlert { get; set; }

        /// <summary>
        /// The AccountNumber, masked with “X” characters, except for the last four digits
        /// </summary>
        [JsonProperty("MaskedAccountNumber", NullValueHandling = NullValueHandling.Ignore)]
        public string MaskedAccountNumber { get; set; }

        /// <summary>
        /// The ChargeLogic Connect-generated Secure Remote Storage token that represents the AccountNumber; can be used for future transactions
        /// </summary>
        [JsonProperty("Token", NullValueHandling = NullValueHandling.Ignore)]
        public string Token { get; set; }

        /// <summary>
        /// The transaction Reference Number
        /// </summary>
        [JsonProperty("return_value", NullValueHandling = NullValueHandling.Ignore)]
        public string ReturnValue { get; set; }

        /// <summary>
        /// False, if an exception was raised. Otherwise, true. A value of true does not mean that the transaction was approved - it only means that an exception was not raised. If Success is true, check the Transaction Status for a value of Approved.
        /// </summary>
        [JsonProperty("Success")]
        public bool Success { get; set; }

        /// <summary>
        /// Exception information
        /// </summary>
        [JsonProperty("ErrorMessage", NullValueHandling = NullValueHandling.Ignore)]
        public string ErrorMessage { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"ResponseModel : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is ResponseModel other &&
                ((this.ResponseCode == null && other.ResponseCode == null) || (this.ResponseCode?.Equals(other.ResponseCode) == true)) &&
                ((this.HostResponseCode == null && other.HostResponseCode == null) || (this.HostResponseCode?.Equals(other.HostResponseCode) == true)) &&
                ((this.Message == null && other.Message == null) || (this.Message?.Equals(other.Message) == true)) &&
                ((this.ApprovalNumber == null && other.ApprovalNumber == null) || (this.ApprovalNumber?.Equals(other.ApprovalNumber) == true)) &&
                ((this.ApprovedAmount == null && other.ApprovedAmount == null) || (this.ApprovedAmount?.Equals(other.ApprovedAmount) == true)) &&
                ((this.BalanceAmount == null && other.BalanceAmount == null) || (this.BalanceAmount?.Equals(other.BalanceAmount) == true)) &&
                ((this.TransactionDate == null && other.TransactionDate == null) || (this.TransactionDate?.Equals(other.TransactionDate) == true)) &&
                ((this.TransactionTime == null && other.TransactionTime == null) || (this.TransactionTime?.Equals(other.TransactionTime) == true)) &&
                ((this.TransactionStatus == null && other.TransactionStatus == null) || (this.TransactionStatus?.Equals(other.TransactionStatus) == true)) &&
                ((this.AddressVerificationAlert == null && other.AddressVerificationAlert == null) || (this.AddressVerificationAlert?.Equals(other.AddressVerificationAlert) == true)) &&
                ((this.CardVerificationValueAlert == null && other.CardVerificationValueAlert == null) || (this.CardVerificationValueAlert?.Equals(other.CardVerificationValueAlert) == true)) &&
                ((this.MaskedAccountNumber == null && other.MaskedAccountNumber == null) || (this.MaskedAccountNumber?.Equals(other.MaskedAccountNumber) == true)) &&
                ((this.Token == null && other.Token == null) || (this.Token?.Equals(other.Token) == true)) &&
                ((this.ReturnValue == null && other.ReturnValue == null) || (this.ReturnValue?.Equals(other.ReturnValue) == true)) &&
                this.Success.Equals(other.Success) &&
                ((this.ErrorMessage == null && other.ErrorMessage == null) || (this.ErrorMessage?.Equals(other.ErrorMessage) == true));
        }
        

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.ResponseCode = {(this.ResponseCode == null ? "null" : this.ResponseCode == string.Empty ? "" : this.ResponseCode)}");
            toStringOutput.Add($"this.HostResponseCode = {(this.HostResponseCode == null ? "null" : this.HostResponseCode == string.Empty ? "" : this.HostResponseCode)}");
            toStringOutput.Add($"this.Message = {(this.Message == null ? "null" : this.Message == string.Empty ? "" : this.Message)}");
            toStringOutput.Add($"this.ApprovalNumber = {(this.ApprovalNumber == null ? "null" : this.ApprovalNumber == string.Empty ? "" : this.ApprovalNumber)}");
            toStringOutput.Add($"this.ApprovedAmount = {(this.ApprovedAmount == null ? "null" : this.ApprovedAmount == string.Empty ? "" : this.ApprovedAmount)}");
            toStringOutput.Add($"this.BalanceAmount = {(this.BalanceAmount == null ? "null" : this.BalanceAmount == string.Empty ? "" : this.BalanceAmount)}");
            toStringOutput.Add($"this.TransactionDate = {(this.TransactionDate == null ? "null" : this.TransactionDate == string.Empty ? "" : this.TransactionDate)}");
            toStringOutput.Add($"this.TransactionTime = {(this.TransactionTime == null ? "null" : this.TransactionTime == string.Empty ? "" : this.TransactionTime)}");
            toStringOutput.Add($"this.TransactionStatus = {(this.TransactionStatus == null ? "null" : this.TransactionStatus == string.Empty ? "" : this.TransactionStatus)}");
            toStringOutput.Add($"this.AddressVerificationAlert = {(this.AddressVerificationAlert == null ? "null" : this.AddressVerificationAlert == string.Empty ? "" : this.AddressVerificationAlert)}");
            toStringOutput.Add($"this.CardVerificationValueAlert = {(this.CardVerificationValueAlert == null ? "null" : this.CardVerificationValueAlert == string.Empty ? "" : this.CardVerificationValueAlert)}");
            toStringOutput.Add($"this.MaskedAccountNumber = {(this.MaskedAccountNumber == null ? "null" : this.MaskedAccountNumber == string.Empty ? "" : this.MaskedAccountNumber)}");
            toStringOutput.Add($"this.Token = {(this.Token == null ? "null" : this.Token == string.Empty ? "" : this.Token)}");
            toStringOutput.Add($"this.ReturnValue = {(this.ReturnValue == null ? "null" : this.ReturnValue == string.Empty ? "" : this.ReturnValue)}");
            toStringOutput.Add($"this.Success = {this.Success}");
            toStringOutput.Add($"this.ErrorMessage = {(this.ErrorMessage == null ? "null" : this.ErrorMessage == string.Empty ? "" : this.ErrorMessage)}");
        }
    }
}