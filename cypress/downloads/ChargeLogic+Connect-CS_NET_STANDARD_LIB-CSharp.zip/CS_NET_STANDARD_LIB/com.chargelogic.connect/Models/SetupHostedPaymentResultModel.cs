// <copyright file="SetupHostedPaymentResultModel.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace com.chargelogic.connect.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using com.chargelogic.connect;
    using com.chargelogic.connect.Utilities;

    /// <summary>
    /// SetupHostedPaymentResultModel.
    /// </summary>
    public class SetupHostedPaymentResultModel
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="SetupHostedPaymentResultModel"/> class.
        /// </summary>
        public SetupHostedPaymentResultModel()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="SetupHostedPaymentResultModel"/> class.
        /// </summary>
        /// <param name="returnValue">return_value.</param>
        /// <param name="success">Success.</param>
        /// <param name="errorMessage">ErrorMessage.</param>
        public SetupHostedPaymentResultModel(
            Guid returnValue,
            bool success,
            string errorMessage)
        {
            this.ReturnValue = returnValue;
            this.Success = success;
            this.ErrorMessage = errorMessage;
        }

        /// <summary>
        /// The Hosted Payment ID for the Hosted Payment
        /// </summary>
        [JsonProperty("return_value")]
        public Guid ReturnValue { get; set; }

        /// <summary>
        /// False, if an exception was raised. True if no exception was raised.
        /// </summary>
        [JsonProperty("Success")]
        public bool Success { get; set; }

        /// <summary>
        /// Exception information
        /// </summary>
        [JsonProperty("ErrorMessage")]
        public string ErrorMessage { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"SetupHostedPaymentResultModel : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is SetupHostedPaymentResultModel other &&
                this.ReturnValue.Equals(other.ReturnValue) &&
                this.Success.Equals(other.Success) &&
                ((this.ErrorMessage == null && other.ErrorMessage == null) || (this.ErrorMessage?.Equals(other.ErrorMessage) == true));
        }
        

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.ReturnValue = {this.ReturnValue}");
            toStringOutput.Add($"this.Success = {this.Success}");
            toStringOutput.Add($"this.ErrorMessage = {(this.ErrorMessage == null ? "null" : this.ErrorMessage == string.Empty ? "" : this.ErrorMessage)}");
        }
    }
}