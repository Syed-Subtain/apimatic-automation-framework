// <copyright file="QueryOrderModel.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace com.chargelogic.connect.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using com.chargelogic.connect;
    using com.chargelogic.connect.Utilities;

    /// <summary>
    /// QueryOrderModel.
    /// </summary>
    public class QueryOrderModel
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="QueryOrderModel"/> class.
        /// </summary>
        public QueryOrderModel()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="QueryOrderModel"/> class.
        /// </summary>
        /// <param name="credential">credential.</param>
        /// <param name="hostedPaymentID">hostedPaymentID.</param>
        /// <param name="orders">orders.</param>
        public QueryOrderModel(
            Models.Credential credential,
            string hostedPaymentID,
            Models.EFTOrders orders)
        {
            this.Credential = credential;
            this.HostedPaymentID = hostedPaymentID;
            this.Orders = orders;
        }

        /// <summary>
        /// The ChargeLogic Connect credentials
        /// </summary>
        [JsonProperty("credential")]
        public Models.Credential Credential { get; set; }

        /// <summary>
        /// The Hosted Payment ID of the order to query
        /// </summary>
        [JsonProperty("hostedPaymentID")]
        public string HostedPaymentID { get; set; }

        /// <summary>
        /// An Order object
        /// </summary>
        [JsonProperty("orders")]
        public Models.EFTOrders Orders { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"QueryOrderModel : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is QueryOrderModel other &&
                ((this.Credential == null && other.Credential == null) || (this.Credential?.Equals(other.Credential) == true)) &&
                ((this.HostedPaymentID == null && other.HostedPaymentID == null) || (this.HostedPaymentID?.Equals(other.HostedPaymentID) == true)) &&
                ((this.Orders == null && other.Orders == null) || (this.Orders?.Equals(other.Orders) == true));
        }
        

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.Credential = {(this.Credential == null ? "null" : this.Credential.ToString())}");
            toStringOutput.Add($"this.HostedPaymentID = {(this.HostedPaymentID == null ? "null" : this.HostedPaymentID == string.Empty ? "" : this.HostedPaymentID)}");
            toStringOutput.Add($"this.Orders = {(this.Orders == null ? "null" : this.Orders.ToString())}");
        }
    }
}