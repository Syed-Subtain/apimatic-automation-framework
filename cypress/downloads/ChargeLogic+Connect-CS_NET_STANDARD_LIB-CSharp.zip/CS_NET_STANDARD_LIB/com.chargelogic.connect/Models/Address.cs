// <copyright file="Address.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace com.chargelogic.connect.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using com.chargelogic.connect;
    using com.chargelogic.connect.Utilities;

    /// <summary>
    /// Address.
    /// </summary>
    public class Address
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="Address"/> class.
        /// </summary>
        public Address()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="Address"/> class.
        /// </summary>
        /// <param name="name">Name.</param>
        /// <param name="streetAddress">StreetAddress.</param>
        /// <param name="streetAddress2">StreetAddress2.</param>
        /// <param name="city">City.</param>
        /// <param name="state">State.</param>
        /// <param name="postCode">PostCode.</param>
        /// <param name="country">Country.</param>
        /// <param name="phoneNumber">PhoneNumber.</param>
        /// <param name="email">Email.</param>
        public Address(
            string name = null,
            string streetAddress = null,
            string streetAddress2 = null,
            string city = null,
            string state = null,
            string postCode = null,
            string country = null,
            string phoneNumber = null,
            string email = null)
        {
            this.Name = name;
            this.StreetAddress = streetAddress;
            this.StreetAddress2 = streetAddress2;
            this.City = city;
            this.State = state;
            this.PostCode = postCode;
            this.Country = country;
            this.PhoneNumber = phoneNumber;
            this.Email = email;
        }

        /// <summary>
        /// The addressee. The maximum length is 50.
        /// </summary>
        [JsonProperty("Name", NullValueHandling = NullValueHandling.Ignore)]
        public string Name { get; set; }

        /// <summary>
        /// The first line of the street address. The maximum length is 50.
        /// </summary>
        [JsonProperty("StreetAddress", NullValueHandling = NullValueHandling.Ignore)]
        public string StreetAddress { get; set; }

        /// <summary>
        /// The second line of the street address. The maximum length is 50.
        /// </summary>
        [JsonProperty("StreetAddress2", NullValueHandling = NullValueHandling.Ignore)]
        public string StreetAddress2 { get; set; }

        /// <summary>
        /// The city.  The maximum length is 30.
        /// </summary>
        [JsonProperty("City", NullValueHandling = NullValueHandling.Ignore)]
        public string City { get; set; }

        /// <summary>
        /// The state or province. The maximum length is 30.
        /// </summary>
        [JsonProperty("State", NullValueHandling = NullValueHandling.Ignore)]
        public string State { get; set; }

        /// <summary>
        /// The post code or ZIP code. The maximum length is 30.
        /// </summary>
        [JsonProperty("PostCode", NullValueHandling = NullValueHandling.Ignore)]
        public string PostCode { get; set; }

        /// <summary>
        /// The 3-character alphabetic ISO country code
        /// </summary>
        [JsonProperty("Country", NullValueHandling = NullValueHandling.Ignore)]
        public string Country { get; set; }

        /// <summary>
        /// The phone number associated with the addressee. The maximum length is 30.
        /// </summary>
        [JsonProperty("PhoneNumber", NullValueHandling = NullValueHandling.Ignore)]
        public string PhoneNumber { get; set; }

        /// <summary>
        /// The email address associated with the addressee. The maximum length is 80.
        /// </summary>
        [JsonProperty("Email", NullValueHandling = NullValueHandling.Ignore)]
        public string Email { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"Address : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is Address other &&
                ((this.Name == null && other.Name == null) || (this.Name?.Equals(other.Name) == true)) &&
                ((this.StreetAddress == null && other.StreetAddress == null) || (this.StreetAddress?.Equals(other.StreetAddress) == true)) &&
                ((this.StreetAddress2 == null && other.StreetAddress2 == null) || (this.StreetAddress2?.Equals(other.StreetAddress2) == true)) &&
                ((this.City == null && other.City == null) || (this.City?.Equals(other.City) == true)) &&
                ((this.State == null && other.State == null) || (this.State?.Equals(other.State) == true)) &&
                ((this.PostCode == null && other.PostCode == null) || (this.PostCode?.Equals(other.PostCode) == true)) &&
                ((this.Country == null && other.Country == null) || (this.Country?.Equals(other.Country) == true)) &&
                ((this.PhoneNumber == null && other.PhoneNumber == null) || (this.PhoneNumber?.Equals(other.PhoneNumber) == true)) &&
                ((this.Email == null && other.Email == null) || (this.Email?.Equals(other.Email) == true));
        }
        

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.Name = {(this.Name == null ? "null" : this.Name == string.Empty ? "" : this.Name)}");
            toStringOutput.Add($"this.StreetAddress = {(this.StreetAddress == null ? "null" : this.StreetAddress == string.Empty ? "" : this.StreetAddress)}");
            toStringOutput.Add($"this.StreetAddress2 = {(this.StreetAddress2 == null ? "null" : this.StreetAddress2 == string.Empty ? "" : this.StreetAddress2)}");
            toStringOutput.Add($"this.City = {(this.City == null ? "null" : this.City == string.Empty ? "" : this.City)}");
            toStringOutput.Add($"this.State = {(this.State == null ? "null" : this.State == string.Empty ? "" : this.State)}");
            toStringOutput.Add($"this.PostCode = {(this.PostCode == null ? "null" : this.PostCode == string.Empty ? "" : this.PostCode)}");
            toStringOutput.Add($"this.Country = {(this.Country == null ? "null" : this.Country == string.Empty ? "" : this.Country)}");
            toStringOutput.Add($"this.PhoneNumber = {(this.PhoneNumber == null ? "null" : this.PhoneNumber == string.Empty ? "" : this.PhoneNumber)}");
            toStringOutput.Add($"this.Email = {(this.Email == null ? "null" : this.Email == string.Empty ? "" : this.Email)}");
        }
    }
}