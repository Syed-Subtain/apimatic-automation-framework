// <copyright file="GiftCardTransactionModel.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace com.chargelogic.connect.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using com.chargelogic.connect;
    using com.chargelogic.connect.Utilities;

    /// <summary>
    /// GiftCardTransactionModel.
    /// </summary>
    public class GiftCardTransactionModel
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="GiftCardTransactionModel"/> class.
        /// </summary>
        public GiftCardTransactionModel()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="GiftCardTransactionModel"/> class.
        /// </summary>
        /// <param name="credential">credential.</param>
        /// <param name="card">card.</param>
        /// <param name="transaction">transaction.</param>
        public GiftCardTransactionModel(
            Models.Credential credential,
            Models.Card card,
            Models.Transaction transaction)
        {
            this.Credential = credential;
            this.Card = card;
            this.Transaction = transaction;
        }

        /// <summary>
        /// The ChargeLogic Connect credentials
        /// </summary>
        [JsonProperty("credential")]
        public Models.Credential Credential { get; set; }

        /// <summary>
        /// Information about the credit card
        /// </summary>
        [JsonProperty("card")]
        public Models.Card Card { get; set; }

        /// <summary>
        /// Information about the transaction
        /// </summary>
        [JsonProperty("transaction")]
        public Models.Transaction Transaction { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"GiftCardTransactionModel : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is GiftCardTransactionModel other &&
                ((this.Credential == null && other.Credential == null) || (this.Credential?.Equals(other.Credential) == true)) &&
                ((this.Card == null && other.Card == null) || (this.Card?.Equals(other.Card) == true)) &&
                ((this.Transaction == null && other.Transaction == null) || (this.Transaction?.Equals(other.Transaction) == true));
        }
        

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.Credential = {(this.Credential == null ? "null" : this.Credential.ToString())}");
            toStringOutput.Add($"this.Card = {(this.Card == null ? "null" : this.Card.ToString())}");
            toStringOutput.Add($"this.Transaction = {(this.Transaction == null ? "null" : this.Transaction.ToString())}");
        }
    }
}