// <copyright file="ReferenceTransaction.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace com.chargelogic.connect.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using com.chargelogic.connect;
    using com.chargelogic.connect.Utilities;

    /// <summary>
    /// ReferenceTransaction.
    /// </summary>
    public class ReferenceTransaction
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ReferenceTransaction"/> class.
        /// </summary>
        public ReferenceTransaction()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ReferenceTransaction"/> class.
        /// </summary>
        /// <param name="originalReferenceNumber">OriginalReferenceNumber.</param>
        /// <param name="amount">Amount.</param>
        public ReferenceTransaction(
            string originalReferenceNumber,
            string amount)
        {
            this.OriginalReferenceNumber = originalReferenceNumber;
            this.Amount = amount;
        }

        /// <summary>
        /// The Reference Number returned by a transaction request
        /// </summary>
        [JsonProperty("OriginalReferenceNumber")]
        public string OriginalReferenceNumber { get; set; }

        /// <summary>
        /// The amount of the new transaction
        /// </summary>
        [JsonProperty("Amount")]
        public string Amount { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"ReferenceTransaction : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is ReferenceTransaction other &&
                ((this.OriginalReferenceNumber == null && other.OriginalReferenceNumber == null) || (this.OriginalReferenceNumber?.Equals(other.OriginalReferenceNumber) == true)) &&
                ((this.Amount == null && other.Amount == null) || (this.Amount?.Equals(other.Amount) == true));
        }
        

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.OriginalReferenceNumber = {(this.OriginalReferenceNumber == null ? "null" : this.OriginalReferenceNumber == string.Empty ? "" : this.OriginalReferenceNumber)}");
            toStringOutput.Add($"this.Amount = {(this.Amount == null ? "null" : this.Amount == string.Empty ? "" : this.Amount)}");
        }
    }
}