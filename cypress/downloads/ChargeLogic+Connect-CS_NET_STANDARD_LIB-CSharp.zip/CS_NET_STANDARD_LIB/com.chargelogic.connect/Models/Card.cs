// <copyright file="Card.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace com.chargelogic.connect.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using com.chargelogic.connect;
    using com.chargelogic.connect.Utilities;

    /// <summary>
    /// Card.
    /// </summary>
    public class Card
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="Card"/> class.
        /// </summary>
        public Card()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="Card"/> class.
        /// </summary>
        /// <param name="cardholderName">CardholderName.</param>
        /// <param name="accountNumber">AccountNumber.</param>
        /// <param name="expirationMonth">ExpirationMonth.</param>
        /// <param name="expirationYear">ExpirationYear.</param>
        /// <param name="track2Data">Track2Data.</param>
        /// <param name="token">Token.</param>
        /// <param name="cardVerificationValue">CardVerificationValue.</param>
        /// <param name="setAsDefault">SetAsDefault.</param>
        public Card(
            string cardholderName = null,
            string accountNumber = null,
            string expirationMonth = null,
            string expirationYear = null,
            string track2Data = null,
            string token = null,
            string cardVerificationValue = null,
            string setAsDefault = null)
        {
            this.CardholderName = cardholderName;
            this.AccountNumber = accountNumber;
            this.ExpirationMonth = expirationMonth;
            this.ExpirationYear = expirationYear;
            this.Track2Data = track2Data;
            this.Token = token;
            this.CardVerificationValue = cardVerificationValue;
            this.SetAsDefault = setAsDefault;
        }

        /// <summary>
        /// The cardholder’s name as it appears on the card.
        /// </summary>
        [JsonProperty("CardholderName", NullValueHandling = NullValueHandling.Ignore)]
        public string CardholderName { get; set; }

        /// <summary>
        /// The credit card number. This field is required if a nether a Token nor Track2Data is supplied. The maximum length is 19.
        /// </summary>
        [JsonProperty("AccountNumber", NullValueHandling = NullValueHandling.Ignore)]
        public string AccountNumber { get; set; }

        /// <summary>
        /// The two-digit expiration month. This field is required if Track2Data is not specified. The maximum length is 2.
        /// </summary>
        [JsonProperty("ExpirationMonth", NullValueHandling = NullValueHandling.Ignore)]
        public string ExpirationMonth { get; set; }

        /// <summary>
        /// The two-digit expiration year. This field is required if Track2Data is not specified. The maximum length is 2.
        /// </summary>
        [JsonProperty("ExpirationYear", NullValueHandling = NullValueHandling.Ignore)]
        public string ExpirationYear { get; set; }

        /// <summary>
        /// All data from Track 2 on the card’s magnetic stripe. This field is required if neither AccountNumber nor Token is specified. The maximum length is 40.
        /// </summary>
        [JsonProperty("Track2Data", NullValueHandling = NullValueHandling.Ignore)]
        public string Track2Data { get; set; }

        /// <summary>
        /// The ChargeLogic Connect-generated Secure Remote Storage token representing the AccountNumber. This field is required if neither AccountNumber nor Track2Data is specified. The maximum length is 50.
        /// </summary>
        [JsonProperty("Token", NullValueHandling = NullValueHandling.Ignore)]
        public string Token { get; set; }

        /// <summary>
        /// The CVV/CVV2/CID from the credit card. For American Express, this is a 4-digit value. For all other card types, it is a 3-digit value. The maximum length is 4.
        /// </summary>
        [JsonProperty("CardVerificationValue", NullValueHandling = NullValueHandling.Ignore)]
        public string CardVerificationValue { get; set; }

        /// <summary>
        /// When set to True, this card will be marked as Default when imported by ChargeLogic Payments
        /// </summary>
        [JsonProperty("SetAsDefault", NullValueHandling = NullValueHandling.Ignore)]
        public string SetAsDefault { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"Card : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is Card other &&
                ((this.CardholderName == null && other.CardholderName == null) || (this.CardholderName?.Equals(other.CardholderName) == true)) &&
                ((this.AccountNumber == null && other.AccountNumber == null) || (this.AccountNumber?.Equals(other.AccountNumber) == true)) &&
                ((this.ExpirationMonth == null && other.ExpirationMonth == null) || (this.ExpirationMonth?.Equals(other.ExpirationMonth) == true)) &&
                ((this.ExpirationYear == null && other.ExpirationYear == null) || (this.ExpirationYear?.Equals(other.ExpirationYear) == true)) &&
                ((this.Track2Data == null && other.Track2Data == null) || (this.Track2Data?.Equals(other.Track2Data) == true)) &&
                ((this.Token == null && other.Token == null) || (this.Token?.Equals(other.Token) == true)) &&
                ((this.CardVerificationValue == null && other.CardVerificationValue == null) || (this.CardVerificationValue?.Equals(other.CardVerificationValue) == true)) &&
                ((this.SetAsDefault == null && other.SetAsDefault == null) || (this.SetAsDefault?.Equals(other.SetAsDefault) == true));
        }
        

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.CardholderName = {(this.CardholderName == null ? "null" : this.CardholderName == string.Empty ? "" : this.CardholderName)}");
            toStringOutput.Add($"this.AccountNumber = {(this.AccountNumber == null ? "null" : this.AccountNumber == string.Empty ? "" : this.AccountNumber)}");
            toStringOutput.Add($"this.ExpirationMonth = {(this.ExpirationMonth == null ? "null" : this.ExpirationMonth == string.Empty ? "" : this.ExpirationMonth)}");
            toStringOutput.Add($"this.ExpirationYear = {(this.ExpirationYear == null ? "null" : this.ExpirationYear == string.Empty ? "" : this.ExpirationYear)}");
            toStringOutput.Add($"this.Track2Data = {(this.Track2Data == null ? "null" : this.Track2Data == string.Empty ? "" : this.Track2Data)}");
            toStringOutput.Add($"this.Token = {(this.Token == null ? "null" : this.Token == string.Empty ? "" : this.Token)}");
            toStringOutput.Add($"this.CardVerificationValue = {(this.CardVerificationValue == null ? "null" : this.CardVerificationValue == string.Empty ? "" : this.CardVerificationValue)}");
            toStringOutput.Add($"this.SetAsDefault = {(this.SetAsDefault == null ? "null" : this.SetAsDefault == string.Empty ? "" : this.SetAsDefault)}");
        }
    }
}