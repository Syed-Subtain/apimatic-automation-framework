// <copyright file="CheckTransactionModel.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace com.chargelogic.connect.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using com.chargelogic.connect;
    using com.chargelogic.connect.Utilities;

    /// <summary>
    /// CheckTransactionModel.
    /// </summary>
    public class CheckTransactionModel
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="CheckTransactionModel"/> class.
        /// </summary>
        public CheckTransactionModel()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="CheckTransactionModel"/> class.
        /// </summary>
        /// <param name="credential">credential.</param>
        /// <param name="demandDepositAccount">demandDepositAccount.</param>
        /// <param name="transaction">transaction.</param>
        /// <param name="identification">identification.</param>
        /// <param name="billingAddress">billingAddress.</param>
        public CheckTransactionModel(
            Models.Credential credential,
            Models.DemandDepositAccount demandDepositAccount,
            Models.Transaction transaction,
            Models.Identification identification,
            Models.Address billingAddress)
        {
            this.Credential = credential;
            this.DemandDepositAccount = demandDepositAccount;
            this.Transaction = transaction;
            this.Identification = identification;
            this.BillingAddress = billingAddress;
        }

        /// <summary>
        /// The ChargeLogic Connect credentials
        /// </summary>
        [JsonProperty("credential")]
        public Models.Credential Credential { get; set; }

        /// <summary>
        /// Information about the checking or savings account
        /// </summary>
        [JsonProperty("demandDepositAccount")]
        public Models.DemandDepositAccount DemandDepositAccount { get; set; }

        /// <summary>
        /// Information about the transaction
        /// </summary>
        [JsonProperty("transaction")]
        public Models.Transaction Transaction { get; set; }

        /// <summary>
        /// Information about the check writer
        /// </summary>
        [JsonProperty("identification")]
        public Models.Identification Identification { get; set; }

        /// <summary>
        /// The check writer's billing address
        /// </summary>
        [JsonProperty("billingAddress")]
        public Models.Address BillingAddress { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"CheckTransactionModel : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is CheckTransactionModel other &&
                ((this.Credential == null && other.Credential == null) || (this.Credential?.Equals(other.Credential) == true)) &&
                ((this.DemandDepositAccount == null && other.DemandDepositAccount == null) || (this.DemandDepositAccount?.Equals(other.DemandDepositAccount) == true)) &&
                ((this.Transaction == null && other.Transaction == null) || (this.Transaction?.Equals(other.Transaction) == true)) &&
                ((this.Identification == null && other.Identification == null) || (this.Identification?.Equals(other.Identification) == true)) &&
                ((this.BillingAddress == null && other.BillingAddress == null) || (this.BillingAddress?.Equals(other.BillingAddress) == true));
        }
        

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.Credential = {(this.Credential == null ? "null" : this.Credential.ToString())}");
            toStringOutput.Add($"this.DemandDepositAccount = {(this.DemandDepositAccount == null ? "null" : this.DemandDepositAccount.ToString())}");
            toStringOutput.Add($"this.Transaction = {(this.Transaction == null ? "null" : this.Transaction.ToString())}");
            toStringOutput.Add($"this.Identification = {(this.Identification == null ? "null" : this.Identification.ToString())}");
            toStringOutput.Add($"this.BillingAddress = {(this.BillingAddress == null ? "null" : this.BillingAddress.ToString())}");
        }
    }
}