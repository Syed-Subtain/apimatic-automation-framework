// <copyright file="TransactionResultModel.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace com.chargelogic.connect.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using com.chargelogic.connect;
    using com.chargelogic.connect.Utilities;

    /// <summary>
    /// TransactionResultModel.
    /// </summary>
    public class TransactionResultModel
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="TransactionResultModel"/> class.
        /// </summary>
        public TransactionResultModel()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="TransactionResultModel"/> class.
        /// </summary>
        /// <param name="creditCardAuthorizeResult">CreditCardAuthorizeResult.</param>
        /// <param name="creditCardAddressVerify2Result">CreditCardAddressVerify2Result.</param>
        /// <param name="creditCardAddressVerifyResult">CreditCardAddressVerifyResult.</param>
        /// <param name="giftCardBalanceIncreaseResult">GiftCardBalanceIncreaseResult.</param>
        /// <param name="giftCardBalanceInquiryResult">GiftCardBalanceInquiryResult.</param>
        /// <param name="giftCardCreditResult">GiftCardCreditResult.</param>
        /// <param name="giftCardDeactivateResult">GiftCardDeactivateResult.</param>
        /// <param name="giftCardActivateResult">GiftCardActivateResult.</param>
        /// <param name="giftCardAuthorizeResult">GiftCardAuthorizeResult.</param>
        /// <param name="giftCardChargeResult">GiftCardChargeResult.</param>
        /// <param name="checkChargeResult">CheckChargeResult.</param>
        /// <param name="setupHostedCheckChargeResult">SetupHostedCheckChargeResult.</param>
        /// <param name="setupHostedCreditCardAuthorizeResult">SetupHostedCreditCardAuthorizeResult.</param>
        /// <param name="setupHostedOrderResult">SetupHostedOrderResult.</param>
        public TransactionResultModel(
            Models.ResponseModel creditCardAuthorizeResult = null,
            Models.ResponseModel creditCardAddressVerify2Result = null,
            Models.ResponseModel creditCardAddressVerifyResult = null,
            Models.ResponseModel giftCardBalanceIncreaseResult = null,
            Models.ResponseModel giftCardBalanceInquiryResult = null,
            Models.ResponseModel giftCardCreditResult = null,
            Models.ResponseModel giftCardDeactivateResult = null,
            Models.ResponseModel giftCardActivateResult = null,
            Models.ResponseModel giftCardAuthorizeResult = null,
            Models.ResponseModel giftCardChargeResult = null,
            Models.ResponseModel checkChargeResult = null,
            Models.SetupHostedPaymentResultModel setupHostedCheckChargeResult = null,
            Models.SetupHostedPaymentResultModel setupHostedCreditCardAuthorizeResult = null,
            Models.SetupHostedPaymentResultModel setupHostedOrderResult = null)
        {
            this.CreditCardAuthorizeResult = creditCardAuthorizeResult;
            this.CreditCardAddressVerify2Result = creditCardAddressVerify2Result;
            this.CreditCardAddressVerifyResult = creditCardAddressVerifyResult;
            this.GiftCardBalanceIncreaseResult = giftCardBalanceIncreaseResult;
            this.GiftCardBalanceInquiryResult = giftCardBalanceInquiryResult;
            this.GiftCardCreditResult = giftCardCreditResult;
            this.GiftCardDeactivateResult = giftCardDeactivateResult;
            this.GiftCardActivateResult = giftCardActivateResult;
            this.GiftCardAuthorizeResult = giftCardAuthorizeResult;
            this.GiftCardChargeResult = giftCardChargeResult;
            this.CheckChargeResult = checkChargeResult;
            this.SetupHostedCheckChargeResult = setupHostedCheckChargeResult;
            this.SetupHostedCreditCardAuthorizeResult = setupHostedCreditCardAuthorizeResult;
            this.SetupHostedOrderResult = setupHostedOrderResult;
        }

        /// <summary>
        /// Response information for a CreditCardAuthorize transaction
        /// </summary>
        [JsonProperty("CreditCardAuthorizeResult", NullValueHandling = NullValueHandling.Ignore)]
        public Models.ResponseModel CreditCardAuthorizeResult { get; set; }

        /// <summary>
        /// Response information for a CreditCardAddressVerify2 transaction
        /// </summary>
        [JsonProperty("CreditCardAddressVerify2Result", NullValueHandling = NullValueHandling.Ignore)]
        public Models.ResponseModel CreditCardAddressVerify2Result { get; set; }

        /// <summary>
        /// Response information for a CreditCardAddressVerify transaction
        /// </summary>
        [JsonProperty("CreditCardAddressVerifyResult", NullValueHandling = NullValueHandling.Ignore)]
        public Models.ResponseModel CreditCardAddressVerifyResult { get; set; }

        /// <summary>
        /// Response information for a GiftCardBalanceIncrease transaction
        /// </summary>
        [JsonProperty("GiftCardBalanceIncreaseResult", NullValueHandling = NullValueHandling.Ignore)]
        public Models.ResponseModel GiftCardBalanceIncreaseResult { get; set; }

        /// <summary>
        /// Response information for a GiftCardBalanceInquiry transaction
        /// </summary>
        [JsonProperty("GiftCardBalanceInquiryResult", NullValueHandling = NullValueHandling.Ignore)]
        public Models.ResponseModel GiftCardBalanceInquiryResult { get; set; }

        /// <summary>
        /// Response information for a GiftCardCredit transaction
        /// </summary>
        [JsonProperty("GiftCardCreditResult", NullValueHandling = NullValueHandling.Ignore)]
        public Models.ResponseModel GiftCardCreditResult { get; set; }

        /// <summary>
        /// Response information for a GiftCardDeactivate transaction
        /// </summary>
        [JsonProperty("GiftCardDeactivateResult", NullValueHandling = NullValueHandling.Ignore)]
        public Models.ResponseModel GiftCardDeactivateResult { get; set; }

        /// <summary>
        /// Response information for a GiftCardActivate transaction
        /// </summary>
        [JsonProperty("GiftCardActivateResult", NullValueHandling = NullValueHandling.Ignore)]
        public Models.ResponseModel GiftCardActivateResult { get; set; }

        /// <summary>
        /// Response information for a GiftCardAuthorize transaction
        /// </summary>
        [JsonProperty("GiftCardAuthorizeResult", NullValueHandling = NullValueHandling.Ignore)]
        public Models.ResponseModel GiftCardAuthorizeResult { get; set; }

        /// <summary>
        /// Response information for a GiftCardCharge transaction
        /// </summary>
        [JsonProperty("GiftCardChargeResult", NullValueHandling = NullValueHandling.Ignore)]
        public Models.ResponseModel GiftCardChargeResult { get; set; }

        /// <summary>
        /// Response information for a CheckCharge transaction
        /// </summary>
        [JsonProperty("CheckChargeResult", NullValueHandling = NullValueHandling.Ignore)]
        public Models.ResponseModel CheckChargeResult { get; set; }

        /// <summary>
        /// Response information for a SetupHostedCheckCharge transaction
        /// </summary>
        [JsonProperty("SetupHostedCheckChargeResult", NullValueHandling = NullValueHandling.Ignore)]
        public Models.SetupHostedPaymentResultModel SetupHostedCheckChargeResult { get; set; }

        /// <summary>
        /// Response information for a SetupHostedCreditCardAuthorize transaction
        /// </summary>
        [JsonProperty("SetupHostedCreditCardAuthorizeResult", NullValueHandling = NullValueHandling.Ignore)]
        public Models.SetupHostedPaymentResultModel SetupHostedCreditCardAuthorizeResult { get; set; }

        /// <summary>
        /// Response information for a SetupHostedOrder transaction
        /// </summary>
        [JsonProperty("SetupHostedOrderResult", NullValueHandling = NullValueHandling.Ignore)]
        public Models.SetupHostedPaymentResultModel SetupHostedOrderResult { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"TransactionResultModel : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is TransactionResultModel other &&
                ((this.CreditCardAuthorizeResult == null && other.CreditCardAuthorizeResult == null) || (this.CreditCardAuthorizeResult?.Equals(other.CreditCardAuthorizeResult) == true)) &&
                ((this.CreditCardAddressVerify2Result == null && other.CreditCardAddressVerify2Result == null) || (this.CreditCardAddressVerify2Result?.Equals(other.CreditCardAddressVerify2Result) == true)) &&
                ((this.CreditCardAddressVerifyResult == null && other.CreditCardAddressVerifyResult == null) || (this.CreditCardAddressVerifyResult?.Equals(other.CreditCardAddressVerifyResult) == true)) &&
                ((this.GiftCardBalanceIncreaseResult == null && other.GiftCardBalanceIncreaseResult == null) || (this.GiftCardBalanceIncreaseResult?.Equals(other.GiftCardBalanceIncreaseResult) == true)) &&
                ((this.GiftCardBalanceInquiryResult == null && other.GiftCardBalanceInquiryResult == null) || (this.GiftCardBalanceInquiryResult?.Equals(other.GiftCardBalanceInquiryResult) == true)) &&
                ((this.GiftCardCreditResult == null && other.GiftCardCreditResult == null) || (this.GiftCardCreditResult?.Equals(other.GiftCardCreditResult) == true)) &&
                ((this.GiftCardDeactivateResult == null && other.GiftCardDeactivateResult == null) || (this.GiftCardDeactivateResult?.Equals(other.GiftCardDeactivateResult) == true)) &&
                ((this.GiftCardActivateResult == null && other.GiftCardActivateResult == null) || (this.GiftCardActivateResult?.Equals(other.GiftCardActivateResult) == true)) &&
                ((this.GiftCardAuthorizeResult == null && other.GiftCardAuthorizeResult == null) || (this.GiftCardAuthorizeResult?.Equals(other.GiftCardAuthorizeResult) == true)) &&
                ((this.GiftCardChargeResult == null && other.GiftCardChargeResult == null) || (this.GiftCardChargeResult?.Equals(other.GiftCardChargeResult) == true)) &&
                ((this.CheckChargeResult == null && other.CheckChargeResult == null) || (this.CheckChargeResult?.Equals(other.CheckChargeResult) == true)) &&
                ((this.SetupHostedCheckChargeResult == null && other.SetupHostedCheckChargeResult == null) || (this.SetupHostedCheckChargeResult?.Equals(other.SetupHostedCheckChargeResult) == true)) &&
                ((this.SetupHostedCreditCardAuthorizeResult == null && other.SetupHostedCreditCardAuthorizeResult == null) || (this.SetupHostedCreditCardAuthorizeResult?.Equals(other.SetupHostedCreditCardAuthorizeResult) == true)) &&
                ((this.SetupHostedOrderResult == null && other.SetupHostedOrderResult == null) || (this.SetupHostedOrderResult?.Equals(other.SetupHostedOrderResult) == true));
        }
        

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.CreditCardAuthorizeResult = {(this.CreditCardAuthorizeResult == null ? "null" : this.CreditCardAuthorizeResult.ToString())}");
            toStringOutput.Add($"this.CreditCardAddressVerify2Result = {(this.CreditCardAddressVerify2Result == null ? "null" : this.CreditCardAddressVerify2Result.ToString())}");
            toStringOutput.Add($"this.CreditCardAddressVerifyResult = {(this.CreditCardAddressVerifyResult == null ? "null" : this.CreditCardAddressVerifyResult.ToString())}");
            toStringOutput.Add($"this.GiftCardBalanceIncreaseResult = {(this.GiftCardBalanceIncreaseResult == null ? "null" : this.GiftCardBalanceIncreaseResult.ToString())}");
            toStringOutput.Add($"this.GiftCardBalanceInquiryResult = {(this.GiftCardBalanceInquiryResult == null ? "null" : this.GiftCardBalanceInquiryResult.ToString())}");
            toStringOutput.Add($"this.GiftCardCreditResult = {(this.GiftCardCreditResult == null ? "null" : this.GiftCardCreditResult.ToString())}");
            toStringOutput.Add($"this.GiftCardDeactivateResult = {(this.GiftCardDeactivateResult == null ? "null" : this.GiftCardDeactivateResult.ToString())}");
            toStringOutput.Add($"this.GiftCardActivateResult = {(this.GiftCardActivateResult == null ? "null" : this.GiftCardActivateResult.ToString())}");
            toStringOutput.Add($"this.GiftCardAuthorizeResult = {(this.GiftCardAuthorizeResult == null ? "null" : this.GiftCardAuthorizeResult.ToString())}");
            toStringOutput.Add($"this.GiftCardChargeResult = {(this.GiftCardChargeResult == null ? "null" : this.GiftCardChargeResult.ToString())}");
            toStringOutput.Add($"this.CheckChargeResult = {(this.CheckChargeResult == null ? "null" : this.CheckChargeResult.ToString())}");
            toStringOutput.Add($"this.SetupHostedCheckChargeResult = {(this.SetupHostedCheckChargeResult == null ? "null" : this.SetupHostedCheckChargeResult.ToString())}");
            toStringOutput.Add($"this.SetupHostedCreditCardAuthorizeResult = {(this.SetupHostedCreditCardAuthorizeResult == null ? "null" : this.SetupHostedCreditCardAuthorizeResult.ToString())}");
            toStringOutput.Add($"this.SetupHostedOrderResult = {(this.SetupHostedOrderResult == null ? "null" : this.SetupHostedOrderResult.ToString())}");
        }
    }
}