// <copyright file="EFTOrders.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace com.chargelogic.connect.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using com.chargelogic.connect;
    using com.chargelogic.connect.Utilities;

    /// <summary>
    /// EFTOrders.
    /// </summary>
    public class EFTOrders
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="EFTOrders"/> class.
        /// </summary>
        public EFTOrders()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="EFTOrders"/> class.
        /// </summary>
        /// <param name="orderCount">OrderCount.</param>
        /// <param name="order">Order.</param>
        public EFTOrders(
            List<string> orderCount,
            List<Models.Order> order = null)
        {
            this.OrderCount = orderCount;
            this.Order = order;
        }

        /// <summary>
        /// The number of orders in the response
        /// </summary>
        [JsonProperty("OrderCount")]
        public List<string> OrderCount { get; set; }

        /// <summary>
        /// The array of orders
        /// </summary>
        [JsonProperty("Order", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.Order> Order { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"EFTOrders : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is EFTOrders other &&
                ((this.OrderCount == null && other.OrderCount == null) || (this.OrderCount?.Equals(other.OrderCount) == true)) &&
                ((this.Order == null && other.Order == null) || (this.Order?.Equals(other.Order) == true));
        }
        

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.OrderCount = {(this.OrderCount == null ? "null" : $"[{string.Join(", ", this.OrderCount)} ]")}");
            toStringOutput.Add($"this.Order = {(this.Order == null ? "null" : $"[{string.Join(", ", this.Order)} ]")}");
        }
    }
}