// <copyright file="DemandDepositAccount.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace com.chargelogic.connect.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using com.chargelogic.connect;
    using com.chargelogic.connect.Utilities;

    /// <summary>
    /// DemandDepositAccount.
    /// </summary>
    public class DemandDepositAccount
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="DemandDepositAccount"/> class.
        /// </summary>
        public DemandDepositAccount()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="DemandDepositAccount"/> class.
        /// </summary>
        /// <param name="routingNumber">RoutingNumber.</param>
        /// <param name="accountNumber">AccountNumber.</param>
        /// <param name="checkType">CheckType.</param>
        /// <param name="accountType">AccountType.</param>
        /// <param name="token">Token.</param>
        /// <param name="checkNumber">CheckNumber.</param>
        public DemandDepositAccount(
            string routingNumber,
            string accountNumber,
            string checkType,
            string accountType,
            string token = null,
            string checkNumber = null)
        {
            this.RoutingNumber = routingNumber;
            this.AccountNumber = accountNumber;
            this.CheckType = checkType;
            this.AccountType = accountType;
            this.Token = token;
            this.CheckNumber = checkNumber;
        }

        /// <summary>
        /// The ABA routing number for US accounts or XXXXXYYY for Canadian accounts, where XXXXX is the Branch Number and YYY is the Institution Number
        /// </summary>
        [JsonProperty("RoutingNumber")]
        public string RoutingNumber { get; set; }

        /// <summary>
        /// The demand deposit account number. The maximum length is 19.
        /// </summary>
        [JsonProperty("AccountNumber")]
        public string AccountNumber { get; set; }

        /// <summary>
        /// The check type; must be one of “ ”, “Personal”, or “Business”
        /// </summary>
        [JsonProperty("CheckType")]
        public string CheckType { get; set; }

        /// <summary>
        /// The demand deposit account type; must be one of “ ”, “Checking”, or “Savings”
        /// </summary>
        [JsonProperty("AccountType")]
        public string AccountType { get; set; }

        /// <summary>
        /// The ChargeLogic Connect-generated Secure Remote Storage token representing the AccountNumber
        /// </summary>
        [JsonProperty("Token", NullValueHandling = NullValueHandling.Ignore)]
        public string Token { get; set; }

        /// <summary>
        /// The check number. The maximum length is 15.
        /// </summary>
        [JsonProperty("CheckNumber", NullValueHandling = NullValueHandling.Ignore)]
        public string CheckNumber { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"DemandDepositAccount : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is DemandDepositAccount other &&
                ((this.RoutingNumber == null && other.RoutingNumber == null) || (this.RoutingNumber?.Equals(other.RoutingNumber) == true)) &&
                ((this.AccountNumber == null && other.AccountNumber == null) || (this.AccountNumber?.Equals(other.AccountNumber) == true)) &&
                ((this.CheckType == null && other.CheckType == null) || (this.CheckType?.Equals(other.CheckType) == true)) &&
                ((this.AccountType == null && other.AccountType == null) || (this.AccountType?.Equals(other.AccountType) == true)) &&
                ((this.Token == null && other.Token == null) || (this.Token?.Equals(other.Token) == true)) &&
                ((this.CheckNumber == null && other.CheckNumber == null) || (this.CheckNumber?.Equals(other.CheckNumber) == true));
        }
        

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.RoutingNumber = {(this.RoutingNumber == null ? "null" : this.RoutingNumber == string.Empty ? "" : this.RoutingNumber)}");
            toStringOutput.Add($"this.AccountNumber = {(this.AccountNumber == null ? "null" : this.AccountNumber == string.Empty ? "" : this.AccountNumber)}");
            toStringOutput.Add($"this.CheckType = {(this.CheckType == null ? "null" : this.CheckType == string.Empty ? "" : this.CheckType)}");
            toStringOutput.Add($"this.AccountType = {(this.AccountType == null ? "null" : this.AccountType == string.Empty ? "" : this.AccountType)}");
            toStringOutput.Add($"this.Token = {(this.Token == null ? "null" : this.Token == string.Empty ? "" : this.Token)}");
            toStringOutput.Add($"this.CheckNumber = {(this.CheckNumber == null ? "null" : this.CheckNumber == string.Empty ? "" : this.CheckNumber)}");
        }
    }
}