// <copyright file="CheckTransactionsController.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace com.chargelogic.connect.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Dynamic;
    using System.Globalization;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading;
    using System.Threading.Tasks;
    using com.chargelogic.connect;
    using com.chargelogic.connect.Authentication;
    using com.chargelogic.connect.Http.Client;
    using com.chargelogic.connect.Http.Request;
    using com.chargelogic.connect.Http.Request.Configuration;
    using com.chargelogic.connect.Http.Response;
    using com.chargelogic.connect.Utilities;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// CheckTransactionsController.
    /// </summary>
    public class CheckTransactionsController : BaseController
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="CheckTransactionsController"/> class.
        /// </summary>
        /// <param name="config"> config instance. </param>
        /// <param name="httpClient"> httpClient. </param>
        /// <param name="authManagers"> authManager. </param>
        internal CheckTransactionsController(IConfiguration config, IHttpClient httpClient, IDictionary<string, IAuthManager> authManagers)
            : base(config, httpClient, authManagers)
        {
        }

        /// <summary>
        /// Deducts funds from a demand deposit account.
        /// </summary>
        /// <param name="checkTransaction">Required parameter: Example: .</param>
        /// <returns>Returns the Models.TransactionResultModel response from the API call.</returns>
        public Models.TransactionResultModel CreateCheckCharge(
                Models.CheckTransactionModel checkTransaction)
        {
            Task<Models.TransactionResultModel> t = this.CreateCheckChargeAsync(checkTransaction);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// Deducts funds from a demand deposit account.
        /// </summary>
        /// <param name="checkTransaction">Required parameter: Example: .</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.TransactionResultModel response from the API call.</returns>
        public async Task<Models.TransactionResultModel> CreateCheckChargeAsync(
                Models.CheckTransactionModel checkTransaction,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/CheckCharge");

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "content-type", "application/json; charset=utf-8" },
            };

            // append body params.
            var bodyText = ApiHelper.JsonSerialize(checkTransaction);

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().PostBody(queryBuilder.ToString(), headers, bodyText);

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.TransactionResultModel>(response.Body);
        }

        /// <summary>
        /// Create a hosted payment record for a check charge transaction.
        /// </summary>
        /// <param name="body">Required parameter: Example: .</param>
        /// <returns>Returns the Models.SetupHostedPaymentResultModel response from the API call.</returns>
        public Models.SetupHostedPaymentResultModel CreateSetupHostedCheckCharge(
                Models.SetupHostedCheckTransactionModel body)
        {
            Task<Models.SetupHostedPaymentResultModel> t = this.CreateSetupHostedCheckChargeAsync(body);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// Create a hosted payment record for a check charge transaction.
        /// </summary>
        /// <param name="body">Required parameter: Example: .</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.SetupHostedPaymentResultModel response from the API call.</returns>
        public async Task<Models.SetupHostedPaymentResultModel> CreateSetupHostedCheckChargeAsync(
                Models.SetupHostedCheckTransactionModel body,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/SetupHostedCheckCharge");

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "content-type", "application/json; charset=utf-8" },
            };

            // append body params.
            var bodyText = ApiHelper.JsonSerialize(body);

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().PostBody(queryBuilder.ToString(), headers, bodyText);

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.SetupHostedPaymentResultModel>(response.Body);
        }
    }
}