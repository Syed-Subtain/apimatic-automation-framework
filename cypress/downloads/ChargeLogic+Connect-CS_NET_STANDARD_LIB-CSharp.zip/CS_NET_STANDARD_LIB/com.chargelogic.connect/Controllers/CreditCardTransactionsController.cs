// <copyright file="CreditCardTransactionsController.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace com.chargelogic.connect.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Dynamic;
    using System.Globalization;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading;
    using System.Threading.Tasks;
    using com.chargelogic.connect;
    using com.chargelogic.connect.Authentication;
    using com.chargelogic.connect.Http.Client;
    using com.chargelogic.connect.Http.Request;
    using com.chargelogic.connect.Http.Request.Configuration;
    using com.chargelogic.connect.Http.Response;
    using com.chargelogic.connect.Utilities;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// CreditCardTransactionsController.
    /// </summary>
    public class CreditCardTransactionsController : BaseController
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="CreditCardTransactionsController"/> class.
        /// </summary>
        /// <param name="config"> config instance. </param>
        /// <param name="httpClient"> httpClient. </param>
        /// <param name="authManagers"> authManager. </param>
        internal CreditCardTransactionsController(IConfiguration config, IHttpClient httpClient, IDictionary<string, IAuthManager> authManagers)
            : base(config, httpClient, authManagers)
        {
        }

        /// <summary>
        /// Create a hosted payment record for a credit card address verification transaction.
        /// </summary>
        /// <param name="body">Required parameter: Example: .</param>
        /// <returns>Returns the Models.TransactionResultModel response from the API call.</returns>
        public Models.TransactionResultModel CreateSetupHostedCreditCardAVS(
                Models.SetupHostedCreditCardTransactionModel body)
        {
            Task<Models.TransactionResultModel> t = this.CreateSetupHostedCreditCardAVSAsync(body);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// Create a hosted payment record for a credit card address verification transaction.
        /// </summary>
        /// <param name="body">Required parameter: Example: .</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.TransactionResultModel response from the API call.</returns>
        public async Task<Models.TransactionResultModel> CreateSetupHostedCreditCardAVSAsync(
                Models.SetupHostedCreditCardTransactionModel body,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/SetupHostedCreditCardAVS");

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "content-type", "application/json; charset=utf-8" },
            };

            // append body params.
            var bodyText = ApiHelper.JsonSerialize(body);

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().PostBody(queryBuilder.ToString(), headers, bodyText);

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.TransactionResultModel>(response.Body);
        }

        /// <summary>
        /// Verify the validity of a credit card and billing address without a transaction parameter (this transaction will not be associated with an order).
        /// </summary>
        /// <param name="body">Required parameter: Example: .</param>
        /// <returns>Returns the Models.TransactionResultModel response from the API call.</returns>
        public Models.TransactionResultModel CreateCreditCardAddressVerify(
                Models.CreditCardVerifyTransactionModel body)
        {
            Task<Models.TransactionResultModel> t = this.CreateCreditCardAddressVerifyAsync(body);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// Verify the validity of a credit card and billing address without a transaction parameter (this transaction will not be associated with an order).
        /// </summary>
        /// <param name="body">Required parameter: Example: .</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.TransactionResultModel response from the API call.</returns>
        public async Task<Models.TransactionResultModel> CreateCreditCardAddressVerifyAsync(
                Models.CreditCardVerifyTransactionModel body,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/CreditCardAddressVerify");

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "content-type", "application/json; charset=utf-8" },
            };

            // append body params.
            var bodyText = ApiHelper.JsonSerialize(body);

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().PostBody(queryBuilder.ToString(), headers, bodyText);

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.TransactionResultModel>(response.Body);
        }

        /// <summary>
        /// Verify the validity of a credit card and billing address. Use this method instead of CreditCardAddressVerify if you want the Address Verify transaction to be imported into ChargeLogic Payments as a part of an order.
        /// </summary>
        /// <param name="body">Required parameter: Example: .</param>
        /// <returns>Returns the Models.TransactionResultModel response from the API call.</returns>
        public Models.TransactionResultModel CreateCreditCardAddressVerify2(
                Models.CreditCardTransactionModel body)
        {
            Task<Models.TransactionResultModel> t = this.CreateCreditCardAddressVerify2Async(body);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// Verify the validity of a credit card and billing address. Use this method instead of CreditCardAddressVerify if you want the Address Verify transaction to be imported into ChargeLogic Payments as a part of an order.
        /// </summary>
        /// <param name="body">Required parameter: Example: .</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.TransactionResultModel response from the API call.</returns>
        public async Task<Models.TransactionResultModel> CreateCreditCardAddressVerify2Async(
                Models.CreditCardTransactionModel body,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/CreditCardAddressVerify2");

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "content-type", "application/json; charset=utf-8" },
            };

            // append body params.
            var bodyText = ApiHelper.JsonSerialize(body);

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().PostBody(queryBuilder.ToString(), headers, bodyText);

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.TransactionResultModel>(response.Body);
        }

        /// <summary>
        /// Attempts to release funds held by a prior credit card authorization.
        /// </summary>
        /// <param name="body">Required parameter: Example: .</param>
        /// <returns>Returns the Models.TransactionResultModel response from the API call.</returns>
        public Models.TransactionResultModel CreateCreditCardReverse(
                Models.ReferenceTransactionModel body)
        {
            Task<Models.TransactionResultModel> t = this.CreateCreditCardReverseAsync(body);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// Attempts to release funds held by a prior credit card authorization.
        /// </summary>
        /// <param name="body">Required parameter: Example: .</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.TransactionResultModel response from the API call.</returns>
        public async Task<Models.TransactionResultModel> CreateCreditCardReverseAsync(
                Models.ReferenceTransactionModel body,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/CreditCardReverse");

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "content-type", "application/json; charset=utf-8" },
            };

            // append body params.
            var bodyText = ApiHelper.JsonSerialize(body);

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().PostBody(queryBuilder.ToString(), headers, bodyText);

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.TransactionResultModel>(response.Body);
        }

        /// <summary>
        /// Create a hosted payment record for a credit card authorize transaction.
        /// </summary>
        /// <param name="body">Required parameter: Example: .</param>
        /// <returns>Returns the Models.TransactionResultModel response from the API call.</returns>
        public Models.TransactionResultModel CreateSetupHostedCreditCardAuthorize(
                Models.SetupHostedCreditCardTransactionModel body)
        {
            Task<Models.TransactionResultModel> t = this.CreateSetupHostedCreditCardAuthorizeAsync(body);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// Create a hosted payment record for a credit card authorize transaction.
        /// </summary>
        /// <param name="body">Required parameter: Example: .</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.TransactionResultModel response from the API call.</returns>
        public async Task<Models.TransactionResultModel> CreateSetupHostedCreditCardAuthorizeAsync(
                Models.SetupHostedCreditCardTransactionModel body,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/SetupHostedCreditCardAuthorize");

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "content-type", "application/json; charset=utf-8" },
            };

            // append body params.
            var bodyText = ApiHelper.JsonSerialize(body);

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().PostBody(queryBuilder.ToString(), headers, bodyText);

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.TransactionResultModel>(response.Body);
        }

        /// <summary>
        /// Authorize a credit card.
        /// </summary>
        /// <param name="body">Required parameter: Example: .</param>
        /// <returns>Returns the Models.TransactionResultModel response from the API call.</returns>
        public Models.TransactionResultModel CreateCreditCardAuthorize(
                Models.CreditCardTransactionModel body)
        {
            Task<Models.TransactionResultModel> t = this.CreateCreditCardAuthorizeAsync(body);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// Authorize a credit card.
        /// </summary>
        /// <param name="body">Required parameter: Example: .</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.TransactionResultModel response from the API call.</returns>
        public async Task<Models.TransactionResultModel> CreateCreditCardAuthorizeAsync(
                Models.CreditCardTransactionModel body,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/CreditCardAuthorize");

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "content-type", "application/json; charset=utf-8" },
            };

            // append body params.
            var bodyText = ApiHelper.JsonSerialize(body);

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().PostBody(queryBuilder.ToString(), headers, bodyText);

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.TransactionResultModel>(response.Body);
        }
    }
}