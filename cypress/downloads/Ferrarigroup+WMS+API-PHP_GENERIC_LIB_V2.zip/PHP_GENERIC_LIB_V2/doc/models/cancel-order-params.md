
# Cancel Order Params

cancel order body params

## Structure

`CancelOrderParams`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `opType` | `string` | Required | order type  (IN for inbound, OUT for delivery notice) | getOpType(): string | setOpType(string opType): void |
| `orderYear` | `string` | Required | Year of the order to cancel<br>**Constraints**: *Minimum Length*: `4`, *Maximum Length*: `4` | getOrderYear(): string | setOrderYear(string orderYear): void |
| `orderNum` | `string` | Required | Order number to cancel<br>**Constraints**: *Maximum Length*: `20` | getOrderNum(): string | setOrderNum(string orderNum): void |
| `reasonForCancellation` | `string` | Required | optional description describing the reason why cancellation is asked<br>**Constraints**: *Maximum Length*: `500` | getReasonForCancellation(): string | setReasonForCancellation(string reasonForCancellation): void |

## Example (as JSON)

```json
{
  "op_type": "IN",
  "order_year": "2021",
  "order_num": "ORD2732231",
  "reason_for_cancellation": "Final consignee cancelled the order"
}
```

