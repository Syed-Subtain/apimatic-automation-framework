
# Order Row

order row detail (item level)

## Structure

`OrderRow`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `itemCode` | `string` | Required | sku code<br>**Constraints**: *Maximum Length*: `33` | getItemCode(): string | setItemCode(string itemCode): void |
| `itemSerialNumber` | `string` | Required | serial number<br>**Constraints**: *Maximum Length*: `15` | getItemSerialNumber(): string | setItemSerialNumber(string itemSerialNumber): void |
| `itemQuantity` | `int` | Required | quantity to be received/shipped | getItemQuantity(): int | setItemQuantity(int itemQuantity): void |
| `addfields` | [`AdditionalField[]`](../../doc/models/additional-field.md) | Required | additional fields (item level) | getAddfields(): array | setAddfields(array addfields): void |

## Example (as JSON)

```json
{
  "item_code": "03.2040.4061/69.C496",
  "item_serial_number": "413121",
  "item_quantity": 1,
  "addfields": {
    "fieldname": "PICK_NOTE",
    "fieldvalue": "after hallmarking"
  }
}
```

