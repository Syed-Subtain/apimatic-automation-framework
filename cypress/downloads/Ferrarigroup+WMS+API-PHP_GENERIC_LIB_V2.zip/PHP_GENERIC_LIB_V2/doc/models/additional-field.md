
# Additional Field

couple of key=>value for additional info on the order/item

## Structure

`AdditionalField`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `fieldname` | `string` | Required | field name<br>**Constraints**: *Maximum Length*: `25` | getFieldname(): string | setFieldname(string fieldname): void |
| `fieldvalue` | `string` | Required | field value<br>**Constraints**: *Maximum Length*: `30` | getFieldvalue(): string | setFieldvalue(string fieldvalue): void |

## Example (as JSON)

```json
{
  "fieldname": "PICK_NOTE",
  "fieldvalue": "after hallmarking"
}
```

