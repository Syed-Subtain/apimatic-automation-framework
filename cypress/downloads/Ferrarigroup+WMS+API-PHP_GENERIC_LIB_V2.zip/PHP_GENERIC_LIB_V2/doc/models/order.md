
# Order

## Structure

`Order`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `orderYear` | `string` | Required | - | getOrderYear(): string | setOrderYear(string orderYear): void |
| `orderNumber` | `string` | Required | - | getOrderNumber(): string | setOrderNumber(string orderNumber): void |
| `orderDate` | `string` | Required | - | getOrderDate(): string | setOrderDate(string orderDate): void |
| `companyName` | `string` | Required | supplier/consignee name | getCompanyName(): string | setCompanyName(string companyName): void |
| `companyAddress` | `string` | Required | supplier/consignee address<br>**Constraints**: *Maximum Length*: `140` | getCompanyAddress(): string | setCompanyAddress(string companyAddress): void |
| `companyZip` | `?string` | Optional | supplier/consignee zip code<br>**Constraints**: *Maximum Length*: `9` | getCompanyZip(): ?string | setCompanyZip(?string companyZip): void |
| `companyCity` | `string` | Required | supplier/consignee city<br>**Constraints**: *Maximum Length*: `35` | getCompanyCity(): string | setCompanyCity(string companyCity): void |
| `companyState` | `?string` | Optional | supplier/consignee province/state | getCompanyState(): ?string | setCompanyState(?string companyState): void |
| `companyCountry` | `string` | Required | supplier/consignee country (iso Alpha-2 standard)<br>**Constraints**: *Maximum Length*: `2` | getCompanyCountry(): string | setCompanyCountry(string companyCountry): void |
| `addfields` | [`?AdditionalField`](../../doc/models/additional-field.md) | Optional | Additional fields (order level) | getAddfields(): ?AdditionalField | setAddfields(?AdditionalField addfields): void |
| `orderNote` | `?string` | Optional | Additional note on the order<br>**Constraints**: *Maximum Length*: `80` | getOrderNote(): ?string | setOrderNote(?string orderNote): void |
| `instructions` | `?string` | Optional | order instructions<br>**Constraints**: *Maximum Length*: `80` | getInstructions(): ?string | setInstructions(?string instructions): void |
| `items` | [`OrderRow[]`](../../doc/models/order-row.md) | Required | - | getItems(): array | setItems(array items): void |
| `warehouseArea` | `string` | Required | area of loading/picking<br>**Constraints**: *Maximum Length*: `5` | getWarehouseArea(): string | setWarehouseArea(string warehouseArea): void |

## Example (as JSON)

```json
{
  "order_year": "2019",
  "order_number": "4.19-00814",
  "order_date": "20191119",
  "company_name": "Emard Ltd",
  "company_address": "1555  Echo Lane",
  "company_city": "LEXINGTON",
  "company_country": "US",
  "items": {
    "item_code": "03.2040.4061/69.C496",
    "item_serial_number": "413121",
    "item_quantity": 1,
    "addfields": {
      "fieldname": "PICK_NOTE",
      "fieldvalue": "after hallmarking"
    }
  },
  "warehouse_area": "STOCK"
}
```

