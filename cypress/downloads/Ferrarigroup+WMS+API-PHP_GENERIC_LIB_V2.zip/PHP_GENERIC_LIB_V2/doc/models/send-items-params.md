
# Send Items Params

send items body params

## Structure

`SendItemsParams`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `opType` | `string` | Required | operation type (ADD/DEL/UPD)<br>**Constraints**: *Maximum Length*: `3` | getOpType(): string | setOpType(string opType): void |
| `item` | [`Item`](../../doc/models/item.md) | Required | Item to add | getItem(): Item | setItem(Item item): void |

## Example (as JSON)

```json
{
  "op_type": "ADD",
  "item": {
    "item_code": "XXX0000001",
    "item_description": "golden ring"
  }
}
```

