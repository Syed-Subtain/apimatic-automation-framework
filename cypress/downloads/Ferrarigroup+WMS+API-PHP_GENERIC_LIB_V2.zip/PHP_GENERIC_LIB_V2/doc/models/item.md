
# Item

item master data detail

## Structure

`Item`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `itemCode` | `string` | Required | sku number<br>**Constraints**: *Maximum Length*: `33` | getItemCode(): string | setItemCode(string itemCode): void |
| `itemSerial` | `?string` | Optional | serial number<br>**Constraints**: *Maximum Length*: `15` | getItemSerial(): ?string | setItemSerial(?string itemSerial): void |
| `itemDescription` | `string` | Required | item description<br>**Constraints**: *Maximum Length*: `70` | getItemDescription(): string | setItemDescription(string itemDescription): void |
| `itemCodeAlt1` | `?string` | Optional | alternative key to identify the sku | getItemCodeAlt1(): ?string | setItemCodeAlt1(?string itemCodeAlt1): void |
| `itemCodeAlt2` | `?string` | Optional | alternative key to identify the sku | getItemCodeAlt2(): ?string | setItemCodeAlt2(?string itemCodeAlt2): void |
| `itemCodeEan` | `?string` | Optional | ean code | getItemCodeEan(): ?string | setItemCodeEan(?string itemCodeEan): void |
| `itemSerialType` | `?string` | Optional | Item with serial number (Y/N)<br>**Constraints**: *Maximum Length*: `1` | getItemSerialType(): ?string | setItemSerialType(?string itemSerialType): void |
| `itemStockValue` | `?float` | Optional | Item value in stock (for liability purpose) | getItemStockValue(): ?float | setItemStockValue(?float itemStockValue): void |
| `itemStockCurrency` | `?string` | Optional | currency for item value | getItemStockCurrency(): ?string | setItemStockCurrency(?string itemStockCurrency): void |
| `itemHtsCode` | `?string` | Optional | commodity code | getItemHtsCode(): ?string | setItemHtsCode(?string itemHtsCode): void |
| `cites` | `?string` | Optional | cites | getCites(): ?string | setCites(?string cites): void |
| `mop` | `?string` | Optional | - | getMop(): ?string | setMop(?string mop): void |
| `countryOrigin` | `?string` | Optional | country of origin | getCountryOrigin(): ?string | setCountryOrigin(?string countryOrigin): void |
| `additionalUnit` | `?string` | Optional | additional unit | getAdditionalUnit(): ?string | setAdditionalUnit(?string additionalUnit): void |
| `productFamilyCode` | `?string` | Optional | - | getProductFamilyCode(): ?string | setProductFamilyCode(?string productFamilyCode): void |
| `productFamilyDescription` | `?string` | Optional | - | getProductFamilyDescription(): ?string | setProductFamilyDescription(?string productFamilyDescription): void |
| `itemStyle` | `?string` | Optional | - | getItemStyle(): ?string | setItemStyle(?string itemStyle): void |
| `productTypeCode` | `?string` | Optional | - | getProductTypeCode(): ?string | setProductTypeCode(?string productTypeCode): void |
| `productTypeDescription` | `?string` | Optional | - | getProductTypeDescription(): ?string | setProductTypeDescription(?string productTypeDescription): void |
| `materialTypeCode` | `?string` | Optional | - | getMaterialTypeCode(): ?string | setMaterialTypeCode(?string materialTypeCode): void |
| `materialTypeDescription` | `?string` | Optional | - | getMaterialTypeDescription(): ?string | setMaterialTypeDescription(?string materialTypeDescription): void |
| `materialNetWeight` | `?float` | Optional | - | getMaterialNetWeight(): ?float | setMaterialNetWeight(?float materialNetWeight): void |
| `unitPieces` | `?int` | Optional | - | getUnitPieces(): ?int | setUnitPieces(?int unitPieces): void |
| `dangerous` | `?string` | Optional | - | getDangerous(): ?string | setDangerous(?string dangerous): void |
| `itemUom` | `?string` | Optional | - | getItemUom(): ?string | setItemUom(?string itemUom): void |
| `itemDim1` | `?float` | Optional | - | getItemDim1(): ?float | setItemDim1(?float itemDim1): void |
| `itemDim2` | `?float` | Optional | - | getItemDim2(): ?float | setItemDim2(?float itemDim2): void |
| `itemDim3` | `?float` | Optional | - | getItemDim3(): ?float | setItemDim3(?float itemDim3): void |
| `itemNetWeight` | `?float` | Optional | - | getItemNetWeight(): ?float | setItemNetWeight(?float itemNetWeight): void |
| `itemGrossWeight` | `?float` | Optional | - | getItemGrossWeight(): ?float | setItemGrossWeight(?float itemGrossWeight): void |
| `storageGrossWeight` | `?float` | Optional | - | getStorageGrossWeight(): ?float | setStorageGrossWeight(?float storageGrossWeight): void |
| `itemUnitWeight` | `?string` | Optional | unità misura peso | getItemUnitWeight(): ?string | setItemUnitWeight(?string itemUnitWeight): void |
| `storageDim1` | `?float` | Optional | - | getStorageDim1(): ?float | setStorageDim1(?float storageDim1): void |
| `storageDim2` | `?float` | Optional | - | getStorageDim2(): ?float | setStorageDim2(?float storageDim2): void |
| `storageDim3` | `?float` | Optional | - | getStorageDim3(): ?float | setStorageDim3(?float storageDim3): void |
| `productCategory` | `?string` | Optional | - | getProductCategory(): ?string | setProductCategory(?string productCategory): void |
| `diamondCertificate` | `?string` | Optional | - | getDiamondCertificate(): ?string | setDiamondCertificate(?string diamondCertificate): void |
| `hallmarkingCode` | `?string` | Optional | - | getHallmarkingCode(): ?string | setHallmarkingCode(?string hallmarkingCode): void |
| `hallmarkingDescription` | `?string` | Optional | - | getHallmarkingDescription(): ?string | setHallmarkingDescription(?string hallmarkingDescription): void |

## Example (as JSON)

```json
{
  "item_code": "XXX0000001",
  "item_description": "golden ring"
}
```

