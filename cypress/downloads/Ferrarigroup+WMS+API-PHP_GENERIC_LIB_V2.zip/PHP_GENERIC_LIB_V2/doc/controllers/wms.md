# WMS

```php
$wMSController = $client->getWMSController();
```

## Class Name

`WMSController`

## Methods

* [Create Order](../../doc/controllers/wms.md#create-order)
* [Send Item](../../doc/controllers/wms.md#send-item)
* [Cancel Order](../../doc/controllers/wms.md#cancel-order)


# Create Order

Create a new order for WMS in thewarehouse, also store items data

```php
function createOrder(CreateOrderParams $params): string
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `params` | [`CreateOrderParams`](../../doc/models/create-order-params.md) | Body, Required | Order to place |

## Requires scope

`CREATE_ORDER`

## Response Type

`string`

## Example Usage

```php
$params_opType = 'IN';
$params_order_orderYear = '2019';
$params_order_orderNumber = '4.19-00814';
$params_order_orderDate = '20191119';
$params_order_companyName = 'Emard Ltd';
$params_order_companyAddress = '1555  Echo Lane';
$params_order_companyCity = 'LEXINGTON';
$params_order_companyCountry = 'US';
$params_order_items = [];

$params_order_items_0_itemCode = '03.2040.4061/69.C496';
$params_order_items_0_itemSerialNumber = '413121';
$params_order_items_0_itemQuantity = 1;
$params_order_items_0_addfields = [];

$params_order_items_0_addfields_0_fieldname = 'PICK_NOTE';
$params_order_items_0_addfields_0_fieldvalue = 'after hallmarking';
$params_order_items_0_addfields[0] = new Models\AdditionalField(
    $params_order_items_0_addfields_0_fieldname,
    $params_order_items_0_addfields_0_fieldvalue
);

$params_order_items_0_addfields_1_fieldname = 'PICK_NOTE';
$params_order_items_0_addfields_1_fieldvalue = 'after hallmarking';
$params_order_items_0_addfields[1] = new Models\AdditionalField(
    $params_order_items_0_addfields_1_fieldname,
    $params_order_items_0_addfields_1_fieldvalue
);

$params_order_items[0] = new Models\OrderRow(
    $params_order_items_0_itemCode,
    $params_order_items_0_itemSerialNumber,
    $params_order_items_0_itemQuantity,
    $params_order_items_0_addfields
);

$params_order_items_1_itemCode = '03.2040.4061/69.C496';
$params_order_items_1_itemSerialNumber = '413121';
$params_order_items_1_itemQuantity = 1;
$params_order_items_1_addfields = [];

$params_order_items_1_addfields_0_fieldname = 'PICK_NOTE';
$params_order_items_1_addfields_0_fieldvalue = 'after hallmarking';
$params_order_items_1_addfields[0] = new Models\AdditionalField(
    $params_order_items_1_addfields_0_fieldname,
    $params_order_items_1_addfields_0_fieldvalue
);

$params_order_items_1_addfields_1_fieldname = 'PICK_NOTE';
$params_order_items_1_addfields_1_fieldvalue = 'after hallmarking';
$params_order_items_1_addfields[1] = new Models\AdditionalField(
    $params_order_items_1_addfields_1_fieldname,
    $params_order_items_1_addfields_1_fieldvalue
);

$params_order_items_1_addfields_2_fieldname = 'PICK_NOTE';
$params_order_items_1_addfields_2_fieldvalue = 'after hallmarking';
$params_order_items_1_addfields[2] = new Models\AdditionalField(
    $params_order_items_1_addfields_2_fieldname,
    $params_order_items_1_addfields_2_fieldvalue
);

$params_order_items[1] = new Models\OrderRow(
    $params_order_items_1_itemCode,
    $params_order_items_1_itemSerialNumber,
    $params_order_items_1_itemQuantity,
    $params_order_items_1_addfields
);

$params_order_warehouseArea = 'STOCK';
$params_order = new Models\Order(
    $params_order_orderYear,
    $params_order_orderNumber,
    $params_order_orderDate,
    $params_order_companyName,
    $params_order_companyAddress,
    $params_order_companyCity,
    $params_order_companyCountry,
    $params_order_items,
    $params_order_warehouseArea
);
$params = new Models\CreateOrderParams(
    $params_opType,
    $params_order
);

$result = $wMSController->createOrder($params);
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 403 | Forbidden | `ApiException` |


# Send Item

```php
function sendItem(SendItemsParams $params): string
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `params` | [`SendItemsParams`](../../doc/models/send-items-params.md) | Body, Required | - |

## Requires scope

`SEND_ITEM`

## Response Type

`string`

## Example Usage

```php
$params_opType = 'ADD';
$params_item_itemCode = 'XXX0000001';
$params_item_itemDescription = 'golden ring';
$params_item = new Models\Item(
    $params_item_itemCode,
    $params_item_itemDescription
);
$params = new Models\SendItemsParams(
    $params_opType,
    $params_item
);

$result = $wMSController->sendItem($params);
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 403 | Forbidden | `ApiException` |


# Cancel Order

Send a request of cancellation for a previously added order. The cancellation will be subject to conditions agreed with Ferrari. The response to this method is meant as a formal response (OK -> your request has been successfully submitted), but it does not imply the cancellation has been done.

```php
function cancelOrder(CancelOrderParams $params): string
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `params` | [`CancelOrderParams`](../../doc/models/cancel-order-params.md) | Body, Required | Order to cancel |

## Requires scope

`CANCEL_ORDER`

## Response Type

`string`

## Example Usage

```php
$params_opType = 'IN';
$params_orderYear = '2021';
$params_orderNum = 'ORD2732231';
$params_reasonForCancellation = 'Final consignee cancelled the order';
$params = new Models\CancelOrderParams(
    $params_opType,
    $params_orderYear,
    $params_orderNum,
    $params_reasonForCancellation
);

$result = $wMSController->cancelOrder($params);
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 403 | Forbidden | `ApiException` |

