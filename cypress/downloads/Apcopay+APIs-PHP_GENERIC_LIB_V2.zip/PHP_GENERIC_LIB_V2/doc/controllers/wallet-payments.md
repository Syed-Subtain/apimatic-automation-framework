# Wallet Payments

```php
$walletPaymentsController = $client->getWalletPaymentsController();
```

## Class Name

`WalletPaymentsController`


# Google Pay API

Send ApcoPay the encrypted payment token from Google Pay for Payment Processing

```php
function googlePayAPI(string $contentType, GooglePayDepositRequest $body): GooglePayDepositResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `contentType` | `string` | Header, Required | - |
| `body` | [`GooglePayDepositRequest`](../../doc/models/google-pay-deposit-request.md) | Body, Required | - |

## Response Type

[`GooglePayDepositResponse`](../../doc/models/google-pay-deposit-response.md)

## Example Usage

```php
$contentType = 'application/json';
$body_merchID = '7561';
$body_regName = 'John Doe';
$body_currencyCode = '978';
$body_amount = '1.0';
$body_oRef = 'OREF1';
$body_clientAcc = 'neil';
$body_address = 'street,city,state,zip';
$body_regCountry = 'MT';
$body_walletProvider = 'GOOGLEPAY';
$body_walletToken = '1234';
$body_userIP = '1.1.1.1';
$body_signature = 'e0c806954dc75c9e6b801e9676181b9ad455f3a36a69fa672b162ead727962a4';
$body_redirectionURL = 'https://mywebsite.com/return';
$body_statusUrl = 'https://mywebsite.com/callback';
$body = new Models\GooglePayDepositRequest(
    $body_merchID,
    $body_regName,
    $body_currencyCode,
    $body_amount,
    $body_oRef,
    $body_clientAcc,
    $body_address,
    $body_regCountry,
    $body_walletProvider,
    $body_walletToken,
    $body_userIP,
    $body_signature,
    $body_redirectionURL,
    $body_statusUrl
);

$result = $walletPaymentsController->googlePayAPI($contentType, $body);
```

