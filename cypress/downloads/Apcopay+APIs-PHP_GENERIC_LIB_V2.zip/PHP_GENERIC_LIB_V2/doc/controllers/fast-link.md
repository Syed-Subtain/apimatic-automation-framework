# Fast Link

```php
$fastLinkController = $client->getFastLinkController();
```

## Class Name

`FastLinkController`


# Generate Fast Link

```php
function generateFastLink(GenerateFastLinkRequest $body): void
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`GenerateFastLinkRequest`](../../doc/models/generate-fast-link-request.md) | Body, Required | - |

## Response Type

`void`

## Example Usage

```php
$body_mchCode = '1111';
$body_merchnatPassword = 'MCHPASS';
$body_orderRef = 'testFLGen';
$body_description = 'Testing';
$body_currency = 'EUR';
$body_amount = '19';
$body_validUntil = '2019/11/14';
$body_notificationURL = '';
$body_eXTRADATA = '';
$body_actionType = 1;
$body_name = 'tester';
$body_surname = 'testing';
$body_email = 'test@test.com';
$body_mobileNumber = '99887788';
$body_showTermsAndConditions = true;
$body = new Models\GenerateFastLinkRequest(
    $body_mchCode,
    $body_merchnatPassword,
    $body_orderRef,
    $body_description,
    $body_currency,
    $body_amount,
    $body_validUntil,
    $body_notificationURL,
    $body_eXTRADATA,
    $body_actionType,
    $body_name,
    $body_surname,
    $body_email,
    $body_mobileNumber,
    $body_showTermsAndConditions
);

$fastLinkController->generateFastLink($body);
```

