# SOAP Requests

```php
$sOAPRequestsController = $client->getSOAPRequestsController();
```

## Class Name

`SOAPRequestsController`

## Methods

* [Card Tokenization](../../doc/controllers/soap-requests.md#card-tokenization)
* [Do Transaction](../../doc/controllers/soap-requests.md#do-transaction)
* [Do 3 D Secure Transaction](../../doc/controllers/soap-requests.md#do-3-d-secure-transaction)
* [Get 3 DS Transaction Status](../../doc/controllers/soap-requests.md#get-3-ds-transaction-status)


# Card Tokenization

```php
function cardTokenization(Envelope $body): void
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`Envelope`](../../doc/models/envelope.md) | Body, Required | - |

## Response Type

`void`

## Example Usage

```php
$body_body_populateTransactionData2_merchID = 5299;
$body_body_populateTransactionData2_password = 1234;
$body_body_populateTransactionData2_cardType = 'VISA';
$body_body_populateTransactionData2_cardNo = 4711100000000000;
$body_body_populateTransactionData2_expMonth = '01';
$body_body_populateTransactionData2_expYear = 2020;
$body_body_populateTransactionData2_ext = 123;
$body_body_populateTransactionData2_cardHolderName = 'APCO TEST';
$body_body_populateTransactionData2_cardHolderAddress = 'Malad Mindspace';
$body_body_populateTransactionData2_cardIssueNum = '';
$body_body_populateTransactionData2_cardStartMonth = '';
$body_body_populateTransactionData2_cardStartYear = '';
$body_body_populateTransactionData2_pspID = '';
$body_body_populateTransactionData2 = new Models\PopulateTransactionData2(
    $body_body_populateTransactionData2_merchID,
    $body_body_populateTransactionData2_password,
    $body_body_populateTransactionData2_cardType,
    $body_body_populateTransactionData2_cardNo,
    $body_body_populateTransactionData2_expMonth,
    $body_body_populateTransactionData2_expYear,
    $body_body_populateTransactionData2_ext,
    $body_body_populateTransactionData2_cardHolderName,
    $body_body_populateTransactionData2_cardHolderAddress,
    $body_body_populateTransactionData2_cardIssueNum,
    $body_body_populateTransactionData2_cardStartMonth,
    $body_body_populateTransactionData2_cardStartYear,
    $body_body_populateTransactionData2_pspID
);
$body_body = new Models\Body(
    $body_body_populateTransactionData2
);
$body = new Models\Envelope(
    $body_body
);

$sOAPRequestsController->cardTokenization($body);
```


# Do Transaction

```php
function doTransaction(Envelope2 $body): void
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`Envelope2`](../../doc/models/envelope-2.md) | Body, Required | - |

## Response Type

`void`

## Example Usage

```php
$body_body_doTransaction_merchID = 7561;
$body_body_doTransaction_pass = 'testkey';
$body_body_doTransaction_trType = 1;
$body_body_doTransaction_cardNum = 4444444444444444;
$body_body_doTransaction_cVV2 = 512;
$body_body_doTransaction_expDay = '06';
$body_body_doTransaction_expMonth = '06';
$body_body_doTransaction_expYear = 2021;
$body_body_doTransaction_cardHName = 'Apco Test';
$body_body_doTransaction_amount = 17.88;
$body_body_doTransaction_currencyCode = 978;
$body_body_doTransaction_addr = '1, main street, town, country, code';
$body_body_doTransaction_postCode = 3243224;
$body_body_doTransaction_transID = 'string';
$body_body_doTransaction_userIP = '78.133.117.182';
$body_body_doTransaction_uDF1 = 'string';
$body_body_doTransaction_uDF2 = 'CT=TESTCARD';
$body_body_doTransaction_uDF3 = '<WS><Email>test@apco.com</Email>vL5yuV6X1UiHKC<CIP>1.1.1.1</CIP></WS>';
$body_body_doTransaction_orderRef = 'string';
$body_body_doTransaction = new Models\DoTransaction(
    $body_body_doTransaction_merchID,
    $body_body_doTransaction_pass,
    $body_body_doTransaction_trType,
    $body_body_doTransaction_cardNum,
    $body_body_doTransaction_cVV2,
    $body_body_doTransaction_expDay,
    $body_body_doTransaction_expMonth,
    $body_body_doTransaction_expYear,
    $body_body_doTransaction_cardHName,
    $body_body_doTransaction_amount,
    $body_body_doTransaction_currencyCode,
    $body_body_doTransaction_addr,
    $body_body_doTransaction_postCode,
    $body_body_doTransaction_transID,
    $body_body_doTransaction_userIP,
    $body_body_doTransaction_uDF1,
    $body_body_doTransaction_uDF2,
    $body_body_doTransaction_uDF3,
    $body_body_doTransaction_orderRef
);
$body_body = new Models\Body2(
    $body_body_doTransaction
);
$body = new Models\Envelope2(
    $body_body
);

$sOAPRequestsController->doTransaction($body);
```


# Do 3 D Secure Transaction

```php
function do3DSecureTransaction(Envelope3 $body): void
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`Envelope3`](../../doc/models/envelope-3.md) | Body, Required | - |

## Response Type

`void`

## Example Usage

```php
$body_body_do3DSTransaction_merchID = 7561;
$body_body_do3DSTransaction_merchPassword = 'test key';
$body_body_do3DSTransaction_trType = 1;
$body_body_do3DSTransaction_cardNum = 4444444444442228;
$body_body_do3DSTransaction_cVV2 = 123;
$body_body_do3DSTransaction_expDay = '01';
$body_body_do3DSTransaction_expMonth = '01';
$body_body_do3DSTransaction_expYear = 2025;
$body_body_do3DSTransaction_cardHName = 'Apco Tesr';
$body_body_do3DSTransaction_amount = 49.94;
$body_body_do3DSTransaction_currencyCode = 978;
$body_body_do3DSTransaction_addr = 'string';
$body_body_do3DSTransaction_postCode = 'string';
$body_body_do3DSTransaction_transID = 'string';
$body_body_do3DSTransaction_userIP = 'string';
$body_body_do3DSTransaction_uDF1 = 'string';
$body_body_do3DSTransaction_uDF2 = 'string';
$body_body_do3DSTransaction_uDF3 = '%3CWS%3E%3CForceBank%3EPTEST%3C%2FForceBank%3E%3C%2FWS%3E';
$body_body_do3DSTransaction_orderRef = 'string';
$body_body_do3DSTransaction = new Models\Do3DSTransaction(
    $body_body_do3DSTransaction_merchID,
    $body_body_do3DSTransaction_merchPassword,
    $body_body_do3DSTransaction_trType,
    $body_body_do3DSTransaction_cardNum,
    $body_body_do3DSTransaction_cVV2,
    $body_body_do3DSTransaction_expDay,
    $body_body_do3DSTransaction_expMonth,
    $body_body_do3DSTransaction_expYear,
    $body_body_do3DSTransaction_cardHName,
    $body_body_do3DSTransaction_amount,
    $body_body_do3DSTransaction_currencyCode,
    $body_body_do3DSTransaction_addr,
    $body_body_do3DSTransaction_postCode,
    $body_body_do3DSTransaction_transID,
    $body_body_do3DSTransaction_userIP,
    $body_body_do3DSTransaction_uDF1,
    $body_body_do3DSTransaction_uDF2,
    $body_body_do3DSTransaction_uDF3,
    $body_body_do3DSTransaction_orderRef
);
$body_body = new Models\Body3(
    $body_body_do3DSTransaction
);
$body = new Models\Envelope3(
    $body_body
);

$sOAPRequestsController->do3DSecureTransaction($body);
```


# Get 3 DS Transaction Status

```php
function get3DSTransactionStatus(Envelope1 $body): void
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`Envelope1`](../../doc/models/envelope-1.md) | Body, Required | - |

## Response Type

`void`

## Example Usage

```php
$body_body_get3DSTransactionStatus_mCHCode = 8493;
$body_body_get3DSTransactionStatus_mCHPass = 'testkey';
$body_body_get3DSTransactionStatus_ticket3D = 'f0b47e3a36444eed93f4811d99dd7f6b';
$body_body_get3DSTransactionStatus = new Models\Get3DSTransactionStatus(
    $body_body_get3DSTransactionStatus_mCHCode,
    $body_body_get3DSTransactionStatus_mCHPass,
    $body_body_get3DSTransactionStatus_ticket3D
);
$body_body = new Models\Body1(
    $body_body_get3DSTransactionStatus
);
$body = new Models\Envelope1(
    $body_body
);

$sOAPRequestsController->get3DSTransactionStatus($body);
```

