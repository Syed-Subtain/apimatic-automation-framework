# REST Calls

```php
$rESTCallsController = $client->getRESTCallsController();
```

## Class Name

`RESTCallsController`

## Methods

* [Get Last Card Numbers](../../doc/controllers/rest-calls.md#get-last-card-numbers)
* [Build XML Token](../../doc/controllers/rest-calls.md#build-xml-token)
* [Get Transaction Status](../../doc/controllers/rest-calls.md#get-transaction-status)
* [Compute Hash](../../doc/controllers/rest-calls.md#compute-hash)
* [Get Cards Used by Account](../../doc/controllers/rest-calls.md#get-cards-used-by-account)
* [Get Daily Transactions](../../doc/controllers/rest-calls.md#get-daily-transactions)
* [Get Transactions by Oref](../../doc/controllers/rest-calls.md#get-transactions-by-oref)
* [Get Transactions XML Response](../../doc/controllers/rest-calls.md#get-transactions-xml-response)


# Get Last Card Numbers

```php
function getLastCardNumbers(GetLastCardNumbersRequest $body): void
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`GetLastCardNumbersRequest`](../../doc/models/get-last-card-numbers-request.md) | Body, Required | - |

## Response Type

`void`

## Example Usage

```php
$body_merchID = '7561';
$body_merchPass = 'testkey';
$body_clientAccount = 'UserTesting';
$body = new Models\GetLastCardNumbersRequest(
    $body_merchID,
    $body_merchPass,
    $body_clientAccount
);

$rESTCallsController->getLastCardNumbers($body);
```


# Build XML Token

fngf

```php
function buildXMLToken(BuildXMLTokenRequest $body): BuildTokenResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`BuildXMLTokenRequest`](../../doc/models/build-xml-token-request.md) | Body, Required | - |

## Response Type

[`BuildTokenResponse`](../../doc/models/build-token-response.md)

## Example Usage

```php
$body_merchID = '7561';
$body_merchPass = 'apcotest';
$body_xMLParam = '<Transaction hash="TestKey"><ProfileID>F26C4BD40A454028A8F9E85806A6395C</ProfileID><Value>1.00</Value><Curr>978</Curr><Lang>en</Lang><ORef>30082021131002740</ORef><ClientAcc>Test</ClientAcc><MobileNo>03569988451</MobileNo><Email>joedoe@mail.com</Email><RedirectionURL>https://www.google.com/thankyoupage.html</RedirectionURL><UDF1 /><UDF2 /><UDF3 /><FastPay><ListAllCards>ALL</ListAllCards><NewCard1Try /><NewCardOnFail /><PromptCVV /><PromptExpiry /></FastPay><ActionType>4</ActionType><status_url urlEncode="true">https://www.google.com</status_url><HideSSLLogo></HideSSLLogo><AntiFraud><Provider></Provider></AntiFraud><return_pspid></return_pspid><ForceBank>PTEST</ForceBank><ByPass3ds /><ForcePayment>TESTCARD</ForcePayment></Transaction>';
$body = new Models\BuildXMLTokenRequest(
    $body_merchID,
    $body_merchPass,
    $body_xMLParam
);

$result = $rESTCallsController->buildXMLToken($body);
```


# Get Transaction Status

```php
function getTransactionStatus(GetTransactionStatusRequest $body): GetTransactionStatusResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`GetTransactionStatusRequest`](../../doc/models/get-transaction-status-request.md) | Body, Required | - |

## Response Type

[`GetTransactionStatusResponse`](../../doc/models/get-transaction-status-response.md)

## Example Usage

```php
$body_merchID = 'MerchID';
$body_merchPass = 'MerhcPass';
$body_oref = 'TestReference01';
$body = new Models\GetTransactionStatusRequest(
    $body_merchID,
    $body_merchPass,
    $body_oref
);

$result = $rESTCallsController->getTransactionStatus($body);
```

## Example Response *(as JSON)*

```json
{
  "Result": "OK",
  "ErrorMsg": "",
  "Responses": "[{\"Response\":\"%3cTransactionResult%3e%3cORef%3eTestReference01%3c%2fORef%3e%3cResult%3eCAPTURED%3c%2fResult%3e%3cAuthCode%3eTEST%3c%2fAuthCode%3e%3cCardInput%3eList%3c%2fCardInput%3e%3cpspid%3e138145656%3c%2fpspid%3e%3cStatus3DS%3eG%3c%2fStatus3DS%3e%3cCurrency%3eEUR%3c%2fCurrency%3e%3cValue%3e1.0000%3c%2fValue%3e%3cExtendedData%3e%3cCardNum%3e444444%2c2228%3c%2fCardNum%3e%3cCardHName%3ea+a%3c%2fCardHName%3e%3cAcq%3ePTEST%3c%2fAcq%3e%3cSource%3ePTEST%3c%2fSource%3e%3c%2fExtendedData%3e%3cCardCountry%3ePOL%3c%2fCardCountry%3e%3cCardType%3e%3c%2fCardType%3e%3cEmail%3esupport%40apcolabs.tech%3c%2fEmail%3e%3cUDF1%3e3DS+Process%3c%2fUDF1%3e%3cUDF2%3eUDF2%3d%2cCT%3dTESTCARD%2c%3c%2fUDF2%3e%3c%2fTransactionResult%3e\"}]"
}
```


# Compute Hash

```php
function computeHash(ComputeHashRequest $body): ComputeHashResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`ComputeHashRequest`](../../doc/models/compute-hash-request.md) | Body, Required | - |

## Response Type

[`ComputeHashResponse`](../../doc/models/compute-hash-response.md)

## Example Usage

```php
$body_merchID = 'MerchID';
$body_merchPass = 'MerchPass';
$body_xMLParam = '<Transaction hash="password"><ProfileID>A803B8D2A9F6F</ProfileID><ActionType>1</ActionType><Value>1.00</Value><Curr>978</Curr><Lang>en</Lang><ORef>TestReference01</ORef><Email>support@apcolabs.tech</Email><UDF1 /><UDF2 /><UDF3 /><RedirectionURL>https://www.apsp.biz/pay/PaymentOptionsTests/Redirect</RedirectionURL><status_url urlEncode="True">https://www.apsp.biz/pay/TestFp/TestListener.aspx</status_url><ForceBank>PTESTv2</ForceBank><ForcePayment>MBKR</ForcePayment><TEST /><MainAcquirer>DIRECT</MainAcquirer></Transaction>';
$body = new Models\ComputeHashRequest(
    $body_merchID,
    $body_merchPass,
    $body_xMLParam
);

$result = $rESTCallsController->computeHash($body);
```


# Get Cards Used by Account

```php
function getCardsUsedByAccount(GetCardsUsedByAccountRequest $body): void
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`GetCardsUsedByAccountRequest`](../../doc/models/get-cards-used-by-account-request.md) | Body, Required | - |

## Response Type

`void`

## Example Usage

```php
$body_merchID = '7561';
$body_merchPass = 'testkey';
$body_clientAccount = 'neil';
$body = new Models\GetCardsUsedByAccountRequest(
    $body_merchID,
    $body_merchPass,
    $body_clientAccount
);

$rESTCallsController->getCardsUsedByAccount($body);
```


# Get Daily Transactions

```php
function getDailyTransactions(GetDailyTransactionsRequest $body): void
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`GetDailyTransactionsRequest`](../../doc/models/get-daily-transactions-request.md) | Body, Required | - |

## Response Type

`void`

## Example Usage

```php
$body_merchID = 'MerchID';
$body_merchPass = 'MerchPass';
$body_date = '20201009';
$body = new Models\GetDailyTransactionsRequest(
    $body_merchID,
    $body_merchPass,
    $body_date
);

$rESTCallsController->getDailyTransactions($body);
```


# Get Transactions by Oref

```php
function getTransactionsByOref(GetTransactionsByOrefRequest $body): void
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`GetTransactionsByOrefRequest`](../../doc/models/get-transactions-by-oref-request.md) | Body, Required | - |

## Response Type

`void`

## Example Usage

```php
$body_merchID = 'MerchID';
$body_merchPass = 'MerchPass';
$body_oref = 'TestReference01';
$body = new Models\GetTransactionsByOrefRequest(
    $body_merchID,
    $body_merchPass,
    $body_oref
);

$rESTCallsController->getTransactionsByOref($body);
```


# Get Transactions XML Response

```php
function getTransactionsXMLResponse(GetTransactionsXMLResponseRequest $body): GetTransactionsXMLResponseRequest
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`GetTransactionsXMLResponseRequest`](../../doc/models/get-transactions-xml-response-request.md) | Body, Required | - |

## Response Type

[`GetTransactionsXMLResponseRequest`](../../doc/models/get-transactions-xml-response-request.md)

## Example Usage

```php
$body_merchID = '7561';
$body_merchPass = 'apcotest34';
$body_oref = 'TestReference01';
$body = new Models\GetTransactionsXMLResponseRequest(
    $body_merchID,
    $body_merchPass,
    $body_oref
);

$result = $rESTCallsController->getTransactionsXMLResponse($body);
```

