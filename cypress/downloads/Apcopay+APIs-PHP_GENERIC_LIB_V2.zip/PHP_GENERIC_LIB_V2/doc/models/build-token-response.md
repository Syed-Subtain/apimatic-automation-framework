
# Build Token Response

Returned Response of Build XML Token Request

## Structure

`BuildTokenResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `result` | `string` | Required | Return Result for the Build Payment Token | getResult(): string | setResult(string result): void |
| `baseURL` | `string` | Required | Base URL for Payment Page | getBaseURL(): string | setBaseURL(string baseURL): void |
| `errorMsg` | `string` | Required | Error Message for Build Token | getErrorMsg(): string | setErrorMsg(string errorMsg): void |
| `token` | `string` | Required | Token for the Transaction Request - Append to BaseURL and Return User to complete payment | getToken(): string | setToken(string token): void |

## Example (as JSON)

```json
{
  "Result": "OK",
  "ErrorMsg": "",
  "BaseURL": "https://www.apsp.biz/pay/FP6/Checkout.aspx?FPToken=",
  "Token": "3295BCEE70AC44B0AAFBC92947CD8E98"
}
```

