
# Get Last Card Numbers Request

Get List of Card Numbers used by Client Account

## Structure

`GetLastCardNumbersRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `merchID` | `string` | Required | APCOPAY Merchant ID | getMerchID(): string | setMerchID(string merchID): void |
| `merchPass` | `string` | Required | APCOPAY Merchant Password | getMerchPass(): string | setMerchPass(string merchPass): void |
| `clientAccount` | `string` | Required | Registered Client Account | getClientAccount(): string | setClientAccount(string clientAccount): void |

## Example (as JSON)

```json
{
  "MerchID": "7561",
  "MerchPass": "testkey",
  "ClientAccount": "UserTesting"
}
```

