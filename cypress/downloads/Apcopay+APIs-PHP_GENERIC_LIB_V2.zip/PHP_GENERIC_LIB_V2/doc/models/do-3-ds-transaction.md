
# Do 3 DS Transaction

## Structure

`Do3DSTransaction`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `merchID` | `int` | Required | - | getMerchID(): int | setMerchID(int merchID): void |
| `merchPassword` | `string` | Required | - | getMerchPassword(): string | setMerchPassword(string merchPassword): void |
| `trType` | `int` | Required | - | getTrType(): int | setTrType(int trType): void |
| `cardNum` | `int` | Required | - | getCardNum(): int | setCardNum(int cardNum): void |
| `cVV2` | `int` | Required | - | getCVV2(): int | setCVV2(int cVV2): void |
| `expDay` | `string` | Required | - | getExpDay(): string | setExpDay(string expDay): void |
| `expMonth` | `string` | Required | - | getExpMonth(): string | setExpMonth(string expMonth): void |
| `expYear` | `int` | Required | - | getExpYear(): int | setExpYear(int expYear): void |
| `cardHName` | `string` | Required | - | getCardHName(): string | setCardHName(string cardHName): void |
| `amount` | `float` | Required | - | getAmount(): float | setAmount(float amount): void |
| `currencyCode` | `int` | Required | - | getCurrencyCode(): int | setCurrencyCode(int currencyCode): void |
| `addr` | `string` | Required | - | getAddr(): string | setAddr(string addr): void |
| `postCode` | `string` | Required | - | getPostCode(): string | setPostCode(string postCode): void |
| `transID` | `string` | Required | - | getTransID(): string | setTransID(string transID): void |
| `userIP` | `string` | Required | - | getUserIP(): string | setUserIP(string userIP): void |
| `uDF1` | `string` | Required | - | getUDF1(): string | setUDF1(string uDF1): void |
| `uDF2` | `string` | Required | - | getUDF2(): string | setUDF2(string uDF2): void |
| `uDF3` | `string` | Required | - | getUDF3(): string | setUDF3(string uDF3): void |
| `orderRef` | `string` | Required | - | getOrderRef(): string | setOrderRef(string orderRef): void |

## Example (as XML)

```xml
<Do3DSTransaction>
  <MerchID>122</MerchID>
  <MerchPassword>MerchPassword0</MerchPassword>
  <TrType>48</TrType>
  <CardNum>214</CardNum>
  <CVV2>226</CVV2>
  <ExpDay>ExpDay0</ExpDay>
  <ExpMonth>ExpMonth2</ExpMonth>
  <ExpYear>18</ExpYear>
  <CardHName>CardHName4</CardHName>
  <Amount>57.88</Amount>
  <CurrencyCode>22</CurrencyCode>
  <Addr>Addr4</Addr>
  <PostCode>PostCode4</PostCode>
  <TransID>TransID2</TransID>
  <UserIP>UserIP6</UserIP>
  <UDF1>UDF16</UDF1>
  <UDF2>UDF26</UDF2>
  <UDF3>UDF38</UDF3>
  <OrderRef>OrderRef0</OrderRef>
</Do3DSTransaction>
```

