
# Populate Transaction Data 2

Tokenize Card Request

## Structure

`PopulateTransactionData2`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `merchID` | `int` | Required | APCOPAY Merchant ID | getMerchID(): int | setMerchID(int merchID): void |
| `password` | `int` | Required | APCOPAY Merchant Password | getPassword(): int | setPassword(int password): void |
| `cardType` | `string` | Required | Card Type | getCardType(): string | setCardType(string cardType): void |
| `cardNo` | `int` | Required | Card Number | getCardNo(): int | setCardNo(int cardNo): void |
| `expMonth` | `string` | Required | Expiry Month | getExpMonth(): string | setExpMonth(string expMonth): void |
| `expYear` | `int` | Required | Expiry Year | getExpYear(): int | setExpYear(int expYear): void |
| `ext` | `int` | Required | Card Verification Code (CVV) | getExt(): int | setExt(int ext): void |
| `cardHolderName` | `string` | Required | Card Holder Name | getCardHolderName(): string | setCardHolderName(string cardHolderName): void |
| `cardHolderAddress` | `string` | Required | Card Holder Address | getCardHolderAddress(): string | setCardHolderAddress(string cardHolderAddress): void |
| `cardIssueNum` | `string` | Required | - | getCardIssueNum(): string | setCardIssueNum(string cardIssueNum): void |
| `cardStartMonth` | `string` | Required | - | getCardStartMonth(): string | setCardStartMonth(string cardStartMonth): void |
| `cardStartYear` | `string` | Required | - | getCardStartYear(): string | setCardStartYear(string cardStartYear): void |
| `pspID` | `string` | Required | - | getPspID(): string | setPspID(string pspID): void |

## Example (as XML)

```xml
<PopulateTransactionData2>
  <MerchID>122</MerchID>
  <Password>184</Password>
  <CardType>CardType8</CardType>
  <CardNo>140</CardNo>
  <ExpMonth>ExpMonth2</ExpMonth>
  <ExpYear>18</ExpYear>
  <Ext>248</Ext>
  <CardHolderName>CardHolderName8</CardHolderName>
  <CardHolderAddress>CardHolderAddress0</CardHolderAddress>
  <CardIssueNum>CardIssueNum0</CardIssueNum>
  <CardStartMonth>CardStartMonth4</CardStartMonth>
  <CardStartYear>CardStartYear2</CardStartYear>
  <PspID>PspID0</PspID>
</PopulateTransactionData2>
```

