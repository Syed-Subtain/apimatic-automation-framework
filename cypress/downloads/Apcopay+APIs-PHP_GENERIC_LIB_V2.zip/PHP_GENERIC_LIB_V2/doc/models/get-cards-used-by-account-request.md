
# Get Cards Used by Account Request

## Structure

`GetCardsUsedByAccountRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `merchID` | `string` | Required | - | getMerchID(): string | setMerchID(string merchID): void |
| `merchPass` | `string` | Required | - | getMerchPass(): string | setMerchPass(string merchPass): void |
| `clientAccount` | `string` | Required | - | getClientAccount(): string | setClientAccount(string clientAccount): void |

## Example (as JSON)

```json
{
  "MerchID": "7561",
  "MerchPass": "testkey",
  "ClientAccount": "neil"
}
```

