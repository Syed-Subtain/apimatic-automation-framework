
# Google Pay Deposit Request

Google Pay Deposit Payload Request

## Structure

`GooglePayDepositRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `merchID` | `string` | Required | APCOPAY Merchant ID | getMerchID(): string | setMerchID(string merchID): void |
| `regName` | `string` | Required | Card Holder Name | getRegName(): string | setRegName(string regName): void |
| `currencyCode` | `string` | Required | Transaction Currency Code 3 Digit ISO Code | getCurrencyCode(): string | setCurrencyCode(string currencyCode): void |
| `amount` | `string` | Required | Transaction Value | getAmount(): string | setAmount(string amount): void |
| `oRef` | `string` | Required | Merchant Payment Reference | getORef(): string | setORef(string oRef): void |
| `clientAcc` | `string` | Required | The user's registered account on website. The client account is mandatory if additional functionality such of restrictions of cards per account is used for the payment request. | getClientAcc(): string | setClientAcc(string clientAcc): void |
| `address` | `string` | Required | The user's full address in the format of House No, Street, City,ZIP, State. Values to be separated by comma. All values must be filled in. | getAddress(): string | setAddress(string address): void |
| `regCountry` | `string` | Required | The user's registration country. Use the 2 letter country code. | getRegCountry(): string | setRegCountry(string regCountry): void |
| `walletProvider` | `string` | Required | Wallet Provider - GOOGLEPAY/APPLEPAY | getWalletProvider(): string | setWalletProvider(string walletProvider): void |
| `walletToken` | `string` | Required | Encrypted Payment Token Received from Wallet Provider | getWalletToken(): string | setWalletToken(string walletToken): void |
| `userIP` | `string` | Required | The user's IP Address | getUserIP(): string | setUserIP(string userIP): void |
| `signature` | `string` | Required | Sha256 calculation of alphabetically sorted values of Address & Amount & ClientAcc & CurrencyCode & CardHName & MerchId &  ORef & UserIP & MerchPass | getSignature(): string | setSignature(string signature): void |
| `redirectionURL` | `string` | Required | Redirection URL for the user to be redirected after 3DSecure Authentication | getRedirectionURL(): string | setRedirectionURL(string redirectionURL): void |
| `statusUrl` | `string` | Required | Call back URL to receive asynchronous response for 3DSecure transactions after payment and authentication are completed | getStatusUrl(): string | setStatusUrl(string statusUrl): void |

## Example (as JSON)

```json
{
  "MerchID": "7561",
  "RegName": "John Doe",
  "CurrencyCode": "978",
  "Amount": "1.0",
  "ORef": "OREF1",
  "ClientAcc": "neil",
  "Address": "street,city,state,zip",
  "RegCountry": "MT",
  "WalletProvider": "GOOGLEPAY",
  "WalletToken": "1234",
  "UserIP": "1.1.1.1",
  "Status_url": "https://mywebsite.com/callback",
  "RedirectionURL": "https://mywebsite.com/return",
  "Signature": "e0c806954dc75c9e6b801e9676181b9ad455f3a36a69fa672b162ead727962a4"
}
```

