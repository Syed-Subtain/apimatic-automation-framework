
# Body 1

## Structure

`Body1`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `get3DSTransactionStatus` | [`Get3DSTransactionStatus`](../../doc/models/get-3-ds-transaction-status.md) | Required | - | getGet3DSTransactionStatus(): Get3DSTransactionStatus | setGet3DSTransactionStatus(Get3DSTransactionStatus get3DSTransactionStatus): void |

## Example (as XML)

```xml
<soap:Body xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">
  <get3DSTransactionStatus>
    <MCHCode>172</MCHCode>
    <MCHPass>MCHPass8</MCHPass>
    <Ticket3D>00001426-0000-0000-0000-000000000000</Ticket3D>
  </get3DSTransactionStatus>
</soap:Body>
```

