
# Get Transactions by Oref Request

Get Transaction Details of Merchant Order Reference Used in Transaction Request

## Structure

`GetTransactionsByOrefRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `merchID` | `string` | Required | APCOPAY Merchant ID | getMerchID(): string | setMerchID(string merchID): void |
| `merchPass` | `string` | Required | APCOPAY Merchant Password | getMerchPass(): string | setMerchPass(string merchPass): void |
| `oref` | `string` | Required | Merchant Order Reference | getOref(): string | setOref(string oref): void |

## Example (as JSON)

```json
{
  "MerchID": "MerchID",
  "MerchPass": "MerchPass",
  "Oref": "TestReference01"
}
```

