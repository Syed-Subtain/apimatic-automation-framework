
# Compute Hash Response

## Structure

`ComputeHashResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `result` | `string` | Required | Return Result for the Compute Hash Request | getResult(): string | setResult(string result): void |
| `errorMsg` | `string` | Required | Error Message for Compute Hash Method | getErrorMsg(): string | setErrorMsg(string errorMsg): void |
| `hashedXML` | `string` | Required | Full XML with Hash Result | getHashedXML(): string | setHashedXML(string hashedXML): void |

## Example (as JSON)

```json
{
  "Result": "OK",
  "ErrorMsg": null,
  "HashedXML": "%3cTransaction+hash%3d%2280f594aad166c041e82430547ae6c1b1%22%3e%3cProfileID%3eA803B8D2A9F6F%3c%2fProfileID%3e%3cActionType%3e1%3c%2fActionType%3e%3cValue%3e1.00%3c%2fValue%3e%3cCurr%3e978%3c%2fCurr%3e%3cLang%3een%3c%2fLang%3e%3cORef%3eTestReference01%3c%2fORef%3e%3cEmail%3esupport%40apcolabs.tech%3c%2fEmail%3e%3cUDF1+%2f%3e%3cUDF2+%2f%3e%3cUDF3+%2f%3e%3cRedirectionURL%3ehttps%3a%2f%2fwww.apsp.biz%2fpay%2fPaymentOptionsTests%2fRedirect%3c%2fRedirectionURL%3e%3cstatus_url+urlEncode%3d%22True%22%3ehttps%3a%2f%2fwww.apsp.biz%2fpay%2fTestFp%2fTestListener.aspx%3c%2fstatus_url%3e%3cForceBank%3ePTESTv2%3c%2fForceBank%3e%3cForcePayment%3eMBKR%3c%2fForcePayment%3e%3cTEST+%2f%3e%3cMainAcquirer%3eDIRECT%3c%2fMainAcquirer%3e%3c%2fTransaction%3e"
}
```

