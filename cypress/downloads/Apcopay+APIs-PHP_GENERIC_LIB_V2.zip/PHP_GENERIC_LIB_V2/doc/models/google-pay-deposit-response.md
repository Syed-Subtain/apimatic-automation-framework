
# Google Pay Deposit Response

## Structure

`GooglePayDepositResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `result` | `string` | Required | - | getResult(): string | setResult(string result): void |
| `errorCode` | `int` | Required | - | getErrorCode(): int | setErrorCode(int errorCode): void |
| `errorMessage` | `string` | Required | - | getErrorMessage(): string | setErrorMessage(string errorMessage): void |

## Example (as JSON)

```json
{
  "Result": "NOTOK",
  "ErrorCode": 1,
  "ErrorMessage": "Invalid Request"
}
```

