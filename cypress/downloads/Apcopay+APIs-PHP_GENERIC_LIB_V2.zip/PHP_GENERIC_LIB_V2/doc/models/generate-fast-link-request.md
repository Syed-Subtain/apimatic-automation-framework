
# Generate Fast Link Request

Generate Links for Fast Link Payment Solution

## Structure

`GenerateFastLinkRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `mchCode` | `string` | Required | APCOPAY Merchant ID | getMchCode(): string | setMchCode(string mchCode): void |
| `merchnatPassword` | `string` | Required | APCOPAY Merchant Password | getMerchnatPassword(): string | setMerchnatPassword(string merchnatPassword): void |
| `orderRef` | `string` | Required | Merchant Order Reference | getOrderRef(): string | setOrderRef(string orderRef): void |
| `description` | `string` | Required | - | getDescription(): string | setDescription(string description): void |
| `currency` | `string` | Required | Transaction Currency | getCurrency(): string | setCurrency(string currency): void |
| `amount` | `string` | Required | Transaction Value | getAmount(): string | setAmount(string amount): void |
| `validUntil` | `string` | Required | Link Expiration Date | getValidUntil(): string | setValidUntil(string validUntil): void |
| `notificationURL` | `string` | Required | - | getNotificationURL(): string | setNotificationURL(string notificationURL): void |
| `eXTRADATA` | `string` | Required | - | getEXTRADATA(): string | setEXTRADATA(string eXTRADATA): void |
| `actionType` | `int` | Required | - | getActionType(): int | setActionType(int actionType): void |
| `name` | `string` | Required | - | getName(): string | setName(string name): void |
| `surname` | `string` | Required | - | getSurname(): string | setSurname(string surname): void |
| `email` | `string` | Required | - | getEmail(): string | setEmail(string email): void |
| `mobileNumber` | `string` | Required | - | getMobileNumber(): string | setMobileNumber(string mobileNumber): void |
| `showTermsAndConditions` | `bool` | Required | - | getShowTermsAndConditions(): bool | setShowTermsAndConditions(bool showTermsAndConditions): void |
| `street1` | `?string` | Optional | Client Address - Street 1 | getStreet1(): ?string | setStreet1(?string street1): void |
| `street2` | `?string` | Optional | Client Address - Street 2 | getStreet2(): ?string | setStreet2(?string street2): void |
| `city` | `?string` | Optional | Client Address - City | getCity(): ?string | setCity(?string city): void |
| `state` | `?string` | Optional | Client Address - State | getState(): ?string | setState(?string state): void |
| `regCountry` | `?string` | Optional | Client Address - RegCountry | getRegCountry(): ?string | setRegCountry(?string regCountry): void |
| `clientAcc` | `?string` | Optional | The user's registered account on website. The client account is mandatory if additional functionality such of restrictions of cards per account is used for the payment request. | getClientAcc(): ?string | setClientAcc(?string clientAcc): void |

## Example (as JSON)

```json
{
  "MchCode": "1111",
  "MerchnatPassword": "MCHPASS",
  "OrderRef": "testFLGen",
  "Description": "Testing",
  "Currency": "EUR",
  "Amount": "19",
  "ValidUntil": "2019/11/14",
  "NotificationURL": "",
  "EXTRADATA": "",
  "ActionType": 1,
  "Name": "tester",
  "Surname": "testing",
  "Email": "test@test.com",
  "MobileNumber": "99887788",
  "ShowTermsAndConditions": true
}
```

