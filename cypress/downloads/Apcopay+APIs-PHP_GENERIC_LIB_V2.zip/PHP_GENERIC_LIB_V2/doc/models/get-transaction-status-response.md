
# Get Transaction Status Response

Get Transaction Status by Merchant Order Reference Response

## Structure

`GetTransactionStatusResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `result` | `string` | Required | Return Result for Get Transaction Status | getResult(): string | setResult(string result): void |
| `errorMsg` | `string` | Required | Error Message for the Get Transaction Status | getErrorMsg(): string | setErrorMsg(string errorMsg): void |
| `responses` | `string` | Required | XML Format Parameters of Transactions with Given ORef | getResponses(): string | setResponses(string responses): void |

## Example (as JSON)

```json
{
  "Result": "OK",
  "ErrorMsg": "",
  "Responses": "[{\"Response\":\"%3cTransactionResult%3e%3cORef%3eTestReference01%3c%2fORef%3e%3cResult%3eCAPTURED%3c%2fResult%3e%3cAuthCode%3eTEST%3c%2fAuthCode%3e%3cCardInput%3eList%3c%2fCardInput%3e%3cpspid%3e138145656%3c%2fpspid%3e%3cStatus3DS%3eG%3c%2fStatus3DS%3e%3cCurrency%3eEUR%3c%2fCurrency%3e%3cValue%3e1.0000%3c%2fValue%3e%3cExtendedData%3e%3cCardNum%3e444444%2c2228%3c%2fCardNum%3e%3cCardHName%3ea+a%3c%2fCardHName%3e%3cAcq%3ePTEST%3c%2fAcq%3e%3cSource%3ePTEST%3c%2fSource%3e%3c%2fExtendedData%3e%3cCardCountry%3ePOL%3c%2fCardCountry%3e%3cCardType%3e%3c%2fCardType%3e%3cEmail%3esupport%40apcolabs.tech%3c%2fEmail%3e%3cUDF1%3e3DS+Process%3c%2fUDF1%3e%3cUDF2%3eUDF2%3d%2cCT%3dTESTCARD%2c%3c%2fUDF2%3e%3c%2fTransactionResult%3e\"}]"
}
```

