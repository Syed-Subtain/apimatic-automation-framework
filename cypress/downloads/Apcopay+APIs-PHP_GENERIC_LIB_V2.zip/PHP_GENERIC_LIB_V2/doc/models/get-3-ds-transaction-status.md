
# Get 3 DS Transaction Status

Get Status of 3DSecure Authentication

## Structure

`Get3DSTransactionStatus`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `mCHCode` | `int` | Required | APCOPAY Merchant ID | getMCHCode(): int | setMCHCode(int mCHCode): void |
| `mCHPass` | `string` | Required | APCOPAY Merchant Password | getMCHPass(): string | setMCHPass(string mCHPass): void |
| `ticket3D` | `string` | Required | 3DSecure ID Returned | getTicket3D(): string | setTicket3D(string ticket3D): void |

## Example (as XML)

```xml
<get3DSTransactionStatus>
  <MCHCode>128</MCHCode>
  <MCHPass>MCHPass4</MCHPass>
  <Ticket3D>0000144a-0000-0000-0000-000000000000</Ticket3D>
</get3DSTransactionStatus>
```

