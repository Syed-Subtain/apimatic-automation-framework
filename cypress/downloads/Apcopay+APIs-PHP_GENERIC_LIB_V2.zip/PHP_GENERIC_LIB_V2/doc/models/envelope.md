
# Envelope

## Structure

`Envelope`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `body` | [`Body`](../../doc/models/body.md) | Required | - | getBody(): Body | setBody(Body body): void |

## Example (as XML)

```xml
<soap:Envelope xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">
  <soap:Body xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">
    <PopulateTransactionData2>
      <MerchID>194</MerchID>
      <Password>112</Password>
      <CardType>CardType4</CardType>
      <CardNo>68</CardNo>
      <ExpMonth>ExpMonth8</ExpMonth>
      <ExpYear>202</ExpYear>
      <Ext>192</Ext>
      <CardHolderName>CardHolderName8</CardHolderName>
      <CardHolderAddress>CardHolderAddress6</CardHolderAddress>
      <CardIssueNum>CardIssueNum6</CardIssueNum>
      <CardStartMonth>CardStartMonth0</CardStartMonth>
      <CardStartYear>CardStartYear8</CardStartYear>
      <PspID>PspID6</PspID>
    </PopulateTransactionData2>
  </soap:Body>
</soap:Envelope>
```

