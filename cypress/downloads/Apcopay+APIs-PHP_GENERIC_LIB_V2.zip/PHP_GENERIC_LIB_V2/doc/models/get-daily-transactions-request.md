
# Get Daily Transactions Request

Get a List of Daily Transactions

## Structure

`GetDailyTransactionsRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `merchID` | `string` | Required | APCOPAY Merchant ID | getMerchID(): string | setMerchID(string merchID): void |
| `merchPass` | `string` | Required | APCOPAY Merchant Password | getMerchPass(): string | setMerchPass(string merchPass): void |
| `date` | `string` | Required | Date for Transaction Report | getDate(): string | setDate(string date): void |

## Example (as JSON)

```json
{
  "MerchID": "MerchID",
  "MerchPass": "MerchPass",
  "Date": "20201009"
}
```

