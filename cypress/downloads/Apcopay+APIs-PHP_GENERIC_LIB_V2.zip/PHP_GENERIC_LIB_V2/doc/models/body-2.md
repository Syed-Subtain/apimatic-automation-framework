
# Body 2

## Structure

`Body2`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `doTransaction` | [`DoTransaction`](../../doc/models/do-transaction.md) | Required | - | getDoTransaction(): DoTransaction | setDoTransaction(DoTransaction doTransaction): void |

## Example (as XML)

```xml
<soap:Body xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">
  <DoTransaction>
    <Amount>1</Amount>
    <CurrencyCode>978</CurrencyCode>
  </DoTransaction>
</soap:Body>
```

