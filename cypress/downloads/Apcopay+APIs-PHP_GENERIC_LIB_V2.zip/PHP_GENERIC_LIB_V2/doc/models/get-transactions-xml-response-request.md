
# Get Transactions XML Response Request

Get XML Response sent to Listener URL for Merchant Order Reference

## Structure

`GetTransactionsXMLResponseRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `merchID` | `string` | Required | APCOPAY Merchant ID | getMerchID(): string | setMerchID(string merchID): void |
| `merchPass` | `string` | Required | APCOPAY Merchant Password | getMerchPass(): string | setMerchPass(string merchPass): void |
| `oref` | `string` | Required | Merchant Order Reference | getOref(): string | setOref(string oref): void |

## Example (as JSON)

```json
{
  "MerchID": "7561",
  "MerchPass": "apcotest34",
  "Oref": "TestReference01"
}
```

