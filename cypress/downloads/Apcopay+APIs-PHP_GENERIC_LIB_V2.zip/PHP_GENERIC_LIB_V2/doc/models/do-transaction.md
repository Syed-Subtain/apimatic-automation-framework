
# Do Transaction

## Structure

`DoTransaction`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `merchID` | `int` | Required | APCOPAY Merchant ID | getMerchID(): int | setMerchID(int merchID): void |
| `pass` | `string` | Required | APCOPAY Merchant Password | getPass(): string | setPass(string pass): void |
| `trType` | `int` | Required | Transaction Type | getTrType(): int | setTrType(int trType): void |
| `cardNum` | `int` | Required | Card Number | getCardNum(): int | setCardNum(int cardNum): void |
| `cVV2` | `int` | Required | Card Verification Code (CVV) | getCVV2(): int | setCVV2(int cVV2): void |
| `expDay` | `string` | Required | Expiry Day | getExpDay(): string | setExpDay(string expDay): void |
| `expMonth` | `string` | Required | Expiry Month | getExpMonth(): string | setExpMonth(string expMonth): void |
| `expYear` | `int` | Required | Expiry Year | getExpYear(): int | setExpYear(int expYear): void |
| `cardHName` | `string` | Required | Card Holder Name | getCardHName(): string | setCardHName(string cardHName): void |
| `amount` | `float` | Required | Transaction Amount | getAmount(): float | setAmount(float amount): void |
| `currencyCode` | `int` | Required | 3-Digit Currency Code | getCurrencyCode(): int | setCurrencyCode(int currencyCode): void |
| `addr` | `string` | Required | Card Holder Address | getAddr(): string | setAddr(string addr): void |
| `postCode` | `int` | Required | Address Post Code | getPostCode(): int | setPostCode(int postCode): void |
| `transID` | `string` | Required | Transaction ID of Previous Deposit - To be used for action types for actions on previous transactions | getTransID(): string | setTransID(string transID): void |
| `userIP` | `string` | Required | Card Holder IP Address | getUserIP(): string | setUserIP(string userIP): void |
| `uDF1` | `string` | Required | User Defined Field | getUDF1(): string | setUDF1(string uDF1): void |
| `uDF2` | `string` | Required | User Defined Field | getUDF2(): string | setUDF2(string uDF2): void |
| `uDF3` | `string` | Required | User Defined Field | getUDF3(): string | setUDF3(string uDF3): void |
| `orderRef` | `string` | Required | Transaction Order Reference | getOrderRef(): string | setOrderRef(string orderRef): void |

## Example (as XML)

```xml
<DoTransaction>
  <Amount>1</Amount>
  <CurrencyCode>978</CurrencyCode>
</DoTransaction>
```

