
# Envelope 2

## Structure

`Envelope2`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `body` | [`Body2`](../../doc/models/body-2.md) | Required | - | getBody(): Body2 | setBody(Body2 body): void |

## Example (as XML)

```xml
<soap:Envelope xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">
  <soap:Body xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">
    <DoTransaction>
      <Amount>1</Amount>
      <CurrencyCode>978</CurrencyCode>
    </DoTransaction>
  </soap:Body>
</soap:Envelope>
```

