
# Get Transaction Status Request

## Structure

`GetTransactionStatusRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `merchID` | `string` | Required | - | getMerchID(): string | setMerchID(string merchID): void |
| `merchPass` | `string` | Required | - | getMerchPass(): string | setMerchPass(string merchPass): void |
| `oref` | `string` | Required | - | getOref(): string | setOref(string oref): void |

## Example (as JSON)

```json
{
  "MerchID": "MerchID",
  "MerchPass": "MerhcPass",
  "Oref": "TestReference01"
}
```

