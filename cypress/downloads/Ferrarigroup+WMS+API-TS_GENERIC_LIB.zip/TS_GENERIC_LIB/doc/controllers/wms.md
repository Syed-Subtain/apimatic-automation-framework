# WMS

```ts
const wMSController = new WMSController(client);
```

## Class Name

`WMSController`

## Methods

* [Create Order](../../doc/controllers/wms.md#create-order)
* [Send Item](../../doc/controllers/wms.md#send-item)
* [Cancel Order](../../doc/controllers/wms.md#cancel-order)


# Create Order

Create a new order for WMS in thewarehouse, also store items data

```ts
async createOrder(
  params: CreateOrderParams,
  requestOptions?: RequestOptions
): Promise<ApiResponse<string>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `params` | [`CreateOrderParams`](../../doc/models/create-order-params.md) | Body, Required | Order to place |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Requires scope

`CreateOrder`

## Response Type

`string`

## Example Usage

```ts
const paramsOrderItems: OrderRow[] = [];

const paramsOrderitems0Addfields: AdditionalField[] = [];

const paramsOrderitems0addfields0: AdditionalField = {
  fieldname: 'PICK_NOTE',
  fieldvalue: 'after hallmarking',
};

paramsOrderitems0Addfields[0] = paramsOrderitems0addfields0;

const paramsOrderitems0addfields1: AdditionalField = {
  fieldname: 'PICK_NOTE',
  fieldvalue: 'after hallmarking',
};

paramsOrderitems0Addfields[1] = paramsOrderitems0addfields1;

const paramsOrderitems0: OrderRow = {
  itemCode: '03.2040.4061/69.C496',
  itemSerialNumber: '413121',
  itemQuantity: 1,
  addfields: paramsOrderitems0Addfields,
};

paramsOrderItems[0] = paramsOrderitems0;

const paramsOrderitems1Addfields: AdditionalField[] = [];

const paramsOrderitems1addfields0: AdditionalField = {
  fieldname: 'PICK_NOTE',
  fieldvalue: 'after hallmarking',
};

paramsOrderitems1Addfields[0] = paramsOrderitems1addfields0;

const paramsOrderitems1addfields1: AdditionalField = {
  fieldname: 'PICK_NOTE',
  fieldvalue: 'after hallmarking',
};

paramsOrderitems1Addfields[1] = paramsOrderitems1addfields1;

const paramsOrderitems1addfields2: AdditionalField = {
  fieldname: 'PICK_NOTE',
  fieldvalue: 'after hallmarking',
};

paramsOrderitems1Addfields[2] = paramsOrderitems1addfields2;

const paramsOrderitems1: OrderRow = {
  itemCode: '03.2040.4061/69.C496',
  itemSerialNumber: '413121',
  itemQuantity: 1,
  addfields: paramsOrderitems1Addfields,
};

paramsOrderItems[1] = paramsOrderitems1;

const paramsOrder: Order = {
  orderYear: '2019',
  orderNumber: '4.19-00814',
  orderDate: '20191119',
  companyName: 'Emard Ltd',
  companyAddress: '1555  Echo Lane',
  companyCity: 'LEXINGTON',
  companyCountry: 'US',
  items: paramsOrderItems,
  warehouseArea: 'STOCK',
};

const params: CreateOrderParams = {
  opType: 'IN',
  order: paramsOrder,
};

try {
  const { result, ...httpResponse } = await wMSController.createOrder(params);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch(error) {
  if (error instanceof ApiError) {
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 403 | Forbidden | `ApiError` |


# Send Item

```ts
async sendItem(
  params: SendItemsParams,
  requestOptions?: RequestOptions
): Promise<ApiResponse<string>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `params` | [`SendItemsParams`](../../doc/models/send-items-params.md) | Body, Required | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Requires scope

`SendItem`

## Response Type

`string`

## Example Usage

```ts
const paramsItem: Item = {
  itemCode: 'XXX0000001',
  itemDescription: 'golden ring',
};

const params: SendItemsParams = {
  opType: 'ADD',
  item: paramsItem,
};

try {
  const { result, ...httpResponse } = await wMSController.sendItem(params);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch(error) {
  if (error instanceof ApiError) {
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 403 | Forbidden | `ApiError` |


# Cancel Order

Send a request of cancellation for a previously added order. The cancellation will be subject to conditions agreed with Ferrari. The response to this method is meant as a formal response (OK -> your request has been successfully submitted), but it does not imply the cancellation has been done.

```ts
async cancelOrder(
  params: CancelOrderParams,
  requestOptions?: RequestOptions
): Promise<ApiResponse<string>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `params` | [`CancelOrderParams`](../../doc/models/cancel-order-params.md) | Body, Required | Order to cancel |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Requires scope

`CancelOrder`

## Response Type

`string`

## Example Usage

```ts
const params: CancelOrderParams = {
  opType: 'IN',
  orderYear: '2021',
  orderNum: 'ORD2732231',
  reasonForCancellation: 'Final consignee cancelled the order',
};

try {
  const { result, ...httpResponse } = await wMSController.cancelOrder(params);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch(error) {
  if (error instanceof ApiError) {
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 403 | Forbidden | `ApiError` |

