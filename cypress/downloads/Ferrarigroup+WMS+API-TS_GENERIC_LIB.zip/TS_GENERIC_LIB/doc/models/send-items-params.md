
# Send Items Params

send items body params

## Structure

`SendItemsParams`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `opType` | `string` | Required | operation type (ADD/DEL/UPD)<br>**Constraints**: *Maximum Length*: `3` |
| `item` | [`Item`](../../doc/models/item.md) | Required | Item to add |

## Example (as JSON)

```json
{
  "op_type": "ADD",
  "item": {
    "item_code": "XXX0000001",
    "item_description": "golden ring"
  }
}
```

