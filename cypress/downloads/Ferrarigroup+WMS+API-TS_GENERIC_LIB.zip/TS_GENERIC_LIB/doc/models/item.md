
# Item

item master data detail

## Structure

`Item`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `itemCode` | `string` | Required | sku number<br>**Constraints**: *Maximum Length*: `33` |
| `itemSerial` | `string \| undefined` | Optional | serial number<br>**Constraints**: *Maximum Length*: `15` |
| `itemDescription` | `string` | Required | item description<br>**Constraints**: *Maximum Length*: `70` |
| `itemCodeAlt1` | `string \| undefined` | Optional | alternative key to identify the sku |
| `itemCodeAlt2` | `string \| undefined` | Optional | alternative key to identify the sku |
| `itemCodeEan` | `string \| undefined` | Optional | ean code |
| `itemSerialType` | `string \| undefined` | Optional | Item with serial number (Y/N)<br>**Constraints**: *Maximum Length*: `1` |
| `itemStockValue` | `number \| undefined` | Optional | Item value in stock (for liability purpose) |
| `itemStockCurrency` | `string \| undefined` | Optional | currency for item value |
| `itemHtsCode` | `string \| undefined` | Optional | commodity code |
| `cites` | `string \| undefined` | Optional | cites |
| `mop` | `string \| undefined` | Optional | - |
| `countryOrigin` | `string \| undefined` | Optional | country of origin |
| `additionalUnit` | `string \| undefined` | Optional | additional unit |
| `productFamilyCode` | `string \| undefined` | Optional | - |
| `productFamilyDescription` | `string \| undefined` | Optional | - |
| `itemStyle` | `string \| undefined` | Optional | - |
| `productTypeCode` | `string \| undefined` | Optional | - |
| `productTypeDescription` | `string \| undefined` | Optional | - |
| `materialTypeCode` | `string \| undefined` | Optional | - |
| `materialTypeDescription` | `string \| undefined` | Optional | - |
| `materialNetWeight` | `number \| undefined` | Optional | - |
| `unitPieces` | `number \| undefined` | Optional | - |
| `dangerous` | `string \| undefined` | Optional | - |
| `itemUom` | `string \| undefined` | Optional | - |
| `itemDim1` | `number \| undefined` | Optional | - |
| `itemDim2` | `number \| undefined` | Optional | - |
| `itemDim3` | `number \| undefined` | Optional | - |
| `itemNetWeight` | `number \| undefined` | Optional | - |
| `itemGrossWeight` | `number \| undefined` | Optional | - |
| `storageGrossWeight` | `number \| undefined` | Optional | - |
| `itemUnitWeight` | `string \| undefined` | Optional | unità misura peso |
| `storageDim1` | `number \| undefined` | Optional | - |
| `storageDim2` | `number \| undefined` | Optional | - |
| `storageDim3` | `number \| undefined` | Optional | - |
| `productCategory` | `string \| undefined` | Optional | - |
| `diamondCertificate` | `string \| undefined` | Optional | - |
| `hallmarkingCode` | `string \| undefined` | Optional | - |
| `hallmarkingDescription` | `string \| undefined` | Optional | - |

## Example (as JSON)

```json
{
  "item_code": "XXX0000001",
  "item_description": "golden ring"
}
```

