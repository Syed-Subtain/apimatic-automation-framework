
# Cancel Order Params

cancel order body params

## Structure

`CancelOrderParams`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `opType` | `string` | Required | order type  (IN for inbound, OUT for delivery notice) |
| `orderYear` | `string` | Required | Year of the order to cancel<br>**Constraints**: *Minimum Length*: `4`, *Maximum Length*: `4` |
| `orderNum` | `string` | Required | Order number to cancel<br>**Constraints**: *Maximum Length*: `20` |
| `reasonForCancellation` | `string` | Required | optional description describing the reason why cancellation is asked<br>**Constraints**: *Maximum Length*: `500` |

## Example (as JSON)

```json
{
  "op_type": "IN",
  "order_year": "2021",
  "order_num": "ORD2732231",
  "reason_for_cancellation": "Final consignee cancelled the order"
}
```

