
# Additional Field

couple of key=>value for additional info on the order/item

## Structure

`AdditionalField`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `fieldname` | `string` | Required | field name<br>**Constraints**: *Maximum Length*: `25` |
| `fieldvalue` | `string` | Required | field value<br>**Constraints**: *Maximum Length*: `30` |

## Example (as JSON)

```json
{
  "fieldname": "PICK_NOTE",
  "fieldvalue": "after hallmarking"
}
```

