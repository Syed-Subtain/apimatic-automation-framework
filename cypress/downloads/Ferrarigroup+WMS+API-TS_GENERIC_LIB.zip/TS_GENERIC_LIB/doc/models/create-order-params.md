
# Create Order Params

create order body params

## Structure

`CreateOrderParams`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `opType` | `string` | Required | order type  (IN for inbound, OUT for delivery notice) |
| `order` | [`Order`](../../doc/models/order.md) | Required | Order to place |

## Example (as JSON)

```json
{
  "op_type": "IN",
  "order": {
    "order_year": "2019",
    "order_number": "4.19-00814",
    "order_date": "20191119",
    "company_name": "Emard Ltd",
    "company_address": "1555  Echo Lane",
    "company_city": "LEXINGTON",
    "company_country": "US",
    "items": {
      "item_code": "03.2040.4061/69.C496",
      "item_serial_number": "413121",
      "item_quantity": 1,
      "addfields": {
        "fieldname": "PICK_NOTE",
        "fieldvalue": "after hallmarking"
      }
    },
    "warehouse_area": "STOCK"
  }
}
```

