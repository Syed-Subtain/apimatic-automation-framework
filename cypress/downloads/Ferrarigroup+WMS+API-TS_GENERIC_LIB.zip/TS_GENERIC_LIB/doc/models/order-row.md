
# Order Row

order row detail (item level)

## Structure

`OrderRow`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `itemCode` | `string` | Required | sku code<br>**Constraints**: *Maximum Length*: `33` |
| `itemSerialNumber` | `string` | Required | serial number<br>**Constraints**: *Maximum Length*: `15` |
| `itemQuantity` | `number` | Required | quantity to be received/shipped |
| `addfields` | [`AdditionalField[]`](../../doc/models/additional-field.md) | Required | additional fields (item level) |

## Example (as JSON)

```json
{
  "item_code": "03.2040.4061/69.C496",
  "item_serial_number": "413121",
  "item_quantity": 1,
  "addfields": {
    "fieldname": "PICK_NOTE",
    "fieldvalue": "after hallmarking"
  }
}
```

