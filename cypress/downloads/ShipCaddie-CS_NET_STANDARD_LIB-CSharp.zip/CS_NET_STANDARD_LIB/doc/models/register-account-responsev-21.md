
# Register Account Responsev 21

## Structure

`RegisterAccountResponsev21`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Error` | [`Models.RequestError`](/doc/models/request-error.md) | Optional | This information can be used to determine if an error has occurred when a request was processed. |
| `Success` | `bool?` | Optional | - |

## Example (as JSON)

```json
{
  "error": null,
  "success": null
}
```

