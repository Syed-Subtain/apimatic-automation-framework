
# Print Format 1 Enum

Indicates the format of the Base64 Label

## Enumeration

`PrintFormat1Enum`

## Fields

| Name |
|  --- |
| `ZPL4x6` |
| `PNG4x6` |
| `EPLII4x6` |
| `PDF4x6` |
| `ZPL4x5` |
| `PNG4x5` |
| `EPLII4x5` |
| `PDF4x5` |
| `PNG6x4` |
| `PDF6x4` |
| `ZPL6x4` |
| `EPLII6x4` |
| `ZPLDocTab` |
| `PNG7x3` |
| `PDF7x3` |

