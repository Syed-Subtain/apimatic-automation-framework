
# Security Token Request

A refresh token can be used to obtain a new security token.

## Structure

`SecurityTokenRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `RefreshToken` | `string` | Required | Required.<br>Use the Refresh Token to obtain a new security token after the Access Token has expired. |

## Example (as JSON)

```json
{
  "refreshToken": "<YOUR REFRESH TOKEN>"
}
```

