
# Data Block

## Structure

`DataBlock`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `DataSourceName` | `string` | Optional | - |
| `Type` | `string` | Optional | - |
| `Data` | `string` | Optional | - |
| `DataURI` | `string` | Optional | - |

## Example (as JSON)

```json
{
  "dataSourceName": null,
  "type": null,
  "data": null,
  "dataURI": null
}
```

