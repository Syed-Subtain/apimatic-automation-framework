
# Get Shipping Labels by Shipping ID Requestv 21

## Structure

`GetShippingLabelsByShippingIDRequestv21`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `AccessToken` | `string` | Required | Required.<br>An authorization token is necessary to call this method.<br><remarks><br>The token can be obtained by calling the GetToken or RefreshToken methods.<br></remarks> |
| `AsClientId` | `int?` | Optional | Optional.<br>When empty or null, this field is ignored.<br>When set, actions will be taken for the client specified by the id. |
| `ShipmentID` | `int` | Required | Shipment identifier. |
| `PrintFormat` | [`Models.PrintFormatEnum`](/doc/models/print-format-enum.md) | Required | Format used for printing labels. |
| `CertifyTestOverride` | [`Models.CertifyTestOverrideEnum?`](/doc/models/certify-test-override-enum.md) | Optional | CertifyTestOverride : Force a Label to overriding what is in the contract |

## Example (as JSON)

```json
{
  "accessToken": "<YOUR ACCESS TOKEN>",
  "asClientId": 12,
  "shipmentID": 19,
  "printFormat": "PNG_4x6",
  "certifyTestOverride": "Contract"
}
```

