
# Package Length Girth Model V21

## Structure

`PackageLengthGirthModelV21`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `CarrierServiceLevelId` | `int?` | Optional | Required - CarrierServiceLevelId |
| `PackageList` | [`List<Models.PackagesV21>`](/doc/models/packages-v21.md) | Optional | List of Packages |

## Example (as JSON)

```json
{
  "carrierServiceLevelId": null,
  "packageList": null
}
```

