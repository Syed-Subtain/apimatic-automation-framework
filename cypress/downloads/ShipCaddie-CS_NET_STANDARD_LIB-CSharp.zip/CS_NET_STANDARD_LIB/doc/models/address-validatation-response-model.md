
# Address Validatation Response Model

Address Validation Response Model

## Structure

`AddressValidatationResponseModel`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Errors` | [`List<Models.ErrorModel>`](/doc/models/error-model.md) | Optional | - |
| `IsValidated` | `bool?` | Optional | Flag indicates whether address is validated or not |
| `ParsedAddresses` | [`List<Models.ParsedAddress>`](/doc/models/parsed-address.md) | Optional | List of parsed address |
| `ReplyTimeStamp` | `DateTime?` | Optional | Reply time stamp |
| `StatusCode` | `string` | Optional | Status code |
| `StatusDescription` | `string` | Optional | Decsription for the status |

## Example (as JSON)

```json
{
  "errors": null,
  "isValidated": null,
  "parsedAddresses": null,
  "replyTimeStamp": null,
  "statusCode": null,
  "statusDescription": null
}
```

