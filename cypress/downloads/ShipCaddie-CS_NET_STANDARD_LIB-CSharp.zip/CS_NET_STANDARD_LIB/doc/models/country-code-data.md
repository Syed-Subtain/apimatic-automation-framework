
# Country Code Data

Country information necessary to construct addresses.

## Structure

`CountryCodeData`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `CountryId` | `int` | Required | Unique ID used to identify a country. |
| `CountryName` | `string` | Required | Friendly Country name. |
| `Alpha2CountryCode` | `string` | Required | Standardized Country Codes. |

## Example (as JSON)

```json
{
  "countryId": 8,
  "countryName": "countryName6",
  "alpha2CountryCode": "alpha2CountryCode6"
}
```

