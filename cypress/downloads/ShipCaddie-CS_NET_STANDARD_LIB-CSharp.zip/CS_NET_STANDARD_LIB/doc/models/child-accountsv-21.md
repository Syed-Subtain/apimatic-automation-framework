
# Child Accountsv 21

## Structure

`ChildAccountsv21`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ClientId` | `int?` | Optional | - |
| `Name` | `string` | Optional | - |
| `IsEnabled` | `bool?` | Optional | - |

## Example (as JSON)

```json
{
  "clientId": null,
  "name": null,
  "isEnabled": null
}
```

