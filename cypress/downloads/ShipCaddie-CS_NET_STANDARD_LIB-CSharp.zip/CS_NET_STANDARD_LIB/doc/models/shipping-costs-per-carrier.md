
# Shipping Costs Per Carrier

## Structure

`ShippingCostsPerCarrier`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ServiceLevelName` | `string` | Optional | - |
| `ServiceLevelID` | `int?` | Optional | - |
| `ParcelChargeDetails` | [`List<Models.ParcelCharges>`](/doc/models/parcel-charges.md) | Optional | Shipping charges relating to individual parcels. |
| `ShippingChargeDetails` | [`List<Models.CostDetail>`](/doc/models/cost-detail.md) | Optional | Shipping charges relating to a shipment as a whole. |
| `TransitDaysMin` | `int?` | Optional | The Days in transit as defined by the carrier for the service level chosen.<br>The number may or may not include non-business days. |
| `TransitDaysMax` | `int?` | Optional | The Days in transit as defined by the carrier for the service level chosen.<br>The number may or may not include non-business days. |
| `TotalChargeAmount` | `double?` | Optional | - |
| `TotalChargeAmount3pl` | `double?` | Optional | The total charge of this shipment.<br>This is the sum of all accessorialCharges.chargeAmount3pl fields in all packages |
| `DeliveryDateTime` | `string` | Optional | - |
| `IsDeliveryGuaranteed` | `bool?` | Optional | - |
| `ZoneName` | `string` | Optional | - |
| `TotalChargeAmountDisplay` | `double?` | Optional | Gets or Sets ZoneName |

## Example (as JSON)

```json
{
  "serviceLevelName": null,
  "serviceLevelID": null,
  "parcelChargeDetails": null,
  "shippingChargeDetails": null,
  "transitDaysMin": null,
  "transitDaysMax": null,
  "totalChargeAmount": null,
  "totalChargeAmount3pl": null,
  "deliveryDateTime": null,
  "isDeliveryGuaranteed": null,
  "zoneName": null,
  "TotalChargeAmountDisplay": null
}
```

