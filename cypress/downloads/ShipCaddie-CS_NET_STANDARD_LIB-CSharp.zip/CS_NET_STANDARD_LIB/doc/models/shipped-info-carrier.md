
# Shipped Info Carrier

## Structure

`ShippedInfoCarrier`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `CarrierClientContractId` | `int?` | Optional | Indicates which Carrier was used. |
| `CarrierName` | `string` | Optional | The name of the carrier used for the shipment. |
| `CarrierServiceLevelId` | `int?` | Optional | Indicates which Carrier Service Level was used. |
| `CarrierServiceLevelName` | `string` | Optional | The name of the service level used. |

## Example (as JSON)

```json
{
  "carrierClientContractId": null,
  "carrierName": null,
  "carrierServiceLevelId": null,
  "carrierServiceLevelName": null
}
```

