
# Scan Form History Responsev 21

## Structure

`ScanFormHistoryResponsev21`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Error` | [`Models.RequestError`](/doc/models/request-error.md) | Optional | This information can be used to determine if an error has occurred when a request was processed. |
| `ScanFormList` | [`List<Models.ScanFormModel>`](/doc/models/scan-form-model.md) | Optional | List of ScanForm Data |

## Example (as JSON)

```json
{
  "error": null,
  "scanFormList": null
}
```

