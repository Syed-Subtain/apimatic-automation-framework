
# Cost Detail

Specific break down of cost.

## Structure

`CostDetail`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Name` | `string` | Required | Name of a specific Charge. |
| `Amount` | `double` | Required | Cost in United States Currency. |
| `AmountDisplay` | `double?` | Optional | Total Charge Amount Display |

## Example (as JSON)

```json
{
  "name": "name0",
  "amount": 56.78,
  "AmountDisplay": null
}
```

