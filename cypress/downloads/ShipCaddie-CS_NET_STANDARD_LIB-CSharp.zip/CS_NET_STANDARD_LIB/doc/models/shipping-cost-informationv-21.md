
# Shipping Cost Informationv 21

Cost details related to shipping.

## Structure

`ShippingCostInformationv21`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ShipmentId` | `int?` | Optional | Internal shipment identifier.<br>Read Only. |
| `OrderReferenceNumber` | `string` | Optional | Optional order reference tag that was set when adding a shipment or getting rates. |
| `ParcelChargeDetails` | [`List<Models.ParcelChargeDetails>`](/doc/models/parcel-charge-details.md) | Optional | Shipping charges relating to individual parcels. |
| `ShippingChargeDetails` | [`List<Models.CostDetailv21>`](/doc/models/cost-detailv-21.md) | Optional | Shipping charges relating to a shipment as a whole. |
| `TransitDaysMin` | `int?` | Optional | The Days in transit as defined by the carrier for the service level chosen.<br>The number may or may not include non-business days. |
| `TransitDaysMax` | `int?` | Optional | The Days in transit as defined by the carrier for the service level chosen.<br>The number may or may not include non-business days. |
| `TotalChargeAmount` | `double?` | Optional | - |
| `TotalChargeAmount3pl` | `double?` | Optional | This is the sum of all accessorialCharges.chargeAmount3pl fields in all packages |
| `DeliveryDateTime` | `DateTime?` | Optional | - |
| `IsDeliveryGuaranteed` | `bool?` | Optional | - |

## Example (as JSON)

```json
{
  "shipmentId": null,
  "orderReferenceNumber": null,
  "parcelChargeDetails": null,
  "shippingChargeDetails": null,
  "transitDaysMin": null,
  "transitDaysMax": null,
  "totalChargeAmount": null,
  "totalChargeAmount3pl": null,
  "deliveryDateTime": null,
  "isDeliveryGuaranteed": null
}
```

