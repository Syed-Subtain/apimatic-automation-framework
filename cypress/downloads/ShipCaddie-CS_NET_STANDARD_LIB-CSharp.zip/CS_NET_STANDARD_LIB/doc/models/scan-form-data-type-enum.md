
# Scan Form Data Type Enum

## Enumeration

`ScanFormDataTypeEnum`

## Fields

| Name |
|  --- |
| `Undefined` |
| `ImageUrl` |
| `ImagePng` |
| `ImageTiff` |
| `Pdf` |
| `PdfUrl` |

