
# Parcel Charge Details

Break down of charges per parcel.

## Structure

`ParcelChargeDetails`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ParcelID` | `string` | Optional | A unique ID used to match<br>parcels with cost details. |
| `CostDetails` | [`List<Models.CostDetailv21>`](/doc/models/cost-detailv-21.md) | Optional | Detailed shipping charges. |

## Example (as JSON)

```json
{
  "parcelID": null,
  "costDetails": null
}
```

