
# Address Validation Information

Informative Messages regarding Address Validation.

## Structure

`AddressValidationInformation`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Code` | `string` | Required | Message Code. |
| `Message` | `string` | Required | Descriptive Message. |

## Example (as JSON)

```json
{
  "code": "code8",
  "message": "message0"
}
```

