
# Packaging Detail

Carrier Packaging Specifications

## Structure

`PackagingDetail`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ParcelId` | `string` | Optional | This ID can be used when specifing a Parcel type. |
| `Name` | `string` | Optional | Parcel Type |
| `Description` | `string` | Optional | Parcel Description |
| `LengthInInches` | `double?` | Optional | Length of one side of parcel in inches. |
| `WidthInInches` | `double?` | Optional | Width of one side of parcel in inches. |
| `HeightInInches` | `double?` | Optional | Height of one side of parcel in inches. |
| `WeightLimit` | `double?` | Optional | Carrier Weight limit for the parcel |
| `PackagingWeight` | `double?` | Optional | Container weight |

## Example (as JSON)

```json
{
  "parcelId": null,
  "name": null,
  "description": null,
  "lengthInInches": null,
  "widthInInches": null,
  "heightInInches": null,
  "weightLimit": null,
  "packagingWeight": null
}
```

