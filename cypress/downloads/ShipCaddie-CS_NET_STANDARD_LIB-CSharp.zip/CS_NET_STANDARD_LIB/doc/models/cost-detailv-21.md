
# Cost Detailv 21

Specific break down of cost.

## Structure

`CostDetailv21`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Name` | `string` | Optional | Name of a specific Charge. |
| `Amount` | `double?` | Optional | Cost in United States Currency. |
| `AmountDisplay` | `double?` | Optional | Total Charge Amount Display |

## Example (as JSON)

```json
{
  "name": null,
  "amount": null,
  "amountDisplay": null
}
```

