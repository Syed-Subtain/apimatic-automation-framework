
# Scan Form Model

## Structure

`ScanFormModel`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Id` | `int?` | Optional | - |
| `ScanFormId` | `string` | Optional | - |
| `BatchId` | `string` | Optional | - |
| `ClientId` | `int?` | Optional | - |
| `ShipmentClientAddressId` | `int?` | Optional | - |
| `ShipDate` | `DateTime?` | Optional | - |
| `ScanFormDataType` | [`Models.ScanFormDataTypeEnum?`](/doc/models/scan-form-data-type-enum.md) | Optional | - |
| `CarrierClientContractId` | `int?` | Optional | - |
| `CarrierClientContractName` | `string` | Optional | - |
| `ShipmentClientAddressLine1` | `string` | Optional | - |
| `ShipmentClientAddressLine2` | `string` | Optional | - |
| `ShipmentClientAddressProvince` | `string` | Optional | - |
| `ShipmentClientAddressCity` | `string` | Optional | - |
| `ShipmentClientAddressPostalCode` | `string` | Optional | - |
| `ShippingSiteName` | `string` | Optional | - |
| `DateCreated` | `DateTime?` | Optional | - |
| `PrintJobs` | [`List<Models.PrintJob>`](/doc/models/print-job.md) | Optional | - |
| `ExcludedItems` | `Dictionary<string, string>` | Optional | This is the list of items that are ignored or already manifested by easypost. |

## Example (as JSON)

```json
{
  "id": null,
  "scanFormId": null,
  "batchId": null,
  "clientId": null,
  "shipmentClientAddressId": null,
  "shipDate": null,
  "scanFormDataType": null,
  "carrierClientContractId": null,
  "carrierClientContractName": null,
  "shipmentClientAddressLine1": null,
  "shipmentClientAddressLine2": null,
  "shipmentClientAddressProvince": null,
  "shipmentClientAddressCity": null,
  "shipmentClientAddressPostalCode": null,
  "shippingSiteName": null,
  "dateCreated": null,
  "printJobs": null,
  "excludedItems": null
}
```

