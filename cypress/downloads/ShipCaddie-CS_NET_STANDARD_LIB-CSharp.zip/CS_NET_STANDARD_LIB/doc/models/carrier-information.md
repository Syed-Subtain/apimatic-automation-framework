
# Carrier Information

## Structure

`CarrierInformation`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `CarrierClientContractId` | `int` | Required | This id is used to identify a carrier.<br>Various API methods require this id. |
| `AffillateName` | `string` | Required | Affillate Name |
| `CarrierName` | `string` | Required | Offical name of carrier. |
| `NickName` | `string` | Required | Descriptive Name |
| `ServiceLevels` | [`List<Models.ServiceLevelDetail>`](/doc/models/service-level-detail.md) | Required | Describes service details such as parcel weight limits. |
| `Error` | [`Models.RequestError`](/doc/models/request-error.md) | Optional | This information can be used to determine if an error has occurred when a request was processed. |

## Example (as JSON)

```json
{
  "carrierClientContractId": 190,
  "affillateName": "affillateName8",
  "carrierName": "carrierName2",
  "nickName": "nickName4",
  "serviceLevels": [
    {
      "carrierServiceLevelID": 34,
      "name": "name2",
      "parcelWeightLimit": 225.12,
      "isInternational": false
    },
    {
      "carrierServiceLevelID": 35,
      "name": "name3",
      "parcelWeightLimit": 225.13,
      "isInternational": true
    }
  ],
  "error": null
}
```

