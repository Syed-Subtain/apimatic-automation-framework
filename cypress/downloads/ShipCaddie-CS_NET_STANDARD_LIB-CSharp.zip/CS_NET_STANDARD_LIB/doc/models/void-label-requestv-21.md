
# Void Label Requestv 21

## Structure

`VoidLabelRequestv21`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `AccessToken` | `string` | Required | Required.<br>An authorization token is necessary to call this method.<br><remarks><br>The token can be obtained by calling the GetToken or RefreshToken methods.<br></remarks> |
| `AsClientId` | `int?` | Optional | Optional.<br>When empty or null, this field is ignored.<br>When set, actions will be taken for the client specified by the id. |
| `LabelKey` | `string` | Required | Identifies which label to delete. |

## Example (as JSON)

```json
{
  "accessToken": "<YOUR ACCESS TOKEN>",
  "asClientId": 12,
  "labelKey": "329058_340709_shp_dfc02221ff5e4b78a45558ef474b6713"
}
```

