
# Ship From Address

## Structure

`ShipFromAddress`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `CompanyName` | `string` | Optional | Optional Company Name.<br>This field is required by some Carriers. |
| `Email` | `string` | Optional | Optional Sender's email address.<br>This field is required by some Carriers. |
| `PhoneNumber` | `string` | Optional | Optional Sender's phone number.<br>This field is required by some Carriers. |
| `Address1` | `string` | Optional | Street Address of Sender. |
| `Address2` | `string` | Optional | Optional additional Street Address. |
| `City` | `string` | Optional | City |
| `StateOrProvince` | `string` | Optional | State |
| `PostalCode` | `string` | Optional | Zip Code |
| `CountryCode` | `string` | Optional | Code which indicates to which<br>country the parcels will be sent from.<br>Obtained from GetContryCodes. |

## Example (as JSON)

```json
{
  "companyName": null,
  "email": null,
  "phoneNumber": null,
  "address1": null,
  "address2": null,
  "city": null,
  "stateOrProvince": null,
  "postalCode": null,
  "countryCode": null
}
```

