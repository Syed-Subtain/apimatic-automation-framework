
# Address Validation Model

Model for the address validation

## Structure

`AddressValidationModel`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Address1` | `string` | Optional | Address Line 1 of the address |
| `Address2` | `string` | Optional | Address Line 2 of the address |
| `Province` | `string` | Optional | Province for the address |
| `ProvinceCode` | `string` | Optional | Code of the Province provided |
| `City` | `string` | Optional | City |
| `CountryCode` | `string` | Optional | The code of the country whose address is provided |
| `PostalCode` | `string` | Optional | Postal code |
| `Countryname` | `string` | Optional | Name of the country |
| `AddressTypeId` | [`Models.AddressTypeIdEnum?`](/doc/models/address-type-id-enum.md) | Optional | Type of address<br>Values :<br>- NotDefined<br>- Residential<br>- Commercial<br>- NotVerified<br>- Invalid |
| `CompanyName` | `string` | Optional | Name of the organization/company |
| `CountryId` | `int?` | Optional | Id of the country specified. |
| `AddressStatus` | `bool?` | Optional | Status of the address |

## Example (as JSON)

```json
{
  "address1": null,
  "address2": null,
  "province": null,
  "provinceCode": null,
  "city": null,
  "countryCode": null,
  "postalCode": null,
  "countryname": null,
  "addressTypeId": null,
  "companyName": null,
  "countryId": null,
  "addressStatus": null
}
```

