
# Scan Form Model Request

## Structure

`ScanFormModelRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `CarrierClientContractId` | `int?` | Optional | - |
| `ShipmentClientAddressId` | `int?` | Optional | - |
| `ShipDate` | `DateTime?` | Optional | - |
| `KeyList` | [`List<Models.KeyValues>`](/doc/models/key-values.md) | Optional | - |
| `RecentScanFormId` | `int?` | Optional | - |

## Example (as JSON)

```json
{
  "carrierClientContractId": null,
  "shipmentClientAddressId": null,
  "shipDate": null,
  "keyList": null,
  "recentScanFormId": null
}
```

