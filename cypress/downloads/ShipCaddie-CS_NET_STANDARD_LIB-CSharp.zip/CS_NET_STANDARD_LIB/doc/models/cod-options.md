
# COD Options

Optional Cash on Demand

## Structure

`CODOptions`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `CodType` | [`Models.CodTypeEnum?`](/doc/models/cod-type-enum.md) | Optional | - |
| `CodAmount` | `double?` | Optional | If COD is used,<br>specify the amount in<br>US Currency. |

## Example (as JSON)

```json
{
  "codType": null,
  "codAmount": null
}
```

