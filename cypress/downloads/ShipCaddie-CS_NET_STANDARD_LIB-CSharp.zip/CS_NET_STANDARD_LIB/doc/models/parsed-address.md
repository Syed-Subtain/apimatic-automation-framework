
# Parsed Address

Parsed Addresses

## Structure

`ParsedAddress`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `RequestedAddress` | [`Models.AddressesModel`](/doc/models/addresses-model.md) | Optional | Common model for Requested and Suggested Addresses |
| `SuggestedAddresses` | [`List<Models.AddressesModel>`](/doc/models/addresses-model.md) | Optional | List of suggested addresses provided by the carrier |
| `AddressStatus` | [`Models.AddressStatusEnum?`](/doc/models/address-status-enum.md) | Optional | Status of the address passed |
| `VerifiedFrom` | `int?` | Optional | To get from where It is verified |

## Example (as JSON)

```json
{
  "requestedAddress": null,
  "suggestedAddresses": null,
  "addressStatus": null,
  "verifiedFrom": null
}
```

