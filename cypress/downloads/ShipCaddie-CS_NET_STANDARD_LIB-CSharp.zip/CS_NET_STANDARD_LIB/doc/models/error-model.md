
# Error Model

Model for the errors

## Structure

`ErrorModel`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ErrorCode` | `string` | Optional | Error Code |
| `ErrorDescription` | `string` | Optional | Description of the error |

## Example (as JSON)

```json
{
  "errorCode": null,
  "errorDescription": null
}
```

