
# Void Label Responsev 21

## Structure

`VoidLabelResponsev21`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `TrackingNumber` | `string` | Optional | Tracking Number of voided Label |
| `Error` | [`Models.RequestError`](/doc/models/request-error.md) | Optional | This information can be used to determine if an error has occurred when a request was processed. |

## Example (as JSON)

```json
{
  "trackingNumber": null,
  "error": null
}
```

