
# User Register Modelv 21

## Structure

`UserRegisterModelv21`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `SystemCountryId` | `int?` | Optional | Country of Origin |
| `NameFirst` | `string` | Optional | Required.<br>First Name<br>Max Length: 25 |
| `NameLast` | `string` | Optional | Required.<br>Last Name<br>Max Length: 35 |
| `CompanyName` | `string` | Optional | Company Name<br>Max Length: 50 |
| `PhoneNumber` | `string` | Optional | Phone Number |
| `UserName` | `string` | Optional | Required.<br>User name |
| `Password` | `string` | Optional | Required.<br>Max Length: 100<br>Min Length: 8<br>Password |
| `PasswordVerify` | `string` | Optional | Confirm password |
| `PromoCode` | `string` | Optional | Promo Code |
| `SubscriptionTierId` | `int?` | Optional | Subscription Tier |
| `IAgree` | `string` | Optional | - |

## Example (as JSON)

```json
{
  "systemCountryId": null,
  "nameFirst": null,
  "nameLast": null,
  "companyName": null,
  "phoneNumber": null,
  "userName": null,
  "password": null,
  "passwordVerify": null,
  "promoCode": null,
  "subscriptionTierId": null,
  "iAgree": null
}
```

