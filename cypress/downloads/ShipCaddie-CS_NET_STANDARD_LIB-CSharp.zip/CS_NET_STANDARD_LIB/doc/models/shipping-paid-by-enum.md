
# Shipping Paid by Enum

Indicates who will pay for the shipping Costs.

## Enumeration

`ShippingPaidByEnum`

## Fields

| Name |
|  --- |
| `NOTAPPLICABLE` |
| `PAIDBYSHIPPER` |
| `PAIDBYRECIPIENT` |
| `PAIDBYTHIRDPARTY` |

