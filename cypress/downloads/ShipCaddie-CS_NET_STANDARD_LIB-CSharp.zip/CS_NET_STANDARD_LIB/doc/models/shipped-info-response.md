
# Shipped Info Response

## Structure

`ShippedInfoResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ShipmentId` | `int?` | Optional | Id used to identify shipment. |
| `DateShipped` | `DateTime?` | Optional | Specifies the date of shipment. |
| `FromAddress` | [`Models.ShipFromAddress`](/doc/models/ship-from-address.md) | Optional | - |
| `ToAddress` | [`Models.ShipToAddress`](/doc/models/ship-to-address.md) | Optional | - |
| `ShipmentOptions` | [`Models.ShippingOptions`](/doc/models/shipping-options.md) | Optional | Billing and Custom Declaration Options for Shipping. |
| `Carrier` | [`Models.ShippedInfoCarrier`](/doc/models/shipped-info-carrier.md) | Optional | - |
| `ParcelInfo` | [`List<Models.ShippedInfoParcel>`](/doc/models/shipped-info-parcel.md) | Optional | The information about the packages in the shipment. |
| `Error` | [`Models.RequestError`](/doc/models/request-error.md) | Required | This information can be used to determine if an error has occurred when a request was processed. |

## Example (as JSON)

```json
{
  "shipmentId": null,
  "dateShipped": null,
  "fromAddress": null,
  "toAddress": null,
  "shipmentOptions": null,
  "carrier": null,
  "parcelInfo": null,
  "error": {
    "details": null,
    "hasError": false
  }
}
```

