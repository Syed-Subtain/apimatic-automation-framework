
# Shipment Information Response

## Structure

`ShipmentInformationResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ShipmentId` | `int?` | Optional | Id used to identify shipment. |
| `Error` | [`Models.RequestError`](/doc/models/request-error.md) | Required | This information can be used to determine if an error has occurred when a request was processed. |
| `Shipment` | [`Models.ShipmentInformation`](/doc/models/shipment-information.md) | Optional | All necessary shipping information |

## Example (as JSON)

```json
{
  "shipmentId": null,
  "error": {
    "details": null,
    "hasError": false
  },
  "shipment": null
}
```

