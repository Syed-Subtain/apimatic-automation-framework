
# Parcel Content

Itemized packaging content used by customs.

## Structure

`ParcelContent`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Sku` | `string` | Optional | Product identifier. |
| `Name` | `string` | Required | Descriptive item name. |
| `Description` | `string` | Optional | Optional item description. |
| `Quantity` | `int` | Required | Number of items. |
| `Price` | `double` | Required | Price of item. |
| `WeightInPounds` | `double` | Required | Weight of the item. |
| `HarmonizeCode` | `string` | Optional | Optional Harmonize code |
| `OriginCountry` | `string` | Required | Country where product was made. |

## Example (as JSON)

```json
{
  "sku": null,
  "name": "name0",
  "description": null,
  "quantity": 68,
  "price": 207.52,
  "weightInPounds": 168.18,
  "harmonizeCode": null,
  "originCountry": "originCountry4"
}
```

