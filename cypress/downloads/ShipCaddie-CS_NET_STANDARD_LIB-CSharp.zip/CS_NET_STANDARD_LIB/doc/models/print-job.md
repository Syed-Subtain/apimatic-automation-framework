
# Print Job

## Structure

`PrintJob`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `PrintTemplateType` | `string` | Optional | - |
| `DataBlocks` | [`List<Models.DataBlock>`](/doc/models/data-block.md) | Optional | - |

## Example (as JSON)

```json
{
  "printTemplateType": null,
  "dataBlocks": null
}
```

