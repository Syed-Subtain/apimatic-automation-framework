
# Packages V21

## Structure

`PackagesV21`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Length` | `double?` | Optional | Required - Length |
| `Width` | `double?` | Optional | Required - Width |
| `Height` | `double?` | Optional | Required - Height |

## Example (as JSON)

```json
{
  "length": null,
  "width": null,
  "height": null
}
```

