
# Get Carrier Balance Responsev 21

## Structure

`GetCarrierBalanceResponsev21`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Threshold` | `double` | Required | Account Threshold |
| `RechargeAmount` | `double` | Required | Account Recharge Amount |
| `Balance` | `double` | Required | Account Balance |
| `Error` | [`Models.RequestError`](/doc/models/request-error.md) | Optional | This information can be used to determine if an error has occurred when a request was processed. |

## Example (as JSON)

```json
{
  "threshold": 204.48,
  "rechargeAmount": 51.02,
  "balance": 26.24,
  "error": null
}
```

