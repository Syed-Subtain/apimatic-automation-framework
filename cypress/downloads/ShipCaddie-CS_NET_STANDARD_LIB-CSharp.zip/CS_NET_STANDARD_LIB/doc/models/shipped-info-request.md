
# Shipped Info Request

## Structure

`ShippedInfoRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `IncludeFromAddress` | `bool?` | Optional | Include the from address information in result. Default false |
| `IncludeToAddress` | `bool?` | Optional | Include the to address information in the result. Default false |
| `IncludeCarrierInfo` | `bool?` | Optional | Include the carrier information in the result. Default false |
| `IncludeShipmentOptions` | `bool?` | Optional | Include the shipment options information in the result. Default false |
| `IncludeParcelInfo` | `bool?` | Optional | Include the parcel information in the result. Default false |
| `IncludeParcelOptions` | `bool?` | Optional | Include the parcel options information in the result. Default false |
| `IncludeParcelItems` | `bool?` | Optional | Include the parcel items information in the result. Default false |
| `AccessToken` | `string` | Required | Required.<br>An authorization token is necessary to call this method.<br><remarks><br>The token can be obtained by calling the GetToken or RefreshToken methods.<br></remarks> |
| `AsClientId` | `int?` | Optional | Optional.<br>When empty or null, this field is ignored.<br>When set, actions will be taken for the client specified by the id. |
| `ShipmentID` | `int?` | Optional | Id of an existing shipment. |

## Example (as JSON)

```json
{
  "includeFromAddress": null,
  "includeToAddress": null,
  "includeCarrierInfo": null,
  "includeShipmentOptions": null,
  "includeParcelInfo": null,
  "includeParcelOptions": null,
  "includeParcelItems": null,
  "accessToken": "accessToken2",
  "asClientId": null,
  "shipmentID": null
}
```

