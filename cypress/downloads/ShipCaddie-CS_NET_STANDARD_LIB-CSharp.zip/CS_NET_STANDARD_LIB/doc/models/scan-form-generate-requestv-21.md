
# Scan Form Generate Requestv 21

## Structure

`ScanFormGenerateRequestv21`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `AccessToken` | `string` | Optional | Required.<br>An authorization token is necessary to call this method.<br><remarks><br>The token can be obtained by calling the GetToken or RefreshToken methods.<br></remarks> |
| `AsClientId` | `int?` | Optional | Optional.<br>When empty or null, this field is ignored.<br>When set, actions will be taken for the client specified by the id. |
| `ScanFormRequest` | [`Models.ScanFormModelRequest`](/doc/models/scan-form-model-request.md) | Optional | - |

## Example (as JSON)

```json
{
  "accessToken": "<YOUR ACCESS TOKEN>",
  "scanFormRequest": {
    "carrierClientContractId": 2526,
    "shipmentClientAddressId": 747,
    "shipDate": "2017-11-29T00:00:00",
    "keyList": [
      {
        "labelKey": "shp_810c212e2dcf4863a1bd8495f9a54d81",
        "trackingNumber": "9400136895239112753275",
        "packageId": 366974
      }
    ],
    "recentScanFormId": 0
  }
}
```

