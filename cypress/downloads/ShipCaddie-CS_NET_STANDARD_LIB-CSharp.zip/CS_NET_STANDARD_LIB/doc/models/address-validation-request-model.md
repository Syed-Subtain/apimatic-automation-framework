
# Address Validation Request Model

Address Validation request model

## Structure

`AddressValidationRequestModel`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `CarrierId` | `int?` | Optional | The Id of the carrier |
| `CarrierContractId` | `int?` | Optional | Identifies the Carrier Client Contract on Shipcaddie |
| `Addresses` | [`List<Models.AddressValidationModel>`](/doc/models/address-validation-model.md) | Optional | List of address validation models |

## Example (as JSON)

```json
{
  "carrierId": null,
  "carrierContractId": null,
  "addresses": null
}
```

