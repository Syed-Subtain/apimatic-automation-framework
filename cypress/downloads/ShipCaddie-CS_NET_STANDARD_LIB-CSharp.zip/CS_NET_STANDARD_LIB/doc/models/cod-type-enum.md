
# Cod Type Enum

## Enumeration

`CodTypeEnum`

## Fields

| Name |
|  --- |
| `NOTAPPLICABLE` |
| `CODSECUREDFUNDS` |
| `CODCASH` |
| `CODCHECK` |
| `CODANY` |

