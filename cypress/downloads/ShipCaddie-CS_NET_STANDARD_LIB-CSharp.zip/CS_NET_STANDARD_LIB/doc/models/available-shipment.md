
# Available Shipment

## Structure

`AvailableShipment`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `CarrierClientContractId` | `int?` | Optional | - |
| `ShipmentId` | `int?` | Optional | - |
| `PackageId` | `int?` | Optional | - |
| `ShipmentClientAddressId` | `int?` | Optional | - |
| `DateShipped` | `DateTime?` | Optional | - |
| `FromShippingSiteName` | `string` | Optional | - |
| `ToAddressLine1` | `string` | Optional | - |
| `ToAddressLine2` | `string` | Optional | - |
| `ToPostalCode` | `string` | Optional | - |
| `ToProvince` | `string` | Optional | - |
| `ToCity` | `string` | Optional | - |
| `AccountAlias` | `string` | Optional | - |
| `LabelKey` | `string` | Optional | - |
| `TrackingNumber` | `string` | Optional | - |

## Example (as JSON)

```json
{
  "carrierClientContractId": null,
  "shipmentId": null,
  "packageId": null,
  "shipmentClientAddressId": null,
  "dateShipped": null,
  "fromShippingSiteName": null,
  "toAddressLine1": null,
  "toAddressLine2": null,
  "toPostalCode": null,
  "toProvince": null,
  "toCity": null,
  "accountAlias": null,
  "labelKey": null,
  "trackingNumber": null
}
```

