
# Billing Options

Specifies how the shipping costs will be paid.

## Structure

`BillingOptions`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ShippingPaidBy` | [`Models.ShippingPaidByEnum`](/doc/models/shipping-paid-by-enum.md) | Required | Indicates who will pay for the shipping Costs. |
| `AccountNumber` | `string` | Optional | Optional Account Number.<br>This is the account number of the person or group which will pay the shipping charges. |
| `PostalCode` | `string` | Optional | Optional Postal Code<br>This is the postal code of the person or group which will pay the shipping charges. |
| `CountryAlpha2Code` | `string` | Optional | Optional Country<br>This is the country of the person or group which will pay the shipping charges. |
| `DutiesPaidBy` | [`Models.DutiesPaidByEnum`](/doc/models/duties-paid-by-enum.md) | Required | Indicates who will pay for any applicable duties. |

## Example (as JSON)

```json
{
  "shippingPaidBy": "PAID_BY_RECIPIENT",
  "accountNumber": null,
  "postalCode": null,
  "country_Alpha2Code": null,
  "dutiesPaidBy": "PAID_BY_RECIPIENT"
}
```

