
# Key Values

## Structure

`KeyValues`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `LabelKey` | `string` | Optional | - |
| `TrackingNumber` | `string` | Optional | - |
| `PackageId` | `int?` | Optional | - |

## Example (as JSON)

```json
{
  "labelKey": null,
  "trackingNumber": null,
  "packageId": null
}
```

