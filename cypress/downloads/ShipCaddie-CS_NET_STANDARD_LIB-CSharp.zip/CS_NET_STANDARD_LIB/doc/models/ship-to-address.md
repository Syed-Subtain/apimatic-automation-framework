
# Ship to Address

## Structure

`ShipToAddress`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `AttentionOf` | `string` | Optional | Attention of the person accepting the parcels.<br>This field is required by some Carriers. |
| `CompanyName` | `string` | Optional | Optional Company Name.<br>This field is required by some Carriers. |
| `Email` | `string` | Optional | This field is required by some Carriers. |
| `PhoneNumber` | `string` | Optional | This field is required by some Carriers. |
| `Address1` | `string` | Optional | Street Address |
| `Address2` | `string` | Optional | Optional additional Street Address. |
| `IsResidential` | `bool?` | Optional | Specifies if the address is a residential address. |
| `City` | `string` | Optional | City to which the parcels will be sent. |
| `StateOrProvince` | `string` | Optional | Use Province or other appropriate value<br>for international addresses. |
| `PostalCode` | `string` | Optional | Zip Code if address in in the United States.<br>Postal Code if the address is international. |
| `CountryCode` | `string` | Optional | Code which indicates to which<br>country the parcels will be sent.<br>Obtained from GetContryCodes. |

## Example (as JSON)

```json
{
  "attentionOf": null,
  "companyName": null,
  "email": null,
  "phoneNumber": null,
  "address1": null,
  "address2": null,
  "isResidential": null,
  "city": null,
  "stateOrProvince": null,
  "postalCode": null,
  "countryCode": null
}
```

