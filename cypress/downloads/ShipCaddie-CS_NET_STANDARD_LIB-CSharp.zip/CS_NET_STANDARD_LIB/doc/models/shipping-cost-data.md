
# Shipping Cost Data

## Structure

`ShippingCostData`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ShippingCost` | [`Models.ShippingCostInformationv21`](/doc/models/shipping-cost-informationv-21.md) | Optional | Cost details related to shipping. |
| `Error` | [`Models.RequestError`](/doc/models/request-error.md) | Optional | This information can be used to determine if an error has occurred when a request was processed. |

## Example (as JSON)

```json
{
  "shippingCost": null,
  "error": null
}
```

