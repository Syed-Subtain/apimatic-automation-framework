
# Shipping Information

Shipment Information used to request a rate.

## Structure

`ShippingInformation`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `CarrierClientContractId` | `int?` | Optional | Specifies the Carrier for which to check rates. |
| `ServiceLevelId` | `int?` | Optional | Specifies the ServiceLevel to check. |
| `DateShipped` | `DateTime?` | Optional | Specifies the date the packages will be shipped. |
| `Options` | [`Models.CustomsOptions`](/doc/models/customs-options.md) | Optional | - |
| `AddressFrom` | [`Models.ShipFromAddress`](/doc/models/ship-from-address.md) | Optional | - |
| `AddressTo` | [`Models.ShipToAddress`](/doc/models/ship-to-address.md) | Optional | - |
| `Parcels` | [`List<Models.ParcelInformation>`](/doc/models/parcel-information.md) | Optional | Details of parcels to send. |

## Example (as JSON)

```json
{
  "carrierClientContractId": null,
  "serviceLevelId": null,
  "dateShipped": null,
  "options": null,
  "addressFrom": null,
  "addressTo": null,
  "parcels": null
}
```

