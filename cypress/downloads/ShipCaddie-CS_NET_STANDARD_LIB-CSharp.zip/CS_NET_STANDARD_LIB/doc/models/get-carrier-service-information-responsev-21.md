
# Get Carrier Service Information Responsev 21

## Structure

`GetCarrierServiceInformationResponsev21`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `CarrierServiceList` | [`List<Models.CarrierInformation>`](/doc/models/carrier-information.md) | Required | List of carriers and associated service level details. |
| `Error` | [`Models.RequestError`](/doc/models/request-error.md) | Optional | This information can be used to determine if an error has occurred when a request was processed. |

## Example (as JSON)

```json
{
  "carrierServiceList": [
    {
      "carrierClientContractId": 92,
      "affillateName": "affillateName8",
      "carrierName": "carrierName2",
      "nickName": "nickName4",
      "serviceLevels": [
        {
          "carrierServiceLevelID": 28,
          "name": "name8",
          "parcelWeightLimit": 193.78,
          "isInternational": false
        },
        {
          "carrierServiceLevelID": 29,
          "name": "name7",
          "parcelWeightLimit": 193.77,
          "isInternational": true
        },
        {
          "carrierServiceLevelID": 30,
          "name": "name6",
          "parcelWeightLimit": 193.76,
          "isInternational": false
        }
      ],
      "error": null
    },
    {
      "carrierClientContractId": 93,
      "affillateName": "affillateName9",
      "carrierName": "carrierName1",
      "nickName": "nickName3",
      "serviceLevels": [
        {
          "carrierServiceLevelID": 27,
          "name": "name9",
          "parcelWeightLimit": 193.79,
          "isInternational": true
        },
        {
          "carrierServiceLevelID": 28,
          "name": "name8",
          "parcelWeightLimit": 193.78,
          "isInternational": false
        }
      ],
      "error": null
    }
  ],
  "error": null
}
```

