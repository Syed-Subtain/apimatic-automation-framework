
# Shipment Inventory by Sku Response

## Structure

`ShipmentInventoryBySkuResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Sku` | `string` | Optional | - |
| `Name` | `string` | Optional | - |
| `Qty` | `int?` | Optional | - |
| `DateShipped` | `DateTime?` | Optional | - |
| `OrderReferenceNumber` | `string` | Optional | - |
| `ShipmentNumber` | `string` | Optional | - |

## Example (as JSON)

```json
{
  "sku": null,
  "name": null,
  "qty": null,
  "dateShipped": null,
  "orderReferenceNumber": null,
  "shipmentNumber": null
}
```

