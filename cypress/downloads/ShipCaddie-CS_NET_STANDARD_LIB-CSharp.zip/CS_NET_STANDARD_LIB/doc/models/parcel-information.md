
# Parcel Information

Details of parcels to send.

## Structure

`ParcelInformation`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `PackagingId` | `string` | Optional | - |
| `WeightInPounds` | `double?` | Optional | Parcel Weight in Pounds.<br>If the weight is a fraction of a pound<br>still use pounds - not ounces. |
| `LengthInInches` | `double?` | Optional | Length of one side of parcel in inches. |
| `WidthInInches` | `double?` | Optional | Width of one side of parcel in inches. |
| `HeightInInches` | `double?` | Optional | Height of one side of parcel in inches. |
| `Options` | [`Models.ParcelOptions`](/doc/models/parcel-options.md) | Optional | Specifies additional parcel options such as COD and required Signatures. |

## Example (as JSON)

```json
{
  "packagingId": null,
  "weightInPounds": null,
  "lengthInInches": null,
  "widthInInches": null,
  "heightInInches": null,
  "options": null
}
```

