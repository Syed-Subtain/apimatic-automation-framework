
# Get Carrier Parcel Specification Responsev 21

## Structure

`GetCarrierParcelSpecificationResponsev21`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ParcelDetails` | [`List<Models.PackagingDetail>`](/doc/models/packaging-detail.md) | Optional | Specifications for parcels handled by carrier. |
| `Error` | [`Models.RequestError`](/doc/models/request-error.md) | Optional | This information can be used to determine if an error has occurred when a request was processed. |

## Example (as JSON)

```json
{
  "parcelDetails": null,
  "error": null
}
```

