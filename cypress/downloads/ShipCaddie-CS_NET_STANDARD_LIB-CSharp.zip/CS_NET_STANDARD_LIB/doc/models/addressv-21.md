
# Addressv 21

## Structure

`Addressv21`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Address1` | `string` | Required | Required |
| `Address2` | `string` | Optional | Optional |
| `City` | `string` | Required | Required |
| `CountryCode` | `string` | Required | Required |
| `StateOrProvidence` | `string` | Required | Required - StateOrProvidence |
| `PostalCode` | `string` | Required | Required - PostalCode |
| `IsResidential` | `bool?` | Optional | Optional - Is Residencial flag |
| `AttentionOf` | `string` | Optional | Optional - Attention of,<br>some Carriers will require this parameter to be set |
| `CompanyName` | `string` | Optional | Optional - Company Name,<br>some Carriers will require this parameter to be set |
| `Email` | `string` | Optional | Optional - Email, some Carriers will require this parameter to be set |
| `PhoneNumber` | `string` | Optional | Optional - Phone Number,<br>some Carriers will require this parameter to be set |

## Example (as JSON)

```json
{
  "address1": "address12",
  "address2": null,
  "city": "city0",
  "countryCode": "countryCode4",
  "stateOrProvidence": "stateOrProvidence4",
  "postalCode": "postalCode8",
  "isResidential": null,
  "attentionOf": null,
  "companyName": null,
  "email": null,
  "phoneNumber": null
}
```

