
# Service Level Detail

Details regarding shipping service methods and types.

## Structure

`ServiceLevelDetail`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `CarrierServiceLevelID` | `int` | Required | Service Level Identifier.  <br>This identifier is used in other methods such as Add Shipment. |
| `Name` | `string` | Required | Descriptive Service Name |
| `ParcelWeightLimit` | `double` | Required | Maximum weight of a parcel for this service level.<br>Weight limit is in pounds - unless specified otherwise. |
| `IsInternational` | `bool` | Required | When true, the service is meant for parcels sent out of the country. |

## Example (as JSON)

```json
{
  "carrierServiceLevelID": 204,
  "name": "name0",
  "parcelWeightLimit": 58.9,
  "isInternational": false
}
```

