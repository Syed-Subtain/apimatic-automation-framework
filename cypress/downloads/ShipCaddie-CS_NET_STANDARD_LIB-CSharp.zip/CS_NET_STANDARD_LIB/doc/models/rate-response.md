
# Rate Response

## Structure

`RateResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ProcessingTimeInSeconds` | `double` | Required | - |
| `CarrierName` | `string` | Optional | - |
| `CarrierClientContractId` | `int?` | Optional | - |
| `Data` | [`List<Models.ShippingCostsPerCarrier>`](/doc/models/shipping-costs-per-carrier.md) | Optional | - |
| `Error` | [`Models.RequestError`](/doc/models/request-error.md) | Required | This information can be used to determine if an error has occurred when a request was processed. |

## Example (as JSON)

```json
{
  "processingTimeInSeconds": 50.3,
  "carrierName": null,
  "carrierClientContractId": null,
  "data": null,
  "error": {
    "details": null,
    "hasError": false
  }
}
```

