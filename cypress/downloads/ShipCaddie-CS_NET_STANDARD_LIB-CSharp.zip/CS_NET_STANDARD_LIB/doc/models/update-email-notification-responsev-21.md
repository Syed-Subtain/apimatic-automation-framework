
# Update Email Notification Responsev 21

## Structure

`UpdateEmailNotificationResponsev21`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `SuccessfullyUpdatedEmailNotification` | `bool` | Required | True if update has completed successfully.<br>False otherwise. |
| `Error` | [`Models.RequestError`](/doc/models/request-error.md) | Required | This information can be used to determine if an error has occurred when a request was processed. |

## Example (as JSON)

```json
{
  "successfullyUpdatedEmailNotification": false,
  "error": {
    "details": null,
    "hasError": false
  }
}
```

