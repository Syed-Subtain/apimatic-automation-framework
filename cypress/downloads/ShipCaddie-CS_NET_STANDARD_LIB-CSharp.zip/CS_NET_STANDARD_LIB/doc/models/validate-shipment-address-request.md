
# Validate Shipment Address Request

Validate Shipment Address Request Model

## Structure

`ValidateShipmentAddressRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `AccessToken` | `string` | Optional | Access Token |
| `AsClientId` | `int?` | Optional | Client Id used in place of Client Id of signed in user. |
| `ShipmentAddressToValidate` | [`Models.AddressValidationRequestModel`](/doc/models/address-validation-request-model.md) | Optional | Address Validation request model |

## Example (as JSON)

```json
{
  "accessToken": "<YOUR ACCESS TOKEN>",
  "asClientId": 14,
  "shipmentAddressToValidate": {
    "carrierId": 4,
    "carrierContractId": 2324,
    "addresses": [
      {
        "address1": "2600 Executive Parkway",
        "address2": "Suite 160",
        "provinceCode": "UT",
        "city": "Lehi",
        "countryCode": "US",
        "postalCode": "84043",
        "addressTypeId": "Commercial",
        "companyName": "iDrive Logistics",
        "countryId": 0,
        "addressStatus": false
      }
    ]
  }
}
```

