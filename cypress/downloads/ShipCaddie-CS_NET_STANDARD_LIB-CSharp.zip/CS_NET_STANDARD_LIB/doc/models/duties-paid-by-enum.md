
# Duties Paid by Enum

Indicates who will pay for any applicable duties.

## Enumeration

`DutiesPaidByEnum`

## Fields

| Name |
|  --- |
| `NOTAPPLICABLE` |
| `PAIDBYSHIPPER` |
| `PAIDBYRECIPIENT` |
| `PAIDBYTHIRDPARTY` |

