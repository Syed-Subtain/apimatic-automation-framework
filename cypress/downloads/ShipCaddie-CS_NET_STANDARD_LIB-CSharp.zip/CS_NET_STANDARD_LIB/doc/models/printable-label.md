
# Printable Label

Print Label information including a base 64 string label.

## Structure

`PrintableLabel`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ParcelIndex` | `int` | Required | The parcel number in a multi-parcel shipment<br>The first index will be 1, then it will increment<br>(ie 1, 2, 3, etc.) |
| `PrintFormat` | [`Models.PrintFormat1Enum`](/doc/models/print-format-1-enum.md) | Required | Indicates the format of the Base64 Label |
| `Base64Label` | `string` | Required | This is a base 64 string which is to be decoded<br>into the Print Format specified by PrintFormat. |
| `LabelKey` | `string` | Required | Used with VoidLabel when voiding a label. |
| `TrackingNumber` | `string` | Required | Tracking Number of the parcel. |
| `LabelURL` | `string` | Required | URL of Printable Label |

## Example (as JSON)

```json
{
  "parcelIndex": 162,
  "printFormat": "PNG_4x5",
  "base64Label": "base64Label0",
  "labelKey": "labelKey6",
  "trackingNumber": "trackingNumber8",
  "labelURL": "labelURL4"
}
```

