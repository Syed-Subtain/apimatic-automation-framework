
# Shipped Info Parcel

## Structure

`ShippedInfoParcel`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Cost` | `double?` | Optional | The cost of shipping the package |
| `ReferenceField1` | `string` | Optional | Optional - Reference Field 1 |
| `ReferenceField2` | `string` | Optional | Optional - Reference Field 2 |
| `ReferenceField3` | `string` | Optional | Optional - Reference Field 3 |
| `WeightInPounds` | `double?` | Optional | Parcel Weight in Pounds. |
| `LengthInInches` | `double?` | Optional | Length of one side of parcel in inches. |
| `WidthInInches` | `double?` | Optional | Width of one side of parcel in inches. |
| `HeightInInches` | `double?` | Optional | Height of one side of parcel in inches. |
| `TrackingNumber` | `string` | Optional | The tracking number of the package. |
| `Options` | [`Models.ParcelOptions`](/doc/models/parcel-options.md) | Optional | Specifies additional parcel options such as COD and required Signatures. |
| `ParcelItems` | [`List<Models.ParcelContent>`](/doc/models/parcel-content.md) | Optional | Type of parcel contents. |

## Example (as JSON)

```json
{
  "cost": null,
  "referenceField1": null,
  "referenceField2": null,
  "referenceField3": null,
  "weightInPounds": null,
  "lengthInInches": null,
  "widthInInches": null,
  "heightInInches": null,
  "trackingNumber": null,
  "options": null,
  "parcelItems": null
}
```

