
# Addresses Model

Common model for Requested and Suggested Addresses

## Structure

`AddressesModel`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Address1` | `string` | Optional | Address Line1 of the address |
| `Address2` | `string` | Optional | Address Line2 of the address |
| `AddressTypeId` | [`Models.AddressTypeId1Enum?`](/doc/models/address-type-id-1-enum.md) | Optional | Id of the address type |
| `City` | `string` | Optional | City |
| `CompanyName` | `string` | Optional | Name of the Company / Organisation |
| `CountryCode` | `string` | Optional | Code of the country provided in address |
| `CountryId` | `int?` | Optional | Id of the country specified. |
| `Countryname` | `string` | Optional | Name of the country with which address relates |
| `PostalCode` | `string` | Optional | Postal Code |
| `Province` | `string` | Optional | Province / State |
| `ProvinceCode` | `string` | Optional | Code the Province |
| `RowKeyHash` | `string` | Optional | Row Key Hash |
| `IsSelected` | `bool?` | Optional | Is Selected |

## Example (as JSON)

```json
{
  "address1": null,
  "address2": null,
  "addressTypeId": null,
  "city": null,
  "companyName": null,
  "countryCode": null,
  "countryId": null,
  "countryname": null,
  "postalCode": null,
  "province": null,
  "provinceCode": null,
  "rowKeyHash": null,
  "isSelected": null
}
```

