
# Credentials

Credentials are used to obtain a Security Token.

## Structure

`Credentials`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `UserName` | `string` | Required | Required.<br>Username as supplied by ShipCaddie. |
| `Password` | `string` | Required | Required.<br>Associated password. |

## Example (as JSON)

```json
{
  "userName": "<Your UserName>",
  "password": "<Your Password>"
}
```

