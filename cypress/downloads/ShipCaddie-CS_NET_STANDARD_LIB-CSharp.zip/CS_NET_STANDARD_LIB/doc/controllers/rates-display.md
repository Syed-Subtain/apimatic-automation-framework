# Rates Display

```csharp
RatesDisplayController ratesDisplayController = client.RatesDisplayController;
```

## Class Name

`RatesDisplayController`


# Get Rates With Display

Before creating a shipping label,
you can use this method to get a
break down of all shipping charges.
This allows you to determine
how much it would cost if you were to
actually send the parcels.

NOTE: HTTPS is Required to recieve a response.

```csharp
GetRatesWithDisplayAsync(
    Models.RateRequest rateRequest = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `rateRequest` | [`Models.RateRequest`](/doc/models/rate-request.md) | Body, Optional | Shipping and parcel information<br>neccessary to calculate rates. |

## Response Type

[`Task<Models.RateResponse>`](/doc/models/rate-response.md)

## Example Usage

```csharp
var rateRequest = new RateRequest();
rateRequest.AccessToken = "YOUR ACCESS TOKEN";
rateRequest.ShippingInfo = new ShippingInformation();
rateRequest.ShippingInfo.CarrierClientContractId = 2526;
rateRequest.ShippingInfo.ServiceLevelId = 0;
rateRequest.ShippingInfo.DateShipped = DateTime.Parse("2020-12-23T23:54:10.2649036Z");
rateRequest.ShippingInfo.Options = new CustomsOptions();
rateRequest.ShippingInfo.Options.IsAPOFPODPOUSTerritory = false;
rateRequest.ShippingInfo.Options.IsInternationalShipment = false;
rateRequest.ShippingInfo.Options.ShipmentContentType = ShipmentContentTypeEnum.CONTENTTYPESAMPLE;
rateRequest.ShippingInfo.AddressFrom = new ShipFromAddress();
rateRequest.ShippingInfo.AddressFrom.CompanyName = "iDrive Logistics";
rateRequest.ShippingInfo.AddressFrom.Email = "sales@idrivelogistics.com";
rateRequest.ShippingInfo.AddressFrom.PhoneNumber = "(888) 797-0929";
rateRequest.ShippingInfo.AddressFrom.Address1 = "2600 Executive Pkwy #160";
rateRequest.ShippingInfo.AddressFrom.Address2 = "";
rateRequest.ShippingInfo.AddressFrom.City = "Lehi";
rateRequest.ShippingInfo.AddressFrom.StateOrProvince = "UT";
rateRequest.ShippingInfo.AddressFrom.PostalCode = "84043";
rateRequest.ShippingInfo.AddressFrom.CountryCode = "US";
rateRequest.ShippingInfo.AddressTo = new ShipToAddress();
rateRequest.ShippingInfo.AddressTo.AttentionOf = "Mr. Jones";
rateRequest.ShippingInfo.AddressTo.CompanyName = "iDrive Logistics";
rateRequest.ShippingInfo.AddressTo.Email = "";
rateRequest.ShippingInfo.AddressTo.PhoneNumber = "";
rateRequest.ShippingInfo.AddressTo.Address1 = "2605 Executive Pkwy #160";
rateRequest.ShippingInfo.AddressTo.Address2 = "";
rateRequest.ShippingInfo.AddressTo.IsResidential = false;
rateRequest.ShippingInfo.AddressTo.City = "Lehi";
rateRequest.ShippingInfo.AddressTo.StateOrProvince = "UT";
rateRequest.ShippingInfo.AddressTo.PostalCode = "84043";
rateRequest.ShippingInfo.AddressTo.CountryCode = "US";
rateRequest.ShippingInfo.Parcels = new List<ParcelInformation>();

var rateRequestShippingInfoParcels0 = new ParcelInformation();
rateRequestShippingInfoParcels0.PackagingId = "";
rateRequestShippingInfoParcels0.WeightInPounds = 0.4;
rateRequestShippingInfoParcels0.LengthInInches = 5;
rateRequestShippingInfoParcels0.WidthInInches = 4;
rateRequestShippingInfoParcels0.HeightInInches = 12;
rateRequestShippingInfoParcels0.Options = new ParcelOptions();
rateRequestShippingInfoParcels0.Options.Return = ReturnEnum.NOTAPPLICABLE;
rateRequestShippingInfoParcels0.Options.InsuranceAmount = 0;
rateRequestShippingInfoParcels0.Options.Signature = SignatureEnum.NOTAPPLICABLE;
rateRequestShippingInfoParcels0.Options.Cod = new CODOptions();
rateRequestShippingInfoParcels0.Options.Cod.CodType = CodTypeEnum.NOTAPPLICABLE;
rateRequestShippingInfoParcels0.Options.Cod.CodAmount = 0;
rateRequestShippingInfoParcels0.Options.Machinable = true;
rateRequestShippingInfoParcels0.Options.HoldForPickup = false;
rateRequest.ShippingInfo.Parcels.Add(rateRequestShippingInfoParcels0);


try
{
    RateResponse result = await ratesDisplayController.GetRatesWithDisplayAsync(rateRequest);
}
catch (ApiException e){};
```

