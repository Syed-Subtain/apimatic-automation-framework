# Carrier Details

```csharp
CarrierDetailsController carrierDetailsController = client.CarrierDetailsController;
```

## Class Name

`CarrierDetailsController`

## Methods

* [Get Carrier Service Information](/doc/controllers/carrier-details.md#get-carrier-service-information)
* [Verify Package Length Girth Limit](/doc/controllers/carrier-details.md#verify-package-length-girth-limit)
* [Get Carrier Parcel Specification](/doc/controllers/carrier-details.md#get-carrier-parcel-specification)


# Get Carrier Service Information

Multiple API methods require this information.

```csharp
GetCarrierServiceInformationAsync(
    Models.GetCarrierServiceInformationRequestv21 input = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `input` | [`Models.GetCarrierServiceInformationRequestv21`](/doc/models/get-carrier-service-information-requestv-21.md) | Body, Optional | - |

## Response Type

[`Task<Models.GetCarrierServiceInformationResponsev21>`](/doc/models/get-carrier-service-information-responsev-21.md)

## Example Usage

```csharp
var input = new GetCarrierServiceInformationRequestv21();
input.AccessToken = "<YOUR ACCESS TOKEN>";
input.AsClientId = 12;

try
{
    GetCarrierServiceInformationResponsev21 result = await carrierDetailsController.GetCarrierServiceInformationAsync(input);
}
catch (ApiException e){};
```

## Example Response *(as JSON)*

```json
{
  "carrierServiceList": [
    {
      "carrierClientContractId": 123,
      "affillateName": "USPS",
      "carrierName": "USPS",
      "nickName": "United States Postal Service",
      "serviceLevels": [
        {
          "carrierServiceLevelID": 23,
          "name": "Priority Mail",
          "parcelWeightLimit": 70.0,
          "isInternational": false
        },
        {
          "carrierServiceLevelID": 34,
          "name": "Express Mail Int'l",
          "parcelWeightLimit": 70.0,
          "isInternational": true
        }
      ],
      "error": {
        "details": [],
        "hasError": false
      }
    }
  ],
  "error": {
    "details": [],
    "hasError": false
  }
}
```


# Verify Package Length Girth Limit

Verifies packages height, length, and width.

```csharp
VerifyPackageLengthGirthLimitAsync(
    Models.VerifyPackageLengthGirthLimitRequestv21 input = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `input` | [`Models.VerifyPackageLengthGirthLimitRequestv21`](/doc/models/verify-package-length-girth-limit-requestv-21.md) | Body, Optional | - |

## Response Type

[`Task<Models.VerifyPackageLengthGirthLimitResponsev21>`](/doc/models/verify-package-length-girth-limit-responsev-21.md)

## Example Usage

```csharp
var input = new VerifyPackageLengthGirthLimitRequestv21();
input.AccessToken = "<YOUR ACCESS TOKEN>";
input.Request = new PackageLengthGirthModelV21();
input.Request.CarrierServiceLevelId = 12;
input.Request.PackageList = new List<PackagesV21>();

var inputRequestPackageList0 = new PackagesV21();
inputRequestPackageList0.Length = 6;
inputRequestPackageList0.Width = 8;
inputRequestPackageList0.Height = 12;
input.Request.PackageList.Add(inputRequestPackageList0);

var inputRequestPackageList1 = new PackagesV21();
inputRequestPackageList1.Length = 6;
inputRequestPackageList1.Width = 8;
inputRequestPackageList1.Height = 12;
input.Request.PackageList.Add(inputRequestPackageList1);


try
{
    VerifyPackageLengthGirthLimitResponsev21 result = await carrierDetailsController.VerifyPackageLengthGirthLimitAsync(input);
}
catch (ApiException e){};
```

## Example Response *(as JSON)*

```json
{
  "error": {
    "details": [],
    "hasError": false
  },
  "valid": true
}
```


# Get Carrier Parcel Specification

Details include parcel weight limits and maximum dimensions.

```csharp
GetCarrierParcelSpecificationAsync(
    Models.GetCarrierParcelSpecificationRequestv21 input = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `input` | [`Models.GetCarrierParcelSpecificationRequestv21`](/doc/models/get-carrier-parcel-specification-requestv-21.md) | Body, Optional | - |

## Response Type

[`Task<Models.GetCarrierParcelSpecificationResponsev21>`](/doc/models/get-carrier-parcel-specification-responsev-21.md)

## Example Usage

```csharp
var input = new GetCarrierParcelSpecificationRequestv21();
input.AccessToken = "<YOUR ACCESS TOKEN>";
input.CarrierClientContractId = 24;
input.AsClientId = 12;

try
{
    GetCarrierParcelSpecificationResponsev21 result = await carrierDetailsController.GetCarrierParcelSpecificationAsync(input);
}
catch (ApiException e){};
```

## Example Response *(as JSON)*

```json
{
  "parcelDetails": [
    {
      "parcelId": "102-0",
      "name": "Large Envelope or Flat",
      "description": "Large Envelope or Flat",
      "lengthInInches": 12.0,
      "widthInInches": 0.75,
      "heightInInches": 4.0,
      "weightLimit": 0.8,
      "packagingWeight": 0.0
    },
    {
      "parcelId": "115-0",
      "name": "Flat Rate Large Box",
      "description": "Large Flat Rate Box",
      "lengthInInches": 12.0,
      "widthInInches": 5.5,
      "heightInInches": 4.0,
      "weightLimit": 70.0,
      "packagingWeight": 0.0
    }
  ],
  "error": {
    "details": [],
    "hasError": false
  }
}
```

