# Account Information

```csharp
AccountInformationController accountInformationController = client.AccountInformationController;
```

## Class Name

`AccountInformationController`


# Get Carrier Balance

Includes:Threshold, Recharge Amount, and Balance.

```csharp
GetCarrierBalanceAsync(
    Models.GetCarrierBalanceRequestv21 input = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `input` | [`Models.GetCarrierBalanceRequestv21`](/doc/models/get-carrier-balance-requestv-21.md) | Body, Optional | - |

## Response Type

[`Task<Models.GetCarrierBalanceResponsev21>`](/doc/models/get-carrier-balance-responsev-21.md)

## Example Usage

```csharp
var input = new GetCarrierBalanceRequestv21();
input.AccessToken = "<YOUR ACCESS TOKEN>";
input.CarrierClientContractId = 34;
input.AsClientId = 12;

try
{
    GetCarrierBalanceResponsev21 result = await accountInformationController.GetCarrierBalanceAsync(input);
}
catch (ApiException e){};
```

## Example Response *(as JSON)*

```json
{
  "threshold": 20.0,
  "rechargeAmount": 10.0,
  "balance": 23.45,
  "error": {
    "details": [],
    "hasError": false
  }
}
```

