# Country Codes

```csharp
CountryCodesController countryCodesController = client.CountryCodesController;
```

## Class Name

`CountryCodesController`


# Get Country Codes

Country information is needed for constructing addresses.

```csharp
GetCountryCodesAsync(
    Models.CountryCodesRequestv21 input = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `input` | [`Models.CountryCodesRequestv21`](/doc/models/country-codes-requestv-21.md) | Body, Optional | - |

## Response Type

[`Task<Models.CountryCodesResponsev21>`](/doc/models/country-codes-responsev-21.md)

## Example Usage

```csharp
var input = new CountryCodesRequestv21();
input.AccessToken = "<YOUR ACCESS TOKEN>";
input.AsClientId = 14;

try
{
    CountryCodesResponsev21 result = await countryCodesController.GetCountryCodesAsync(input);
}
catch (ApiException e){};
```

## Example Response *(as JSON)*

```json
{
  "countryCodeList": [
    {
      "countryId": 10,
      "countryName": "Antarctica",
      "alpha2CountryCode": "AQ"
    },
    {
      "countryId": 840,
      "countryName": "United States",
      "alpha2CountryCode": "US"
    }
  ],
  "error": {
    "details": [],
    "hasError": false
  }
}
```

