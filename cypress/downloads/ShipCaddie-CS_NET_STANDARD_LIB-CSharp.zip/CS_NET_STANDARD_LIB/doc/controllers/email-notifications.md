# Email Notifications

```csharp
EmailNotificationsController emailNotificationsController = client.EmailNotificationsController;
```

## Class Name

`EmailNotificationsController`


# Update Email Notification

Email notifications can be turned on or off for each carrier.

```csharp
UpdateEmailNotificationAsync(
    Models.UpdateEmailNotificationRequestv21 input = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `input` | [`Models.UpdateEmailNotificationRequestv21`](/doc/models/update-email-notification-requestv-21.md) | Body, Optional | - |

## Response Type

[`Task<Models.UpdateEmailNotificationResponsev21>`](/doc/models/update-email-notification-responsev-21.md)

## Example Usage

```csharp
var input = new UpdateEmailNotificationRequestv21();
input.AccessToken = "<YOUR ACCESS TOKEN>";
input.CarrierClientContractId = 19;
input.NotifyByEmail = true;
input.AsClientId = 12;

try
{
    UpdateEmailNotificationResponsev21 result = await emailNotificationsController.UpdateEmailNotificationAsync(input);
}
catch (ApiException e){};
```

## Example Response *(as JSON)*

```json
{
  "successfullyUpdatedEmailNotification": true,
  "error": {
    "details": [],
    "hasError": false
  }
}
```

