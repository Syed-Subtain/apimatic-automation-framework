# Authentication

```csharp
AuthenticationController authenticationController = client.AuthenticationController;
```

## Class Name

`AuthenticationController`

## Methods

* [Get Token](/doc/controllers/authentication.md#get-token)
* [Refresh Token](/doc/controllers/authentication.md#refresh-token)


# Get Token

Token contains an expiration date, TokenExpirationDate, that expires in 30 days. When the token expires, use 'RefreshToken' endpoint to obtain a new token.

```csharp
GetTokenAsync(
    Models.Credentials input = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `input` | [`Models.Credentials`](/doc/models/credentials.md) | Body, Optional | - |

## Response Type

[`Task<Models.SecurityToken>`](/doc/models/security-token.md)

## Example Usage

```csharp
var input = new Credentials();
input.UserName = "<Your UserName>";
input.Password = "<Your Password>";

try
{
    SecurityToken result = await authenticationController.GetTokenAsync(input);
}
catch (ApiException e){};
```

## Example Response *(as JSON)*

```json
{
  "accessToken": "C_SkR2QvI25BljqKgVpt1d... (Truncated)",
  "refreshToken": "0e842ea7c4a046ceab8b5e3283321a08",
  "refreshTokenExpirationDate": "2020-12-23T23:54:10.3273331Z",
  "accessTokenExpirationDate": "2020-12-23T23:54:10.3273331Z",
  "error": {
    "details": [],
    "hasError": false
  }
}
```


# Refresh Token

This method must be called before the refresh token expiration date, TokenExpirationDate. Token expires in 30 days.

```csharp
RefreshTokenAsync(
    Models.SecurityTokenRequest input = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `input` | [`Models.SecurityTokenRequest`](/doc/models/security-token-request.md) | Body, Optional | - |

## Response Type

[`Task<Models.SecurityToken>`](/doc/models/security-token.md)

## Example Usage

```csharp
var input = new SecurityTokenRequest();
input.RefreshToken = "<YOUR REFRESH TOKEN>";

try
{
    SecurityToken result = await authenticationController.RefreshTokenAsync(input);
}
catch (ApiException e){};
```

## Example Response *(as JSON)*

```json
{
  "accessToken": "C_SkR2QvI25BljqKgVpt1d... (Truncated)",
  "refreshToken": "0e842ea7c4a046ceab8b5e3283321a08",
  "refreshTokenExpirationDate": "2020-12-23T23:54:10.3273331Z",
  "accessTokenExpirationDate": "2020-12-23T23:54:10.3273331Z",
  "error": {
    "details": [],
    "hasError": false
  }
}
```

