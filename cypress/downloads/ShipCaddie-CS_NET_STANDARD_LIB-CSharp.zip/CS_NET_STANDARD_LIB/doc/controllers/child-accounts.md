# Child Accounts

```csharp
ChildAccountsController childAccountsController = client.ChildAccountsController;
```

## Class Name

`ChildAccountsController`


# Get Child Accounts

Obtain child accounts which are associated with this account.

```csharp
GetChildAccountsAsync(
    Models.GetChildAccountsRequestv21 input = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `input` | [`Models.GetChildAccountsRequestv21`](/doc/models/get-child-accounts-requestv-21.md) | Body, Optional | - |

## Response Type

[`Task<Models.GetChildAccountsResponsev21>`](/doc/models/get-child-accounts-responsev-21.md)

## Example Usage

```csharp
var input = new GetChildAccountsRequestv21();
input.AccessToken = "<YOUR ACCESS TOKEN>";

try
{
    GetChildAccountsResponsev21 result = await childAccountsController.GetChildAccountsAsync(input);
}
catch (ApiException e){};
```

## Example Response *(as JSON)*

```json
{
  "error": {
    "details": [],
    "hasError": false
  },
  "childAccounts": [
    {
      "clientId": 343,
      "name": "Company A",
      "isEnabled": true
    },
    {
      "clientId": 233,
      "name": "Company B",
      "isEnabled": false
    }
  ]
}
```

