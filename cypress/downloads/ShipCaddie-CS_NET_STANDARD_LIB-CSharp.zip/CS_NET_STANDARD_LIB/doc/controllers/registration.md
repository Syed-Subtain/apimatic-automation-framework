# Registration

```csharp
RegistrationController registrationController = client.RegistrationController;
```

## Class Name

`RegistrationController`


# Register Account

Allows a registration of a new account.

```csharp
RegisterAccountAsync(
    Models.RegisterAccountLimitRequestv21 input = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `input` | [`Models.RegisterAccountLimitRequestv21`](/doc/models/register-account-limit-requestv-21.md) | Body, Optional | - |

## Response Type

[`Task<Models.RegisterAccountResponsev21>`](/doc/models/register-account-responsev-21.md)

## Example Usage

```csharp
var input = new RegisterAccountLimitRequestv21();
input.RegistrationInformation = new UserRegisterModelv21();
input.RegistrationInformation.SystemCountryId = 840;
input.RegistrationInformation.NameFirst = "Tom";
input.RegistrationInformation.NameLast = "Thomson";
input.RegistrationInformation.CompanyName = "Ace";
input.RegistrationInformation.PhoneNumber = "123 456-7890";
input.RegistrationInformation.UserName = "User Name";
input.RegistrationInformation.Password = "Password";
input.RegistrationInformation.PasswordVerify = "Password";
input.RegistrationInformation.PromoCode = "";
input.RegistrationInformation.SubscriptionTierId = 1;
input.RegistrationInformation.IAgree = "yes";

try
{
    RegisterAccountResponsev21 result = await registrationController.RegisterAccountAsync(input);
}
catch (ApiException e){};
```

## Example Response *(as JSON)*

```json
{
  "error": {
    "details": [],
    "hasError": false
  },
  "success": true
}
```

