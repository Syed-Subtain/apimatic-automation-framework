# Address Validation

```csharp
AddressValidationController addressValidationController = client.AddressValidationController;
```

## Class Name

`AddressValidationController`


# Validate Address

Use this function to validate an address.

```csharp
ValidateAddressAsync(
    Models.ValidateAddressRequestv21 input = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `input` | [`Models.ValidateAddressRequestv21`](/doc/models/validate-address-requestv-21.md) | Body, Optional | - |

## Response Type

[`Task<Models.ValidateAddressResponsev21>`](/doc/models/validate-address-responsev-21.md)

## Example Usage

```csharp
var input = new ValidateAddressRequestv21();
input.AccessToken = "<YOUR ACCESS TOKEN>";
input.AddressToValidate = new Addressv21();
input.AddressToValidate.Address1 = "2600 Executive Parkway";
input.AddressToValidate.City = "Lehi";
input.AddressToValidate.CountryCode = "US";
input.AddressToValidate.StateOrProvidence = "UT";
input.AddressToValidate.PostalCode = "84043";
input.AddressToValidate.Address2 = "Suite 160";
input.AddressToValidate.IsResidential = false;
input.AddressToValidate.AttentionOf = "Mr. Jones";
input.AddressToValidate.CompanyName = "iDrive Logistics";
input.AddressToValidate.Email = "sales@idrivelogistics.com";
input.AddressToValidate.PhoneNumber = "(888) 797-0929";
input.AsClientId = 14;

try
{
    ValidateAddressResponsev21 result = await addressValidationController.ValidateAddressAsync(input);
}
catch (ApiException e){};
```

## Example Response *(as JSON)*

```json
{
  "addressIsValidated": true,
  "validationMessages": [
    {
      "code": "Default Match",
      "message": "Street address (directional or suffix only) was corrected to validate the address. Please check this correction prior to using address."
    }
  ],
  "validatedAddress": {
    "address1": "2600 W Executive Pkwy Ste 160",
    "address2": "",
    "city": "LEHI",
    "countryCode": "US",
    "stateOrProvidence": "UT",
    "postalCode": "84043-3987",
    "isResidential": false,
    "attentionOf": "Mr. Jones",
    "companyName": "iDrive Logistics",
    "email": "sales@idrivelogistics.com",
    "phoneNumber": "8887970929"
  },
  "error": {
    "details": [],
    "hasError": false
  }
}
```

