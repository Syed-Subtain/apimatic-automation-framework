# Shipments

```csharp
ShipmentsController shipmentsController = client.ShipmentsController;
```

## Class Name

`ShipmentsController`

## Methods

* [Update Shipment](/doc/controllers/shipments.md#update-shipment)
* [Delete Shipment by ID](/doc/controllers/shipments.md#delete-shipment-by-id)
* [Get Shipment Items by Sku](/doc/controllers/shipments.md#get-shipment-items-by-sku)
* [Add Shipment](/doc/controllers/shipments.md#add-shipment)
* [Get Shipment Information](/doc/controllers/shipments.md#get-shipment-information)
* [Get Shipped Info](/doc/controllers/shipments.md#get-shipped-info)


# Update Shipment

UpdateShipment:    Updates existing Shipment information

```csharp
UpdateShipmentAsync(
    Models.UpdateShipmentRequest input = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `input` | [`Models.UpdateShipmentRequest`](/doc/models/update-shipment-request.md) | Body, Optional | - |

## Response Type

[`Task<Models.ShippingCostData>`](/doc/models/shipping-cost-data.md)

## Example Usage

```csharp
var input = new UpdateShipmentRequest();
input.AccessToken = "<YOUR ACCESS TOKEN>";
input.AsClientId = 12;
input.ShipmentId = 37;
input.Shipment = new ShipmentInformation();
input.Shipment.DateShipped = DateTime.Parse("2020-12-23T23:54:10.3585858Z");
input.Shipment.CarrierClientContractId = 2404;
input.Shipment.CarrierServiceLevelId = 1115;
input.Shipment.AddressFrom = new ShipFromAddress();
input.Shipment.AddressFrom.CompanyName = "iDrive Logistics";
input.Shipment.AddressFrom.Email = "sales@idrivelogistics.com";
input.Shipment.AddressFrom.PhoneNumber = "(888) 797-0929";
input.Shipment.AddressFrom.Address1 = "2600 Executive Pkwy #160";
input.Shipment.AddressFrom.Address2 = "";
input.Shipment.AddressFrom.City = "Lehi";
input.Shipment.AddressFrom.StateOrProvince = "UT";
input.Shipment.AddressFrom.PostalCode = "84043";
input.Shipment.AddressFrom.CountryCode = "US";
input.Shipment.AddressTo = new ShipToAddress();
input.Shipment.AddressTo.AttentionOf = "Mr. Jones";
input.Shipment.AddressTo.CompanyName = "iDrive Logistics";
input.Shipment.AddressTo.Email = "sales@idrivelogistics.com";
input.Shipment.AddressTo.PhoneNumber = "(888) 797-0929";
input.Shipment.AddressTo.Address1 = "2605 Executive Pkwy #160";
input.Shipment.AddressTo.Address2 = "";
input.Shipment.AddressTo.IsResidential = false;
input.Shipment.AddressTo.City = "Lehi";
input.Shipment.AddressTo.StateOrProvince = "UT";
input.Shipment.AddressTo.PostalCode = "84043";
input.Shipment.AddressTo.CountryCode = "US";
input.Shipment.Parcels = new List<ParcelDetail>();

var inputShipmentParcels0 = new ParcelDetail();
inputShipmentParcels0.WeightInPounds = 0.4;
inputShipmentParcels0.LengthInInches = 5;
inputShipmentParcels0.WidthInInches = 4;
inputShipmentParcels0.HeightInInches = 12;
inputShipmentParcels0.Options = new ParcelOptions();
inputShipmentParcels0.Options.Return = ReturnEnum.NOTAPPLICABLE;
inputShipmentParcels0.Options.InsuranceAmount = 0;
inputShipmentParcels0.Options.Signature = SignatureEnum.NOTAPPLICABLE;
inputShipmentParcels0.Options.Cod = new CODOptions();
inputShipmentParcels0.Options.Cod.CodType = CodTypeEnum.NOTAPPLICABLE;
inputShipmentParcels0.Options.Cod.CodAmount = 0;
inputShipmentParcels0.ReferenceField1 = "1";
inputShipmentParcels0.ReferenceField2 = "";
inputShipmentParcels0.ReferenceField3 = "";
inputShipmentParcels0.ParcelID = "1";
inputShipmentParcels0.PackagingId = "";
inputShipmentParcels0.ParcelItems = new List<ParcelContent>();

var inputShipmentParcels0ParcelItems0 = new ParcelContent();
inputShipmentParcels0ParcelItems0.Name = "chocolate";
inputShipmentParcels0ParcelItems0.Quantity = 7;
inputShipmentParcels0ParcelItems0.Price = 1.03;
inputShipmentParcels0ParcelItems0.WeightInPounds = 0.5;
inputShipmentParcels0ParcelItems0.OriginCountry = "US";
inputShipmentParcels0ParcelItems0.Sku = "none";
inputShipmentParcels0ParcelItems0.Description = "candy";
inputShipmentParcels0ParcelItems0.HarmonizeCode = "";
inputShipmentParcels0.ParcelItems.Add(inputShipmentParcels0ParcelItems0);

input.Shipment.Parcels.Add(inputShipmentParcels0);

input.Shipment.OrderReferenceNumber = "test order";
input.Shipment.Options = new ShippingOptions();
input.Shipment.Options.IsAPOFPODPOUSTerritory = false;
input.Shipment.Options.IsInternationalShipment = false;
input.Shipment.Options.Billing = new BillingOptions();
input.Shipment.Options.Billing.ShippingPaidBy = ShippingPaidByEnum.NOTAPPLICABLE;
input.Shipment.Options.Billing.DutiesPaidBy = DutiesPaidByEnum.NOTAPPLICABLE;
input.Shipment.Options.Billing.AccountNumber = "";
input.Shipment.Options.Billing.PostalCode = "";
input.Shipment.Options.Billing.CountryAlpha2Code = "";
input.Shipment.Options.ShipmentContentType = ShipmentContentTypeEnum.CONTENTTYPESAMPLE;

try
{
    ShippingCostData result = await shipmentsController.UpdateShipmentAsync(input);
}
catch (ApiException e){};
```

## Example Response *(as JSON)*

```json
{
  "shippingCost": {
    "shipmentId": 12,
    "orderReferenceNumber": "123",
    "parcelChargeDetails": [
      {
        "parcelID": "1",
        "costDetails": [
          {
            "name": "FREIGHT",
            "amount": 3.23,
            "amountDisplay": 0.0
          }
        ]
      }
    ],
    "shippingChargeDetails": [
      {
        "name": "Charge",
        "amount": 2.34,
        "amountDisplay": 0.0
      }
    ],
    "transitDaysMin": -1,
    "transitDaysMax": -1,
    "totalChargeAmount": -1.0,
    "isDeliveryGuaranteed": false
  },
  "error": {
    "details": [],
    "hasError": false
  }
}
```


# Delete Shipment by ID

```csharp
DeleteShipmentByIDAsync(
    Models.ShipmentRequestByID input = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `input` | [`Models.ShipmentRequestByID`](/doc/models/shipment-request-by-id.md) | Body, Optional | - |

## Response Type

[`Task<Models.DeleteShipmentResult>`](/doc/models/delete-shipment-result.md)

## Example Usage

```csharp
var input = new ShipmentRequestByID();
input.AccessToken = "<YOUR ACCESS TOKEN>";
input.AsClientId = 12;
input.ShipmentID = 37;

try
{
    DeleteShipmentResult result = await shipmentsController.DeleteShipmentByIDAsync(input);
}
catch (ApiException e){};
```

## Example Response *(as JSON)*

```json
{
  "shipmentId": 23,
  "isDeleted": true,
  "error": {
    "details": [],
    "hasError": false
  }
}
```


# Get Shipment Items by Sku

This method can be used to get the shipments inventeries by sku within given date range.

```csharp
GetShipmentItemsBySkuAsync(
    Models.ShipmentRequestByDate input = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `input` | [`Models.ShipmentRequestByDate`](/doc/models/shipment-request-by-date.md) | Body, Optional | - |

## Response Type

[`Task<Models.ShipmentInventoryBySkuResponseModel>`](/doc/models/shipment-inventory-by-sku-response-model.md)

## Example Usage

```csharp
var input = new ShipmentRequestByDate();
input.AccessToken = "<YOUR ACCESS TOKEN>";
input.AsClientId = 12;
input.StartDate = DateTime.Parse("2020-12-23T23:54:10.2804606+00:00");
input.EndDate = DateTime.Parse("2020-12-23T23:54:10.2804606+00:00");

try
{
    ShipmentInventoryBySkuResponseModel result = await shipmentsController.GetShipmentItemsBySkuAsync(input);
}
catch (ApiException e){};
```

## Example Response *(as JSON)*

```json
{
  "shipmentInventoryBySku_Response": [
    {
      "sku": "TestSku1",
      "name": "TestName",
      "qty": 2,
      "dateShipped": "0001-01-01T00:00:00"
    },
    {
      "sku": "TestSku2",
      "name": "TestName2",
      "qty": 5,
      "dateShipped": "0001-01-01T00:00:00"
    }
  ],
  "error": {
    "details": [],
    "hasError": false
  }
}
```


# Add Shipment

After successfully adding a shipment request,
use the Get Shipping Labels by ShippingID
to get the shipping label.

```csharp
AddShipmentAsync(
    Models.AddShipmentRequest input = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `input` | [`Models.AddShipmentRequest`](/doc/models/add-shipment-request.md) | Body, Optional | - |

## Response Type

[`Task<Models.ShippingCostData>`](/doc/models/shipping-cost-data.md)

## Example Usage

```csharp
var input = new AddShipmentRequest();
input.AccessToken = "<YOUR ACCESS TOKEN>";
input.AsClientId = 12;
input.Shipment = new ShipmentInformation();
input.Shipment.DateShipped = DateTime.Parse("2020-12-23T23:54:10.0929416Z");
input.Shipment.CarrierClientContractId = 2404;
input.Shipment.CarrierServiceLevelId = 1115;
input.Shipment.AddressFrom = new ShipFromAddress();
input.Shipment.AddressFrom.CompanyName = "iDrive Logistics";
input.Shipment.AddressFrom.Email = "sales@idrivelogistics.com";
input.Shipment.AddressFrom.PhoneNumber = "(888) 797-0929";
input.Shipment.AddressFrom.Address1 = "2600 Executive Pkwy #160";
input.Shipment.AddressFrom.Address2 = "";
input.Shipment.AddressFrom.City = "Lehi";
input.Shipment.AddressFrom.StateOrProvince = "UT";
input.Shipment.AddressFrom.PostalCode = "84043";
input.Shipment.AddressFrom.CountryCode = "US";
input.Shipment.AddressTo = new ShipToAddress();
input.Shipment.AddressTo.AttentionOf = "Mr. Jones";
input.Shipment.AddressTo.CompanyName = "iDrive Logistics";
input.Shipment.AddressTo.Email = "sales@idrivelogistics.com";
input.Shipment.AddressTo.PhoneNumber = "(888) 797-0929";
input.Shipment.AddressTo.Address1 = "2605 Executive Pkwy #160";
input.Shipment.AddressTo.Address2 = "";
input.Shipment.AddressTo.IsResidential = false;
input.Shipment.AddressTo.City = "Lehi";
input.Shipment.AddressTo.StateOrProvince = "UT";
input.Shipment.AddressTo.PostalCode = "84043";
input.Shipment.AddressTo.CountryCode = "US";
input.Shipment.Parcels = new List<ParcelDetail>();

var inputShipmentParcels0 = new ParcelDetail();
inputShipmentParcels0.WeightInPounds = 0.4;
inputShipmentParcels0.LengthInInches = 5;
inputShipmentParcels0.WidthInInches = 4;
inputShipmentParcels0.HeightInInches = 12;
inputShipmentParcels0.Options = new ParcelOptions();
inputShipmentParcels0.Options.Return = ReturnEnum.NOTAPPLICABLE;
inputShipmentParcels0.Options.InsuranceAmount = 0;
inputShipmentParcels0.Options.Signature = SignatureEnum.NOTAPPLICABLE;
inputShipmentParcels0.Options.Cod = new CODOptions();
inputShipmentParcels0.Options.Cod.CodType = CodTypeEnum.NOTAPPLICABLE;
inputShipmentParcels0.Options.Cod.CodAmount = 0;
inputShipmentParcels0.ReferenceField1 = "1";
inputShipmentParcels0.ReferenceField2 = "";
inputShipmentParcels0.ReferenceField3 = "";
inputShipmentParcels0.ParcelID = "1";
inputShipmentParcels0.PackagingId = "";
inputShipmentParcels0.ParcelItems = new List<ParcelContent>();

var inputShipmentParcels0ParcelItems0 = new ParcelContent();
inputShipmentParcels0ParcelItems0.Name = "chocolate";
inputShipmentParcels0ParcelItems0.Quantity = 7;
inputShipmentParcels0ParcelItems0.Price = 1.03;
inputShipmentParcels0ParcelItems0.WeightInPounds = 0.5;
inputShipmentParcels0ParcelItems0.OriginCountry = "US";
inputShipmentParcels0ParcelItems0.Sku = "none";
inputShipmentParcels0ParcelItems0.Description = "candy";
inputShipmentParcels0ParcelItems0.HarmonizeCode = "";
inputShipmentParcels0.ParcelItems.Add(inputShipmentParcels0ParcelItems0);

input.Shipment.Parcels.Add(inputShipmentParcels0);

input.Shipment.OrderReferenceNumber = "test order";
input.Shipment.Options = new ShippingOptions();
input.Shipment.Options.IsAPOFPODPOUSTerritory = false;
input.Shipment.Options.IsInternationalShipment = false;
input.Shipment.Options.Billing = new BillingOptions();
input.Shipment.Options.Billing.ShippingPaidBy = ShippingPaidByEnum.NOTAPPLICABLE;
input.Shipment.Options.Billing.DutiesPaidBy = DutiesPaidByEnum.NOTAPPLICABLE;
input.Shipment.Options.Billing.AccountNumber = "";
input.Shipment.Options.Billing.PostalCode = "";
input.Shipment.Options.Billing.CountryAlpha2Code = "";
input.Shipment.Options.ShipmentContentType = ShipmentContentTypeEnum.CONTENTTYPESAMPLE;

try
{
    ShippingCostData result = await shipmentsController.AddShipmentAsync(input);
}
catch (ApiException e){};
```

## Example Response *(as JSON)*

```json
{
  "shippingCost": {
    "shipmentId": 12,
    "orderReferenceNumber": "123",
    "parcelChargeDetails": [
      {
        "parcelID": "1",
        "costDetails": [
          {
            "name": "FREIGHT",
            "amount": 3.23,
            "amountDisplay": 0.0
          }
        ]
      }
    ],
    "shippingChargeDetails": [
      {
        "name": "Charge",
        "amount": 2.34,
        "amountDisplay": 0.0
      }
    ],
    "transitDaysMin": -1,
    "transitDaysMax": -1,
    "totalChargeAmount": -1.0,
    "isDeliveryGuaranteed": false
  },
  "error": {
    "details": [],
    "hasError": false
  }
}
```


# Get Shipment Information

This method can be used to get the information necessary to update a shipment.

```csharp
GetShipmentInformationAsync(
    Models.ShipmentRequestByID input = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `input` | [`Models.ShipmentRequestByID`](/doc/models/shipment-request-by-id.md) | Body, Optional | - |

## Response Type

[`Task<Models.ShipmentInformationResponse>`](/doc/models/shipment-information-response.md)

## Example Usage

```csharp
var input = new ShipmentRequestByID();
input.AccessToken = "<YOUR ACCESS TOKEN>";
input.AsClientId = 12;
input.ShipmentID = 37;

try
{
    ShipmentInformationResponse result = await shipmentsController.GetShipmentInformationAsync(input);
}
catch (ApiException e){};
```

## Example Response *(as JSON)*

```json
{
  "shipmentId": 37,
  "error": {
    "details": [],
    "hasError": false
  },
  "shipment": {
    "orderReferenceNumber": "test order",
    "dateShipped": "2020-12-23T23:54:10.2804606Z",
    "options": {
      "isAPO_FPO_DPO_USTerritory": false,
      "isInternationalShipment": false,
      "billing": {
        "shippingPaidBy": "NOT_APPLICABLE",
        "accountNumber": "",
        "postalCode": "",
        "country_Alpha2Code": "",
        "dutiesPaidBy": "NOT_APPLICABLE"
      },
      "shipmentContentType": "CONTENT_TYPE_SAMPLE"
    },
    "carrierClientContractId": 2404,
    "carrierServiceLevelId": 1115,
    "addressFrom": {
      "companyName": "iDrive Logistics",
      "email": "sales@idrivelogistics.com",
      "phoneNumber": "(888) 797-0929",
      "address1": "2600 Executive Pkwy #160",
      "address2": "",
      "city": "Lehi",
      "stateOrProvince": "UT",
      "postalCode": "84043",
      "countryCode": "US"
    },
    "addressTo": {
      "attentionOf": "Mr. Jones",
      "companyName": "iDrive Logistics",
      "email": "sales@idrivelogistics.com",
      "phoneNumber": "(888) 797-0929",
      "address1": "2605 Executive Pkwy #160",
      "address2": "",
      "isResidential": false,
      "city": "Lehi",
      "stateOrProvince": "UT",
      "postalCode": "84043",
      "countryCode": "US"
    },
    "parcels": [
      {
        "referenceField1": "1",
        "referenceField2": "",
        "referenceField3": "",
        "parcelID": "1",
        "packagingId": "",
        "weightInPounds": 0.4,
        "lengthInInches": 5.0,
        "widthInInches": 4.0,
        "heightInInches": 12.0,
        "options": {
          "return": "NOT_APPLICABLE",
          "insuranceAmount": 0.0,
          "signature": "NOT_APPLICABLE",
          "cod": {
            "codType": "NOT_APPLICABLE",
            "codAmount": 0.0
          }
        },
        "parcelItems": [
          {
            "sku": "none",
            "name": "chocolate",
            "description": "candy",
            "quantity": 7,
            "price": 1.03,
            "weightInPounds": 0.5,
            "harmonizeCode": "",
            "originCountry": "US"
          }
        ]
      }
    ]
  }
}
```


# Get Shipped Info

This method can be used to get the information about a shipped shipment.

```csharp
GetShippedInfoAsync(
    Models.ShippedInfoRequest input = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `input` | [`Models.ShippedInfoRequest`](/doc/models/shipped-info-request.md) | Body, Optional | - |

## Response Type

[`Task<Models.ShippedInfoResponse>`](/doc/models/shipped-info-response.md)

## Example Usage

```csharp
try
{
    ShippedInfoResponse result = await shipmentsController.GetShippedInfoAsync(null);
}
catch (ApiException e){};
```

## Example Response *(as JSON)*

```json
{
  "shipmentId": 37,
  "error": {
    "details": [],
    "hasError": false
  },
  "shipment": {
    "orderReferenceNumber": "test order",
    "dateShipped": "2020-12-23T23:54:10.2960842Z",
    "options": {
      "isAPO_FPO_DPO_USTerritory": false,
      "isInternationalShipment": false,
      "billing": {
        "shippingPaidBy": "NOT_APPLICABLE",
        "accountNumber": "",
        "postalCode": "",
        "country_Alpha2Code": "",
        "dutiesPaidBy": "NOT_APPLICABLE"
      },
      "shipmentContentType": "CONTENT_TYPE_SAMPLE"
    },
    "carrierClientContractId": 2404,
    "carrierServiceLevelId": 1115,
    "addressFrom": {
      "companyName": "iDrive Logistics",
      "email": "sales@idrivelogistics.com",
      "phoneNumber": "(888) 797-0929",
      "address1": "2600 Executive Pkwy #160",
      "address2": "",
      "city": "Lehi",
      "stateOrProvince": "UT",
      "postalCode": "84043",
      "countryCode": "US"
    },
    "addressTo": {
      "attentionOf": "Mr. Jones",
      "companyName": "iDrive Logistics",
      "email": "sales@idrivelogistics.com",
      "phoneNumber": "(888) 797-0929",
      "address1": "2605 Executive Pkwy #160",
      "address2": "",
      "isResidential": false,
      "city": "Lehi",
      "stateOrProvince": "UT",
      "postalCode": "84043",
      "countryCode": "US"
    },
    "parcels": [
      {
        "referenceField1": "1",
        "referenceField2": "",
        "referenceField3": "",
        "parcelID": "1",
        "packagingId": "",
        "weightInPounds": 0.4,
        "lengthInInches": 5.0,
        "widthInInches": 4.0,
        "heightInInches": 12.0,
        "options": {
          "return": "NOT_APPLICABLE",
          "insuranceAmount": 0.0,
          "signature": "NOT_APPLICABLE",
          "cod": {
            "codType": "NOT_APPLICABLE",
            "codAmount": 0.0
          }
        },
        "parcelItems": [
          {
            "sku": "none",
            "name": "chocolate",
            "description": "candy",
            "quantity": 7,
            "price": 1.03,
            "weightInPounds": 0.5,
            "harmonizeCode": "",
            "originCountry": "US"
          }
        ]
      }
    ]
  }
}
```

