# Address Validation Shipment

```csharp
AddressValidationShipmentController addressValidationShipmentController = client.AddressValidationShipmentController;
```

## Class Name

`AddressValidationShipmentController`


# Validate Shipment Address

Use this function to validate an address.

```csharp
ValidateShipmentAddressAsync(
    Models.ValidateShipmentAddressRequest input = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `input` | [`Models.ValidateShipmentAddressRequest`](/doc/models/validate-shipment-address-request.md) | Body, Optional | - |

## Response Type

[`Task<Models.AddressValidationResponseReturnModel>`](/doc/models/address-validation-response-return-model.md)

## Example Usage

```csharp
var input = new ValidateShipmentAddressRequest();
input.AccessToken = "<YOUR ACCESS TOKEN>";
input.AsClientId = 14;
input.ShipmentAddressToValidate = new AddressValidationRequestModel();
input.ShipmentAddressToValidate.CarrierId = 4;
input.ShipmentAddressToValidate.CarrierContractId = 2324;
input.ShipmentAddressToValidate.Addresses = new List<AddressValidationModel>();

var inputShipmentAddressToValidateAddresses0 = new AddressValidationModel();
inputShipmentAddressToValidateAddresses0.Address1 = "2600 Executive Parkway";
inputShipmentAddressToValidateAddresses0.Address2 = "Suite 160";
inputShipmentAddressToValidateAddresses0.ProvinceCode = "UT";
inputShipmentAddressToValidateAddresses0.City = "Lehi";
inputShipmentAddressToValidateAddresses0.CountryCode = "US";
inputShipmentAddressToValidateAddresses0.PostalCode = "84043";
inputShipmentAddressToValidateAddresses0.AddressTypeId = AddressTypeIdEnum.Commercial;
inputShipmentAddressToValidateAddresses0.CompanyName = "iDrive Logistics";
inputShipmentAddressToValidateAddresses0.CountryId = 0;
inputShipmentAddressToValidateAddresses0.AddressStatus = false;
input.ShipmentAddressToValidate.Addresses.Add(inputShipmentAddressToValidateAddresses0);


try
{
    AddressValidationResponseReturnModel result = await addressValidationShipmentController.ValidateShipmentAddressAsync(input);
}
catch (ApiException e){};
```

