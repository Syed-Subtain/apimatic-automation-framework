# Rates

```csharp
RatesController ratesController = client.RatesController;
```

## Class Name

`RatesController`

## Methods

* [Get Rates for All Carriers](/doc/controllers/rates.md#get-rates-for-all-carriers)
* [Get Rates](/doc/controllers/rates.md#get-rates)
* [Get Rates by Carrier](/doc/controllers/rates.md#get-rates-by-carrier)
* [Get Multiple Rates](/doc/controllers/rates.md#get-multiple-rates)


# Get Rates for All Carriers

Before creating a shipping label,
you can use this method to get a
break down of all shipping charges.
This allows you to determine
how much it would cost if you were to
actually send the parcels.

If the CarrierClientContractId is set to 0,
all carriers and service levels will be returned.

If the CarrierClientContractId is supplied but
the ServiceLevelId is set to 0 or not supplied,
only the specified carrier with all associated
service levels will be returned.

If the CarrierClientContractId is supplied and
the ServiceLevelId is also supplied,
only the specified carrier and service level
will be returned.

NOTE: HTTPS is Required to recieve a response.

```csharp
GetRatesForAllCarriersAsync(
    Models.RateRequest rateRequest = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `rateRequest` | [`Models.RateRequest`](/doc/models/rate-request.md) | Body, Optional | Shipping and parcel information<br>neccessary to calculate rates. |

## Response Type

[`Task<List<Models.RateResponse>>`](/doc/models/rate-response.md)

## Example Usage

```csharp
var rateRequest = new RateRequest();
rateRequest.AccessToken = "YOUR ACCESS TOKEN";
rateRequest.ShippingInfo = new ShippingInformation();
rateRequest.ShippingInfo.CarrierClientContractId = 2526;
rateRequest.ShippingInfo.ServiceLevelId = 0;
rateRequest.ShippingInfo.DateShipped = DateTime.Parse("2020-12-23T23:54:10.2649036Z");
rateRequest.ShippingInfo.Options = new CustomsOptions();
rateRequest.ShippingInfo.Options.IsAPOFPODPOUSTerritory = false;
rateRequest.ShippingInfo.Options.IsInternationalShipment = false;
rateRequest.ShippingInfo.Options.ShipmentContentType = ShipmentContentTypeEnum.CONTENTTYPESAMPLE;
rateRequest.ShippingInfo.AddressFrom = new ShipFromAddress();
rateRequest.ShippingInfo.AddressFrom.CompanyName = "iDrive Logistics";
rateRequest.ShippingInfo.AddressFrom.Email = "sales@idrivelogistics.com";
rateRequest.ShippingInfo.AddressFrom.PhoneNumber = "(888) 797-0929";
rateRequest.ShippingInfo.AddressFrom.Address1 = "2600 Executive Pkwy #160";
rateRequest.ShippingInfo.AddressFrom.Address2 = "";
rateRequest.ShippingInfo.AddressFrom.City = "Lehi";
rateRequest.ShippingInfo.AddressFrom.StateOrProvince = "UT";
rateRequest.ShippingInfo.AddressFrom.PostalCode = "84043";
rateRequest.ShippingInfo.AddressFrom.CountryCode = "US";
rateRequest.ShippingInfo.AddressTo = new ShipToAddress();
rateRequest.ShippingInfo.AddressTo.AttentionOf = "Mr. Jones";
rateRequest.ShippingInfo.AddressTo.CompanyName = "iDrive Logistics";
rateRequest.ShippingInfo.AddressTo.Email = "";
rateRequest.ShippingInfo.AddressTo.PhoneNumber = "";
rateRequest.ShippingInfo.AddressTo.Address1 = "2605 Executive Pkwy #160";
rateRequest.ShippingInfo.AddressTo.Address2 = "";
rateRequest.ShippingInfo.AddressTo.IsResidential = false;
rateRequest.ShippingInfo.AddressTo.City = "Lehi";
rateRequest.ShippingInfo.AddressTo.StateOrProvince = "UT";
rateRequest.ShippingInfo.AddressTo.PostalCode = "84043";
rateRequest.ShippingInfo.AddressTo.CountryCode = "US";
rateRequest.ShippingInfo.Parcels = new List<ParcelInformation>();

var rateRequestShippingInfoParcels0 = new ParcelInformation();
rateRequestShippingInfoParcels0.PackagingId = "";
rateRequestShippingInfoParcels0.WeightInPounds = 0.4;
rateRequestShippingInfoParcels0.LengthInInches = 5;
rateRequestShippingInfoParcels0.WidthInInches = 4;
rateRequestShippingInfoParcels0.HeightInInches = 12;
rateRequestShippingInfoParcels0.Options = new ParcelOptions();
rateRequestShippingInfoParcels0.Options.Return = ReturnEnum.NOTAPPLICABLE;
rateRequestShippingInfoParcels0.Options.InsuranceAmount = 0;
rateRequestShippingInfoParcels0.Options.Signature = SignatureEnum.NOTAPPLICABLE;
rateRequestShippingInfoParcels0.Options.Cod = new CODOptions();
rateRequestShippingInfoParcels0.Options.Cod.CodType = CodTypeEnum.NOTAPPLICABLE;
rateRequestShippingInfoParcels0.Options.Cod.CodAmount = 0;
rateRequestShippingInfoParcels0.Options.Machinable = true;
rateRequestShippingInfoParcels0.Options.HoldForPickup = false;
rateRequest.ShippingInfo.Parcels.Add(rateRequestShippingInfoParcels0);


try
{
    List<RateResponse> result = await ratesController.GetRatesForAllCarriersAsync(rateRequest);
}
catch (ApiException e){};
```


# Get Rates

Before creating a shipping label,
you can use this method to get a
break down of all shipping charges.
This allows you to determine
how much it would cost if you were to
actually send the parcels.

NOTE: HTTPS is Required to recieve a response.

```csharp
GetRatesAsync(
    Models.RateRequest rateRequest = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `rateRequest` | [`Models.RateRequest`](/doc/models/rate-request.md) | Body, Optional | Shipping and parcel information<br>neccessary to calculate rates. |

## Response Type

[`Task<Models.RateResponse>`](/doc/models/rate-response.md)

## Example Usage

```csharp
var rateRequest = new RateRequest();
rateRequest.AccessToken = "YOUR ACCESS TOKEN";
rateRequest.ShippingInfo = new ShippingInformation();
rateRequest.ShippingInfo.CarrierClientContractId = 2526;
rateRequest.ShippingInfo.ServiceLevelId = 0;
rateRequest.ShippingInfo.DateShipped = DateTime.Parse("2020-12-23T23:54:10.2649036Z");
rateRequest.ShippingInfo.Options = new CustomsOptions();
rateRequest.ShippingInfo.Options.IsAPOFPODPOUSTerritory = false;
rateRequest.ShippingInfo.Options.IsInternationalShipment = false;
rateRequest.ShippingInfo.Options.ShipmentContentType = ShipmentContentTypeEnum.CONTENTTYPESAMPLE;
rateRequest.ShippingInfo.AddressFrom = new ShipFromAddress();
rateRequest.ShippingInfo.AddressFrom.CompanyName = "iDrive Logistics";
rateRequest.ShippingInfo.AddressFrom.Email = "sales@idrivelogistics.com";
rateRequest.ShippingInfo.AddressFrom.PhoneNumber = "(888) 797-0929";
rateRequest.ShippingInfo.AddressFrom.Address1 = "2600 Executive Pkwy #160";
rateRequest.ShippingInfo.AddressFrom.Address2 = "";
rateRequest.ShippingInfo.AddressFrom.City = "Lehi";
rateRequest.ShippingInfo.AddressFrom.StateOrProvince = "UT";
rateRequest.ShippingInfo.AddressFrom.PostalCode = "84043";
rateRequest.ShippingInfo.AddressFrom.CountryCode = "US";
rateRequest.ShippingInfo.AddressTo = new ShipToAddress();
rateRequest.ShippingInfo.AddressTo.AttentionOf = "Mr. Jones";
rateRequest.ShippingInfo.AddressTo.CompanyName = "iDrive Logistics";
rateRequest.ShippingInfo.AddressTo.Email = "";
rateRequest.ShippingInfo.AddressTo.PhoneNumber = "";
rateRequest.ShippingInfo.AddressTo.Address1 = "2605 Executive Pkwy #160";
rateRequest.ShippingInfo.AddressTo.Address2 = "";
rateRequest.ShippingInfo.AddressTo.IsResidential = false;
rateRequest.ShippingInfo.AddressTo.City = "Lehi";
rateRequest.ShippingInfo.AddressTo.StateOrProvince = "UT";
rateRequest.ShippingInfo.AddressTo.PostalCode = "84043";
rateRequest.ShippingInfo.AddressTo.CountryCode = "US";
rateRequest.ShippingInfo.Parcels = new List<ParcelInformation>();

var rateRequestShippingInfoParcels0 = new ParcelInformation();
rateRequestShippingInfoParcels0.PackagingId = "";
rateRequestShippingInfoParcels0.WeightInPounds = 0.4;
rateRequestShippingInfoParcels0.LengthInInches = 5;
rateRequestShippingInfoParcels0.WidthInInches = 4;
rateRequestShippingInfoParcels0.HeightInInches = 12;
rateRequestShippingInfoParcels0.Options = new ParcelOptions();
rateRequestShippingInfoParcels0.Options.Return = ReturnEnum.NOTAPPLICABLE;
rateRequestShippingInfoParcels0.Options.InsuranceAmount = 0;
rateRequestShippingInfoParcels0.Options.Signature = SignatureEnum.NOTAPPLICABLE;
rateRequestShippingInfoParcels0.Options.Cod = new CODOptions();
rateRequestShippingInfoParcels0.Options.Cod.CodType = CodTypeEnum.NOTAPPLICABLE;
rateRequestShippingInfoParcels0.Options.Cod.CodAmount = 0;
rateRequestShippingInfoParcels0.Options.Machinable = true;
rateRequestShippingInfoParcels0.Options.HoldForPickup = false;
rateRequest.ShippingInfo.Parcels.Add(rateRequestShippingInfoParcels0);


try
{
    RateResponse result = await ratesController.GetRatesAsync(rateRequest);
}
catch (ApiException e){};
```


# Get Rates by Carrier

Before creating a shipping label,
you can use this method to get a
break down of all shipping charges.
This allows you to determine
how much it would cost if you were to
actually send the parcels.

NOTE: HTTPS is Required to recieve a response.

```csharp
GetRatesByCarrierAsync(
    Models.RateRequest rateRequest = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `rateRequest` | [`Models.RateRequest`](/doc/models/rate-request.md) | Body, Optional | Shipping and parcel information<br>neccessary to calculate rates. |

## Response Type

[`Task<Models.RateResponse>`](/doc/models/rate-response.md)

## Example Usage

```csharp
var rateRequest = new RateRequest();
rateRequest.AccessToken = "YOUR ACCESS TOKEN";
rateRequest.ShippingInfo = new ShippingInformation();
rateRequest.ShippingInfo.CarrierClientContractId = 2526;
rateRequest.ShippingInfo.ServiceLevelId = 0;
rateRequest.ShippingInfo.DateShipped = DateTime.Parse("2020-12-23T23:54:10.2649036Z");
rateRequest.ShippingInfo.Options = new CustomsOptions();
rateRequest.ShippingInfo.Options.IsAPOFPODPOUSTerritory = false;
rateRequest.ShippingInfo.Options.IsInternationalShipment = false;
rateRequest.ShippingInfo.Options.ShipmentContentType = ShipmentContentTypeEnum.CONTENTTYPESAMPLE;
rateRequest.ShippingInfo.AddressFrom = new ShipFromAddress();
rateRequest.ShippingInfo.AddressFrom.CompanyName = "iDrive Logistics";
rateRequest.ShippingInfo.AddressFrom.Email = "sales@idrivelogistics.com";
rateRequest.ShippingInfo.AddressFrom.PhoneNumber = "(888) 797-0929";
rateRequest.ShippingInfo.AddressFrom.Address1 = "2600 Executive Pkwy #160";
rateRequest.ShippingInfo.AddressFrom.Address2 = "";
rateRequest.ShippingInfo.AddressFrom.City = "Lehi";
rateRequest.ShippingInfo.AddressFrom.StateOrProvince = "UT";
rateRequest.ShippingInfo.AddressFrom.PostalCode = "84043";
rateRequest.ShippingInfo.AddressFrom.CountryCode = "US";
rateRequest.ShippingInfo.AddressTo = new ShipToAddress();
rateRequest.ShippingInfo.AddressTo.AttentionOf = "Mr. Jones";
rateRequest.ShippingInfo.AddressTo.CompanyName = "iDrive Logistics";
rateRequest.ShippingInfo.AddressTo.Email = "";
rateRequest.ShippingInfo.AddressTo.PhoneNumber = "";
rateRequest.ShippingInfo.AddressTo.Address1 = "2605 Executive Pkwy #160";
rateRequest.ShippingInfo.AddressTo.Address2 = "";
rateRequest.ShippingInfo.AddressTo.IsResidential = false;
rateRequest.ShippingInfo.AddressTo.City = "Lehi";
rateRequest.ShippingInfo.AddressTo.StateOrProvince = "UT";
rateRequest.ShippingInfo.AddressTo.PostalCode = "84043";
rateRequest.ShippingInfo.AddressTo.CountryCode = "US";
rateRequest.ShippingInfo.Parcels = new List<ParcelInformation>();

var rateRequestShippingInfoParcels0 = new ParcelInformation();
rateRequestShippingInfoParcels0.PackagingId = "";
rateRequestShippingInfoParcels0.WeightInPounds = 0.4;
rateRequestShippingInfoParcels0.LengthInInches = 5;
rateRequestShippingInfoParcels0.WidthInInches = 4;
rateRequestShippingInfoParcels0.HeightInInches = 12;
rateRequestShippingInfoParcels0.Options = new ParcelOptions();
rateRequestShippingInfoParcels0.Options.Return = ReturnEnum.NOTAPPLICABLE;
rateRequestShippingInfoParcels0.Options.InsuranceAmount = 0;
rateRequestShippingInfoParcels0.Options.Signature = SignatureEnum.NOTAPPLICABLE;
rateRequestShippingInfoParcels0.Options.Cod = new CODOptions();
rateRequestShippingInfoParcels0.Options.Cod.CodType = CodTypeEnum.NOTAPPLICABLE;
rateRequestShippingInfoParcels0.Options.Cod.CodAmount = 0;
rateRequestShippingInfoParcels0.Options.Machinable = true;
rateRequestShippingInfoParcels0.Options.HoldForPickup = false;
rateRequest.ShippingInfo.Parcels.Add(rateRequestShippingInfoParcels0);


try
{
    RateResponse result = await ratesController.GetRatesByCarrierAsync(rateRequest);
}
catch (ApiException e){};
```


# Get Multiple Rates

Before creating a shipping label,
you can use this method to get multiple
break downs of all shipping charges.
This allows you to determine
how much it would cost if you were to
actually send the parcels.

NOTE: HTTPS is Required to recieve a response.

```csharp
GetMultipleRatesAsync(
    List<Models.RateRequest> rateRequest = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `rateRequest` | [`List<Models.RateRequest>`](/doc/models/rate-request.md) | Body, Optional | Shipping and parcel information<br>neccessary to calculate rates. |

## Response Type

[`Task<List<Models.RateResponse>>`](/doc/models/rate-response.md)

## Example Usage

```csharp
var rateRequest = new List<RateRequest>();

var rateRequest0 = new RateRequest();
rateRequest0.AccessToken = "YOUR ACCESS TOKEN";
rateRequest0.ShippingInfo = new ShippingInformation();
rateRequest0.ShippingInfo.CarrierClientContractId = 2526;
rateRequest0.ShippingInfo.ServiceLevelId = 0;
rateRequest0.ShippingInfo.DateShipped = DateTime.Parse("2020-12-23T23:54:10.2649036Z");
rateRequest0.ShippingInfo.Options = new CustomsOptions();
rateRequest0.ShippingInfo.Options.IsAPOFPODPOUSTerritory = false;
rateRequest0.ShippingInfo.Options.IsInternationalShipment = false;
rateRequest0.ShippingInfo.Options.ShipmentContentType = ShipmentContentTypeEnum.CONTENTTYPESAMPLE;
rateRequest0.ShippingInfo.AddressFrom = new ShipFromAddress();
rateRequest0.ShippingInfo.AddressFrom.CompanyName = "iDrive Logistics";
rateRequest0.ShippingInfo.AddressFrom.Email = "sales@idrivelogistics.com";
rateRequest0.ShippingInfo.AddressFrom.PhoneNumber = "(888) 797-0929";
rateRequest0.ShippingInfo.AddressFrom.Address1 = "2600 Executive Pkwy #160";
rateRequest0.ShippingInfo.AddressFrom.Address2 = "";
rateRequest0.ShippingInfo.AddressFrom.City = "Lehi";
rateRequest0.ShippingInfo.AddressFrom.StateOrProvince = "UT";
rateRequest0.ShippingInfo.AddressFrom.PostalCode = "84043";
rateRequest0.ShippingInfo.AddressFrom.CountryCode = "US";
rateRequest0.ShippingInfo.AddressTo = new ShipToAddress();
rateRequest0.ShippingInfo.AddressTo.AttentionOf = "Mr. Jones";
rateRequest0.ShippingInfo.AddressTo.CompanyName = "iDrive Logistics";
rateRequest0.ShippingInfo.AddressTo.Email = "";
rateRequest0.ShippingInfo.AddressTo.PhoneNumber = "";
rateRequest0.ShippingInfo.AddressTo.Address1 = "2605 Executive Pkwy #160";
rateRequest0.ShippingInfo.AddressTo.Address2 = "";
rateRequest0.ShippingInfo.AddressTo.IsResidential = false;
rateRequest0.ShippingInfo.AddressTo.City = "Lehi";
rateRequest0.ShippingInfo.AddressTo.StateOrProvince = "UT";
rateRequest0.ShippingInfo.AddressTo.PostalCode = "84043";
rateRequest0.ShippingInfo.AddressTo.CountryCode = "US";
rateRequest0.ShippingInfo.Parcels = new List<ParcelInformation>();

var rateRequest0ShippingInfoParcels0 = new ParcelInformation();
rateRequest0ShippingInfoParcels0.PackagingId = "";
rateRequest0ShippingInfoParcels0.WeightInPounds = 0.4;
rateRequest0ShippingInfoParcels0.LengthInInches = 5;
rateRequest0ShippingInfoParcels0.WidthInInches = 4;
rateRequest0ShippingInfoParcels0.HeightInInches = 12;
rateRequest0ShippingInfoParcels0.Options = new ParcelOptions();
rateRequest0ShippingInfoParcels0.Options.Return = ReturnEnum.NOTAPPLICABLE;
rateRequest0ShippingInfoParcels0.Options.InsuranceAmount = 0;
rateRequest0ShippingInfoParcels0.Options.Signature = SignatureEnum.NOTAPPLICABLE;
rateRequest0ShippingInfoParcels0.Options.Cod = new CODOptions();
rateRequest0ShippingInfoParcels0.Options.Cod.CodType = CodTypeEnum.NOTAPPLICABLE;
rateRequest0ShippingInfoParcels0.Options.Cod.CodAmount = 0;
rateRequest0ShippingInfoParcels0.Options.Machinable = true;
rateRequest0ShippingInfoParcels0.Options.HoldForPickup = false;
rateRequest0.ShippingInfo.Parcels.Add(rateRequest0ShippingInfoParcels0);

rateRequest.Add(rateRequest0);

var rateRequest1 = new RateRequest();
rateRequest1.AccessToken = "YOUR ACCESS TOKEN";
rateRequest1.ShippingInfo = new ShippingInformation();
rateRequest1.ShippingInfo.CarrierClientContractId = 2526;
rateRequest1.ShippingInfo.ServiceLevelId = 0;
rateRequest1.ShippingInfo.DateShipped = DateTime.Parse("2020-12-23T23:54:10.2649036Z");
rateRequest1.ShippingInfo.Options = new CustomsOptions();
rateRequest1.ShippingInfo.Options.IsAPOFPODPOUSTerritory = false;
rateRequest1.ShippingInfo.Options.IsInternationalShipment = false;
rateRequest1.ShippingInfo.Options.ShipmentContentType = ShipmentContentTypeEnum.CONTENTTYPESAMPLE;
rateRequest1.ShippingInfo.AddressFrom = new ShipFromAddress();
rateRequest1.ShippingInfo.AddressFrom.CompanyName = "iDrive Logistics";
rateRequest1.ShippingInfo.AddressFrom.Email = "sales@idrivelogistics.com";
rateRequest1.ShippingInfo.AddressFrom.PhoneNumber = "(888) 797-0929";
rateRequest1.ShippingInfo.AddressFrom.Address1 = "2600 Executive Pkwy #160";
rateRequest1.ShippingInfo.AddressFrom.Address2 = "";
rateRequest1.ShippingInfo.AddressFrom.City = "Lehi";
rateRequest1.ShippingInfo.AddressFrom.StateOrProvince = "UT";
rateRequest1.ShippingInfo.AddressFrom.PostalCode = "84043";
rateRequest1.ShippingInfo.AddressFrom.CountryCode = "US";
rateRequest1.ShippingInfo.AddressTo = new ShipToAddress();
rateRequest1.ShippingInfo.AddressTo.AttentionOf = "Mr. Jones";
rateRequest1.ShippingInfo.AddressTo.CompanyName = "iDrive Logistics";
rateRequest1.ShippingInfo.AddressTo.Email = "";
rateRequest1.ShippingInfo.AddressTo.PhoneNumber = "";
rateRequest1.ShippingInfo.AddressTo.Address1 = "2605 Executive Pkwy #160";
rateRequest1.ShippingInfo.AddressTo.Address2 = "";
rateRequest1.ShippingInfo.AddressTo.IsResidential = false;
rateRequest1.ShippingInfo.AddressTo.City = "Lehi";
rateRequest1.ShippingInfo.AddressTo.StateOrProvince = "UT";
rateRequest1.ShippingInfo.AddressTo.PostalCode = "84043";
rateRequest1.ShippingInfo.AddressTo.CountryCode = "US";
rateRequest1.ShippingInfo.Parcels = new List<ParcelInformation>();

var rateRequest1ShippingInfoParcels0 = new ParcelInformation();
rateRequest1ShippingInfoParcels0.PackagingId = "";
rateRequest1ShippingInfoParcels0.WeightInPounds = 0.4;
rateRequest1ShippingInfoParcels0.LengthInInches = 5;
rateRequest1ShippingInfoParcels0.WidthInInches = 4;
rateRequest1ShippingInfoParcels0.HeightInInches = 12;
rateRequest1ShippingInfoParcels0.Options = new ParcelOptions();
rateRequest1ShippingInfoParcels0.Options.Return = ReturnEnum.NOTAPPLICABLE;
rateRequest1ShippingInfoParcels0.Options.InsuranceAmount = 0;
rateRequest1ShippingInfoParcels0.Options.Signature = SignatureEnum.NOTAPPLICABLE;
rateRequest1ShippingInfoParcels0.Options.Cod = new CODOptions();
rateRequest1ShippingInfoParcels0.Options.Cod.CodType = CodTypeEnum.NOTAPPLICABLE;
rateRequest1ShippingInfoParcels0.Options.Cod.CodAmount = 0;
rateRequest1ShippingInfoParcels0.Options.Machinable = true;
rateRequest1ShippingInfoParcels0.Options.HoldForPickup = false;
rateRequest1.ShippingInfo.Parcels.Add(rateRequest1ShippingInfoParcels0);

rateRequest.Add(rateRequest1);

var rateRequest2 = new RateRequest();
rateRequest2.AccessToken = "YOUR ACCESS TOKEN";
rateRequest2.ShippingInfo = new ShippingInformation();
rateRequest2.ShippingInfo.CarrierClientContractId = 2526;
rateRequest2.ShippingInfo.ServiceLevelId = 0;
rateRequest2.ShippingInfo.DateShipped = DateTime.Parse("2020-12-23T23:54:10.2649036Z");
rateRequest2.ShippingInfo.Options = new CustomsOptions();
rateRequest2.ShippingInfo.Options.IsAPOFPODPOUSTerritory = false;
rateRequest2.ShippingInfo.Options.IsInternationalShipment = false;
rateRequest2.ShippingInfo.Options.ShipmentContentType = ShipmentContentTypeEnum.CONTENTTYPESAMPLE;
rateRequest2.ShippingInfo.AddressFrom = new ShipFromAddress();
rateRequest2.ShippingInfo.AddressFrom.CompanyName = "iDrive Logistics";
rateRequest2.ShippingInfo.AddressFrom.Email = "sales@idrivelogistics.com";
rateRequest2.ShippingInfo.AddressFrom.PhoneNumber = "(888) 797-0929";
rateRequest2.ShippingInfo.AddressFrom.Address1 = "2600 Executive Pkwy #160";
rateRequest2.ShippingInfo.AddressFrom.Address2 = "";
rateRequest2.ShippingInfo.AddressFrom.City = "Lehi";
rateRequest2.ShippingInfo.AddressFrom.StateOrProvince = "UT";
rateRequest2.ShippingInfo.AddressFrom.PostalCode = "84043";
rateRequest2.ShippingInfo.AddressFrom.CountryCode = "US";
rateRequest2.ShippingInfo.AddressTo = new ShipToAddress();
rateRequest2.ShippingInfo.AddressTo.AttentionOf = "Mr. Jones";
rateRequest2.ShippingInfo.AddressTo.CompanyName = "iDrive Logistics";
rateRequest2.ShippingInfo.AddressTo.Email = "";
rateRequest2.ShippingInfo.AddressTo.PhoneNumber = "";
rateRequest2.ShippingInfo.AddressTo.Address1 = "2605 Executive Pkwy #160";
rateRequest2.ShippingInfo.AddressTo.Address2 = "";
rateRequest2.ShippingInfo.AddressTo.IsResidential = false;
rateRequest2.ShippingInfo.AddressTo.City = "Lehi";
rateRequest2.ShippingInfo.AddressTo.StateOrProvince = "UT";
rateRequest2.ShippingInfo.AddressTo.PostalCode = "84043";
rateRequest2.ShippingInfo.AddressTo.CountryCode = "US";
rateRequest2.ShippingInfo.Parcels = new List<ParcelInformation>();

var rateRequest2ShippingInfoParcels0 = new ParcelInformation();
rateRequest2ShippingInfoParcels0.PackagingId = "";
rateRequest2ShippingInfoParcels0.WeightInPounds = 0.4;
rateRequest2ShippingInfoParcels0.LengthInInches = 5;
rateRequest2ShippingInfoParcels0.WidthInInches = 4;
rateRequest2ShippingInfoParcels0.HeightInInches = 12;
rateRequest2ShippingInfoParcels0.Options = new ParcelOptions();
rateRequest2ShippingInfoParcels0.Options.Return = ReturnEnum.NOTAPPLICABLE;
rateRequest2ShippingInfoParcels0.Options.InsuranceAmount = 0;
rateRequest2ShippingInfoParcels0.Options.Signature = SignatureEnum.NOTAPPLICABLE;
rateRequest2ShippingInfoParcels0.Options.Cod = new CODOptions();
rateRequest2ShippingInfoParcels0.Options.Cod.CodType = CodTypeEnum.NOTAPPLICABLE;
rateRequest2ShippingInfoParcels0.Options.Cod.CodAmount = 0;
rateRequest2ShippingInfoParcels0.Options.Machinable = true;
rateRequest2ShippingInfoParcels0.Options.HoldForPickup = false;
rateRequest2.ShippingInfo.Parcels.Add(rateRequest2ShippingInfoParcels0);

rateRequest.Add(rateRequest2);


try
{
    List<RateResponse> result = await ratesController.GetMultipleRatesAsync(rateRequest);
}
catch (ApiException e){};
```

