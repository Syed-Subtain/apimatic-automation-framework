# Labels

```csharp
LabelsController labelsController = client.LabelsController;
```

## Class Name

`LabelsController`

## Methods

* [Get Labels by Shipping ID With Cost](/doc/controllers/labels.md#get-labels-by-shipping-id-with-cost)
* [Void Label](/doc/controllers/labels.md#void-label)
* [Get Shipping Labels by Shipping ID](/doc/controllers/labels.md#get-shipping-labels-by-shipping-id)
* [Get Shipping Labels](/doc/controllers/labels.md#get-shipping-labels)
* [Get Label With Cost](/doc/controllers/labels.md#get-label-with-cost)


# Get Labels by Shipping ID With Cost

The labels are represented by a base 64 string.

```csharp
GetLabelsByShippingIDWithCostAsync(
    Models.GetShippingLabelsByShippingIDRequestv21 input = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `input` | [`Models.GetShippingLabelsByShippingIDRequestv21`](/doc/models/get-shipping-labels-by-shipping-id-requestv-21.md) | Body, Optional | - |

## Response Type

[`Task<Models.LabelInformationWithCost>`](/doc/models/label-information-with-cost.md)

## Example Usage

```csharp
var input = new GetShippingLabelsByShippingIDRequestv21();
input.AccessToken = "<YOUR ACCESS TOKEN>";
input.ShipmentID = 19;
input.PrintFormat = PrintFormatEnum.PNG4x6;
input.AsClientId = 12;
input.CertifyTestOverride = CertifyTestOverrideEnum.Contract;

try
{
    LabelInformationWithCost result = await labelsController.GetLabelsByShippingIDWithCostAsync(input);
}
catch (ApiException e){};
```


# Void Label

In some conditions - such as already shipped parcels - the labels will not be voided.

```csharp
VoidLabelAsync(
    Models.VoidLabelRequestv21 input = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `input` | [`Models.VoidLabelRequestv21`](/doc/models/void-label-requestv-21.md) | Body, Optional | - |

## Response Type

[`Task<Models.VoidLabelResponsev21>`](/doc/models/void-label-responsev-21.md)

## Example Usage

```csharp
var input = new VoidLabelRequestv21();
input.AccessToken = "<YOUR ACCESS TOKEN>";
input.LabelKey = "329058_340709_shp_dfc02221ff5e4b78a45558ef474b6713";
input.AsClientId = 12;

try
{
    VoidLabelResponsev21 result = await labelsController.VoidLabelAsync(input);
}
catch (ApiException e){};
```

## Example Response *(as JSON)*

```json
{
  "trackingNumber": "9405536895239111999004",
  "error": {
    "details": [],
    "hasError": false
  }
}
```


# Get Shipping Labels by Shipping ID

The labels are represented by a base 64 string.

```csharp
GetShippingLabelsByShippingIDAsync(
    Models.GetShippingLabelsByShippingIDRequestv21 input = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `input` | [`Models.GetShippingLabelsByShippingIDRequestv21`](/doc/models/get-shipping-labels-by-shipping-id-requestv-21.md) | Body, Optional | - |

## Response Type

[`Task<Models.LabelInformation>`](/doc/models/label-information.md)

## Example Usage

```csharp
var input = new GetShippingLabelsByShippingIDRequestv21();
input.AccessToken = "<YOUR ACCESS TOKEN>";
input.ShipmentID = 19;
input.PrintFormat = PrintFormatEnum.PNG4x6;
input.AsClientId = 12;
input.CertifyTestOverride = CertifyTestOverrideEnum.Contract;

try
{
    LabelInformation result = await labelsController.GetShippingLabelsByShippingIDAsync(input);
}
catch (ApiException e){};
```


# Get Shipping Labels

The labels are represented by a base 64 string.

```csharp
GetShippingLabelsAsync(
    Models.GetShippingLabelsRequestv21 input = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `input` | [`Models.GetShippingLabelsRequestv21`](/doc/models/get-shipping-labels-requestv-21.md) | Body, Optional | - |

## Response Type

[`Task<Models.LabelInformation>`](/doc/models/label-information.md)

## Example Usage

```csharp
var input = new GetShippingLabelsRequestv21();
input.AccessToken = "<YOUR ACCESS TOKEN>";
input.PrintFormat = PrintFormatEnum.PNG4x6;
input.AsClientId = 12;
input.Shipment = new ShipmentInformation();
input.Shipment.DateShipped = DateTime.Parse("2020-12-23T23:54:10.3117094Z");
input.Shipment.CarrierClientContractId = 2404;
input.Shipment.CarrierServiceLevelId = 1115;
input.Shipment.AddressFrom = new ShipFromAddress();
input.Shipment.AddressFrom.CompanyName = "iDrive Logistics";
input.Shipment.AddressFrom.Email = "sales@idrivelogistics.com";
input.Shipment.AddressFrom.PhoneNumber = "(888) 797-0929";
input.Shipment.AddressFrom.Address1 = "2600 Executive Pkwy #160";
input.Shipment.AddressFrom.Address2 = "";
input.Shipment.AddressFrom.City = "Lehi";
input.Shipment.AddressFrom.StateOrProvince = "UT";
input.Shipment.AddressFrom.PostalCode = "84043";
input.Shipment.AddressFrom.CountryCode = "US";
input.Shipment.AddressTo = new ShipToAddress();
input.Shipment.AddressTo.AttentionOf = "Mr. Jones";
input.Shipment.AddressTo.CompanyName = "iDrive Logistics";
input.Shipment.AddressTo.Email = "sales@idrivelogistics.com";
input.Shipment.AddressTo.PhoneNumber = "(888) 797-0929";
input.Shipment.AddressTo.Address1 = "2605 Executive Pkwy #160";
input.Shipment.AddressTo.Address2 = "";
input.Shipment.AddressTo.IsResidential = false;
input.Shipment.AddressTo.City = "Lehi";
input.Shipment.AddressTo.StateOrProvince = "UT";
input.Shipment.AddressTo.PostalCode = "84043";
input.Shipment.AddressTo.CountryCode = "US";
input.Shipment.Parcels = new List<ParcelDetail>();

var inputShipmentParcels0 = new ParcelDetail();
inputShipmentParcels0.WeightInPounds = 0.4;
inputShipmentParcels0.LengthInInches = 5;
inputShipmentParcels0.WidthInInches = 4;
inputShipmentParcels0.HeightInInches = 12;
inputShipmentParcels0.Options = new ParcelOptions();
inputShipmentParcels0.Options.Return = ReturnEnum.NOTAPPLICABLE;
inputShipmentParcels0.Options.InsuranceAmount = 0;
inputShipmentParcels0.Options.Signature = SignatureEnum.NOTAPPLICABLE;
inputShipmentParcels0.Options.Cod = new CODOptions();
inputShipmentParcels0.Options.Cod.CodType = CodTypeEnum.NOTAPPLICABLE;
inputShipmentParcels0.Options.Cod.CodAmount = 0;
inputShipmentParcels0.ReferenceField1 = "1";
inputShipmentParcels0.ReferenceField2 = "";
inputShipmentParcels0.ReferenceField3 = "";
inputShipmentParcels0.ParcelID = "1";
inputShipmentParcels0.PackagingId = "";
inputShipmentParcels0.ParcelItems = new List<ParcelContent>();

var inputShipmentParcels0ParcelItems0 = new ParcelContent();
inputShipmentParcels0ParcelItems0.Name = "chocolate";
inputShipmentParcels0ParcelItems0.Quantity = 7;
inputShipmentParcels0ParcelItems0.Price = 1.03;
inputShipmentParcels0ParcelItems0.WeightInPounds = 0.5;
inputShipmentParcels0ParcelItems0.OriginCountry = "US";
inputShipmentParcels0ParcelItems0.Sku = "none";
inputShipmentParcels0ParcelItems0.Description = "candy";
inputShipmentParcels0ParcelItems0.HarmonizeCode = "";
inputShipmentParcels0.ParcelItems.Add(inputShipmentParcels0ParcelItems0);

input.Shipment.Parcels.Add(inputShipmentParcels0);

input.Shipment.OrderReferenceNumber = "test order";
input.Shipment.Options = new ShippingOptions();
input.Shipment.Options.IsAPOFPODPOUSTerritory = false;
input.Shipment.Options.IsInternationalShipment = false;
input.Shipment.Options.Billing = new BillingOptions();
input.Shipment.Options.Billing.ShippingPaidBy = ShippingPaidByEnum.NOTAPPLICABLE;
input.Shipment.Options.Billing.DutiesPaidBy = DutiesPaidByEnum.NOTAPPLICABLE;
input.Shipment.Options.Billing.AccountNumber = "";
input.Shipment.Options.Billing.PostalCode = "";
input.Shipment.Options.Billing.CountryAlpha2Code = "";
input.Shipment.Options.ShipmentContentType = ShipmentContentTypeEnum.CONTENTTYPESAMPLE;
input.CertifyTestOverride = CertifyTestOverrideEnum.Contract;
input.ImageRotation = ImageRotationEnum.RotateNoneFlipNone;

try
{
    LabelInformation result = await labelsController.GetShippingLabelsAsync(input);
}
catch (ApiException e){};
```


# Get Label With Cost

The labels are represented by a base 64 string.

```csharp
GetLabelWithCostAsync(
    Models.GetShippingLabelsRequestv21 input = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `input` | [`Models.GetShippingLabelsRequestv21`](/doc/models/get-shipping-labels-requestv-21.md) | Body, Optional | - |

## Response Type

[`Task<Models.LabelInformationWithCost>`](/doc/models/label-information-with-cost.md)

## Example Usage

```csharp
var input = new GetShippingLabelsRequestv21();
input.AccessToken = "<YOUR ACCESS TOKEN>";
input.PrintFormat = PrintFormatEnum.PNG4x6;
input.AsClientId = 12;
input.Shipment = new ShipmentInformation();
input.Shipment.DateShipped = DateTime.Parse("2020-12-23T23:54:10.3117094Z");
input.Shipment.CarrierClientContractId = 2404;
input.Shipment.CarrierServiceLevelId = 1115;
input.Shipment.AddressFrom = new ShipFromAddress();
input.Shipment.AddressFrom.CompanyName = "iDrive Logistics";
input.Shipment.AddressFrom.Email = "sales@idrivelogistics.com";
input.Shipment.AddressFrom.PhoneNumber = "(888) 797-0929";
input.Shipment.AddressFrom.Address1 = "2600 Executive Pkwy #160";
input.Shipment.AddressFrom.Address2 = "";
input.Shipment.AddressFrom.City = "Lehi";
input.Shipment.AddressFrom.StateOrProvince = "UT";
input.Shipment.AddressFrom.PostalCode = "84043";
input.Shipment.AddressFrom.CountryCode = "US";
input.Shipment.AddressTo = new ShipToAddress();
input.Shipment.AddressTo.AttentionOf = "Mr. Jones";
input.Shipment.AddressTo.CompanyName = "iDrive Logistics";
input.Shipment.AddressTo.Email = "sales@idrivelogistics.com";
input.Shipment.AddressTo.PhoneNumber = "(888) 797-0929";
input.Shipment.AddressTo.Address1 = "2605 Executive Pkwy #160";
input.Shipment.AddressTo.Address2 = "";
input.Shipment.AddressTo.IsResidential = false;
input.Shipment.AddressTo.City = "Lehi";
input.Shipment.AddressTo.StateOrProvince = "UT";
input.Shipment.AddressTo.PostalCode = "84043";
input.Shipment.AddressTo.CountryCode = "US";
input.Shipment.Parcels = new List<ParcelDetail>();

var inputShipmentParcels0 = new ParcelDetail();
inputShipmentParcels0.WeightInPounds = 0.4;
inputShipmentParcels0.LengthInInches = 5;
inputShipmentParcels0.WidthInInches = 4;
inputShipmentParcels0.HeightInInches = 12;
inputShipmentParcels0.Options = new ParcelOptions();
inputShipmentParcels0.Options.Return = ReturnEnum.NOTAPPLICABLE;
inputShipmentParcels0.Options.InsuranceAmount = 0;
inputShipmentParcels0.Options.Signature = SignatureEnum.NOTAPPLICABLE;
inputShipmentParcels0.Options.Cod = new CODOptions();
inputShipmentParcels0.Options.Cod.CodType = CodTypeEnum.NOTAPPLICABLE;
inputShipmentParcels0.Options.Cod.CodAmount = 0;
inputShipmentParcels0.ReferenceField1 = "1";
inputShipmentParcels0.ReferenceField2 = "";
inputShipmentParcels0.ReferenceField3 = "";
inputShipmentParcels0.ParcelID = "1";
inputShipmentParcels0.PackagingId = "";
inputShipmentParcels0.ParcelItems = new List<ParcelContent>();

var inputShipmentParcels0ParcelItems0 = new ParcelContent();
inputShipmentParcels0ParcelItems0.Name = "chocolate";
inputShipmentParcels0ParcelItems0.Quantity = 7;
inputShipmentParcels0ParcelItems0.Price = 1.03;
inputShipmentParcels0ParcelItems0.WeightInPounds = 0.5;
inputShipmentParcels0ParcelItems0.OriginCountry = "US";
inputShipmentParcels0ParcelItems0.Sku = "none";
inputShipmentParcels0ParcelItems0.Description = "candy";
inputShipmentParcels0ParcelItems0.HarmonizeCode = "";
inputShipmentParcels0.ParcelItems.Add(inputShipmentParcels0ParcelItems0);

input.Shipment.Parcels.Add(inputShipmentParcels0);

input.Shipment.OrderReferenceNumber = "test order";
input.Shipment.Options = new ShippingOptions();
input.Shipment.Options.IsAPOFPODPOUSTerritory = false;
input.Shipment.Options.IsInternationalShipment = false;
input.Shipment.Options.Billing = new BillingOptions();
input.Shipment.Options.Billing.ShippingPaidBy = ShippingPaidByEnum.NOTAPPLICABLE;
input.Shipment.Options.Billing.DutiesPaidBy = DutiesPaidByEnum.NOTAPPLICABLE;
input.Shipment.Options.Billing.AccountNumber = "";
input.Shipment.Options.Billing.PostalCode = "";
input.Shipment.Options.Billing.CountryAlpha2Code = "";
input.Shipment.Options.ShipmentContentType = ShipmentContentTypeEnum.CONTENTTYPESAMPLE;
input.CertifyTestOverride = CertifyTestOverrideEnum.Contract;
input.ImageRotation = ImageRotationEnum.RotateNoneFlipNone;

try
{
    LabelInformationWithCost result = await labelsController.GetLabelWithCostAsync(input);
}
catch (ApiException e){};
```

