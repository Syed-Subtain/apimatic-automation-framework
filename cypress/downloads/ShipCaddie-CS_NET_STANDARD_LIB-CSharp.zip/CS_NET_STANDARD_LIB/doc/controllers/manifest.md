# Manifest

```csharp
ManifestController manifestController = client.ManifestController;
```

## Class Name

`ManifestController`

## Methods

* [Manifest](/doc/controllers/manifest.md#manifest)
* [Generate](/doc/controllers/manifest.md#generate)
* [Regenerate](/doc/controllers/manifest.md#regenerate)
* [Scan Form History](/doc/controllers/manifest.md#scan-form-history)
* [Available Shipments](/doc/controllers/manifest.md#available-shipments)
* [Scan Form Generate](/doc/controllers/manifest.md#scan-form-generate)


# Manifest

Manifest:    Create end-of-day Manifest / Scan Form (USPS).

```csharp
ManifestAsync(
    Models.ScanFormHistoryByIDRequestv21 input = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `input` | [`Models.ScanFormHistoryByIDRequestv21`](/doc/models/scan-form-history-by-id-requestv-21.md) | Body, Optional | - |

## Response Type

[`Task<Models.ScanFormHistoryByIDResponsev21>`](/doc/models/scan-form-history-by-id-responsev-21.md)

## Example Usage

```csharp
var input = new ScanFormHistoryByIDRequestv21();
input.AccessToken = "<YOUR ACCESS TOKEN>";
input.ScanFormId = 23;

try
{
    ScanFormHistoryByIDResponsev21 result = await manifestController.ManifestAsync(input);
}
catch (ApiException e){};
```

## Example Response *(as JSON)*

```json
{
  "error": {
    "details": [],
    "hasError": false
  },
  "scanFormInformation": {
    "id": 12,
    "scanFormId": "ScanFormID",
    "batchId": "BatchID",
    "clientId": 12,
    "shipmentClientAddressId": 747,
    "shipDate": "2020-12-23T23:54:10.3273331+00:00",
    "scanFormDataType": "imagePng",
    "carrierClientContractId": 2526,
    "carrierClientContractName": "Test",
    "shipmentClientAddressLine1": "",
    "shipmentClientAddressLine2": "",
    "shipmentClientAddressProvince": "",
    "shipmentClientAddressCity": "",
    "shipmentClientAddressPostalCode": "",
    "shippingSiteName": "",
    "dateCreated": "2020-12-23T23:54:10.3273331+00:00",
    "printJobs": [
      {
        "printTemplateType": "Template Type",
        "dataBlocks": []
      }
    ],
    "excludedItems": {}
  }
}
```


# Generate

Generate:    Obtain a ScanForm

```csharp
GenerateAsync(
    Models.GenerateRequestv21 input = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `input` | [`Models.GenerateRequestv21`](/doc/models/generate-requestv-21.md) | Body, Optional | - |

## Response Type

[`Task<Models.GenerateResponsev21>`](/doc/models/generate-responsev-21.md)

## Example Usage

```csharp
var input = new GenerateRequestv21();
input.AccessToken = "<YOUR ACCESS TOKEN>";
input.ScanFormRequest = new ScanFormModelRequest();
input.ScanFormRequest.CarrierClientContractId = 2526;
input.ScanFormRequest.ShipmentClientAddressId = 747;
input.ScanFormRequest.ShipDate = DateTime.Parse("2017-11-29T00:00:00");
input.ScanFormRequest.KeyList = new List<KeyValues>();

var inputScanFormRequestKeyList0 = new KeyValues();
inputScanFormRequestKeyList0.LabelKey = "shp_810c212e2dcf4863a1bd8495f9a54d81";
inputScanFormRequestKeyList0.TrackingNumber = "9400136895239112753275";
inputScanFormRequestKeyList0.PackageId = 366974;
input.ScanFormRequest.KeyList.Add(inputScanFormRequestKeyList0);

input.ScanFormRequest.RecentScanFormId = 0;

try
{
    GenerateResponsev21 result = await manifestController.GenerateAsync(input);
}
catch (ApiException e){};
```

## Example Response *(as JSON)*

```json
{
  "error": {
    "details": [],
    "hasError": false
  },
  "scanFormInformation": {
    "id": 12,
    "scanFormId": "ScanFormID",
    "batchId": "BatchID",
    "clientId": 12,
    "shipmentClientAddressId": 747,
    "shipDate": "2020-12-23T23:54:10.1867682+00:00",
    "scanFormDataType": "imagePng",
    "carrierClientContractId": 2526,
    "carrierClientContractName": "Test",
    "shipmentClientAddressLine1": "",
    "shipmentClientAddressLine2": "",
    "shipmentClientAddressProvince": "",
    "shipmentClientAddressCity": "",
    "shipmentClientAddressPostalCode": "",
    "shippingSiteName": "",
    "dateCreated": "2020-12-23T23:54:10.1867682+00:00",
    "printJobs": [
      {
        "printTemplateType": "Template Type",
        "dataBlocks": []
      }
    ],
    "excludedItems": {}
  }
}
```


# Regenerate

Regenerate:    Obtain a ScanForm

```csharp
RegenerateAsync(
    Models.RegenerateRequestv21 input = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `input` | [`Models.RegenerateRequestv21`](/doc/models/regenerate-requestv-21.md) | Body, Optional | - |

## Response Type

[`Task<Models.RegenerateResponsev21>`](/doc/models/regenerate-responsev-21.md)

## Example Usage

```csharp
var input = new RegenerateRequestv21();
input.AccessToken = "<YOUR ACCESS TOKEN>";
input.IsRegenerate = false;
input.ScanFormRequest = new ScanFormModelRequest();
input.ScanFormRequest.CarrierClientContractId = 2526;
input.ScanFormRequest.ShipmentClientAddressId = 747;
input.ScanFormRequest.ShipDate = DateTime.Parse("2017-11-29T00:00:00");
input.ScanFormRequest.KeyList = new List<KeyValues>();

var inputScanFormRequestKeyList0 = new KeyValues();
inputScanFormRequestKeyList0.LabelKey = "shp_810c212e2dcf4863a1bd8495f9a54d81";
inputScanFormRequestKeyList0.TrackingNumber = "9400136895239112753275";
inputScanFormRequestKeyList0.PackageId = 366974;
input.ScanFormRequest.KeyList.Add(inputScanFormRequestKeyList0);

input.ScanFormRequest.RecentScanFormId = 0;

try
{
    RegenerateResponsev21 result = await manifestController.RegenerateAsync(input);
}
catch (ApiException e){};
```

## Example Response *(as JSON)*

```json
{
  "error": {
    "details": [],
    "hasError": false
  },
  "scanFormInformation": {
    "id": 12,
    "scanFormId": "ScanFormID",
    "batchId": "BatchID",
    "clientId": 12,
    "shipmentClientAddressId": 747,
    "shipDate": "2020-12-23T23:54:10.3273331+00:00",
    "scanFormDataType": "imagePng",
    "carrierClientContractId": 2526,
    "carrierClientContractName": "Test",
    "shipmentClientAddressLine1": "",
    "shipmentClientAddressLine2": "",
    "shipmentClientAddressProvince": "",
    "shipmentClientAddressCity": "",
    "shipmentClientAddressPostalCode": "",
    "shippingSiteName": "",
    "dateCreated": "2020-12-23T23:54:10.3273331+00:00",
    "printJobs": [
      {
        "printTemplateType": "Template Type",
        "dataBlocks": []
      }
    ],
    "excludedItems": {}
  }
}
```


# Scan Form History

ScanForm_History:         Get the end-of-day Manifests / Scan Forms (USPS)

```csharp
ScanFormHistoryAsync(
    Models.ScanFormHistoryRequestv21 input = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `input` | [`Models.ScanFormHistoryRequestv21`](/doc/models/scan-form-history-requestv-21.md) | Body, Optional | - |

## Response Type

[`Task<Models.ScanFormHistoryResponsev21>`](/doc/models/scan-form-history-responsev-21.md)

## Example Usage

```csharp
var input = new ScanFormHistoryRequestv21();
input.AccessToken = "<YOUR ACCESS TOKEN>";

try
{
    ScanFormHistoryResponsev21 result = await manifestController.ScanFormHistoryAsync(input);
}
catch (ApiException e){};
```

## Example Response *(as JSON)*

```json
{
  "error": {
    "details": [],
    "hasError": false
  },
  "scanFormList": [
    {
      "id": 12,
      "scanFormId": "ScanFormID",
      "batchId": "BatchID",
      "clientId": 12,
      "shipmentClientAddressId": 747,
      "shipDate": "2020-12-23T23:54:10.3585858+00:00",
      "scanFormDataType": "imagePng",
      "carrierClientContractId": 2526,
      "carrierClientContractName": "Test",
      "shipmentClientAddressLine1": "",
      "shipmentClientAddressLine2": "",
      "shipmentClientAddressProvince": "",
      "shipmentClientAddressCity": "",
      "shipmentClientAddressPostalCode": "",
      "shippingSiteName": "",
      "dateCreated": "2020-12-23T23:54:10.3585858+00:00",
      "printJobs": [
        {
          "printTemplateType": "Template Type",
          "dataBlocks": []
        }
      ],
      "excludedItems": {}
    }
  ]
}
```


# Available Shipments

AvailableShipments:    Gets Available Shipments

```csharp
AvailableShipmentsAsync(
    Models.AvailableShipmentsRequestv21 input = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `input` | [`Models.AvailableShipmentsRequestv21`](/doc/models/available-shipments-requestv-21.md) | Body, Optional | - |

## Response Type

[`Task<Models.AvailableShipmentsResponsev21>`](/doc/models/available-shipments-responsev-21.md)

## Example Usage

```csharp
var input = new AvailableShipmentsRequestv21();
input.AccessToken = "<YOUR ACCESS TOKEN>";
input.AsClientId = 12;
input.CarrierClientContractId = 34;
input.AddressId = 23;
input.ShipDate = DateTime.Parse("2020-12-23T23:54:10.1554517+00:00");

try
{
    AvailableShipmentsResponsev21 result = await manifestController.AvailableShipmentsAsync(input);
}
catch (ApiException e){};
```

## Example Response *(as JSON)*

```json
{
  "error": {
    "details": [],
    "hasError": false
  },
  "availableShipments": [
    {
      "carrierClientContractId": 14,
      "shipmentId": 23,
      "packageId": 45,
      "shipmentClientAddressId": 52,
      "dateShipped": "2020-12-23T23:54:10.1554517+00:00",
      "fromShippingSiteName": "Shipping Site Name",
      "toAddressLine1": "564 Drury Lane",
      "toAddressLine2": "",
      "toPostalCode": "95654",
      "toProvince": "CA",
      "toCity": "LA",
      "accountAlias": "",
      "labelKey": "fds32y4rddaf",
      "trackingNumber": "565489079094"
    }
  ]
}
```


# Scan Form Generate

ScanForm_Generate:         Get Manifests / Scan Forms (USPS)

```csharp
ScanFormGenerateAsync(
    Models.ScanFormGenerateRequestv21 input = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `input` | [`Models.ScanFormGenerateRequestv21`](/doc/models/scan-form-generate-requestv-21.md) | Body, Optional | - |

## Response Type

[`Task<Models.ScanFormGenerateResponsev21>`](/doc/models/scan-form-generate-responsev-21.md)

## Example Usage

```csharp
var input = new ScanFormGenerateRequestv21();
input.AccessToken = "<YOUR ACCESS TOKEN>";
input.ScanFormRequest = new ScanFormModelRequest();
input.ScanFormRequest.CarrierClientContractId = 2526;
input.ScanFormRequest.ShipmentClientAddressId = 747;
input.ScanFormRequest.ShipDate = DateTime.Parse("2017-11-29T00:00:00");
input.ScanFormRequest.KeyList = new List<KeyValues>();

var inputScanFormRequestKeyList0 = new KeyValues();
inputScanFormRequestKeyList0.LabelKey = "shp_810c212e2dcf4863a1bd8495f9a54d81";
inputScanFormRequestKeyList0.TrackingNumber = "9400136895239112753275";
inputScanFormRequestKeyList0.PackageId = 366974;
input.ScanFormRequest.KeyList.Add(inputScanFormRequestKeyList0);

input.ScanFormRequest.RecentScanFormId = 0;

try
{
    ScanFormGenerateResponsev21 result = await manifestController.ScanFormGenerateAsync(input);
}
catch (ApiException e){};
```

## Example Response *(as JSON)*

```json
{
  "error": {
    "details": [],
    "hasError": false
  },
  "scanFormInformation": {
    "id": 12,
    "scanFormId": "ScanFormID",
    "batchId": "BatchID",
    "clientId": 12,
    "shipmentClientAddressId": 747,
    "shipDate": "2020-12-23T23:54:10.3585858+00:00",
    "scanFormDataType": "imagePng",
    "carrierClientContractId": 2526,
    "carrierClientContractName": "Test",
    "shipmentClientAddressLine1": "",
    "shipmentClientAddressLine2": "",
    "shipmentClientAddressProvince": "",
    "shipmentClientAddressCity": "",
    "shipmentClientAddressPostalCode": "",
    "shippingSiteName": "",
    "dateCreated": "2020-12-23T23:54:10.3585858+00:00",
    "printJobs": [
      {
        "printTemplateType": "Template Type",
        "dataBlocks": []
      }
    ],
    "excludedItems": {}
  }
}
```

