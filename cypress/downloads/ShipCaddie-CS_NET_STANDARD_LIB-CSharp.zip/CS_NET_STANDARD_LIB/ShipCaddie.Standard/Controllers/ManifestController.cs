// <copyright file="ManifestController.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace ShipCaddie.Standard.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Dynamic;
    using System.Globalization;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading;
    using System.Threading.Tasks;
    using Newtonsoft.Json.Converters;
    using ShipCaddie.Standard;
    using ShipCaddie.Standard.Authentication;
    using ShipCaddie.Standard.Http.Client;
    using ShipCaddie.Standard.Http.Request;
    using ShipCaddie.Standard.Http.Response;
    using ShipCaddie.Standard.Utilities;

    /// <summary>
    /// ManifestController.
    /// </summary>
    public class ManifestController : BaseController
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ManifestController"/> class.
        /// </summary>
        /// <param name="config"> config instance. </param>
        /// <param name="httpClient"> httpClient. </param>
        /// <param name="authManagers"> authManager. </param>
        internal ManifestController(IConfiguration config, IHttpClient httpClient, IDictionary<string, IAuthManager> authManagers)
            : base(config, httpClient, authManagers)
        {
        }

        /// <summary>
        /// Manifest:    Create end-of-day Manifest / Scan Form (USPS)..
        /// </summary>
        /// <param name="input">Optional parameter: Example: .</param>
        /// <returns>Returns the Models.ScanFormHistoryByIDResponsev21 response from the API call.</returns>
        public Models.ScanFormHistoryByIDResponsev21 Manifest(
                Models.ScanFormHistoryByIDRequestv21 input = null)
        {
            Task<Models.ScanFormHistoryByIDResponsev21> t = this.ManifestAsync(input);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// Manifest:    Create end-of-day Manifest / Scan Form (USPS)..
        /// </summary>
        /// <param name="input">Optional parameter: Example: .</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.ScanFormHistoryByIDResponsev21 response from the API call.</returns>
        public async Task<Models.ScanFormHistoryByIDResponsev21> ManifestAsync(
                Models.ScanFormHistoryByIDRequestv21 input = null,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/api/v2.1/Manifest");

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "content-type", "application/json; charset=utf-8" },
            };

            // append body params.
            var bodyText = ApiHelper.JsonSerialize(input);

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().PostBody(queryBuilder.ToString(), headers, bodyText);

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.ScanFormHistoryByIDResponsev21>(response.Body);
        }

        /// <summary>
        /// Generate:    Obtain a ScanForm.
        /// </summary>
        /// <param name="input">Optional parameter: Example: .</param>
        /// <returns>Returns the Models.GenerateResponsev21 response from the API call.</returns>
        public Models.GenerateResponsev21 Generate(
                Models.GenerateRequestv21 input = null)
        {
            Task<Models.GenerateResponsev21> t = this.GenerateAsync(input);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// Generate:    Obtain a ScanForm.
        /// </summary>
        /// <param name="input">Optional parameter: Example: .</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.GenerateResponsev21 response from the API call.</returns>
        public async Task<Models.GenerateResponsev21> GenerateAsync(
                Models.GenerateRequestv21 input = null,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/api/v2.1/Generate");

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "content-type", "application/json; charset=utf-8" },
            };

            // append body params.
            var bodyText = ApiHelper.JsonSerialize(input);

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().PostBody(queryBuilder.ToString(), headers, bodyText);

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.GenerateResponsev21>(response.Body);
        }

        /// <summary>
        /// Regenerate:    Obtain a ScanForm.
        /// </summary>
        /// <param name="input">Optional parameter: Example: .</param>
        /// <returns>Returns the Models.RegenerateResponsev21 response from the API call.</returns>
        public Models.RegenerateResponsev21 Regenerate(
                Models.RegenerateRequestv21 input = null)
        {
            Task<Models.RegenerateResponsev21> t = this.RegenerateAsync(input);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// Regenerate:    Obtain a ScanForm.
        /// </summary>
        /// <param name="input">Optional parameter: Example: .</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.RegenerateResponsev21 response from the API call.</returns>
        public async Task<Models.RegenerateResponsev21> RegenerateAsync(
                Models.RegenerateRequestv21 input = null,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/api/v2.1/Regenerate");

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "content-type", "application/json; charset=utf-8" },
            };

            // append body params.
            var bodyText = ApiHelper.JsonSerialize(input);

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().PostBody(queryBuilder.ToString(), headers, bodyText);

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.RegenerateResponsev21>(response.Body);
        }

        /// <summary>
        /// ScanForm_History:         Get the end-of-day Manifests / Scan Forms (USPS).
        /// </summary>
        /// <param name="input">Optional parameter: Example: .</param>
        /// <returns>Returns the Models.ScanFormHistoryResponsev21 response from the API call.</returns>
        public Models.ScanFormHistoryResponsev21 ScanFormHistory(
                Models.ScanFormHistoryRequestv21 input = null)
        {
            Task<Models.ScanFormHistoryResponsev21> t = this.ScanFormHistoryAsync(input);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// ScanForm_History:         Get the end-of-day Manifests / Scan Forms (USPS).
        /// </summary>
        /// <param name="input">Optional parameter: Example: .</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.ScanFormHistoryResponsev21 response from the API call.</returns>
        public async Task<Models.ScanFormHistoryResponsev21> ScanFormHistoryAsync(
                Models.ScanFormHistoryRequestv21 input = null,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/api/v2.1/ScanForm_History");

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "content-type", "application/json; charset=utf-8" },
            };

            // append body params.
            var bodyText = ApiHelper.JsonSerialize(input);

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().PostBody(queryBuilder.ToString(), headers, bodyText);

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.ScanFormHistoryResponsev21>(response.Body);
        }

        /// <summary>
        /// AvailableShipments:    Gets Available Shipments.
        /// </summary>
        /// <param name="input">Optional parameter: Example: .</param>
        /// <returns>Returns the Models.AvailableShipmentsResponsev21 response from the API call.</returns>
        public Models.AvailableShipmentsResponsev21 AvailableShipments(
                Models.AvailableShipmentsRequestv21 input = null)
        {
            Task<Models.AvailableShipmentsResponsev21> t = this.AvailableShipmentsAsync(input);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// AvailableShipments:    Gets Available Shipments.
        /// </summary>
        /// <param name="input">Optional parameter: Example: .</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.AvailableShipmentsResponsev21 response from the API call.</returns>
        public async Task<Models.AvailableShipmentsResponsev21> AvailableShipmentsAsync(
                Models.AvailableShipmentsRequestv21 input = null,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/api/v2.1/AvailableShipments");

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "content-type", "application/json; charset=utf-8" },
            };

            // append body params.
            var bodyText = ApiHelper.JsonSerialize(input);

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().PostBody(queryBuilder.ToString(), headers, bodyText);

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.AvailableShipmentsResponsev21>(response.Body);
        }

        /// <summary>
        /// ScanForm_Generate:         Get Manifests / Scan Forms (USPS).
        /// </summary>
        /// <param name="input">Optional parameter: Example: .</param>
        /// <returns>Returns the Models.ScanFormGenerateResponsev21 response from the API call.</returns>
        public Models.ScanFormGenerateResponsev21 ScanFormGenerate(
                Models.ScanFormGenerateRequestv21 input = null)
        {
            Task<Models.ScanFormGenerateResponsev21> t = this.ScanFormGenerateAsync(input);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// ScanForm_Generate:         Get Manifests / Scan Forms (USPS).
        /// </summary>
        /// <param name="input">Optional parameter: Example: .</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.ScanFormGenerateResponsev21 response from the API call.</returns>
        public async Task<Models.ScanFormGenerateResponsev21> ScanFormGenerateAsync(
                Models.ScanFormGenerateRequestv21 input = null,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/api/v2.1/ScanForm_Generate");

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "content-type", "application/json; charset=utf-8" },
            };

            // append body params.
            var bodyText = ApiHelper.JsonSerialize(input);

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().PostBody(queryBuilder.ToString(), headers, bodyText);

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.ScanFormGenerateResponsev21>(response.Body);
        }
    }
}