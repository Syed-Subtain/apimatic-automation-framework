// <copyright file="ShipmentsController.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace ShipCaddie.Standard.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Dynamic;
    using System.Globalization;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading;
    using System.Threading.Tasks;
    using Newtonsoft.Json.Converters;
    using ShipCaddie.Standard;
    using ShipCaddie.Standard.Authentication;
    using ShipCaddie.Standard.Http.Client;
    using ShipCaddie.Standard.Http.Request;
    using ShipCaddie.Standard.Http.Response;
    using ShipCaddie.Standard.Utilities;

    /// <summary>
    /// ShipmentsController.
    /// </summary>
    public class ShipmentsController : BaseController
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ShipmentsController"/> class.
        /// </summary>
        /// <param name="config"> config instance. </param>
        /// <param name="httpClient"> httpClient. </param>
        /// <param name="authManagers"> authManager. </param>
        internal ShipmentsController(IConfiguration config, IHttpClient httpClient, IDictionary<string, IAuthManager> authManagers)
            : base(config, httpClient, authManagers)
        {
        }

        /// <summary>
        /// UpdateShipment:    Updates existing Shipment information.
        /// </summary>
        /// <param name="input">Optional parameter: Example: .</param>
        /// <returns>Returns the Models.ShippingCostData response from the API call.</returns>
        public Models.ShippingCostData UpdateShipment(
                Models.UpdateShipmentRequest input = null)
        {
            Task<Models.ShippingCostData> t = this.UpdateShipmentAsync(input);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// UpdateShipment:    Updates existing Shipment information.
        /// </summary>
        /// <param name="input">Optional parameter: Example: .</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.ShippingCostData response from the API call.</returns>
        public async Task<Models.ShippingCostData> UpdateShipmentAsync(
                Models.UpdateShipmentRequest input = null,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/api/v2.1/UpdateShipment");

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "content-type", "application/json; charset=utf-8" },
            };

            // append body params.
            var bodyText = ApiHelper.JsonSerialize(input);

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().PostBody(queryBuilder.ToString(), headers, bodyText);

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.ShippingCostData>(response.Body);
        }

        /// <summary>
        /// DeleteShipmentByID EndPoint.
        /// </summary>
        /// <param name="input">Optional parameter: Example: .</param>
        /// <returns>Returns the Models.DeleteShipmentResult response from the API call.</returns>
        public Models.DeleteShipmentResult DeleteShipmentByID(
                Models.ShipmentRequestByID input = null)
        {
            Task<Models.DeleteShipmentResult> t = this.DeleteShipmentByIDAsync(input);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// DeleteShipmentByID EndPoint.
        /// </summary>
        /// <param name="input">Optional parameter: Example: .</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.DeleteShipmentResult response from the API call.</returns>
        public async Task<Models.DeleteShipmentResult> DeleteShipmentByIDAsync(
                Models.ShipmentRequestByID input = null,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/api/v2.1/DeleteShipmentByID");

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "content-type", "application/json; charset=utf-8" },
            };

            // append body params.
            var bodyText = ApiHelper.JsonSerialize(input);

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().PostBody(queryBuilder.ToString(), headers, bodyText);

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.DeleteShipmentResult>(response.Body);
        }

        /// <summary>
        /// This method can be used to get the shipments inventeries by sku within given date range..
        /// </summary>
        /// <param name="input">Optional parameter: Example: .</param>
        /// <returns>Returns the Models.ShipmentInventoryBySkuResponseModel response from the API call.</returns>
        public Models.ShipmentInventoryBySkuResponseModel GetShipmentItemsBySku(
                Models.ShipmentRequestByDate input = null)
        {
            Task<Models.ShipmentInventoryBySkuResponseModel> t = this.GetShipmentItemsBySkuAsync(input);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// This method can be used to get the shipments inventeries by sku within given date range..
        /// </summary>
        /// <param name="input">Optional parameter: Example: .</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.ShipmentInventoryBySkuResponseModel response from the API call.</returns>
        public async Task<Models.ShipmentInventoryBySkuResponseModel> GetShipmentItemsBySkuAsync(
                Models.ShipmentRequestByDate input = null,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/api/v2.1/GetShipmentItemsBySku");

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "content-type", "application/json; charset=utf-8" },
            };

            // append body params.
            var bodyText = ApiHelper.JsonSerialize(input);

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().PostBody(queryBuilder.ToString(), headers, bodyText);

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.ShipmentInventoryBySkuResponseModel>(response.Body);
        }

        /// <summary>
        /// After successfully adding a shipment request,.
        /// use the Get Shipping Labels by ShippingID.
        /// to get the shipping label..
        /// </summary>
        /// <param name="input">Optional parameter: Example: .</param>
        /// <returns>Returns the Models.ShippingCostData response from the API call.</returns>
        public Models.ShippingCostData AddShipment(
                Models.AddShipmentRequest input = null)
        {
            Task<Models.ShippingCostData> t = this.AddShipmentAsync(input);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// After successfully adding a shipment request,.
        /// use the Get Shipping Labels by ShippingID.
        /// to get the shipping label..
        /// </summary>
        /// <param name="input">Optional parameter: Example: .</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.ShippingCostData response from the API call.</returns>
        public async Task<Models.ShippingCostData> AddShipmentAsync(
                Models.AddShipmentRequest input = null,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/api/v2.1/AddNewShipment");

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "content-type", "application/json; charset=utf-8" },
            };

            // append body params.
            var bodyText = ApiHelper.JsonSerialize(input);

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().PostBody(queryBuilder.ToString(), headers, bodyText);

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.ShippingCostData>(response.Body);
        }

        /// <summary>
        /// This method can be used to get the information necessary to update a shipment..
        /// </summary>
        /// <param name="input">Optional parameter: Example: .</param>
        /// <returns>Returns the Models.ShipmentInformationResponse response from the API call.</returns>
        public Models.ShipmentInformationResponse GetShipmentInformation(
                Models.ShipmentRequestByID input = null)
        {
            Task<Models.ShipmentInformationResponse> t = this.GetShipmentInformationAsync(input);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// This method can be used to get the information necessary to update a shipment..
        /// </summary>
        /// <param name="input">Optional parameter: Example: .</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.ShipmentInformationResponse response from the API call.</returns>
        public async Task<Models.ShipmentInformationResponse> GetShipmentInformationAsync(
                Models.ShipmentRequestByID input = null,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/api/v2.1/GetShipmentInformation");

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "content-type", "application/json; charset=utf-8" },
            };

            // append body params.
            var bodyText = ApiHelper.JsonSerialize(input);

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().PostBody(queryBuilder.ToString(), headers, bodyText);

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.ShipmentInformationResponse>(response.Body);
        }

        /// <summary>
        /// This method can be used to get the information about a shipped shipment..
        /// </summary>
        /// <param name="input">Optional parameter: Example: .</param>
        /// <returns>Returns the Models.ShippedInfoResponse response from the API call.</returns>
        public Models.ShippedInfoResponse GetShippedInfo(
                Models.ShippedInfoRequest input = null)
        {
            Task<Models.ShippedInfoResponse> t = this.GetShippedInfoAsync(input);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// This method can be used to get the information about a shipped shipment..
        /// </summary>
        /// <param name="input">Optional parameter: Example: .</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.ShippedInfoResponse response from the API call.</returns>
        public async Task<Models.ShippedInfoResponse> GetShippedInfoAsync(
                Models.ShippedInfoRequest input = null,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/api/v2.1/GetShippedInfo");

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "content-type", "application/json; charset=utf-8" },
            };

            // append body params.
            var bodyText = ApiHelper.JsonSerialize(input);

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().PostBody(queryBuilder.ToString(), headers, bodyText);

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.ShippedInfoResponse>(response.Body);
        }
    }
}