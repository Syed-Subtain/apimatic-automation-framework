// <copyright file="RatesDisplayController.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace ShipCaddie.Standard.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Dynamic;
    using System.Globalization;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading;
    using System.Threading.Tasks;
    using Newtonsoft.Json.Converters;
    using ShipCaddie.Standard;
    using ShipCaddie.Standard.Authentication;
    using ShipCaddie.Standard.Http.Client;
    using ShipCaddie.Standard.Http.Request;
    using ShipCaddie.Standard.Http.Response;
    using ShipCaddie.Standard.Utilities;

    /// <summary>
    /// RatesDisplayController.
    /// </summary>
    public class RatesDisplayController : BaseController
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="RatesDisplayController"/> class.
        /// </summary>
        /// <param name="config"> config instance. </param>
        /// <param name="httpClient"> httpClient. </param>
        /// <param name="authManagers"> authManager. </param>
        internal RatesDisplayController(IConfiguration config, IHttpClient httpClient, IDictionary<string, IAuthManager> authManagers)
            : base(config, httpClient, authManagers)
        {
        }

        /// <summary>
        /// Before creating a shipping label, .
        /// you can use this method to get a .
        /// break down of all shipping charges..
        /// This allows you to determine .
        /// how much it would cost if you were to .
        /// actually send the parcels..
        ///  NOTE: HTTPS is Required to recieve a response..
        /// </summary>
        /// <param name="rateRequest">Optional parameter: Shipping and parcel information                neccessary to calculate rates..</param>
        /// <returns>Returns the Models.RateResponse response from the API call.</returns>
        public Models.RateResponse GetRatesWithDisplay(
                Models.RateRequest rateRequest = null)
        {
            Task<Models.RateResponse> t = this.GetRatesWithDisplayAsync(rateRequest);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// Before creating a shipping label, .
        /// you can use this method to get a .
        /// break down of all shipping charges..
        /// This allows you to determine .
        /// how much it would cost if you were to .
        /// actually send the parcels..
        ///  NOTE: HTTPS is Required to recieve a response..
        /// </summary>
        /// <param name="rateRequest">Optional parameter: Shipping and parcel information                neccessary to calculate rates..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.RateResponse response from the API call.</returns>
        public async Task<Models.RateResponse> GetRatesWithDisplayAsync(
                Models.RateRequest rateRequest = null,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/api/v2.1/GetRatesWithDisplay");

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "content-type", "application/json; charset=utf-8" },
            };

            // append body params.
            var bodyText = ApiHelper.JsonSerialize(rateRequest);

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().PostBody(queryBuilder.ToString(), headers, bodyText);

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.RateResponse>(response.Body);
        }
    }
}