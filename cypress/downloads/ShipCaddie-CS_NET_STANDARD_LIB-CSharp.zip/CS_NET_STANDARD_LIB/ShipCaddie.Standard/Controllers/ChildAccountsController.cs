// <copyright file="ChildAccountsController.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace ShipCaddie.Standard.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Dynamic;
    using System.Globalization;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading;
    using System.Threading.Tasks;
    using Newtonsoft.Json.Converters;
    using ShipCaddie.Standard;
    using ShipCaddie.Standard.Authentication;
    using ShipCaddie.Standard.Http.Client;
    using ShipCaddie.Standard.Http.Request;
    using ShipCaddie.Standard.Http.Response;
    using ShipCaddie.Standard.Utilities;

    /// <summary>
    /// ChildAccountsController.
    /// </summary>
    public class ChildAccountsController : BaseController
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ChildAccountsController"/> class.
        /// </summary>
        /// <param name="config"> config instance. </param>
        /// <param name="httpClient"> httpClient. </param>
        /// <param name="authManagers"> authManager. </param>
        internal ChildAccountsController(IConfiguration config, IHttpClient httpClient, IDictionary<string, IAuthManager> authManagers)
            : base(config, httpClient, authManagers)
        {
        }

        /// <summary>
        /// Obtain child accounts which are associated with this account..
        /// </summary>
        /// <param name="input">Optional parameter: Example: .</param>
        /// <returns>Returns the Models.GetChildAccountsResponsev21 response from the API call.</returns>
        public Models.GetChildAccountsResponsev21 GetChildAccounts(
                Models.GetChildAccountsRequestv21 input = null)
        {
            Task<Models.GetChildAccountsResponsev21> t = this.GetChildAccountsAsync(input);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// Obtain child accounts which are associated with this account..
        /// </summary>
        /// <param name="input">Optional parameter: Example: .</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.GetChildAccountsResponsev21 response from the API call.</returns>
        public async Task<Models.GetChildAccountsResponsev21> GetChildAccountsAsync(
                Models.GetChildAccountsRequestv21 input = null,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/api/v2.1/GetChildAccounts");

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "content-type", "application/json; charset=utf-8" },
            };

            // append body params.
            var bodyText = ApiHelper.JsonSerialize(input);

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().PostBody(queryBuilder.ToString(), headers, bodyText);

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.GetChildAccountsResponsev21>(response.Body);
        }
    }
}