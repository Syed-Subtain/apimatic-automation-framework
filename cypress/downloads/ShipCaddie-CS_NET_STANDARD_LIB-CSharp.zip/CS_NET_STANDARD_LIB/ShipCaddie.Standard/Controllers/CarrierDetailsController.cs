// <copyright file="CarrierDetailsController.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace ShipCaddie.Standard.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Dynamic;
    using System.Globalization;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading;
    using System.Threading.Tasks;
    using Newtonsoft.Json.Converters;
    using ShipCaddie.Standard;
    using ShipCaddie.Standard.Authentication;
    using ShipCaddie.Standard.Http.Client;
    using ShipCaddie.Standard.Http.Request;
    using ShipCaddie.Standard.Http.Response;
    using ShipCaddie.Standard.Utilities;

    /// <summary>
    /// CarrierDetailsController.
    /// </summary>
    public class CarrierDetailsController : BaseController
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="CarrierDetailsController"/> class.
        /// </summary>
        /// <param name="config"> config instance. </param>
        /// <param name="httpClient"> httpClient. </param>
        /// <param name="authManagers"> authManager. </param>
        internal CarrierDetailsController(IConfiguration config, IHttpClient httpClient, IDictionary<string, IAuthManager> authManagers)
            : base(config, httpClient, authManagers)
        {
        }

        /// <summary>
        /// Multiple API methods require this information..
        /// </summary>
        /// <param name="input">Optional parameter: Example: .</param>
        /// <returns>Returns the Models.GetCarrierServiceInformationResponsev21 response from the API call.</returns>
        public Models.GetCarrierServiceInformationResponsev21 GetCarrierServiceInformation(
                Models.GetCarrierServiceInformationRequestv21 input = null)
        {
            Task<Models.GetCarrierServiceInformationResponsev21> t = this.GetCarrierServiceInformationAsync(input);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// Multiple API methods require this information..
        /// </summary>
        /// <param name="input">Optional parameter: Example: .</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.GetCarrierServiceInformationResponsev21 response from the API call.</returns>
        public async Task<Models.GetCarrierServiceInformationResponsev21> GetCarrierServiceInformationAsync(
                Models.GetCarrierServiceInformationRequestv21 input = null,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/api/v2.1/GetCarrierServiceInformation");

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "content-type", "application/json; charset=utf-8" },
            };

            // append body params.
            var bodyText = ApiHelper.JsonSerialize(input);

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().PostBody(queryBuilder.ToString(), headers, bodyText);

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.GetCarrierServiceInformationResponsev21>(response.Body);
        }

        /// <summary>
        /// Verifies packages height, length, and width..
        /// </summary>
        /// <param name="input">Optional parameter: Example: .</param>
        /// <returns>Returns the Models.VerifyPackageLengthGirthLimitResponsev21 response from the API call.</returns>
        public Models.VerifyPackageLengthGirthLimitResponsev21 VerifyPackageLengthGirthLimit(
                Models.VerifyPackageLengthGirthLimitRequestv21 input = null)
        {
            Task<Models.VerifyPackageLengthGirthLimitResponsev21> t = this.VerifyPackageLengthGirthLimitAsync(input);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// Verifies packages height, length, and width..
        /// </summary>
        /// <param name="input">Optional parameter: Example: .</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.VerifyPackageLengthGirthLimitResponsev21 response from the API call.</returns>
        public async Task<Models.VerifyPackageLengthGirthLimitResponsev21> VerifyPackageLengthGirthLimitAsync(
                Models.VerifyPackageLengthGirthLimitRequestv21 input = null,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/api/v2.1/VerifyPackageLengthGirthLimit");

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "content-type", "application/json; charset=utf-8" },
            };

            // append body params.
            var bodyText = ApiHelper.JsonSerialize(input);

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().PostBody(queryBuilder.ToString(), headers, bodyText);

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.VerifyPackageLengthGirthLimitResponsev21>(response.Body);
        }

        /// <summary>
        /// Details include parcel weight limits and maximum dimensions..
        /// </summary>
        /// <param name="input">Optional parameter: Example: .</param>
        /// <returns>Returns the Models.GetCarrierParcelSpecificationResponsev21 response from the API call.</returns>
        public Models.GetCarrierParcelSpecificationResponsev21 GetCarrierParcelSpecification(
                Models.GetCarrierParcelSpecificationRequestv21 input = null)
        {
            Task<Models.GetCarrierParcelSpecificationResponsev21> t = this.GetCarrierParcelSpecificationAsync(input);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// Details include parcel weight limits and maximum dimensions..
        /// </summary>
        /// <param name="input">Optional parameter: Example: .</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.GetCarrierParcelSpecificationResponsev21 response from the API call.</returns>
        public async Task<Models.GetCarrierParcelSpecificationResponsev21> GetCarrierParcelSpecificationAsync(
                Models.GetCarrierParcelSpecificationRequestv21 input = null,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/api/v2.1/GetCarrierParcelSpecification");

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "content-type", "application/json; charset=utf-8" },
            };

            // append body params.
            var bodyText = ApiHelper.JsonSerialize(input);

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().PostBody(queryBuilder.ToString(), headers, bodyText);

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.GetCarrierParcelSpecificationResponsev21>(response.Body);
        }
    }
}