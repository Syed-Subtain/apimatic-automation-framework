// <copyright file="LabelsController.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace ShipCaddie.Standard.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Dynamic;
    using System.Globalization;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading;
    using System.Threading.Tasks;
    using Newtonsoft.Json.Converters;
    using ShipCaddie.Standard;
    using ShipCaddie.Standard.Authentication;
    using ShipCaddie.Standard.Http.Client;
    using ShipCaddie.Standard.Http.Request;
    using ShipCaddie.Standard.Http.Response;
    using ShipCaddie.Standard.Utilities;

    /// <summary>
    /// LabelsController.
    /// </summary>
    public class LabelsController : BaseController
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="LabelsController"/> class.
        /// </summary>
        /// <param name="config"> config instance. </param>
        /// <param name="httpClient"> httpClient. </param>
        /// <param name="authManagers"> authManager. </param>
        internal LabelsController(IConfiguration config, IHttpClient httpClient, IDictionary<string, IAuthManager> authManagers)
            : base(config, httpClient, authManagers)
        {
        }

        /// <summary>
        /// The labels are represented by a base 64 string..
        /// </summary>
        /// <param name="input">Optional parameter: Example: .</param>
        /// <returns>Returns the Models.LabelInformationWithCost response from the API call.</returns>
        public Models.LabelInformationWithCost GetLabelsByShippingIDWithCost(
                Models.GetShippingLabelsByShippingIDRequestv21 input = null)
        {
            Task<Models.LabelInformationWithCost> t = this.GetLabelsByShippingIDWithCostAsync(input);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// The labels are represented by a base 64 string..
        /// </summary>
        /// <param name="input">Optional parameter: Example: .</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.LabelInformationWithCost response from the API call.</returns>
        public async Task<Models.LabelInformationWithCost> GetLabelsByShippingIDWithCostAsync(
                Models.GetShippingLabelsByShippingIDRequestv21 input = null,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/api/v2.1/GetLabelsByShippingIDWithCost");

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "content-type", "application/json; charset=utf-8" },
            };

            // append body params.
            var bodyText = ApiHelper.JsonSerialize(input);

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().PostBody(queryBuilder.ToString(), headers, bodyText);

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.LabelInformationWithCost>(response.Body);
        }

        /// <summary>
        /// In some conditions - such as already shipped parcels - the labels will not be voided..
        /// </summary>
        /// <param name="input">Optional parameter: Example: .</param>
        /// <returns>Returns the Models.VoidLabelResponsev21 response from the API call.</returns>
        public Models.VoidLabelResponsev21 VoidLabel(
                Models.VoidLabelRequestv21 input = null)
        {
            Task<Models.VoidLabelResponsev21> t = this.VoidLabelAsync(input);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// In some conditions - such as already shipped parcels - the labels will not be voided..
        /// </summary>
        /// <param name="input">Optional parameter: Example: .</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.VoidLabelResponsev21 response from the API call.</returns>
        public async Task<Models.VoidLabelResponsev21> VoidLabelAsync(
                Models.VoidLabelRequestv21 input = null,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/api/v2.1/VoidLabel");

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "content-type", "application/json; charset=utf-8" },
            };

            // append body params.
            var bodyText = ApiHelper.JsonSerialize(input);

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().PostBody(queryBuilder.ToString(), headers, bodyText);

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.VoidLabelResponsev21>(response.Body);
        }

        /// <summary>
        /// The labels are represented by a base 64 string..
        /// </summary>
        /// <param name="input">Optional parameter: Example: .</param>
        /// <returns>Returns the Models.LabelInformation response from the API call.</returns>
        public Models.LabelInformation GetShippingLabelsByShippingID(
                Models.GetShippingLabelsByShippingIDRequestv21 input = null)
        {
            Task<Models.LabelInformation> t = this.GetShippingLabelsByShippingIDAsync(input);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// The labels are represented by a base 64 string..
        /// </summary>
        /// <param name="input">Optional parameter: Example: .</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.LabelInformation response from the API call.</returns>
        public async Task<Models.LabelInformation> GetShippingLabelsByShippingIDAsync(
                Models.GetShippingLabelsByShippingIDRequestv21 input = null,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/api/v2.1/GetShippingLabelsByShippingID");

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "content-type", "application/json; charset=utf-8" },
            };

            // append body params.
            var bodyText = ApiHelper.JsonSerialize(input);

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().PostBody(queryBuilder.ToString(), headers, bodyText);

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.LabelInformation>(response.Body);
        }

        /// <summary>
        /// The labels are represented by a base 64 string..
        /// </summary>
        /// <param name="input">Optional parameter: Example: .</param>
        /// <returns>Returns the Models.LabelInformation response from the API call.</returns>
        public Models.LabelInformation GetShippingLabels(
                Models.GetShippingLabelsRequestv21 input = null)
        {
            Task<Models.LabelInformation> t = this.GetShippingLabelsAsync(input);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// The labels are represented by a base 64 string..
        /// </summary>
        /// <param name="input">Optional parameter: Example: .</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.LabelInformation response from the API call.</returns>
        public async Task<Models.LabelInformation> GetShippingLabelsAsync(
                Models.GetShippingLabelsRequestv21 input = null,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/api/v2.1/GetShippingLabels");

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "content-type", "application/json; charset=utf-8" },
            };

            // append body params.
            var bodyText = ApiHelper.JsonSerialize(input);

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().PostBody(queryBuilder.ToString(), headers, bodyText);

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.LabelInformation>(response.Body);
        }

        /// <summary>
        /// The labels are represented by a base 64 string..
        /// </summary>
        /// <param name="input">Optional parameter: Example: .</param>
        /// <returns>Returns the Models.LabelInformationWithCost response from the API call.</returns>
        public Models.LabelInformationWithCost GetLabelWithCost(
                Models.GetShippingLabelsRequestv21 input = null)
        {
            Task<Models.LabelInformationWithCost> t = this.GetLabelWithCostAsync(input);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// The labels are represented by a base 64 string..
        /// </summary>
        /// <param name="input">Optional parameter: Example: .</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.LabelInformationWithCost response from the API call.</returns>
        public async Task<Models.LabelInformationWithCost> GetLabelWithCostAsync(
                Models.GetShippingLabelsRequestv21 input = null,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/api/v2.1/GetLabelWithCost");

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "content-type", "application/json; charset=utf-8" },
            };

            // append body params.
            var bodyText = ApiHelper.JsonSerialize(input);

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().PostBody(queryBuilder.ToString(), headers, bodyText);

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.LabelInformationWithCost>(response.Body);
        }
    }
}