// <copyright file="ShippingOptions.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace ShipCaddie.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using ShipCaddie.Standard;
    using ShipCaddie.Standard.Utilities;

    /// <summary>
    /// ShippingOptions.
    /// </summary>
    public class ShippingOptions
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ShippingOptions"/> class.
        /// </summary>
        public ShippingOptions()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ShippingOptions"/> class.
        /// </summary>
        /// <param name="isAPOFPODPOUSTerritory">isAPO_FPO_DPO_USTerritory.</param>
        /// <param name="isInternationalShipment">isInternationalShipment.</param>
        /// <param name="billing">billing.</param>
        /// <param name="shipmentContentType">shipmentContentType.</param>
        /// <param name="customsCertify">customsCertify.</param>
        /// <param name="customsSigner">customsSigner.</param>
        /// <param name="internalTransactionNumber">internalTransactionNumber.</param>
        /// <param name="contentsExplanation">contentsExplanation.</param>
        public ShippingOptions(
            bool isAPOFPODPOUSTerritory,
            bool isInternationalShipment,
            Models.BillingOptions billing,
            Models.ShipmentContentTypeEnum? shipmentContentType = null,
            bool? customsCertify = null,
            string customsSigner = null,
            string internalTransactionNumber = null,
            string contentsExplanation = null)
        {
            this.IsAPOFPODPOUSTerritory = isAPOFPODPOUSTerritory;
            this.IsInternationalShipment = isInternationalShipment;
            this.Billing = billing;
            this.ShipmentContentType = shipmentContentType;
            this.CustomsCertify = customsCertify;
            this.CustomsSigner = customsSigner;
            this.InternalTransactionNumber = internalTransactionNumber;
            this.ContentsExplanation = contentsExplanation;
        }

        /// <summary>
        /// Set this to true if shipping to:
        /// * Army Post Office
        /// * Fleet Post Office
        /// * Diplomatic Post Office
        /// * US Territories
        /// Default value is false.
        /// </summary>
        [JsonProperty("isAPO_FPO_DPO_USTerritory")]
        public bool IsAPOFPODPOUSTerritory { get; set; }

        /// <summary>
        /// Specifies if this shipment is an international shipment.
        ///  Default is false.
        /// </summary>
        [JsonProperty("isInternationalShipment")]
        public bool IsInternationalShipment { get; set; }

        /// <summary>
        /// Specifies how the shipping costs will be paid.
        /// </summary>
        [JsonProperty("billing")]
        public Models.BillingOptions Billing { get; set; }

        /// <summary>
        /// Indicates the type of content that is in the parcels.
        /// Will be used for customs declarations if shipping internationally.
        /// </summary>
        [JsonProperty("shipmentContentType", ItemConverterType = typeof(StringEnumConverter), NullValueHandling = NullValueHandling.Ignore)]
        public Models.ShipmentContentTypeEnum? ShipmentContentType { get; set; }

        /// <summary>
        /// TRUE means the customs information is certified to be correct and the CustomsSigner name is recommended
        ///  Default is null.
        /// </summary>
        [JsonProperty("customsCertify", NullValueHandling = NullValueHandling.Ignore)]
        public bool? CustomsCertify { get; set; }

        /// <summary>
        /// Name of person certifying that the customs information is correct.
        /// This name prints on the customs form in place of a signature
        /// if CustomsCertify is TRUE. Required if CustomsCertify is TRUE
        ///  Default is null.
        /// </summary>
        [JsonProperty("customsSigner", NullValueHandling = NullValueHandling.Ignore)]
        public string CustomsSigner { get; set; }

        /// <summary>
        /// InternalTransactionNumber is required in case of international shipments and having customDeclarationValue &gt; 2500
        /// </summary>
        [JsonProperty("internalTransactionNumber", NullValueHandling = NullValueHandling.Ignore)]
        public string InternalTransactionNumber { get; set; }

        /// <summary>
        /// If we have "CONTENT_TYPE_OTHER" as content type then
        /// Then need to pass ContentsExplanation as value
        /// </summary>
        [JsonProperty("contentsExplanation", NullValueHandling = NullValueHandling.Ignore)]
        public string ContentsExplanation { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"ShippingOptions : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is ShippingOptions other &&
                this.IsAPOFPODPOUSTerritory.Equals(other.IsAPOFPODPOUSTerritory) &&
                this.IsInternationalShipment.Equals(other.IsInternationalShipment) &&
                ((this.Billing == null && other.Billing == null) || (this.Billing?.Equals(other.Billing) == true)) &&
                ((this.ShipmentContentType == null && other.ShipmentContentType == null) || (this.ShipmentContentType?.Equals(other.ShipmentContentType) == true)) &&
                ((this.CustomsCertify == null && other.CustomsCertify == null) || (this.CustomsCertify?.Equals(other.CustomsCertify) == true)) &&
                ((this.CustomsSigner == null && other.CustomsSigner == null) || (this.CustomsSigner?.Equals(other.CustomsSigner) == true)) &&
                ((this.InternalTransactionNumber == null && other.InternalTransactionNumber == null) || (this.InternalTransactionNumber?.Equals(other.InternalTransactionNumber) == true)) &&
                ((this.ContentsExplanation == null && other.ContentsExplanation == null) || (this.ContentsExplanation?.Equals(other.ContentsExplanation) == true));
        }

        /// <inheritdoc/>
        public override int GetHashCode()
        {
            int hashCode = 2146279566;
            hashCode += this.IsAPOFPODPOUSTerritory.GetHashCode();
            hashCode += this.IsInternationalShipment.GetHashCode();

            if (this.Billing != null)
            {
               hashCode += this.Billing.GetHashCode();
            }

            if (this.ShipmentContentType != null)
            {
               hashCode += this.ShipmentContentType.GetHashCode();
            }

            if (this.CustomsCertify != null)
            {
               hashCode += this.CustomsCertify.GetHashCode();
            }

            if (this.CustomsSigner != null)
            {
               hashCode += this.CustomsSigner.GetHashCode();
            }

            if (this.InternalTransactionNumber != null)
            {
               hashCode += this.InternalTransactionNumber.GetHashCode();
            }

            if (this.ContentsExplanation != null)
            {
               hashCode += this.ContentsExplanation.GetHashCode();
            }

            return hashCode;
        }

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.IsAPOFPODPOUSTerritory = {this.IsAPOFPODPOUSTerritory}");
            toStringOutput.Add($"this.IsInternationalShipment = {this.IsInternationalShipment}");
            toStringOutput.Add($"this.Billing = {(this.Billing == null ? "null" : this.Billing.ToString())}");
            toStringOutput.Add($"this.ShipmentContentType = {(this.ShipmentContentType == null ? "null" : this.ShipmentContentType.ToString())}");
            toStringOutput.Add($"this.CustomsCertify = {(this.CustomsCertify == null ? "null" : this.CustomsCertify.ToString())}");
            toStringOutput.Add($"this.CustomsSigner = {(this.CustomsSigner == null ? "null" : this.CustomsSigner == string.Empty ? "" : this.CustomsSigner)}");
            toStringOutput.Add($"this.InternalTransactionNumber = {(this.InternalTransactionNumber == null ? "null" : this.InternalTransactionNumber == string.Empty ? "" : this.InternalTransactionNumber)}");
            toStringOutput.Add($"this.ContentsExplanation = {(this.ContentsExplanation == null ? "null" : this.ContentsExplanation == string.Empty ? "" : this.ContentsExplanation)}");
        }
    }
}