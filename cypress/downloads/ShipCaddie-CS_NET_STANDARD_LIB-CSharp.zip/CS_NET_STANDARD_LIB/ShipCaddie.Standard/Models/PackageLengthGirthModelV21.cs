// <copyright file="PackageLengthGirthModelV21.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace ShipCaddie.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using ShipCaddie.Standard;
    using ShipCaddie.Standard.Utilities;

    /// <summary>
    /// PackageLengthGirthModelV21.
    /// </summary>
    public class PackageLengthGirthModelV21
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="PackageLengthGirthModelV21"/> class.
        /// </summary>
        public PackageLengthGirthModelV21()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="PackageLengthGirthModelV21"/> class.
        /// </summary>
        /// <param name="carrierServiceLevelId">carrierServiceLevelId.</param>
        /// <param name="packageList">packageList.</param>
        public PackageLengthGirthModelV21(
            int? carrierServiceLevelId = null,
            List<Models.PackagesV21> packageList = null)
        {
            this.CarrierServiceLevelId = carrierServiceLevelId;
            this.PackageList = packageList;
        }

        /// <summary>
        /// Required - CarrierServiceLevelId
        /// </summary>
        [JsonProperty("carrierServiceLevelId", NullValueHandling = NullValueHandling.Ignore)]
        public int? CarrierServiceLevelId { get; set; }

        /// <summary>
        /// List of Packages
        /// </summary>
        [JsonProperty("packageList", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.PackagesV21> PackageList { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"PackageLengthGirthModelV21 : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is PackageLengthGirthModelV21 other &&
                ((this.CarrierServiceLevelId == null && other.CarrierServiceLevelId == null) || (this.CarrierServiceLevelId?.Equals(other.CarrierServiceLevelId) == true)) &&
                ((this.PackageList == null && other.PackageList == null) || (this.PackageList?.Equals(other.PackageList) == true));
        }

        /// <inheritdoc/>
        public override int GetHashCode()
        {
            int hashCode = -448426219;

            if (this.CarrierServiceLevelId != null)
            {
               hashCode += this.CarrierServiceLevelId.GetHashCode();
            }

            if (this.PackageList != null)
            {
               hashCode += this.PackageList.GetHashCode();
            }

            return hashCode;
        }

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.CarrierServiceLevelId = {(this.CarrierServiceLevelId == null ? "null" : this.CarrierServiceLevelId.ToString())}");
            toStringOutput.Add($"this.PackageList = {(this.PackageList == null ? "null" : $"[{string.Join(", ", this.PackageList)} ]")}");
        }
    }
}