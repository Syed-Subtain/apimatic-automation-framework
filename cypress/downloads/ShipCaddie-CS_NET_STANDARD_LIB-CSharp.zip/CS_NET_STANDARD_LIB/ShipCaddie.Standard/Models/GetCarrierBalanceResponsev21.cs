// <copyright file="GetCarrierBalanceResponsev21.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace ShipCaddie.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using ShipCaddie.Standard;
    using ShipCaddie.Standard.Utilities;

    /// <summary>
    /// GetCarrierBalanceResponsev21.
    /// </summary>
    public class GetCarrierBalanceResponsev21
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="GetCarrierBalanceResponsev21"/> class.
        /// </summary>
        public GetCarrierBalanceResponsev21()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="GetCarrierBalanceResponsev21"/> class.
        /// </summary>
        /// <param name="threshold">threshold.</param>
        /// <param name="rechargeAmount">rechargeAmount.</param>
        /// <param name="balance">balance.</param>
        /// <param name="error">error.</param>
        public GetCarrierBalanceResponsev21(
            double threshold,
            double rechargeAmount,
            double balance,
            Models.RequestError error = null)
        {
            this.Threshold = threshold;
            this.RechargeAmount = rechargeAmount;
            this.Balance = balance;
            this.Error = error;
        }

        /// <summary>
        /// Account Threshold
        /// </summary>
        [JsonProperty("threshold")]
        public double Threshold { get; set; }

        /// <summary>
        /// Account Recharge Amount
        /// </summary>
        [JsonProperty("rechargeAmount")]
        public double RechargeAmount { get; set; }

        /// <summary>
        /// Account Balance
        /// </summary>
        [JsonProperty("balance")]
        public double Balance { get; set; }

        /// <summary>
        /// This information can be used to determine if an error has occurred when a request was processed.
        /// </summary>
        [JsonProperty("error", NullValueHandling = NullValueHandling.Ignore)]
        public Models.RequestError Error { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"GetCarrierBalanceResponsev21 : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is GetCarrierBalanceResponsev21 other &&
                this.Threshold.Equals(other.Threshold) &&
                this.RechargeAmount.Equals(other.RechargeAmount) &&
                this.Balance.Equals(other.Balance) &&
                ((this.Error == null && other.Error == null) || (this.Error?.Equals(other.Error) == true));
        }

        /// <inheritdoc/>
        public override int GetHashCode()
        {
            int hashCode = 2052560251;
            hashCode += this.Threshold.GetHashCode();
            hashCode += this.RechargeAmount.GetHashCode();
            hashCode += this.Balance.GetHashCode();

            if (this.Error != null)
            {
               hashCode += this.Error.GetHashCode();
            }

            return hashCode;
        }

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.Threshold = {this.Threshold}");
            toStringOutput.Add($"this.RechargeAmount = {this.RechargeAmount}");
            toStringOutput.Add($"this.Balance = {this.Balance}");
            toStringOutput.Add($"this.Error = {(this.Error == null ? "null" : this.Error.ToString())}");
        }
    }
}