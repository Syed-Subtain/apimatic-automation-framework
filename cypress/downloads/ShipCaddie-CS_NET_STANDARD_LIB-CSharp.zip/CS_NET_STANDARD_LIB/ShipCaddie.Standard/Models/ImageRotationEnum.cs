// <copyright file="ImageRotationEnum.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace ShipCaddie.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Runtime.Serialization;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using ShipCaddie.Standard;
    using ShipCaddie.Standard.Utilities;

    /// <summary>
    /// ImageRotationEnum.
    /// </summary>
    [JsonConverter(typeof(StringEnumConverter))]
    public enum ImageRotationEnum
    {
        /// <summary>
        /// RotateNoneFlipNone.
        /// </summary>
        [EnumMember(Value = "RotateNoneFlipNone")]
        RotateNoneFlipNone,

        /// <summary>
        /// Rotate180FlipXY.
        /// </summary>
        [EnumMember(Value = "Rotate180FlipXY")]
        Rotate180FlipXY,

        /// <summary>
        /// Rotate90FlipNone.
        /// </summary>
        [EnumMember(Value = "Rotate90FlipNone")]
        Rotate90FlipNone,

        /// <summary>
        /// Rotate270FlipXY.
        /// </summary>
        [EnumMember(Value = "Rotate270FlipXY")]
        Rotate270FlipXY,

        /// <summary>
        /// Rotate180FlipNone.
        /// </summary>
        [EnumMember(Value = "Rotate180FlipNone")]
        Rotate180FlipNone,

        /// <summary>
        /// RotateNoneFlipXY.
        /// </summary>
        [EnumMember(Value = "RotateNoneFlipXY")]
        RotateNoneFlipXY,

        /// <summary>
        /// Rotate270FlipNone.
        /// </summary>
        [EnumMember(Value = "Rotate270FlipNone")]
        Rotate270FlipNone,

        /// <summary>
        /// Rotate90FlipXY.
        /// </summary>
        [EnumMember(Value = "Rotate90FlipXY")]
        Rotate90FlipXY,

        /// <summary>
        /// RotateNoneFlipX.
        /// </summary>
        [EnumMember(Value = "RotateNoneFlipX")]
        RotateNoneFlipX,

        /// <summary>
        /// Rotate180FlipY.
        /// </summary>
        [EnumMember(Value = "Rotate180FlipY")]
        Rotate180FlipY,

        /// <summary>
        /// Rotate90FlipX.
        /// </summary>
        [EnumMember(Value = "Rotate90FlipX")]
        Rotate90FlipX,

        /// <summary>
        /// Rotate270FlipY.
        /// </summary>
        [EnumMember(Value = "Rotate270FlipY")]
        Rotate270FlipY,

        /// <summary>
        /// Rotate180FlipX.
        /// </summary>
        [EnumMember(Value = "Rotate180FlipX")]
        Rotate180FlipX,

        /// <summary>
        /// RotateNoneFlipY.
        /// </summary>
        [EnumMember(Value = "RotateNoneFlipY")]
        RotateNoneFlipY,

        /// <summary>
        /// Rotate270FlipX.
        /// </summary>
        [EnumMember(Value = "Rotate270FlipX")]
        Rotate270FlipX,

        /// <summary>
        /// Rotate90FlipY.
        /// </summary>
        [EnumMember(Value = "Rotate90FlipY")]
        Rotate90FlipY,
    }
}