// <copyright file="SecurityToken.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace ShipCaddie.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using ShipCaddie.Standard;
    using ShipCaddie.Standard.Utilities;

    /// <summary>
    /// SecurityToken.
    /// </summary>
    public class SecurityToken
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="SecurityToken"/> class.
        /// </summary>
        public SecurityToken()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="SecurityToken"/> class.
        /// </summary>
        /// <param name="accessToken">accessToken.</param>
        /// <param name="refreshToken">refreshToken.</param>
        /// <param name="refreshTokenExpirationDate">refreshTokenExpirationDate.</param>
        /// <param name="accessTokenExpirationDate">accessTokenExpirationDate.</param>
        /// <param name="error">error.</param>
        public SecurityToken(
            string accessToken,
            string refreshToken,
            DateTime refreshTokenExpirationDate,
            DateTime accessTokenExpirationDate,
            Models.RequestError error)
        {
            this.AccessToken = accessToken;
            this.RefreshToken = refreshToken;
            this.RefreshTokenExpirationDate = refreshTokenExpirationDate;
            this.AccessTokenExpirationDate = accessTokenExpirationDate;
            this.Error = error;
        }

        /// <summary>
        /// Use this authorization token when calling other API methods.
        /// </summary>
        [JsonProperty("accessToken")]
        public string AccessToken { get; set; }

        /// <summary>
        /// Use the Refresh Token to obtain a new token after the Access Token has expired.
        /// </summary>
        [JsonProperty("refreshToken")]
        public string RefreshToken { get; set; }

        /// <summary>
        /// After this time it will be neccessary to obtain a new token using a valid username and password by calling GetToken.
        /// The time is expressed in Universal Time. (UTC)
        /// </summary>
        [JsonConverter(typeof(IsoDateTimeConverter))]
        [JsonProperty("refreshTokenExpirationDate")]
        public DateTime RefreshTokenExpirationDate { get; set; }

        /// <summary>
        /// After this time a new token can be obtained by calling RefreshToken using a valid RefreshToken.
        /// The time is expressed in Universal Time. (UTC)
        /// </summary>
        [JsonConverter(typeof(IsoDateTimeConverter))]
        [JsonProperty("accessTokenExpirationDate")]
        public DateTime AccessTokenExpirationDate { get; set; }

        /// <summary>
        /// This information can be used to determine if an error has occurred when a request was processed.
        /// </summary>
        [JsonProperty("error")]
        public Models.RequestError Error { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"SecurityToken : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is SecurityToken other &&
                ((this.AccessToken == null && other.AccessToken == null) || (this.AccessToken?.Equals(other.AccessToken) == true)) &&
                ((this.RefreshToken == null && other.RefreshToken == null) || (this.RefreshToken?.Equals(other.RefreshToken) == true)) &&
                this.RefreshTokenExpirationDate.Equals(other.RefreshTokenExpirationDate) &&
                this.AccessTokenExpirationDate.Equals(other.AccessTokenExpirationDate) &&
                ((this.Error == null && other.Error == null) || (this.Error?.Equals(other.Error) == true));
        }

        /// <inheritdoc/>
        public override int GetHashCode()
        {
            int hashCode = -428200774;

            if (this.AccessToken != null)
            {
               hashCode += this.AccessToken.GetHashCode();
            }

            if (this.RefreshToken != null)
            {
               hashCode += this.RefreshToken.GetHashCode();
            }

            hashCode += this.RefreshTokenExpirationDate.GetHashCode();
            hashCode += this.AccessTokenExpirationDate.GetHashCode();

            if (this.Error != null)
            {
               hashCode += this.Error.GetHashCode();
            }

            return hashCode;
        }

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.AccessToken = {(this.AccessToken == null ? "null" : this.AccessToken == string.Empty ? "" : this.AccessToken)}");
            toStringOutput.Add($"this.RefreshToken = {(this.RefreshToken == null ? "null" : this.RefreshToken == string.Empty ? "" : this.RefreshToken)}");
            toStringOutput.Add($"this.RefreshTokenExpirationDate = {this.RefreshTokenExpirationDate}");
            toStringOutput.Add($"this.AccessTokenExpirationDate = {this.AccessTokenExpirationDate}");
            toStringOutput.Add($"this.Error = {(this.Error == null ? "null" : this.Error.ToString())}");
        }
    }
}