// <copyright file="AddressTypeIdEnum.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace ShipCaddie.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Runtime.Serialization;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using ShipCaddie.Standard;
    using ShipCaddie.Standard.Utilities;

    /// <summary>
    /// AddressTypeIdEnum.
    /// </summary>
    [JsonConverter(typeof(StringEnumConverter))]
    public enum AddressTypeIdEnum
    {
        /// <summary>
        /// NotDefined.
        /// </summary>
        [EnumMember(Value = "NotDefined")]
        NotDefined,

        /// <summary>
        /// Residential.
        /// </summary>
        [EnumMember(Value = "Residential")]
        Residential,

        /// <summary>
        /// Commercial.
        /// </summary>
        [EnumMember(Value = "Commercial")]
        Commercial,

        /// <summary>
        /// NotVerified.
        /// </summary>
        [EnumMember(Value = "NotVerified")]
        NotVerified,

        /// <summary>
        /// Invalid.
        /// </summary>
        [EnumMember(Value = "Invalid")]
        Invalid,

        /// <summary>
        /// FailedAddress.
        /// </summary>
        [EnumMember(Value = "FailedAddress")]
        FailedAddress,

        /// <summary>
        /// UserVerified.
        /// </summary>
        [EnumMember(Value = "UserVerified")]
        UserVerified,

        /// <summary>
        /// Processing.
        /// </summary>
        [EnumMember(Value = "Processing")]
        Processing,

        /// <summary>
        /// Military.
        /// </summary>
        [EnumMember(Value = "Military")]
        Military,

        /// <summary>
        /// International.
        /// </summary>
        [EnumMember(Value = "International")]
        International,

        /// <summary>
        /// UsTerritory.
        /// </summary>
        [EnumMember(Value = "UsTerritory")]
        UsTerritory,

        /// <summary>
        /// PoBox.
        /// </summary>
        [EnumMember(Value = "PoBox")]
        PoBox,
    }
}