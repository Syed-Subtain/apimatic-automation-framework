// <copyright file="ShippedInfoRequest.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace ShipCaddie.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using ShipCaddie.Standard;
    using ShipCaddie.Standard.Utilities;

    /// <summary>
    /// ShippedInfoRequest.
    /// </summary>
    public class ShippedInfoRequest
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ShippedInfoRequest"/> class.
        /// </summary>
        public ShippedInfoRequest()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ShippedInfoRequest"/> class.
        /// </summary>
        /// <param name="accessToken">accessToken.</param>
        /// <param name="includeFromAddress">includeFromAddress.</param>
        /// <param name="includeToAddress">includeToAddress.</param>
        /// <param name="includeCarrierInfo">includeCarrierInfo.</param>
        /// <param name="includeShipmentOptions">includeShipmentOptions.</param>
        /// <param name="includeParcelInfo">includeParcelInfo.</param>
        /// <param name="includeParcelOptions">includeParcelOptions.</param>
        /// <param name="includeParcelItems">includeParcelItems.</param>
        /// <param name="asClientId">asClientId.</param>
        /// <param name="shipmentID">shipmentID.</param>
        public ShippedInfoRequest(
            string accessToken,
            bool? includeFromAddress = null,
            bool? includeToAddress = null,
            bool? includeCarrierInfo = null,
            bool? includeShipmentOptions = null,
            bool? includeParcelInfo = null,
            bool? includeParcelOptions = null,
            bool? includeParcelItems = null,
            int? asClientId = null,
            int? shipmentID = null)
        {
            this.IncludeFromAddress = includeFromAddress;
            this.IncludeToAddress = includeToAddress;
            this.IncludeCarrierInfo = includeCarrierInfo;
            this.IncludeShipmentOptions = includeShipmentOptions;
            this.IncludeParcelInfo = includeParcelInfo;
            this.IncludeParcelOptions = includeParcelOptions;
            this.IncludeParcelItems = includeParcelItems;
            this.AccessToken = accessToken;
            this.AsClientId = asClientId;
            this.ShipmentID = shipmentID;
        }

        /// <summary>
        /// Include the from address information in result. Default false
        /// </summary>
        [JsonProperty("includeFromAddress", NullValueHandling = NullValueHandling.Ignore)]
        public bool? IncludeFromAddress { get; set; }

        /// <summary>
        /// Include the to address information in the result. Default false
        /// </summary>
        [JsonProperty("includeToAddress", NullValueHandling = NullValueHandling.Ignore)]
        public bool? IncludeToAddress { get; set; }

        /// <summary>
        /// Include the carrier information in the result. Default false
        /// </summary>
        [JsonProperty("includeCarrierInfo", NullValueHandling = NullValueHandling.Ignore)]
        public bool? IncludeCarrierInfo { get; set; }

        /// <summary>
        /// Include the shipment options information in the result. Default false
        /// </summary>
        [JsonProperty("includeShipmentOptions", NullValueHandling = NullValueHandling.Ignore)]
        public bool? IncludeShipmentOptions { get; set; }

        /// <summary>
        /// Include the parcel information in the result. Default false
        /// </summary>
        [JsonProperty("includeParcelInfo", NullValueHandling = NullValueHandling.Ignore)]
        public bool? IncludeParcelInfo { get; set; }

        /// <summary>
        /// Include the parcel options information in the result. Default false
        /// </summary>
        [JsonProperty("includeParcelOptions", NullValueHandling = NullValueHandling.Ignore)]
        public bool? IncludeParcelOptions { get; set; }

        /// <summary>
        /// Include the parcel items information in the result. Default false
        /// </summary>
        [JsonProperty("includeParcelItems", NullValueHandling = NullValueHandling.Ignore)]
        public bool? IncludeParcelItems { get; set; }

        /// <summary>
        /// Required.
        /// An authorization token is necessary to call this method.
        /// <remarks>
        /// The token can be obtained by calling the GetToken or RefreshToken methods.
        /// </remarks>
        /// </summary>
        [JsonProperty("accessToken")]
        public string AccessToken { get; set; }

        /// <summary>
        /// Optional.
        /// When empty or null, this field is ignored.
        /// When set, actions will be taken for the client specified by the id.
        /// </summary>
        [JsonProperty("asClientId", NullValueHandling = NullValueHandling.Ignore)]
        public int? AsClientId { get; set; }

        /// <summary>
        /// Id of an existing shipment.
        /// </summary>
        [JsonProperty("shipmentID", NullValueHandling = NullValueHandling.Ignore)]
        public int? ShipmentID { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"ShippedInfoRequest : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is ShippedInfoRequest other &&
                ((this.IncludeFromAddress == null && other.IncludeFromAddress == null) || (this.IncludeFromAddress?.Equals(other.IncludeFromAddress) == true)) &&
                ((this.IncludeToAddress == null && other.IncludeToAddress == null) || (this.IncludeToAddress?.Equals(other.IncludeToAddress) == true)) &&
                ((this.IncludeCarrierInfo == null && other.IncludeCarrierInfo == null) || (this.IncludeCarrierInfo?.Equals(other.IncludeCarrierInfo) == true)) &&
                ((this.IncludeShipmentOptions == null && other.IncludeShipmentOptions == null) || (this.IncludeShipmentOptions?.Equals(other.IncludeShipmentOptions) == true)) &&
                ((this.IncludeParcelInfo == null && other.IncludeParcelInfo == null) || (this.IncludeParcelInfo?.Equals(other.IncludeParcelInfo) == true)) &&
                ((this.IncludeParcelOptions == null && other.IncludeParcelOptions == null) || (this.IncludeParcelOptions?.Equals(other.IncludeParcelOptions) == true)) &&
                ((this.IncludeParcelItems == null && other.IncludeParcelItems == null) || (this.IncludeParcelItems?.Equals(other.IncludeParcelItems) == true)) &&
                ((this.AccessToken == null && other.AccessToken == null) || (this.AccessToken?.Equals(other.AccessToken) == true)) &&
                ((this.AsClientId == null && other.AsClientId == null) || (this.AsClientId?.Equals(other.AsClientId) == true)) &&
                ((this.ShipmentID == null && other.ShipmentID == null) || (this.ShipmentID?.Equals(other.ShipmentID) == true));
        }

        /// <inheritdoc/>
        public override int GetHashCode()
        {
            int hashCode = -2086225450;

            if (this.IncludeFromAddress != null)
            {
               hashCode += this.IncludeFromAddress.GetHashCode();
            }

            if (this.IncludeToAddress != null)
            {
               hashCode += this.IncludeToAddress.GetHashCode();
            }

            if (this.IncludeCarrierInfo != null)
            {
               hashCode += this.IncludeCarrierInfo.GetHashCode();
            }

            if (this.IncludeShipmentOptions != null)
            {
               hashCode += this.IncludeShipmentOptions.GetHashCode();
            }

            if (this.IncludeParcelInfo != null)
            {
               hashCode += this.IncludeParcelInfo.GetHashCode();
            }

            if (this.IncludeParcelOptions != null)
            {
               hashCode += this.IncludeParcelOptions.GetHashCode();
            }

            if (this.IncludeParcelItems != null)
            {
               hashCode += this.IncludeParcelItems.GetHashCode();
            }

            if (this.AccessToken != null)
            {
               hashCode += this.AccessToken.GetHashCode();
            }

            if (this.AsClientId != null)
            {
               hashCode += this.AsClientId.GetHashCode();
            }

            if (this.ShipmentID != null)
            {
               hashCode += this.ShipmentID.GetHashCode();
            }

            return hashCode;
        }

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.IncludeFromAddress = {(this.IncludeFromAddress == null ? "null" : this.IncludeFromAddress.ToString())}");
            toStringOutput.Add($"this.IncludeToAddress = {(this.IncludeToAddress == null ? "null" : this.IncludeToAddress.ToString())}");
            toStringOutput.Add($"this.IncludeCarrierInfo = {(this.IncludeCarrierInfo == null ? "null" : this.IncludeCarrierInfo.ToString())}");
            toStringOutput.Add($"this.IncludeShipmentOptions = {(this.IncludeShipmentOptions == null ? "null" : this.IncludeShipmentOptions.ToString())}");
            toStringOutput.Add($"this.IncludeParcelInfo = {(this.IncludeParcelInfo == null ? "null" : this.IncludeParcelInfo.ToString())}");
            toStringOutput.Add($"this.IncludeParcelOptions = {(this.IncludeParcelOptions == null ? "null" : this.IncludeParcelOptions.ToString())}");
            toStringOutput.Add($"this.IncludeParcelItems = {(this.IncludeParcelItems == null ? "null" : this.IncludeParcelItems.ToString())}");
            toStringOutput.Add($"this.AccessToken = {(this.AccessToken == null ? "null" : this.AccessToken == string.Empty ? "" : this.AccessToken)}");
            toStringOutput.Add($"this.AsClientId = {(this.AsClientId == null ? "null" : this.AsClientId.ToString())}");
            toStringOutput.Add($"this.ShipmentID = {(this.ShipmentID == null ? "null" : this.ShipmentID.ToString())}");
        }
    }
}