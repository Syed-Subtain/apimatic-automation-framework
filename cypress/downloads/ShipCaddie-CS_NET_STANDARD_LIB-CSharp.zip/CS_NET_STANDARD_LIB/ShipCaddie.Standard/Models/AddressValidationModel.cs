// <copyright file="AddressValidationModel.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace ShipCaddie.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using ShipCaddie.Standard;
    using ShipCaddie.Standard.Utilities;

    /// <summary>
    /// AddressValidationModel.
    /// </summary>
    public class AddressValidationModel
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="AddressValidationModel"/> class.
        /// </summary>
        public AddressValidationModel()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="AddressValidationModel"/> class.
        /// </summary>
        /// <param name="address1">address1.</param>
        /// <param name="address2">address2.</param>
        /// <param name="province">province.</param>
        /// <param name="provinceCode">provinceCode.</param>
        /// <param name="city">city.</param>
        /// <param name="countryCode">countryCode.</param>
        /// <param name="postalCode">postalCode.</param>
        /// <param name="countryname">countryname.</param>
        /// <param name="addressTypeId">addressTypeId.</param>
        /// <param name="companyName">companyName.</param>
        /// <param name="countryId">countryId.</param>
        /// <param name="addressStatus">addressStatus.</param>
        public AddressValidationModel(
            string address1 = null,
            string address2 = null,
            string province = null,
            string provinceCode = null,
            string city = null,
            string countryCode = null,
            string postalCode = null,
            string countryname = null,
            Models.AddressTypeIdEnum? addressTypeId = null,
            string companyName = null,
            int? countryId = null,
            bool? addressStatus = null)
        {
            this.Address1 = address1;
            this.Address2 = address2;
            this.Province = province;
            this.ProvinceCode = provinceCode;
            this.City = city;
            this.CountryCode = countryCode;
            this.PostalCode = postalCode;
            this.Countryname = countryname;
            this.AddressTypeId = addressTypeId;
            this.CompanyName = companyName;
            this.CountryId = countryId;
            this.AddressStatus = addressStatus;
        }

        /// <summary>
        /// Address Line 1 of the address
        /// </summary>
        [JsonProperty("address1", NullValueHandling = NullValueHandling.Ignore)]
        public string Address1 { get; set; }

        /// <summary>
        /// Address Line 2 of the address
        /// </summary>
        [JsonProperty("address2", NullValueHandling = NullValueHandling.Ignore)]
        public string Address2 { get; set; }

        /// <summary>
        /// Province for the address
        /// </summary>
        [JsonProperty("province", NullValueHandling = NullValueHandling.Ignore)]
        public string Province { get; set; }

        /// <summary>
        /// Code of the Province provided
        /// </summary>
        [JsonProperty("provinceCode", NullValueHandling = NullValueHandling.Ignore)]
        public string ProvinceCode { get; set; }

        /// <summary>
        /// City
        /// </summary>
        [JsonProperty("city", NullValueHandling = NullValueHandling.Ignore)]
        public string City { get; set; }

        /// <summary>
        /// The code of the country whose address is provided
        /// </summary>
        [JsonProperty("countryCode", NullValueHandling = NullValueHandling.Ignore)]
        public string CountryCode { get; set; }

        /// <summary>
        /// Postal code
        /// </summary>
        [JsonProperty("postalCode", NullValueHandling = NullValueHandling.Ignore)]
        public string PostalCode { get; set; }

        /// <summary>
        /// Name of the country
        /// </summary>
        [JsonProperty("countryname", NullValueHandling = NullValueHandling.Ignore)]
        public string Countryname { get; set; }

        /// <summary>
        /// Type of address
        /// Values :
        ///     - NotDefined
        ///     - Residential
        ///     - Commercial
        ///     - NotVerified
        ///     - Invalid
        /// </summary>
        [JsonProperty("addressTypeId", ItemConverterType = typeof(StringEnumConverter), NullValueHandling = NullValueHandling.Ignore)]
        public Models.AddressTypeIdEnum? AddressTypeId { get; set; }

        /// <summary>
        /// Name of the organization/company
        /// </summary>
        [JsonProperty("companyName", NullValueHandling = NullValueHandling.Ignore)]
        public string CompanyName { get; set; }

        /// <summary>
        /// Id of the country specified.
        /// </summary>
        [JsonProperty("countryId", NullValueHandling = NullValueHandling.Ignore)]
        public int? CountryId { get; set; }

        /// <summary>
        /// Status of the address
        /// </summary>
        [JsonProperty("addressStatus", NullValueHandling = NullValueHandling.Ignore)]
        public bool? AddressStatus { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"AddressValidationModel : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is AddressValidationModel other &&
                ((this.Address1 == null && other.Address1 == null) || (this.Address1?.Equals(other.Address1) == true)) &&
                ((this.Address2 == null && other.Address2 == null) || (this.Address2?.Equals(other.Address2) == true)) &&
                ((this.Province == null && other.Province == null) || (this.Province?.Equals(other.Province) == true)) &&
                ((this.ProvinceCode == null && other.ProvinceCode == null) || (this.ProvinceCode?.Equals(other.ProvinceCode) == true)) &&
                ((this.City == null && other.City == null) || (this.City?.Equals(other.City) == true)) &&
                ((this.CountryCode == null && other.CountryCode == null) || (this.CountryCode?.Equals(other.CountryCode) == true)) &&
                ((this.PostalCode == null && other.PostalCode == null) || (this.PostalCode?.Equals(other.PostalCode) == true)) &&
                ((this.Countryname == null && other.Countryname == null) || (this.Countryname?.Equals(other.Countryname) == true)) &&
                ((this.AddressTypeId == null && other.AddressTypeId == null) || (this.AddressTypeId?.Equals(other.AddressTypeId) == true)) &&
                ((this.CompanyName == null && other.CompanyName == null) || (this.CompanyName?.Equals(other.CompanyName) == true)) &&
                ((this.CountryId == null && other.CountryId == null) || (this.CountryId?.Equals(other.CountryId) == true)) &&
                ((this.AddressStatus == null && other.AddressStatus == null) || (this.AddressStatus?.Equals(other.AddressStatus) == true));
        }

        /// <inheritdoc/>
        public override int GetHashCode()
        {
            int hashCode = 776124504;

            if (this.Address1 != null)
            {
               hashCode += this.Address1.GetHashCode();
            }

            if (this.Address2 != null)
            {
               hashCode += this.Address2.GetHashCode();
            }

            if (this.Province != null)
            {
               hashCode += this.Province.GetHashCode();
            }

            if (this.ProvinceCode != null)
            {
               hashCode += this.ProvinceCode.GetHashCode();
            }

            if (this.City != null)
            {
               hashCode += this.City.GetHashCode();
            }

            if (this.CountryCode != null)
            {
               hashCode += this.CountryCode.GetHashCode();
            }

            if (this.PostalCode != null)
            {
               hashCode += this.PostalCode.GetHashCode();
            }

            if (this.Countryname != null)
            {
               hashCode += this.Countryname.GetHashCode();
            }

            if (this.AddressTypeId != null)
            {
               hashCode += this.AddressTypeId.GetHashCode();
            }

            if (this.CompanyName != null)
            {
               hashCode += this.CompanyName.GetHashCode();
            }

            if (this.CountryId != null)
            {
               hashCode += this.CountryId.GetHashCode();
            }

            if (this.AddressStatus != null)
            {
               hashCode += this.AddressStatus.GetHashCode();
            }

            return hashCode;
        }

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.Address1 = {(this.Address1 == null ? "null" : this.Address1 == string.Empty ? "" : this.Address1)}");
            toStringOutput.Add($"this.Address2 = {(this.Address2 == null ? "null" : this.Address2 == string.Empty ? "" : this.Address2)}");
            toStringOutput.Add($"this.Province = {(this.Province == null ? "null" : this.Province == string.Empty ? "" : this.Province)}");
            toStringOutput.Add($"this.ProvinceCode = {(this.ProvinceCode == null ? "null" : this.ProvinceCode == string.Empty ? "" : this.ProvinceCode)}");
            toStringOutput.Add($"this.City = {(this.City == null ? "null" : this.City == string.Empty ? "" : this.City)}");
            toStringOutput.Add($"this.CountryCode = {(this.CountryCode == null ? "null" : this.CountryCode == string.Empty ? "" : this.CountryCode)}");
            toStringOutput.Add($"this.PostalCode = {(this.PostalCode == null ? "null" : this.PostalCode == string.Empty ? "" : this.PostalCode)}");
            toStringOutput.Add($"this.Countryname = {(this.Countryname == null ? "null" : this.Countryname == string.Empty ? "" : this.Countryname)}");
            toStringOutput.Add($"this.AddressTypeId = {(this.AddressTypeId == null ? "null" : this.AddressTypeId.ToString())}");
            toStringOutput.Add($"this.CompanyName = {(this.CompanyName == null ? "null" : this.CompanyName == string.Empty ? "" : this.CompanyName)}");
            toStringOutput.Add($"this.CountryId = {(this.CountryId == null ? "null" : this.CountryId.ToString())}");
            toStringOutput.Add($"this.AddressStatus = {(this.AddressStatus == null ? "null" : this.AddressStatus.ToString())}");
        }
    }
}