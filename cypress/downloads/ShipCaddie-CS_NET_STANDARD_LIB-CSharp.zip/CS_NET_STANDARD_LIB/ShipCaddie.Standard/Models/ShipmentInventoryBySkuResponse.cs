// <copyright file="ShipmentInventoryBySkuResponse.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace ShipCaddie.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using ShipCaddie.Standard;
    using ShipCaddie.Standard.Utilities;

    /// <summary>
    /// ShipmentInventoryBySkuResponse.
    /// </summary>
    public class ShipmentInventoryBySkuResponse
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ShipmentInventoryBySkuResponse"/> class.
        /// </summary>
        public ShipmentInventoryBySkuResponse()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ShipmentInventoryBySkuResponse"/> class.
        /// </summary>
        /// <param name="sku">sku.</param>
        /// <param name="name">name.</param>
        /// <param name="qty">qty.</param>
        /// <param name="dateShipped">dateShipped.</param>
        /// <param name="orderReferenceNumber">orderReferenceNumber.</param>
        /// <param name="shipmentNumber">shipmentNumber.</param>
        public ShipmentInventoryBySkuResponse(
            string sku = null,
            string name = null,
            int? qty = null,
            DateTime? dateShipped = null,
            string orderReferenceNumber = null,
            string shipmentNumber = null)
        {
            this.Sku = sku;
            this.Name = name;
            this.Qty = qty;
            this.DateShipped = dateShipped;
            this.OrderReferenceNumber = orderReferenceNumber;
            this.ShipmentNumber = shipmentNumber;
        }

        /// <summary>
        /// Gets or sets Sku.
        /// </summary>
        [JsonProperty("sku", NullValueHandling = NullValueHandling.Ignore)]
        public string Sku { get; set; }

        /// <summary>
        /// Gets or sets Name.
        /// </summary>
        [JsonProperty("name", NullValueHandling = NullValueHandling.Ignore)]
        public string Name { get; set; }

        /// <summary>
        /// Gets or sets Qty.
        /// </summary>
        [JsonProperty("qty", NullValueHandling = NullValueHandling.Ignore)]
        public int? Qty { get; set; }

        /// <summary>
        /// Gets or sets DateShipped.
        /// </summary>
        [JsonConverter(typeof(IsoDateTimeConverter))]
        [JsonProperty("dateShipped", NullValueHandling = NullValueHandling.Ignore)]
        public DateTime? DateShipped { get; set; }

        /// <summary>
        /// Gets or sets OrderReferenceNumber.
        /// </summary>
        [JsonProperty("orderReferenceNumber", NullValueHandling = NullValueHandling.Ignore)]
        public string OrderReferenceNumber { get; set; }

        /// <summary>
        /// Gets or sets ShipmentNumber.
        /// </summary>
        [JsonProperty("shipmentNumber", NullValueHandling = NullValueHandling.Ignore)]
        public string ShipmentNumber { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"ShipmentInventoryBySkuResponse : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is ShipmentInventoryBySkuResponse other &&
                ((this.Sku == null && other.Sku == null) || (this.Sku?.Equals(other.Sku) == true)) &&
                ((this.Name == null && other.Name == null) || (this.Name?.Equals(other.Name) == true)) &&
                ((this.Qty == null && other.Qty == null) || (this.Qty?.Equals(other.Qty) == true)) &&
                ((this.DateShipped == null && other.DateShipped == null) || (this.DateShipped?.Equals(other.DateShipped) == true)) &&
                ((this.OrderReferenceNumber == null && other.OrderReferenceNumber == null) || (this.OrderReferenceNumber?.Equals(other.OrderReferenceNumber) == true)) &&
                ((this.ShipmentNumber == null && other.ShipmentNumber == null) || (this.ShipmentNumber?.Equals(other.ShipmentNumber) == true));
        }

        /// <inheritdoc/>
        public override int GetHashCode()
        {
            int hashCode = 2317270;

            if (this.Sku != null)
            {
               hashCode += this.Sku.GetHashCode();
            }

            if (this.Name != null)
            {
               hashCode += this.Name.GetHashCode();
            }

            if (this.Qty != null)
            {
               hashCode += this.Qty.GetHashCode();
            }

            if (this.DateShipped != null)
            {
               hashCode += this.DateShipped.GetHashCode();
            }

            if (this.OrderReferenceNumber != null)
            {
               hashCode += this.OrderReferenceNumber.GetHashCode();
            }

            if (this.ShipmentNumber != null)
            {
               hashCode += this.ShipmentNumber.GetHashCode();
            }

            return hashCode;
        }

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.Sku = {(this.Sku == null ? "null" : this.Sku == string.Empty ? "" : this.Sku)}");
            toStringOutput.Add($"this.Name = {(this.Name == null ? "null" : this.Name == string.Empty ? "" : this.Name)}");
            toStringOutput.Add($"this.Qty = {(this.Qty == null ? "null" : this.Qty.ToString())}");
            toStringOutput.Add($"this.DateShipped = {(this.DateShipped == null ? "null" : this.DateShipped.ToString())}");
            toStringOutput.Add($"this.OrderReferenceNumber = {(this.OrderReferenceNumber == null ? "null" : this.OrderReferenceNumber == string.Empty ? "" : this.OrderReferenceNumber)}");
            toStringOutput.Add($"this.ShipmentNumber = {(this.ShipmentNumber == null ? "null" : this.ShipmentNumber == string.Empty ? "" : this.ShipmentNumber)}");
        }
    }
}