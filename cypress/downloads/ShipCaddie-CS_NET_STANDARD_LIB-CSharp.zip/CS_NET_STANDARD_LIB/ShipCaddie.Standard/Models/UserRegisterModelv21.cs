// <copyright file="UserRegisterModelv21.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace ShipCaddie.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using ShipCaddie.Standard;
    using ShipCaddie.Standard.Utilities;

    /// <summary>
    /// UserRegisterModelv21.
    /// </summary>
    public class UserRegisterModelv21
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="UserRegisterModelv21"/> class.
        /// </summary>
        public UserRegisterModelv21()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="UserRegisterModelv21"/> class.
        /// </summary>
        /// <param name="systemCountryId">systemCountryId.</param>
        /// <param name="nameFirst">nameFirst.</param>
        /// <param name="nameLast">nameLast.</param>
        /// <param name="companyName">companyName.</param>
        /// <param name="phoneNumber">phoneNumber.</param>
        /// <param name="userName">userName.</param>
        /// <param name="password">password.</param>
        /// <param name="passwordVerify">passwordVerify.</param>
        /// <param name="promoCode">promoCode.</param>
        /// <param name="subscriptionTierId">subscriptionTierId.</param>
        /// <param name="iAgree">iAgree.</param>
        public UserRegisterModelv21(
            int? systemCountryId = null,
            string nameFirst = null,
            string nameLast = null,
            string companyName = null,
            string phoneNumber = null,
            string userName = null,
            string password = null,
            string passwordVerify = null,
            string promoCode = null,
            int? subscriptionTierId = null,
            string iAgree = null)
        {
            this.SystemCountryId = systemCountryId;
            this.NameFirst = nameFirst;
            this.NameLast = nameLast;
            this.CompanyName = companyName;
            this.PhoneNumber = phoneNumber;
            this.UserName = userName;
            this.Password = password;
            this.PasswordVerify = passwordVerify;
            this.PromoCode = promoCode;
            this.SubscriptionTierId = subscriptionTierId;
            this.IAgree = iAgree;
        }

        /// <summary>
        /// Country of Origin
        /// </summary>
        [JsonProperty("systemCountryId", NullValueHandling = NullValueHandling.Ignore)]
        public int? SystemCountryId { get; set; }

        /// <summary>
        /// Required.
        /// First Name
        /// Max Length: 25
        /// </summary>
        [JsonProperty("nameFirst", NullValueHandling = NullValueHandling.Ignore)]
        public string NameFirst { get; set; }

        /// <summary>
        /// Required.
        /// Last Name
        /// Max Length: 35
        /// </summary>
        [JsonProperty("nameLast", NullValueHandling = NullValueHandling.Ignore)]
        public string NameLast { get; set; }

        /// <summary>
        /// Company Name
        /// Max Length: 50
        /// </summary>
        [JsonProperty("companyName", NullValueHandling = NullValueHandling.Ignore)]
        public string CompanyName { get; set; }

        /// <summary>
        /// Phone Number
        /// </summary>
        [JsonProperty("phoneNumber", NullValueHandling = NullValueHandling.Ignore)]
        public string PhoneNumber { get; set; }

        /// <summary>
        /// Required.
        /// User name
        /// </summary>
        [JsonProperty("userName", NullValueHandling = NullValueHandling.Ignore)]
        public string UserName { get; set; }

        /// <summary>
        /// Required.
        /// Max Length: 100
        /// Min Length: 8
        /// Password
        /// </summary>
        [JsonProperty("password", NullValueHandling = NullValueHandling.Ignore)]
        public string Password { get; set; }

        /// <summary>
        /// Confirm password
        /// </summary>
        [JsonProperty("passwordVerify", NullValueHandling = NullValueHandling.Ignore)]
        public string PasswordVerify { get; set; }

        /// <summary>
        /// Promo Code
        /// </summary>
        [JsonProperty("promoCode", NullValueHandling = NullValueHandling.Ignore)]
        public string PromoCode { get; set; }

        /// <summary>
        /// Subscription Tier
        /// </summary>
        [JsonProperty("subscriptionTierId", NullValueHandling = NullValueHandling.Ignore)]
        public int? SubscriptionTierId { get; set; }

        /// <summary>
        /// Gets or sets IAgree.
        /// </summary>
        [JsonProperty("iAgree", NullValueHandling = NullValueHandling.Ignore)]
        public string IAgree { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"UserRegisterModelv21 : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is UserRegisterModelv21 other &&
                ((this.SystemCountryId == null && other.SystemCountryId == null) || (this.SystemCountryId?.Equals(other.SystemCountryId) == true)) &&
                ((this.NameFirst == null && other.NameFirst == null) || (this.NameFirst?.Equals(other.NameFirst) == true)) &&
                ((this.NameLast == null && other.NameLast == null) || (this.NameLast?.Equals(other.NameLast) == true)) &&
                ((this.CompanyName == null && other.CompanyName == null) || (this.CompanyName?.Equals(other.CompanyName) == true)) &&
                ((this.PhoneNumber == null && other.PhoneNumber == null) || (this.PhoneNumber?.Equals(other.PhoneNumber) == true)) &&
                ((this.UserName == null && other.UserName == null) || (this.UserName?.Equals(other.UserName) == true)) &&
                ((this.Password == null && other.Password == null) || (this.Password?.Equals(other.Password) == true)) &&
                ((this.PasswordVerify == null && other.PasswordVerify == null) || (this.PasswordVerify?.Equals(other.PasswordVerify) == true)) &&
                ((this.PromoCode == null && other.PromoCode == null) || (this.PromoCode?.Equals(other.PromoCode) == true)) &&
                ((this.SubscriptionTierId == null && other.SubscriptionTierId == null) || (this.SubscriptionTierId?.Equals(other.SubscriptionTierId) == true)) &&
                ((this.IAgree == null && other.IAgree == null) || (this.IAgree?.Equals(other.IAgree) == true));
        }

        /// <inheritdoc/>
        public override int GetHashCode()
        {
            int hashCode = -1985486721;

            if (this.SystemCountryId != null)
            {
               hashCode += this.SystemCountryId.GetHashCode();
            }

            if (this.NameFirst != null)
            {
               hashCode += this.NameFirst.GetHashCode();
            }

            if (this.NameLast != null)
            {
               hashCode += this.NameLast.GetHashCode();
            }

            if (this.CompanyName != null)
            {
               hashCode += this.CompanyName.GetHashCode();
            }

            if (this.PhoneNumber != null)
            {
               hashCode += this.PhoneNumber.GetHashCode();
            }

            if (this.UserName != null)
            {
               hashCode += this.UserName.GetHashCode();
            }

            if (this.Password != null)
            {
               hashCode += this.Password.GetHashCode();
            }

            if (this.PasswordVerify != null)
            {
               hashCode += this.PasswordVerify.GetHashCode();
            }

            if (this.PromoCode != null)
            {
               hashCode += this.PromoCode.GetHashCode();
            }

            if (this.SubscriptionTierId != null)
            {
               hashCode += this.SubscriptionTierId.GetHashCode();
            }

            if (this.IAgree != null)
            {
               hashCode += this.IAgree.GetHashCode();
            }

            return hashCode;
        }

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.SystemCountryId = {(this.SystemCountryId == null ? "null" : this.SystemCountryId.ToString())}");
            toStringOutput.Add($"this.NameFirst = {(this.NameFirst == null ? "null" : this.NameFirst == string.Empty ? "" : this.NameFirst)}");
            toStringOutput.Add($"this.NameLast = {(this.NameLast == null ? "null" : this.NameLast == string.Empty ? "" : this.NameLast)}");
            toStringOutput.Add($"this.CompanyName = {(this.CompanyName == null ? "null" : this.CompanyName == string.Empty ? "" : this.CompanyName)}");
            toStringOutput.Add($"this.PhoneNumber = {(this.PhoneNumber == null ? "null" : this.PhoneNumber == string.Empty ? "" : this.PhoneNumber)}");
            toStringOutput.Add($"this.UserName = {(this.UserName == null ? "null" : this.UserName == string.Empty ? "" : this.UserName)}");
            toStringOutput.Add($"this.Password = {(this.Password == null ? "null" : this.Password == string.Empty ? "" : this.Password)}");
            toStringOutput.Add($"this.PasswordVerify = {(this.PasswordVerify == null ? "null" : this.PasswordVerify == string.Empty ? "" : this.PasswordVerify)}");
            toStringOutput.Add($"this.PromoCode = {(this.PromoCode == null ? "null" : this.PromoCode == string.Empty ? "" : this.PromoCode)}");
            toStringOutput.Add($"this.SubscriptionTierId = {(this.SubscriptionTierId == null ? "null" : this.SubscriptionTierId.ToString())}");
            toStringOutput.Add($"this.IAgree = {(this.IAgree == null ? "null" : this.IAgree == string.Empty ? "" : this.IAgree)}");
        }
    }
}