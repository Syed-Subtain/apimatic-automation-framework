// <copyright file="ReturnEnum.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace ShipCaddie.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Runtime.Serialization;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using ShipCaddie.Standard;
    using ShipCaddie.Standard.Utilities;

    /// <summary>
    /// ReturnEnum.
    /// </summary>
    [JsonConverter(typeof(StringEnumConverter))]
    public enum ReturnEnum
    {
        /// <summary>
        /// NOTAPPLICABLE.
        /// </summary>
        [EnumMember(Value = "NOT_APPLICABLE")]
        NOTAPPLICABLE,

        /// <summary>
        /// RETURNLABEL.
        /// </summary>
        [EnumMember(Value = "RETURN_LABEL")]
        RETURNLABEL,

        /// <summary>
        /// RETURNLABELSHIP.
        /// </summary>
        [EnumMember(Value = "RETURN_LABEL_SHIP")]
        RETURNLABELSHIP,

        /// <summary>
        /// RETURNLABELONUSE.
        /// </summary>
        [EnumMember(Value = "RETURN_LABEL_ON_USE")]
        RETURNLABELONUSE,
    }
}