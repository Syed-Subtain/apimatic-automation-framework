// <copyright file="ShippedInfoCarrier.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace ShipCaddie.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using ShipCaddie.Standard;
    using ShipCaddie.Standard.Utilities;

    /// <summary>
    /// ShippedInfoCarrier.
    /// </summary>
    public class ShippedInfoCarrier
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ShippedInfoCarrier"/> class.
        /// </summary>
        public ShippedInfoCarrier()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ShippedInfoCarrier"/> class.
        /// </summary>
        /// <param name="carrierClientContractId">carrierClientContractId.</param>
        /// <param name="carrierName">carrierName.</param>
        /// <param name="carrierServiceLevelId">carrierServiceLevelId.</param>
        /// <param name="carrierServiceLevelName">carrierServiceLevelName.</param>
        public ShippedInfoCarrier(
            int? carrierClientContractId = null,
            string carrierName = null,
            int? carrierServiceLevelId = null,
            string carrierServiceLevelName = null)
        {
            this.CarrierClientContractId = carrierClientContractId;
            this.CarrierName = carrierName;
            this.CarrierServiceLevelId = carrierServiceLevelId;
            this.CarrierServiceLevelName = carrierServiceLevelName;
        }

        /// <summary>
        /// Indicates which Carrier was used.
        /// </summary>
        [JsonProperty("carrierClientContractId", NullValueHandling = NullValueHandling.Ignore)]
        public int? CarrierClientContractId { get; set; }

        /// <summary>
        /// The name of the carrier used for the shipment.
        /// </summary>
        [JsonProperty("carrierName", NullValueHandling = NullValueHandling.Ignore)]
        public string CarrierName { get; set; }

        /// <summary>
        /// Indicates which Carrier Service Level was used.
        /// </summary>
        [JsonProperty("carrierServiceLevelId", NullValueHandling = NullValueHandling.Ignore)]
        public int? CarrierServiceLevelId { get; set; }

        /// <summary>
        /// The name of the service level used.
        /// </summary>
        [JsonProperty("carrierServiceLevelName", NullValueHandling = NullValueHandling.Ignore)]
        public string CarrierServiceLevelName { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"ShippedInfoCarrier : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is ShippedInfoCarrier other &&
                ((this.CarrierClientContractId == null && other.CarrierClientContractId == null) || (this.CarrierClientContractId?.Equals(other.CarrierClientContractId) == true)) &&
                ((this.CarrierName == null && other.CarrierName == null) || (this.CarrierName?.Equals(other.CarrierName) == true)) &&
                ((this.CarrierServiceLevelId == null && other.CarrierServiceLevelId == null) || (this.CarrierServiceLevelId?.Equals(other.CarrierServiceLevelId) == true)) &&
                ((this.CarrierServiceLevelName == null && other.CarrierServiceLevelName == null) || (this.CarrierServiceLevelName?.Equals(other.CarrierServiceLevelName) == true));
        }

        /// <inheritdoc/>
        public override int GetHashCode()
        {
            int hashCode = -190056590;

            if (this.CarrierClientContractId != null)
            {
               hashCode += this.CarrierClientContractId.GetHashCode();
            }

            if (this.CarrierName != null)
            {
               hashCode += this.CarrierName.GetHashCode();
            }

            if (this.CarrierServiceLevelId != null)
            {
               hashCode += this.CarrierServiceLevelId.GetHashCode();
            }

            if (this.CarrierServiceLevelName != null)
            {
               hashCode += this.CarrierServiceLevelName.GetHashCode();
            }

            return hashCode;
        }

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.CarrierClientContractId = {(this.CarrierClientContractId == null ? "null" : this.CarrierClientContractId.ToString())}");
            toStringOutput.Add($"this.CarrierName = {(this.CarrierName == null ? "null" : this.CarrierName == string.Empty ? "" : this.CarrierName)}");
            toStringOutput.Add($"this.CarrierServiceLevelId = {(this.CarrierServiceLevelId == null ? "null" : this.CarrierServiceLevelId.ToString())}");
            toStringOutput.Add($"this.CarrierServiceLevelName = {(this.CarrierServiceLevelName == null ? "null" : this.CarrierServiceLevelName == string.Empty ? "" : this.CarrierServiceLevelName)}");
        }
    }
}