// <copyright file="ShipmentRequestByDate.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace ShipCaddie.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using ShipCaddie.Standard;
    using ShipCaddie.Standard.Utilities;

    /// <summary>
    /// ShipmentRequestByDate.
    /// </summary>
    public class ShipmentRequestByDate
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ShipmentRequestByDate"/> class.
        /// </summary>
        public ShipmentRequestByDate()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ShipmentRequestByDate"/> class.
        /// </summary>
        /// <param name="accessToken">accessToken.</param>
        /// <param name="asClientId">asClientId.</param>
        /// <param name="startDate">startDate.</param>
        /// <param name="endDate">endDate.</param>
        public ShipmentRequestByDate(
            string accessToken,
            int? asClientId = null,
            DateTime? startDate = null,
            DateTime? endDate = null)
        {
            this.AccessToken = accessToken;
            this.AsClientId = asClientId;
            this.StartDate = startDate;
            this.EndDate = endDate;
        }

        /// <summary>
        /// Required.
        /// An authorization token is necessary to call this method.
        /// <remarks>
        /// The token can be obtained by calling the GetToken or RefreshToken methods.
        /// </remarks>
        /// </summary>
        [JsonProperty("accessToken")]
        public string AccessToken { get; set; }

        /// <summary>
        /// Optional.
        /// When empty or null, this field is ignored.
        /// When set, actions will be taken for the client specified by the id.
        /// </summary>
        [JsonProperty("asClientId", NullValueHandling = NullValueHandling.Ignore)]
        public int? AsClientId { get; set; }

        /// <summary>
        /// StartDate.
        /// </summary>
        [JsonConverter(typeof(IsoDateTimeConverter))]
        [JsonProperty("startDate", NullValueHandling = NullValueHandling.Ignore)]
        public DateTime? StartDate { get; set; }

        /// <summary>
        /// EndDate.
        /// </summary>
        [JsonConverter(typeof(IsoDateTimeConverter))]
        [JsonProperty("endDate", NullValueHandling = NullValueHandling.Ignore)]
        public DateTime? EndDate { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"ShipmentRequestByDate : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is ShipmentRequestByDate other &&
                ((this.AccessToken == null && other.AccessToken == null) || (this.AccessToken?.Equals(other.AccessToken) == true)) &&
                ((this.AsClientId == null && other.AsClientId == null) || (this.AsClientId?.Equals(other.AsClientId) == true)) &&
                ((this.StartDate == null && other.StartDate == null) || (this.StartDate?.Equals(other.StartDate) == true)) &&
                ((this.EndDate == null && other.EndDate == null) || (this.EndDate?.Equals(other.EndDate) == true));
        }

        /// <inheritdoc/>
        public override int GetHashCode()
        {
            int hashCode = -41522929;

            if (this.AccessToken != null)
            {
               hashCode += this.AccessToken.GetHashCode();
            }

            if (this.AsClientId != null)
            {
               hashCode += this.AsClientId.GetHashCode();
            }

            if (this.StartDate != null)
            {
               hashCode += this.StartDate.GetHashCode();
            }

            if (this.EndDate != null)
            {
               hashCode += this.EndDate.GetHashCode();
            }

            return hashCode;
        }

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.AccessToken = {(this.AccessToken == null ? "null" : this.AccessToken == string.Empty ? "" : this.AccessToken)}");
            toStringOutput.Add($"this.AsClientId = {(this.AsClientId == null ? "null" : this.AsClientId.ToString())}");
            toStringOutput.Add($"this.StartDate = {(this.StartDate == null ? "null" : this.StartDate.ToString())}");
            toStringOutput.Add($"this.EndDate = {(this.EndDate == null ? "null" : this.EndDate.ToString())}");
        }
    }
}