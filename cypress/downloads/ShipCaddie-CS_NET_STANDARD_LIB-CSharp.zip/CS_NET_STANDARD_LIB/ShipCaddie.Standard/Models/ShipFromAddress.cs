// <copyright file="ShipFromAddress.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace ShipCaddie.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using ShipCaddie.Standard;
    using ShipCaddie.Standard.Utilities;

    /// <summary>
    /// ShipFromAddress.
    /// </summary>
    public class ShipFromAddress
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ShipFromAddress"/> class.
        /// </summary>
        public ShipFromAddress()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ShipFromAddress"/> class.
        /// </summary>
        /// <param name="companyName">companyName.</param>
        /// <param name="email">email.</param>
        /// <param name="phoneNumber">phoneNumber.</param>
        /// <param name="address1">address1.</param>
        /// <param name="address2">address2.</param>
        /// <param name="city">city.</param>
        /// <param name="stateOrProvince">stateOrProvince.</param>
        /// <param name="postalCode">postalCode.</param>
        /// <param name="countryCode">countryCode.</param>
        public ShipFromAddress(
            string companyName = null,
            string email = null,
            string phoneNumber = null,
            string address1 = null,
            string address2 = null,
            string city = null,
            string stateOrProvince = null,
            string postalCode = null,
            string countryCode = null)
        {
            this.CompanyName = companyName;
            this.Email = email;
            this.PhoneNumber = phoneNumber;
            this.Address1 = address1;
            this.Address2 = address2;
            this.City = city;
            this.StateOrProvince = stateOrProvince;
            this.PostalCode = postalCode;
            this.CountryCode = countryCode;
        }

        /// <summary>
        /// Optional Company Name.
        /// This field is required by some Carriers.
        /// </summary>
        [JsonProperty("companyName", NullValueHandling = NullValueHandling.Ignore)]
        public string CompanyName { get; set; }

        /// <summary>
        /// Optional Sender's email address.
        /// This field is required by some Carriers.
        /// </summary>
        [JsonProperty("email", NullValueHandling = NullValueHandling.Ignore)]
        public string Email { get; set; }

        /// <summary>
        /// Optional Sender's phone number.
        /// This field is required by some Carriers.
        /// </summary>
        [JsonProperty("phoneNumber", NullValueHandling = NullValueHandling.Ignore)]
        public string PhoneNumber { get; set; }

        /// <summary>
        /// Street Address of Sender.
        /// </summary>
        [JsonProperty("address1", NullValueHandling = NullValueHandling.Ignore)]
        public string Address1 { get; set; }

        /// <summary>
        /// Optional additional Street Address.
        /// </summary>
        [JsonProperty("address2", NullValueHandling = NullValueHandling.Ignore)]
        public string Address2 { get; set; }

        /// <summary>
        /// City
        /// </summary>
        [JsonProperty("city", NullValueHandling = NullValueHandling.Ignore)]
        public string City { get; set; }

        /// <summary>
        /// State
        /// </summary>
        [JsonProperty("stateOrProvince", NullValueHandling = NullValueHandling.Ignore)]
        public string StateOrProvince { get; set; }

        /// <summary>
        /// Zip Code
        /// </summary>
        [JsonProperty("postalCode", NullValueHandling = NullValueHandling.Ignore)]
        public string PostalCode { get; set; }

        /// <summary>
        /// Code which indicates to which
        /// country the parcels will be sent from.
        /// Obtained from GetContryCodes.
        /// </summary>
        [JsonProperty("countryCode", NullValueHandling = NullValueHandling.Ignore)]
        public string CountryCode { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"ShipFromAddress : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is ShipFromAddress other &&
                ((this.CompanyName == null && other.CompanyName == null) || (this.CompanyName?.Equals(other.CompanyName) == true)) &&
                ((this.Email == null && other.Email == null) || (this.Email?.Equals(other.Email) == true)) &&
                ((this.PhoneNumber == null && other.PhoneNumber == null) || (this.PhoneNumber?.Equals(other.PhoneNumber) == true)) &&
                ((this.Address1 == null && other.Address1 == null) || (this.Address1?.Equals(other.Address1) == true)) &&
                ((this.Address2 == null && other.Address2 == null) || (this.Address2?.Equals(other.Address2) == true)) &&
                ((this.City == null && other.City == null) || (this.City?.Equals(other.City) == true)) &&
                ((this.StateOrProvince == null && other.StateOrProvince == null) || (this.StateOrProvince?.Equals(other.StateOrProvince) == true)) &&
                ((this.PostalCode == null && other.PostalCode == null) || (this.PostalCode?.Equals(other.PostalCode) == true)) &&
                ((this.CountryCode == null && other.CountryCode == null) || (this.CountryCode?.Equals(other.CountryCode) == true));
        }

        /// <inheritdoc/>
        public override int GetHashCode()
        {
            int hashCode = 2129636397;

            if (this.CompanyName != null)
            {
               hashCode += this.CompanyName.GetHashCode();
            }

            if (this.Email != null)
            {
               hashCode += this.Email.GetHashCode();
            }

            if (this.PhoneNumber != null)
            {
               hashCode += this.PhoneNumber.GetHashCode();
            }

            if (this.Address1 != null)
            {
               hashCode += this.Address1.GetHashCode();
            }

            if (this.Address2 != null)
            {
               hashCode += this.Address2.GetHashCode();
            }

            if (this.City != null)
            {
               hashCode += this.City.GetHashCode();
            }

            if (this.StateOrProvince != null)
            {
               hashCode += this.StateOrProvince.GetHashCode();
            }

            if (this.PostalCode != null)
            {
               hashCode += this.PostalCode.GetHashCode();
            }

            if (this.CountryCode != null)
            {
               hashCode += this.CountryCode.GetHashCode();
            }

            return hashCode;
        }

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.CompanyName = {(this.CompanyName == null ? "null" : this.CompanyName == string.Empty ? "" : this.CompanyName)}");
            toStringOutput.Add($"this.Email = {(this.Email == null ? "null" : this.Email == string.Empty ? "" : this.Email)}");
            toStringOutput.Add($"this.PhoneNumber = {(this.PhoneNumber == null ? "null" : this.PhoneNumber == string.Empty ? "" : this.PhoneNumber)}");
            toStringOutput.Add($"this.Address1 = {(this.Address1 == null ? "null" : this.Address1 == string.Empty ? "" : this.Address1)}");
            toStringOutput.Add($"this.Address2 = {(this.Address2 == null ? "null" : this.Address2 == string.Empty ? "" : this.Address2)}");
            toStringOutput.Add($"this.City = {(this.City == null ? "null" : this.City == string.Empty ? "" : this.City)}");
            toStringOutput.Add($"this.StateOrProvince = {(this.StateOrProvince == null ? "null" : this.StateOrProvince == string.Empty ? "" : this.StateOrProvince)}");
            toStringOutput.Add($"this.PostalCode = {(this.PostalCode == null ? "null" : this.PostalCode == string.Empty ? "" : this.PostalCode)}");
            toStringOutput.Add($"this.CountryCode = {(this.CountryCode == null ? "null" : this.CountryCode == string.Empty ? "" : this.CountryCode)}");
        }
    }
}