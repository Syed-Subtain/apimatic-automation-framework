// <copyright file="PackagesV21.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace ShipCaddie.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using ShipCaddie.Standard;
    using ShipCaddie.Standard.Utilities;

    /// <summary>
    /// PackagesV21.
    /// </summary>
    public class PackagesV21
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="PackagesV21"/> class.
        /// </summary>
        public PackagesV21()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="PackagesV21"/> class.
        /// </summary>
        /// <param name="length">length.</param>
        /// <param name="width">width.</param>
        /// <param name="height">height.</param>
        public PackagesV21(
            double? length = null,
            double? width = null,
            double? height = null)
        {
            this.Length = length;
            this.Width = width;
            this.Height = height;
        }

        /// <summary>
        /// Required - Length
        /// </summary>
        [JsonProperty("length", NullValueHandling = NullValueHandling.Ignore)]
        public double? Length { get; set; }

        /// <summary>
        /// Required - Width
        /// </summary>
        [JsonProperty("width", NullValueHandling = NullValueHandling.Ignore)]
        public double? Width { get; set; }

        /// <summary>
        /// Required - Height
        /// </summary>
        [JsonProperty("height", NullValueHandling = NullValueHandling.Ignore)]
        public double? Height { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"PackagesV21 : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is PackagesV21 other &&
                ((this.Length == null && other.Length == null) || (this.Length?.Equals(other.Length) == true)) &&
                ((this.Width == null && other.Width == null) || (this.Width?.Equals(other.Width) == true)) &&
                ((this.Height == null && other.Height == null) || (this.Height?.Equals(other.Height) == true));
        }

        /// <inheritdoc/>
        public override int GetHashCode()
        {
            int hashCode = -878973232;

            if (this.Length != null)
            {
               hashCode += this.Length.GetHashCode();
            }

            if (this.Width != null)
            {
               hashCode += this.Width.GetHashCode();
            }

            if (this.Height != null)
            {
               hashCode += this.Height.GetHashCode();
            }

            return hashCode;
        }

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.Length = {(this.Length == null ? "null" : this.Length.ToString())}");
            toStringOutput.Add($"this.Width = {(this.Width == null ? "null" : this.Width.ToString())}");
            toStringOutput.Add($"this.Height = {(this.Height == null ? "null" : this.Height.ToString())}");
        }
    }
}