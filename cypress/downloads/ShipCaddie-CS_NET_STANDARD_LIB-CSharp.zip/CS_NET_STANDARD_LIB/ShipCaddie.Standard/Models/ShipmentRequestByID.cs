// <copyright file="ShipmentRequestByID.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace ShipCaddie.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using ShipCaddie.Standard;
    using ShipCaddie.Standard.Utilities;

    /// <summary>
    /// ShipmentRequestByID.
    /// </summary>
    public class ShipmentRequestByID
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ShipmentRequestByID"/> class.
        /// </summary>
        public ShipmentRequestByID()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ShipmentRequestByID"/> class.
        /// </summary>
        /// <param name="accessToken">accessToken.</param>
        /// <param name="asClientId">asClientId.</param>
        /// <param name="shipmentID">shipmentID.</param>
        public ShipmentRequestByID(
            string accessToken,
            int? asClientId = null,
            int? shipmentID = null)
        {
            this.AccessToken = accessToken;
            this.AsClientId = asClientId;
            this.ShipmentID = shipmentID;
        }

        /// <summary>
        /// Required.
        /// An authorization token is necessary to call this method.
        /// <remarks>
        /// The token can be obtained by calling the GetToken or RefreshToken methods.
        /// </remarks>
        /// </summary>
        [JsonProperty("accessToken")]
        public string AccessToken { get; set; }

        /// <summary>
        /// Optional.
        /// When empty or null, this field is ignored.
        /// When set, actions will be taken for the client specified by the id.
        /// </summary>
        [JsonProperty("asClientId", NullValueHandling = NullValueHandling.Ignore)]
        public int? AsClientId { get; set; }

        /// <summary>
        /// Id of an existing shipment.
        /// </summary>
        [JsonProperty("shipmentID", NullValueHandling = NullValueHandling.Ignore)]
        public int? ShipmentID { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"ShipmentRequestByID : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is ShipmentRequestByID other &&
                ((this.AccessToken == null && other.AccessToken == null) || (this.AccessToken?.Equals(other.AccessToken) == true)) &&
                ((this.AsClientId == null && other.AsClientId == null) || (this.AsClientId?.Equals(other.AsClientId) == true)) &&
                ((this.ShipmentID == null && other.ShipmentID == null) || (this.ShipmentID?.Equals(other.ShipmentID) == true));
        }

        /// <inheritdoc/>
        public override int GetHashCode()
        {
            int hashCode = 58258528;

            if (this.AccessToken != null)
            {
               hashCode += this.AccessToken.GetHashCode();
            }

            if (this.AsClientId != null)
            {
               hashCode += this.AsClientId.GetHashCode();
            }

            if (this.ShipmentID != null)
            {
               hashCode += this.ShipmentID.GetHashCode();
            }

            return hashCode;
        }

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.AccessToken = {(this.AccessToken == null ? "null" : this.AccessToken == string.Empty ? "" : this.AccessToken)}");
            toStringOutput.Add($"this.AsClientId = {(this.AsClientId == null ? "null" : this.AsClientId.ToString())}");
            toStringOutput.Add($"this.ShipmentID = {(this.ShipmentID == null ? "null" : this.ShipmentID.ToString())}");
        }
    }
}