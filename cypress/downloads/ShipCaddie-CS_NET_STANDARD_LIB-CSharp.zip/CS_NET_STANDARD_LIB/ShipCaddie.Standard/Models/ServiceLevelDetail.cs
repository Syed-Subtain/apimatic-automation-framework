// <copyright file="ServiceLevelDetail.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace ShipCaddie.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using ShipCaddie.Standard;
    using ShipCaddie.Standard.Utilities;

    /// <summary>
    /// ServiceLevelDetail.
    /// </summary>
    public class ServiceLevelDetail
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ServiceLevelDetail"/> class.
        /// </summary>
        public ServiceLevelDetail()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ServiceLevelDetail"/> class.
        /// </summary>
        /// <param name="carrierServiceLevelID">carrierServiceLevelID.</param>
        /// <param name="name">name.</param>
        /// <param name="parcelWeightLimit">parcelWeightLimit.</param>
        /// <param name="isInternational">isInternational.</param>
        public ServiceLevelDetail(
            int carrierServiceLevelID,
            string name,
            double parcelWeightLimit,
            bool isInternational)
        {
            this.CarrierServiceLevelID = carrierServiceLevelID;
            this.Name = name;
            this.ParcelWeightLimit = parcelWeightLimit;
            this.IsInternational = isInternational;
        }

        /// <summary>
        /// Service Level Identifier.
        /// This identifier is used in other methods such as Add Shipment.
        /// </summary>
        [JsonProperty("carrierServiceLevelID")]
        public int CarrierServiceLevelID { get; set; }

        /// <summary>
        /// Descriptive Service Name
        /// </summary>
        [JsonProperty("name")]
        public string Name { get; set; }

        /// <summary>
        /// Maximum weight of a parcel for this service level.
        /// Weight limit is in pounds - unless specified otherwise.
        /// </summary>
        [JsonProperty("parcelWeightLimit")]
        public double ParcelWeightLimit { get; set; }

        /// <summary>
        /// When true, the service is meant for parcels sent out of the country.
        /// </summary>
        [JsonProperty("isInternational")]
        public bool IsInternational { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"ServiceLevelDetail : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is ServiceLevelDetail other &&
                this.CarrierServiceLevelID.Equals(other.CarrierServiceLevelID) &&
                ((this.Name == null && other.Name == null) || (this.Name?.Equals(other.Name) == true)) &&
                this.ParcelWeightLimit.Equals(other.ParcelWeightLimit) &&
                this.IsInternational.Equals(other.IsInternational);
        }

        /// <inheritdoc/>
        public override int GetHashCode()
        {
            int hashCode = 1722221942;
            hashCode += this.CarrierServiceLevelID.GetHashCode();

            if (this.Name != null)
            {
               hashCode += this.Name.GetHashCode();
            }

            hashCode += this.ParcelWeightLimit.GetHashCode();
            hashCode += this.IsInternational.GetHashCode();

            return hashCode;
        }

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.CarrierServiceLevelID = {this.CarrierServiceLevelID}");
            toStringOutput.Add($"this.Name = {(this.Name == null ? "null" : this.Name == string.Empty ? "" : this.Name)}");
            toStringOutput.Add($"this.ParcelWeightLimit = {this.ParcelWeightLimit}");
            toStringOutput.Add($"this.IsInternational = {this.IsInternational}");
        }
    }
}