// <copyright file="AddressesModel.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace ShipCaddie.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using ShipCaddie.Standard;
    using ShipCaddie.Standard.Utilities;

    /// <summary>
    /// AddressesModel.
    /// </summary>
    public class AddressesModel
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="AddressesModel"/> class.
        /// </summary>
        public AddressesModel()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="AddressesModel"/> class.
        /// </summary>
        /// <param name="address1">address1.</param>
        /// <param name="address2">address2.</param>
        /// <param name="addressTypeId">addressTypeId.</param>
        /// <param name="city">city.</param>
        /// <param name="companyName">companyName.</param>
        /// <param name="countryCode">countryCode.</param>
        /// <param name="countryId">countryId.</param>
        /// <param name="countryname">countryname.</param>
        /// <param name="postalCode">postalCode.</param>
        /// <param name="province">province.</param>
        /// <param name="provinceCode">provinceCode.</param>
        /// <param name="rowKeyHash">rowKeyHash.</param>
        /// <param name="isSelected">isSelected.</param>
        public AddressesModel(
            string address1 = null,
            string address2 = null,
            Models.AddressTypeId1Enum? addressTypeId = null,
            string city = null,
            string companyName = null,
            string countryCode = null,
            int? countryId = null,
            string countryname = null,
            string postalCode = null,
            string province = null,
            string provinceCode = null,
            string rowKeyHash = null,
            bool? isSelected = null)
        {
            this.Address1 = address1;
            this.Address2 = address2;
            this.AddressTypeId = addressTypeId;
            this.City = city;
            this.CompanyName = companyName;
            this.CountryCode = countryCode;
            this.CountryId = countryId;
            this.Countryname = countryname;
            this.PostalCode = postalCode;
            this.Province = province;
            this.ProvinceCode = provinceCode;
            this.RowKeyHash = rowKeyHash;
            this.IsSelected = isSelected;
        }

        /// <summary>
        /// Address Line1 of the address
        /// </summary>
        [JsonProperty("address1", NullValueHandling = NullValueHandling.Ignore)]
        public string Address1 { get; set; }

        /// <summary>
        /// Address Line2 of the address
        /// </summary>
        [JsonProperty("address2", NullValueHandling = NullValueHandling.Ignore)]
        public string Address2 { get; set; }

        /// <summary>
        /// Id of the address type
        /// </summary>
        [JsonProperty("addressTypeId", ItemConverterType = typeof(StringEnumConverter), NullValueHandling = NullValueHandling.Ignore)]
        public Models.AddressTypeId1Enum? AddressTypeId { get; set; }

        /// <summary>
        /// City
        /// </summary>
        [JsonProperty("city", NullValueHandling = NullValueHandling.Ignore)]
        public string City { get; set; }

        /// <summary>
        /// Name of the Company / Organisation
        /// </summary>
        [JsonProperty("companyName", NullValueHandling = NullValueHandling.Ignore)]
        public string CompanyName { get; set; }

        /// <summary>
        /// Code of the country provided in address
        /// </summary>
        [JsonProperty("countryCode", NullValueHandling = NullValueHandling.Ignore)]
        public string CountryCode { get; set; }

        /// <summary>
        /// Id of the country specified.
        /// </summary>
        [JsonProperty("countryId", NullValueHandling = NullValueHandling.Ignore)]
        public int? CountryId { get; set; }

        /// <summary>
        /// Name of the country with which address relates
        /// </summary>
        [JsonProperty("countryname", NullValueHandling = NullValueHandling.Ignore)]
        public string Countryname { get; set; }

        /// <summary>
        /// Postal Code
        /// </summary>
        [JsonProperty("postalCode", NullValueHandling = NullValueHandling.Ignore)]
        public string PostalCode { get; set; }

        /// <summary>
        /// Province / State
        /// </summary>
        [JsonProperty("province", NullValueHandling = NullValueHandling.Ignore)]
        public string Province { get; set; }

        /// <summary>
        /// Code the Province
        /// </summary>
        [JsonProperty("provinceCode", NullValueHandling = NullValueHandling.Ignore)]
        public string ProvinceCode { get; set; }

        /// <summary>
        /// Row Key Hash
        /// </summary>
        [JsonProperty("rowKeyHash", NullValueHandling = NullValueHandling.Ignore)]
        public string RowKeyHash { get; set; }

        /// <summary>
        /// Is Selected
        /// </summary>
        [JsonProperty("isSelected", NullValueHandling = NullValueHandling.Ignore)]
        public bool? IsSelected { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"AddressesModel : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is AddressesModel other &&
                ((this.Address1 == null && other.Address1 == null) || (this.Address1?.Equals(other.Address1) == true)) &&
                ((this.Address2 == null && other.Address2 == null) || (this.Address2?.Equals(other.Address2) == true)) &&
                ((this.AddressTypeId == null && other.AddressTypeId == null) || (this.AddressTypeId?.Equals(other.AddressTypeId) == true)) &&
                ((this.City == null && other.City == null) || (this.City?.Equals(other.City) == true)) &&
                ((this.CompanyName == null && other.CompanyName == null) || (this.CompanyName?.Equals(other.CompanyName) == true)) &&
                ((this.CountryCode == null && other.CountryCode == null) || (this.CountryCode?.Equals(other.CountryCode) == true)) &&
                ((this.CountryId == null && other.CountryId == null) || (this.CountryId?.Equals(other.CountryId) == true)) &&
                ((this.Countryname == null && other.Countryname == null) || (this.Countryname?.Equals(other.Countryname) == true)) &&
                ((this.PostalCode == null && other.PostalCode == null) || (this.PostalCode?.Equals(other.PostalCode) == true)) &&
                ((this.Province == null && other.Province == null) || (this.Province?.Equals(other.Province) == true)) &&
                ((this.ProvinceCode == null && other.ProvinceCode == null) || (this.ProvinceCode?.Equals(other.ProvinceCode) == true)) &&
                ((this.RowKeyHash == null && other.RowKeyHash == null) || (this.RowKeyHash?.Equals(other.RowKeyHash) == true)) &&
                ((this.IsSelected == null && other.IsSelected == null) || (this.IsSelected?.Equals(other.IsSelected) == true));
        }

        /// <inheritdoc/>
        public override int GetHashCode()
        {
            int hashCode = 1918042037;

            if (this.Address1 != null)
            {
               hashCode += this.Address1.GetHashCode();
            }

            if (this.Address2 != null)
            {
               hashCode += this.Address2.GetHashCode();
            }

            if (this.AddressTypeId != null)
            {
               hashCode += this.AddressTypeId.GetHashCode();
            }

            if (this.City != null)
            {
               hashCode += this.City.GetHashCode();
            }

            if (this.CompanyName != null)
            {
               hashCode += this.CompanyName.GetHashCode();
            }

            if (this.CountryCode != null)
            {
               hashCode += this.CountryCode.GetHashCode();
            }

            if (this.CountryId != null)
            {
               hashCode += this.CountryId.GetHashCode();
            }

            if (this.Countryname != null)
            {
               hashCode += this.Countryname.GetHashCode();
            }

            if (this.PostalCode != null)
            {
               hashCode += this.PostalCode.GetHashCode();
            }

            if (this.Province != null)
            {
               hashCode += this.Province.GetHashCode();
            }

            if (this.ProvinceCode != null)
            {
               hashCode += this.ProvinceCode.GetHashCode();
            }

            if (this.RowKeyHash != null)
            {
               hashCode += this.RowKeyHash.GetHashCode();
            }

            if (this.IsSelected != null)
            {
               hashCode += this.IsSelected.GetHashCode();
            }

            return hashCode;
        }

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.Address1 = {(this.Address1 == null ? "null" : this.Address1 == string.Empty ? "" : this.Address1)}");
            toStringOutput.Add($"this.Address2 = {(this.Address2 == null ? "null" : this.Address2 == string.Empty ? "" : this.Address2)}");
            toStringOutput.Add($"this.AddressTypeId = {(this.AddressTypeId == null ? "null" : this.AddressTypeId.ToString())}");
            toStringOutput.Add($"this.City = {(this.City == null ? "null" : this.City == string.Empty ? "" : this.City)}");
            toStringOutput.Add($"this.CompanyName = {(this.CompanyName == null ? "null" : this.CompanyName == string.Empty ? "" : this.CompanyName)}");
            toStringOutput.Add($"this.CountryCode = {(this.CountryCode == null ? "null" : this.CountryCode == string.Empty ? "" : this.CountryCode)}");
            toStringOutput.Add($"this.CountryId = {(this.CountryId == null ? "null" : this.CountryId.ToString())}");
            toStringOutput.Add($"this.Countryname = {(this.Countryname == null ? "null" : this.Countryname == string.Empty ? "" : this.Countryname)}");
            toStringOutput.Add($"this.PostalCode = {(this.PostalCode == null ? "null" : this.PostalCode == string.Empty ? "" : this.PostalCode)}");
            toStringOutput.Add($"this.Province = {(this.Province == null ? "null" : this.Province == string.Empty ? "" : this.Province)}");
            toStringOutput.Add($"this.ProvinceCode = {(this.ProvinceCode == null ? "null" : this.ProvinceCode == string.Empty ? "" : this.ProvinceCode)}");
            toStringOutput.Add($"this.RowKeyHash = {(this.RowKeyHash == null ? "null" : this.RowKeyHash == string.Empty ? "" : this.RowKeyHash)}");
            toStringOutput.Add($"this.IsSelected = {(this.IsSelected == null ? "null" : this.IsSelected.ToString())}");
        }
    }
}