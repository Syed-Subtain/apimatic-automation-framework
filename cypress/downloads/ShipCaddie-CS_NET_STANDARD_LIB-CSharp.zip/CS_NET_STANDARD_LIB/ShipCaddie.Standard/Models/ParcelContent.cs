// <copyright file="ParcelContent.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace ShipCaddie.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using ShipCaddie.Standard;
    using ShipCaddie.Standard.Utilities;

    /// <summary>
    /// ParcelContent.
    /// </summary>
    public class ParcelContent
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ParcelContent"/> class.
        /// </summary>
        public ParcelContent()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ParcelContent"/> class.
        /// </summary>
        /// <param name="name">name.</param>
        /// <param name="quantity">quantity.</param>
        /// <param name="price">price.</param>
        /// <param name="weightInPounds">weightInPounds.</param>
        /// <param name="originCountry">originCountry.</param>
        /// <param name="sku">sku.</param>
        /// <param name="description">description.</param>
        /// <param name="harmonizeCode">harmonizeCode.</param>
        public ParcelContent(
            string name,
            int quantity,
            double price,
            double weightInPounds,
            string originCountry,
            string sku = null,
            string description = null,
            string harmonizeCode = null)
        {
            this.Sku = sku;
            this.Name = name;
            this.Description = description;
            this.Quantity = quantity;
            this.Price = price;
            this.WeightInPounds = weightInPounds;
            this.HarmonizeCode = harmonizeCode;
            this.OriginCountry = originCountry;
        }

        /// <summary>
        /// Product identifier.
        /// </summary>
        [JsonProperty("sku", NullValueHandling = NullValueHandling.Ignore)]
        public string Sku { get; set; }

        /// <summary>
        /// Descriptive item name.
        /// </summary>
        [JsonProperty("name")]
        public string Name { get; set; }

        /// <summary>
        /// Optional item description.
        /// </summary>
        [JsonProperty("description", NullValueHandling = NullValueHandling.Ignore)]
        public string Description { get; set; }

        /// <summary>
        /// Number of items.
        /// </summary>
        [JsonProperty("quantity")]
        public int Quantity { get; set; }

        /// <summary>
        /// Price of item.
        /// </summary>
        [JsonProperty("price")]
        public double Price { get; set; }

        /// <summary>
        /// Weight of the item.
        /// </summary>
        [JsonProperty("weightInPounds")]
        public double WeightInPounds { get; set; }

        /// <summary>
        /// Optional Harmonize code
        /// </summary>
        [JsonProperty("harmonizeCode", NullValueHandling = NullValueHandling.Ignore)]
        public string HarmonizeCode { get; set; }

        /// <summary>
        /// Country where product was made.
        /// </summary>
        [JsonProperty("originCountry")]
        public string OriginCountry { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"ParcelContent : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is ParcelContent other &&
                ((this.Sku == null && other.Sku == null) || (this.Sku?.Equals(other.Sku) == true)) &&
                ((this.Name == null && other.Name == null) || (this.Name?.Equals(other.Name) == true)) &&
                ((this.Description == null && other.Description == null) || (this.Description?.Equals(other.Description) == true)) &&
                this.Quantity.Equals(other.Quantity) &&
                this.Price.Equals(other.Price) &&
                this.WeightInPounds.Equals(other.WeightInPounds) &&
                ((this.HarmonizeCode == null && other.HarmonizeCode == null) || (this.HarmonizeCode?.Equals(other.HarmonizeCode) == true)) &&
                ((this.OriginCountry == null && other.OriginCountry == null) || (this.OriginCountry?.Equals(other.OriginCountry) == true));
        }

        /// <inheritdoc/>
        public override int GetHashCode()
        {
            int hashCode = 1933832226;

            if (this.Sku != null)
            {
               hashCode += this.Sku.GetHashCode();
            }

            if (this.Name != null)
            {
               hashCode += this.Name.GetHashCode();
            }

            if (this.Description != null)
            {
               hashCode += this.Description.GetHashCode();
            }

            hashCode += this.Quantity.GetHashCode();
            hashCode += this.Price.GetHashCode();
            hashCode += this.WeightInPounds.GetHashCode();

            if (this.HarmonizeCode != null)
            {
               hashCode += this.HarmonizeCode.GetHashCode();
            }

            if (this.OriginCountry != null)
            {
               hashCode += this.OriginCountry.GetHashCode();
            }

            return hashCode;
        }

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.Sku = {(this.Sku == null ? "null" : this.Sku == string.Empty ? "" : this.Sku)}");
            toStringOutput.Add($"this.Name = {(this.Name == null ? "null" : this.Name == string.Empty ? "" : this.Name)}");
            toStringOutput.Add($"this.Description = {(this.Description == null ? "null" : this.Description == string.Empty ? "" : this.Description)}");
            toStringOutput.Add($"this.Quantity = {this.Quantity}");
            toStringOutput.Add($"this.Price = {this.Price}");
            toStringOutput.Add($"this.WeightInPounds = {this.WeightInPounds}");
            toStringOutput.Add($"this.HarmonizeCode = {(this.HarmonizeCode == null ? "null" : this.HarmonizeCode == string.Empty ? "" : this.HarmonizeCode)}");
            toStringOutput.Add($"this.OriginCountry = {(this.OriginCountry == null ? "null" : this.OriginCountry == string.Empty ? "" : this.OriginCountry)}");
        }
    }
}