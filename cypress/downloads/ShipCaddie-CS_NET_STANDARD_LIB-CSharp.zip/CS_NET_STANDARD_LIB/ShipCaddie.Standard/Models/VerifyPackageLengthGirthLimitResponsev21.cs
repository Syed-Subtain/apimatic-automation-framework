// <copyright file="VerifyPackageLengthGirthLimitResponsev21.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace ShipCaddie.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using ShipCaddie.Standard;
    using ShipCaddie.Standard.Utilities;

    /// <summary>
    /// VerifyPackageLengthGirthLimitResponsev21.
    /// </summary>
    public class VerifyPackageLengthGirthLimitResponsev21
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="VerifyPackageLengthGirthLimitResponsev21"/> class.
        /// </summary>
        public VerifyPackageLengthGirthLimitResponsev21()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="VerifyPackageLengthGirthLimitResponsev21"/> class.
        /// </summary>
        /// <param name="error">error.</param>
        /// <param name="valid">valid.</param>
        public VerifyPackageLengthGirthLimitResponsev21(
            Models.RequestError error = null,
            bool? valid = null)
        {
            this.Error = error;
            this.Valid = valid;
        }

        /// <summary>
        /// This information can be used to determine if an error has occurred when a request was processed.
        /// </summary>
        [JsonProperty("error", NullValueHandling = NullValueHandling.Ignore)]
        public Models.RequestError Error { get; set; }

        /// <summary>
        /// Gets or sets Valid.
        /// </summary>
        [JsonProperty("valid", NullValueHandling = NullValueHandling.Ignore)]
        public bool? Valid { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"VerifyPackageLengthGirthLimitResponsev21 : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is VerifyPackageLengthGirthLimitResponsev21 other &&
                ((this.Error == null && other.Error == null) || (this.Error?.Equals(other.Error) == true)) &&
                ((this.Valid == null && other.Valid == null) || (this.Valid?.Equals(other.Valid) == true));
        }

        /// <inheritdoc/>
        public override int GetHashCode()
        {
            int hashCode = 1887607131;

            if (this.Error != null)
            {
               hashCode += this.Error.GetHashCode();
            }

            if (this.Valid != null)
            {
               hashCode += this.Valid.GetHashCode();
            }

            return hashCode;
        }

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.Error = {(this.Error == null ? "null" : this.Error.ToString())}");
            toStringOutput.Add($"this.Valid = {(this.Valid == null ? "null" : this.Valid.ToString())}");
        }
    }
}