// <copyright file="KeyValues.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace ShipCaddie.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using ShipCaddie.Standard;
    using ShipCaddie.Standard.Utilities;

    /// <summary>
    /// KeyValues.
    /// </summary>
    public class KeyValues
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="KeyValues"/> class.
        /// </summary>
        public KeyValues()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="KeyValues"/> class.
        /// </summary>
        /// <param name="labelKey">labelKey.</param>
        /// <param name="trackingNumber">trackingNumber.</param>
        /// <param name="packageId">packageId.</param>
        public KeyValues(
            string labelKey = null,
            string trackingNumber = null,
            int? packageId = null)
        {
            this.LabelKey = labelKey;
            this.TrackingNumber = trackingNumber;
            this.PackageId = packageId;
        }

        /// <summary>
        /// Gets or sets LabelKey.
        /// </summary>
        [JsonProperty("labelKey", NullValueHandling = NullValueHandling.Ignore)]
        public string LabelKey { get; set; }

        /// <summary>
        /// Gets or sets TrackingNumber.
        /// </summary>
        [JsonProperty("trackingNumber", NullValueHandling = NullValueHandling.Ignore)]
        public string TrackingNumber { get; set; }

        /// <summary>
        /// Gets or sets PackageId.
        /// </summary>
        [JsonProperty("packageId", NullValueHandling = NullValueHandling.Ignore)]
        public int? PackageId { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"KeyValues : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is KeyValues other &&
                ((this.LabelKey == null && other.LabelKey == null) || (this.LabelKey?.Equals(other.LabelKey) == true)) &&
                ((this.TrackingNumber == null && other.TrackingNumber == null) || (this.TrackingNumber?.Equals(other.TrackingNumber) == true)) &&
                ((this.PackageId == null && other.PackageId == null) || (this.PackageId?.Equals(other.PackageId) == true));
        }

        /// <inheritdoc/>
        public override int GetHashCode()
        {
            int hashCode = -1201690985;

            if (this.LabelKey != null)
            {
               hashCode += this.LabelKey.GetHashCode();
            }

            if (this.TrackingNumber != null)
            {
               hashCode += this.TrackingNumber.GetHashCode();
            }

            if (this.PackageId != null)
            {
               hashCode += this.PackageId.GetHashCode();
            }

            return hashCode;
        }

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.LabelKey = {(this.LabelKey == null ? "null" : this.LabelKey == string.Empty ? "" : this.LabelKey)}");
            toStringOutput.Add($"this.TrackingNumber = {(this.TrackingNumber == null ? "null" : this.TrackingNumber == string.Empty ? "" : this.TrackingNumber)}");
            toStringOutput.Add($"this.PackageId = {(this.PackageId == null ? "null" : this.PackageId.ToString())}");
        }
    }
}