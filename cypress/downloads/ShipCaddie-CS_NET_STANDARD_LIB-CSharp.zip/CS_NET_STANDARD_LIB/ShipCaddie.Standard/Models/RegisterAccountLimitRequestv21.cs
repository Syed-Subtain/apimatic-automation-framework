// <copyright file="RegisterAccountLimitRequestv21.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace ShipCaddie.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using ShipCaddie.Standard;
    using ShipCaddie.Standard.Utilities;

    /// <summary>
    /// RegisterAccountLimitRequestv21.
    /// </summary>
    public class RegisterAccountLimitRequestv21
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="RegisterAccountLimitRequestv21"/> class.
        /// </summary>
        public RegisterAccountLimitRequestv21()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="RegisterAccountLimitRequestv21"/> class.
        /// </summary>
        /// <param name="registrationInformation">registrationInformation.</param>
        public RegisterAccountLimitRequestv21(
            Models.UserRegisterModelv21 registrationInformation = null)
        {
            this.RegistrationInformation = registrationInformation;
        }

        /// <summary>
        /// Gets or sets RegistrationInformation.
        /// </summary>
        [JsonProperty("registrationInformation", NullValueHandling = NullValueHandling.Ignore)]
        public Models.UserRegisterModelv21 RegistrationInformation { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"RegisterAccountLimitRequestv21 : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is RegisterAccountLimitRequestv21 other &&
                ((this.RegistrationInformation == null && other.RegistrationInformation == null) || (this.RegistrationInformation?.Equals(other.RegistrationInformation) == true));
        }

        /// <inheritdoc/>
        public override int GetHashCode()
        {
            int hashCode = 1057088375;

            if (this.RegistrationInformation != null)
            {
               hashCode += this.RegistrationInformation.GetHashCode();
            }

            return hashCode;
        }

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.RegistrationInformation = {(this.RegistrationInformation == null ? "null" : this.RegistrationInformation.ToString())}");
        }
    }
}