// <copyright file="ParcelOptions.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace ShipCaddie.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using ShipCaddie.Standard;
    using ShipCaddie.Standard.Utilities;

    /// <summary>
    /// ParcelOptions.
    /// </summary>
    public class ParcelOptions
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ParcelOptions"/> class.
        /// </summary>
        public ParcelOptions()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ParcelOptions"/> class.
        /// </summary>
        /// <param name="mReturn">return.</param>
        /// <param name="insuranceAmount">insuranceAmount.</param>
        /// <param name="signature">signature.</param>
        /// <param name="cod">cod.</param>
        /// <param name="machinable">machinable.</param>
        /// <param name="holdForPickup">holdForPickup.</param>
        public ParcelOptions(
            Models.ReturnEnum? mReturn = null,
            double? insuranceAmount = null,
            Models.SignatureEnum? signature = null,
            Models.CODOptions cod = null,
            bool? machinable = null,
            bool? holdForPickup = null)
        {
            this.MReturn = mReturn;
            this.InsuranceAmount = insuranceAmount;
            this.Signature = signature;
            this.Cod = cod;
            this.Machinable = machinable;
            this.HoldForPickup = holdForPickup;
        }

        /// <summary>
        /// Indicates if this is a return parcel.
        /// and if so what type of return should be used.
        /// </summary>
        [JsonProperty("return", ItemConverterType = typeof(StringEnumConverter), NullValueHandling = NullValueHandling.Ignore)]
        public Models.ReturnEnum? MReturn { get; set; }

        /// <summary>
        /// Amount of insurance in US currency
        /// </summary>
        [JsonProperty("insuranceAmount", NullValueHandling = NullValueHandling.Ignore)]
        public double? InsuranceAmount { get; set; }

        /// <summary>
        /// Indicates if a signature is required,
        /// and if so what type of signature should be used.
        /// </summary>
        [JsonProperty("signature", ItemConverterType = typeof(StringEnumConverter), NullValueHandling = NullValueHandling.Ignore)]
        public Models.SignatureEnum? Signature { get; set; }

        /// <summary>
        /// Optional Cash on Demand
        /// </summary>
        [JsonProperty("cod", NullValueHandling = NullValueHandling.Ignore)]
        public Models.CODOptions Cod { get; set; }

        /// <summary>
        /// If True, package is machinable. (Default). If false, package is non-machinable.
        ///  Default null
        /// </summary>
        [JsonProperty("machinable", NullValueHandling = NullValueHandling.Ignore)]
        public bool? Machinable { get; set; }

        /// <summary>
        /// The Hold For Pickup service allows mailpieces to be held at a designated Post Office location for pickup by a specified addressee or designee
        ///  Default null
        /// </summary>
        [JsonProperty("holdForPickup", NullValueHandling = NullValueHandling.Ignore)]
        public bool? HoldForPickup { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"ParcelOptions : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is ParcelOptions other &&
                ((this.MReturn == null && other.MReturn == null) || (this.MReturn?.Equals(other.MReturn) == true)) &&
                ((this.InsuranceAmount == null && other.InsuranceAmount == null) || (this.InsuranceAmount?.Equals(other.InsuranceAmount) == true)) &&
                ((this.Signature == null && other.Signature == null) || (this.Signature?.Equals(other.Signature) == true)) &&
                ((this.Cod == null && other.Cod == null) || (this.Cod?.Equals(other.Cod) == true)) &&
                ((this.Machinable == null && other.Machinable == null) || (this.Machinable?.Equals(other.Machinable) == true)) &&
                ((this.HoldForPickup == null && other.HoldForPickup == null) || (this.HoldForPickup?.Equals(other.HoldForPickup) == true));
        }

        /// <inheritdoc/>
        public override int GetHashCode()
        {
            int hashCode = -1779698065;

            if (this.MReturn != null)
            {
               hashCode += this.MReturn.GetHashCode();
            }

            if (this.InsuranceAmount != null)
            {
               hashCode += this.InsuranceAmount.GetHashCode();
            }

            if (this.Signature != null)
            {
               hashCode += this.Signature.GetHashCode();
            }

            if (this.Cod != null)
            {
               hashCode += this.Cod.GetHashCode();
            }

            if (this.Machinable != null)
            {
               hashCode += this.Machinable.GetHashCode();
            }

            if (this.HoldForPickup != null)
            {
               hashCode += this.HoldForPickup.GetHashCode();
            }

            return hashCode;
        }

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.MReturn = {(this.MReturn == null ? "null" : this.MReturn.ToString())}");
            toStringOutput.Add($"this.InsuranceAmount = {(this.InsuranceAmount == null ? "null" : this.InsuranceAmount.ToString())}");
            toStringOutput.Add($"this.Signature = {(this.Signature == null ? "null" : this.Signature.ToString())}");
            toStringOutput.Add($"this.Cod = {(this.Cod == null ? "null" : this.Cod.ToString())}");
            toStringOutput.Add($"this.Machinable = {(this.Machinable == null ? "null" : this.Machinable.ToString())}");
            toStringOutput.Add($"this.HoldForPickup = {(this.HoldForPickup == null ? "null" : this.HoldForPickup.ToString())}");
        }
    }
}