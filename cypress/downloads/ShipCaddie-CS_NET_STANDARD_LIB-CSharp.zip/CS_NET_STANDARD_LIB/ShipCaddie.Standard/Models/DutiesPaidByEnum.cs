// <copyright file="DutiesPaidByEnum.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace ShipCaddie.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Runtime.Serialization;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using ShipCaddie.Standard;
    using ShipCaddie.Standard.Utilities;

    /// <summary>
    /// DutiesPaidByEnum.
    /// </summary>
    [JsonConverter(typeof(StringEnumConverter))]
    public enum DutiesPaidByEnum
    {
        /// <summary>
        /// NOTAPPLICABLE.
        /// </summary>
        [EnumMember(Value = "NOT_APPLICABLE")]
        NOTAPPLICABLE,

        /// <summary>
        /// PAIDBYSHIPPER.
        /// </summary>
        [EnumMember(Value = "PAID_BY_SHIPPER")]
        PAIDBYSHIPPER,

        /// <summary>
        /// PAIDBYRECIPIENT.
        /// </summary>
        [EnumMember(Value = "PAID_BY_RECIPIENT")]
        PAIDBYRECIPIENT,

        /// <summary>
        /// PAIDBYTHIRDPARTY.
        /// </summary>
        [EnumMember(Value = "PAID_BY_THIRD_PARTY")]
        PAIDBYTHIRDPARTY,
    }
}