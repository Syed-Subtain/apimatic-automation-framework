// <copyright file="GetShippingLabelsRequestv21.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace ShipCaddie.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using ShipCaddie.Standard;
    using ShipCaddie.Standard.Utilities;

    /// <summary>
    /// GetShippingLabelsRequestv21.
    /// </summary>
    public class GetShippingLabelsRequestv21
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="GetShippingLabelsRequestv21"/> class.
        /// </summary>
        public GetShippingLabelsRequestv21()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="GetShippingLabelsRequestv21"/> class.
        /// </summary>
        /// <param name="accessToken">accessToken.</param>
        /// <param name="printFormat">printFormat.</param>
        /// <param name="asClientId">asClientId.</param>
        /// <param name="shipment">shipment.</param>
        /// <param name="certifyTestOverride">certifyTestOverride.</param>
        /// <param name="imageRotation">imageRotation.</param>
        public GetShippingLabelsRequestv21(
            string accessToken,
            Models.PrintFormatEnum printFormat,
            int? asClientId = null,
            Models.ShipmentInformation shipment = null,
            Models.CertifyTestOverrideEnum? certifyTestOverride = null,
            Models.ImageRotationEnum? imageRotation = null)
        {
            this.AccessToken = accessToken;
            this.AsClientId = asClientId;
            this.PrintFormat = printFormat;
            this.Shipment = shipment;
            this.CertifyTestOverride = certifyTestOverride;
            this.ImageRotation = imageRotation;
        }

        /// <summary>
        /// Required.
        /// An authorization token is necessary to call this method.
        /// <remarks>
        /// The token can be obtained by calling the GetToken or RefreshToken methods.
        /// </remarks>
        /// </summary>
        [JsonProperty("accessToken")]
        public string AccessToken { get; set; }

        /// <summary>
        /// Optional.
        /// When empty or null, this field is ignored.
        /// When set, actions will be taken for the client specified by the id.
        /// </summary>
        [JsonProperty("asClientId", NullValueHandling = NullValueHandling.Ignore)]
        public int? AsClientId { get; set; }

        /// <summary>
        /// Format used for printing labels.
        /// </summary>
        [JsonProperty("printFormat", ItemConverterType = typeof(StringEnumConverter))]
        public Models.PrintFormatEnum PrintFormat { get; set; }

        /// <summary>
        /// All necessary shipping information
        /// </summary>
        [JsonProperty("shipment", NullValueHandling = NullValueHandling.Ignore)]
        public Models.ShipmentInformation Shipment { get; set; }

        /// <summary>
        /// CertifyTestOverride : Force a Label to overriding what is in the contract
        /// </summary>
        [JsonProperty("certifyTestOverride", ItemConverterType = typeof(StringEnumConverter), NullValueHandling = NullValueHandling.Ignore)]
        public Models.CertifyTestOverrideEnum? CertifyTestOverride { get; set; }

        /// <summary>
        /// Image Rotation Like 90,180,270
        /// </summary>
        [JsonProperty("imageRotation", ItemConverterType = typeof(StringEnumConverter), NullValueHandling = NullValueHandling.Ignore)]
        public Models.ImageRotationEnum? ImageRotation { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"GetShippingLabelsRequestv21 : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is GetShippingLabelsRequestv21 other &&
                ((this.AccessToken == null && other.AccessToken == null) || (this.AccessToken?.Equals(other.AccessToken) == true)) &&
                ((this.AsClientId == null && other.AsClientId == null) || (this.AsClientId?.Equals(other.AsClientId) == true)) &&
                this.PrintFormat.Equals(other.PrintFormat) &&
                ((this.Shipment == null && other.Shipment == null) || (this.Shipment?.Equals(other.Shipment) == true)) &&
                ((this.CertifyTestOverride == null && other.CertifyTestOverride == null) || (this.CertifyTestOverride?.Equals(other.CertifyTestOverride) == true)) &&
                ((this.ImageRotation == null && other.ImageRotation == null) || (this.ImageRotation?.Equals(other.ImageRotation) == true));
        }

        /// <inheritdoc/>
        public override int GetHashCode()
        {
            int hashCode = 1367681217;

            if (this.AccessToken != null)
            {
               hashCode += this.AccessToken.GetHashCode();
            }

            if (this.AsClientId != null)
            {
               hashCode += this.AsClientId.GetHashCode();
            }

            hashCode += this.PrintFormat.GetHashCode();

            if (this.Shipment != null)
            {
               hashCode += this.Shipment.GetHashCode();
            }

            if (this.CertifyTestOverride != null)
            {
               hashCode += this.CertifyTestOverride.GetHashCode();
            }

            if (this.ImageRotation != null)
            {
               hashCode += this.ImageRotation.GetHashCode();
            }

            return hashCode;
        }

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.AccessToken = {(this.AccessToken == null ? "null" : this.AccessToken == string.Empty ? "" : this.AccessToken)}");
            toStringOutput.Add($"this.AsClientId = {(this.AsClientId == null ? "null" : this.AsClientId.ToString())}");
            toStringOutput.Add($"this.PrintFormat = {this.PrintFormat}");
            toStringOutput.Add($"this.Shipment = {(this.Shipment == null ? "null" : this.Shipment.ToString())}");
            toStringOutput.Add($"this.CertifyTestOverride = {(this.CertifyTestOverride == null ? "null" : this.CertifyTestOverride.ToString())}");
            toStringOutput.Add($"this.ImageRotation = {(this.ImageRotation == null ? "null" : this.ImageRotation.ToString())}");
        }
    }
}