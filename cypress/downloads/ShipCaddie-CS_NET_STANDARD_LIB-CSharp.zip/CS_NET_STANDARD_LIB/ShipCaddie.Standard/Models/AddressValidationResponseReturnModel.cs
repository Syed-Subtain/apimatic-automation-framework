// <copyright file="AddressValidationResponseReturnModel.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace ShipCaddie.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using ShipCaddie.Standard;
    using ShipCaddie.Standard.Utilities;

    /// <summary>
    /// AddressValidationResponseReturnModel.
    /// </summary>
    public class AddressValidationResponseReturnModel
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="AddressValidationResponseReturnModel"/> class.
        /// </summary>
        public AddressValidationResponseReturnModel()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="AddressValidationResponseReturnModel"/> class.
        /// </summary>
        /// <param name="data">data.</param>
        /// <param name="success">success.</param>
        /// <param name="error">error.</param>
        /// <param name="v2Error">v2Error.</param>
        public AddressValidationResponseReturnModel(
            Models.AddressValidatationResponseModel data = null,
            bool? success = null,
            Models.ApiErrorModel error = null,
            Models.RequestError v2Error = null)
        {
            this.Data = data;
            this.Success = success;
            this.Error = error;
            this.V2Error = v2Error;
        }

        /// <summary>
        /// Address Validation Response Model
        /// </summary>
        [JsonProperty("data", NullValueHandling = NullValueHandling.Ignore)]
        public Models.AddressValidatationResponseModel Data { get; set; }

        /// <summary>
        /// Flag to indicate success or failure
        /// </summary>
        [JsonProperty("success", NullValueHandling = NullValueHandling.Ignore)]
        public bool? Success { get; set; }

        /// <summary>
        /// The error model that is used throughout all the api's
        /// </summary>
        [JsonProperty("error", NullValueHandling = NullValueHandling.Ignore)]
        public Models.ApiErrorModel Error { get; set; }

        /// <summary>
        /// This information can be used to determine if an error has occurred when a request was processed.
        /// </summary>
        [JsonProperty("v2Error", NullValueHandling = NullValueHandling.Ignore)]
        public Models.RequestError V2Error { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"AddressValidationResponseReturnModel : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is AddressValidationResponseReturnModel other &&
                ((this.Data == null && other.Data == null) || (this.Data?.Equals(other.Data) == true)) &&
                ((this.Success == null && other.Success == null) || (this.Success?.Equals(other.Success) == true)) &&
                ((this.Error == null && other.Error == null) || (this.Error?.Equals(other.Error) == true)) &&
                ((this.V2Error == null && other.V2Error == null) || (this.V2Error?.Equals(other.V2Error) == true));
        }

        /// <inheritdoc/>
        public override int GetHashCode()
        {
            int hashCode = 1176267763;

            if (this.Data != null)
            {
               hashCode += this.Data.GetHashCode();
            }

            if (this.Success != null)
            {
               hashCode += this.Success.GetHashCode();
            }

            if (this.Error != null)
            {
               hashCode += this.Error.GetHashCode();
            }

            if (this.V2Error != null)
            {
               hashCode += this.V2Error.GetHashCode();
            }

            return hashCode;
        }

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.Data = {(this.Data == null ? "null" : this.Data.ToString())}");
            toStringOutput.Add($"this.Success = {(this.Success == null ? "null" : this.Success.ToString())}");
            toStringOutput.Add($"this.Error = {(this.Error == null ? "null" : this.Error.ToString())}");
            toStringOutput.Add($"this.V2Error = {(this.V2Error == null ? "null" : this.V2Error.ToString())}");
        }
    }
}