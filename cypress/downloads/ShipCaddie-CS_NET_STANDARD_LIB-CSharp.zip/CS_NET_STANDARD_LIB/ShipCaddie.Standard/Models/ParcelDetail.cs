// <copyright file="ParcelDetail.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace ShipCaddie.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using ShipCaddie.Standard;
    using ShipCaddie.Standard.Utilities;

    /// <summary>
    /// ParcelDetail.
    /// </summary>
    public class ParcelDetail
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ParcelDetail"/> class.
        /// </summary>
        public ParcelDetail()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ParcelDetail"/> class.
        /// </summary>
        /// <param name="weightInPounds">weightInPounds.</param>
        /// <param name="lengthInInches">lengthInInches.</param>
        /// <param name="widthInInches">widthInInches.</param>
        /// <param name="heightInInches">heightInInches.</param>
        /// <param name="options">options.</param>
        /// <param name="referenceField1">referenceField1.</param>
        /// <param name="referenceField2">referenceField2.</param>
        /// <param name="referenceField3">referenceField3.</param>
        /// <param name="parcelID">parcelID.</param>
        /// <param name="packagingId">packagingId.</param>
        /// <param name="parcelItems">parcelItems.</param>
        public ParcelDetail(
            double weightInPounds,
            double lengthInInches,
            double widthInInches,
            double heightInInches,
            Models.ParcelOptions options,
            string referenceField1 = null,
            string referenceField2 = null,
            string referenceField3 = null,
            string parcelID = null,
            string packagingId = null,
            List<Models.ParcelContent> parcelItems = null)
        {
            this.ReferenceField1 = referenceField1;
            this.ReferenceField2 = referenceField2;
            this.ReferenceField3 = referenceField3;
            this.ParcelID = parcelID;
            this.PackagingId = packagingId;
            this.WeightInPounds = weightInPounds;
            this.LengthInInches = lengthInInches;
            this.WidthInInches = widthInInches;
            this.HeightInInches = heightInInches;
            this.Options = options;
            this.ParcelItems = parcelItems;
        }

        /// <summary>
        /// Optional - Reference Field 1
        /// </summary>
        [JsonProperty("referenceField1", NullValueHandling = NullValueHandling.Ignore)]
        public string ReferenceField1 { get; set; }

        /// <summary>
        /// Optional - Reference Field 2
        /// </summary>
        [JsonProperty("referenceField2", NullValueHandling = NullValueHandling.Ignore)]
        public string ReferenceField2 { get; set; }

        /// <summary>
        /// Optional - Reference Field 3
        /// </summary>
        [JsonProperty("referenceField3", NullValueHandling = NullValueHandling.Ignore)]
        public string ReferenceField3 { get; set; }

        /// <summary>
        /// A unique ID used to match
        /// parcels with cost details.
        /// This will be set automatically
        /// if a value is not supplied.
        /// </summary>
        [JsonProperty("parcelID", NullValueHandling = NullValueHandling.Ignore)]
        public string ParcelID { get; set; }

        /// <summary>
        /// Gets or sets PackagingId.
        /// </summary>
        [JsonProperty("packagingId", NullValueHandling = NullValueHandling.Ignore)]
        public string PackagingId { get; set; }

        /// <summary>
        /// Parcel Weight in Pounds.
        /// If the weight is a fraction of a pound
        /// still use pounds - not ounces.
        /// </summary>
        [JsonProperty("weightInPounds")]
        public double WeightInPounds { get; set; }

        /// <summary>
        /// Length of one side of parcel in inches.
        /// </summary>
        [JsonProperty("lengthInInches")]
        public double LengthInInches { get; set; }

        /// <summary>
        /// Width of one side of parcel in inches.
        /// </summary>
        [JsonProperty("widthInInches")]
        public double WidthInInches { get; set; }

        /// <summary>
        /// Height of one side of parcel in inches.
        /// </summary>
        [JsonProperty("heightInInches")]
        public double HeightInInches { get; set; }

        /// <summary>
        /// Specifies additional parcel options such as COD and required Signatures.
        /// </summary>
        [JsonProperty("options")]
        public Models.ParcelOptions Options { get; set; }

        /// <summary>
        /// Type of parcel contents.
        /// This is required for some destinations.
        /// </summary>
        [JsonProperty("parcelItems", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.ParcelContent> ParcelItems { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"ParcelDetail : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is ParcelDetail other &&
                ((this.ReferenceField1 == null && other.ReferenceField1 == null) || (this.ReferenceField1?.Equals(other.ReferenceField1) == true)) &&
                ((this.ReferenceField2 == null && other.ReferenceField2 == null) || (this.ReferenceField2?.Equals(other.ReferenceField2) == true)) &&
                ((this.ReferenceField3 == null && other.ReferenceField3 == null) || (this.ReferenceField3?.Equals(other.ReferenceField3) == true)) &&
                ((this.ParcelID == null && other.ParcelID == null) || (this.ParcelID?.Equals(other.ParcelID) == true)) &&
                ((this.PackagingId == null && other.PackagingId == null) || (this.PackagingId?.Equals(other.PackagingId) == true)) &&
                this.WeightInPounds.Equals(other.WeightInPounds) &&
                this.LengthInInches.Equals(other.LengthInInches) &&
                this.WidthInInches.Equals(other.WidthInInches) &&
                this.HeightInInches.Equals(other.HeightInInches) &&
                ((this.Options == null && other.Options == null) || (this.Options?.Equals(other.Options) == true)) &&
                ((this.ParcelItems == null && other.ParcelItems == null) || (this.ParcelItems?.Equals(other.ParcelItems) == true));
        }

        /// <inheritdoc/>
        public override int GetHashCode()
        {
            int hashCode = -2113742052;

            if (this.ReferenceField1 != null)
            {
               hashCode += this.ReferenceField1.GetHashCode();
            }

            if (this.ReferenceField2 != null)
            {
               hashCode += this.ReferenceField2.GetHashCode();
            }

            if (this.ReferenceField3 != null)
            {
               hashCode += this.ReferenceField3.GetHashCode();
            }

            if (this.ParcelID != null)
            {
               hashCode += this.ParcelID.GetHashCode();
            }

            if (this.PackagingId != null)
            {
               hashCode += this.PackagingId.GetHashCode();
            }

            hashCode += this.WeightInPounds.GetHashCode();
            hashCode += this.LengthInInches.GetHashCode();
            hashCode += this.WidthInInches.GetHashCode();
            hashCode += this.HeightInInches.GetHashCode();

            if (this.Options != null)
            {
               hashCode += this.Options.GetHashCode();
            }

            if (this.ParcelItems != null)
            {
               hashCode += this.ParcelItems.GetHashCode();
            }

            return hashCode;
        }

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.ReferenceField1 = {(this.ReferenceField1 == null ? "null" : this.ReferenceField1 == string.Empty ? "" : this.ReferenceField1)}");
            toStringOutput.Add($"this.ReferenceField2 = {(this.ReferenceField2 == null ? "null" : this.ReferenceField2 == string.Empty ? "" : this.ReferenceField2)}");
            toStringOutput.Add($"this.ReferenceField3 = {(this.ReferenceField3 == null ? "null" : this.ReferenceField3 == string.Empty ? "" : this.ReferenceField3)}");
            toStringOutput.Add($"this.ParcelID = {(this.ParcelID == null ? "null" : this.ParcelID == string.Empty ? "" : this.ParcelID)}");
            toStringOutput.Add($"this.PackagingId = {(this.PackagingId == null ? "null" : this.PackagingId == string.Empty ? "" : this.PackagingId)}");
            toStringOutput.Add($"this.WeightInPounds = {this.WeightInPounds}");
            toStringOutput.Add($"this.LengthInInches = {this.LengthInInches}");
            toStringOutput.Add($"this.WidthInInches = {this.WidthInInches}");
            toStringOutput.Add($"this.HeightInInches = {this.HeightInInches}");
            toStringOutput.Add($"this.Options = {(this.Options == null ? "null" : this.Options.ToString())}");
            toStringOutput.Add($"this.ParcelItems = {(this.ParcelItems == null ? "null" : $"[{string.Join(", ", this.ParcelItems)} ]")}");
        }
    }
}