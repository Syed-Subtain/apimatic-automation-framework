// <copyright file="SecurityTokenRequest.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace ShipCaddie.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using ShipCaddie.Standard;
    using ShipCaddie.Standard.Utilities;

    /// <summary>
    /// SecurityTokenRequest.
    /// </summary>
    public class SecurityTokenRequest
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="SecurityTokenRequest"/> class.
        /// </summary>
        public SecurityTokenRequest()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="SecurityTokenRequest"/> class.
        /// </summary>
        /// <param name="refreshToken">refreshToken.</param>
        public SecurityTokenRequest(
            string refreshToken)
        {
            this.RefreshToken = refreshToken;
        }

        /// <summary>
        /// Required.
        /// Use the Refresh Token to obtain a new security token after the Access Token has expired.
        /// </summary>
        [JsonProperty("refreshToken")]
        public string RefreshToken { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"SecurityTokenRequest : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is SecurityTokenRequest other &&
                ((this.RefreshToken == null && other.RefreshToken == null) || (this.RefreshToken?.Equals(other.RefreshToken) == true));
        }

        /// <inheritdoc/>
        public override int GetHashCode()
        {
            int hashCode = -629688751;

            if (this.RefreshToken != null)
            {
               hashCode += this.RefreshToken.GetHashCode();
            }

            return hashCode;
        }

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.RefreshToken = {(this.RefreshToken == null ? "null" : this.RefreshToken == string.Empty ? "" : this.RefreshToken)}");
        }
    }
}