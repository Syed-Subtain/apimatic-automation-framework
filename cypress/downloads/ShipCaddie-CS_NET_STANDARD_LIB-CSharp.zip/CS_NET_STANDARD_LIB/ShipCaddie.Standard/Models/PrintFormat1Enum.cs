// <copyright file="PrintFormat1Enum.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace ShipCaddie.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Runtime.Serialization;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using ShipCaddie.Standard;
    using ShipCaddie.Standard.Utilities;

    /// <summary>
    /// PrintFormat1Enum.
    /// </summary>
    [JsonConverter(typeof(StringEnumConverter))]
    public enum PrintFormat1Enum
    {
        /// <summary>
        /// ZPL4x6.
        /// </summary>
        [EnumMember(Value = "ZPL_4x6")]
        ZPL4x6,

        /// <summary>
        /// PNG4x6.
        /// </summary>
        [EnumMember(Value = "PNG_4x6")]
        PNG4x6,

        /// <summary>
        /// EPLII4x6.
        /// </summary>
        [EnumMember(Value = "EPLII_4x6")]
        EPLII4x6,

        /// <summary>
        /// PDF4x6.
        /// </summary>
        [EnumMember(Value = "PDF_4x6")]
        PDF4x6,

        /// <summary>
        /// ZPL4x5.
        /// </summary>
        [EnumMember(Value = "ZPL_4x5")]
        ZPL4x5,

        /// <summary>
        /// PNG4x5.
        /// </summary>
        [EnumMember(Value = "PNG_4x5")]
        PNG4x5,

        /// <summary>
        /// EPLII4x5.
        /// </summary>
        [EnumMember(Value = "EPLII_4x5")]
        EPLII4x5,

        /// <summary>
        /// PDF4x5.
        /// </summary>
        [EnumMember(Value = "PDF_4x5")]
        PDF4x5,

        /// <summary>
        /// PNG6x4.
        /// </summary>
        [EnumMember(Value = "PNG_6x4")]
        PNG6x4,

        /// <summary>
        /// PDF6x4.
        /// </summary>
        [EnumMember(Value = "PDF_6x4")]
        PDF6x4,

        /// <summary>
        /// ZPL6x4.
        /// </summary>
        [EnumMember(Value = "ZPL_6x4")]
        ZPL6x4,

        /// <summary>
        /// EPLII6x4.
        /// </summary>
        [EnumMember(Value = "EPLII_6x4")]
        EPLII6x4,

        /// <summary>
        /// ZPLDocTab.
        /// </summary>
        [EnumMember(Value = "ZPL_DocTab")]
        ZPLDocTab,

        /// <summary>
        /// PNG7x3.
        /// </summary>
        [EnumMember(Value = "PNG_7x3")]
        PNG7x3,

        /// <summary>
        /// PDF7x3.
        /// </summary>
        [EnumMember(Value = "PDF_7x3")]
        PDF7x3,
    }
}