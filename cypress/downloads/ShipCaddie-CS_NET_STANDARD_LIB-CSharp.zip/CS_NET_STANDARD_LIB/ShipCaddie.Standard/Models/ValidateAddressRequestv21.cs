// <copyright file="ValidateAddressRequestv21.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace ShipCaddie.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using ShipCaddie.Standard;
    using ShipCaddie.Standard.Utilities;

    /// <summary>
    /// ValidateAddressRequestv21.
    /// </summary>
    public class ValidateAddressRequestv21
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ValidateAddressRequestv21"/> class.
        /// </summary>
        public ValidateAddressRequestv21()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ValidateAddressRequestv21"/> class.
        /// </summary>
        /// <param name="accessToken">accessToken.</param>
        /// <param name="addressToValidate">addressToValidate.</param>
        /// <param name="asClientId">asClientId.</param>
        public ValidateAddressRequestv21(
            string accessToken,
            Models.Addressv21 addressToValidate,
            int? asClientId = null)
        {
            this.AccessToken = accessToken;
            this.AsClientId = asClientId;
            this.AddressToValidate = addressToValidate;
        }

        /// <summary>
        /// Required.
        /// An authorization token is necessary to call this method.
        /// <remarks>
        /// The token can be obtained by calling the GetToken or RefreshToken methods.
        /// </remarks>
        /// </summary>
        [JsonProperty("accessToken")]
        public string AccessToken { get; set; }

        /// <summary>
        /// Optional.
        /// When empty or null, this field is ignored.
        /// When set, actions will be taken for the client specified by the id.
        /// </summary>
        [JsonProperty("asClientId", NullValueHandling = NullValueHandling.Ignore)]
        public int? AsClientId { get; set; }

        /// <summary>
        /// Gets or sets AddressToValidate.
        /// </summary>
        [JsonProperty("addressToValidate")]
        public Models.Addressv21 AddressToValidate { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"ValidateAddressRequestv21 : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is ValidateAddressRequestv21 other &&
                ((this.AccessToken == null && other.AccessToken == null) || (this.AccessToken?.Equals(other.AccessToken) == true)) &&
                ((this.AsClientId == null && other.AsClientId == null) || (this.AsClientId?.Equals(other.AsClientId) == true)) &&
                ((this.AddressToValidate == null && other.AddressToValidate == null) || (this.AddressToValidate?.Equals(other.AddressToValidate) == true));
        }

        /// <inheritdoc/>
        public override int GetHashCode()
        {
            int hashCode = -154906801;

            if (this.AccessToken != null)
            {
               hashCode += this.AccessToken.GetHashCode();
            }

            if (this.AsClientId != null)
            {
               hashCode += this.AsClientId.GetHashCode();
            }

            if (this.AddressToValidate != null)
            {
               hashCode += this.AddressToValidate.GetHashCode();
            }

            return hashCode;
        }

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.AccessToken = {(this.AccessToken == null ? "null" : this.AccessToken == string.Empty ? "" : this.AccessToken)}");
            toStringOutput.Add($"this.AsClientId = {(this.AsClientId == null ? "null" : this.AsClientId.ToString())}");
            toStringOutput.Add($"this.AddressToValidate = {(this.AddressToValidate == null ? "null" : this.AddressToValidate.ToString())}");
        }
    }
}