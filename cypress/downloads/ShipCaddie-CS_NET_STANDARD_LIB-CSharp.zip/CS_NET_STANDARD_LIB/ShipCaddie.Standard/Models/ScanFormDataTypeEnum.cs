// <copyright file="ScanFormDataTypeEnum.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace ShipCaddie.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Runtime.Serialization;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using ShipCaddie.Standard;
    using ShipCaddie.Standard.Utilities;

    /// <summary>
    /// ScanFormDataTypeEnum.
    /// </summary>
    [JsonConverter(typeof(StringEnumConverter))]
    public enum ScanFormDataTypeEnum
    {
        /// <summary>
        /// Undefined.
        /// </summary>
        [EnumMember(Value = "undefined")]
        Undefined,

        /// <summary>
        /// ImageUrl.
        /// </summary>
        [EnumMember(Value = "imageUrl")]
        ImageUrl,

        /// <summary>
        /// ImagePng.
        /// </summary>
        [EnumMember(Value = "imagePng")]
        ImagePng,

        /// <summary>
        /// ImageTiff.
        /// </summary>
        [EnumMember(Value = "imageTiff")]
        ImageTiff,

        /// <summary>
        /// Pdf.
        /// </summary>
        [EnumMember(Value = "pdf")]
        Pdf,

        /// <summary>
        /// PdfUrl.
        /// </summary>
        [EnumMember(Value = "pdfUrl")]
        PdfUrl,
    }
}