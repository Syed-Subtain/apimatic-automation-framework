// <copyright file="CountryCodesResponsev21.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace ShipCaddie.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using ShipCaddie.Standard;
    using ShipCaddie.Standard.Utilities;

    /// <summary>
    /// CountryCodesResponsev21.
    /// </summary>
    public class CountryCodesResponsev21
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="CountryCodesResponsev21"/> class.
        /// </summary>
        public CountryCodesResponsev21()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="CountryCodesResponsev21"/> class.
        /// </summary>
        /// <param name="countryCodeList">countryCodeList.</param>
        /// <param name="error">error.</param>
        public CountryCodesResponsev21(
            List<Models.CountryCodeData> countryCodeList,
            Models.RequestError error)
        {
            this.CountryCodeList = countryCodeList;
            this.Error = error;
        }

        /// <summary>
        /// List of Country Codes, Country Names and CountryIds.
        /// </summary>
        [JsonProperty("countryCodeList")]
        public List<Models.CountryCodeData> CountryCodeList { get; set; }

        /// <summary>
        /// This information can be used to determine if an error has occurred when a request was processed.
        /// </summary>
        [JsonProperty("error")]
        public Models.RequestError Error { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"CountryCodesResponsev21 : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is CountryCodesResponsev21 other &&
                ((this.CountryCodeList == null && other.CountryCodeList == null) || (this.CountryCodeList?.Equals(other.CountryCodeList) == true)) &&
                ((this.Error == null && other.Error == null) || (this.Error?.Equals(other.Error) == true));
        }

        /// <inheritdoc/>
        public override int GetHashCode()
        {
            int hashCode = -140566128;

            if (this.CountryCodeList != null)
            {
               hashCode += this.CountryCodeList.GetHashCode();
            }

            if (this.Error != null)
            {
               hashCode += this.Error.GetHashCode();
            }

            return hashCode;
        }

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.CountryCodeList = {(this.CountryCodeList == null ? "null" : $"[{string.Join(", ", this.CountryCodeList)} ]")}");
            toStringOutput.Add($"this.Error = {(this.Error == null ? "null" : this.Error.ToString())}");
        }
    }
}