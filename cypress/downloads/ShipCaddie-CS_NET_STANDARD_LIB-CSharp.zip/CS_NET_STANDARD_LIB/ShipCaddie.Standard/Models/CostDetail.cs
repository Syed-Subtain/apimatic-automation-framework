// <copyright file="CostDetail.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace ShipCaddie.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using ShipCaddie.Standard;
    using ShipCaddie.Standard.Utilities;

    /// <summary>
    /// CostDetail.
    /// </summary>
    public class CostDetail
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="CostDetail"/> class.
        /// </summary>
        public CostDetail()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="CostDetail"/> class.
        /// </summary>
        /// <param name="name">name.</param>
        /// <param name="amount">amount.</param>
        /// <param name="amountDisplay">AmountDisplay.</param>
        public CostDetail(
            string name,
            double amount,
            double? amountDisplay = null)
        {
            this.Name = name;
            this.Amount = amount;
            this.AmountDisplay = amountDisplay;
        }

        /// <summary>
        /// Name of a specific Charge.
        /// </summary>
        [JsonProperty("name")]
        public string Name { get; set; }

        /// <summary>
        /// Cost in United States Currency.
        /// </summary>
        [JsonProperty("amount")]
        public double Amount { get; set; }

        /// <summary>
        /// Total Charge Amount Display
        /// </summary>
        [JsonProperty("AmountDisplay", NullValueHandling = NullValueHandling.Ignore)]
        public double? AmountDisplay { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"CostDetail : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is CostDetail other &&
                ((this.Name == null && other.Name == null) || (this.Name?.Equals(other.Name) == true)) &&
                this.Amount.Equals(other.Amount) &&
                ((this.AmountDisplay == null && other.AmountDisplay == null) || (this.AmountDisplay?.Equals(other.AmountDisplay) == true));
        }

        /// <inheritdoc/>
        public override int GetHashCode()
        {
            int hashCode = 858184895;

            if (this.Name != null)
            {
               hashCode += this.Name.GetHashCode();
            }

            hashCode += this.Amount.GetHashCode();

            if (this.AmountDisplay != null)
            {
               hashCode += this.AmountDisplay.GetHashCode();
            }

            return hashCode;
        }

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.Name = {(this.Name == null ? "null" : this.Name == string.Empty ? "" : this.Name)}");
            toStringOutput.Add($"this.Amount = {this.Amount}");
            toStringOutput.Add($"this.AmountDisplay = {(this.AmountDisplay == null ? "null" : this.AmountDisplay.ToString())}");
        }
    }
}