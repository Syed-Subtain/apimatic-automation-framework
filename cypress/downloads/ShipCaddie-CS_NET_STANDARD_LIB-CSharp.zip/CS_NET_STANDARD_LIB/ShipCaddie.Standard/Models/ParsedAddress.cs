// <copyright file="ParsedAddress.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace ShipCaddie.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using ShipCaddie.Standard;
    using ShipCaddie.Standard.Utilities;

    /// <summary>
    /// ParsedAddress.
    /// </summary>
    public class ParsedAddress
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ParsedAddress"/> class.
        /// </summary>
        public ParsedAddress()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ParsedAddress"/> class.
        /// </summary>
        /// <param name="requestedAddress">requestedAddress.</param>
        /// <param name="suggestedAddresses">suggestedAddresses.</param>
        /// <param name="addressStatus">addressStatus.</param>
        /// <param name="verifiedFrom">verifiedFrom.</param>
        public ParsedAddress(
            Models.AddressesModel requestedAddress = null,
            List<Models.AddressesModel> suggestedAddresses = null,
            Models.AddressStatusEnum? addressStatus = null,
            int? verifiedFrom = null)
        {
            this.RequestedAddress = requestedAddress;
            this.SuggestedAddresses = suggestedAddresses;
            this.AddressStatus = addressStatus;
            this.VerifiedFrom = verifiedFrom;
        }

        /// <summary>
        /// Common model for Requested and Suggested Addresses
        /// </summary>
        [JsonProperty("requestedAddress", NullValueHandling = NullValueHandling.Ignore)]
        public Models.AddressesModel RequestedAddress { get; set; }

        /// <summary>
        /// List of suggested addresses provided by the carrier
        /// </summary>
        [JsonProperty("suggestedAddresses", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.AddressesModel> SuggestedAddresses { get; set; }

        /// <summary>
        /// Status of the address passed
        /// </summary>
        [JsonProperty("addressStatus", ItemConverterType = typeof(StringEnumConverter), NullValueHandling = NullValueHandling.Ignore)]
        public Models.AddressStatusEnum? AddressStatus { get; set; }

        /// <summary>
        /// To get from where It is verified
        /// </summary>
        [JsonProperty("verifiedFrom", NullValueHandling = NullValueHandling.Ignore)]
        public int? VerifiedFrom { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"ParsedAddress : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is ParsedAddress other &&
                ((this.RequestedAddress == null && other.RequestedAddress == null) || (this.RequestedAddress?.Equals(other.RequestedAddress) == true)) &&
                ((this.SuggestedAddresses == null && other.SuggestedAddresses == null) || (this.SuggestedAddresses?.Equals(other.SuggestedAddresses) == true)) &&
                ((this.AddressStatus == null && other.AddressStatus == null) || (this.AddressStatus?.Equals(other.AddressStatus) == true)) &&
                ((this.VerifiedFrom == null && other.VerifiedFrom == null) || (this.VerifiedFrom?.Equals(other.VerifiedFrom) == true));
        }

        /// <inheritdoc/>
        public override int GetHashCode()
        {
            int hashCode = 533857312;

            if (this.RequestedAddress != null)
            {
               hashCode += this.RequestedAddress.GetHashCode();
            }

            if (this.SuggestedAddresses != null)
            {
               hashCode += this.SuggestedAddresses.GetHashCode();
            }

            if (this.AddressStatus != null)
            {
               hashCode += this.AddressStatus.GetHashCode();
            }

            if (this.VerifiedFrom != null)
            {
               hashCode += this.VerifiedFrom.GetHashCode();
            }

            return hashCode;
        }

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.RequestedAddress = {(this.RequestedAddress == null ? "null" : this.RequestedAddress.ToString())}");
            toStringOutput.Add($"this.SuggestedAddresses = {(this.SuggestedAddresses == null ? "null" : $"[{string.Join(", ", this.SuggestedAddresses)} ]")}");
            toStringOutput.Add($"this.AddressStatus = {(this.AddressStatus == null ? "null" : this.AddressStatus.ToString())}");
            toStringOutput.Add($"this.VerifiedFrom = {(this.VerifiedFrom == null ? "null" : this.VerifiedFrom.ToString())}");
        }
    }
}