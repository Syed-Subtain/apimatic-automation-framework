// <copyright file="ShippingCostData.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace ShipCaddie.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using ShipCaddie.Standard;
    using ShipCaddie.Standard.Utilities;

    /// <summary>
    /// ShippingCostData.
    /// </summary>
    public class ShippingCostData
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ShippingCostData"/> class.
        /// </summary>
        public ShippingCostData()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ShippingCostData"/> class.
        /// </summary>
        /// <param name="shippingCost">shippingCost.</param>
        /// <param name="error">error.</param>
        public ShippingCostData(
            Models.ShippingCostInformationv21 shippingCost = null,
            Models.RequestError error = null)
        {
            this.ShippingCost = shippingCost;
            this.Error = error;
        }

        /// <summary>
        /// Cost details related to shipping.
        /// </summary>
        [JsonProperty("shippingCost", NullValueHandling = NullValueHandling.Ignore)]
        public Models.ShippingCostInformationv21 ShippingCost { get; set; }

        /// <summary>
        /// This information can be used to determine if an error has occurred when a request was processed.
        /// </summary>
        [JsonProperty("error", NullValueHandling = NullValueHandling.Ignore)]
        public Models.RequestError Error { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"ShippingCostData : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is ShippingCostData other &&
                ((this.ShippingCost == null && other.ShippingCost == null) || (this.ShippingCost?.Equals(other.ShippingCost) == true)) &&
                ((this.Error == null && other.Error == null) || (this.Error?.Equals(other.Error) == true));
        }

        /// <inheritdoc/>
        public override int GetHashCode()
        {
            int hashCode = 1136186543;

            if (this.ShippingCost != null)
            {
               hashCode += this.ShippingCost.GetHashCode();
            }

            if (this.Error != null)
            {
               hashCode += this.Error.GetHashCode();
            }

            return hashCode;
        }

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.ShippingCost = {(this.ShippingCost == null ? "null" : this.ShippingCost.ToString())}");
            toStringOutput.Add($"this.Error = {(this.Error == null ? "null" : this.Error.ToString())}");
        }
    }
}