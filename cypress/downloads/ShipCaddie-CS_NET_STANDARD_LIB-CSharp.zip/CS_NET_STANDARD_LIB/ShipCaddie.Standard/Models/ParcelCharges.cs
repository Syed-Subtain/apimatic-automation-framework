// <copyright file="ParcelCharges.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace ShipCaddie.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using ShipCaddie.Standard;
    using ShipCaddie.Standard.Utilities;

    /// <summary>
    /// ParcelCharges.
    /// </summary>
    public class ParcelCharges
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ParcelCharges"/> class.
        /// </summary>
        public ParcelCharges()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ParcelCharges"/> class.
        /// </summary>
        /// <param name="parcelID">parcelID.</param>
        /// <param name="costDetails">costDetails.</param>
        /// <param name="packagingId">packagingId.</param>
        public ParcelCharges(
            Guid parcelID,
            List<Models.CostDetail> costDetails = null,
            string packagingId = null)
        {
            this.ParcelID = parcelID;
            this.CostDetails = costDetails;
            this.PackagingId = packagingId;
        }

        /// <summary>
        /// A unique ID used to match
        /// parcels with cost details.
        /// </summary>
        [JsonProperty("parcelID")]
        public Guid ParcelID { get; set; }

        /// <summary>
        /// Detailed shipping charges.
        /// </summary>
        [JsonProperty("costDetails", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.CostDetail> CostDetails { get; set; }

        /// <summary>
        /// Gets or sets PackagingId.
        /// </summary>
        [JsonProperty("packagingId", NullValueHandling = NullValueHandling.Ignore)]
        public string PackagingId { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"ParcelCharges : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is ParcelCharges other &&
                this.ParcelID.Equals(other.ParcelID) &&
                ((this.CostDetails == null && other.CostDetails == null) || (this.CostDetails?.Equals(other.CostDetails) == true)) &&
                ((this.PackagingId == null && other.PackagingId == null) || (this.PackagingId?.Equals(other.PackagingId) == true));
        }

        /// <inheritdoc/>
        public override int GetHashCode()
        {
            int hashCode = -1691200723;
            hashCode += this.ParcelID.GetHashCode();

            if (this.CostDetails != null)
            {
               hashCode += this.CostDetails.GetHashCode();
            }

            if (this.PackagingId != null)
            {
               hashCode += this.PackagingId.GetHashCode();
            }

            return hashCode;
        }

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.ParcelID = {this.ParcelID}");
            toStringOutput.Add($"this.CostDetails = {(this.CostDetails == null ? "null" : $"[{string.Join(", ", this.CostDetails)} ]")}");
            toStringOutput.Add($"this.PackagingId = {(this.PackagingId == null ? "null" : this.PackagingId == string.Empty ? "" : this.PackagingId)}");
        }
    }
}