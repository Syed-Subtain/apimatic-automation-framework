// <copyright file="ShipmentContentTypeEnum.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace ShipCaddie.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Runtime.Serialization;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using ShipCaddie.Standard;
    using ShipCaddie.Standard.Utilities;

    /// <summary>
    /// ShipmentContentTypeEnum.
    /// </summary>
    [JsonConverter(typeof(StringEnumConverter))]
    public enum ShipmentContentTypeEnum
    {
        /// <summary>
        /// NOTAPPLICABLE.
        /// </summary>
        [EnumMember(Value = "NOT_APPLICABLE")]
        NOTAPPLICABLE,

        /// <summary>
        /// CONTENTTYPESAMPLE.
        /// </summary>
        [EnumMember(Value = "CONTENT_TYPE_SAMPLE")]
        CONTENTTYPESAMPLE,

        /// <summary>
        /// CONTENTTYPEDOCUMENTS.
        /// </summary>
        [EnumMember(Value = "CONTENT_TYPE_DOCUMENTS")]
        CONTENTTYPEDOCUMENTS,

        /// <summary>
        /// CONTENTTYPEGIFT.
        /// </summary>
        [EnumMember(Value = "CONTENT_TYPE_GIFT")]
        CONTENTTYPEGIFT,

        /// <summary>
        /// CONTENTTYPEMERCHANDISE.
        /// </summary>
        [EnumMember(Value = "CONTENT_TYPE_MERCHANDISE")]
        CONTENTTYPEMERCHANDISE,

        /// <summary>
        /// CONTENTTYPERETURNEDGOODS.
        /// </summary>
        [EnumMember(Value = "CONTENT_TYPE_RETURNEDGOODS")]
        CONTENTTYPERETURNEDGOODS,

        /// <summary>
        /// CONTENTTYPEOTHER.
        /// </summary>
        [EnumMember(Value = "CONTENT_TYPE_OTHER")]
        CONTENTTYPEOTHER,
    }
}