// <copyright file="UpdateEmailNotificationRequestv21.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace ShipCaddie.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using ShipCaddie.Standard;
    using ShipCaddie.Standard.Utilities;

    /// <summary>
    /// UpdateEmailNotificationRequestv21.
    /// </summary>
    public class UpdateEmailNotificationRequestv21
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="UpdateEmailNotificationRequestv21"/> class.
        /// </summary>
        public UpdateEmailNotificationRequestv21()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="UpdateEmailNotificationRequestv21"/> class.
        /// </summary>
        /// <param name="accessToken">accessToken.</param>
        /// <param name="carrierClientContractId">carrierClientContractId.</param>
        /// <param name="notifyByEmail">notifyByEmail.</param>
        /// <param name="asClientId">asClientId.</param>
        public UpdateEmailNotificationRequestv21(
            string accessToken,
            int carrierClientContractId,
            bool notifyByEmail,
            int? asClientId = null)
        {
            this.AccessToken = accessToken;
            this.AsClientId = asClientId;
            this.CarrierClientContractId = carrierClientContractId;
            this.NotifyByEmail = notifyByEmail;
        }

        /// <summary>
        /// Required.
        /// An authorization token is necessary to call this method.
        /// <remarks>
        /// The token can be obtained by calling the GetToken or RefreshToken methods.
        /// </remarks>
        /// </summary>
        [JsonProperty("accessToken")]
        public string AccessToken { get; set; }

        /// <summary>
        /// Optional.
        /// When empty or null, this field is ignored.
        /// When set, actions will be taken for the client specified by the id.
        /// </summary>
        [JsonProperty("asClientId", NullValueHandling = NullValueHandling.Ignore)]
        public int? AsClientId { get; set; }

        /// <summary>
        /// Required.
        /// Turn email notifications on or off for the carrier specified by CarrierClientContractId.
        /// </summary>
        [JsonProperty("carrierClientContractId")]
        public int CarrierClientContractId { get; set; }

        /// <summary>
        /// Required.
        /// Set to true if you want to recieve email notifictions.  Set to false otherwise.
        /// </summary>
        [JsonProperty("notifyByEmail")]
        public bool NotifyByEmail { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"UpdateEmailNotificationRequestv21 : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is UpdateEmailNotificationRequestv21 other &&
                ((this.AccessToken == null && other.AccessToken == null) || (this.AccessToken?.Equals(other.AccessToken) == true)) &&
                ((this.AsClientId == null && other.AsClientId == null) || (this.AsClientId?.Equals(other.AsClientId) == true)) &&
                this.CarrierClientContractId.Equals(other.CarrierClientContractId) &&
                this.NotifyByEmail.Equals(other.NotifyByEmail);
        }

        /// <inheritdoc/>
        public override int GetHashCode()
        {
            int hashCode = -604586468;

            if (this.AccessToken != null)
            {
               hashCode += this.AccessToken.GetHashCode();
            }

            if (this.AsClientId != null)
            {
               hashCode += this.AsClientId.GetHashCode();
            }

            hashCode += this.CarrierClientContractId.GetHashCode();
            hashCode += this.NotifyByEmail.GetHashCode();

            return hashCode;
        }

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.AccessToken = {(this.AccessToken == null ? "null" : this.AccessToken == string.Empty ? "" : this.AccessToken)}");
            toStringOutput.Add($"this.AsClientId = {(this.AsClientId == null ? "null" : this.AsClientId.ToString())}");
            toStringOutput.Add($"this.CarrierClientContractId = {this.CarrierClientContractId}");
            toStringOutput.Add($"this.NotifyByEmail = {this.NotifyByEmail}");
        }
    }
}