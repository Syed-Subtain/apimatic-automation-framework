// <copyright file="VoidLabelResponsev21.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace ShipCaddie.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using ShipCaddie.Standard;
    using ShipCaddie.Standard.Utilities;

    /// <summary>
    /// VoidLabelResponsev21.
    /// </summary>
    public class VoidLabelResponsev21
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="VoidLabelResponsev21"/> class.
        /// </summary>
        public VoidLabelResponsev21()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="VoidLabelResponsev21"/> class.
        /// </summary>
        /// <param name="trackingNumber">trackingNumber.</param>
        /// <param name="error">error.</param>
        public VoidLabelResponsev21(
            string trackingNumber = null,
            Models.RequestError error = null)
        {
            this.TrackingNumber = trackingNumber;
            this.Error = error;
        }

        /// <summary>
        /// Tracking Number of voided Label
        /// </summary>
        [JsonProperty("trackingNumber", NullValueHandling = NullValueHandling.Ignore)]
        public string TrackingNumber { get; set; }

        /// <summary>
        /// This information can be used to determine if an error has occurred when a request was processed.
        /// </summary>
        [JsonProperty("error", NullValueHandling = NullValueHandling.Ignore)]
        public Models.RequestError Error { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"VoidLabelResponsev21 : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is VoidLabelResponsev21 other &&
                ((this.TrackingNumber == null && other.TrackingNumber == null) || (this.TrackingNumber?.Equals(other.TrackingNumber) == true)) &&
                ((this.Error == null && other.Error == null) || (this.Error?.Equals(other.Error) == true));
        }

        /// <inheritdoc/>
        public override int GetHashCode()
        {
            int hashCode = 838350019;

            if (this.TrackingNumber != null)
            {
               hashCode += this.TrackingNumber.GetHashCode();
            }

            if (this.Error != null)
            {
               hashCode += this.Error.GetHashCode();
            }

            return hashCode;
        }

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.TrackingNumber = {(this.TrackingNumber == null ? "null" : this.TrackingNumber == string.Empty ? "" : this.TrackingNumber)}");
            toStringOutput.Add($"this.Error = {(this.Error == null ? "null" : this.Error.ToString())}");
        }
    }
}