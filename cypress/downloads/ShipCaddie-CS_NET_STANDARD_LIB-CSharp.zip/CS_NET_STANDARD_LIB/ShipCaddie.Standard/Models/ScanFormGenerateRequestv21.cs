// <copyright file="ScanFormGenerateRequestv21.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace ShipCaddie.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using ShipCaddie.Standard;
    using ShipCaddie.Standard.Utilities;

    /// <summary>
    /// ScanFormGenerateRequestv21.
    /// </summary>
    public class ScanFormGenerateRequestv21
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ScanFormGenerateRequestv21"/> class.
        /// </summary>
        public ScanFormGenerateRequestv21()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ScanFormGenerateRequestv21"/> class.
        /// </summary>
        /// <param name="accessToken">accessToken.</param>
        /// <param name="asClientId">asClientId.</param>
        /// <param name="scanFormRequest">scanFormRequest.</param>
        public ScanFormGenerateRequestv21(
            string accessToken = null,
            int? asClientId = null,
            Models.ScanFormModelRequest scanFormRequest = null)
        {
            this.AccessToken = accessToken;
            this.AsClientId = asClientId;
            this.ScanFormRequest = scanFormRequest;
        }

        /// <summary>
        /// Required.
        /// An authorization token is necessary to call this method.
        /// <remarks>
        /// The token can be obtained by calling the GetToken or RefreshToken methods.
        /// </remarks>
        /// </summary>
        [JsonProperty("accessToken", NullValueHandling = NullValueHandling.Ignore)]
        public string AccessToken { get; set; }

        /// <summary>
        /// Optional.
        /// When empty or null, this field is ignored.
        /// When set, actions will be taken for the client specified by the id.
        /// </summary>
        [JsonProperty("asClientId", NullValueHandling = NullValueHandling.Ignore)]
        public int? AsClientId { get; set; }

        /// <summary>
        /// Gets or sets ScanFormRequest.
        /// </summary>
        [JsonProperty("scanFormRequest", NullValueHandling = NullValueHandling.Ignore)]
        public Models.ScanFormModelRequest ScanFormRequest { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"ScanFormGenerateRequestv21 : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is ScanFormGenerateRequestv21 other &&
                ((this.AccessToken == null && other.AccessToken == null) || (this.AccessToken?.Equals(other.AccessToken) == true)) &&
                ((this.AsClientId == null && other.AsClientId == null) || (this.AsClientId?.Equals(other.AsClientId) == true)) &&
                ((this.ScanFormRequest == null && other.ScanFormRequest == null) || (this.ScanFormRequest?.Equals(other.ScanFormRequest) == true));
        }

        /// <inheritdoc/>
        public override int GetHashCode()
        {
            int hashCode = -409622797;

            if (this.AccessToken != null)
            {
               hashCode += this.AccessToken.GetHashCode();
            }

            if (this.AsClientId != null)
            {
               hashCode += this.AsClientId.GetHashCode();
            }

            if (this.ScanFormRequest != null)
            {
               hashCode += this.ScanFormRequest.GetHashCode();
            }

            return hashCode;
        }

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.AccessToken = {(this.AccessToken == null ? "null" : this.AccessToken == string.Empty ? "" : this.AccessToken)}");
            toStringOutput.Add($"this.AsClientId = {(this.AsClientId == null ? "null" : this.AsClientId.ToString())}");
            toStringOutput.Add($"this.ScanFormRequest = {(this.ScanFormRequest == null ? "null" : this.ScanFormRequest.ToString())}");
        }
    }
}