// <copyright file="ApiErrorModel.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace ShipCaddie.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using ShipCaddie.Standard;
    using ShipCaddie.Standard.Utilities;

    /// <summary>
    /// ApiErrorModel.
    /// </summary>
    public class ApiErrorModel
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ApiErrorModel"/> class.
        /// </summary>
        public ApiErrorModel()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ApiErrorModel"/> class.
        /// </summary>
        /// <param name="error">error.</param>
        /// <param name="developerMessage">developerMessage.</param>
        /// <param name="userMessage">userMessage.</param>
        /// <param name="misc">misc.</param>
        public ApiErrorModel(
            string error = null,
            string developerMessage = null,
            string userMessage = null,
            object misc = null)
        {
            this.Error = error;
            this.DeveloperMessage = developerMessage;
            this.UserMessage = userMessage;
            this.Misc = misc;
        }

        /// <summary>
        /// The code that identifies the error.
        /// </summary>
        [JsonProperty("error", NullValueHandling = NullValueHandling.Ignore)]
        public string Error { get; set; }

        /// <summary>
        /// The message that should go back to the developer.
        /// </summary>
        [JsonProperty("developerMessage", NullValueHandling = NullValueHandling.Ignore)]
        public string DeveloperMessage { get; set; }

        /// <summary>
        /// The message if any that should go back to the user.
        /// </summary>
        [JsonProperty("userMessage", NullValueHandling = NullValueHandling.Ignore)]
        public string UserMessage { get; set; }

        /// <summary>
        /// Other misc objects that need to be passed to controller for return with other methods
        /// </summary>
        [JsonProperty("misc", NullValueHandling = NullValueHandling.Ignore)]
        public object Misc { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"ApiErrorModel : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is ApiErrorModel other &&
                ((this.Error == null && other.Error == null) || (this.Error?.Equals(other.Error) == true)) &&
                ((this.DeveloperMessage == null && other.DeveloperMessage == null) || (this.DeveloperMessage?.Equals(other.DeveloperMessage) == true)) &&
                ((this.UserMessage == null && other.UserMessage == null) || (this.UserMessage?.Equals(other.UserMessage) == true)) &&
                ((this.Misc == null && other.Misc == null) || (this.Misc?.Equals(other.Misc) == true));
        }

        /// <inheritdoc/>
        public override int GetHashCode()
        {
            int hashCode = 2126041788;

            if (this.Error != null)
            {
               hashCode += this.Error.GetHashCode();
            }

            if (this.DeveloperMessage != null)
            {
               hashCode += this.DeveloperMessage.GetHashCode();
            }

            if (this.UserMessage != null)
            {
               hashCode += this.UserMessage.GetHashCode();
            }

            if (this.Misc != null)
            {
               hashCode += this.Misc.GetHashCode();
            }

            return hashCode;
        }

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.Error = {(this.Error == null ? "null" : this.Error == string.Empty ? "" : this.Error)}");
            toStringOutput.Add($"this.DeveloperMessage = {(this.DeveloperMessage == null ? "null" : this.DeveloperMessage == string.Empty ? "" : this.DeveloperMessage)}");
            toStringOutput.Add($"this.UserMessage = {(this.UserMessage == null ? "null" : this.UserMessage == string.Empty ? "" : this.UserMessage)}");
            toStringOutput.Add($"Misc = {(this.Misc == null ? "null" : this.Misc.ToString())}");
        }
    }
}