// <copyright file="ParcelInformation.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace ShipCaddie.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using ShipCaddie.Standard;
    using ShipCaddie.Standard.Utilities;

    /// <summary>
    /// ParcelInformation.
    /// </summary>
    public class ParcelInformation
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ParcelInformation"/> class.
        /// </summary>
        public ParcelInformation()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ParcelInformation"/> class.
        /// </summary>
        /// <param name="packagingId">packagingId.</param>
        /// <param name="weightInPounds">weightInPounds.</param>
        /// <param name="lengthInInches">lengthInInches.</param>
        /// <param name="widthInInches">widthInInches.</param>
        /// <param name="heightInInches">heightInInches.</param>
        /// <param name="options">options.</param>
        public ParcelInformation(
            string packagingId = null,
            double? weightInPounds = null,
            double? lengthInInches = null,
            double? widthInInches = null,
            double? heightInInches = null,
            Models.ParcelOptions options = null)
        {
            this.PackagingId = packagingId;
            this.WeightInPounds = weightInPounds;
            this.LengthInInches = lengthInInches;
            this.WidthInInches = widthInInches;
            this.HeightInInches = heightInInches;
            this.Options = options;
        }

        /// <summary>
        /// Gets or sets PackagingId.
        /// </summary>
        [JsonProperty("packagingId", NullValueHandling = NullValueHandling.Ignore)]
        public string PackagingId { get; set; }

        /// <summary>
        /// Parcel Weight in Pounds.
        /// If the weight is a fraction of a pound
        /// still use pounds - not ounces.
        /// </summary>
        [JsonProperty("weightInPounds", NullValueHandling = NullValueHandling.Ignore)]
        public double? WeightInPounds { get; set; }

        /// <summary>
        /// Length of one side of parcel in inches.
        /// </summary>
        [JsonProperty("lengthInInches", NullValueHandling = NullValueHandling.Ignore)]
        public double? LengthInInches { get; set; }

        /// <summary>
        /// Width of one side of parcel in inches.
        /// </summary>
        [JsonProperty("widthInInches", NullValueHandling = NullValueHandling.Ignore)]
        public double? WidthInInches { get; set; }

        /// <summary>
        /// Height of one side of parcel in inches.
        /// </summary>
        [JsonProperty("heightInInches", NullValueHandling = NullValueHandling.Ignore)]
        public double? HeightInInches { get; set; }

        /// <summary>
        /// Specifies additional parcel options such as COD and required Signatures.
        /// </summary>
        [JsonProperty("options", NullValueHandling = NullValueHandling.Ignore)]
        public Models.ParcelOptions Options { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"ParcelInformation : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is ParcelInformation other &&
                ((this.PackagingId == null && other.PackagingId == null) || (this.PackagingId?.Equals(other.PackagingId) == true)) &&
                ((this.WeightInPounds == null && other.WeightInPounds == null) || (this.WeightInPounds?.Equals(other.WeightInPounds) == true)) &&
                ((this.LengthInInches == null && other.LengthInInches == null) || (this.LengthInInches?.Equals(other.LengthInInches) == true)) &&
                ((this.WidthInInches == null && other.WidthInInches == null) || (this.WidthInInches?.Equals(other.WidthInInches) == true)) &&
                ((this.HeightInInches == null && other.HeightInInches == null) || (this.HeightInInches?.Equals(other.HeightInInches) == true)) &&
                ((this.Options == null && other.Options == null) || (this.Options?.Equals(other.Options) == true));
        }

        /// <inheritdoc/>
        public override int GetHashCode()
        {
            int hashCode = -794456451;

            if (this.PackagingId != null)
            {
               hashCode += this.PackagingId.GetHashCode();
            }

            if (this.WeightInPounds != null)
            {
               hashCode += this.WeightInPounds.GetHashCode();
            }

            if (this.LengthInInches != null)
            {
               hashCode += this.LengthInInches.GetHashCode();
            }

            if (this.WidthInInches != null)
            {
               hashCode += this.WidthInInches.GetHashCode();
            }

            if (this.HeightInInches != null)
            {
               hashCode += this.HeightInInches.GetHashCode();
            }

            if (this.Options != null)
            {
               hashCode += this.Options.GetHashCode();
            }

            return hashCode;
        }

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.PackagingId = {(this.PackagingId == null ? "null" : this.PackagingId == string.Empty ? "" : this.PackagingId)}");
            toStringOutput.Add($"this.WeightInPounds = {(this.WeightInPounds == null ? "null" : this.WeightInPounds.ToString())}");
            toStringOutput.Add($"this.LengthInInches = {(this.LengthInInches == null ? "null" : this.LengthInInches.ToString())}");
            toStringOutput.Add($"this.WidthInInches = {(this.WidthInInches == null ? "null" : this.WidthInInches.ToString())}");
            toStringOutput.Add($"this.HeightInInches = {(this.HeightInInches == null ? "null" : this.HeightInInches.ToString())}");
            toStringOutput.Add($"this.Options = {(this.Options == null ? "null" : this.Options.ToString())}");
        }
    }
}