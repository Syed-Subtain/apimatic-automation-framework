// <copyright file="PrintJob.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace ShipCaddie.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using ShipCaddie.Standard;
    using ShipCaddie.Standard.Utilities;

    /// <summary>
    /// PrintJob.
    /// </summary>
    public class PrintJob
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="PrintJob"/> class.
        /// </summary>
        public PrintJob()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="PrintJob"/> class.
        /// </summary>
        /// <param name="printTemplateType">printTemplateType.</param>
        /// <param name="dataBlocks">dataBlocks.</param>
        public PrintJob(
            string printTemplateType = null,
            List<Models.DataBlock> dataBlocks = null)
        {
            this.PrintTemplateType = printTemplateType;
            this.DataBlocks = dataBlocks;
        }

        /// <summary>
        /// Gets or sets PrintTemplateType.
        /// </summary>
        [JsonProperty("printTemplateType", NullValueHandling = NullValueHandling.Ignore)]
        public string PrintTemplateType { get; set; }

        /// <summary>
        /// Gets or sets DataBlocks.
        /// </summary>
        [JsonProperty("dataBlocks", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.DataBlock> DataBlocks { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"PrintJob : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is PrintJob other &&
                ((this.PrintTemplateType == null && other.PrintTemplateType == null) || (this.PrintTemplateType?.Equals(other.PrintTemplateType) == true)) &&
                ((this.DataBlocks == null && other.DataBlocks == null) || (this.DataBlocks?.Equals(other.DataBlocks) == true));
        }

        /// <inheritdoc/>
        public override int GetHashCode()
        {
            int hashCode = -228182609;

            if (this.PrintTemplateType != null)
            {
               hashCode += this.PrintTemplateType.GetHashCode();
            }

            if (this.DataBlocks != null)
            {
               hashCode += this.DataBlocks.GetHashCode();
            }

            return hashCode;
        }

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.PrintTemplateType = {(this.PrintTemplateType == null ? "null" : this.PrintTemplateType == string.Empty ? "" : this.PrintTemplateType)}");
            toStringOutput.Add($"this.DataBlocks = {(this.DataBlocks == null ? "null" : $"[{string.Join(", ", this.DataBlocks)} ]")}");
        }
    }
}