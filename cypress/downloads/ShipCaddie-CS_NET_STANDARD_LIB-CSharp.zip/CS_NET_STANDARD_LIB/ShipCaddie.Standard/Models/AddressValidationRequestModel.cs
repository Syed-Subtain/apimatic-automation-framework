// <copyright file="AddressValidationRequestModel.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace ShipCaddie.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using ShipCaddie.Standard;
    using ShipCaddie.Standard.Utilities;

    /// <summary>
    /// AddressValidationRequestModel.
    /// </summary>
    public class AddressValidationRequestModel
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="AddressValidationRequestModel"/> class.
        /// </summary>
        public AddressValidationRequestModel()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="AddressValidationRequestModel"/> class.
        /// </summary>
        /// <param name="carrierId">carrierId.</param>
        /// <param name="carrierContractId">carrierContractId.</param>
        /// <param name="addresses">addresses.</param>
        public AddressValidationRequestModel(
            int? carrierId = null,
            int? carrierContractId = null,
            List<Models.AddressValidationModel> addresses = null)
        {
            this.CarrierId = carrierId;
            this.CarrierContractId = carrierContractId;
            this.Addresses = addresses;
        }

        /// <summary>
        /// The Id of the carrier
        /// </summary>
        [JsonProperty("carrierId", NullValueHandling = NullValueHandling.Ignore)]
        public int? CarrierId { get; set; }

        /// <summary>
        /// Identifies the Carrier Client Contract on Shipcaddie
        /// </summary>
        [JsonProperty("carrierContractId", NullValueHandling = NullValueHandling.Ignore)]
        public int? CarrierContractId { get; set; }

        /// <summary>
        /// List of address validation models
        /// </summary>
        [JsonProperty("addresses", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.AddressValidationModel> Addresses { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"AddressValidationRequestModel : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is AddressValidationRequestModel other &&
                ((this.CarrierId == null && other.CarrierId == null) || (this.CarrierId?.Equals(other.CarrierId) == true)) &&
                ((this.CarrierContractId == null && other.CarrierContractId == null) || (this.CarrierContractId?.Equals(other.CarrierContractId) == true)) &&
                ((this.Addresses == null && other.Addresses == null) || (this.Addresses?.Equals(other.Addresses) == true));
        }

        /// <inheritdoc/>
        public override int GetHashCode()
        {
            int hashCode = 471288671;

            if (this.CarrierId != null)
            {
               hashCode += this.CarrierId.GetHashCode();
            }

            if (this.CarrierContractId != null)
            {
               hashCode += this.CarrierContractId.GetHashCode();
            }

            if (this.Addresses != null)
            {
               hashCode += this.Addresses.GetHashCode();
            }

            return hashCode;
        }

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.CarrierId = {(this.CarrierId == null ? "null" : this.CarrierId.ToString())}");
            toStringOutput.Add($"this.CarrierContractId = {(this.CarrierContractId == null ? "null" : this.CarrierContractId.ToString())}");
            toStringOutput.Add($"this.Addresses = {(this.Addresses == null ? "null" : $"[{string.Join(", ", this.Addresses)} ]")}");
        }
    }
}