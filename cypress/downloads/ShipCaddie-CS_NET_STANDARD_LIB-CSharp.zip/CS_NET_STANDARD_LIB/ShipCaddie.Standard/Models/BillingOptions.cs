// <copyright file="BillingOptions.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace ShipCaddie.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using ShipCaddie.Standard;
    using ShipCaddie.Standard.Utilities;

    /// <summary>
    /// BillingOptions.
    /// </summary>
    public class BillingOptions
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="BillingOptions"/> class.
        /// </summary>
        public BillingOptions()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="BillingOptions"/> class.
        /// </summary>
        /// <param name="shippingPaidBy">shippingPaidBy.</param>
        /// <param name="dutiesPaidBy">dutiesPaidBy.</param>
        /// <param name="accountNumber">accountNumber.</param>
        /// <param name="postalCode">postalCode.</param>
        /// <param name="countryAlpha2Code">country_Alpha2Code.</param>
        public BillingOptions(
            Models.ShippingPaidByEnum shippingPaidBy,
            Models.DutiesPaidByEnum dutiesPaidBy,
            string accountNumber = null,
            string postalCode = null,
            string countryAlpha2Code = null)
        {
            this.ShippingPaidBy = shippingPaidBy;
            this.AccountNumber = accountNumber;
            this.PostalCode = postalCode;
            this.CountryAlpha2Code = countryAlpha2Code;
            this.DutiesPaidBy = dutiesPaidBy;
        }

        /// <summary>
        /// Indicates who will pay for the shipping Costs.
        /// </summary>
        [JsonProperty("shippingPaidBy", ItemConverterType = typeof(StringEnumConverter))]
        public Models.ShippingPaidByEnum ShippingPaidBy { get; set; }

        /// <summary>
        /// Optional Account Number.
        /// This is the account number of the person or group which will pay the shipping charges.
        /// </summary>
        [JsonProperty("accountNumber", NullValueHandling = NullValueHandling.Ignore)]
        public string AccountNumber { get; set; }

        /// <summary>
        /// Optional Postal Code
        /// This is the postal code of the person or group which will pay the shipping charges.
        /// </summary>
        [JsonProperty("postalCode", NullValueHandling = NullValueHandling.Ignore)]
        public string PostalCode { get; set; }

        /// <summary>
        /// Optional Country
        /// This is the country of the person or group which will pay the shipping charges.
        /// </summary>
        [JsonProperty("country_Alpha2Code", NullValueHandling = NullValueHandling.Ignore)]
        public string CountryAlpha2Code { get; set; }

        /// <summary>
        /// Indicates who will pay for any applicable duties.
        /// </summary>
        [JsonProperty("dutiesPaidBy", ItemConverterType = typeof(StringEnumConverter))]
        public Models.DutiesPaidByEnum DutiesPaidBy { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"BillingOptions : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is BillingOptions other &&
                this.ShippingPaidBy.Equals(other.ShippingPaidBy) &&
                ((this.AccountNumber == null && other.AccountNumber == null) || (this.AccountNumber?.Equals(other.AccountNumber) == true)) &&
                ((this.PostalCode == null && other.PostalCode == null) || (this.PostalCode?.Equals(other.PostalCode) == true)) &&
                ((this.CountryAlpha2Code == null && other.CountryAlpha2Code == null) || (this.CountryAlpha2Code?.Equals(other.CountryAlpha2Code) == true)) &&
                this.DutiesPaidBy.Equals(other.DutiesPaidBy);
        }

        /// <inheritdoc/>
        public override int GetHashCode()
        {
            int hashCode = -1901070426;
            hashCode += this.ShippingPaidBy.GetHashCode();

            if (this.AccountNumber != null)
            {
               hashCode += this.AccountNumber.GetHashCode();
            }

            if (this.PostalCode != null)
            {
               hashCode += this.PostalCode.GetHashCode();
            }

            if (this.CountryAlpha2Code != null)
            {
               hashCode += this.CountryAlpha2Code.GetHashCode();
            }

            hashCode += this.DutiesPaidBy.GetHashCode();

            return hashCode;
        }

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.ShippingPaidBy = {this.ShippingPaidBy}");
            toStringOutput.Add($"this.AccountNumber = {(this.AccountNumber == null ? "null" : this.AccountNumber == string.Empty ? "" : this.AccountNumber)}");
            toStringOutput.Add($"this.PostalCode = {(this.PostalCode == null ? "null" : this.PostalCode == string.Empty ? "" : this.PostalCode)}");
            toStringOutput.Add($"this.CountryAlpha2Code = {(this.CountryAlpha2Code == null ? "null" : this.CountryAlpha2Code == string.Empty ? "" : this.CountryAlpha2Code)}");
            toStringOutput.Add($"this.DutiesPaidBy = {this.DutiesPaidBy}");
        }
    }
}