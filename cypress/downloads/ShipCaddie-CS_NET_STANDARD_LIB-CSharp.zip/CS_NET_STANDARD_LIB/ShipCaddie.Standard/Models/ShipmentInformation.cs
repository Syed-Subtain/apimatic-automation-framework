// <copyright file="ShipmentInformation.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace ShipCaddie.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using ShipCaddie.Standard;
    using ShipCaddie.Standard.Utilities;

    /// <summary>
    /// ShipmentInformation.
    /// </summary>
    public class ShipmentInformation
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ShipmentInformation"/> class.
        /// </summary>
        public ShipmentInformation()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ShipmentInformation"/> class.
        /// </summary>
        /// <param name="dateShipped">dateShipped.</param>
        /// <param name="carrierClientContractId">carrierClientContractId.</param>
        /// <param name="carrierServiceLevelId">carrierServiceLevelId.</param>
        /// <param name="addressFrom">addressFrom.</param>
        /// <param name="addressTo">addressTo.</param>
        /// <param name="parcels">parcels.</param>
        /// <param name="orderReferenceNumber">orderReferenceNumber.</param>
        /// <param name="options">options.</param>
        public ShipmentInformation(
            DateTime dateShipped,
            int carrierClientContractId,
            int carrierServiceLevelId,
            Models.ShipFromAddress addressFrom,
            Models.ShipToAddress addressTo,
            List<Models.ParcelDetail> parcels,
            string orderReferenceNumber = null,
            Models.ShippingOptions options = null)
        {
            this.OrderReferenceNumber = orderReferenceNumber;
            this.DateShipped = dateShipped;
            this.Options = options;
            this.CarrierClientContractId = carrierClientContractId;
            this.CarrierServiceLevelId = carrierServiceLevelId;
            this.AddressFrom = addressFrom;
            this.AddressTo = addressTo;
            this.Parcels = parcels;
        }

        /// <summary>
        /// Optional Reference number which can be used
        /// to uniquely identify a shipment.
        /// </summary>
        [JsonProperty("orderReferenceNumber", NullValueHandling = NullValueHandling.Ignore)]
        public string OrderReferenceNumber { get; set; }

        /// <summary>
        /// Specifies the date of shipment.
        /// </summary>
        [JsonConverter(typeof(IsoDateTimeConverter))]
        [JsonProperty("dateShipped")]
        public DateTime DateShipped { get; set; }

        /// <summary>
        /// Billing and Custom Declaration Options for Shipping.
        /// </summary>
        [JsonProperty("options", NullValueHandling = NullValueHandling.Ignore)]
        public Models.ShippingOptions Options { get; set; }

        /// <summary>
        /// Indicates which Carrier to use.
        /// Obtained from GetCarrierServiceInformation.
        /// </summary>
        [JsonProperty("carrierClientContractId")]
        public int CarrierClientContractId { get; set; }

        /// <summary>
        /// Indicates which Carrier Service Level to use.
        /// Obtained from GetCarrierServiceInformation.
        /// </summary>
        [JsonProperty("carrierServiceLevelId")]
        public int CarrierServiceLevelId { get; set; }

        /// <summary>
        /// Gets or sets AddressFrom.
        /// </summary>
        [JsonProperty("addressFrom")]
        public Models.ShipFromAddress AddressFrom { get; set; }

        /// <summary>
        /// Gets or sets AddressTo.
        /// </summary>
        [JsonProperty("addressTo")]
        public Models.ShipToAddress AddressTo { get; set; }

        /// <summary>
        /// Details of parcels to send.
        /// </summary>
        [JsonProperty("parcels")]
        public List<Models.ParcelDetail> Parcels { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"ShipmentInformation : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is ShipmentInformation other &&
                ((this.OrderReferenceNumber == null && other.OrderReferenceNumber == null) || (this.OrderReferenceNumber?.Equals(other.OrderReferenceNumber) == true)) &&
                this.DateShipped.Equals(other.DateShipped) &&
                ((this.Options == null && other.Options == null) || (this.Options?.Equals(other.Options) == true)) &&
                this.CarrierClientContractId.Equals(other.CarrierClientContractId) &&
                this.CarrierServiceLevelId.Equals(other.CarrierServiceLevelId) &&
                ((this.AddressFrom == null && other.AddressFrom == null) || (this.AddressFrom?.Equals(other.AddressFrom) == true)) &&
                ((this.AddressTo == null && other.AddressTo == null) || (this.AddressTo?.Equals(other.AddressTo) == true)) &&
                ((this.Parcels == null && other.Parcels == null) || (this.Parcels?.Equals(other.Parcels) == true));
        }

        /// <inheritdoc/>
        public override int GetHashCode()
        {
            int hashCode = 1023299385;

            if (this.OrderReferenceNumber != null)
            {
               hashCode += this.OrderReferenceNumber.GetHashCode();
            }

            hashCode += this.DateShipped.GetHashCode();

            if (this.Options != null)
            {
               hashCode += this.Options.GetHashCode();
            }

            hashCode += this.CarrierClientContractId.GetHashCode();
            hashCode += this.CarrierServiceLevelId.GetHashCode();

            if (this.AddressFrom != null)
            {
               hashCode += this.AddressFrom.GetHashCode();
            }

            if (this.AddressTo != null)
            {
               hashCode += this.AddressTo.GetHashCode();
            }

            if (this.Parcels != null)
            {
               hashCode += this.Parcels.GetHashCode();
            }

            return hashCode;
        }

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.OrderReferenceNumber = {(this.OrderReferenceNumber == null ? "null" : this.OrderReferenceNumber == string.Empty ? "" : this.OrderReferenceNumber)}");
            toStringOutput.Add($"this.DateShipped = {this.DateShipped}");
            toStringOutput.Add($"this.Options = {(this.Options == null ? "null" : this.Options.ToString())}");
            toStringOutput.Add($"this.CarrierClientContractId = {this.CarrierClientContractId}");
            toStringOutput.Add($"this.CarrierServiceLevelId = {this.CarrierServiceLevelId}");
            toStringOutput.Add($"this.AddressFrom = {(this.AddressFrom == null ? "null" : this.AddressFrom.ToString())}");
            toStringOutput.Add($"this.AddressTo = {(this.AddressTo == null ? "null" : this.AddressTo.ToString())}");
            toStringOutput.Add($"this.Parcels = {(this.Parcels == null ? "null" : $"[{string.Join(", ", this.Parcels)} ]")}");
        }
    }
}