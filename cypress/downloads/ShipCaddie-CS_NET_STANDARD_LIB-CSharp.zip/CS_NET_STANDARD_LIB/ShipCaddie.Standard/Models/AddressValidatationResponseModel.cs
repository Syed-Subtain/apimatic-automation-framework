// <copyright file="AddressValidatationResponseModel.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace ShipCaddie.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using ShipCaddie.Standard;
    using ShipCaddie.Standard.Utilities;

    /// <summary>
    /// AddressValidatationResponseModel.
    /// </summary>
    public class AddressValidatationResponseModel
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="AddressValidatationResponseModel"/> class.
        /// </summary>
        public AddressValidatationResponseModel()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="AddressValidatationResponseModel"/> class.
        /// </summary>
        /// <param name="errors">errors.</param>
        /// <param name="isValidated">isValidated.</param>
        /// <param name="parsedAddresses">parsedAddresses.</param>
        /// <param name="replyTimeStamp">replyTimeStamp.</param>
        /// <param name="statusCode">statusCode.</param>
        /// <param name="statusDescription">statusDescription.</param>
        public AddressValidatationResponseModel(
            List<Models.ErrorModel> errors = null,
            bool? isValidated = null,
            List<Models.ParsedAddress> parsedAddresses = null,
            DateTime? replyTimeStamp = null,
            string statusCode = null,
            string statusDescription = null)
        {
            this.Errors = errors;
            this.IsValidated = isValidated;
            this.ParsedAddresses = parsedAddresses;
            this.ReplyTimeStamp = replyTimeStamp;
            this.StatusCode = statusCode;
            this.StatusDescription = statusDescription;
        }

        /// <summary>
        /// Gets or sets Errors.
        /// </summary>
        [JsonProperty("errors", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.ErrorModel> Errors { get; set; }

        /// <summary>
        /// Flag indicates whether address is validated or not
        /// </summary>
        [JsonProperty("isValidated", NullValueHandling = NullValueHandling.Ignore)]
        public bool? IsValidated { get; set; }

        /// <summary>
        /// List of parsed address
        /// </summary>
        [JsonProperty("parsedAddresses", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.ParsedAddress> ParsedAddresses { get; set; }

        /// <summary>
        /// Reply time stamp
        /// </summary>
        [JsonConverter(typeof(IsoDateTimeConverter))]
        [JsonProperty("replyTimeStamp", NullValueHandling = NullValueHandling.Ignore)]
        public DateTime? ReplyTimeStamp { get; set; }

        /// <summary>
        /// Status code
        /// </summary>
        [JsonProperty("statusCode", NullValueHandling = NullValueHandling.Ignore)]
        public string StatusCode { get; set; }

        /// <summary>
        /// Decsription for the status
        /// </summary>
        [JsonProperty("statusDescription", NullValueHandling = NullValueHandling.Ignore)]
        public string StatusDescription { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"AddressValidatationResponseModel : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is AddressValidatationResponseModel other &&
                ((this.Errors == null && other.Errors == null) || (this.Errors?.Equals(other.Errors) == true)) &&
                ((this.IsValidated == null && other.IsValidated == null) || (this.IsValidated?.Equals(other.IsValidated) == true)) &&
                ((this.ParsedAddresses == null && other.ParsedAddresses == null) || (this.ParsedAddresses?.Equals(other.ParsedAddresses) == true)) &&
                ((this.ReplyTimeStamp == null && other.ReplyTimeStamp == null) || (this.ReplyTimeStamp?.Equals(other.ReplyTimeStamp) == true)) &&
                ((this.StatusCode == null && other.StatusCode == null) || (this.StatusCode?.Equals(other.StatusCode) == true)) &&
                ((this.StatusDescription == null && other.StatusDescription == null) || (this.StatusDescription?.Equals(other.StatusDescription) == true));
        }

        /// <inheritdoc/>
        public override int GetHashCode()
        {
            int hashCode = 393601212;

            if (this.Errors != null)
            {
               hashCode += this.Errors.GetHashCode();
            }

            if (this.IsValidated != null)
            {
               hashCode += this.IsValidated.GetHashCode();
            }

            if (this.ParsedAddresses != null)
            {
               hashCode += this.ParsedAddresses.GetHashCode();
            }

            if (this.ReplyTimeStamp != null)
            {
               hashCode += this.ReplyTimeStamp.GetHashCode();
            }

            if (this.StatusCode != null)
            {
               hashCode += this.StatusCode.GetHashCode();
            }

            if (this.StatusDescription != null)
            {
               hashCode += this.StatusDescription.GetHashCode();
            }

            return hashCode;
        }

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.Errors = {(this.Errors == null ? "null" : $"[{string.Join(", ", this.Errors)} ]")}");
            toStringOutput.Add($"this.IsValidated = {(this.IsValidated == null ? "null" : this.IsValidated.ToString())}");
            toStringOutput.Add($"this.ParsedAddresses = {(this.ParsedAddresses == null ? "null" : $"[{string.Join(", ", this.ParsedAddresses)} ]")}");
            toStringOutput.Add($"this.ReplyTimeStamp = {(this.ReplyTimeStamp == null ? "null" : this.ReplyTimeStamp.ToString())}");
            toStringOutput.Add($"this.StatusCode = {(this.StatusCode == null ? "null" : this.StatusCode == string.Empty ? "" : this.StatusCode)}");
            toStringOutput.Add($"this.StatusDescription = {(this.StatusDescription == null ? "null" : this.StatusDescription == string.Empty ? "" : this.StatusDescription)}");
        }
    }
}