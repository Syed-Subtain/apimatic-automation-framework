// <copyright file="AddressStatusEnum.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace ShipCaddie.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Runtime.Serialization;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using ShipCaddie.Standard;
    using ShipCaddie.Standard.Utilities;

    /// <summary>
    /// AddressStatusEnum.
    /// </summary>
    [JsonConverter(typeof(StringEnumConverter))]
    public enum AddressStatusEnum
    {
        /// <summary>
        /// NotCorrected.
        /// </summary>
        [EnumMember(Value = "NotCorrected")]
        NotCorrected,

        /// <summary>
        /// Corrected.
        /// </summary>
        [EnumMember(Value = "Corrected")]
        Corrected,
    }
}