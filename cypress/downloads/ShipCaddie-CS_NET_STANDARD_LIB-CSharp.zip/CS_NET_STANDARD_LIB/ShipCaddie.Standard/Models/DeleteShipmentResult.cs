// <copyright file="DeleteShipmentResult.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace ShipCaddie.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using ShipCaddie.Standard;
    using ShipCaddie.Standard.Utilities;

    /// <summary>
    /// DeleteShipmentResult.
    /// </summary>
    public class DeleteShipmentResult
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="DeleteShipmentResult"/> class.
        /// </summary>
        public DeleteShipmentResult()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="DeleteShipmentResult"/> class.
        /// </summary>
        /// <param name="shipmentId">shipmentId.</param>
        /// <param name="isDeleted">isDeleted.</param>
        /// <param name="error">error.</param>
        public DeleteShipmentResult(
            int? shipmentId = null,
            bool? isDeleted = null,
            Models.RequestError error = null)
        {
            this.ShipmentId = shipmentId;
            this.IsDeleted = isDeleted;
            this.Error = error;
        }

        /// <summary>
        /// ID uniquely identifying the shipment that was requested to be deleted.
        /// </summary>
        [JsonProperty("shipmentId", NullValueHandling = NullValueHandling.Ignore)]
        public int? ShipmentId { get; set; }

        /// <summary>
        /// Set to true if the shipment was deleted successfully.
        /// </summary>
        [JsonProperty("isDeleted", NullValueHandling = NullValueHandling.Ignore)]
        public bool? IsDeleted { get; set; }

        /// <summary>
        /// This information can be used to determine if an error has occurred when a request was processed.
        /// </summary>
        [JsonProperty("error", NullValueHandling = NullValueHandling.Ignore)]
        public Models.RequestError Error { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"DeleteShipmentResult : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is DeleteShipmentResult other &&
                ((this.ShipmentId == null && other.ShipmentId == null) || (this.ShipmentId?.Equals(other.ShipmentId) == true)) &&
                ((this.IsDeleted == null && other.IsDeleted == null) || (this.IsDeleted?.Equals(other.IsDeleted) == true)) &&
                ((this.Error == null && other.Error == null) || (this.Error?.Equals(other.Error) == true));
        }

        /// <inheritdoc/>
        public override int GetHashCode()
        {
            int hashCode = -1479866834;

            if (this.ShipmentId != null)
            {
               hashCode += this.ShipmentId.GetHashCode();
            }

            if (this.IsDeleted != null)
            {
               hashCode += this.IsDeleted.GetHashCode();
            }

            if (this.Error != null)
            {
               hashCode += this.Error.GetHashCode();
            }

            return hashCode;
        }

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.ShipmentId = {(this.ShipmentId == null ? "null" : this.ShipmentId.ToString())}");
            toStringOutput.Add($"this.IsDeleted = {(this.IsDeleted == null ? "null" : this.IsDeleted.ToString())}");
            toStringOutput.Add($"this.Error = {(this.Error == null ? "null" : this.Error.ToString())}");
        }
    }
}