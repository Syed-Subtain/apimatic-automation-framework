// <copyright file="LabelInformationWithCost.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace ShipCaddie.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using ShipCaddie.Standard;
    using ShipCaddie.Standard.Utilities;

    /// <summary>
    /// LabelInformationWithCost.
    /// </summary>
    public class LabelInformationWithCost
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="LabelInformationWithCost"/> class.
        /// </summary>
        public LabelInformationWithCost()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="LabelInformationWithCost"/> class.
        /// </summary>
        /// <param name="labels">labels.</param>
        /// <param name="shipmentID">shipmentID.</param>
        /// <param name="error">error.</param>
        /// <param name="carrier">carrier.</param>
        /// <param name="serviceLevel">serviceLevel.</param>
        /// <param name="totalAmount">totalAmount.</param>
        public LabelInformationWithCost(
            List<Models.PrintableLabel> labels,
            int shipmentID,
            Models.RequestError error,
            string carrier = null,
            string serviceLevel = null,
            double? totalAmount = null)
        {
            this.Labels = labels;
            this.ShipmentID = shipmentID;
            this.Carrier = carrier;
            this.ServiceLevel = serviceLevel;
            this.TotalAmount = totalAmount;
            this.Error = error;
        }

        /// <summary>
        /// Printable labels. One for each parcel.
        /// </summary>
        [JsonProperty("labels")]
        public List<Models.PrintableLabel> Labels { get; set; }

        /// <summary>
        /// ID which uniquely identifies this shipment.
        /// This ID can be used in other API Methods.
        /// </summary>
        [JsonProperty("shipmentID")]
        public int ShipmentID { get; set; }

        /// <summary>
        /// Name of the Carrier.
        /// </summary>
        [JsonProperty("carrier", NullValueHandling = NullValueHandling.Ignore)]
        public string Carrier { get; set; }

        /// <summary>
        /// Name of the selected Service Level
        /// </summary>
        [JsonProperty("serviceLevel", NullValueHandling = NullValueHandling.Ignore)]
        public string ServiceLevel { get; set; }

        /// <summary>
        /// Total amount of the Shipment
        /// </summary>
        [JsonProperty("totalAmount", NullValueHandling = NullValueHandling.Ignore)]
        public double? TotalAmount { get; set; }

        /// <summary>
        /// This information can be used to determine if an error has occurred when a request was processed.
        /// </summary>
        [JsonProperty("error")]
        public Models.RequestError Error { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"LabelInformationWithCost : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is LabelInformationWithCost other &&
                ((this.Labels == null && other.Labels == null) || (this.Labels?.Equals(other.Labels) == true)) &&
                this.ShipmentID.Equals(other.ShipmentID) &&
                ((this.Carrier == null && other.Carrier == null) || (this.Carrier?.Equals(other.Carrier) == true)) &&
                ((this.ServiceLevel == null && other.ServiceLevel == null) || (this.ServiceLevel?.Equals(other.ServiceLevel) == true)) &&
                ((this.TotalAmount == null && other.TotalAmount == null) || (this.TotalAmount?.Equals(other.TotalAmount) == true)) &&
                ((this.Error == null && other.Error == null) || (this.Error?.Equals(other.Error) == true));
        }

        /// <inheritdoc/>
        public override int GetHashCode()
        {
            int hashCode = 126666045;

            if (this.Labels != null)
            {
               hashCode += this.Labels.GetHashCode();
            }

            hashCode += this.ShipmentID.GetHashCode();

            if (this.Carrier != null)
            {
               hashCode += this.Carrier.GetHashCode();
            }

            if (this.ServiceLevel != null)
            {
               hashCode += this.ServiceLevel.GetHashCode();
            }

            if (this.TotalAmount != null)
            {
               hashCode += this.TotalAmount.GetHashCode();
            }

            if (this.Error != null)
            {
               hashCode += this.Error.GetHashCode();
            }

            return hashCode;
        }

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.Labels = {(this.Labels == null ? "null" : $"[{string.Join(", ", this.Labels)} ]")}");
            toStringOutput.Add($"this.ShipmentID = {this.ShipmentID}");
            toStringOutput.Add($"this.Carrier = {(this.Carrier == null ? "null" : this.Carrier == string.Empty ? "" : this.Carrier)}");
            toStringOutput.Add($"this.ServiceLevel = {(this.ServiceLevel == null ? "null" : this.ServiceLevel == string.Empty ? "" : this.ServiceLevel)}");
            toStringOutput.Add($"this.TotalAmount = {(this.TotalAmount == null ? "null" : this.TotalAmount.ToString())}");
            toStringOutput.Add($"this.Error = {(this.Error == null ? "null" : this.Error.ToString())}");
        }
    }
}