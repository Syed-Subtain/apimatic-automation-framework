// <copyright file="PrintableLabel.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace ShipCaddie.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using ShipCaddie.Standard;
    using ShipCaddie.Standard.Utilities;

    /// <summary>
    /// PrintableLabel.
    /// </summary>
    public class PrintableLabel
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="PrintableLabel"/> class.
        /// </summary>
        public PrintableLabel()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="PrintableLabel"/> class.
        /// </summary>
        /// <param name="parcelIndex">parcelIndex.</param>
        /// <param name="printFormat">printFormat.</param>
        /// <param name="base64Label">base64Label.</param>
        /// <param name="labelKey">labelKey.</param>
        /// <param name="trackingNumber">trackingNumber.</param>
        /// <param name="labelURL">labelURL.</param>
        public PrintableLabel(
            int parcelIndex,
            Models.PrintFormat1Enum printFormat,
            string base64Label,
            string labelKey,
            string trackingNumber,
            string labelURL)
        {
            this.ParcelIndex = parcelIndex;
            this.PrintFormat = printFormat;
            this.Base64Label = base64Label;
            this.LabelKey = labelKey;
            this.TrackingNumber = trackingNumber;
            this.LabelURL = labelURL;
        }

        /// <summary>
        /// The parcel number in a multi-parcel shipment
        /// The first index will be 1, then it will increment
        /// (ie 1, 2, 3, etc.)
        /// </summary>
        [JsonProperty("parcelIndex")]
        public int ParcelIndex { get; set; }

        /// <summary>
        /// Indicates the format of the Base64 Label
        /// </summary>
        [JsonProperty("printFormat", ItemConverterType = typeof(StringEnumConverter))]
        public Models.PrintFormat1Enum PrintFormat { get; set; }

        /// <summary>
        /// This is a base 64 string which is to be decoded
        /// into the Print Format specified by PrintFormat.
        /// </summary>
        [JsonProperty("base64Label")]
        public string Base64Label { get; set; }

        /// <summary>
        /// Used with VoidLabel when voiding a label.
        /// </summary>
        [JsonProperty("labelKey")]
        public string LabelKey { get; set; }

        /// <summary>
        /// Tracking Number of the parcel.
        /// </summary>
        [JsonProperty("trackingNumber")]
        public string TrackingNumber { get; set; }

        /// <summary>
        /// URL of Printable Label
        /// </summary>
        [JsonProperty("labelURL")]
        public string LabelURL { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"PrintableLabel : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is PrintableLabel other &&
                this.ParcelIndex.Equals(other.ParcelIndex) &&
                this.PrintFormat.Equals(other.PrintFormat) &&
                ((this.Base64Label == null && other.Base64Label == null) || (this.Base64Label?.Equals(other.Base64Label) == true)) &&
                ((this.LabelKey == null && other.LabelKey == null) || (this.LabelKey?.Equals(other.LabelKey) == true)) &&
                ((this.TrackingNumber == null && other.TrackingNumber == null) || (this.TrackingNumber?.Equals(other.TrackingNumber) == true)) &&
                ((this.LabelURL == null && other.LabelURL == null) || (this.LabelURL?.Equals(other.LabelURL) == true));
        }

        /// <inheritdoc/>
        public override int GetHashCode()
        {
            int hashCode = -1221396968;
            hashCode += this.ParcelIndex.GetHashCode();
            hashCode += this.PrintFormat.GetHashCode();

            if (this.Base64Label != null)
            {
               hashCode += this.Base64Label.GetHashCode();
            }

            if (this.LabelKey != null)
            {
               hashCode += this.LabelKey.GetHashCode();
            }

            if (this.TrackingNumber != null)
            {
               hashCode += this.TrackingNumber.GetHashCode();
            }

            if (this.LabelURL != null)
            {
               hashCode += this.LabelURL.GetHashCode();
            }

            return hashCode;
        }

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.ParcelIndex = {this.ParcelIndex}");
            toStringOutput.Add($"this.PrintFormat = {this.PrintFormat}");
            toStringOutput.Add($"this.Base64Label = {(this.Base64Label == null ? "null" : this.Base64Label == string.Empty ? "" : this.Base64Label)}");
            toStringOutput.Add($"this.LabelKey = {(this.LabelKey == null ? "null" : this.LabelKey == string.Empty ? "" : this.LabelKey)}");
            toStringOutput.Add($"this.TrackingNumber = {(this.TrackingNumber == null ? "null" : this.TrackingNumber == string.Empty ? "" : this.TrackingNumber)}");
            toStringOutput.Add($"this.LabelURL = {(this.LabelURL == null ? "null" : this.LabelURL == string.Empty ? "" : this.LabelURL)}");
        }
    }
}