// <copyright file="CarrierInformation.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace ShipCaddie.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using ShipCaddie.Standard;
    using ShipCaddie.Standard.Utilities;

    /// <summary>
    /// CarrierInformation.
    /// </summary>
    public class CarrierInformation
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="CarrierInformation"/> class.
        /// </summary>
        public CarrierInformation()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="CarrierInformation"/> class.
        /// </summary>
        /// <param name="carrierClientContractId">carrierClientContractId.</param>
        /// <param name="affillateName">affillateName.</param>
        /// <param name="carrierName">carrierName.</param>
        /// <param name="nickName">nickName.</param>
        /// <param name="serviceLevels">serviceLevels.</param>
        /// <param name="error">error.</param>
        public CarrierInformation(
            int carrierClientContractId,
            string affillateName,
            string carrierName,
            string nickName,
            List<Models.ServiceLevelDetail> serviceLevels,
            Models.RequestError error = null)
        {
            this.CarrierClientContractId = carrierClientContractId;
            this.AffillateName = affillateName;
            this.CarrierName = carrierName;
            this.NickName = nickName;
            this.ServiceLevels = serviceLevels;
            this.Error = error;
        }

        /// <summary>
        /// This id is used to identify a carrier.
        /// Various API methods require this id.
        /// </summary>
        [JsonProperty("carrierClientContractId")]
        public int CarrierClientContractId { get; set; }

        /// <summary>
        /// Affillate Name
        /// </summary>
        [JsonProperty("affillateName")]
        public string AffillateName { get; set; }

        /// <summary>
        /// Offical name of carrier.
        /// </summary>
        [JsonProperty("carrierName")]
        public string CarrierName { get; set; }

        /// <summary>
        /// Descriptive Name
        /// </summary>
        [JsonProperty("nickName")]
        public string NickName { get; set; }

        /// <summary>
        /// Describes service details such as parcel weight limits.
        /// </summary>
        [JsonProperty("serviceLevels")]
        public List<Models.ServiceLevelDetail> ServiceLevels { get; set; }

        /// <summary>
        /// This information can be used to determine if an error has occurred when a request was processed.
        /// </summary>
        [JsonProperty("error", NullValueHandling = NullValueHandling.Ignore)]
        public Models.RequestError Error { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"CarrierInformation : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is CarrierInformation other &&
                this.CarrierClientContractId.Equals(other.CarrierClientContractId) &&
                ((this.AffillateName == null && other.AffillateName == null) || (this.AffillateName?.Equals(other.AffillateName) == true)) &&
                ((this.CarrierName == null && other.CarrierName == null) || (this.CarrierName?.Equals(other.CarrierName) == true)) &&
                ((this.NickName == null && other.NickName == null) || (this.NickName?.Equals(other.NickName) == true)) &&
                ((this.ServiceLevels == null && other.ServiceLevels == null) || (this.ServiceLevels?.Equals(other.ServiceLevels) == true)) &&
                ((this.Error == null && other.Error == null) || (this.Error?.Equals(other.Error) == true));
        }

        /// <inheritdoc/>
        public override int GetHashCode()
        {
            int hashCode = 980171209;
            hashCode += this.CarrierClientContractId.GetHashCode();

            if (this.AffillateName != null)
            {
               hashCode += this.AffillateName.GetHashCode();
            }

            if (this.CarrierName != null)
            {
               hashCode += this.CarrierName.GetHashCode();
            }

            if (this.NickName != null)
            {
               hashCode += this.NickName.GetHashCode();
            }

            if (this.ServiceLevels != null)
            {
               hashCode += this.ServiceLevels.GetHashCode();
            }

            if (this.Error != null)
            {
               hashCode += this.Error.GetHashCode();
            }

            return hashCode;
        }

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.CarrierClientContractId = {this.CarrierClientContractId}");
            toStringOutput.Add($"this.AffillateName = {(this.AffillateName == null ? "null" : this.AffillateName == string.Empty ? "" : this.AffillateName)}");
            toStringOutput.Add($"this.CarrierName = {(this.CarrierName == null ? "null" : this.CarrierName == string.Empty ? "" : this.CarrierName)}");
            toStringOutput.Add($"this.NickName = {(this.NickName == null ? "null" : this.NickName == string.Empty ? "" : this.NickName)}");
            toStringOutput.Add($"this.ServiceLevels = {(this.ServiceLevels == null ? "null" : $"[{string.Join(", ", this.ServiceLevels)} ]")}");
            toStringOutput.Add($"this.Error = {(this.Error == null ? "null" : this.Error.ToString())}");
        }
    }
}