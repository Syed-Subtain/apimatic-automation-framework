// <copyright file="ShipmentInformationResponse.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace ShipCaddie.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using ShipCaddie.Standard;
    using ShipCaddie.Standard.Utilities;

    /// <summary>
    /// ShipmentInformationResponse.
    /// </summary>
    public class ShipmentInformationResponse
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ShipmentInformationResponse"/> class.
        /// </summary>
        public ShipmentInformationResponse()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ShipmentInformationResponse"/> class.
        /// </summary>
        /// <param name="error">error.</param>
        /// <param name="shipmentId">shipmentId.</param>
        /// <param name="shipment">shipment.</param>
        public ShipmentInformationResponse(
            Models.RequestError error,
            int? shipmentId = null,
            Models.ShipmentInformation shipment = null)
        {
            this.ShipmentId = shipmentId;
            this.Error = error;
            this.Shipment = shipment;
        }

        /// <summary>
        /// Id used to identify shipment.
        /// </summary>
        [JsonProperty("shipmentId", NullValueHandling = NullValueHandling.Ignore)]
        public int? ShipmentId { get; set; }

        /// <summary>
        /// This information can be used to determine if an error has occurred when a request was processed.
        /// </summary>
        [JsonProperty("error")]
        public Models.RequestError Error { get; set; }

        /// <summary>
        /// All necessary shipping information
        /// </summary>
        [JsonProperty("shipment", NullValueHandling = NullValueHandling.Ignore)]
        public Models.ShipmentInformation Shipment { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"ShipmentInformationResponse : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is ShipmentInformationResponse other &&
                ((this.ShipmentId == null && other.ShipmentId == null) || (this.ShipmentId?.Equals(other.ShipmentId) == true)) &&
                ((this.Error == null && other.Error == null) || (this.Error?.Equals(other.Error) == true)) &&
                ((this.Shipment == null && other.Shipment == null) || (this.Shipment?.Equals(other.Shipment) == true));
        }

        /// <inheritdoc/>
        public override int GetHashCode()
        {
            int hashCode = -2016081649;

            if (this.ShipmentId != null)
            {
               hashCode += this.ShipmentId.GetHashCode();
            }

            if (this.Error != null)
            {
               hashCode += this.Error.GetHashCode();
            }

            if (this.Shipment != null)
            {
               hashCode += this.Shipment.GetHashCode();
            }

            return hashCode;
        }

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.ShipmentId = {(this.ShipmentId == null ? "null" : this.ShipmentId.ToString())}");
            toStringOutput.Add($"this.Error = {(this.Error == null ? "null" : this.Error.ToString())}");
            toStringOutput.Add($"this.Shipment = {(this.Shipment == null ? "null" : this.Shipment.ToString())}");
        }
    }
}