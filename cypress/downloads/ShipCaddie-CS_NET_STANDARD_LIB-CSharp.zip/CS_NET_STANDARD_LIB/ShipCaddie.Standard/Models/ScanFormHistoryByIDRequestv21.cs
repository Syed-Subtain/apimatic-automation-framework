// <copyright file="ScanFormHistoryByIDRequestv21.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace ShipCaddie.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using ShipCaddie.Standard;
    using ShipCaddie.Standard.Utilities;

    /// <summary>
    /// ScanFormHistoryByIDRequestv21.
    /// </summary>
    public class ScanFormHistoryByIDRequestv21
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ScanFormHistoryByIDRequestv21"/> class.
        /// </summary>
        public ScanFormHistoryByIDRequestv21()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ScanFormHistoryByIDRequestv21"/> class.
        /// </summary>
        /// <param name="accessToken">accessToken.</param>
        /// <param name="scanFormId">scanFormId.</param>
        /// <param name="asClientId">asClientId.</param>
        public ScanFormHistoryByIDRequestv21(
            string accessToken,
            int scanFormId,
            int? asClientId = null)
        {
            this.AccessToken = accessToken;
            this.ScanFormId = scanFormId;
            this.AsClientId = asClientId;
        }

        /// <summary>
        /// Required.
        /// An authorization token is necessary to call this method.
        /// <remarks>
        /// The token can be obtained by calling the GetToken or RefreshToken methods.
        /// </remarks>
        /// </summary>
        [JsonProperty("accessToken")]
        public string AccessToken { get; set; }

        /// <summary>
        /// ID of Scan form to retrieve.
        /// </summary>
        [JsonProperty("scanFormId")]
        public int ScanFormId { get; set; }

        /// <summary>
        /// Optional.
        /// When empty or null, this field is ignored.
        /// When set, actions will be taken for the client specified by the id.
        /// </summary>
        [JsonProperty("asClientId", NullValueHandling = NullValueHandling.Ignore)]
        public int? AsClientId { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"ScanFormHistoryByIDRequestv21 : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is ScanFormHistoryByIDRequestv21 other &&
                ((this.AccessToken == null && other.AccessToken == null) || (this.AccessToken?.Equals(other.AccessToken) == true)) &&
                this.ScanFormId.Equals(other.ScanFormId) &&
                ((this.AsClientId == null && other.AsClientId == null) || (this.AsClientId?.Equals(other.AsClientId) == true));
        }

        /// <inheritdoc/>
        public override int GetHashCode()
        {
            int hashCode = -1289270492;

            if (this.AccessToken != null)
            {
               hashCode += this.AccessToken.GetHashCode();
            }

            hashCode += this.ScanFormId.GetHashCode();

            if (this.AsClientId != null)
            {
               hashCode += this.AsClientId.GetHashCode();
            }

            return hashCode;
        }

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.AccessToken = {(this.AccessToken == null ? "null" : this.AccessToken == string.Empty ? "" : this.AccessToken)}");
            toStringOutput.Add($"this.ScanFormId = {this.ScanFormId}");
            toStringOutput.Add($"this.AsClientId = {(this.AsClientId == null ? "null" : this.AsClientId.ToString())}");
        }
    }
}