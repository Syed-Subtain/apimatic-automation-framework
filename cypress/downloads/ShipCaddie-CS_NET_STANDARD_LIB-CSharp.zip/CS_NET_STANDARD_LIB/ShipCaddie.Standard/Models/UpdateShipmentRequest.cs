// <copyright file="UpdateShipmentRequest.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace ShipCaddie.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using ShipCaddie.Standard;
    using ShipCaddie.Standard.Utilities;

    /// <summary>
    /// UpdateShipmentRequest.
    /// </summary>
    public class UpdateShipmentRequest
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="UpdateShipmentRequest"/> class.
        /// </summary>
        public UpdateShipmentRequest()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="UpdateShipmentRequest"/> class.
        /// </summary>
        /// <param name="accessToken">accessToken.</param>
        /// <param name="asClientId">asClientId.</param>
        /// <param name="shipmentId">shipmentId.</param>
        /// <param name="shipment">shipment.</param>
        public UpdateShipmentRequest(
            string accessToken,
            int? asClientId = null,
            int? shipmentId = null,
            Models.ShipmentInformation shipment = null)
        {
            this.AccessToken = accessToken;
            this.AsClientId = asClientId;
            this.ShipmentId = shipmentId;
            this.Shipment = shipment;
        }

        /// <summary>
        /// Required.
        /// An authorization token is necessary to call this method.
        /// <remarks>
        /// The token can be obtained by calling the GetToken or RefreshToken methods.
        /// </remarks>
        /// </summary>
        [JsonProperty("accessToken")]
        public string AccessToken { get; set; }

        /// <summary>
        /// Optional.
        /// When empty or null, this field is ignored.
        /// When set, actions will be taken for the client specified by the id.
        /// </summary>
        [JsonProperty("asClientId", NullValueHandling = NullValueHandling.Ignore)]
        public int? AsClientId { get; set; }

        /// <summary>
        /// Id of an existing shipment.
        /// </summary>
        [JsonProperty("shipmentId", NullValueHandling = NullValueHandling.Ignore)]
        public int? ShipmentId { get; set; }

        /// <summary>
        /// All necessary shipping information
        /// </summary>
        [JsonProperty("shipment", NullValueHandling = NullValueHandling.Ignore)]
        public Models.ShipmentInformation Shipment { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"UpdateShipmentRequest : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is UpdateShipmentRequest other &&
                ((this.AccessToken == null && other.AccessToken == null) || (this.AccessToken?.Equals(other.AccessToken) == true)) &&
                ((this.AsClientId == null && other.AsClientId == null) || (this.AsClientId?.Equals(other.AsClientId) == true)) &&
                ((this.ShipmentId == null && other.ShipmentId == null) || (this.ShipmentId?.Equals(other.ShipmentId) == true)) &&
                ((this.Shipment == null && other.Shipment == null) || (this.Shipment?.Equals(other.Shipment) == true));
        }

        /// <inheritdoc/>
        public override int GetHashCode()
        {
            int hashCode = -1350990601;

            if (this.AccessToken != null)
            {
               hashCode += this.AccessToken.GetHashCode();
            }

            if (this.AsClientId != null)
            {
               hashCode += this.AsClientId.GetHashCode();
            }

            if (this.ShipmentId != null)
            {
               hashCode += this.ShipmentId.GetHashCode();
            }

            if (this.Shipment != null)
            {
               hashCode += this.Shipment.GetHashCode();
            }

            return hashCode;
        }

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.AccessToken = {(this.AccessToken == null ? "null" : this.AccessToken == string.Empty ? "" : this.AccessToken)}");
            toStringOutput.Add($"this.AsClientId = {(this.AsClientId == null ? "null" : this.AsClientId.ToString())}");
            toStringOutput.Add($"this.ShipmentId = {(this.ShipmentId == null ? "null" : this.ShipmentId.ToString())}");
            toStringOutput.Add($"this.Shipment = {(this.Shipment == null ? "null" : this.Shipment.ToString())}");
        }
    }
}