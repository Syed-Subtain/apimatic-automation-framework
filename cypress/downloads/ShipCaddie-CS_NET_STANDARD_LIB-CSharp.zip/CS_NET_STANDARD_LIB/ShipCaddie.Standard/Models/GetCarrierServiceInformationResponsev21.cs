// <copyright file="GetCarrierServiceInformationResponsev21.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace ShipCaddie.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using ShipCaddie.Standard;
    using ShipCaddie.Standard.Utilities;

    /// <summary>
    /// GetCarrierServiceInformationResponsev21.
    /// </summary>
    public class GetCarrierServiceInformationResponsev21
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="GetCarrierServiceInformationResponsev21"/> class.
        /// </summary>
        public GetCarrierServiceInformationResponsev21()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="GetCarrierServiceInformationResponsev21"/> class.
        /// </summary>
        /// <param name="carrierServiceList">carrierServiceList.</param>
        /// <param name="error">error.</param>
        public GetCarrierServiceInformationResponsev21(
            List<Models.CarrierInformation> carrierServiceList,
            Models.RequestError error = null)
        {
            this.CarrierServiceList = carrierServiceList;
            this.Error = error;
        }

        /// <summary>
        /// List of carriers and associated service level details.
        /// </summary>
        [JsonProperty("carrierServiceList")]
        public List<Models.CarrierInformation> CarrierServiceList { get; set; }

        /// <summary>
        /// This information can be used to determine if an error has occurred when a request was processed.
        /// </summary>
        [JsonProperty("error", NullValueHandling = NullValueHandling.Ignore)]
        public Models.RequestError Error { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"GetCarrierServiceInformationResponsev21 : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is GetCarrierServiceInformationResponsev21 other &&
                ((this.CarrierServiceList == null && other.CarrierServiceList == null) || (this.CarrierServiceList?.Equals(other.CarrierServiceList) == true)) &&
                ((this.Error == null && other.Error == null) || (this.Error?.Equals(other.Error) == true));
        }

        /// <inheritdoc/>
        public override int GetHashCode()
        {
            int hashCode = -1974359900;

            if (this.CarrierServiceList != null)
            {
               hashCode += this.CarrierServiceList.GetHashCode();
            }

            if (this.Error != null)
            {
               hashCode += this.Error.GetHashCode();
            }

            return hashCode;
        }

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.CarrierServiceList = {(this.CarrierServiceList == null ? "null" : $"[{string.Join(", ", this.CarrierServiceList)} ]")}");
            toStringOutput.Add($"this.Error = {(this.Error == null ? "null" : this.Error.ToString())}");
        }
    }
}