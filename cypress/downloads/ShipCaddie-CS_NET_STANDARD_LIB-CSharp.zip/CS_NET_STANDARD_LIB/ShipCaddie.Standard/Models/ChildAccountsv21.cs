// <copyright file="ChildAccountsv21.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace ShipCaddie.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using ShipCaddie.Standard;
    using ShipCaddie.Standard.Utilities;

    /// <summary>
    /// ChildAccountsv21.
    /// </summary>
    public class ChildAccountsv21
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ChildAccountsv21"/> class.
        /// </summary>
        public ChildAccountsv21()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ChildAccountsv21"/> class.
        /// </summary>
        /// <param name="clientId">clientId.</param>
        /// <param name="name">name.</param>
        /// <param name="isEnabled">isEnabled.</param>
        public ChildAccountsv21(
            int? clientId = null,
            string name = null,
            bool? isEnabled = null)
        {
            this.ClientId = clientId;
            this.Name = name;
            this.IsEnabled = isEnabled;
        }

        /// <summary>
        /// Gets or sets ClientId.
        /// </summary>
        [JsonProperty("clientId", NullValueHandling = NullValueHandling.Ignore)]
        public int? ClientId { get; set; }

        /// <summary>
        /// Gets or sets Name.
        /// </summary>
        [JsonProperty("name", NullValueHandling = NullValueHandling.Ignore)]
        public string Name { get; set; }

        /// <summary>
        /// Gets or sets IsEnabled.
        /// </summary>
        [JsonProperty("isEnabled", NullValueHandling = NullValueHandling.Ignore)]
        public bool? IsEnabled { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"ChildAccountsv21 : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is ChildAccountsv21 other &&
                ((this.ClientId == null && other.ClientId == null) || (this.ClientId?.Equals(other.ClientId) == true)) &&
                ((this.Name == null && other.Name == null) || (this.Name?.Equals(other.Name) == true)) &&
                ((this.IsEnabled == null && other.IsEnabled == null) || (this.IsEnabled?.Equals(other.IsEnabled) == true));
        }

        /// <inheritdoc/>
        public override int GetHashCode()
        {
            int hashCode = 42566456;

            if (this.ClientId != null)
            {
               hashCode += this.ClientId.GetHashCode();
            }

            if (this.Name != null)
            {
               hashCode += this.Name.GetHashCode();
            }

            if (this.IsEnabled != null)
            {
               hashCode += this.IsEnabled.GetHashCode();
            }

            return hashCode;
        }

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.ClientId = {(this.ClientId == null ? "null" : this.ClientId.ToString())}");
            toStringOutput.Add($"this.Name = {(this.Name == null ? "null" : this.Name == string.Empty ? "" : this.Name)}");
            toStringOutput.Add($"this.IsEnabled = {(this.IsEnabled == null ? "null" : this.IsEnabled.ToString())}");
        }
    }
}