// <copyright file="SignatureEnum.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace ShipCaddie.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Runtime.Serialization;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using ShipCaddie.Standard;
    using ShipCaddie.Standard.Utilities;

    /// <summary>
    /// SignatureEnum.
    /// </summary>
    [JsonConverter(typeof(StringEnumConverter))]
    public enum SignatureEnum
    {
        /// <summary>
        /// NOTAPPLICABLE.
        /// </summary>
        [EnumMember(Value = "NOT_APPLICABLE")]
        NOTAPPLICABLE,

        /// <summary>
        /// SIGNATUREADULT.
        /// </summary>
        [EnumMember(Value = "SIGNATURE_ADULT")]
        SIGNATUREADULT,

        /// <summary>
        /// SIGNATUREADULTRESTRICTED.
        /// </summary>
        [EnumMember(Value = "SIGNATURE_ADULT_RESTRICTED")]
        SIGNATUREADULTRESTRICTED,

        /// <summary>
        /// SIGNATUREREQUIRED.
        /// </summary>
        [EnumMember(Value = "SIGNATURE_REQUIRED")]
        SIGNATUREREQUIRED,

        /// <summary>
        /// SIGNATURENOREQUIRED.
        /// </summary>
        [EnumMember(Value = "SIGNATURE_NO_REQUIRED")]
        SIGNATURENOREQUIRED,

        /// <summary>
        /// SIGNATUREDIRECT.
        /// </summary>
        [EnumMember(Value = "SIGNATURE_DIRECT")]
        SIGNATUREDIRECT,

        /// <summary>
        /// SIGNATUREINDIRECT.
        /// </summary>
        [EnumMember(Value = "SIGNATURE_INDIRECT")]
        SIGNATUREINDIRECT,
    }
}