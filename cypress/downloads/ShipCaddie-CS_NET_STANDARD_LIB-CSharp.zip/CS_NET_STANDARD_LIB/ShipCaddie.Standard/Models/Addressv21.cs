// <copyright file="Addressv21.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace ShipCaddie.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using ShipCaddie.Standard;
    using ShipCaddie.Standard.Utilities;

    /// <summary>
    /// Addressv21.
    /// </summary>
    public class Addressv21
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="Addressv21"/> class.
        /// </summary>
        public Addressv21()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="Addressv21"/> class.
        /// </summary>
        /// <param name="address1">address1.</param>
        /// <param name="city">city.</param>
        /// <param name="countryCode">countryCode.</param>
        /// <param name="stateOrProvidence">stateOrProvidence.</param>
        /// <param name="postalCode">postalCode.</param>
        /// <param name="address2">address2.</param>
        /// <param name="isResidential">isResidential.</param>
        /// <param name="attentionOf">attentionOf.</param>
        /// <param name="companyName">companyName.</param>
        /// <param name="email">email.</param>
        /// <param name="phoneNumber">phoneNumber.</param>
        public Addressv21(
            string address1,
            string city,
            string countryCode,
            string stateOrProvidence,
            string postalCode,
            string address2 = null,
            bool? isResidential = null,
            string attentionOf = null,
            string companyName = null,
            string email = null,
            string phoneNumber = null)
        {
            this.Address1 = address1;
            this.Address2 = address2;
            this.City = city;
            this.CountryCode = countryCode;
            this.StateOrProvidence = stateOrProvidence;
            this.PostalCode = postalCode;
            this.IsResidential = isResidential;
            this.AttentionOf = attentionOf;
            this.CompanyName = companyName;
            this.Email = email;
            this.PhoneNumber = phoneNumber;
        }

        /// <summary>
        /// Required
        /// </summary>
        [JsonProperty("address1")]
        public string Address1 { get; set; }

        /// <summary>
        /// Optional
        /// </summary>
        [JsonProperty("address2", NullValueHandling = NullValueHandling.Ignore)]
        public string Address2 { get; set; }

        /// <summary>
        /// Required
        /// </summary>
        [JsonProperty("city")]
        public string City { get; set; }

        /// <summary>
        /// Required
        /// </summary>
        [JsonProperty("countryCode")]
        public string CountryCode { get; set; }

        /// <summary>
        /// Required - StateOrProvidence
        /// </summary>
        [JsonProperty("stateOrProvidence")]
        public string StateOrProvidence { get; set; }

        /// <summary>
        /// Required - PostalCode
        /// </summary>
        [JsonProperty("postalCode")]
        public string PostalCode { get; set; }

        /// <summary>
        /// Optional - Is Residencial flag
        /// </summary>
        [JsonProperty("isResidential", NullValueHandling = NullValueHandling.Ignore)]
        public bool? IsResidential { get; set; }

        /// <summary>
        /// Optional - Attention of,
        /// some Carriers will require this parameter to be set
        /// </summary>
        [JsonProperty("attentionOf", NullValueHandling = NullValueHandling.Ignore)]
        public string AttentionOf { get; set; }

        /// <summary>
        /// Optional - Company Name,
        /// some Carriers will require this parameter to be set
        /// </summary>
        [JsonProperty("companyName", NullValueHandling = NullValueHandling.Ignore)]
        public string CompanyName { get; set; }

        /// <summary>
        /// Optional - Email, some Carriers will require this parameter to be set
        /// </summary>
        [JsonProperty("email", NullValueHandling = NullValueHandling.Ignore)]
        public string Email { get; set; }

        /// <summary>
        /// Optional - Phone Number,
        /// some Carriers will require this parameter to be set
        /// </summary>
        [JsonProperty("phoneNumber", NullValueHandling = NullValueHandling.Ignore)]
        public string PhoneNumber { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"Addressv21 : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is Addressv21 other &&
                ((this.Address1 == null && other.Address1 == null) || (this.Address1?.Equals(other.Address1) == true)) &&
                ((this.Address2 == null && other.Address2 == null) || (this.Address2?.Equals(other.Address2) == true)) &&
                ((this.City == null && other.City == null) || (this.City?.Equals(other.City) == true)) &&
                ((this.CountryCode == null && other.CountryCode == null) || (this.CountryCode?.Equals(other.CountryCode) == true)) &&
                ((this.StateOrProvidence == null && other.StateOrProvidence == null) || (this.StateOrProvidence?.Equals(other.StateOrProvidence) == true)) &&
                ((this.PostalCode == null && other.PostalCode == null) || (this.PostalCode?.Equals(other.PostalCode) == true)) &&
                ((this.IsResidential == null && other.IsResidential == null) || (this.IsResidential?.Equals(other.IsResidential) == true)) &&
                ((this.AttentionOf == null && other.AttentionOf == null) || (this.AttentionOf?.Equals(other.AttentionOf) == true)) &&
                ((this.CompanyName == null && other.CompanyName == null) || (this.CompanyName?.Equals(other.CompanyName) == true)) &&
                ((this.Email == null && other.Email == null) || (this.Email?.Equals(other.Email) == true)) &&
                ((this.PhoneNumber == null && other.PhoneNumber == null) || (this.PhoneNumber?.Equals(other.PhoneNumber) == true));
        }

        /// <inheritdoc/>
        public override int GetHashCode()
        {
            int hashCode = -269619949;

            if (this.Address1 != null)
            {
               hashCode += this.Address1.GetHashCode();
            }

            if (this.Address2 != null)
            {
               hashCode += this.Address2.GetHashCode();
            }

            if (this.City != null)
            {
               hashCode += this.City.GetHashCode();
            }

            if (this.CountryCode != null)
            {
               hashCode += this.CountryCode.GetHashCode();
            }

            if (this.StateOrProvidence != null)
            {
               hashCode += this.StateOrProvidence.GetHashCode();
            }

            if (this.PostalCode != null)
            {
               hashCode += this.PostalCode.GetHashCode();
            }

            if (this.IsResidential != null)
            {
               hashCode += this.IsResidential.GetHashCode();
            }

            if (this.AttentionOf != null)
            {
               hashCode += this.AttentionOf.GetHashCode();
            }

            if (this.CompanyName != null)
            {
               hashCode += this.CompanyName.GetHashCode();
            }

            if (this.Email != null)
            {
               hashCode += this.Email.GetHashCode();
            }

            if (this.PhoneNumber != null)
            {
               hashCode += this.PhoneNumber.GetHashCode();
            }

            return hashCode;
        }

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.Address1 = {(this.Address1 == null ? "null" : this.Address1 == string.Empty ? "" : this.Address1)}");
            toStringOutput.Add($"this.Address2 = {(this.Address2 == null ? "null" : this.Address2 == string.Empty ? "" : this.Address2)}");
            toStringOutput.Add($"this.City = {(this.City == null ? "null" : this.City == string.Empty ? "" : this.City)}");
            toStringOutput.Add($"this.CountryCode = {(this.CountryCode == null ? "null" : this.CountryCode == string.Empty ? "" : this.CountryCode)}");
            toStringOutput.Add($"this.StateOrProvidence = {(this.StateOrProvidence == null ? "null" : this.StateOrProvidence == string.Empty ? "" : this.StateOrProvidence)}");
            toStringOutput.Add($"this.PostalCode = {(this.PostalCode == null ? "null" : this.PostalCode == string.Empty ? "" : this.PostalCode)}");
            toStringOutput.Add($"this.IsResidential = {(this.IsResidential == null ? "null" : this.IsResidential.ToString())}");
            toStringOutput.Add($"this.AttentionOf = {(this.AttentionOf == null ? "null" : this.AttentionOf == string.Empty ? "" : this.AttentionOf)}");
            toStringOutput.Add($"this.CompanyName = {(this.CompanyName == null ? "null" : this.CompanyName == string.Empty ? "" : this.CompanyName)}");
            toStringOutput.Add($"this.Email = {(this.Email == null ? "null" : this.Email == string.Empty ? "" : this.Email)}");
            toStringOutput.Add($"this.PhoneNumber = {(this.PhoneNumber == null ? "null" : this.PhoneNumber == string.Empty ? "" : this.PhoneNumber)}");
        }
    }
}