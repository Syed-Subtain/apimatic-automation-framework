// <copyright file="GenerateResponsev21.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace ShipCaddie.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using ShipCaddie.Standard;
    using ShipCaddie.Standard.Utilities;

    /// <summary>
    /// GenerateResponsev21.
    /// </summary>
    public class GenerateResponsev21
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="GenerateResponsev21"/> class.
        /// </summary>
        public GenerateResponsev21()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="GenerateResponsev21"/> class.
        /// </summary>
        /// <param name="error">error.</param>
        /// <param name="scanFormInformation">scanFormInformation.</param>
        public GenerateResponsev21(
            Models.RequestError error = null,
            Models.ScanFormModel scanFormInformation = null)
        {
            this.Error = error;
            this.ScanFormInformation = scanFormInformation;
        }

        /// <summary>
        /// This information can be used to determine if an error has occurred when a request was processed.
        /// </summary>
        [JsonProperty("error", NullValueHandling = NullValueHandling.Ignore)]
        public Models.RequestError Error { get; set; }

        /// <summary>
        /// Gets or sets ScanFormInformation.
        /// </summary>
        [JsonProperty("scanFormInformation", NullValueHandling = NullValueHandling.Ignore)]
        public Models.ScanFormModel ScanFormInformation { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"GenerateResponsev21 : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is GenerateResponsev21 other &&
                ((this.Error == null && other.Error == null) || (this.Error?.Equals(other.Error) == true)) &&
                ((this.ScanFormInformation == null && other.ScanFormInformation == null) || (this.ScanFormInformation?.Equals(other.ScanFormInformation) == true));
        }

        /// <inheritdoc/>
        public override int GetHashCode()
        {
            int hashCode = -1400934218;

            if (this.Error != null)
            {
               hashCode += this.Error.GetHashCode();
            }

            if (this.ScanFormInformation != null)
            {
               hashCode += this.ScanFormInformation.GetHashCode();
            }

            return hashCode;
        }

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.Error = {(this.Error == null ? "null" : this.Error.ToString())}");
            toStringOutput.Add($"this.ScanFormInformation = {(this.ScanFormInformation == null ? "null" : this.ScanFormInformation.ToString())}");
        }
    }
}