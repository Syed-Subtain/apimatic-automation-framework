// <copyright file="RegisterAccountResponsev21.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace ShipCaddie.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using ShipCaddie.Standard;
    using ShipCaddie.Standard.Utilities;

    /// <summary>
    /// RegisterAccountResponsev21.
    /// </summary>
    public class RegisterAccountResponsev21
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="RegisterAccountResponsev21"/> class.
        /// </summary>
        public RegisterAccountResponsev21()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="RegisterAccountResponsev21"/> class.
        /// </summary>
        /// <param name="error">error.</param>
        /// <param name="success">success.</param>
        public RegisterAccountResponsev21(
            Models.RequestError error = null,
            bool? success = null)
        {
            this.Error = error;
            this.Success = success;
        }

        /// <summary>
        /// This information can be used to determine if an error has occurred when a request was processed.
        /// </summary>
        [JsonProperty("error", NullValueHandling = NullValueHandling.Ignore)]
        public Models.RequestError Error { get; set; }

        /// <summary>
        /// Gets or sets Success.
        /// </summary>
        [JsonProperty("success", NullValueHandling = NullValueHandling.Ignore)]
        public bool? Success { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"RegisterAccountResponsev21 : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is RegisterAccountResponsev21 other &&
                ((this.Error == null && other.Error == null) || (this.Error?.Equals(other.Error) == true)) &&
                ((this.Success == null && other.Success == null) || (this.Success?.Equals(other.Success) == true));
        }

        /// <inheritdoc/>
        public override int GetHashCode()
        {
            int hashCode = -766735460;

            if (this.Error != null)
            {
               hashCode += this.Error.GetHashCode();
            }

            if (this.Success != null)
            {
               hashCode += this.Success.GetHashCode();
            }

            return hashCode;
        }

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.Error = {(this.Error == null ? "null" : this.Error.ToString())}");
            toStringOutput.Add($"this.Success = {(this.Success == null ? "null" : this.Success.ToString())}");
        }
    }
}