// <copyright file="DataBlock.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace ShipCaddie.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using ShipCaddie.Standard;
    using ShipCaddie.Standard.Utilities;

    /// <summary>
    /// DataBlock.
    /// </summary>
    public class DataBlock
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="DataBlock"/> class.
        /// </summary>
        public DataBlock()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="DataBlock"/> class.
        /// </summary>
        /// <param name="dataSourceName">dataSourceName.</param>
        /// <param name="type">type.</param>
        /// <param name="data">data.</param>
        /// <param name="dataURI">dataURI.</param>
        public DataBlock(
            string dataSourceName = null,
            string type = null,
            string data = null,
            string dataURI = null)
        {
            this.DataSourceName = dataSourceName;
            this.Type = type;
            this.Data = data;
            this.DataURI = dataURI;
        }

        /// <summary>
        /// Gets or sets DataSourceName.
        /// </summary>
        [JsonProperty("dataSourceName", NullValueHandling = NullValueHandling.Ignore)]
        public string DataSourceName { get; set; }

        /// <summary>
        /// Gets or sets Type.
        /// </summary>
        [JsonProperty("type", NullValueHandling = NullValueHandling.Ignore)]
        public string Type { get; set; }

        /// <summary>
        /// Gets or sets Data.
        /// </summary>
        [JsonProperty("data", NullValueHandling = NullValueHandling.Ignore)]
        public string Data { get; set; }

        /// <summary>
        /// Gets or sets DataURI.
        /// </summary>
        [JsonProperty("dataURI", NullValueHandling = NullValueHandling.Ignore)]
        public string DataURI { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"DataBlock : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is DataBlock other &&
                ((this.DataSourceName == null && other.DataSourceName == null) || (this.DataSourceName?.Equals(other.DataSourceName) == true)) &&
                ((this.Type == null && other.Type == null) || (this.Type?.Equals(other.Type) == true)) &&
                ((this.Data == null && other.Data == null) || (this.Data?.Equals(other.Data) == true)) &&
                ((this.DataURI == null && other.DataURI == null) || (this.DataURI?.Equals(other.DataURI) == true));
        }

        /// <inheritdoc/>
        public override int GetHashCode()
        {
            int hashCode = -1882251099;

            if (this.DataSourceName != null)
            {
               hashCode += this.DataSourceName.GetHashCode();
            }

            if (this.Type != null)
            {
               hashCode += this.Type.GetHashCode();
            }

            if (this.Data != null)
            {
               hashCode += this.Data.GetHashCode();
            }

            if (this.DataURI != null)
            {
               hashCode += this.DataURI.GetHashCode();
            }

            return hashCode;
        }

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.DataSourceName = {(this.DataSourceName == null ? "null" : this.DataSourceName == string.Empty ? "" : this.DataSourceName)}");
            toStringOutput.Add($"this.Type = {(this.Type == null ? "null" : this.Type == string.Empty ? "" : this.Type)}");
            toStringOutput.Add($"this.Data = {(this.Data == null ? "null" : this.Data == string.Empty ? "" : this.Data)}");
            toStringOutput.Add($"this.DataURI = {(this.DataURI == null ? "null" : this.DataURI == string.Empty ? "" : this.DataURI)}");
        }
    }
}