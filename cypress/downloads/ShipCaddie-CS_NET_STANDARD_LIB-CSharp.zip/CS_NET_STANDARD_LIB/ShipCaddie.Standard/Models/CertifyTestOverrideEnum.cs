// <copyright file="CertifyTestOverrideEnum.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace ShipCaddie.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Runtime.Serialization;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using ShipCaddie.Standard;
    using ShipCaddie.Standard.Utilities;

    /// <summary>
    /// CertifyTestOverrideEnum.
    /// </summary>
    [JsonConverter(typeof(StringEnumConverter))]
    public enum CertifyTestOverrideEnum
    {
        /// <summary>
        /// Contract.
        /// </summary>
        [EnumMember(Value = "Contract")]
        Contract,

        /// <summary>
        /// ForceLive.
        /// </summary>
        [EnumMember(Value = "ForceLive")]
        ForceLive,

        /// <summary>
        /// ForceTest.
        /// </summary>
        [EnumMember(Value = "ForceTest")]
        ForceTest,
    }
}