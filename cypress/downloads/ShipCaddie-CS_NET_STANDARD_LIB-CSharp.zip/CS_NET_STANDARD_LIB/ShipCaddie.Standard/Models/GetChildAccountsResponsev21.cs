// <copyright file="GetChildAccountsResponsev21.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace ShipCaddie.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using ShipCaddie.Standard;
    using ShipCaddie.Standard.Utilities;

    /// <summary>
    /// GetChildAccountsResponsev21.
    /// </summary>
    public class GetChildAccountsResponsev21
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="GetChildAccountsResponsev21"/> class.
        /// </summary>
        public GetChildAccountsResponsev21()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="GetChildAccountsResponsev21"/> class.
        /// </summary>
        /// <param name="error">error.</param>
        /// <param name="childAccounts">childAccounts.</param>
        public GetChildAccountsResponsev21(
            Models.RequestError error = null,
            List<Models.ChildAccountsv21> childAccounts = null)
        {
            this.Error = error;
            this.ChildAccounts = childAccounts;
        }

        /// <summary>
        /// This information can be used to determine if an error has occurred when a request was processed.
        /// </summary>
        [JsonProperty("error", NullValueHandling = NullValueHandling.Ignore)]
        public Models.RequestError Error { get; set; }

        /// <summary>
        /// List of associated child accounts
        /// </summary>
        [JsonProperty("childAccounts", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.ChildAccountsv21> ChildAccounts { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"GetChildAccountsResponsev21 : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is GetChildAccountsResponsev21 other &&
                ((this.Error == null && other.Error == null) || (this.Error?.Equals(other.Error) == true)) &&
                ((this.ChildAccounts == null && other.ChildAccounts == null) || (this.ChildAccounts?.Equals(other.ChildAccounts) == true));
        }

        /// <inheritdoc/>
        public override int GetHashCode()
        {
            int hashCode = 1427182603;

            if (this.Error != null)
            {
               hashCode += this.Error.GetHashCode();
            }

            if (this.ChildAccounts != null)
            {
               hashCode += this.ChildAccounts.GetHashCode();
            }

            return hashCode;
        }

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.Error = {(this.Error == null ? "null" : this.Error.ToString())}");
            toStringOutput.Add($"this.ChildAccounts = {(this.ChildAccounts == null ? "null" : $"[{string.Join(", ", this.ChildAccounts)} ]")}");
        }
    }
}