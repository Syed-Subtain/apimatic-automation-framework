// <copyright file="ShippingCostsPerCarrier.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace ShipCaddie.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using ShipCaddie.Standard;
    using ShipCaddie.Standard.Utilities;

    /// <summary>
    /// ShippingCostsPerCarrier.
    /// </summary>
    public class ShippingCostsPerCarrier
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ShippingCostsPerCarrier"/> class.
        /// </summary>
        public ShippingCostsPerCarrier()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ShippingCostsPerCarrier"/> class.
        /// </summary>
        /// <param name="serviceLevelName">serviceLevelName.</param>
        /// <param name="serviceLevelID">serviceLevelID.</param>
        /// <param name="parcelChargeDetails">parcelChargeDetails.</param>
        /// <param name="shippingChargeDetails">shippingChargeDetails.</param>
        /// <param name="transitDaysMin">transitDaysMin.</param>
        /// <param name="transitDaysMax">transitDaysMax.</param>
        /// <param name="totalChargeAmount">totalChargeAmount.</param>
        /// <param name="totalChargeAmount3pl">totalChargeAmount3pl.</param>
        /// <param name="deliveryDateTime">deliveryDateTime.</param>
        /// <param name="isDeliveryGuaranteed">isDeliveryGuaranteed.</param>
        /// <param name="zoneName">zoneName.</param>
        /// <param name="totalChargeAmountDisplay">TotalChargeAmountDisplay.</param>
        public ShippingCostsPerCarrier(
            string serviceLevelName = null,
            int? serviceLevelID = null,
            List<Models.ParcelCharges> parcelChargeDetails = null,
            List<Models.CostDetail> shippingChargeDetails = null,
            int? transitDaysMin = null,
            int? transitDaysMax = null,
            double? totalChargeAmount = null,
            double? totalChargeAmount3pl = null,
            string deliveryDateTime = null,
            bool? isDeliveryGuaranteed = null,
            string zoneName = null,
            double? totalChargeAmountDisplay = null)
        {
            this.ServiceLevelName = serviceLevelName;
            this.ServiceLevelID = serviceLevelID;
            this.ParcelChargeDetails = parcelChargeDetails;
            this.ShippingChargeDetails = shippingChargeDetails;
            this.TransitDaysMin = transitDaysMin;
            this.TransitDaysMax = transitDaysMax;
            this.TotalChargeAmount = totalChargeAmount;
            this.TotalChargeAmount3pl = totalChargeAmount3pl;
            this.DeliveryDateTime = deliveryDateTime;
            this.IsDeliveryGuaranteed = isDeliveryGuaranteed;
            this.ZoneName = zoneName;
            this.TotalChargeAmountDisplay = totalChargeAmountDisplay;
        }

        /// <summary>
        /// Gets or sets ServiceLevelName.
        /// </summary>
        [JsonProperty("serviceLevelName", NullValueHandling = NullValueHandling.Ignore)]
        public string ServiceLevelName { get; set; }

        /// <summary>
        /// Gets or sets ServiceLevelID.
        /// </summary>
        [JsonProperty("serviceLevelID", NullValueHandling = NullValueHandling.Ignore)]
        public int? ServiceLevelID { get; set; }

        /// <summary>
        /// Shipping charges relating to individual parcels.
        /// </summary>
        [JsonProperty("parcelChargeDetails", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.ParcelCharges> ParcelChargeDetails { get; set; }

        /// <summary>
        /// Shipping charges relating to a shipment as a whole.
        /// </summary>
        [JsonProperty("shippingChargeDetails", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.CostDetail> ShippingChargeDetails { get; set; }

        /// <summary>
        /// The Days in transit as defined by the carrier for the service level chosen.
        ///                 The number may or may not include non-business days.
        /// </summary>
        [JsonProperty("transitDaysMin", NullValueHandling = NullValueHandling.Ignore)]
        public int? TransitDaysMin { get; set; }

        /// <summary>
        /// The Days in transit as defined by the carrier for the service level chosen.
        ///                 The number may or may not include non-business days.
        /// </summary>
        [JsonProperty("transitDaysMax", NullValueHandling = NullValueHandling.Ignore)]
        public int? TransitDaysMax { get; set; }

        /// <summary>
        /// Gets or sets TotalChargeAmount.
        /// </summary>
        [JsonProperty("totalChargeAmount", NullValueHandling = NullValueHandling.Ignore)]
        public double? TotalChargeAmount { get; set; }

        /// <summary>
        /// The total charge of this shipment.
        ///                 This is the sum of all accessorialCharges.chargeAmount3pl fields in all packages
        /// </summary>
        [JsonProperty("totalChargeAmount3pl", NullValueHandling = NullValueHandling.Ignore)]
        public double? TotalChargeAmount3pl { get; set; }

        /// <summary>
        /// Gets or sets DeliveryDateTime.
        /// </summary>
        [JsonProperty("deliveryDateTime", NullValueHandling = NullValueHandling.Ignore)]
        public string DeliveryDateTime { get; set; }

        /// <summary>
        /// Gets or sets IsDeliveryGuaranteed.
        /// </summary>
        [JsonProperty("isDeliveryGuaranteed", NullValueHandling = NullValueHandling.Ignore)]
        public bool? IsDeliveryGuaranteed { get; set; }

        /// <summary>
        /// Gets or sets ZoneName.
        /// </summary>
        [JsonProperty("zoneName", NullValueHandling = NullValueHandling.Ignore)]
        public string ZoneName { get; set; }

        /// <summary>
        /// Gets or Sets ZoneName
        /// </summary>
        [JsonProperty("TotalChargeAmountDisplay", NullValueHandling = NullValueHandling.Ignore)]
        public double? TotalChargeAmountDisplay { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"ShippingCostsPerCarrier : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is ShippingCostsPerCarrier other &&
                ((this.ServiceLevelName == null && other.ServiceLevelName == null) || (this.ServiceLevelName?.Equals(other.ServiceLevelName) == true)) &&
                ((this.ServiceLevelID == null && other.ServiceLevelID == null) || (this.ServiceLevelID?.Equals(other.ServiceLevelID) == true)) &&
                ((this.ParcelChargeDetails == null && other.ParcelChargeDetails == null) || (this.ParcelChargeDetails?.Equals(other.ParcelChargeDetails) == true)) &&
                ((this.ShippingChargeDetails == null && other.ShippingChargeDetails == null) || (this.ShippingChargeDetails?.Equals(other.ShippingChargeDetails) == true)) &&
                ((this.TransitDaysMin == null && other.TransitDaysMin == null) || (this.TransitDaysMin?.Equals(other.TransitDaysMin) == true)) &&
                ((this.TransitDaysMax == null && other.TransitDaysMax == null) || (this.TransitDaysMax?.Equals(other.TransitDaysMax) == true)) &&
                ((this.TotalChargeAmount == null && other.TotalChargeAmount == null) || (this.TotalChargeAmount?.Equals(other.TotalChargeAmount) == true)) &&
                ((this.TotalChargeAmount3pl == null && other.TotalChargeAmount3pl == null) || (this.TotalChargeAmount3pl?.Equals(other.TotalChargeAmount3pl) == true)) &&
                ((this.DeliveryDateTime == null && other.DeliveryDateTime == null) || (this.DeliveryDateTime?.Equals(other.DeliveryDateTime) == true)) &&
                ((this.IsDeliveryGuaranteed == null && other.IsDeliveryGuaranteed == null) || (this.IsDeliveryGuaranteed?.Equals(other.IsDeliveryGuaranteed) == true)) &&
                ((this.ZoneName == null && other.ZoneName == null) || (this.ZoneName?.Equals(other.ZoneName) == true)) &&
                ((this.TotalChargeAmountDisplay == null && other.TotalChargeAmountDisplay == null) || (this.TotalChargeAmountDisplay?.Equals(other.TotalChargeAmountDisplay) == true));
        }

        /// <inheritdoc/>
        public override int GetHashCode()
        {
            int hashCode = -570604951;

            if (this.ServiceLevelName != null)
            {
               hashCode += this.ServiceLevelName.GetHashCode();
            }

            if (this.ServiceLevelID != null)
            {
               hashCode += this.ServiceLevelID.GetHashCode();
            }

            if (this.ParcelChargeDetails != null)
            {
               hashCode += this.ParcelChargeDetails.GetHashCode();
            }

            if (this.ShippingChargeDetails != null)
            {
               hashCode += this.ShippingChargeDetails.GetHashCode();
            }

            if (this.TransitDaysMin != null)
            {
               hashCode += this.TransitDaysMin.GetHashCode();
            }

            if (this.TransitDaysMax != null)
            {
               hashCode += this.TransitDaysMax.GetHashCode();
            }

            if (this.TotalChargeAmount != null)
            {
               hashCode += this.TotalChargeAmount.GetHashCode();
            }

            if (this.TotalChargeAmount3pl != null)
            {
               hashCode += this.TotalChargeAmount3pl.GetHashCode();
            }

            if (this.DeliveryDateTime != null)
            {
               hashCode += this.DeliveryDateTime.GetHashCode();
            }

            if (this.IsDeliveryGuaranteed != null)
            {
               hashCode += this.IsDeliveryGuaranteed.GetHashCode();
            }

            if (this.ZoneName != null)
            {
               hashCode += this.ZoneName.GetHashCode();
            }

            if (this.TotalChargeAmountDisplay != null)
            {
               hashCode += this.TotalChargeAmountDisplay.GetHashCode();
            }

            return hashCode;
        }

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.ServiceLevelName = {(this.ServiceLevelName == null ? "null" : this.ServiceLevelName == string.Empty ? "" : this.ServiceLevelName)}");
            toStringOutput.Add($"this.ServiceLevelID = {(this.ServiceLevelID == null ? "null" : this.ServiceLevelID.ToString())}");
            toStringOutput.Add($"this.ParcelChargeDetails = {(this.ParcelChargeDetails == null ? "null" : $"[{string.Join(", ", this.ParcelChargeDetails)} ]")}");
            toStringOutput.Add($"this.ShippingChargeDetails = {(this.ShippingChargeDetails == null ? "null" : $"[{string.Join(", ", this.ShippingChargeDetails)} ]")}");
            toStringOutput.Add($"this.TransitDaysMin = {(this.TransitDaysMin == null ? "null" : this.TransitDaysMin.ToString())}");
            toStringOutput.Add($"this.TransitDaysMax = {(this.TransitDaysMax == null ? "null" : this.TransitDaysMax.ToString())}");
            toStringOutput.Add($"this.TotalChargeAmount = {(this.TotalChargeAmount == null ? "null" : this.TotalChargeAmount.ToString())}");
            toStringOutput.Add($"this.TotalChargeAmount3pl = {(this.TotalChargeAmount3pl == null ? "null" : this.TotalChargeAmount3pl.ToString())}");
            toStringOutput.Add($"this.DeliveryDateTime = {(this.DeliveryDateTime == null ? "null" : this.DeliveryDateTime == string.Empty ? "" : this.DeliveryDateTime)}");
            toStringOutput.Add($"this.IsDeliveryGuaranteed = {(this.IsDeliveryGuaranteed == null ? "null" : this.IsDeliveryGuaranteed.ToString())}");
            toStringOutput.Add($"this.ZoneName = {(this.ZoneName == null ? "null" : this.ZoneName == string.Empty ? "" : this.ZoneName)}");
            toStringOutput.Add($"this.TotalChargeAmountDisplay = {(this.TotalChargeAmountDisplay == null ? "null" : this.TotalChargeAmountDisplay.ToString())}");
        }
    }
}