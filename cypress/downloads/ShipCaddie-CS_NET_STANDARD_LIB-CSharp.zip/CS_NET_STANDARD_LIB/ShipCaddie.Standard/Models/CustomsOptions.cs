// <copyright file="CustomsOptions.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace ShipCaddie.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using ShipCaddie.Standard;
    using ShipCaddie.Standard.Utilities;

    /// <summary>
    /// CustomsOptions.
    /// </summary>
    public class CustomsOptions
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="CustomsOptions"/> class.
        /// </summary>
        public CustomsOptions()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="CustomsOptions"/> class.
        /// </summary>
        /// <param name="isAPOFPODPOUSTerritory">isAPO_FPO_DPO_USTerritory.</param>
        /// <param name="isInternationalShipment">isInternationalShipment.</param>
        /// <param name="shipmentContentType">shipmentContentType.</param>
        public CustomsOptions(
            bool? isAPOFPODPOUSTerritory = null,
            bool? isInternationalShipment = null,
            Models.ShipmentContentTypeEnum? shipmentContentType = null)
        {
            this.IsAPOFPODPOUSTerritory = isAPOFPODPOUSTerritory;
            this.IsInternationalShipment = isInternationalShipment;
            this.ShipmentContentType = shipmentContentType;
        }

        /// <summary>
        /// Set this to true if shipping to:
        /// * Army Post Office
        /// * Fleet Post Office
        /// * Diplomatic Post Office
        /// * US Territories
        /// Default value is false.
        /// </summary>
        [JsonProperty("isAPO_FPO_DPO_USTerritory", NullValueHandling = NullValueHandling.Ignore)]
        public bool? IsAPOFPODPOUSTerritory { get; set; }

        /// <summary>
        /// Specifies if this shipment is an international shipment.
        ///  Default is false.
        /// </summary>
        [JsonProperty("isInternationalShipment", NullValueHandling = NullValueHandling.Ignore)]
        public bool? IsInternationalShipment { get; set; }

        /// <summary>
        /// Indicates the type of content that is in the parcels.
        /// Will be used for customs declarations if shipping internationally.
        /// </summary>
        [JsonProperty("shipmentContentType", ItemConverterType = typeof(StringEnumConverter), NullValueHandling = NullValueHandling.Ignore)]
        public Models.ShipmentContentTypeEnum? ShipmentContentType { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"CustomsOptions : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is CustomsOptions other &&
                ((this.IsAPOFPODPOUSTerritory == null && other.IsAPOFPODPOUSTerritory == null) || (this.IsAPOFPODPOUSTerritory?.Equals(other.IsAPOFPODPOUSTerritory) == true)) &&
                ((this.IsInternationalShipment == null && other.IsInternationalShipment == null) || (this.IsInternationalShipment?.Equals(other.IsInternationalShipment) == true)) &&
                ((this.ShipmentContentType == null && other.ShipmentContentType == null) || (this.ShipmentContentType?.Equals(other.ShipmentContentType) == true));
        }

        /// <inheritdoc/>
        public override int GetHashCode()
        {
            int hashCode = -714955027;

            if (this.IsAPOFPODPOUSTerritory != null)
            {
               hashCode += this.IsAPOFPODPOUSTerritory.GetHashCode();
            }

            if (this.IsInternationalShipment != null)
            {
               hashCode += this.IsInternationalShipment.GetHashCode();
            }

            if (this.ShipmentContentType != null)
            {
               hashCode += this.ShipmentContentType.GetHashCode();
            }

            return hashCode;
        }

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.IsAPOFPODPOUSTerritory = {(this.IsAPOFPODPOUSTerritory == null ? "null" : this.IsAPOFPODPOUSTerritory.ToString())}");
            toStringOutput.Add($"this.IsInternationalShipment = {(this.IsInternationalShipment == null ? "null" : this.IsInternationalShipment.ToString())}");
            toStringOutput.Add($"this.ShipmentContentType = {(this.ShipmentContentType == null ? "null" : this.ShipmentContentType.ToString())}");
        }
    }
}