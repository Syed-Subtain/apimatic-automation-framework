// <copyright file="AvailableShipment.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace ShipCaddie.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using ShipCaddie.Standard;
    using ShipCaddie.Standard.Utilities;

    /// <summary>
    /// AvailableShipment.
    /// </summary>
    public class AvailableShipment
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="AvailableShipment"/> class.
        /// </summary>
        public AvailableShipment()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="AvailableShipment"/> class.
        /// </summary>
        /// <param name="carrierClientContractId">carrierClientContractId.</param>
        /// <param name="shipmentId">shipmentId.</param>
        /// <param name="packageId">packageId.</param>
        /// <param name="shipmentClientAddressId">shipmentClientAddressId.</param>
        /// <param name="dateShipped">dateShipped.</param>
        /// <param name="fromShippingSiteName">fromShippingSiteName.</param>
        /// <param name="toAddressLine1">toAddressLine1.</param>
        /// <param name="toAddressLine2">toAddressLine2.</param>
        /// <param name="toPostalCode">toPostalCode.</param>
        /// <param name="toProvince">toProvince.</param>
        /// <param name="toCity">toCity.</param>
        /// <param name="accountAlias">accountAlias.</param>
        /// <param name="labelKey">labelKey.</param>
        /// <param name="trackingNumber">trackingNumber.</param>
        public AvailableShipment(
            int? carrierClientContractId = null,
            int? shipmentId = null,
            int? packageId = null,
            int? shipmentClientAddressId = null,
            DateTime? dateShipped = null,
            string fromShippingSiteName = null,
            string toAddressLine1 = null,
            string toAddressLine2 = null,
            string toPostalCode = null,
            string toProvince = null,
            string toCity = null,
            string accountAlias = null,
            string labelKey = null,
            string trackingNumber = null)
        {
            this.CarrierClientContractId = carrierClientContractId;
            this.ShipmentId = shipmentId;
            this.PackageId = packageId;
            this.ShipmentClientAddressId = shipmentClientAddressId;
            this.DateShipped = dateShipped;
            this.FromShippingSiteName = fromShippingSiteName;
            this.ToAddressLine1 = toAddressLine1;
            this.ToAddressLine2 = toAddressLine2;
            this.ToPostalCode = toPostalCode;
            this.ToProvince = toProvince;
            this.ToCity = toCity;
            this.AccountAlias = accountAlias;
            this.LabelKey = labelKey;
            this.TrackingNumber = trackingNumber;
        }

        /// <summary>
        /// Gets or sets CarrierClientContractId.
        /// </summary>
        [JsonProperty("carrierClientContractId", NullValueHandling = NullValueHandling.Ignore)]
        public int? CarrierClientContractId { get; set; }

        /// <summary>
        /// Gets or sets ShipmentId.
        /// </summary>
        [JsonProperty("shipmentId", NullValueHandling = NullValueHandling.Ignore)]
        public int? ShipmentId { get; set; }

        /// <summary>
        /// Gets or sets PackageId.
        /// </summary>
        [JsonProperty("packageId", NullValueHandling = NullValueHandling.Ignore)]
        public int? PackageId { get; set; }

        /// <summary>
        /// Gets or sets ShipmentClientAddressId.
        /// </summary>
        [JsonProperty("shipmentClientAddressId", NullValueHandling = NullValueHandling.Ignore)]
        public int? ShipmentClientAddressId { get; set; }

        /// <summary>
        /// Gets or sets DateShipped.
        /// </summary>
        [JsonConverter(typeof(IsoDateTimeConverter))]
        [JsonProperty("dateShipped", NullValueHandling = NullValueHandling.Ignore)]
        public DateTime? DateShipped { get; set; }

        /// <summary>
        /// Gets or sets FromShippingSiteName.
        /// </summary>
        [JsonProperty("fromShippingSiteName", NullValueHandling = NullValueHandling.Ignore)]
        public string FromShippingSiteName { get; set; }

        /// <summary>
        /// Gets or sets ToAddressLine1.
        /// </summary>
        [JsonProperty("toAddressLine1", NullValueHandling = NullValueHandling.Ignore)]
        public string ToAddressLine1 { get; set; }

        /// <summary>
        /// Gets or sets ToAddressLine2.
        /// </summary>
        [JsonProperty("toAddressLine2", NullValueHandling = NullValueHandling.Ignore)]
        public string ToAddressLine2 { get; set; }

        /// <summary>
        /// Gets or sets ToPostalCode.
        /// </summary>
        [JsonProperty("toPostalCode", NullValueHandling = NullValueHandling.Ignore)]
        public string ToPostalCode { get; set; }

        /// <summary>
        /// Gets or sets ToProvince.
        /// </summary>
        [JsonProperty("toProvince", NullValueHandling = NullValueHandling.Ignore)]
        public string ToProvince { get; set; }

        /// <summary>
        /// Gets or sets ToCity.
        /// </summary>
        [JsonProperty("toCity", NullValueHandling = NullValueHandling.Ignore)]
        public string ToCity { get; set; }

        /// <summary>
        /// Gets or sets AccountAlias.
        /// </summary>
        [JsonProperty("accountAlias", NullValueHandling = NullValueHandling.Ignore)]
        public string AccountAlias { get; set; }

        /// <summary>
        /// Gets or sets LabelKey.
        /// </summary>
        [JsonProperty("labelKey", NullValueHandling = NullValueHandling.Ignore)]
        public string LabelKey { get; set; }

        /// <summary>
        /// Gets or sets TrackingNumber.
        /// </summary>
        [JsonProperty("trackingNumber", NullValueHandling = NullValueHandling.Ignore)]
        public string TrackingNumber { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"AvailableShipment : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is AvailableShipment other &&
                ((this.CarrierClientContractId == null && other.CarrierClientContractId == null) || (this.CarrierClientContractId?.Equals(other.CarrierClientContractId) == true)) &&
                ((this.ShipmentId == null && other.ShipmentId == null) || (this.ShipmentId?.Equals(other.ShipmentId) == true)) &&
                ((this.PackageId == null && other.PackageId == null) || (this.PackageId?.Equals(other.PackageId) == true)) &&
                ((this.ShipmentClientAddressId == null && other.ShipmentClientAddressId == null) || (this.ShipmentClientAddressId?.Equals(other.ShipmentClientAddressId) == true)) &&
                ((this.DateShipped == null && other.DateShipped == null) || (this.DateShipped?.Equals(other.DateShipped) == true)) &&
                ((this.FromShippingSiteName == null && other.FromShippingSiteName == null) || (this.FromShippingSiteName?.Equals(other.FromShippingSiteName) == true)) &&
                ((this.ToAddressLine1 == null && other.ToAddressLine1 == null) || (this.ToAddressLine1?.Equals(other.ToAddressLine1) == true)) &&
                ((this.ToAddressLine2 == null && other.ToAddressLine2 == null) || (this.ToAddressLine2?.Equals(other.ToAddressLine2) == true)) &&
                ((this.ToPostalCode == null && other.ToPostalCode == null) || (this.ToPostalCode?.Equals(other.ToPostalCode) == true)) &&
                ((this.ToProvince == null && other.ToProvince == null) || (this.ToProvince?.Equals(other.ToProvince) == true)) &&
                ((this.ToCity == null && other.ToCity == null) || (this.ToCity?.Equals(other.ToCity) == true)) &&
                ((this.AccountAlias == null && other.AccountAlias == null) || (this.AccountAlias?.Equals(other.AccountAlias) == true)) &&
                ((this.LabelKey == null && other.LabelKey == null) || (this.LabelKey?.Equals(other.LabelKey) == true)) &&
                ((this.TrackingNumber == null && other.TrackingNumber == null) || (this.TrackingNumber?.Equals(other.TrackingNumber) == true));
        }

        /// <inheritdoc/>
        public override int GetHashCode()
        {
            int hashCode = -1965888238;

            if (this.CarrierClientContractId != null)
            {
               hashCode += this.CarrierClientContractId.GetHashCode();
            }

            if (this.ShipmentId != null)
            {
               hashCode += this.ShipmentId.GetHashCode();
            }

            if (this.PackageId != null)
            {
               hashCode += this.PackageId.GetHashCode();
            }

            if (this.ShipmentClientAddressId != null)
            {
               hashCode += this.ShipmentClientAddressId.GetHashCode();
            }

            if (this.DateShipped != null)
            {
               hashCode += this.DateShipped.GetHashCode();
            }

            if (this.FromShippingSiteName != null)
            {
               hashCode += this.FromShippingSiteName.GetHashCode();
            }

            if (this.ToAddressLine1 != null)
            {
               hashCode += this.ToAddressLine1.GetHashCode();
            }

            if (this.ToAddressLine2 != null)
            {
               hashCode += this.ToAddressLine2.GetHashCode();
            }

            if (this.ToPostalCode != null)
            {
               hashCode += this.ToPostalCode.GetHashCode();
            }

            if (this.ToProvince != null)
            {
               hashCode += this.ToProvince.GetHashCode();
            }

            if (this.ToCity != null)
            {
               hashCode += this.ToCity.GetHashCode();
            }

            if (this.AccountAlias != null)
            {
               hashCode += this.AccountAlias.GetHashCode();
            }

            if (this.LabelKey != null)
            {
               hashCode += this.LabelKey.GetHashCode();
            }

            if (this.TrackingNumber != null)
            {
               hashCode += this.TrackingNumber.GetHashCode();
            }

            return hashCode;
        }

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.CarrierClientContractId = {(this.CarrierClientContractId == null ? "null" : this.CarrierClientContractId.ToString())}");
            toStringOutput.Add($"this.ShipmentId = {(this.ShipmentId == null ? "null" : this.ShipmentId.ToString())}");
            toStringOutput.Add($"this.PackageId = {(this.PackageId == null ? "null" : this.PackageId.ToString())}");
            toStringOutput.Add($"this.ShipmentClientAddressId = {(this.ShipmentClientAddressId == null ? "null" : this.ShipmentClientAddressId.ToString())}");
            toStringOutput.Add($"this.DateShipped = {(this.DateShipped == null ? "null" : this.DateShipped.ToString())}");
            toStringOutput.Add($"this.FromShippingSiteName = {(this.FromShippingSiteName == null ? "null" : this.FromShippingSiteName == string.Empty ? "" : this.FromShippingSiteName)}");
            toStringOutput.Add($"this.ToAddressLine1 = {(this.ToAddressLine1 == null ? "null" : this.ToAddressLine1 == string.Empty ? "" : this.ToAddressLine1)}");
            toStringOutput.Add($"this.ToAddressLine2 = {(this.ToAddressLine2 == null ? "null" : this.ToAddressLine2 == string.Empty ? "" : this.ToAddressLine2)}");
            toStringOutput.Add($"this.ToPostalCode = {(this.ToPostalCode == null ? "null" : this.ToPostalCode == string.Empty ? "" : this.ToPostalCode)}");
            toStringOutput.Add($"this.ToProvince = {(this.ToProvince == null ? "null" : this.ToProvince == string.Empty ? "" : this.ToProvince)}");
            toStringOutput.Add($"this.ToCity = {(this.ToCity == null ? "null" : this.ToCity == string.Empty ? "" : this.ToCity)}");
            toStringOutput.Add($"this.AccountAlias = {(this.AccountAlias == null ? "null" : this.AccountAlias == string.Empty ? "" : this.AccountAlias)}");
            toStringOutput.Add($"this.LabelKey = {(this.LabelKey == null ? "null" : this.LabelKey == string.Empty ? "" : this.LabelKey)}");
            toStringOutput.Add($"this.TrackingNumber = {(this.TrackingNumber == null ? "null" : this.TrackingNumber == string.Empty ? "" : this.TrackingNumber)}");
        }
    }
}