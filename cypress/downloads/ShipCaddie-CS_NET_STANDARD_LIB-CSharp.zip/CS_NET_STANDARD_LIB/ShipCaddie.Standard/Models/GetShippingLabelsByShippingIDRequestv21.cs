// <copyright file="GetShippingLabelsByShippingIDRequestv21.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace ShipCaddie.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using ShipCaddie.Standard;
    using ShipCaddie.Standard.Utilities;

    /// <summary>
    /// GetShippingLabelsByShippingIDRequestv21.
    /// </summary>
    public class GetShippingLabelsByShippingIDRequestv21
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="GetShippingLabelsByShippingIDRequestv21"/> class.
        /// </summary>
        public GetShippingLabelsByShippingIDRequestv21()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="GetShippingLabelsByShippingIDRequestv21"/> class.
        /// </summary>
        /// <param name="accessToken">accessToken.</param>
        /// <param name="shipmentID">shipmentID.</param>
        /// <param name="printFormat">printFormat.</param>
        /// <param name="asClientId">asClientId.</param>
        /// <param name="certifyTestOverride">certifyTestOverride.</param>
        public GetShippingLabelsByShippingIDRequestv21(
            string accessToken,
            int shipmentID,
            Models.PrintFormatEnum printFormat,
            int? asClientId = null,
            Models.CertifyTestOverrideEnum? certifyTestOverride = null)
        {
            this.AccessToken = accessToken;
            this.AsClientId = asClientId;
            this.ShipmentID = shipmentID;
            this.PrintFormat = printFormat;
            this.CertifyTestOverride = certifyTestOverride;
        }

        /// <summary>
        /// Required.
        /// An authorization token is necessary to call this method.
        /// <remarks>
        /// The token can be obtained by calling the GetToken or RefreshToken methods.
        /// </remarks>
        /// </summary>
        [JsonProperty("accessToken")]
        public string AccessToken { get; set; }

        /// <summary>
        /// Optional.
        /// When empty or null, this field is ignored.
        /// When set, actions will be taken for the client specified by the id.
        /// </summary>
        [JsonProperty("asClientId", NullValueHandling = NullValueHandling.Ignore)]
        public int? AsClientId { get; set; }

        /// <summary>
        /// Shipment identifier.
        /// </summary>
        [JsonProperty("shipmentID")]
        public int ShipmentID { get; set; }

        /// <summary>
        /// Format used for printing labels.
        /// </summary>
        [JsonProperty("printFormat", ItemConverterType = typeof(StringEnumConverter))]
        public Models.PrintFormatEnum PrintFormat { get; set; }

        /// <summary>
        /// CertifyTestOverride : Force a Label to overriding what is in the contract
        /// </summary>
        [JsonProperty("certifyTestOverride", ItemConverterType = typeof(StringEnumConverter), NullValueHandling = NullValueHandling.Ignore)]
        public Models.CertifyTestOverrideEnum? CertifyTestOverride { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"GetShippingLabelsByShippingIDRequestv21 : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is GetShippingLabelsByShippingIDRequestv21 other &&
                ((this.AccessToken == null && other.AccessToken == null) || (this.AccessToken?.Equals(other.AccessToken) == true)) &&
                ((this.AsClientId == null && other.AsClientId == null) || (this.AsClientId?.Equals(other.AsClientId) == true)) &&
                this.ShipmentID.Equals(other.ShipmentID) &&
                this.PrintFormat.Equals(other.PrintFormat) &&
                ((this.CertifyTestOverride == null && other.CertifyTestOverride == null) || (this.CertifyTestOverride?.Equals(other.CertifyTestOverride) == true));
        }

        /// <inheritdoc/>
        public override int GetHashCode()
        {
            int hashCode = 1294974397;

            if (this.AccessToken != null)
            {
               hashCode += this.AccessToken.GetHashCode();
            }

            if (this.AsClientId != null)
            {
               hashCode += this.AsClientId.GetHashCode();
            }

            hashCode += this.ShipmentID.GetHashCode();
            hashCode += this.PrintFormat.GetHashCode();

            if (this.CertifyTestOverride != null)
            {
               hashCode += this.CertifyTestOverride.GetHashCode();
            }

            return hashCode;
        }

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.AccessToken = {(this.AccessToken == null ? "null" : this.AccessToken == string.Empty ? "" : this.AccessToken)}");
            toStringOutput.Add($"this.AsClientId = {(this.AsClientId == null ? "null" : this.AsClientId.ToString())}");
            toStringOutput.Add($"this.ShipmentID = {this.ShipmentID}");
            toStringOutput.Add($"this.PrintFormat = {this.PrintFormat}");
            toStringOutput.Add($"this.CertifyTestOverride = {(this.CertifyTestOverride == null ? "null" : this.CertifyTestOverride.ToString())}");
        }
    }
}