// <copyright file="ShippedInfoParcel.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace ShipCaddie.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using ShipCaddie.Standard;
    using ShipCaddie.Standard.Utilities;

    /// <summary>
    /// ShippedInfoParcel.
    /// </summary>
    public class ShippedInfoParcel
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ShippedInfoParcel"/> class.
        /// </summary>
        public ShippedInfoParcel()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ShippedInfoParcel"/> class.
        /// </summary>
        /// <param name="cost">cost.</param>
        /// <param name="referenceField1">referenceField1.</param>
        /// <param name="referenceField2">referenceField2.</param>
        /// <param name="referenceField3">referenceField3.</param>
        /// <param name="weightInPounds">weightInPounds.</param>
        /// <param name="lengthInInches">lengthInInches.</param>
        /// <param name="widthInInches">widthInInches.</param>
        /// <param name="heightInInches">heightInInches.</param>
        /// <param name="trackingNumber">trackingNumber.</param>
        /// <param name="options">options.</param>
        /// <param name="parcelItems">parcelItems.</param>
        public ShippedInfoParcel(
            double? cost = null,
            string referenceField1 = null,
            string referenceField2 = null,
            string referenceField3 = null,
            double? weightInPounds = null,
            double? lengthInInches = null,
            double? widthInInches = null,
            double? heightInInches = null,
            string trackingNumber = null,
            Models.ParcelOptions options = null,
            List<Models.ParcelContent> parcelItems = null)
        {
            this.Cost = cost;
            this.ReferenceField1 = referenceField1;
            this.ReferenceField2 = referenceField2;
            this.ReferenceField3 = referenceField3;
            this.WeightInPounds = weightInPounds;
            this.LengthInInches = lengthInInches;
            this.WidthInInches = widthInInches;
            this.HeightInInches = heightInInches;
            this.TrackingNumber = trackingNumber;
            this.Options = options;
            this.ParcelItems = parcelItems;
        }

        /// <summary>
        /// The cost of shipping the package
        /// </summary>
        [JsonProperty("cost", NullValueHandling = NullValueHandling.Ignore)]
        public double? Cost { get; set; }

        /// <summary>
        /// Optional - Reference Field 1
        /// </summary>
        [JsonProperty("referenceField1", NullValueHandling = NullValueHandling.Ignore)]
        public string ReferenceField1 { get; set; }

        /// <summary>
        /// Optional - Reference Field 2
        /// </summary>
        [JsonProperty("referenceField2", NullValueHandling = NullValueHandling.Ignore)]
        public string ReferenceField2 { get; set; }

        /// <summary>
        /// Optional - Reference Field 3
        /// </summary>
        [JsonProperty("referenceField3", NullValueHandling = NullValueHandling.Ignore)]
        public string ReferenceField3 { get; set; }

        /// <summary>
        /// Parcel Weight in Pounds.
        /// </summary>
        [JsonProperty("weightInPounds", NullValueHandling = NullValueHandling.Ignore)]
        public double? WeightInPounds { get; set; }

        /// <summary>
        /// Length of one side of parcel in inches.
        /// </summary>
        [JsonProperty("lengthInInches", NullValueHandling = NullValueHandling.Ignore)]
        public double? LengthInInches { get; set; }

        /// <summary>
        /// Width of one side of parcel in inches.
        /// </summary>
        [JsonProperty("widthInInches", NullValueHandling = NullValueHandling.Ignore)]
        public double? WidthInInches { get; set; }

        /// <summary>
        /// Height of one side of parcel in inches.
        /// </summary>
        [JsonProperty("heightInInches", NullValueHandling = NullValueHandling.Ignore)]
        public double? HeightInInches { get; set; }

        /// <summary>
        /// The tracking number of the package.
        /// </summary>
        [JsonProperty("trackingNumber", NullValueHandling = NullValueHandling.Ignore)]
        public string TrackingNumber { get; set; }

        /// <summary>
        /// Specifies additional parcel options such as COD and required Signatures.
        /// </summary>
        [JsonProperty("options", NullValueHandling = NullValueHandling.Ignore)]
        public Models.ParcelOptions Options { get; set; }

        /// <summary>
        /// Type of parcel contents.
        /// </summary>
        [JsonProperty("parcelItems", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.ParcelContent> ParcelItems { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"ShippedInfoParcel : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is ShippedInfoParcel other &&
                ((this.Cost == null && other.Cost == null) || (this.Cost?.Equals(other.Cost) == true)) &&
                ((this.ReferenceField1 == null && other.ReferenceField1 == null) || (this.ReferenceField1?.Equals(other.ReferenceField1) == true)) &&
                ((this.ReferenceField2 == null && other.ReferenceField2 == null) || (this.ReferenceField2?.Equals(other.ReferenceField2) == true)) &&
                ((this.ReferenceField3 == null && other.ReferenceField3 == null) || (this.ReferenceField3?.Equals(other.ReferenceField3) == true)) &&
                ((this.WeightInPounds == null && other.WeightInPounds == null) || (this.WeightInPounds?.Equals(other.WeightInPounds) == true)) &&
                ((this.LengthInInches == null && other.LengthInInches == null) || (this.LengthInInches?.Equals(other.LengthInInches) == true)) &&
                ((this.WidthInInches == null && other.WidthInInches == null) || (this.WidthInInches?.Equals(other.WidthInInches) == true)) &&
                ((this.HeightInInches == null && other.HeightInInches == null) || (this.HeightInInches?.Equals(other.HeightInInches) == true)) &&
                ((this.TrackingNumber == null && other.TrackingNumber == null) || (this.TrackingNumber?.Equals(other.TrackingNumber) == true)) &&
                ((this.Options == null && other.Options == null) || (this.Options?.Equals(other.Options) == true)) &&
                ((this.ParcelItems == null && other.ParcelItems == null) || (this.ParcelItems?.Equals(other.ParcelItems) == true));
        }

        /// <inheritdoc/>
        public override int GetHashCode()
        {
            int hashCode = -1677137280;

            if (this.Cost != null)
            {
               hashCode += this.Cost.GetHashCode();
            }

            if (this.ReferenceField1 != null)
            {
               hashCode += this.ReferenceField1.GetHashCode();
            }

            if (this.ReferenceField2 != null)
            {
               hashCode += this.ReferenceField2.GetHashCode();
            }

            if (this.ReferenceField3 != null)
            {
               hashCode += this.ReferenceField3.GetHashCode();
            }

            if (this.WeightInPounds != null)
            {
               hashCode += this.WeightInPounds.GetHashCode();
            }

            if (this.LengthInInches != null)
            {
               hashCode += this.LengthInInches.GetHashCode();
            }

            if (this.WidthInInches != null)
            {
               hashCode += this.WidthInInches.GetHashCode();
            }

            if (this.HeightInInches != null)
            {
               hashCode += this.HeightInInches.GetHashCode();
            }

            if (this.TrackingNumber != null)
            {
               hashCode += this.TrackingNumber.GetHashCode();
            }

            if (this.Options != null)
            {
               hashCode += this.Options.GetHashCode();
            }

            if (this.ParcelItems != null)
            {
               hashCode += this.ParcelItems.GetHashCode();
            }

            return hashCode;
        }

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.Cost = {(this.Cost == null ? "null" : this.Cost.ToString())}");
            toStringOutput.Add($"this.ReferenceField1 = {(this.ReferenceField1 == null ? "null" : this.ReferenceField1 == string.Empty ? "" : this.ReferenceField1)}");
            toStringOutput.Add($"this.ReferenceField2 = {(this.ReferenceField2 == null ? "null" : this.ReferenceField2 == string.Empty ? "" : this.ReferenceField2)}");
            toStringOutput.Add($"this.ReferenceField3 = {(this.ReferenceField3 == null ? "null" : this.ReferenceField3 == string.Empty ? "" : this.ReferenceField3)}");
            toStringOutput.Add($"this.WeightInPounds = {(this.WeightInPounds == null ? "null" : this.WeightInPounds.ToString())}");
            toStringOutput.Add($"this.LengthInInches = {(this.LengthInInches == null ? "null" : this.LengthInInches.ToString())}");
            toStringOutput.Add($"this.WidthInInches = {(this.WidthInInches == null ? "null" : this.WidthInInches.ToString())}");
            toStringOutput.Add($"this.HeightInInches = {(this.HeightInInches == null ? "null" : this.HeightInInches.ToString())}");
            toStringOutput.Add($"this.TrackingNumber = {(this.TrackingNumber == null ? "null" : this.TrackingNumber == string.Empty ? "" : this.TrackingNumber)}");
            toStringOutput.Add($"this.Options = {(this.Options == null ? "null" : this.Options.ToString())}");
            toStringOutput.Add($"this.ParcelItems = {(this.ParcelItems == null ? "null" : $"[{string.Join(", ", this.ParcelItems)} ]")}");
        }
    }
}