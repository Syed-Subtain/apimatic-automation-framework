// <copyright file="RequestError.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace ShipCaddie.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using ShipCaddie.Standard;
    using ShipCaddie.Standard.Utilities;

    /// <summary>
    /// RequestError.
    /// </summary>
    public class RequestError
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="RequestError"/> class.
        /// </summary>
        public RequestError()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="RequestError"/> class.
        /// </summary>
        /// <param name="hasError">hasError.</param>
        /// <param name="details">details.</param>
        public RequestError(
            bool hasError,
            List<string> details = null)
        {
            this.Details = details;
            this.HasError = hasError;
        }

        /// <summary>
        /// Describes the error that occurred during the request.
        /// </summary>
        [JsonProperty("details", NullValueHandling = NullValueHandling.Ignore)]
        public List<string> Details { get; set; }

        /// <summary>
        /// Set to true in the case that an error has occurred while processing the request.
        /// Set to false otherwise.
        /// </summary>
        [JsonProperty("hasError")]
        public bool HasError { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"RequestError : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is RequestError other &&
                ((this.Details == null && other.Details == null) || (this.Details?.Equals(other.Details) == true)) &&
                this.HasError.Equals(other.HasError);
        }

        /// <inheritdoc/>
        public override int GetHashCode()
        {
            int hashCode = -633930246;

            if (this.Details != null)
            {
               hashCode += this.Details.GetHashCode();
            }

            hashCode += this.HasError.GetHashCode();

            return hashCode;
        }

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.Details = {(this.Details == null ? "null" : $"[{string.Join(", ", this.Details)} ]")}");
            toStringOutput.Add($"this.HasError = {this.HasError}");
        }
    }
}