// <copyright file="RateRequest.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace ShipCaddie.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using ShipCaddie.Standard;
    using ShipCaddie.Standard.Utilities;

    /// <summary>
    /// RateRequest.
    /// </summary>
    public class RateRequest
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="RateRequest"/> class.
        /// </summary>
        public RateRequest()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="RateRequest"/> class.
        /// </summary>
        /// <param name="accessToken">accessToken.</param>
        /// <param name="asClientID">asClientID.</param>
        /// <param name="shippingInfo">shippingInfo.</param>
        public RateRequest(
            string accessToken = null,
            int? asClientID = null,
            Models.ShippingInformation shippingInfo = null)
        {
            this.AccessToken = accessToken;
            this.AsClientID = asClientID;
            this.ShippingInfo = shippingInfo;
        }

        /// <summary>
        /// Authorization Token obtained from Security Token.
        /// </summary>
        [JsonProperty("accessToken", NullValueHandling = NullValueHandling.Ignore)]
        public string AccessToken { get; set; }

        /// <summary>
        /// Optional.  When present, the request will be made for the specified client.
        /// </summary>
        [JsonProperty("asClientID", NullValueHandling = NullValueHandling.Ignore)]
        public int? AsClientID { get; set; }

        /// <summary>
        /// Shipment Information used to request a rate.
        /// </summary>
        [JsonProperty("shippingInfo", NullValueHandling = NullValueHandling.Ignore)]
        public Models.ShippingInformation ShippingInfo { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"RateRequest : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is RateRequest other &&
                ((this.AccessToken == null && other.AccessToken == null) || (this.AccessToken?.Equals(other.AccessToken) == true)) &&
                ((this.AsClientID == null && other.AsClientID == null) || (this.AsClientID?.Equals(other.AsClientID) == true)) &&
                ((this.ShippingInfo == null && other.ShippingInfo == null) || (this.ShippingInfo?.Equals(other.ShippingInfo) == true));
        }

        /// <inheritdoc/>
        public override int GetHashCode()
        {
            int hashCode = -421787465;

            if (this.AccessToken != null)
            {
               hashCode += this.AccessToken.GetHashCode();
            }

            if (this.AsClientID != null)
            {
               hashCode += this.AsClientID.GetHashCode();
            }

            if (this.ShippingInfo != null)
            {
               hashCode += this.ShippingInfo.GetHashCode();
            }

            return hashCode;
        }

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.AccessToken = {(this.AccessToken == null ? "null" : this.AccessToken == string.Empty ? "" : this.AccessToken)}");
            toStringOutput.Add($"this.AsClientID = {(this.AsClientID == null ? "null" : this.AsClientID.ToString())}");
            toStringOutput.Add($"this.ShippingInfo = {(this.ShippingInfo == null ? "null" : this.ShippingInfo.ToString())}");
        }
    }
}