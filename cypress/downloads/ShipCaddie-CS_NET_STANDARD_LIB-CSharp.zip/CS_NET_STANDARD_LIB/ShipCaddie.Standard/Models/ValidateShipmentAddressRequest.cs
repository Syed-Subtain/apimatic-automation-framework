// <copyright file="ValidateShipmentAddressRequest.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace ShipCaddie.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using ShipCaddie.Standard;
    using ShipCaddie.Standard.Utilities;

    /// <summary>
    /// ValidateShipmentAddressRequest.
    /// </summary>
    public class ValidateShipmentAddressRequest
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ValidateShipmentAddressRequest"/> class.
        /// </summary>
        public ValidateShipmentAddressRequest()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ValidateShipmentAddressRequest"/> class.
        /// </summary>
        /// <param name="accessToken">accessToken.</param>
        /// <param name="asClientId">asClientId.</param>
        /// <param name="shipmentAddressToValidate">shipmentAddressToValidate.</param>
        public ValidateShipmentAddressRequest(
            string accessToken = null,
            int? asClientId = null,
            Models.AddressValidationRequestModel shipmentAddressToValidate = null)
        {
            this.AccessToken = accessToken;
            this.AsClientId = asClientId;
            this.ShipmentAddressToValidate = shipmentAddressToValidate;
        }

        /// <summary>
        /// Access Token
        /// </summary>
        [JsonProperty("accessToken", NullValueHandling = NullValueHandling.Ignore)]
        public string AccessToken { get; set; }

        /// <summary>
        /// Client Id used in place of Client Id of signed in user.
        /// </summary>
        [JsonProperty("asClientId", NullValueHandling = NullValueHandling.Ignore)]
        public int? AsClientId { get; set; }

        /// <summary>
        /// Address Validation request model
        /// </summary>
        [JsonProperty("shipmentAddressToValidate", NullValueHandling = NullValueHandling.Ignore)]
        public Models.AddressValidationRequestModel ShipmentAddressToValidate { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"ValidateShipmentAddressRequest : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is ValidateShipmentAddressRequest other &&
                ((this.AccessToken == null && other.AccessToken == null) || (this.AccessToken?.Equals(other.AccessToken) == true)) &&
                ((this.AsClientId == null && other.AsClientId == null) || (this.AsClientId?.Equals(other.AsClientId) == true)) &&
                ((this.ShipmentAddressToValidate == null && other.ShipmentAddressToValidate == null) || (this.ShipmentAddressToValidate?.Equals(other.ShipmentAddressToValidate) == true));
        }

        /// <inheritdoc/>
        public override int GetHashCode()
        {
            int hashCode = 875751553;

            if (this.AccessToken != null)
            {
               hashCode += this.AccessToken.GetHashCode();
            }

            if (this.AsClientId != null)
            {
               hashCode += this.AsClientId.GetHashCode();
            }

            if (this.ShipmentAddressToValidate != null)
            {
               hashCode += this.ShipmentAddressToValidate.GetHashCode();
            }

            return hashCode;
        }

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.AccessToken = {(this.AccessToken == null ? "null" : this.AccessToken == string.Empty ? "" : this.AccessToken)}");
            toStringOutput.Add($"this.AsClientId = {(this.AsClientId == null ? "null" : this.AsClientId.ToString())}");
            toStringOutput.Add($"this.ShipmentAddressToValidate = {(this.ShipmentAddressToValidate == null ? "null" : this.ShipmentAddressToValidate.ToString())}");
        }
    }
}