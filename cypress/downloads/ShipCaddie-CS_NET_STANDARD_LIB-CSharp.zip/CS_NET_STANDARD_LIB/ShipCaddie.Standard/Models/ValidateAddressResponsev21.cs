// <copyright file="ValidateAddressResponsev21.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace ShipCaddie.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using ShipCaddie.Standard;
    using ShipCaddie.Standard.Utilities;

    /// <summary>
    /// ValidateAddressResponsev21.
    /// </summary>
    public class ValidateAddressResponsev21
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ValidateAddressResponsev21"/> class.
        /// </summary>
        public ValidateAddressResponsev21()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ValidateAddressResponsev21"/> class.
        /// </summary>
        /// <param name="addressIsValidated">addressIsValidated.</param>
        /// <param name="validationMessages">validationMessages.</param>
        /// <param name="validatedAddress">validatedAddress.</param>
        /// <param name="error">error.</param>
        public ValidateAddressResponsev21(
            bool addressIsValidated,
            List<Models.AddressValidationInformation> validationMessages,
            Models.Addressv21 validatedAddress,
            Models.RequestError error)
        {
            this.AddressIsValidated = addressIsValidated;
            this.ValidationMessages = validationMessages;
            this.ValidatedAddress = validatedAddress;
            this.Error = error;
        }

        /// <summary>
        /// True if address is valid.  False otherwise.
        /// </summary>
        [JsonProperty("addressIsValidated")]
        public bool AddressIsValidated { get; set; }

        /// <summary>
        /// Informative Messages regarding Address Validation.
        /// </summary>
        [JsonProperty("validationMessages")]
        public List<Models.AddressValidationInformation> ValidationMessages { get; set; }

        /// <summary>
        /// Gets or sets ValidatedAddress.
        /// </summary>
        [JsonProperty("validatedAddress")]
        public Models.Addressv21 ValidatedAddress { get; set; }

        /// <summary>
        /// This information can be used to determine if an error has occurred when a request was processed.
        /// </summary>
        [JsonProperty("error")]
        public Models.RequestError Error { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"ValidateAddressResponsev21 : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is ValidateAddressResponsev21 other &&
                this.AddressIsValidated.Equals(other.AddressIsValidated) &&
                ((this.ValidationMessages == null && other.ValidationMessages == null) || (this.ValidationMessages?.Equals(other.ValidationMessages) == true)) &&
                ((this.ValidatedAddress == null && other.ValidatedAddress == null) || (this.ValidatedAddress?.Equals(other.ValidatedAddress) == true)) &&
                ((this.Error == null && other.Error == null) || (this.Error?.Equals(other.Error) == true));
        }

        /// <inheritdoc/>
        public override int GetHashCode()
        {
            int hashCode = -1065942707;
            hashCode += this.AddressIsValidated.GetHashCode();

            if (this.ValidationMessages != null)
            {
               hashCode += this.ValidationMessages.GetHashCode();
            }

            if (this.ValidatedAddress != null)
            {
               hashCode += this.ValidatedAddress.GetHashCode();
            }

            if (this.Error != null)
            {
               hashCode += this.Error.GetHashCode();
            }

            return hashCode;
        }

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.AddressIsValidated = {this.AddressIsValidated}");
            toStringOutput.Add($"this.ValidationMessages = {(this.ValidationMessages == null ? "null" : $"[{string.Join(", ", this.ValidationMessages)} ]")}");
            toStringOutput.Add($"this.ValidatedAddress = {(this.ValidatedAddress == null ? "null" : this.ValidatedAddress.ToString())}");
            toStringOutput.Add($"this.Error = {(this.Error == null ? "null" : this.Error.ToString())}");
        }
    }
}