// <copyright file="LabelInformation.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace ShipCaddie.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using ShipCaddie.Standard;
    using ShipCaddie.Standard.Utilities;

    /// <summary>
    /// LabelInformation.
    /// </summary>
    public class LabelInformation
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="LabelInformation"/> class.
        /// </summary>
        public LabelInformation()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="LabelInformation"/> class.
        /// </summary>
        /// <param name="labels">labels.</param>
        /// <param name="shipmentID">shipmentID.</param>
        /// <param name="error">error.</param>
        public LabelInformation(
            List<Models.PrintableLabel> labels,
            int shipmentID,
            Models.RequestError error)
        {
            this.Labels = labels;
            this.ShipmentID = shipmentID;
            this.Error = error;
        }

        /// <summary>
        /// Printable labels. One for each parcel.
        /// </summary>
        [JsonProperty("labels")]
        public List<Models.PrintableLabel> Labels { get; set; }

        /// <summary>
        /// ID which uniquely identifies this shipment.
        /// This ID can be used in other API Methods.
        /// </summary>
        [JsonProperty("shipmentID")]
        public int ShipmentID { get; set; }

        /// <summary>
        /// This information can be used to determine if an error has occurred when a request was processed.
        /// </summary>
        [JsonProperty("error")]
        public Models.RequestError Error { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"LabelInformation : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is LabelInformation other &&
                ((this.Labels == null && other.Labels == null) || (this.Labels?.Equals(other.Labels) == true)) &&
                this.ShipmentID.Equals(other.ShipmentID) &&
                ((this.Error == null && other.Error == null) || (this.Error?.Equals(other.Error) == true));
        }

        /// <inheritdoc/>
        public override int GetHashCode()
        {
            int hashCode = -388565215;

            if (this.Labels != null)
            {
               hashCode += this.Labels.GetHashCode();
            }

            hashCode += this.ShipmentID.GetHashCode();

            if (this.Error != null)
            {
               hashCode += this.Error.GetHashCode();
            }

            return hashCode;
        }

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.Labels = {(this.Labels == null ? "null" : $"[{string.Join(", ", this.Labels)} ]")}");
            toStringOutput.Add($"this.ShipmentID = {this.ShipmentID}");
            toStringOutput.Add($"this.Error = {(this.Error == null ? "null" : this.Error.ToString())}");
        }
    }
}