// <copyright file="ParcelChargeDetails.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace ShipCaddie.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using ShipCaddie.Standard;
    using ShipCaddie.Standard.Utilities;

    /// <summary>
    /// ParcelChargeDetails.
    /// </summary>
    public class ParcelChargeDetails
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ParcelChargeDetails"/> class.
        /// </summary>
        public ParcelChargeDetails()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ParcelChargeDetails"/> class.
        /// </summary>
        /// <param name="parcelID">parcelID.</param>
        /// <param name="costDetails">costDetails.</param>
        public ParcelChargeDetails(
            string parcelID = null,
            List<Models.CostDetailv21> costDetails = null)
        {
            this.ParcelID = parcelID;
            this.CostDetails = costDetails;
        }

        /// <summary>
        /// A unique ID used to match
        /// parcels with cost details.
        /// </summary>
        [JsonProperty("parcelID", NullValueHandling = NullValueHandling.Ignore)]
        public string ParcelID { get; set; }

        /// <summary>
        /// Detailed shipping charges.
        /// </summary>
        [JsonProperty("costDetails", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.CostDetailv21> CostDetails { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"ParcelChargeDetails : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is ParcelChargeDetails other &&
                ((this.ParcelID == null && other.ParcelID == null) || (this.ParcelID?.Equals(other.ParcelID) == true)) &&
                ((this.CostDetails == null && other.CostDetails == null) || (this.CostDetails?.Equals(other.CostDetails) == true));
        }

        /// <inheritdoc/>
        public override int GetHashCode()
        {
            int hashCode = -62238958;

            if (this.ParcelID != null)
            {
               hashCode += this.ParcelID.GetHashCode();
            }

            if (this.CostDetails != null)
            {
               hashCode += this.CostDetails.GetHashCode();
            }

            return hashCode;
        }

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.ParcelID = {(this.ParcelID == null ? "null" : this.ParcelID == string.Empty ? "" : this.ParcelID)}");
            toStringOutput.Add($"this.CostDetails = {(this.CostDetails == null ? "null" : $"[{string.Join(", ", this.CostDetails)} ]")}");
        }
    }
}