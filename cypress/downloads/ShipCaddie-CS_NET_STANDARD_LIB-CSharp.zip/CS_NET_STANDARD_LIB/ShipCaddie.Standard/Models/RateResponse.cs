// <copyright file="RateResponse.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace ShipCaddie.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using ShipCaddie.Standard;
    using ShipCaddie.Standard.Utilities;

    /// <summary>
    /// RateResponse.
    /// </summary>
    public class RateResponse
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="RateResponse"/> class.
        /// </summary>
        public RateResponse()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="RateResponse"/> class.
        /// </summary>
        /// <param name="processingTimeInSeconds">processingTimeInSeconds.</param>
        /// <param name="error">error.</param>
        /// <param name="carrierName">carrierName.</param>
        /// <param name="carrierClientContractId">carrierClientContractId.</param>
        /// <param name="data">data.</param>
        public RateResponse(
            double processingTimeInSeconds,
            Models.RequestError error,
            string carrierName = null,
            int? carrierClientContractId = null,
            List<Models.ShippingCostsPerCarrier> data = null)
        {
            this.ProcessingTimeInSeconds = processingTimeInSeconds;
            this.CarrierName = carrierName;
            this.CarrierClientContractId = carrierClientContractId;
            this.Data = data;
            this.Error = error;
        }

        /// <summary>
        /// Gets or sets ProcessingTimeInSeconds.
        /// </summary>
        [JsonProperty("processingTimeInSeconds")]
        public double ProcessingTimeInSeconds { get; set; }

        /// <summary>
        /// Gets or sets CarrierName.
        /// </summary>
        [JsonProperty("carrierName", NullValueHandling = NullValueHandling.Ignore)]
        public string CarrierName { get; set; }

        /// <summary>
        /// Gets or sets CarrierClientContractId.
        /// </summary>
        [JsonProperty("carrierClientContractId", NullValueHandling = NullValueHandling.Ignore)]
        public int? CarrierClientContractId { get; set; }

        /// <summary>
        /// Gets or sets Data.
        /// </summary>
        [JsonProperty("data", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.ShippingCostsPerCarrier> Data { get; set; }

        /// <summary>
        /// This information can be used to determine if an error has occurred when a request was processed.
        /// </summary>
        [JsonProperty("error")]
        public Models.RequestError Error { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"RateResponse : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is RateResponse other &&
                this.ProcessingTimeInSeconds.Equals(other.ProcessingTimeInSeconds) &&
                ((this.CarrierName == null && other.CarrierName == null) || (this.CarrierName?.Equals(other.CarrierName) == true)) &&
                ((this.CarrierClientContractId == null && other.CarrierClientContractId == null) || (this.CarrierClientContractId?.Equals(other.CarrierClientContractId) == true)) &&
                ((this.Data == null && other.Data == null) || (this.Data?.Equals(other.Data) == true)) &&
                ((this.Error == null && other.Error == null) || (this.Error?.Equals(other.Error) == true));
        }

        /// <inheritdoc/>
        public override int GetHashCode()
        {
            int hashCode = -193296094;
            hashCode += this.ProcessingTimeInSeconds.GetHashCode();

            if (this.CarrierName != null)
            {
               hashCode += this.CarrierName.GetHashCode();
            }

            if (this.CarrierClientContractId != null)
            {
               hashCode += this.CarrierClientContractId.GetHashCode();
            }

            if (this.Data != null)
            {
               hashCode += this.Data.GetHashCode();
            }

            if (this.Error != null)
            {
               hashCode += this.Error.GetHashCode();
            }

            return hashCode;
        }

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.ProcessingTimeInSeconds = {this.ProcessingTimeInSeconds}");
            toStringOutput.Add($"this.CarrierName = {(this.CarrierName == null ? "null" : this.CarrierName == string.Empty ? "" : this.CarrierName)}");
            toStringOutput.Add($"this.CarrierClientContractId = {(this.CarrierClientContractId == null ? "null" : this.CarrierClientContractId.ToString())}");
            toStringOutput.Add($"this.Data = {(this.Data == null ? "null" : $"[{string.Join(", ", this.Data)} ]")}");
            toStringOutput.Add($"this.Error = {(this.Error == null ? "null" : this.Error.ToString())}");
        }
    }
}