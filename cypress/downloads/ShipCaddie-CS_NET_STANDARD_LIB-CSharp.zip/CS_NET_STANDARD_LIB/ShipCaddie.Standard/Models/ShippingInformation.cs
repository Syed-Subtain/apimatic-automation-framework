// <copyright file="ShippingInformation.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace ShipCaddie.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using ShipCaddie.Standard;
    using ShipCaddie.Standard.Utilities;

    /// <summary>
    /// ShippingInformation.
    /// </summary>
    public class ShippingInformation
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ShippingInformation"/> class.
        /// </summary>
        public ShippingInformation()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ShippingInformation"/> class.
        /// </summary>
        /// <param name="carrierClientContractId">carrierClientContractId.</param>
        /// <param name="serviceLevelId">serviceLevelId.</param>
        /// <param name="dateShipped">dateShipped.</param>
        /// <param name="options">options.</param>
        /// <param name="addressFrom">addressFrom.</param>
        /// <param name="addressTo">addressTo.</param>
        /// <param name="parcels">parcels.</param>
        public ShippingInformation(
            int? carrierClientContractId = null,
            int? serviceLevelId = null,
            DateTime? dateShipped = null,
            Models.CustomsOptions options = null,
            Models.ShipFromAddress addressFrom = null,
            Models.ShipToAddress addressTo = null,
            List<Models.ParcelInformation> parcels = null)
        {
            this.CarrierClientContractId = carrierClientContractId;
            this.ServiceLevelId = serviceLevelId;
            this.DateShipped = dateShipped;
            this.Options = options;
            this.AddressFrom = addressFrom;
            this.AddressTo = addressTo;
            this.Parcels = parcels;
        }

        /// <summary>
        /// Specifies the Carrier for which to check rates.
        /// </summary>
        [JsonProperty("carrierClientContractId", NullValueHandling = NullValueHandling.Ignore)]
        public int? CarrierClientContractId { get; set; }

        /// <summary>
        /// Specifies the ServiceLevel to check.
        /// </summary>
        [JsonProperty("serviceLevelId", NullValueHandling = NullValueHandling.Ignore)]
        public int? ServiceLevelId { get; set; }

        /// <summary>
        /// Specifies the date the packages will be shipped.
        /// </summary>
        [JsonConverter(typeof(IsoDateTimeConverter))]
        [JsonProperty("dateShipped", NullValueHandling = NullValueHandling.Ignore)]
        public DateTime? DateShipped { get; set; }

        /// <summary>
        /// Gets or sets Options.
        /// </summary>
        [JsonProperty("options", NullValueHandling = NullValueHandling.Ignore)]
        public Models.CustomsOptions Options { get; set; }

        /// <summary>
        /// Gets or sets AddressFrom.
        /// </summary>
        [JsonProperty("addressFrom", NullValueHandling = NullValueHandling.Ignore)]
        public Models.ShipFromAddress AddressFrom { get; set; }

        /// <summary>
        /// Gets or sets AddressTo.
        /// </summary>
        [JsonProperty("addressTo", NullValueHandling = NullValueHandling.Ignore)]
        public Models.ShipToAddress AddressTo { get; set; }

        /// <summary>
        /// Details of parcels to send.
        /// </summary>
        [JsonProperty("parcels", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.ParcelInformation> Parcels { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"ShippingInformation : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is ShippingInformation other &&
                ((this.CarrierClientContractId == null && other.CarrierClientContractId == null) || (this.CarrierClientContractId?.Equals(other.CarrierClientContractId) == true)) &&
                ((this.ServiceLevelId == null && other.ServiceLevelId == null) || (this.ServiceLevelId?.Equals(other.ServiceLevelId) == true)) &&
                ((this.DateShipped == null && other.DateShipped == null) || (this.DateShipped?.Equals(other.DateShipped) == true)) &&
                ((this.Options == null && other.Options == null) || (this.Options?.Equals(other.Options) == true)) &&
                ((this.AddressFrom == null && other.AddressFrom == null) || (this.AddressFrom?.Equals(other.AddressFrom) == true)) &&
                ((this.AddressTo == null && other.AddressTo == null) || (this.AddressTo?.Equals(other.AddressTo) == true)) &&
                ((this.Parcels == null && other.Parcels == null) || (this.Parcels?.Equals(other.Parcels) == true));
        }

        /// <inheritdoc/>
        public override int GetHashCode()
        {
            int hashCode = 485212346;

            if (this.CarrierClientContractId != null)
            {
               hashCode += this.CarrierClientContractId.GetHashCode();
            }

            if (this.ServiceLevelId != null)
            {
               hashCode += this.ServiceLevelId.GetHashCode();
            }

            if (this.DateShipped != null)
            {
               hashCode += this.DateShipped.GetHashCode();
            }

            if (this.Options != null)
            {
               hashCode += this.Options.GetHashCode();
            }

            if (this.AddressFrom != null)
            {
               hashCode += this.AddressFrom.GetHashCode();
            }

            if (this.AddressTo != null)
            {
               hashCode += this.AddressTo.GetHashCode();
            }

            if (this.Parcels != null)
            {
               hashCode += this.Parcels.GetHashCode();
            }

            return hashCode;
        }

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.CarrierClientContractId = {(this.CarrierClientContractId == null ? "null" : this.CarrierClientContractId.ToString())}");
            toStringOutput.Add($"this.ServiceLevelId = {(this.ServiceLevelId == null ? "null" : this.ServiceLevelId.ToString())}");
            toStringOutput.Add($"this.DateShipped = {(this.DateShipped == null ? "null" : this.DateShipped.ToString())}");
            toStringOutput.Add($"this.Options = {(this.Options == null ? "null" : this.Options.ToString())}");
            toStringOutput.Add($"this.AddressFrom = {(this.AddressFrom == null ? "null" : this.AddressFrom.ToString())}");
            toStringOutput.Add($"this.AddressTo = {(this.AddressTo == null ? "null" : this.AddressTo.ToString())}");
            toStringOutput.Add($"this.Parcels = {(this.Parcels == null ? "null" : $"[{string.Join(", ", this.Parcels)} ]")}");
        }
    }
}