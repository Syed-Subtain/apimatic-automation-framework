// <copyright file="ScanFormModel.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace ShipCaddie.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using ShipCaddie.Standard;
    using ShipCaddie.Standard.Utilities;

    /// <summary>
    /// ScanFormModel.
    /// </summary>
    public class ScanFormModel
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ScanFormModel"/> class.
        /// </summary>
        public ScanFormModel()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ScanFormModel"/> class.
        /// </summary>
        /// <param name="id">id.</param>
        /// <param name="scanFormId">scanFormId.</param>
        /// <param name="batchId">batchId.</param>
        /// <param name="clientId">clientId.</param>
        /// <param name="shipmentClientAddressId">shipmentClientAddressId.</param>
        /// <param name="shipDate">shipDate.</param>
        /// <param name="scanFormDataType">scanFormDataType.</param>
        /// <param name="carrierClientContractId">carrierClientContractId.</param>
        /// <param name="carrierClientContractName">carrierClientContractName.</param>
        /// <param name="shipmentClientAddressLine1">shipmentClientAddressLine1.</param>
        /// <param name="shipmentClientAddressLine2">shipmentClientAddressLine2.</param>
        /// <param name="shipmentClientAddressProvince">shipmentClientAddressProvince.</param>
        /// <param name="shipmentClientAddressCity">shipmentClientAddressCity.</param>
        /// <param name="shipmentClientAddressPostalCode">shipmentClientAddressPostalCode.</param>
        /// <param name="shippingSiteName">shippingSiteName.</param>
        /// <param name="dateCreated">dateCreated.</param>
        /// <param name="printJobs">printJobs.</param>
        /// <param name="excludedItems">excludedItems.</param>
        public ScanFormModel(
            int? id = null,
            string scanFormId = null,
            string batchId = null,
            int? clientId = null,
            int? shipmentClientAddressId = null,
            DateTime? shipDate = null,
            Models.ScanFormDataTypeEnum? scanFormDataType = null,
            int? carrierClientContractId = null,
            string carrierClientContractName = null,
            string shipmentClientAddressLine1 = null,
            string shipmentClientAddressLine2 = null,
            string shipmentClientAddressProvince = null,
            string shipmentClientAddressCity = null,
            string shipmentClientAddressPostalCode = null,
            string shippingSiteName = null,
            DateTime? dateCreated = null,
            List<Models.PrintJob> printJobs = null,
            Dictionary<string, string> excludedItems = null)
        {
            this.Id = id;
            this.ScanFormId = scanFormId;
            this.BatchId = batchId;
            this.ClientId = clientId;
            this.ShipmentClientAddressId = shipmentClientAddressId;
            this.ShipDate = shipDate;
            this.ScanFormDataType = scanFormDataType;
            this.CarrierClientContractId = carrierClientContractId;
            this.CarrierClientContractName = carrierClientContractName;
            this.ShipmentClientAddressLine1 = shipmentClientAddressLine1;
            this.ShipmentClientAddressLine2 = shipmentClientAddressLine2;
            this.ShipmentClientAddressProvince = shipmentClientAddressProvince;
            this.ShipmentClientAddressCity = shipmentClientAddressCity;
            this.ShipmentClientAddressPostalCode = shipmentClientAddressPostalCode;
            this.ShippingSiteName = shippingSiteName;
            this.DateCreated = dateCreated;
            this.PrintJobs = printJobs;
            this.ExcludedItems = excludedItems;
        }

        /// <summary>
        /// Gets or sets Id.
        /// </summary>
        [JsonProperty("id", NullValueHandling = NullValueHandling.Ignore)]
        public int? Id { get; set; }

        /// <summary>
        /// Gets or sets ScanFormId.
        /// </summary>
        [JsonProperty("scanFormId", NullValueHandling = NullValueHandling.Ignore)]
        public string ScanFormId { get; set; }

        /// <summary>
        /// Gets or sets BatchId.
        /// </summary>
        [JsonProperty("batchId", NullValueHandling = NullValueHandling.Ignore)]
        public string BatchId { get; set; }

        /// <summary>
        /// Gets or sets ClientId.
        /// </summary>
        [JsonProperty("clientId", NullValueHandling = NullValueHandling.Ignore)]
        public int? ClientId { get; set; }

        /// <summary>
        /// Gets or sets ShipmentClientAddressId.
        /// </summary>
        [JsonProperty("shipmentClientAddressId", NullValueHandling = NullValueHandling.Ignore)]
        public int? ShipmentClientAddressId { get; set; }

        /// <summary>
        /// Gets or sets ShipDate.
        /// </summary>
        [JsonConverter(typeof(IsoDateTimeConverter))]
        [JsonProperty("shipDate", NullValueHandling = NullValueHandling.Ignore)]
        public DateTime? ShipDate { get; set; }

        /// <summary>
        /// Gets or sets ScanFormDataType.
        /// </summary>
        [JsonProperty("scanFormDataType", ItemConverterType = typeof(StringEnumConverter), NullValueHandling = NullValueHandling.Ignore)]
        public Models.ScanFormDataTypeEnum? ScanFormDataType { get; set; }

        /// <summary>
        /// Gets or sets CarrierClientContractId.
        /// </summary>
        [JsonProperty("carrierClientContractId", NullValueHandling = NullValueHandling.Ignore)]
        public int? CarrierClientContractId { get; set; }

        /// <summary>
        /// Gets or sets CarrierClientContractName.
        /// </summary>
        [JsonProperty("carrierClientContractName", NullValueHandling = NullValueHandling.Ignore)]
        public string CarrierClientContractName { get; set; }

        /// <summary>
        /// Gets or sets ShipmentClientAddressLine1.
        /// </summary>
        [JsonProperty("shipmentClientAddressLine1", NullValueHandling = NullValueHandling.Ignore)]
        public string ShipmentClientAddressLine1 { get; set; }

        /// <summary>
        /// Gets or sets ShipmentClientAddressLine2.
        /// </summary>
        [JsonProperty("shipmentClientAddressLine2", NullValueHandling = NullValueHandling.Ignore)]
        public string ShipmentClientAddressLine2 { get; set; }

        /// <summary>
        /// Gets or sets ShipmentClientAddressProvince.
        /// </summary>
        [JsonProperty("shipmentClientAddressProvince", NullValueHandling = NullValueHandling.Ignore)]
        public string ShipmentClientAddressProvince { get; set; }

        /// <summary>
        /// Gets or sets ShipmentClientAddressCity.
        /// </summary>
        [JsonProperty("shipmentClientAddressCity", NullValueHandling = NullValueHandling.Ignore)]
        public string ShipmentClientAddressCity { get; set; }

        /// <summary>
        /// Gets or sets ShipmentClientAddressPostalCode.
        /// </summary>
        [JsonProperty("shipmentClientAddressPostalCode", NullValueHandling = NullValueHandling.Ignore)]
        public string ShipmentClientAddressPostalCode { get; set; }

        /// <summary>
        /// Gets or sets ShippingSiteName.
        /// </summary>
        [JsonProperty("shippingSiteName", NullValueHandling = NullValueHandling.Ignore)]
        public string ShippingSiteName { get; set; }

        /// <summary>
        /// Gets or sets DateCreated.
        /// </summary>
        [JsonConverter(typeof(IsoDateTimeConverter))]
        [JsonProperty("dateCreated", NullValueHandling = NullValueHandling.Ignore)]
        public DateTime? DateCreated { get; set; }

        /// <summary>
        /// Gets or sets PrintJobs.
        /// </summary>
        [JsonProperty("printJobs", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.PrintJob> PrintJobs { get; set; }

        /// <summary>
        /// This is the list of items that are ignored or already manifested by easypost.
        /// </summary>
        [JsonProperty("excludedItems", NullValueHandling = NullValueHandling.Ignore)]
        public Dictionary<string, string> ExcludedItems { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"ScanFormModel : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is ScanFormModel other &&
                ((this.Id == null && other.Id == null) || (this.Id?.Equals(other.Id) == true)) &&
                ((this.ScanFormId == null && other.ScanFormId == null) || (this.ScanFormId?.Equals(other.ScanFormId) == true)) &&
                ((this.BatchId == null && other.BatchId == null) || (this.BatchId?.Equals(other.BatchId) == true)) &&
                ((this.ClientId == null && other.ClientId == null) || (this.ClientId?.Equals(other.ClientId) == true)) &&
                ((this.ShipmentClientAddressId == null && other.ShipmentClientAddressId == null) || (this.ShipmentClientAddressId?.Equals(other.ShipmentClientAddressId) == true)) &&
                ((this.ShipDate == null && other.ShipDate == null) || (this.ShipDate?.Equals(other.ShipDate) == true)) &&
                ((this.ScanFormDataType == null && other.ScanFormDataType == null) || (this.ScanFormDataType?.Equals(other.ScanFormDataType) == true)) &&
                ((this.CarrierClientContractId == null && other.CarrierClientContractId == null) || (this.CarrierClientContractId?.Equals(other.CarrierClientContractId) == true)) &&
                ((this.CarrierClientContractName == null && other.CarrierClientContractName == null) || (this.CarrierClientContractName?.Equals(other.CarrierClientContractName) == true)) &&
                ((this.ShipmentClientAddressLine1 == null && other.ShipmentClientAddressLine1 == null) || (this.ShipmentClientAddressLine1?.Equals(other.ShipmentClientAddressLine1) == true)) &&
                ((this.ShipmentClientAddressLine2 == null && other.ShipmentClientAddressLine2 == null) || (this.ShipmentClientAddressLine2?.Equals(other.ShipmentClientAddressLine2) == true)) &&
                ((this.ShipmentClientAddressProvince == null && other.ShipmentClientAddressProvince == null) || (this.ShipmentClientAddressProvince?.Equals(other.ShipmentClientAddressProvince) == true)) &&
                ((this.ShipmentClientAddressCity == null && other.ShipmentClientAddressCity == null) || (this.ShipmentClientAddressCity?.Equals(other.ShipmentClientAddressCity) == true)) &&
                ((this.ShipmentClientAddressPostalCode == null && other.ShipmentClientAddressPostalCode == null) || (this.ShipmentClientAddressPostalCode?.Equals(other.ShipmentClientAddressPostalCode) == true)) &&
                ((this.ShippingSiteName == null && other.ShippingSiteName == null) || (this.ShippingSiteName?.Equals(other.ShippingSiteName) == true)) &&
                ((this.DateCreated == null && other.DateCreated == null) || (this.DateCreated?.Equals(other.DateCreated) == true)) &&
                ((this.PrintJobs == null && other.PrintJobs == null) || (this.PrintJobs?.Equals(other.PrintJobs) == true)) &&
                ((this.ExcludedItems == null && other.ExcludedItems == null) || (this.ExcludedItems?.Equals(other.ExcludedItems) == true));
        }

        /// <inheritdoc/>
        public override int GetHashCode()
        {
            int hashCode = 801419459;

            if (this.Id != null)
            {
               hashCode += this.Id.GetHashCode();
            }

            if (this.ScanFormId != null)
            {
               hashCode += this.ScanFormId.GetHashCode();
            }

            if (this.BatchId != null)
            {
               hashCode += this.BatchId.GetHashCode();
            }

            if (this.ClientId != null)
            {
               hashCode += this.ClientId.GetHashCode();
            }

            if (this.ShipmentClientAddressId != null)
            {
               hashCode += this.ShipmentClientAddressId.GetHashCode();
            }

            if (this.ShipDate != null)
            {
               hashCode += this.ShipDate.GetHashCode();
            }

            if (this.ScanFormDataType != null)
            {
               hashCode += this.ScanFormDataType.GetHashCode();
            }

            if (this.CarrierClientContractId != null)
            {
               hashCode += this.CarrierClientContractId.GetHashCode();
            }

            if (this.CarrierClientContractName != null)
            {
               hashCode += this.CarrierClientContractName.GetHashCode();
            }

            if (this.ShipmentClientAddressLine1 != null)
            {
               hashCode += this.ShipmentClientAddressLine1.GetHashCode();
            }

            if (this.ShipmentClientAddressLine2 != null)
            {
               hashCode += this.ShipmentClientAddressLine2.GetHashCode();
            }

            if (this.ShipmentClientAddressProvince != null)
            {
               hashCode += this.ShipmentClientAddressProvince.GetHashCode();
            }

            if (this.ShipmentClientAddressCity != null)
            {
               hashCode += this.ShipmentClientAddressCity.GetHashCode();
            }

            if (this.ShipmentClientAddressPostalCode != null)
            {
               hashCode += this.ShipmentClientAddressPostalCode.GetHashCode();
            }

            if (this.ShippingSiteName != null)
            {
               hashCode += this.ShippingSiteName.GetHashCode();
            }

            if (this.DateCreated != null)
            {
               hashCode += this.DateCreated.GetHashCode();
            }

            if (this.PrintJobs != null)
            {
               hashCode += this.PrintJobs.GetHashCode();
            }

            if (this.ExcludedItems != null)
            {
               hashCode += this.ExcludedItems.GetHashCode();
            }

            return hashCode;
        }

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.Id = {(this.Id == null ? "null" : this.Id.ToString())}");
            toStringOutput.Add($"this.ScanFormId = {(this.ScanFormId == null ? "null" : this.ScanFormId == string.Empty ? "" : this.ScanFormId)}");
            toStringOutput.Add($"this.BatchId = {(this.BatchId == null ? "null" : this.BatchId == string.Empty ? "" : this.BatchId)}");
            toStringOutput.Add($"this.ClientId = {(this.ClientId == null ? "null" : this.ClientId.ToString())}");
            toStringOutput.Add($"this.ShipmentClientAddressId = {(this.ShipmentClientAddressId == null ? "null" : this.ShipmentClientAddressId.ToString())}");
            toStringOutput.Add($"this.ShipDate = {(this.ShipDate == null ? "null" : this.ShipDate.ToString())}");
            toStringOutput.Add($"this.ScanFormDataType = {(this.ScanFormDataType == null ? "null" : this.ScanFormDataType.ToString())}");
            toStringOutput.Add($"this.CarrierClientContractId = {(this.CarrierClientContractId == null ? "null" : this.CarrierClientContractId.ToString())}");
            toStringOutput.Add($"this.CarrierClientContractName = {(this.CarrierClientContractName == null ? "null" : this.CarrierClientContractName == string.Empty ? "" : this.CarrierClientContractName)}");
            toStringOutput.Add($"this.ShipmentClientAddressLine1 = {(this.ShipmentClientAddressLine1 == null ? "null" : this.ShipmentClientAddressLine1 == string.Empty ? "" : this.ShipmentClientAddressLine1)}");
            toStringOutput.Add($"this.ShipmentClientAddressLine2 = {(this.ShipmentClientAddressLine2 == null ? "null" : this.ShipmentClientAddressLine2 == string.Empty ? "" : this.ShipmentClientAddressLine2)}");
            toStringOutput.Add($"this.ShipmentClientAddressProvince = {(this.ShipmentClientAddressProvince == null ? "null" : this.ShipmentClientAddressProvince == string.Empty ? "" : this.ShipmentClientAddressProvince)}");
            toStringOutput.Add($"this.ShipmentClientAddressCity = {(this.ShipmentClientAddressCity == null ? "null" : this.ShipmentClientAddressCity == string.Empty ? "" : this.ShipmentClientAddressCity)}");
            toStringOutput.Add($"this.ShipmentClientAddressPostalCode = {(this.ShipmentClientAddressPostalCode == null ? "null" : this.ShipmentClientAddressPostalCode == string.Empty ? "" : this.ShipmentClientAddressPostalCode)}");
            toStringOutput.Add($"this.ShippingSiteName = {(this.ShippingSiteName == null ? "null" : this.ShippingSiteName == string.Empty ? "" : this.ShippingSiteName)}");
            toStringOutput.Add($"this.DateCreated = {(this.DateCreated == null ? "null" : this.DateCreated.ToString())}");
            toStringOutput.Add($"this.PrintJobs = {(this.PrintJobs == null ? "null" : $"[{string.Join(", ", this.PrintJobs)} ]")}");
            toStringOutput.Add($"ExcludedItems = {(this.ExcludedItems == null ? "null" : this.ExcludedItems.ToString())}");
        }
    }
}