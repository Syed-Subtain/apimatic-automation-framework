// <copyright file="GetCarrierParcelSpecificationResponsev21.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace ShipCaddie.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using ShipCaddie.Standard;
    using ShipCaddie.Standard.Utilities;

    /// <summary>
    /// GetCarrierParcelSpecificationResponsev21.
    /// </summary>
    public class GetCarrierParcelSpecificationResponsev21
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="GetCarrierParcelSpecificationResponsev21"/> class.
        /// </summary>
        public GetCarrierParcelSpecificationResponsev21()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="GetCarrierParcelSpecificationResponsev21"/> class.
        /// </summary>
        /// <param name="parcelDetails">parcelDetails.</param>
        /// <param name="error">error.</param>
        public GetCarrierParcelSpecificationResponsev21(
            List<Models.PackagingDetail> parcelDetails = null,
            Models.RequestError error = null)
        {
            this.ParcelDetails = parcelDetails;
            this.Error = error;
        }

        /// <summary>
        /// Specifications for parcels handled by carrier.
        /// </summary>
        [JsonProperty("parcelDetails", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.PackagingDetail> ParcelDetails { get; set; }

        /// <summary>
        /// This information can be used to determine if an error has occurred when a request was processed.
        /// </summary>
        [JsonProperty("error", NullValueHandling = NullValueHandling.Ignore)]
        public Models.RequestError Error { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"GetCarrierParcelSpecificationResponsev21 : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is GetCarrierParcelSpecificationResponsev21 other &&
                ((this.ParcelDetails == null && other.ParcelDetails == null) || (this.ParcelDetails?.Equals(other.ParcelDetails) == true)) &&
                ((this.Error == null && other.Error == null) || (this.Error?.Equals(other.Error) == true));
        }

        /// <inheritdoc/>
        public override int GetHashCode()
        {
            int hashCode = 1767789429;

            if (this.ParcelDetails != null)
            {
               hashCode += this.ParcelDetails.GetHashCode();
            }

            if (this.Error != null)
            {
               hashCode += this.Error.GetHashCode();
            }

            return hashCode;
        }

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.ParcelDetails = {(this.ParcelDetails == null ? "null" : $"[{string.Join(", ", this.ParcelDetails)} ]")}");
            toStringOutput.Add($"this.Error = {(this.Error == null ? "null" : this.Error.ToString())}");
        }
    }
}