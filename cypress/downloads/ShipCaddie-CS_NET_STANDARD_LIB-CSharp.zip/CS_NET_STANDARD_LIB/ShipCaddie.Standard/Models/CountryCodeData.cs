// <copyright file="CountryCodeData.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace ShipCaddie.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using ShipCaddie.Standard;
    using ShipCaddie.Standard.Utilities;

    /// <summary>
    /// CountryCodeData.
    /// </summary>
    public class CountryCodeData
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="CountryCodeData"/> class.
        /// </summary>
        public CountryCodeData()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="CountryCodeData"/> class.
        /// </summary>
        /// <param name="countryId">countryId.</param>
        /// <param name="countryName">countryName.</param>
        /// <param name="alpha2CountryCode">alpha2CountryCode.</param>
        public CountryCodeData(
            int countryId,
            string countryName,
            string alpha2CountryCode)
        {
            this.CountryId = countryId;
            this.CountryName = countryName;
            this.Alpha2CountryCode = alpha2CountryCode;
        }

        /// <summary>
        /// Unique ID used to identify a country.
        /// </summary>
        [JsonProperty("countryId")]
        public int CountryId { get; set; }

        /// <summary>
        /// Friendly Country name.
        /// </summary>
        [JsonProperty("countryName")]
        public string CountryName { get; set; }

        /// <summary>
        /// Standardized Country Codes.
        /// </summary>
        [JsonProperty("alpha2CountryCode")]
        public string Alpha2CountryCode { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"CountryCodeData : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is CountryCodeData other &&
                this.CountryId.Equals(other.CountryId) &&
                ((this.CountryName == null && other.CountryName == null) || (this.CountryName?.Equals(other.CountryName) == true)) &&
                ((this.Alpha2CountryCode == null && other.Alpha2CountryCode == null) || (this.Alpha2CountryCode?.Equals(other.Alpha2CountryCode) == true));
        }

        /// <inheritdoc/>
        public override int GetHashCode()
        {
            int hashCode = 723790143;
            hashCode += this.CountryId.GetHashCode();

            if (this.CountryName != null)
            {
               hashCode += this.CountryName.GetHashCode();
            }

            if (this.Alpha2CountryCode != null)
            {
               hashCode += this.Alpha2CountryCode.GetHashCode();
            }

            return hashCode;
        }

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.CountryId = {this.CountryId}");
            toStringOutput.Add($"this.CountryName = {(this.CountryName == null ? "null" : this.CountryName == string.Empty ? "" : this.CountryName)}");
            toStringOutput.Add($"this.Alpha2CountryCode = {(this.Alpha2CountryCode == null ? "null" : this.Alpha2CountryCode == string.Empty ? "" : this.Alpha2CountryCode)}");
        }
    }
}