// <copyright file="VerifyPackageLengthGirthLimitRequestv21.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace ShipCaddie.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using ShipCaddie.Standard;
    using ShipCaddie.Standard.Utilities;

    /// <summary>
    /// VerifyPackageLengthGirthLimitRequestv21.
    /// </summary>
    public class VerifyPackageLengthGirthLimitRequestv21
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="VerifyPackageLengthGirthLimitRequestv21"/> class.
        /// </summary>
        public VerifyPackageLengthGirthLimitRequestv21()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="VerifyPackageLengthGirthLimitRequestv21"/> class.
        /// </summary>
        /// <param name="accessToken">accessToken.</param>
        /// <param name="request">request.</param>
        public VerifyPackageLengthGirthLimitRequestv21(
            string accessToken = null,
            Models.PackageLengthGirthModelV21 request = null)
        {
            this.AccessToken = accessToken;
            this.Request = request;
        }

        /// <summary>
        /// Required.
        /// An authorization token is necessary to call this method.
        /// <remarks>
        /// The token can be obtained by calling the GetToken or RefreshToken methods.
        /// </remarks>
        /// </summary>
        [JsonProperty("accessToken", NullValueHandling = NullValueHandling.Ignore)]
        public string AccessToken { get; set; }

        /// <summary>
        /// Gets or sets Request.
        /// </summary>
        [JsonProperty("request", NullValueHandling = NullValueHandling.Ignore)]
        public Models.PackageLengthGirthModelV21 Request { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"VerifyPackageLengthGirthLimitRequestv21 : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is VerifyPackageLengthGirthLimitRequestv21 other &&
                ((this.AccessToken == null && other.AccessToken == null) || (this.AccessToken?.Equals(other.AccessToken) == true)) &&
                ((this.Request == null && other.Request == null) || (this.Request?.Equals(other.Request) == true));
        }

        /// <inheritdoc/>
        public override int GetHashCode()
        {
            int hashCode = 1924042532;

            if (this.AccessToken != null)
            {
               hashCode += this.AccessToken.GetHashCode();
            }

            if (this.Request != null)
            {
               hashCode += this.Request.GetHashCode();
            }

            return hashCode;
        }

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.AccessToken = {(this.AccessToken == null ? "null" : this.AccessToken == string.Empty ? "" : this.AccessToken)}");
            toStringOutput.Add($"this.Request = {(this.Request == null ? "null" : this.Request.ToString())}");
        }
    }
}