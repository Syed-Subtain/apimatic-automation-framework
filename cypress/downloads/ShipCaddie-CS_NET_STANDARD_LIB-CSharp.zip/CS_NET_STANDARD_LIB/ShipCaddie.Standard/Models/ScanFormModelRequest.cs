// <copyright file="ScanFormModelRequest.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace ShipCaddie.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using ShipCaddie.Standard;
    using ShipCaddie.Standard.Utilities;

    /// <summary>
    /// ScanFormModelRequest.
    /// </summary>
    public class ScanFormModelRequest
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ScanFormModelRequest"/> class.
        /// </summary>
        public ScanFormModelRequest()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ScanFormModelRequest"/> class.
        /// </summary>
        /// <param name="carrierClientContractId">carrierClientContractId.</param>
        /// <param name="shipmentClientAddressId">shipmentClientAddressId.</param>
        /// <param name="shipDate">shipDate.</param>
        /// <param name="keyList">keyList.</param>
        /// <param name="recentScanFormId">recentScanFormId.</param>
        public ScanFormModelRequest(
            int? carrierClientContractId = null,
            int? shipmentClientAddressId = null,
            DateTime? shipDate = null,
            List<Models.KeyValues> keyList = null,
            int? recentScanFormId = null)
        {
            this.CarrierClientContractId = carrierClientContractId;
            this.ShipmentClientAddressId = shipmentClientAddressId;
            this.ShipDate = shipDate;
            this.KeyList = keyList;
            this.RecentScanFormId = recentScanFormId;
        }

        /// <summary>
        /// Gets or sets CarrierClientContractId.
        /// </summary>
        [JsonProperty("carrierClientContractId", NullValueHandling = NullValueHandling.Ignore)]
        public int? CarrierClientContractId { get; set; }

        /// <summary>
        /// Gets or sets ShipmentClientAddressId.
        /// </summary>
        [JsonProperty("shipmentClientAddressId", NullValueHandling = NullValueHandling.Ignore)]
        public int? ShipmentClientAddressId { get; set; }

        /// <summary>
        /// Gets or sets ShipDate.
        /// </summary>
        [JsonConverter(typeof(IsoDateTimeConverter))]
        [JsonProperty("shipDate", NullValueHandling = NullValueHandling.Ignore)]
        public DateTime? ShipDate { get; set; }

        /// <summary>
        /// Gets or sets KeyList.
        /// </summary>
        [JsonProperty("keyList", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.KeyValues> KeyList { get; set; }

        /// <summary>
        /// Gets or sets RecentScanFormId.
        /// </summary>
        [JsonProperty("recentScanFormId", NullValueHandling = NullValueHandling.Ignore)]
        public int? RecentScanFormId { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"ScanFormModelRequest : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is ScanFormModelRequest other &&
                ((this.CarrierClientContractId == null && other.CarrierClientContractId == null) || (this.CarrierClientContractId?.Equals(other.CarrierClientContractId) == true)) &&
                ((this.ShipmentClientAddressId == null && other.ShipmentClientAddressId == null) || (this.ShipmentClientAddressId?.Equals(other.ShipmentClientAddressId) == true)) &&
                ((this.ShipDate == null && other.ShipDate == null) || (this.ShipDate?.Equals(other.ShipDate) == true)) &&
                ((this.KeyList == null && other.KeyList == null) || (this.KeyList?.Equals(other.KeyList) == true)) &&
                ((this.RecentScanFormId == null && other.RecentScanFormId == null) || (this.RecentScanFormId?.Equals(other.RecentScanFormId) == true));
        }

        /// <inheritdoc/>
        public override int GetHashCode()
        {
            int hashCode = 1331491778;

            if (this.CarrierClientContractId != null)
            {
               hashCode += this.CarrierClientContractId.GetHashCode();
            }

            if (this.ShipmentClientAddressId != null)
            {
               hashCode += this.ShipmentClientAddressId.GetHashCode();
            }

            if (this.ShipDate != null)
            {
               hashCode += this.ShipDate.GetHashCode();
            }

            if (this.KeyList != null)
            {
               hashCode += this.KeyList.GetHashCode();
            }

            if (this.RecentScanFormId != null)
            {
               hashCode += this.RecentScanFormId.GetHashCode();
            }

            return hashCode;
        }

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.CarrierClientContractId = {(this.CarrierClientContractId == null ? "null" : this.CarrierClientContractId.ToString())}");
            toStringOutput.Add($"this.ShipmentClientAddressId = {(this.ShipmentClientAddressId == null ? "null" : this.ShipmentClientAddressId.ToString())}");
            toStringOutput.Add($"this.ShipDate = {(this.ShipDate == null ? "null" : this.ShipDate.ToString())}");
            toStringOutput.Add($"this.KeyList = {(this.KeyList == null ? "null" : $"[{string.Join(", ", this.KeyList)} ]")}");
            toStringOutput.Add($"this.RecentScanFormId = {(this.RecentScanFormId == null ? "null" : this.RecentScanFormId.ToString())}");
        }
    }
}