// <copyright file="CodTypeEnum.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace ShipCaddie.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Runtime.Serialization;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using ShipCaddie.Standard;
    using ShipCaddie.Standard.Utilities;

    /// <summary>
    /// CodTypeEnum.
    /// </summary>
    [JsonConverter(typeof(StringEnumConverter))]
    public enum CodTypeEnum
    {
        /// <summary>
        /// NOTAPPLICABLE.
        /// </summary>
        [EnumMember(Value = "NOT_APPLICABLE")]
        NOTAPPLICABLE,

        /// <summary>
        /// CODSECUREDFUNDS.
        /// </summary>
        [EnumMember(Value = "COD_SECURED_FUNDS")]
        CODSECUREDFUNDS,

        /// <summary>
        /// CODCASH.
        /// </summary>
        [EnumMember(Value = "COD_CASH")]
        CODCASH,

        /// <summary>
        /// CODCHECK.
        /// </summary>
        [EnumMember(Value = "COD_CHECK")]
        CODCHECK,

        /// <summary>
        /// CODANY.
        /// </summary>
        [EnumMember(Value = "COD_ANY")]
        CODANY,
    }
}