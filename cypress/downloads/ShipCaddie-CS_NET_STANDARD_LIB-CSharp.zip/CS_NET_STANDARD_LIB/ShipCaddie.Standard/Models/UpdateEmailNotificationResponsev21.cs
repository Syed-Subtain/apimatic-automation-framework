// <copyright file="UpdateEmailNotificationResponsev21.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace ShipCaddie.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using ShipCaddie.Standard;
    using ShipCaddie.Standard.Utilities;

    /// <summary>
    /// UpdateEmailNotificationResponsev21.
    /// </summary>
    public class UpdateEmailNotificationResponsev21
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="UpdateEmailNotificationResponsev21"/> class.
        /// </summary>
        public UpdateEmailNotificationResponsev21()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="UpdateEmailNotificationResponsev21"/> class.
        /// </summary>
        /// <param name="successfullyUpdatedEmailNotification">successfullyUpdatedEmailNotification.</param>
        /// <param name="error">error.</param>
        public UpdateEmailNotificationResponsev21(
            bool successfullyUpdatedEmailNotification,
            Models.RequestError error)
        {
            this.SuccessfullyUpdatedEmailNotification = successfullyUpdatedEmailNotification;
            this.Error = error;
        }

        /// <summary>
        /// True if update has completed successfully.
        /// False otherwise.
        /// </summary>
        [JsonProperty("successfullyUpdatedEmailNotification")]
        public bool SuccessfullyUpdatedEmailNotification { get; set; }

        /// <summary>
        /// This information can be used to determine if an error has occurred when a request was processed.
        /// </summary>
        [JsonProperty("error")]
        public Models.RequestError Error { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"UpdateEmailNotificationResponsev21 : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is UpdateEmailNotificationResponsev21 other &&
                this.SuccessfullyUpdatedEmailNotification.Equals(other.SuccessfullyUpdatedEmailNotification) &&
                ((this.Error == null && other.Error == null) || (this.Error?.Equals(other.Error) == true));
        }

        /// <inheritdoc/>
        public override int GetHashCode()
        {
            int hashCode = -526930483;
            hashCode += this.SuccessfullyUpdatedEmailNotification.GetHashCode();

            if (this.Error != null)
            {
               hashCode += this.Error.GetHashCode();
            }

            return hashCode;
        }

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.SuccessfullyUpdatedEmailNotification = {this.SuccessfullyUpdatedEmailNotification}");
            toStringOutput.Add($"this.Error = {(this.Error == null ? "null" : this.Error.ToString())}");
        }
    }
}