// <copyright file="CODOptions.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace ShipCaddie.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using ShipCaddie.Standard;
    using ShipCaddie.Standard.Utilities;

    /// <summary>
    /// CODOptions.
    /// </summary>
    public class CODOptions
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="CODOptions"/> class.
        /// </summary>
        public CODOptions()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="CODOptions"/> class.
        /// </summary>
        /// <param name="codType">codType.</param>
        /// <param name="codAmount">codAmount.</param>
        public CODOptions(
            Models.CodTypeEnum? codType = null,
            double? codAmount = null)
        {
            this.CodType = codType;
            this.CodAmount = codAmount;
        }

        /// <summary>
        /// Gets or sets CodType.
        /// </summary>
        [JsonProperty("codType", ItemConverterType = typeof(StringEnumConverter), NullValueHandling = NullValueHandling.Ignore)]
        public Models.CodTypeEnum? CodType { get; set; }

        /// <summary>
        /// If COD is used,
        /// specify the amount in
        /// US Currency.
        /// </summary>
        [JsonProperty("codAmount", NullValueHandling = NullValueHandling.Ignore)]
        public double? CodAmount { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"CODOptions : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is CODOptions other &&
                ((this.CodType == null && other.CodType == null) || (this.CodType?.Equals(other.CodType) == true)) &&
                ((this.CodAmount == null && other.CodAmount == null) || (this.CodAmount?.Equals(other.CodAmount) == true));
        }

        /// <inheritdoc/>
        public override int GetHashCode()
        {
            int hashCode = 279968652;

            if (this.CodType != null)
            {
               hashCode += this.CodType.GetHashCode();
            }

            if (this.CodAmount != null)
            {
               hashCode += this.CodAmount.GetHashCode();
            }

            return hashCode;
        }

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.CodType = {(this.CodType == null ? "null" : this.CodType.ToString())}");
            toStringOutput.Add($"this.CodAmount = {(this.CodAmount == null ? "null" : this.CodAmount.ToString())}");
        }
    }
}