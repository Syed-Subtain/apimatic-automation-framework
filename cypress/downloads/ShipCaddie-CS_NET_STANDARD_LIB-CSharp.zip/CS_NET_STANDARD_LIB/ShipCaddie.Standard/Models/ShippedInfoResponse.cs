// <copyright file="ShippedInfoResponse.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace ShipCaddie.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using ShipCaddie.Standard;
    using ShipCaddie.Standard.Utilities;

    /// <summary>
    /// ShippedInfoResponse.
    /// </summary>
    public class ShippedInfoResponse
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ShippedInfoResponse"/> class.
        /// </summary>
        public ShippedInfoResponse()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ShippedInfoResponse"/> class.
        /// </summary>
        /// <param name="error">error.</param>
        /// <param name="shipmentId">shipmentId.</param>
        /// <param name="dateShipped">dateShipped.</param>
        /// <param name="fromAddress">fromAddress.</param>
        /// <param name="toAddress">toAddress.</param>
        /// <param name="shipmentOptions">shipmentOptions.</param>
        /// <param name="carrier">carrier.</param>
        /// <param name="parcelInfo">parcelInfo.</param>
        public ShippedInfoResponse(
            Models.RequestError error,
            int? shipmentId = null,
            DateTime? dateShipped = null,
            Models.ShipFromAddress fromAddress = null,
            Models.ShipToAddress toAddress = null,
            Models.ShippingOptions shipmentOptions = null,
            Models.ShippedInfoCarrier carrier = null,
            List<Models.ShippedInfoParcel> parcelInfo = null)
        {
            this.ShipmentId = shipmentId;
            this.DateShipped = dateShipped;
            this.FromAddress = fromAddress;
            this.ToAddress = toAddress;
            this.ShipmentOptions = shipmentOptions;
            this.Carrier = carrier;
            this.ParcelInfo = parcelInfo;
            this.Error = error;
        }

        /// <summary>
        /// Id used to identify shipment.
        /// </summary>
        [JsonProperty("shipmentId", NullValueHandling = NullValueHandling.Ignore)]
        public int? ShipmentId { get; set; }

        /// <summary>
        /// Specifies the date of shipment.
        /// </summary>
        [JsonConverter(typeof(IsoDateTimeConverter))]
        [JsonProperty("dateShipped", NullValueHandling = NullValueHandling.Ignore)]
        public DateTime? DateShipped { get; set; }

        /// <summary>
        /// Gets or sets FromAddress.
        /// </summary>
        [JsonProperty("fromAddress", NullValueHandling = NullValueHandling.Ignore)]
        public Models.ShipFromAddress FromAddress { get; set; }

        /// <summary>
        /// Gets or sets ToAddress.
        /// </summary>
        [JsonProperty("toAddress", NullValueHandling = NullValueHandling.Ignore)]
        public Models.ShipToAddress ToAddress { get; set; }

        /// <summary>
        /// Billing and Custom Declaration Options for Shipping.
        /// </summary>
        [JsonProperty("shipmentOptions", NullValueHandling = NullValueHandling.Ignore)]
        public Models.ShippingOptions ShipmentOptions { get; set; }

        /// <summary>
        /// Gets or sets Carrier.
        /// </summary>
        [JsonProperty("carrier", NullValueHandling = NullValueHandling.Ignore)]
        public Models.ShippedInfoCarrier Carrier { get; set; }

        /// <summary>
        /// The information about the packages in the shipment.
        /// </summary>
        [JsonProperty("parcelInfo", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.ShippedInfoParcel> ParcelInfo { get; set; }

        /// <summary>
        /// This information can be used to determine if an error has occurred when a request was processed.
        /// </summary>
        [JsonProperty("error")]
        public Models.RequestError Error { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"ShippedInfoResponse : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is ShippedInfoResponse other &&
                ((this.ShipmentId == null && other.ShipmentId == null) || (this.ShipmentId?.Equals(other.ShipmentId) == true)) &&
                ((this.DateShipped == null && other.DateShipped == null) || (this.DateShipped?.Equals(other.DateShipped) == true)) &&
                ((this.FromAddress == null && other.FromAddress == null) || (this.FromAddress?.Equals(other.FromAddress) == true)) &&
                ((this.ToAddress == null && other.ToAddress == null) || (this.ToAddress?.Equals(other.ToAddress) == true)) &&
                ((this.ShipmentOptions == null && other.ShipmentOptions == null) || (this.ShipmentOptions?.Equals(other.ShipmentOptions) == true)) &&
                ((this.Carrier == null && other.Carrier == null) || (this.Carrier?.Equals(other.Carrier) == true)) &&
                ((this.ParcelInfo == null && other.ParcelInfo == null) || (this.ParcelInfo?.Equals(other.ParcelInfo) == true)) &&
                ((this.Error == null && other.Error == null) || (this.Error?.Equals(other.Error) == true));
        }

        /// <inheritdoc/>
        public override int GetHashCode()
        {
            int hashCode = -1508991683;

            if (this.ShipmentId != null)
            {
               hashCode += this.ShipmentId.GetHashCode();
            }

            if (this.DateShipped != null)
            {
               hashCode += this.DateShipped.GetHashCode();
            }

            if (this.FromAddress != null)
            {
               hashCode += this.FromAddress.GetHashCode();
            }

            if (this.ToAddress != null)
            {
               hashCode += this.ToAddress.GetHashCode();
            }

            if (this.ShipmentOptions != null)
            {
               hashCode += this.ShipmentOptions.GetHashCode();
            }

            if (this.Carrier != null)
            {
               hashCode += this.Carrier.GetHashCode();
            }

            if (this.ParcelInfo != null)
            {
               hashCode += this.ParcelInfo.GetHashCode();
            }

            if (this.Error != null)
            {
               hashCode += this.Error.GetHashCode();
            }

            return hashCode;
        }

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.ShipmentId = {(this.ShipmentId == null ? "null" : this.ShipmentId.ToString())}");
            toStringOutput.Add($"this.DateShipped = {(this.DateShipped == null ? "null" : this.DateShipped.ToString())}");
            toStringOutput.Add($"this.FromAddress = {(this.FromAddress == null ? "null" : this.FromAddress.ToString())}");
            toStringOutput.Add($"this.ToAddress = {(this.ToAddress == null ? "null" : this.ToAddress.ToString())}");
            toStringOutput.Add($"this.ShipmentOptions = {(this.ShipmentOptions == null ? "null" : this.ShipmentOptions.ToString())}");
            toStringOutput.Add($"this.Carrier = {(this.Carrier == null ? "null" : this.Carrier.ToString())}");
            toStringOutput.Add($"this.ParcelInfo = {(this.ParcelInfo == null ? "null" : $"[{string.Join(", ", this.ParcelInfo)} ]")}");
            toStringOutput.Add($"this.Error = {(this.Error == null ? "null" : this.Error.ToString())}");
        }
    }
}