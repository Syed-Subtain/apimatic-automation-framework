// <copyright file="PackagingDetail.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace ShipCaddie.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using ShipCaddie.Standard;
    using ShipCaddie.Standard.Utilities;

    /// <summary>
    /// PackagingDetail.
    /// </summary>
    public class PackagingDetail
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="PackagingDetail"/> class.
        /// </summary>
        public PackagingDetail()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="PackagingDetail"/> class.
        /// </summary>
        /// <param name="parcelId">parcelId.</param>
        /// <param name="name">name.</param>
        /// <param name="description">description.</param>
        /// <param name="lengthInInches">lengthInInches.</param>
        /// <param name="widthInInches">widthInInches.</param>
        /// <param name="heightInInches">heightInInches.</param>
        /// <param name="weightLimit">weightLimit.</param>
        /// <param name="packagingWeight">packagingWeight.</param>
        public PackagingDetail(
            string parcelId = null,
            string name = null,
            string description = null,
            double? lengthInInches = null,
            double? widthInInches = null,
            double? heightInInches = null,
            double? weightLimit = null,
            double? packagingWeight = null)
        {
            this.ParcelId = parcelId;
            this.Name = name;
            this.Description = description;
            this.LengthInInches = lengthInInches;
            this.WidthInInches = widthInInches;
            this.HeightInInches = heightInInches;
            this.WeightLimit = weightLimit;
            this.PackagingWeight = packagingWeight;
        }

        /// <summary>
        /// This ID can be used when specifing a Parcel type.
        /// </summary>
        [JsonProperty("parcelId", NullValueHandling = NullValueHandling.Ignore)]
        public string ParcelId { get; set; }

        /// <summary>
        /// Parcel Type
        /// </summary>
        [JsonProperty("name", NullValueHandling = NullValueHandling.Ignore)]
        public string Name { get; set; }

        /// <summary>
        /// Parcel Description
        /// </summary>
        [JsonProperty("description", NullValueHandling = NullValueHandling.Ignore)]
        public string Description { get; set; }

        /// <summary>
        /// Length of one side of parcel in inches.
        /// </summary>
        [JsonProperty("lengthInInches", NullValueHandling = NullValueHandling.Ignore)]
        public double? LengthInInches { get; set; }

        /// <summary>
        /// Width of one side of parcel in inches.
        /// </summary>
        [JsonProperty("widthInInches", NullValueHandling = NullValueHandling.Ignore)]
        public double? WidthInInches { get; set; }

        /// <summary>
        /// Height of one side of parcel in inches.
        /// </summary>
        [JsonProperty("heightInInches", NullValueHandling = NullValueHandling.Ignore)]
        public double? HeightInInches { get; set; }

        /// <summary>
        /// Carrier Weight limit for the parcel
        /// </summary>
        [JsonProperty("weightLimit", NullValueHandling = NullValueHandling.Ignore)]
        public double? WeightLimit { get; set; }

        /// <summary>
        /// Container weight
        /// </summary>
        [JsonProperty("packagingWeight", NullValueHandling = NullValueHandling.Ignore)]
        public double? PackagingWeight { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"PackagingDetail : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is PackagingDetail other &&
                ((this.ParcelId == null && other.ParcelId == null) || (this.ParcelId?.Equals(other.ParcelId) == true)) &&
                ((this.Name == null && other.Name == null) || (this.Name?.Equals(other.Name) == true)) &&
                ((this.Description == null && other.Description == null) || (this.Description?.Equals(other.Description) == true)) &&
                ((this.LengthInInches == null && other.LengthInInches == null) || (this.LengthInInches?.Equals(other.LengthInInches) == true)) &&
                ((this.WidthInInches == null && other.WidthInInches == null) || (this.WidthInInches?.Equals(other.WidthInInches) == true)) &&
                ((this.HeightInInches == null && other.HeightInInches == null) || (this.HeightInInches?.Equals(other.HeightInInches) == true)) &&
                ((this.WeightLimit == null && other.WeightLimit == null) || (this.WeightLimit?.Equals(other.WeightLimit) == true)) &&
                ((this.PackagingWeight == null && other.PackagingWeight == null) || (this.PackagingWeight?.Equals(other.PackagingWeight) == true));
        }

        /// <inheritdoc/>
        public override int GetHashCode()
        {
            int hashCode = -851721930;

            if (this.ParcelId != null)
            {
               hashCode += this.ParcelId.GetHashCode();
            }

            if (this.Name != null)
            {
               hashCode += this.Name.GetHashCode();
            }

            if (this.Description != null)
            {
               hashCode += this.Description.GetHashCode();
            }

            if (this.LengthInInches != null)
            {
               hashCode += this.LengthInInches.GetHashCode();
            }

            if (this.WidthInInches != null)
            {
               hashCode += this.WidthInInches.GetHashCode();
            }

            if (this.HeightInInches != null)
            {
               hashCode += this.HeightInInches.GetHashCode();
            }

            if (this.WeightLimit != null)
            {
               hashCode += this.WeightLimit.GetHashCode();
            }

            if (this.PackagingWeight != null)
            {
               hashCode += this.PackagingWeight.GetHashCode();
            }

            return hashCode;
        }

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.ParcelId = {(this.ParcelId == null ? "null" : this.ParcelId == string.Empty ? "" : this.ParcelId)}");
            toStringOutput.Add($"this.Name = {(this.Name == null ? "null" : this.Name == string.Empty ? "" : this.Name)}");
            toStringOutput.Add($"this.Description = {(this.Description == null ? "null" : this.Description == string.Empty ? "" : this.Description)}");
            toStringOutput.Add($"this.LengthInInches = {(this.LengthInInches == null ? "null" : this.LengthInInches.ToString())}");
            toStringOutput.Add($"this.WidthInInches = {(this.WidthInInches == null ? "null" : this.WidthInInches.ToString())}");
            toStringOutput.Add($"this.HeightInInches = {(this.HeightInInches == null ? "null" : this.HeightInInches.ToString())}");
            toStringOutput.Add($"this.WeightLimit = {(this.WeightLimit == null ? "null" : this.WeightLimit.ToString())}");
            toStringOutput.Add($"this.PackagingWeight = {(this.PackagingWeight == null ? "null" : this.PackagingWeight.ToString())}");
        }
    }
}