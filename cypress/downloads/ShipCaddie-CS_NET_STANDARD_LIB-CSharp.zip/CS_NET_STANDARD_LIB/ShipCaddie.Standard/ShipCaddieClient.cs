// <copyright file="ShipCaddieClient.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace ShipCaddie.Standard
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Net;
    using System.Text;
    using ShipCaddie.Standard.Authentication;
    using ShipCaddie.Standard.Controllers;
    using ShipCaddie.Standard.Http.Client;
    using ShipCaddie.Standard.Utilities;

    /// <summary>
    /// The gateway for the SDK. This class acts as a factory for Controller and
    /// holds the configuration of the SDK.
    /// </summary>
    public sealed class ShipCaddieClient : IConfiguration
    {
        // A map of environments and their corresponding servers/baseurls
        private static readonly Dictionary<Environment, Dictionary<Server, string>> EnvironmentsMap =
            new Dictionary<Environment, Dictionary<Server, string>>
        {
            {
                Environment.Production, new Dictionary<Server, string>
                {
                    { Server.Server1, "https://api.shipcaddie.com/" },
                    { Server.Server2, "http://api.shipcaddie.com/" },
                }
            },
        };

        private readonly IDictionary<string, IAuthManager> authManagers;
        private readonly IHttpClient httpClient;
        private readonly AccessTokenManager accessTokenManager;

        private readonly Lazy<ShipmentsController> shipments;
        private readonly Lazy<ManifestController> manifest;
        private readonly Lazy<AccountInformationController> accountInformation;
        private readonly Lazy<CarrierDetailsController> carrierDetails;
        private readonly Lazy<ChildAccountsController> childAccounts;
        private readonly Lazy<CountryCodesController> countryCodes;
        private readonly Lazy<RatesController> rates;
        private readonly Lazy<RatesDisplayController> ratesDisplay;
        private readonly Lazy<LabelsController> labels;
        private readonly Lazy<AuthenticationController> authentication;
        private readonly Lazy<RegistrationController> registration;
        private readonly Lazy<EmailNotificationsController> emailNotifications;
        private readonly Lazy<AddressValidationController> addressValidation;
        private readonly Lazy<AddressValidationShipmentController> addressValidationShipment;

        private ShipCaddieClient(
            Environment environment,
            string accessToken,
            IDictionary<string, IAuthManager> authManagers,
            IHttpClient httpClient,
            IHttpClientConfiguration httpClientConfiguration)
        {
            this.Environment = environment;
            this.httpClient = httpClient;
            this.authManagers = (authManagers == null) ? new Dictionary<string, IAuthManager>() : new Dictionary<string, IAuthManager>(authManagers);
            this.HttpClientConfiguration = httpClientConfiguration;

            this.shipments = new Lazy<ShipmentsController>(
                () => new ShipmentsController(this, this.httpClient, this.authManagers));
            this.manifest = new Lazy<ManifestController>(
                () => new ManifestController(this, this.httpClient, this.authManagers));
            this.accountInformation = new Lazy<AccountInformationController>(
                () => new AccountInformationController(this, this.httpClient, this.authManagers));
            this.carrierDetails = new Lazy<CarrierDetailsController>(
                () => new CarrierDetailsController(this, this.httpClient, this.authManagers));
            this.childAccounts = new Lazy<ChildAccountsController>(
                () => new ChildAccountsController(this, this.httpClient, this.authManagers));
            this.countryCodes = new Lazy<CountryCodesController>(
                () => new CountryCodesController(this, this.httpClient, this.authManagers));
            this.rates = new Lazy<RatesController>(
                () => new RatesController(this, this.httpClient, this.authManagers));
            this.ratesDisplay = new Lazy<RatesDisplayController>(
                () => new RatesDisplayController(this, this.httpClient, this.authManagers));
            this.labels = new Lazy<LabelsController>(
                () => new LabelsController(this, this.httpClient, this.authManagers));
            this.authentication = new Lazy<AuthenticationController>(
                () => new AuthenticationController(this, this.httpClient, this.authManagers));
            this.registration = new Lazy<RegistrationController>(
                () => new RegistrationController(this, this.httpClient, this.authManagers));
            this.emailNotifications = new Lazy<EmailNotificationsController>(
                () => new EmailNotificationsController(this, this.httpClient, this.authManagers));
            this.addressValidation = new Lazy<AddressValidationController>(
                () => new AddressValidationController(this, this.httpClient, this.authManagers));
            this.addressValidationShipment = new Lazy<AddressValidationShipmentController>(
                () => new AddressValidationShipmentController(this, this.httpClient, this.authManagers));

            if (this.authManagers.ContainsKey("global"))
            {
                this.accessTokenManager = (AccessTokenManager)this.authManagers["global"];
            }

            if (!this.authManagers.ContainsKey("global")
                || !this.AccessTokenCredentials.Equals(accessToken))
            {
                this.accessTokenManager = new AccessTokenManager(accessToken);
                this.authManagers["global"] = this.accessTokenManager;
            }
        }

        /// <summary>
        /// Gets ShipmentsController controller.
        /// </summary>
        public ShipmentsController ShipmentsController => this.shipments.Value;

        /// <summary>
        /// Gets ManifestController controller.
        /// </summary>
        public ManifestController ManifestController => this.manifest.Value;

        /// <summary>
        /// Gets AccountInformationController controller.
        /// </summary>
        public AccountInformationController AccountInformationController => this.accountInformation.Value;

        /// <summary>
        /// Gets CarrierDetailsController controller.
        /// </summary>
        public CarrierDetailsController CarrierDetailsController => this.carrierDetails.Value;

        /// <summary>
        /// Gets ChildAccountsController controller.
        /// </summary>
        public ChildAccountsController ChildAccountsController => this.childAccounts.Value;

        /// <summary>
        /// Gets CountryCodesController controller.
        /// </summary>
        public CountryCodesController CountryCodesController => this.countryCodes.Value;

        /// <summary>
        /// Gets RatesController controller.
        /// </summary>
        public RatesController RatesController => this.rates.Value;

        /// <summary>
        /// Gets RatesDisplayController controller.
        /// </summary>
        public RatesDisplayController RatesDisplayController => this.ratesDisplay.Value;

        /// <summary>
        /// Gets LabelsController controller.
        /// </summary>
        public LabelsController LabelsController => this.labels.Value;

        /// <summary>
        /// Gets AuthenticationController controller.
        /// </summary>
        public AuthenticationController AuthenticationController => this.authentication.Value;

        /// <summary>
        /// Gets RegistrationController controller.
        /// </summary>
        public RegistrationController RegistrationController => this.registration.Value;

        /// <summary>
        /// Gets EmailNotificationsController controller.
        /// </summary>
        public EmailNotificationsController EmailNotificationsController => this.emailNotifications.Value;

        /// <summary>
        /// Gets AddressValidationController controller.
        /// </summary>
        public AddressValidationController AddressValidationController => this.addressValidation.Value;

        /// <summary>
        /// Gets AddressValidationShipmentController controller.
        /// </summary>
        public AddressValidationShipmentController AddressValidationShipmentController => this.addressValidationShipment.Value;

        /// <summary>
        /// Gets the configuration of the Http Client associated with this client.
        /// </summary>
        public IHttpClientConfiguration HttpClientConfiguration { get; }

        /// <summary>
        /// Gets Environment.
        /// Current API environment.
        /// </summary>
        public Environment Environment { get; }

        /// <summary>
        /// Gets auth managers.
        /// </summary>
        internal IDictionary<string, IAuthManager> AuthManagers => this.authManagers;

        /// <summary>
        /// Gets http client.
        /// </summary>
        internal IHttpClient HttpClient => this.httpClient;

        /// <summary>
        /// Gets the credentials to use with AccessToken.
        /// </summary>
        private IAccessTokenCredentials AccessTokenCredentials => this.accessTokenManager;

        /// <summary>
        /// Gets the access token to use with OAuth 2 authentication.
        /// </summary>
        public string AccessToken => this.AccessTokenCredentials.AccessToken;

        /// <summary>
        /// Gets the URL for a particular alias in the current environment and appends
        /// it with template parameters.
        /// </summary>
        /// <param name="alias">Default value:SERVER1.</param>
        /// <returns>Returns the baseurl.</returns>
        public string GetBaseUri(Server alias = Server.Server1)
        {
            StringBuilder url = new StringBuilder(EnvironmentsMap[this.Environment][alias]);
            ApiHelper.AppendUrlWithTemplateParameters(url, this.GetBaseUriParameters());

            return url.ToString();
        }

        /// <summary>
        /// Creates an object of the ShipCaddieClient using the values provided for the builder.
        /// </summary>
        /// <returns>Builder.</returns>
        public Builder ToBuilder()
        {
            Builder builder = new Builder()
                .Environment(this.Environment)
                .AccessToken(this.AccessTokenCredentials.AccessToken)
                .HttpClient(this.httpClient)
                .AuthManagers(this.authManagers)
                .HttpClientConfig(config => config.Build());

            return builder;
        }

        /// <inheritdoc/>
        public override string ToString()
        {
            return
                $"Environment = {this.Environment}, " +
                $"HttpClientConfiguration = {this.HttpClientConfiguration}, ";
        }

        /// <summary>
        /// Creates the client using builder.
        /// </summary>
        /// <returns> ShipCaddieClient.</returns>
        internal static ShipCaddieClient CreateFromEnvironment()
        {
            var builder = new Builder();

            string environment = System.Environment.GetEnvironmentVariable("SHIP_CADDIE_STANDARD_ENVIRONMENT");
            string accessToken = System.Environment.GetEnvironmentVariable("SHIP_CADDIE_STANDARD_ACCESS_TOKEN");

            if (environment != null)
            {
                builder.Environment(ApiHelper.JsonDeserialize<Environment>($"\"{environment}\""));
            }

            if (accessToken != null)
            {
                builder.AccessToken(accessToken);
            }

            return builder.Build();
        }

        /// <summary>
        /// Makes a list of the BaseURL parameters.
        /// </summary>
        /// <returns>Returns the parameters list.</returns>
        private List<KeyValuePair<string, object>> GetBaseUriParameters()
        {
            List<KeyValuePair<string, object>> kvpList = new List<KeyValuePair<string, object>>()
            {
            };
            return kvpList;
        }

        /// <summary>
        /// Builder class.
        /// </summary>
        public class Builder
        {
            private Environment environment = ShipCaddie.Standard.Environment.Production;
            private string accessToken = "TODO: Replace";
            private IDictionary<string, IAuthManager> authManagers = new Dictionary<string, IAuthManager>();
            private HttpClientConfiguration.Builder httpClientConfig = new HttpClientConfiguration.Builder();
            private IHttpClient httpClient;

            /// <summary>
            /// Sets credentials for AccessToken.
            /// </summary>
            /// <param name="accessToken">AccessToken.</param>
            /// <returns>Builder.</returns>
            public Builder AccessToken(string accessToken)
            {
                this.accessToken = accessToken ?? throw new ArgumentNullException(nameof(accessToken));
                return this;
            }

            /// <summary>
            /// Sets Environment.
            /// </summary>
            /// <param name="environment"> Environment. </param>
            /// <returns> Builder. </returns>
            public Builder Environment(Environment environment)
            {
                this.environment = environment;
                return this;
            }

            /// <summary>
            /// Sets HttpClientConfig.
            /// </summary>
            /// <param name="action"> Action. </param>
            /// <returns>Builder.</returns>
            public Builder HttpClientConfig(Action<HttpClientConfiguration.Builder> action)
            {
                if (action is null)
                {
                    throw new ArgumentNullException(nameof(action));
                }

                action(this.httpClientConfig);
                return this;
            }

            /// <summary>
            /// Sets the IHttpClient for the Builder.
            /// </summary>
            /// <param name="httpClient"> http client. </param>
            /// <returns>Builder.</returns>
            internal Builder HttpClient(IHttpClient httpClient)
            {
                this.httpClient = httpClient ?? throw new ArgumentNullException(nameof(httpClient));
                return this;
            }

            /// <summary>
            /// Sets the authentication managers for the Builder.
            /// </summary>
            /// <param name="authManagers"> auth managers. </param>
            /// <returns>Builder.</returns>
            internal Builder AuthManagers(IDictionary<string, IAuthManager> authManagers)
            {
                this.authManagers = authManagers ?? throw new ArgumentNullException(nameof(authManagers));
                return this;
            }

            /// <summary>
            /// Creates an object of the ShipCaddieClient using the values provided for the builder.
            /// </summary>
            /// <returns>ShipCaddieClient.</returns>
            public ShipCaddieClient Build()
            {
                this.httpClient = new HttpClientWrapper(this.httpClientConfig.Build());

                return new ShipCaddieClient(
                    this.environment,
                    this.accessToken,
                    this.authManagers,
                    this.httpClient,
                    this.httpClientConfig.Build());
            }
        }
    }
}
