
# Client Class Documentation

The following parameters are configurable for the API Client:

| Parameter | Type | Description |
|  --- | --- | --- |
| `contentType` | `String` | *Default*: `"application/x-www-form-urlencoded"` |
| `instanceURL` | `String` | Replace yourinstance.transtream.com with the URL of your instance. You will also need to change the API Key for your request to be authorized.<br>*Default*: `"yourinstance.transtream.com"` |
| `environment` | Environment | The API environment. <br> **Default: `Environment.PRODUCTION`** |
| `httpClientConfig` | `ReadonlyHttpClientConfiguration` | Http Client Configuration instance. |
| `apikey` | `String` | Enter your provided API key for your system here<br>*Default*: `"<Obtain API Key>"` |

The API client can be initialized as follows:

```java
ShippingAPIClient client = new ShippingAPIClient.Builder()
    .httpClientConfig(configBuilder -> configBuilder
            .timeout(0))
    .contentType("application/x-www-form-urlencoded")
    .customQueryAuthenticationCredentials("<Obtain API Key>")
    .environment(Environment.PRODUCTION)
    .instanceURL("yourinstance.transtream.com")
    .build();
```

## Shipping APIClient Class

The gateway for the SDK. This class acts as a factory for the Controllers and also holds the configuration of the SDK.

### Controllers

| Name | Description | Return Type |
|  --- | --- | --- |
| `getShippingAPIController()` | Provides access to ShippingAPI controller. | `ShippingAPIController` |

### Methods

| Name | Description | Return Type |
|  --- | --- | --- |
| `shutdown()` | Shutdown the underlying HttpClient instance. | `void` |
| `getEnvironment()` | Current API environment. | `Environment` |
| `getInstanceURL()` | Replace yourinstance.transtream.com with the URL of your instance. You will also need to change the API Key for your request to be authorized. | `String` |
| `getContentType()` | . | `String` |
| `getHttpClient()` | The HTTP Client instance to use for making HTTP requests. | `HttpClient` |
| `getHttpClientConfig()` | Http Client Configuration instance. | `ReadonlyHttpClientConfiguration` |
| `getBaseUri(Server server)` | Get base URI by current environment | `String` |
| `getBaseUri()` | Get base URI by current environment | `String` |

