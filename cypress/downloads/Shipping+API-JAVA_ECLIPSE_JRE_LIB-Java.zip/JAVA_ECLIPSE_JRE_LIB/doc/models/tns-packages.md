
# Tns Packages

Container for all packages associated with the transaction.

## Structure

`TnsPackages`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Package` | [`List<TnsPackage>`](../../doc/models/tns-package.md) | Required | Container for an individual package associated with the transaction. | List<TnsPackage> getPackage() | setPackage(List<TnsPackage> mPackage) |

## Example (as JSON)

```json
{
  "Package": [
    {
      "Status": {
        "Code": 76,
        "Description": null,
        "Warnings": null,
        "Errors": null
      }
    }
  ]
}
```

