
# Wtg Point

## Structure

`WtgPoint`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `X` | `double` | Required | x coordinate, used as height. | double getX() | setX(double x) |
| `Y` | `double` | Required | y coordinate, used as width. | double getY() | setY(double y) |
| `Z` | `double` | Required | z coordinate, used as length. | double getZ() | setZ(double z) |

## Example (as XML)

```xml
<wtg:Point xmlns:wtg="https://www.wisetechglobal.com/">
  <wtg:x xmlns:wtg="https://www.wisetechglobal.com/">222.14</wtg:x>
  <wtg:y xmlns:wtg="https://www.wisetechglobal.com/">165.14</wtg:y>
  <wtg:z xmlns:wtg="https://www.wisetechglobal.com/">163.94</wtg:z>
</wtg:Point>
```

