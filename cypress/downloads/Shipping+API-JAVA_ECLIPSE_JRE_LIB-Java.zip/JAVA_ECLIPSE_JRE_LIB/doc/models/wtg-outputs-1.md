
# Wtg Outputs 1

Container for outputs the transaction should generate or customize the printing of.

## Structure

`WtgOutputs1`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Output` | [`List<WtgOutput2>`](../../doc/models/wtg-output-2.md) | Optional | Container for an output the transaction should generate or customize the printing of. | List<WtgOutput2> getOutput() | setOutput(List<WtgOutput2> output) |

## Example (as XML)

```xml
<wtg:Outputs xmlns:wtg="https://www.wisetechglobal.com/" />
```

