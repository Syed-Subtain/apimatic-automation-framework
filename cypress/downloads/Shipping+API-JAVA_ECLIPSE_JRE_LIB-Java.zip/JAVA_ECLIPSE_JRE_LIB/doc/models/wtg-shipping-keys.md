
# Wtg Shipping Keys

Container for shipping keys.

## Structure

`WtgShippingKeys`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `ShippingKey` | `List<String>` | Optional | Shipping key to perform the end of day action for. | List<String> getShippingKey() | setShippingKey(List<String> shippingKey) |

## Example (as XML)

```xml
<wtg:ShippingKeys xmlns:wtg="https://www.wisetechglobal.com/" />
```

