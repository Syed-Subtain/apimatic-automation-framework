
# Wtg Contents 7

Container for all contents (line items) associated with the transaction.

## Structure

`WtgContents7`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Content` | [`List<WtgContent7>`](../../doc/models/wtg-content-7.md) | Optional | Container for a individual content (line item) associated with the transaction. | List<WtgContent7> getContent() | setContent(List<WtgContent7> content) |

## Example (as XML)

```xml
<wtg:Contents xmlns:wtg="https://www.wisetechglobal.com/" />
```

