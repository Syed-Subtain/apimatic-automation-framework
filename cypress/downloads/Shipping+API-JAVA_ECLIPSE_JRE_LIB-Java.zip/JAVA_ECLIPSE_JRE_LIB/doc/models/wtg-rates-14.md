
# Wtg Rates 14

Container for all rates associated with the package

## Structure

`WtgRates14`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Rate` | [`List<WtgRate14>`](../../doc/models/wtg-rate-14.md) | Optional | Container for an individual rate associated with the package | List<WtgRate14> getRate() | setRate(List<WtgRate14> rate) |

## Example (as XML)

```xml
<wtg:Rates xmlns:wtg="https://www.wisetechglobal.com/" />
```

