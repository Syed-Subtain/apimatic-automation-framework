
# Wtg Status 3

Container for HubCapp printing status.

## Structure

`WtgStatus3`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Code` | `Integer` | Optional | If the transaction was successful this was will equal one, otherwise zero. | Integer getCode() | setCode(Integer code) |
| `Description` | `String` | Optional | Contains a description of the status, if the transaction failed this will contain an error message. | String getDescription() | setDescription(String description) |

## Example (as XML)

```xml
<wtg:Status xmlns:wtg="https://www.wisetechglobal.com/" />
```

