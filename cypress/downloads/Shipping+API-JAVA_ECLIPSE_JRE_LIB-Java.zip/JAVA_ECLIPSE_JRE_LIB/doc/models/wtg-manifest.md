
# Wtg Manifest

Container for a single manifest.

## Structure

`WtgManifest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `CarrierName` | `String` | Required | The name for the carrier. | String getCarrierName() | setCarrierName(String carrierName) |
| `Carrier` | `int` | Required | Numeric identifier for the carrier. | int getCarrier() | setCarrier(int carrier) |
| `ShipDate` | `LocalDate` | Required | The date associated with the carrier's manifest. | LocalDate getShipDate() | setShipDate(LocalDate shipDate) |
| `Identifier` | `String` | Optional | The carrier's identifier for the manifest. | String getIdentifier() | setIdentifier(String identifier) |
| `AccountNumber` | `String` | Optional | The number of the account associated with this carrier's manifest. | String getAccountNumber() | setAccountNumber(String accountNumber) |
| `ShippingKey` | `String` | Optional | The number of the account associated with this carrier's manifest. | String getShippingKey() | setShippingKey(String shippingKey) |

## Example (as XML)

```xml
<wtg:Manifest xmlns:wtg="https://www.wisetechglobal.com/">
  <wtg:CarrierName xmlns:wtg="https://www.wisetechglobal.com/">CarrierName6</wtg:CarrierName>
  <wtg:Carrier xmlns:wtg="https://www.wisetechglobal.com/">34</wtg:Carrier>
  <wtg:ShipDate xmlns:wtg="https://www.wisetechglobal.com/">2016-03-13</wtg:ShipDate>
</wtg:Manifest>
```

