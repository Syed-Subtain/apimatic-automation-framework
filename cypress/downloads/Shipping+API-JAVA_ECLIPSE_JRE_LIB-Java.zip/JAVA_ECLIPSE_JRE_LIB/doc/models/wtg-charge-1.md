
# Wtg Charge 1

Container for an individual charge within the group associated with the transaction.

## Structure

`WtgCharge1`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `ChargeType` | `String` | Optional | An identifier for the type of the charge. | String getChargeType() | setChargeType(String chargeType) |
| `ChargeDescription` | `String` | Optional | The description for the type of charge. | String getChargeDescription() | setChargeDescription(String chargeDescription) |
| `ChargeValue` | `String` | Optional | The value of the charge associated with the transaction. | String getChargeValue() | setChargeValue(String chargeValue) |
| `ChargeCurrency` | `String` | Optional | A code indicating the type of currency for the charge. | String getChargeCurrency() | setChargeCurrency(String chargeCurrency) |
| `ChargeISOCurrency` | `String` | Optional | International standard code for the charge group currency. | String getChargeISOCurrency() | setChargeISOCurrency(String chargeISOCurrency) |

## Example (as XML)

```xml
<wtg:Charge xmlns:wtg="https://www.wisetechglobal.com/" />
```

