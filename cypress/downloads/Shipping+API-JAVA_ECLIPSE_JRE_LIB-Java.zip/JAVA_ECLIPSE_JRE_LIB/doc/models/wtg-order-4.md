
# Wtg Order 4

Container for an individual order.

## Structure

`WtgOrder4`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `OrderID` | `Integer` | Optional | The ID associated with the order. | Integer getOrderID() | setOrderID(Integer orderID) |
| `OrderNumber` | `String` | Optional | The number associated with the order used in combination with the release number to identify the order. | String getOrderNumber() | setOrderNumber(String orderNumber) |

## Example (as XML)

```xml
<wtg:Order xmlns:wtg="https://www.wisetechglobal.com/" />
```

