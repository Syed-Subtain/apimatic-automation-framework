
# Wtg Pierbridge Void Response

Indicates the status of a Void request.

## Structure

`WtgPierbridgeVoidResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `TransactionIdentifier` | `String` | Optional | The unique identifier for the transaction given in the request. | String getTransactionIdentifier() | setTransactionIdentifier(String transactionIdentifier) |
| `ControlIdentifier` | `String` | Optional | The control reference for the transaction given in the request. | String getControlIdentifier() | setControlIdentifier(String controlIdentifier) |
| `Carrier` | `Integer` | Optional | Numeric identifier for the carrier.<br>**Default**: `0` | Integer getCarrier() | setCarrier(Integer carrier) |
| `CarrierName` | `String` | Optional | The name for the carrier. | String getCarrierName() | setCarrierName(String carrierName) |
| `CarrierScac` | `String` | Optional | The NMFTA (National Motor Freight Traffic Association) Standard Carrier Alpha Code of the carrier. | String getCarrierScac() | setCarrierScac(String carrierScac) |
| `PickListNumber` | `String` | Optional | The pick list number, used to identify the pick list. | String getPickListNumber() | setPickListNumber(String pickListNumber) |
| `PurchaseOrderNumber` | `String` | Optional | Purchase order number associated with the transaction. | String getPurchaseOrderNumber() | setPurchaseOrderNumber(String purchaseOrderNumber) |
| `SalesOrderNumber` | `String` | Optional | Sales order number associated with the transaction. | String getSalesOrderNumber() | setSalesOrderNumber(String salesOrderNumber) |
| `AccountNumber` | `String` | Optional | Number of the account used during the void. | String getAccountNumber() | setAccountNumber(String accountNumber) |
| `AllPackagesVoided` | `Boolean` | Optional | Indicates if all the packages in a shipment were voided. | Boolean getAllPackagesVoided() | setAllPackagesVoided(Boolean allPackagesVoided) |
| `RecordIdentifiers` | [`WtgRecordIdentifiers11`](../../doc/models/wtg-record-identifiers-11.md) | Optional | Outer container for transaction identifiers. | WtgRecordIdentifiers11 getRecordIdentifiers() | setRecordIdentifiers(WtgRecordIdentifiers11 recordIdentifiers) |
| `Packages` | [`WtgPackages24`](../../doc/models/wtg-packages-24.md) | Optional | Container for all packages associated with the transaction. | WtgPackages24 getPackages() | setPackages(WtgPackages24 packages) |
| `Status` | [`WtgStatus`](../../doc/models/wtg-status.md) | Required | Container for transaction errors and warning elements. | WtgStatus getStatus() | setStatus(WtgStatus status) |
| `Processing` | [`WtgProcessing`](../../doc/models/wtg-processing.md) | Required | Container element for transaction processing statistics. | WtgProcessing getProcessing() | setProcessing(WtgProcessing processing) |

## Example (as XML)

```xml
<wtg:PierbridgeVoidResponse xmlns:wtg="https://www.wisetechglobal.com/">
  <wtg:RecordIdentifiers xmlns:wtg="https://www.wisetechglobal.com/" />
  <wtg:Packages xmlns:wtg="https://www.wisetechglobal.com/" />
  <wtg:Status xmlns:wtg="https://www.wisetechglobal.com/">
    <wtg:Code>108</wtg:Code>
    <wtg:Warnings />
    <wtg:Errors />
  </wtg:Status>
  <wtg:Processing xmlns:wtg="https://www.wisetechglobal.com/">
    <wtg:StartTime>StartTime4</wtg:StartTime>
    <wtg:EndTime>EndTime0</wtg:EndTime>
    <wtg:Duration>252.24</wtg:Duration>
    <wtg:External />
    <wtg:ServerName>ServerName6</wtg:ServerName>
  </wtg:Processing>
</wtg:PierbridgeVoidResponse>
```

