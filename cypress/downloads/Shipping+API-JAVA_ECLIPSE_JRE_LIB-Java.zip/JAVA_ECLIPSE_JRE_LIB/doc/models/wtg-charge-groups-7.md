
# Wtg Charge Groups 7

Container for all charge groups associated with the transaction.

## Structure

`WtgChargeGroups7`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `ChargeGroup` | [`List<WtgChargeGroup7>`](../../doc/models/wtg-charge-group-7.md) | Optional | Container for an individual charge group associated with the transaction. | List<WtgChargeGroup7> getChargeGroup() | setChargeGroup(List<WtgChargeGroup7> chargeGroup) |

## Example (as XML)

```xml
<wtg:ChargeGroups xmlns:wtg="https://www.wisetechglobal.com/" />
```

