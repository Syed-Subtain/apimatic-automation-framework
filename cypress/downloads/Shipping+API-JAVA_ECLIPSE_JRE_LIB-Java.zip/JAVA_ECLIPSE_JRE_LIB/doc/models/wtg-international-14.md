
# Wtg International 14

Container for international details associated with the shipment.

## Structure

`WtgInternational14`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `DocumentsOnly` | `Boolean` | Optional | Indicates if the item only contained documents.<br>**Default**: `false` | Boolean getDocumentsOnly() | setDocumentsOnly(Boolean documentsOnly) |
| `Contents` | [`WtgContents11`](../../doc/models/wtg-contents-11.md) | Optional | Container for all contents (line items) associated with the transaction. | WtgContents11 getContents() | setContents(WtgContents11 contents) |

## Example (as XML)

```xml
<wtg:International xmlns:wtg="https://www.wisetechglobal.com/">
  <wtg:Contents xmlns:wtg="https://www.wisetechglobal.com/" />
</wtg:International>
```

