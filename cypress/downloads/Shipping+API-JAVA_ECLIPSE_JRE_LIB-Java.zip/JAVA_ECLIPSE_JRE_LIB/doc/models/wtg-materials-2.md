
# Wtg Materials 2

Container for all material details.

## Structure

`WtgMaterials2`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Material` | [`List<WtgMaterial3>`](../../doc/models/wtg-material-3.md) | Optional | Container for material details. | List<WtgMaterial3> getMaterial() | setMaterial(List<WtgMaterial3> material) |

## Example (as XML)

```xml
<wtg:Materials xmlns:wtg="https://www.wisetechglobal.com/" />
```

