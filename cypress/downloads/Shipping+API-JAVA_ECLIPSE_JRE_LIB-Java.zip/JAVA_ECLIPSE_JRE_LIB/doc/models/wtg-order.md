
# Wtg Order

Container for an individual order.

## Structure

`WtgOrder`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `OrderID` | `Integer` | Optional | Identifier of the order being rated.<br>**Default**: `0` | Integer getOrderID() | setOrderID(Integer orderID) |
| `PickLists` | [`WtgPickLists`](../../doc/models/wtg-pick-lists.md) | Optional | Container all order picklists. | WtgPickLists getPickLists() | setPickLists(WtgPickLists pickLists) |
| `OrderNumber` | `String` | Optional | Order number of the order being rated. | String getOrderNumber() | setOrderNumber(String orderNumber) |

## Example (as XML)

```xml
<wtg:Order xmlns:wtg="https://www.wisetechglobal.com/">
  <wtg:PickLists xmlns:wtg="https://www.wisetechglobal.com/" />
</wtg:Order>
```

