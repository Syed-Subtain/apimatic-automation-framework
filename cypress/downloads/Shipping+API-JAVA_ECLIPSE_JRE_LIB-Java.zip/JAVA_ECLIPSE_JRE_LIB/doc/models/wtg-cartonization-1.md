
# Wtg Cartonization 1

Container for cartonization data for this transaction.

## Structure

`WtgCartonization1`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Carrier` | `String` | Optional | The id of the carrier to use for cartonization. | String getCarrier() | setCarrier(String carrier) |
| `UserName` | `String` | Optional | The username to use for the underlying cartonization request. | String getUserName() | setUserName(String userName) |
| `ControlIdentifier` | `String` | Optional | The control identifier to use for the underlying cartonization request. | String getControlIdentifier() | setControlIdentifier(String controlIdentifier) |
| `DimensionsUOM` | `String` | Optional | The units of measure for the box length, width and height. | String getDimensionsUOM() | setDimensionsUOM(String dimensionsUOM) |
| `WeightUOM` | `String` | Optional | The units of measure for the unit weight. | String getWeightUOM() | setWeightUOM(String weightUOM) |
| `CurrencyCode` | `String` | Optional | Currency of the value of the comtent. | String getCurrencyCode() | setCurrencyCode(String currencyCode) |
| `LayFlat` | `Boolean` | Optional | Aligns all items laying flat. If possible, it may create a "brick-laying" pattern to increase stability. | Boolean getLayFlat() | setLayFlat(Boolean layFlat) |
| `Corners` | `Boolean` | Optional | Only pack items at valid corner points of other items (optimal) | Boolean getCorners() | setCorners(Boolean corners) |
| `UsableSpace` | `Double` | Optional | Estimate of percentage space in boxes that is usable, i.e., not packing material. | Double getUsableSpace() | setUsableSpace(Double usableSpace) |
| `ReservedSpace` | `Double` | Optional | Space in boxes that is reserved, i.e., for packing material.. | Double getReservedSpace() | setReservedSpace(Double reservedSpace) |
| `BoxTypeChoiceGoal` | `String` | Optional | The objective to evaluate boxTypeChoices by. ‘lowest-cost’ minimizes price or volume cost of boxTypes selected, ‘most-items’ maximizes item count per box opened, i.e., fewest total boxes used. | String getBoxTypeChoiceGoal() | setBoxTypeChoiceGoal(String boxTypeChoiceGoal) |
| `BoxTypeSets` | [`WtgBoxTypeSets`](../../doc/models/wtg-box-type-sets.md) | Optional | predefined box types to be used, separated by commas. Will be overridden by boxTypes. | WtgBoxTypeSets getBoxTypeSets() | setBoxTypeSets(WtgBoxTypeSets boxTypeSets) |
| `Rules` | `String` | Optional | a space-delimited array of packing rule strings. The only acceptable rule-type at the moment is "exclude", and it follows the form; exclude,[item-ref-id],[target-item-ref-id] | String getRules() | setRules(String rules) |
| `CartonizationGroupID` | `int` | Required | Numeric identifier for a cartonization group.<br>**Default**: `0` | int getCartonizationGroupID() | setCartonizationGroupID(int cartonizationGroupID) |
| `Contents` | [`WtgContents3`](../../doc/models/wtg-contents-3.md) | Required | Container for all contents associated with the transaction. | WtgContents3 getContents() | setContents(WtgContents3 contents) |
| `PackageTemplate` | [`WtgPackageTemplate1`](../../doc/models/wtg-package-template-1.md) | Required | Container for elements to be applied to each package created from the cartonization response . | WtgPackageTemplate1 getPackageTemplate() | setPackageTemplate(WtgPackageTemplate1 packageTemplate) |

## Example (as XML)

```xml
<wtg:Cartonization xmlns:wtg="https://www.wisetechglobal.com/">
  <wtg:CartonizationGroupID xmlns:wtg="https://www.wisetechglobal.com/">0</wtg:CartonizationGroupID>
  <wtg:Contents xmlns:wtg="https://www.wisetechglobal.com/" />
  <wtg:PackageTemplate xmlns:wtg="https://www.wisetechglobal.com/" />
</wtg:Cartonization>
```

