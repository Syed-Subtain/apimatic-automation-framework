
# Wtg Package 16

Container for an individual package associated with the transaction.

## Structure

`WtgPackage16`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `ShipperReference` | `String` | Optional | Primary reference number, which will be printed on the package's label. | String getShipperReference() | setShipperReference(String shipperReference) |
| `ReferenceOne` | `String` | Optional | First additional reference number. | String getReferenceOne() | setReferenceOne(String referenceOne) |
| `ReferenceTwo` | `String` | Optional | Second additional reference number. | String getReferenceTwo() | setReferenceTwo(String referenceTwo) |
| `ReferenceThree` | `String` | Optional | Third additional reference number. | String getReferenceThree() | setReferenceThree(String referenceThree) |
| `ReferenceFour` | `String` | Optional | Fourth additional reference number. | String getReferenceFour() | setReferenceFour(String referenceFour) |
| `ReferenceFive` | `String` | Optional | Fifth additional reference number. | String getReferenceFive() | setReferenceFive(String referenceFive) |
| `ReferenceSix` | `String` | Optional | Sixth additional reference number. | String getReferenceSix() | setReferenceSix(String referenceSix) |
| `ReceiverName` | `String` | Required | The name of for the receiver of the package. | String getReceiverName() | setReceiverName(String receiverName) |
| `ReceiverPhone` | `String` | Optional | The phone number for the receiver of the package. | String getReceiverPhone() | setReceiverPhone(String receiverPhone) |
| `ReceiverEmail` | `String` | Optional | The email address for the receiver of the package. | String getReceiverEmail() | setReceiverEmail(String receiverEmail) |
| `PackageType` | `int` | Required | Carrier package (e.g. letter, package, pallet) that is to be shipped. | int getPackageType() | setPackageType(int packageType) |
| `Weight` | `Double` | Optional | The weight of the package.<br>**Default**: `0d` | Double getWeight() | setWeight(Double weight) |
| `MajorWeight` | `Double` | Optional | Major Weight of the package.<br>**Default**: `0d` | Double getMajorWeight() | setMajorWeight(Double majorWeight) |
| `MinorWeight` | `Double` | Optional | Minor Weight of the package.<br>**Default**: `0d` | Double getMinorWeight() | setMinorWeight(Double minorWeight) |
| `WeightUOM` | `String` | Optional | The units of measure for the package weight. | String getWeightUOM() | setWeightUOM(String weightUOM) |
| `Length` | `Double` | Optional | The dimensional lenth of the package.<br>**Default**: `0d` | Double getLength() | setLength(Double length) |
| `Width` | `Double` | Optional | The dimensional width of the package.<br>**Default**: `0d` | Double getWidth() | setWidth(Double width) |
| `Height` | `Double` | Optional | The dimensional height of the package.<br>**Default**: `0d` | Double getHeight() | setHeight(Double height) |
| `DimensionsUOM` | `String` | Optional | The units of measure for the package length, width and height. | String getDimensionsUOM() | setDimensionsUOM(String dimensionsUOM) |
| `WayBillNumber` | `String` | Optional | Tracking number to associate with the package. | String getWayBillNumber() | setWayBillNumber(String wayBillNumber) |
| `Charges` | [`WtgCharges10`](../../doc/models/wtg-charges-10.md) | Optional | Container for all charges within the group associated with the transaction. | WtgCharges10 getCharges() | setCharges(WtgCharges10 charges) |

## Example (as XML)

```xml
<wtg:Package xmlns:wtg="https://www.wisetechglobal.com/">
  <wtg:ReceiverName xmlns:wtg="https://www.wisetechglobal.com/">ReceiverName2</wtg:ReceiverName>
  <wtg:PackageType xmlns:wtg="https://www.wisetechglobal.com/">200</wtg:PackageType>
  <wtg:Charges xmlns:wtg="https://www.wisetechglobal.com/" />
</wtg:Package>
```

