
# Wtg Material Exemption

Container for material exemption.

## Structure

`WtgMaterialExemption`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `ExemptionName` | `String` | Required | Hazardous material exemption name for 3rd party hazardous partner. | String getExemptionName() | setExemptionName(String exemptionName) |
| `ExemptionType` | [`WtgExemptionTypeEnum`](../../doc/models/wtg-exemption-type-enum.md) | Required | Hazardous material exemption type for 3rd party hazardous partner. | WtgExemptionTypeEnum getExemptionType() | setExemptionType(WtgExemptionTypeEnum exemptionType) |

## Example (as XML)

```xml
<wtg:MaterialExemption xmlns:wtg="https://www.wisetechglobal.com/">
  <wtg:ExemptionName xmlns:wtg="https://www.wisetechglobal.com/">ExemptionName4</wtg:ExemptionName>
  <wtg:ExemptionType xmlns:wtg="https://www.wisetechglobal.com/">VRI</wtg:ExemptionType>
</wtg:MaterialExemption>
```

