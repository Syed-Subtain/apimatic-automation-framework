
# Wtg Rates 9

Container all rates associated with the transaction.

## Structure

`WtgRates9`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Rate` | [`List<WtgRate9>`](../../doc/models/wtg-rate-9.md) | Optional | Container for an individual rate. | List<WtgRate9> getRate() | setRate(List<WtgRate9> rate) |

## Example (as XML)

```xml
<wtg:Rates xmlns:wtg="https://www.wisetechglobal.com/" />
```

