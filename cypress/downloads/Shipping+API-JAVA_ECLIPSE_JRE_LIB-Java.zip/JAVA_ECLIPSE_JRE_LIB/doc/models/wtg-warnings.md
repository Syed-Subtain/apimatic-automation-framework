
# Wtg Warnings

Container for all warnings found whilst processing the transaction.

## Structure

`WtgWarnings`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Warning` | [`List<WtgWarning>`](../../doc/models/wtg-warning.md) | Optional | Container for a single warning found whilst processing the transaction. | List<WtgWarning> getWarning() | setWarning(List<WtgWarning> warning) |

## Example (as XML)

```xml
<wtg:Warnings xmlns:wtg="https://www.wisetechglobal.com/" />
```

