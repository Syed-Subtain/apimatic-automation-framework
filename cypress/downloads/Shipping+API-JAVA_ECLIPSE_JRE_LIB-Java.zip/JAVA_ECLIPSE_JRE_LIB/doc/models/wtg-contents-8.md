
# Wtg Contents 8

Container for all contents (line items) associated with the transaction.

## Structure

`WtgContents8`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Content` | [`List<WtgContent8>`](../../doc/models/wtg-content-8.md) | Optional | Container for a individual content (line item) associated with the transaction. | List<WtgContent8> getContent() | setContent(List<WtgContent8> content) |

## Example (as XML)

```xml
<wtg:Contents xmlns:wtg="https://www.wisetechglobal.com/" />
```

