
# Wtg Orders 4

Container all orders associated with the transaction.

## Structure

`WtgOrders4`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Order` | [`List<WtgOrder4>`](../../doc/models/wtg-order-4.md) | Optional | Container for an individual order. | List<WtgOrder4> getOrder() | setOrder(List<WtgOrder4> order) |

## Example (as XML)

```xml
<wtg:Orders xmlns:wtg="https://www.wisetechglobal.com/" />
```

