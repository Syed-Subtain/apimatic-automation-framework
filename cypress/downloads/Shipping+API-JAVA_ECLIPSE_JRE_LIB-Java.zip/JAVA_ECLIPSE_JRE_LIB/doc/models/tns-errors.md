
# Tns Errors

Container for all errors found whilst processing the transaction.

## Structure

`TnsErrors`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Error` | [`List<TnsError>`](../../doc/models/tns-error.md) | Optional | Container for a single error found whilst processing the transaction. | List<TnsError> getError() | setError(List<TnsError> error) |

## Example (as JSON)

```json
{
  "Error": null
}
```

