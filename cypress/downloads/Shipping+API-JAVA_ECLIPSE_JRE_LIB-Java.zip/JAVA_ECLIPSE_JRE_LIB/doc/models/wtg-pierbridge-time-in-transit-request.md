
# Wtg Pierbridge Time in Transit Request

Performs a time in transit request with a carrier.

## Structure

`WtgPierbridgeTimeInTransitRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `TransactionIdentifier` | `String` | Optional | A unique identifier for the transaction, this value is not used during processing and will be returned in the response. | String getTransactionIdentifier() | setTransactionIdentifier(String transactionIdentifier) |
| `ControlIdentifier` | `String` | Optional | A reference to a control which generated the request, this value is not used during processing and will be returned in the response. | String getControlIdentifier() | setControlIdentifier(String controlIdentifier) |
| `UserName` | `String` | Required | The user name to use when processing the transaction.<br>**Constraints**: *Minimum Length*: `1` | String getUserName() | setUserName(String userName) |
| `Live` | `Boolean` | Optional | Indicates whether the transaction is a test or live.  Defaults to system configured value if not submitted.<br>**Default**: `false` | Boolean getLive() | setLive(Boolean live) |
| `Carrier` | `int` | Required | Numeric identifier for the carrier. | int getCarrier() | setCarrier(int carrier) |
| `ServiceType` | `int` | Required | Carrier service (e.g. Next Day, Ground, Express) that is to be rated for. | int getServiceType() | setServiceType(int serviceType) |
| `ShipDate` | `String` | Optional | Date the items are to be shipped. Defaults to current date if not submitted. | String getShipDate() | setShipDate(String shipDate) |
| `SmartPostIndiciaType` | `Integer` | Optional | Indicates the SmartPost Indicia type selected for the shipment. Mandatory for SmartPost. | Integer getSmartPostIndiciaType() | setSmartPostIndiciaType(Integer smartPostIndiciaType) |
| `SmartPostHubID` | `Integer` | Optional | Indicates the SmartPost Hub ID selected for the shipment. Mandatory for SmartPost. | Integer getSmartPostHubID() | setSmartPostHubID(Integer smartPostHubID) |
| `Receiver` | [`WtgReceiver14`](../../doc/models/wtg-receiver-14.md) | Required | Container for the receiver address details associated with the transaction. | WtgReceiver14 getReceiver() | setReceiver(WtgReceiver14 receiver) |
| `Packages` | [`WtgPackages19`](../../doc/models/wtg-packages-19.md) | Required | Container for all packages associated with the transaction. | WtgPackages19 getPackages() | setPackages(WtgPackages19 packages) |
| `Diagnostics` | [`WtgDiagnostics`](../../doc/models/wtg-diagnostics.md) | Optional | Container for logging and diagnostic override elements. | WtgDiagnostics getDiagnostics() | setDiagnostics(WtgDiagnostics diagnostics) |
| `Identification` | [`WtgIdentification`](../../doc/models/wtg-identification.md) | Optional | Container for client identification elements. | WtgIdentification getIdentification() | setIdentification(WtgIdentification identification) |

## Example (as XML)

```xml
<wtg:PierbridgeTimeInTransitRequest xmlns:wtg="https://www.wisetechglobal.com/">
  <wtg:Receiver xmlns:wtg="https://www.wisetechglobal.com/" />
  <wtg:Packages xmlns:wtg="https://www.wisetechglobal.com/" />
</wtg:PierbridgeTimeInTransitRequest>
```

