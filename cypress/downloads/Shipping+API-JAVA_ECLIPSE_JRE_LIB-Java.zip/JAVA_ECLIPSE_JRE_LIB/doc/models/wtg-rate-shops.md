
# Wtg Rate Shops

The container for all Rate Groups associated with the transaction.

## Structure

`WtgRateShops`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `RateShop` | [`List<WtgRateShop>`](../../doc/models/wtg-rate-shop.md) | Optional | The container for an individual Rate Group. | List<WtgRateShop> getRateShop() | setRateShop(List<WtgRateShop> rateShop) |

## Example (as XML)

```xml
<wtg:RateShops xmlns:wtg="https://www.wisetechglobal.com/" />
```

