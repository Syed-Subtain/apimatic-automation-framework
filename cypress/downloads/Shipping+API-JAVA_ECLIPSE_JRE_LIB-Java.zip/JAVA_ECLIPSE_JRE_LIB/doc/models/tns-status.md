
# Tns Status

Container for transaction errors and warning elements.

## Structure

`TnsStatus`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Code` | `int` | Required | If the transaction was successful this was will equal one, otherwise zero. | int getCode() | setCode(int code) |
| `Description` | `String` | Optional | Contains a description of the status, if the transaction failed this will contain an error message. | String getDescription() | setDescription(String description) |
| `Warnings` | [`TnsWarnings`](../../doc/models/tns-warnings.md) | Optional | Container for all warnings found whilst processing the transaction. | TnsWarnings getWarnings() | setWarnings(TnsWarnings warnings) |
| `Errors` | [`TnsErrors`](../../doc/models/tns-errors.md) | Optional | Container for all errors found whilst processing the transaction. | TnsErrors getErrors() | setErrors(TnsErrors errors) |

## Example (as JSON)

```json
{
  "Code": 148,
  "Description": null,
  "Warnings": null,
  "Errors": null
}
```

