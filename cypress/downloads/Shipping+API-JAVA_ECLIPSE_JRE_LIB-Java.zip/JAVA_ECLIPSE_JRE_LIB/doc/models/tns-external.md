
# Tns External

Container for the timings associated with external systems.

## Structure

`TnsExternal`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `StartTime` | `String` | Required | The time the transaction started to be processed by an external system. | String getStartTime() | setStartTime(String startTime) |
| `EndTime` | `String` | Required | The time the transaction finished processing by an external system. | String getEndTime() | setEndTime(String endTime) |
| `Duration` | `double` | Required | The difference in milliseconds between the processing external start and end times. | double getDuration() | setDuration(double duration) |

## Example (as JSON)

```json
{
  "StartTime": "StartTime8",
  "EndTime": "EndTime4",
  "Duration": 234.88
}
```

