
# Wtg Shipment 1

Container for a single shipment.

## Structure

`WtgShipment1`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `ShipmentID` | `Integer` | Optional | Unique identifier for the shipment.<br>**Default**: `0` | Integer getShipmentID() | setShipmentID(Integer shipmentID) |
| `ShipperReference` | `String` | Optional | Shipper specified identifier for the shipment.<br>**Default**: `"0"` | String getShipperReference() | setShipperReference(String shipperReference) |
| `InsuranceID` | `Integer` | Optional | The identifier for the insurance record.<br>**Default**: `0` | Integer getInsuranceID() | setInsuranceID(Integer insuranceID) |
| `ShipDate` | `String` | Optional | Date the items where shipped. | String getShipDate() | setShipDate(String shipDate) |
| `DeliveryDate` | `String` | Optional | The requested delivery date for the shipment. | String getDeliveryDate() | setDeliveryDate(String deliveryDate) |
| `BolNumber` | `String` | Optional | The bill of lading number for the shipment. | String getBolNumber() | setBolNumber(String bolNumber) |
| `CarrierName` | `String` | Optional | The name for the carrier. | String getCarrierName() | setCarrierName(String carrierName) |
| `CarrierService` | `String` | Optional | The name for the carrier service. | String getCarrierService() | setCarrierService(String carrierService) |
| `Receiver` | [`WtgReceiver13`](../../doc/models/wtg-receiver-13.md) | Optional | Container for the receiver address details associated with the transaction. | WtgReceiver13 getReceiver() | setReceiver(WtgReceiver13 receiver) |
| `Sender` | [`WtgSender7`](../../doc/models/wtg-sender-7.md) | Optional | Container to allow the customization of the sender address details associated with the transaction. | WtgSender7 getSender() | setSender(WtgSender7 sender) |
| `ChargeGroups` | [`WtgChargeGroups10`](../../doc/models/wtg-charge-groups-10.md) | Optional | Container for all charge groups associated with the transaction. | WtgChargeGroups10 getChargeGroups() | setChargeGroups(WtgChargeGroups10 chargeGroups) |
| `InvoiceChargeGroups` | [`WtgInvoiceChargeGroups`](../../doc/models/wtg-invoice-charge-groups.md) | Optional | Container for invoice charges associated with the shipment. | WtgInvoiceChargeGroups getInvoiceChargeGroups() | setInvoiceChargeGroups(WtgInvoiceChargeGroups invoiceChargeGroups) |
| `Outputs` | [`WtgOutputs3`](../../doc/models/wtg-outputs-3.md) | Optional | Container for outputs the transaction should generate or customize the printing of. | WtgOutputs3 getOutputs() | setOutputs(WtgOutputs3 outputs) |
| `Packages` | [`WtgPackages18`](../../doc/models/wtg-packages-18.md) | Optional | Container for all packages associated with the transaction. | WtgPackages18 getPackages() | setPackages(WtgPackages18 packages) |
| `History` | [`WtgHistory`](../../doc/models/wtg-history.md) | Optional | Container for all history details of the shipment. | WtgHistory getHistory() | setHistory(WtgHistory history) |

## Example (as XML)

```xml
<wtg:Shipment xmlns:wtg="https://www.wisetechglobal.com/">
  <wtg:Receiver xmlns:wtg="https://www.wisetechglobal.com/" />
  <wtg:Sender xmlns:wtg="https://www.wisetechglobal.com/" />
  <wtg:ChargeGroups xmlns:wtg="https://www.wisetechglobal.com/" />
  <wtg:InvoiceChargeGroups xmlns:wtg="https://www.wisetechglobal.com/" />
  <wtg:Outputs xmlns:wtg="https://www.wisetechglobal.com/" />
  <wtg:Packages xmlns:wtg="https://www.wisetechglobal.com/" />
  <wtg:History xmlns:wtg="https://www.wisetechglobal.com/" />
</wtg:Shipment>
```

