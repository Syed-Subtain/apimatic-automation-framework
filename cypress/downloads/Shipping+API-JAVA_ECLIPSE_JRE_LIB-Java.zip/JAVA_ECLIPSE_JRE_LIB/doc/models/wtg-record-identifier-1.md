
# Wtg Record Identifier 1

Inner container for transaction identifiers.

## Structure

`WtgRecordIdentifier1`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `RecordIdentifierID` | `int` | Required | Unique identifier for the record identifier record. | int getRecordIdentifierID() | setRecordIdentifierID(int recordIdentifierID) |
| `Keys` | [`WtgKeys`](../../doc/models/wtg-keys.md) | Optional | Container for transaction identifiers to be stored. | WtgKeys getKeys() | setKeys(WtgKeys keys) |

## Example (as XML)

```xml
<wtg:RecordIdentifier xmlns:wtg="https://www.wisetechglobal.com/">
  <wtg:RecordIdentifierID xmlns:wtg="https://www.wisetechglobal.com/">166</wtg:RecordIdentifierID>
  <wtg:Keys xmlns:wtg="https://www.wisetechglobal.com/" />
</wtg:RecordIdentifier>
```

