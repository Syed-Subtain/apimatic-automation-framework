
# Wtg Packages 3

Container for all packages associated with the transaction.

## Structure

`WtgPackages3`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Package` | [`List<WtgPackage3>`](../../doc/models/wtg-package-3.md) | Required | Container for an individual package associated with the transaction. | List<WtgPackage3> getPackage() | setPackage(List<WtgPackage3> mPackage) |

## Example (as XML)

```xml
<wtg:Packages xmlns:wtg="https://www.wisetechglobal.com/">
  <wtg:Package xmlns:wtg="https://www.wisetechglobal.com/">
    <wtg:Status>
      <wtg:Code>76</wtg:Code>
      <wtg:Warnings />
      <wtg:Errors />
    </wtg:Status>
    <wtg:RecordIdentifiers />
    <wtg:Shipping />
    <wtg:Customer />
    <wtg:International />
    <wtg:Rates />
  </wtg:Package>
</wtg:Packages>
```

