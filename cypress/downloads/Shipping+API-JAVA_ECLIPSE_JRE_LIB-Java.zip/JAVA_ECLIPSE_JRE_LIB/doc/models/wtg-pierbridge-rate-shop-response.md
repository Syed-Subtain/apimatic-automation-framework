
# Wtg Pierbridge Rate Shop Response

Contains the results following a RateShop request.

## Structure

`WtgPierbridgeRateShopResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Status` | [`WtgStatus`](../../doc/models/wtg-status.md) | Required | Container for transaction errors and warning elements. | WtgStatus getStatus() | setStatus(WtgStatus status) |
| `TransactionIdentifier` | `String` | Optional | The unique identifier for the transaction given in the request. | String getTransactionIdentifier() | setTransactionIdentifier(String transactionIdentifier) |
| `ControlIdentifier` | `String` | Optional | The control reference for the transaction given in the request. | String getControlIdentifier() | setControlIdentifier(String controlIdentifier) |
| `Rates` | [`WtgRates3`](../../doc/models/wtg-rates-3.md) | Optional | Container all rates associated with the transaction. | WtgRates3 getRates() | setRates(WtgRates3 rates) |
| `Carrier` | `String` | Optional | Numeric identifier for the carrier. | String getCarrier() | setCarrier(String carrier) |
| `CarrierName` | `String` | Optional | The name for the carrier. | String getCarrierName() | setCarrierName(String carrierName) |
| `CarrierScac` | `String` | Optional | The NMFTA (National Motor Freight Traffic Association) Standard Carrier Alpha Code of the carrier. | String getCarrierScac() | setCarrierScac(String carrierScac) |
| `ServiceType` | `String` | Optional | Numeric identifier for the carrier service assocaited with the transaction. | String getServiceType() | setServiceType(String serviceType) |
| `ServiceTypeName` | `String` | Optional | Description of the service used for the transaction. | String getServiceTypeName() | setServiceTypeName(String serviceTypeName) |
| `ServiceIsGuaranteed` | `Boolean` | Optional | Indicates if the carrier service has a guaranteed delivery window.<br>**Default**: `false` | Boolean getServiceIsGuaranteed() | setServiceIsGuaranteed(Boolean serviceIsGuaranteed) |
| `DayOfWeek` | `String` | Optional | The description for the date of the shipment associated with the transaction. | String getDayOfWeek() | setDayOfWeek(String dayOfWeek) |
| `RequiredDate` | `String` | Optional | Date that the shipment is required to arrive at the receiver. | String getRequiredDate() | setRequiredDate(String requiredDate) |
| `Weight` | `Double` | Optional | Total weight of the shipment.<br>**Default**: `0d` | Double getWeight() | setWeight(Double weight) |
| `Receiver` | [`WtgReceiver3`](../../doc/models/wtg-receiver-3.md) | Optional | Container for the receiver address details associated with the transaction. | WtgReceiver3 getReceiver() | setReceiver(WtgReceiver3 receiver) |
| `RateGroup` | `String` | Optional | Rate group name used within the transaction. | String getRateGroup() | setRateGroup(String rateGroup) |
| `FilterRateShopResult` | `String` | Optional | Indicates what rates should be returned back to the client i.e. only successful rates, success and partial failures or all rates.<br>**Default**: `"SuccessOnly"` | String getFilterRateShopResult() | setFilterRateShopResult(String filterRateShopResult) |
| `FreightPackages` | [`WtgFreightPackages`](../../doc/models/wtg-freight-packages.md) | Optional | Container for all packages associated with the transaction. | WtgFreightPackages getFreightPackages() | setFreightPackages(WtgFreightPackages freightPackages) |
| `Packages` | [`WtgPackages7`](../../doc/models/wtg-packages-7.md) | Optional | Container for all packages associated with the transaction. | WtgPackages7 getPackages() | setPackages(WtgPackages7 packages) |
| `Localization` | [`WtgLocalization1`](../../doc/models/wtg-localization-1.md) | Optional | Container for localization information. | WtgLocalization1 getLocalization() | setLocalization(WtgLocalization1 localization) |
| `Processing` | [`WtgProcessing`](../../doc/models/wtg-processing.md) | Required | Container element for transaction processing statistics. | WtgProcessing getProcessing() | setProcessing(WtgProcessing processing) |

## Example (as XML)

```xml
<wtg:PierbridgeRateShopResponse xmlns:wtg="https://www.wisetechglobal.com/">
  <wtg:Status xmlns:wtg="https://www.wisetechglobal.com/">
    <wtg:Code>108</wtg:Code>
    <wtg:Warnings />
    <wtg:Errors />
  </wtg:Status>
  <wtg:Rates xmlns:wtg="https://www.wisetechglobal.com/" />
  <wtg:Receiver xmlns:wtg="https://www.wisetechglobal.com/" />
  <wtg:FreightPackages xmlns:wtg="https://www.wisetechglobal.com/" />
  <wtg:Packages xmlns:wtg="https://www.wisetechglobal.com/" />
  <wtg:Localization xmlns:wtg="https://www.wisetechglobal.com/" />
  <wtg:Processing xmlns:wtg="https://www.wisetechglobal.com/">
    <wtg:StartTime>StartTime4</wtg:StartTime>
    <wtg:EndTime>EndTime0</wtg:EndTime>
    <wtg:Duration>252.24</wtg:Duration>
    <wtg:External />
    <wtg:ServerName>ServerName6</wtg:ServerName>
  </wtg:Processing>
</wtg:PierbridgeRateShopResponse>
```

