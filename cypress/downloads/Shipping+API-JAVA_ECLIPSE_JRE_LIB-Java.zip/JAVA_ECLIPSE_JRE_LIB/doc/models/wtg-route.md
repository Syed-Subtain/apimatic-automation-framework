
# Wtg Route

Container for a single route.

## Structure

`WtgRoute`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `RouteID` | `Integer` | Optional | Route recommended for the shipment by the routing process.<br>**Default**: `0` | Integer getRouteID() | setRouteID(Integer routeID) |
| `Carrier` | `Integer` | Optional | Numeric identifier for the carrier.<br>**Default**: `0` | Integer getCarrier() | setCarrier(Integer carrier) |
| `ServiceType` | `Integer` | Optional | Numeric identifier for the carrier service assocaited with the transaction.<br>**Default**: `0` | Integer getServiceType() | setServiceType(Integer serviceType) |
| `Billing` | [`WtgBilling5`](../../doc/models/wtg-billing-5.md) | Optional | Container for billing details associated with the transaction. | WtgBilling5 getBilling() | setBilling(WtgBilling5 billing) |
| `Insurance` | `Boolean` | Optional | Container for insurance details.<br>**Default**: `false` | Boolean getInsurance() | setInsurance(Boolean insurance) |
| `Notes` | `String` | Optional | Optional free form notes field. | String getNotes() | setNotes(String notes) |
| `RateGroupID` | `Integer` | Optional | Numeric identifier for the rate group.<br>**Default**: `0` | Integer getRateGroupID() | setRateGroupID(Integer rateGroupID) |
| `Default` | `Boolean` | Optional | Indicates if the route is the configured as the default route.<br>**Default**: `false` | Boolean getDefault() | setDefault(Boolean mDefault) |
| `ReturnParameter` | `String` | Optional | Pre-configured parameter value to return for the route. | String getReturnParameter() | setReturnParameter(String returnParameter) |
| `RouteName` | `String` | Optional | Name of the route. | String getRouteName() | setRouteName(String routeName) |

## Example (as XML)

```xml
<wtg:Route xmlns:wtg="https://www.wisetechglobal.com/">
  <wtg:Billing xmlns:wtg="https://www.wisetechglobal.com/" />
</wtg:Route>
```

