
# Wtg Package 15

Container for an individual package associated with the transaction.

## Structure

`WtgPackage15`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `RecordIdentifiers` | [`WtgRecordIdentifiers`](../../doc/models/wtg-record-identifiers.md) | Optional | Outer container for transaction identifiers. | WtgRecordIdentifiers getRecordIdentifiers() | setRecordIdentifiers(WtgRecordIdentifiers recordIdentifiers) |
| `PackageRequisitionID` | `Integer` | Optional | Used to edit an existing package requisition.<br>**Default**: `0` | Integer getPackageRequisitionID() | setPackageRequisitionID(Integer packageRequisitionID) |
| `ShipperReference` | `String` | Optional | Primary reference number, which will be printed on the package's label. | String getShipperReference() | setShipperReference(String shipperReference) |
| `Weight` | `Double` | Optional | The weight of the package.<br>**Default**: `0d` | Double getWeight() | setWeight(Double weight) |
| `MajorWeight` | `Double` | Optional | Major Weight of the package.<br>**Default**: `0d` | Double getMajorWeight() | setMajorWeight(Double majorWeight) |
| `MinorWeight` | `Double` | Optional | Minor Weight of the package.<br>**Default**: `0d` | Double getMinorWeight() | setMinorWeight(Double minorWeight) |
| `WeightUOM` | `String` | Optional | The units of measure for the package weight. | String getWeightUOM() | setWeightUOM(String weightUOM) |
| `Length` | `Double` | Optional | The dimensional length of the package.<br>**Default**: `0d` | Double getLength() | setLength(Double length) |
| `Width` | `Double` | Optional | The dimensional width of the package.<br>**Default**: `0d` | Double getWidth() | setWidth(Double width) |
| `Height` | `Double` | Optional | The dimensional height of the package.<br>**Default**: `0d` | Double getHeight() | setHeight(Double height) |
| `DimensionsUOM` | `String` | Optional | The units of measure for the package length, width and height. | String getDimensionsUOM() | setDimensionsUOM(String dimensionsUOM) |
| `FreightClass` | `String` | Optional | The freight class of the package's content. | String getFreightClass() | setFreightClass(String freightClass) |
| `NMFC` | `String` | Optional | The National Motor Freight Classification of the package. | String getNMFC() | setNMFC(String nMFC) |
| `ItemsOnPallet` | `Integer` | Optional | Number of items on the pallet.<br>**Default**: `0` | Integer getItemsOnPallet() | setItemsOnPallet(Integer itemsOnPallet) |
| `ContentDescription` | `String` | Optional | Free form description of the package's content. | String getContentDescription() | setContentDescription(String contentDescription) |
| `WayBillNumber` | `String` | Optional | Tracking number to associate with the package. | String getWayBillNumber() | setWayBillNumber(String wayBillNumber) |
| `ReferenceOne` | `String` | Optional | First additional reference number. | String getReferenceOne() | setReferenceOne(String referenceOne) |
| `ReferenceTwo` | `String` | Optional | Second additional reference number. | String getReferenceTwo() | setReferenceTwo(String referenceTwo) |
| `Insurance` | [`WtgInsurance`](../../doc/models/wtg-insurance.md) | Optional | Container for insurance details. | WtgInsurance getInsurance() | setInsurance(WtgInsurance insurance) |
| `COD` | [`WtgCOD`](../../doc/models/wtg-cod.md) | Optional | Container for collect on delivery details. | WtgCOD getCOD() | setCOD(WtgCOD cOD) |
| `GuaranteedService` | `Integer` | Optional | Numeric identifer for the type of guaranteed service.  Defaults to no guaranteed service if not submitted.<br>**Default**: `0` | Integer getGuaranteedService() | setGuaranteedService(Integer guaranteedService) |
| `HazardousPackaging` | `String` | Optional | Description of hazardous packaging. | String getHazardousPackaging() | setHazardousPackaging(String hazardousPackaging) |
| `HazardousPackageUnCode` | `String` | Optional | UN Code of hazardous packaging. | String getHazardousPackageUnCode() | setHazardousPackageUnCode(String hazardousPackageUnCode) |
| `ECOD` | `Boolean` | Optional | Electronic COD indicator. Defaults to not ECOD.<br>**Default**: `false` | Boolean getECOD() | setECOD(Boolean eCOD) |
| `DryIceWeight` | `Double` | Optional | Weight of dry ice in the package.<br>**Default**: `0d` | Double getDryIceWeight() | setDryIceWeight(Double dryIceWeight) |
| `ERR` | `Boolean` | Optional | Indicates that Electronic Return Receipt is required.<br>**Default**: `false` | Boolean getERR() | setERR(Boolean eRR) |
| `ReturnReceiptMerchandise` | `Boolean` | Optional | Indicates that Return Receipt Merchandise is required.<br>**Default**: `false` | Boolean getReturnReceiptMerchandise() | setReturnReceiptMerchandise(Boolean returnReceiptMerchandise) |
| `ReturnReceipt` | `Boolean` | Optional | Indicates whether a return receipt should be provided back to the shipper for this package.<br>**Default**: `false` | Boolean getReturnReceipt() | setReturnReceipt(Boolean returnReceipt) |
| `ElectronicCertified` | `Boolean` | Optional | Indicates that Electronic Certified Mail service is required.<br>**Default**: `false` | Boolean getElectronicCertified() | setElectronicCertified(Boolean electronicCertified) |
| `Registered` | `Boolean` | Optional | Indicates whether the package is to be sent via registered mail.  Defaults to not registered if omitted.<br>**Default**: `false` | Boolean getRegistered() | setRegistered(Boolean registered) |
| `Certified` | `Boolean` | Optional | Indicates whether the package is to be sent via certified mail.  Defaults to not certified if omitted.<br>**Default**: `false` | Boolean getCertified() | setCertified(Boolean certified) |
| `EmailNotification` | `Boolean` | Optional | Indicates whether an email notification should be sent to receiver's email address when package is shipped.  Defaults to not send email notification if omitted.<br>**Default**: `false` | Boolean getEmailNotification() | setEmailNotification(Boolean emailNotification) |
| `Hold` | `Boolean` | Optional | Indicates whether the package should be held for collection at a carrier's depot or some other location.<br>**Default**: `false` | Boolean getHold() | setHold(Boolean hold) |
| `NonFlatMachinable` | `Boolean` | Optional | Indicates whether the package is non-flat and machinable.  Defaults to not non-flat and machinable if omitted.<br>**Default**: `false` | Boolean getNonFlatMachinable() | setNonFlatMachinable(Boolean nonFlatMachinable) |
| `NonMachinable` | `Boolean` | Optional | Indicates whether the package is non-machinable.  Defaults to machinable if omitted.<br>**Default**: `false` | Boolean getNonMachinable() | setNonMachinable(Boolean nonMachinable) |
| `NonRectangular` | `Boolean` | Optional | Indicates whether the package is non-rectangular.  Defaults to rectangular if omitted.<br>**Default**: `false` | Boolean getNonRectangular() | setNonRectangular(Boolean nonRectangular) |
| `Flat` | `Boolean` | Optional | Indicates whether the package is flat.  Defaults to not flat if omitted.<br>**Default**: `false` | Boolean getFlat() | setFlat(Boolean flat) |
| `RestrictedDelivery` | `Boolean` | Optional | Indicates whether the package is to be sent using restricted delivery.  Defaults to not restricted if omitted.<br>**Default**: `false` | Boolean getRestrictedDelivery() | setRestrictedDelivery(Boolean restrictedDelivery) |
| `DeliveryConfirmation` | `Integer` | Optional | Type of delivery confirmation required for the package.  Defaults to none if not submitted.<br>**Default**: `0` | Integer getDeliveryConfirmation() | setDeliveryConfirmation(Integer deliveryConfirmation) |
| `LargePackage` | `Boolean` | Optional | Indicates that package size exceeds carrier's normal limits.  Defaults to not large package if not submitted.<br>**Default**: `false` | Boolean getLargePackage() | setLargePackage(Boolean largePackage) |
| `NonStandardContainer` | `Boolean` | Optional | Indicates whether the package has non standard dimensions.  Defaults to standard dimensions if omitted.<br>**Default**: `false` | Boolean getNonStandardContainer() | setNonStandardContainer(Boolean nonStandardContainer) |
| `PriorityAlert` | `Boolean` | Optional | Indicates whether a priority alert is required for this package.  Defaults to no priority alertt if not submitted.<br>**Default**: `false` | Boolean getPriorityAlert() | setPriorityAlert(Boolean priorityAlert) |
| `PriorityAlertPlus` | `Boolean` | Optional | Indicates whether a priority alert plus is required for this package.  Defaults to no priority alert plus if not submitted.<br>**Default**: `false` | Boolean getPriorityAlertPlus() | setPriorityAlertPlus(Boolean priorityAlertPlus) |
| `ReceiverEmail` | `String` | Optional | The email address for the receiver of the package. | String getReceiverEmail() | setReceiverEmail(String receiverEmail) |
| `PackageType` | `int` | Required | Carrier package (e.g. letter, package, pallet) that is to be shipped.<br>**Default**: `0` | int getPackageType() | setPackageType(int packageType) |
| `AdditionalHandling` | `Boolean` | Optional | Indicates that extra handling measures are required when loading the package.<br>**Default**: `false` | Boolean getAdditionalHandling() | setAdditionalHandling(Boolean additionalHandling) |
| `AdmissibilityPackagingType` | `String` | Optional | Specific FedEx Ground non-standard container type used for domestic and cross border shipments. | String getAdmissibilityPackagingType() | setAdmissibilityPackagingType(String admissibilityPackagingType) |
| `International` | [`WtgInternational16`](../../doc/models/wtg-international-16.md) | Optional | Container for international details associated with the shipment. | WtgInternational16 getInternational() | setInternational(WtgInternational16 international) |
| `ExternalTrackingID` | `String` | Optional | Used to reference an entry in an external system.<br>**Default**: `"0"` | String getExternalTrackingID() | setExternalTrackingID(String externalTrackingID) |
| `HistoryStateID` | `Integer` | Optional | Sets an existing package requisition to the given history state.<br>**Default**: `0` | Integer getHistoryStateID() | setHistoryStateID(Integer historyStateID) |

## Example (as XML)

```xml
<wtg:Package xmlns:wtg="https://www.wisetechglobal.com/">
  <wtg:PackageType xmlns:wtg="https://www.wisetechglobal.com/">0</wtg:PackageType>
</wtg:Package>
```

