
# Wtg Contents 3

Container for all contents associated with the transaction.

## Structure

`WtgContents3`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Content` | [`List<WtgContent3>`](../../doc/models/wtg-content-3.md) | Required | Container for an individual content associated with the transaction. | List<WtgContent3> getContent() | setContent(List<WtgContent3> content) |

## Example (as XML)

```xml
<wtg:Contents xmlns:wtg="https://www.wisetechglobal.com/">
  <wtg:Content xmlns:wtg="https://www.wisetechglobal.com/">
    <wtg:CenterOfMass />
  </wtg:Content>
</wtg:Contents>
```

