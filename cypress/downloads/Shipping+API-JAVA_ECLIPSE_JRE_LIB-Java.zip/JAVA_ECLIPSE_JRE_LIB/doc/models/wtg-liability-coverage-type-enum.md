
# Wtg Liability Coverage Type Enum

## Enumeration

`WtgLiabilityCoverageTypeEnum`

## Fields

| Name |
|  --- |
| `Enum1` |
| `Enum2` |

