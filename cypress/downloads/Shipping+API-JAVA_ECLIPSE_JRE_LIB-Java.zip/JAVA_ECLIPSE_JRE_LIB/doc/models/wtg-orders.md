
# Wtg Orders

Container all orders associated with the transaction.

## Structure

`WtgOrders`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Order` | [`List<WtgOrder>`](../../doc/models/wtg-order.md) | Optional | Container for an individual order. | List<WtgOrder> getOrder() | setOrder(List<WtgOrder> order) |

## Example (as XML)

```xml
<wtg:Orders xmlns:wtg="https://www.wisetechglobal.com/" />
```

