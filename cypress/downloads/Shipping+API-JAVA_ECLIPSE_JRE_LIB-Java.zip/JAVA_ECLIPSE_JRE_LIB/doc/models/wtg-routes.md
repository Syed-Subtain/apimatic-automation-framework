
# Wtg Routes

Outer container for routes.

## Structure

`WtgRoutes`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Route` | [`List<WtgRoute>`](../../doc/models/wtg-route.md) | Optional | Container for a single route. | List<WtgRoute> getRoute() | setRoute(List<WtgRoute> route) |

## Example (as XML)

```xml
<wtg:Routes xmlns:wtg="https://www.wisetechglobal.com/" />
```

