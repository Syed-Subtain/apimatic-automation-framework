
# Wtg Rates 13

Container for all rates associated with the transaction.

## Structure

`WtgRates13`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Rate` | [`List<WtgRate13>`](../../doc/models/wtg-rate-13.md) | Optional | Container for an individual rate associated with the transaction. | List<WtgRate13> getRate() | setRate(List<WtgRate13> rate) |

## Example (as XML)

```xml
<wtg:Rates xmlns:wtg="https://www.wisetechglobal.com/" />
```

