
# Wtg Pierbridge Cartonize Request

Request to provide a simple and flexible cartonization result.

## Structure

`WtgPierbridgeCartonizeRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `TransactionIdentifier` | `String` | Optional | A unique identifier for the transaction, this value is not used during processing and will be returned in the response. | String getTransactionIdentifier() | setTransactionIdentifier(String transactionIdentifier) |
| `ControlIdentifier` | `String` | Optional | A reference to a control which generated the request, this value is not used during processing and will be returned in the response. | String getControlIdentifier() | setControlIdentifier(String controlIdentifier) |
| `UserName` | `String` | Required | The user name to use when processing the transaction.<br>**Constraints**: *Minimum Length*: `1` | String getUserName() | setUserName(String userName) |
| `Carrier` | `int` | Required | Numeric identifier for the carrier.<br>**Default**: `0` | int getCarrier() | setCarrier(int carrier) |
| `ShippingCarrier` | `int` | Required | Numeric identifier for the shipping carrier.<br>**Default**: `0` | int getShippingCarrier() | setShippingCarrier(int shippingCarrier) |
| `Cartonization` | [`WtgCartonization`](../../doc/models/wtg-cartonization.md) | Required | Container for cartonization data for this transaction. | WtgCartonization getCartonization() | setCartonization(WtgCartonization cartonization) |
| `Identification` | [`WtgIdentification`](../../doc/models/wtg-identification.md) | Optional | Container for client identification elements. | WtgIdentification getIdentification() | setIdentification(WtgIdentification identification) |

## Example (as XML)

```xml
<wtg:PierbridgeCartonizeRequest xmlns:wtg="https://www.wisetechglobal.com/">
  <wtg:Carrier xmlns:wtg="https://www.wisetechglobal.com/">0</wtg:Carrier>
  <wtg:ShippingCarrier xmlns:wtg="https://www.wisetechglobal.com/">0</wtg:ShippingCarrier>
  <wtg:Cartonization xmlns:wtg="https://www.wisetechglobal.com/">
    <wtg:CartonizationGroupID>0</wtg:CartonizationGroupID>
    <wtg:Contents />
    <wtg:PackageTemplate />
  </wtg:Cartonization>
</wtg:PierbridgeCartonizeRequest>
```

