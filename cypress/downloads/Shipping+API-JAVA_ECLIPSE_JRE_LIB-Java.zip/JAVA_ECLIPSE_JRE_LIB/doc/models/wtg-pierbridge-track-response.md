
# Wtg Pierbridge Track Response

Contains details about the latest status of a shipment as defined by a Track request.

## Structure

`WtgPierbridgeTrackResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `TransactionIdentifier` | `String` | Optional | The unique identifier for the transaction given in the request. | String getTransactionIdentifier() | setTransactionIdentifier(String transactionIdentifier) |
| `ControlIdentifier` | `String` | Optional | The control reference for the transaction given in the request. | String getControlIdentifier() | setControlIdentifier(String controlIdentifier) |
| `ShipDate` | `String` | Optional | Date the items where shipped. | String getShipDate() | setShipDate(String shipDate) |
| `Service` | `String` | Optional | The carrier service description. | String getService() | setService(String service) |
| `Carrier` | `Integer` | Optional | Numeric identifier for the carrier.<br>**Default**: `0` | Integer getCarrier() | setCarrier(Integer carrier) |
| `CarrierName` | `String` | Optional | The name for the carrier. | String getCarrierName() | setCarrierName(String carrierName) |
| `ServiceType` | `Integer` | Optional | Numeric identifier for the carrier service associated with the transaction.<br>**Default**: `0` | Integer getServiceType() | setServiceType(Integer serviceType) |
| `ServiceTypeName` | `String` | Optional | Description of the service used for the transaction. | String getServiceTypeName() | setServiceTypeName(String serviceTypeName) |
| `CarrierScac` | `String` | Optional | The NMFTA (National Motor Freight Traffic Association) Standard Carrier Alpha Code of the carrier. | String getCarrierScac() | setCarrierScac(String carrierScac) |
| `Sender` | [`WtgSender9`](../../doc/models/wtg-sender-9.md) | Optional | Container to allow the customization of the sender address details associated with the transaction. | WtgSender9 getSender() | setSender(WtgSender9 sender) |
| `Receiver` | [`WtgReceiver16`](../../doc/models/wtg-receiver-16.md) | Optional | Container for the receiver address details associated with the transaction. | WtgReceiver16 getReceiver() | setReceiver(WtgReceiver16 receiver) |
| `Packages` | [`WtgPackages22`](../../doc/models/wtg-packages-22.md) | Optional | Container for all packages associated with the transaction. | WtgPackages22 getPackages() | setPackages(WtgPackages22 packages) |
| `Status` | [`WtgStatus`](../../doc/models/wtg-status.md) | Required | Container for transaction errors and warning elements. | WtgStatus getStatus() | setStatus(WtgStatus status) |
| `Processing` | [`WtgProcessing`](../../doc/models/wtg-processing.md) | Required | Container element for transaction processing statistics. | WtgProcessing getProcessing() | setProcessing(WtgProcessing processing) |

## Example (as XML)

```xml
<wtg:PierbridgeTrackResponse xmlns:wtg="https://www.wisetechglobal.com/">
  <wtg:Sender xmlns:wtg="https://www.wisetechglobal.com/" />
  <wtg:Receiver xmlns:wtg="https://www.wisetechglobal.com/" />
  <wtg:Packages xmlns:wtg="https://www.wisetechglobal.com/" />
  <wtg:Status xmlns:wtg="https://www.wisetechglobal.com/">
    <wtg:Code>108</wtg:Code>
    <wtg:Warnings />
    <wtg:Errors />
  </wtg:Status>
  <wtg:Processing xmlns:wtg="https://www.wisetechglobal.com/">
    <wtg:StartTime>StartTime4</wtg:StartTime>
    <wtg:EndTime>EndTime0</wtg:EndTime>
    <wtg:Duration>252.24</wtg:Duration>
    <wtg:External />
    <wtg:ServerName>ServerName6</wtg:ServerName>
  </wtg:Processing>
</wtg:PierbridgeTrackResponse>
```

