
# Wtg Charges 12

Container for all charges within the group associated with the transaction.

## Structure

`WtgCharges12`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Charge` | [`List<WtgCharge12>`](../../doc/models/wtg-charge-12.md) | Optional | Container for an individual charge within the group associated with the transaction. | List<WtgCharge12> getCharge() | setCharge(List<WtgCharge12> charge) |

## Example (as XML)

```xml
<wtg:Charges xmlns:wtg="https://www.wisetechglobal.com/" />
```

