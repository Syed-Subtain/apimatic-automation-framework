
# Wtg Outputs 3

Container for outputs the transaction should generate or customize the printing of.

## Structure

`WtgOutputs3`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Output` | [`List<WtgOutput7>`](../../doc/models/wtg-output-7.md) | Optional | Container for documents to be printed externally from the transaction. | List<WtgOutput7> getOutput() | setOutput(List<WtgOutput7> output) |

## Example (as XML)

```xml
<wtg:Outputs xmlns:wtg="https://www.wisetechglobal.com/" />
```

