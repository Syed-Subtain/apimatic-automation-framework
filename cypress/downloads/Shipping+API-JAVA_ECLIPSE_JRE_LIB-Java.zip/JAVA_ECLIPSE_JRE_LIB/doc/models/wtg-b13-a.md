
# Wtg B13 A

Container for B13A details.

## Structure

`WtgB13A`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Method` | `Integer` | Optional | B13A method type identifier.<br>**Default**: `0` | Integer getMethod() | setMethod(Integer method) |
| `StatementData` | `String` | Optional | B13A statement data. | String getStatementData() | setStatementData(String statementData) |

## Example (as XML)

```xml
<wtg:B13A xmlns:wtg="https://www.wisetechglobal.com/" />
```

