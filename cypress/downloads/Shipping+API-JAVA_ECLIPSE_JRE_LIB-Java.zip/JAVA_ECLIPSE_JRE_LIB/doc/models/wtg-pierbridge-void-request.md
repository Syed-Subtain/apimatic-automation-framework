
# Wtg Pierbridge Void Request

Cancels a shipment that had already been processing with a carrier.

## Structure

`WtgPierbridgeVoidRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `TransactionIdentifier` | `String` | Optional | A unique identifier for the transaction, this value is not used during processing and will be returned in the response. | String getTransactionIdentifier() | setTransactionIdentifier(String transactionIdentifier) |
| `ControlIdentifier` | `String` | Optional | A reference to a control which generated the request, this value is not used during processing and will be returned in the response. | String getControlIdentifier() | setControlIdentifier(String controlIdentifier) |
| `UserName` | `String` | Required | The user name to use when processing the transaction.<br>**Constraints**: *Minimum Length*: `1` | String getUserName() | setUserName(String userName) |
| `Live` | `Boolean` | Optional | Indicates whether the transaction is a test or live.  Defaults to system configured value if not submitted.<br>**Default**: `false` | Boolean getLive() | setLive(Boolean live) |
| `ShipmentID` | `Integer` | Optional | Identifier of the shipment to void.  Must submit shipment identifier, shipment group identifier, package identifier or tracking number.<br>**Default**: `0` | Integer getShipmentID() | setShipmentID(Integer shipmentID) |
| `DisableExecution` | `Boolean` | Optional | Indicates whether to disable the actual execution with the carrier engine for this request. Use with caution, the shipment will be recorded in the system but not executed with the carrier. Rating can be passed manually or executed with Rating Options.<br>**Default**: `false` | Boolean getDisableExecution() | setDisableExecution(Boolean disableExecution) |
| `ShipmentRequisitionID` | `Integer` | Optional | Identifier of the shipment requisition to void.  Must submit shipment identifier, shipment group identifier, package identifier, tracking number or shipment requisition identifier.<br>**Default**: `0` | Integer getShipmentRequisitionID() | setShipmentRequisitionID(Integer shipmentRequisitionID) |
| `ShipmentGroupID` | `Integer` | Optional | Identifier of the shipment group to void.  Must submit shipment identifier, shipment group identifier, package identifier or tracking number.<br>**Default**: `0` | Integer getShipmentGroupID() | setShipmentGroupID(Integer shipmentGroupID) |
| `AccountID` | `Integer` | Optional | Overrides the account to allow voiding using any account.<br>**Default**: `0` | Integer getAccountID() | setAccountID(Integer accountID) |
| `Carrier` | `Integer` | Optional | Numeric identifier for the carrier.<br>**Default**: `0` | Integer getCarrier() | setCarrier(Integer carrier) |
| `Packages` | [`WtgPackages23`](../../doc/models/wtg-packages-23.md) | Optional | Container for all packages associated with the transaction. | WtgPackages23 getPackages() | setPackages(WtgPackages23 packages) |
| `Diagnostics` | [`WtgDiagnostics`](../../doc/models/wtg-diagnostics.md) | Optional | Container for logging and diagnostic override elements. | WtgDiagnostics getDiagnostics() | setDiagnostics(WtgDiagnostics diagnostics) |
| `Identification` | [`WtgIdentification`](../../doc/models/wtg-identification.md) | Optional | Container for client identification elements. | WtgIdentification getIdentification() | setIdentification(WtgIdentification identification) |

## Example (as XML)

```xml
<wtg:PierbridgeVoidRequest xmlns:wtg="https://www.wisetechglobal.com/">
  <wtg:UserName xmlns:wtg="https://www.wisetechglobal.com/">UserName6</wtg:UserName>
  <wtg:Packages xmlns:wtg="https://www.wisetechglobal.com/" />
  <wtg:Diagnostics xmlns:wtg="https://www.wisetechglobal.com/" />
  <wtg:Identification xmlns:wtg="https://www.wisetechglobal.com/" />
</wtg:PierbridgeVoidRequest>
```

