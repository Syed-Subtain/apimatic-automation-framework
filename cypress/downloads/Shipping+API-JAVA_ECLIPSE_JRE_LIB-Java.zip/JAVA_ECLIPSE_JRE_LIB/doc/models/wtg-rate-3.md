
# Wtg Rate 3

Container for an individual rate.

## Structure

`WtgRate3`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Status` | [`WtgStatus1`](../../doc/models/wtg-status-1.md) | Required | Container for transaction errors and warning elements. | WtgStatus1 getStatus() | setStatus(WtgStatus1 status) |
| `Carrier` | [`WtgCarrier`](../../doc/models/wtg-carrier.md) | Optional | Container element for the carrier. | WtgCarrier getCarrier() | setCarrier(WtgCarrier carrier) |
| `ServiceType` | [`WtgServiceType`](../../doc/models/wtg-service-type.md) | Optional | Container element for the carrier service. | WtgServiceType getServiceType() | setServiceType(WtgServiceType serviceType) |
| `PackageType` | [`WtgPackageType`](../../doc/models/wtg-package-type.md) | Optional | Container element for the carrier package type. | WtgPackageType getPackageType() | setPackageType(WtgPackageType packageType) |
| `Interline` | `Boolean` | Optional | Indicates that another carrier maybe be involved with part of the delivery.<br>**Default**: `false` | Boolean getInterline() | setInterline(Boolean interline) |
| `Shipping` | [`WtgShipping`](../../doc/models/wtg-shipping.md) | Optional | Container for shipping associated with the transaction. | WtgShipping getShipping() | setShipping(WtgShipping shipping) |
| `Customer` | [`WtgCustomer`](../../doc/models/wtg-customer.md) | Optional | Container for customer details. | WtgCustomer getCustomer() | setCustomer(WtgCustomer customer) |
| `BrokerReference` | `String` | Optional | Broker reference. | String getBrokerReference() | setBrokerReference(String brokerReference) |
| `CommitmentLevel` | `String` | Optional | Returned by the carrier indicating the expected delivery date and time. | String getCommitmentLevel() | setCommitmentLevel(String commitmentLevel) |
| `ServiceIsGuaranteed` | `Boolean` | Optional | Indicates a guaranteed service. | Boolean getServiceIsGuaranteed() | setServiceIsGuaranteed(Boolean serviceIsGuaranteed) |
| `DeliverAfterTime` | `String` | Optional | Identifies a delivery window. | String getDeliverAfterTime() | setDeliverAfterTime(String deliverAfterTime) |
| `RateType` | `Integer` | Optional | Numeric identifier for the rate type.<br>**Default**: `0` | Integer getRateType() | setRateType(Integer rateType) |
| `RateDescription` | `String` | Optional | Free form description for the rate type. | String getRateDescription() | setRateDescription(String rateDescription) |
| `RateWeight` | `Double` | Optional | The rated weight for the package.<br>**Default**: `0d` | Double getRateWeight() | setRateWeight(Double rateWeight) |
| `ShipDate` | `String` | Optional | Date the items where shipped. | String getShipDate() | setShipDate(String shipDate) |
| `DeliveryDate` | `String` | Optional | The requested delivery date for the shipment. | String getDeliveryDate() | setDeliveryDate(String deliveryDate) |
| `DeliveryIn` | `Integer` | Optional | Returned by the carrier indicating the number of days the shipment will take to reach its destination.<br>**Default**: `0` | Integer getDeliveryIn() | setDeliveryIn(Integer deliveryIn) |
| `DisplayRate` | `Boolean` | Optional | Indicates if the rate is marked for display to the user.<br>**Default**: `false` | Boolean getDisplayRate() | setDisplayRate(Boolean displayRate) |
| `UpdateRate` | `Boolean` | Optional | Indicates if the rate is used during updates back to customer host systems.<br>**Default**: `false` | Boolean getUpdateRate() | setUpdateRate(Boolean updateRate) |
| `Zone` | `String` | Optional | The zone assosicated with the rate. | String getZone() | setZone(String zone) |
| `QuoteID` | `String` | Optional | The unique quote identifier for freight based transactions. | String getQuoteID() | setQuoteID(String quoteID) |
| `OptionID` | `String` | Optional | The unique option identifier for freight based transactions. | String getOptionID() | setOptionID(String optionID) |
| `ChargeGroups` | [`WtgChargeGroups1`](../../doc/models/wtg-charge-groups-1.md) | Optional | Container for all charge groups associated with the transaction. | WtgChargeGroups1 getChargeGroups() | setChargeGroups(WtgChargeGroups1 chargeGroups) |
| `Packages` | [`WtgPackages6`](../../doc/models/wtg-packages-6.md) | Optional | Container for all packages relating to the specific rate. | WtgPackages6 getPackages() | setPackages(WtgPackages6 packages) |

## Example (as XML)

```xml
<wtg:Rate xmlns:wtg="https://www.wisetechglobal.com/">
  <wtg:Status xmlns:wtg="https://www.wisetechglobal.com/">
    <wtg:Code>108</wtg:Code>
    <wtg:Description>Description8</wtg:Description>
    <wtg:Warnings />
    <wtg:Errors />
  </wtg:Status>
  <wtg:Carrier xmlns:wtg="https://www.wisetechglobal.com/" />
  <wtg:ServiceType xmlns:wtg="https://www.wisetechglobal.com/" />
  <wtg:PackageType xmlns:wtg="https://www.wisetechglobal.com/" />
  <wtg:Shipping xmlns:wtg="https://www.wisetechglobal.com/" />
  <wtg:Customer xmlns:wtg="https://www.wisetechglobal.com/" />
  <wtg:ChargeGroups xmlns:wtg="https://www.wisetechglobal.com/" />
  <wtg:Packages xmlns:wtg="https://www.wisetechglobal.com/" />
</wtg:Rate>
```

