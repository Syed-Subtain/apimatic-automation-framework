
# Wtg Packages 12

Container for all packages associated with the transaction.

## Structure

`WtgPackages12`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Package` | [`List<WtgPackage13>`](../../doc/models/wtg-package-13.md) | Required | Container for an individual package associated with the transaction. | List<WtgPackage13> getPackage() | setPackage(List<WtgPackage13> mPackage) |

## Example (as XML)

```xml
<wtg:Packages xmlns:wtg="https://www.wisetechglobal.com/">
  <wtg:Package xmlns:wtg="https://www.wisetechglobal.com/">
    <wtg:RecordIdentifiers />
    <wtg:Status>
      <wtg:Code>76</wtg:Code>
      <wtg:Warnings />
      <wtg:Errors />
    </wtg:Status>
    <wtg:Insurance />
    <wtg:International />
    <wtg:Labels />
    <wtg:Documents />
    <wtg:Shipping />
    <wtg:Customer />
    <wtg:Rates />
  </wtg:Package>
</wtg:Packages>
```

