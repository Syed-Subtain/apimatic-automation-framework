
# Wtg Rates 5

Container all rates associated with the transaction.

## Structure

`WtgRates5`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Rate` | [`List<WtgRate5>`](../../doc/models/wtg-rate-5.md) | Optional | Container for an individual rate. | List<WtgRate5> getRate() | setRate(List<WtgRate5> rate) |

## Example (as XML)

```xml
<wtg:Rates xmlns:wtg="https://www.wisetechglobal.com/" />
```

