
# Wtg Rates 2

Container for rates returned for the shipment packages.

## Structure

`WtgRates2`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Rate` | [`List<WtgRate2>`](../../doc/models/wtg-rate-2.md) | Optional | Container for individual rates associated with the package. | List<WtgRate2> getRate() | setRate(List<WtgRate2> rate) |

## Example (as XML)

```xml
<wtg:Rates xmlns:wtg="https://www.wisetechglobal.com/" />
```

