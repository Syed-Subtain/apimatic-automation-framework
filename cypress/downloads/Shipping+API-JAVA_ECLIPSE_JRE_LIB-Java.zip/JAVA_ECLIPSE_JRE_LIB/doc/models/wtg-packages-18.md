
# Wtg Packages 18

Container for all packages associated with the transaction.

## Structure

`WtgPackages18`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Package` | [`List<WtgPackage19>`](../../doc/models/wtg-package-19.md) | Optional | Container for an individual package associated with the transaction. | List<WtgPackage19> getPackage() | setPackage(List<WtgPackage19> mPackage) |

## Example (as XML)

```xml
<wtg:Packages xmlns:wtg="https://www.wisetechglobal.com/" />
```

