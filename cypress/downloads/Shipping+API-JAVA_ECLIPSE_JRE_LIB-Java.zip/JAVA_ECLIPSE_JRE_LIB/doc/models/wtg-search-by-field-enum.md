
# Wtg Search by Field Enum

## Enumeration

`WtgSearchByFieldEnum`

## Fields

| Name |
|  --- |
| `ShipmentID` |
| `ShipmentDate` |
| `SalesOrderNumber` |
| `PurchaseOrderNumber` |
| `OrderNumber` |
| `ShipperReference` |

