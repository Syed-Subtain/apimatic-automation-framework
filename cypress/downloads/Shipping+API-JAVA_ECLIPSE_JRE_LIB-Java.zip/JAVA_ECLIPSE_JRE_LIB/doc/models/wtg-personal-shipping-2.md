
# Wtg Personal Shipping 2

Container for personal shipping elements.

## Structure

`WtgPersonalShipping2`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `PersonalShipment` | `Boolean` | Optional | Indicates that shipment is a personal shipment.<br>**Default**: `false` | Boolean getPersonalShipment() | setPersonalShipment(Boolean personalShipment) |
| `PaymentIntentID` | `String` | Optional | The id of the payment intent used to pay for a personal shipment. | String getPaymentIntentID() | setPaymentIntentID(String paymentIntentID) |
| `TotalCharge` | `Double` | Optional | Cost that the customer will be charged for the personal shipment.<br>**Default**: `0d` | Double getTotalCharge() | setTotalCharge(Double totalCharge) |
| `ConvenienceFee` | `Double` | Optional | Cost to the user for processing a personal shipment. This cost is included in the total cost<br>**Default**: `0d` | Double getConvenienceFee() | setConvenienceFee(Double convenienceFee) |
| `PaymentStatus` | [`WtgPaymentStatus`](../../doc/models/wtg-payment-status.md) | Optional | Container for payment processing status. | WtgPaymentStatus getPaymentStatus() | setPaymentStatus(WtgPaymentStatus paymentStatus) |

## Example (as XML)

```xml
<wtg:PersonalShipping xmlns:wtg="https://www.wisetechglobal.com/">
  <wtg:PaymentStatus xmlns:wtg="https://www.wisetechglobal.com/" />
</wtg:PersonalShipping>
```

