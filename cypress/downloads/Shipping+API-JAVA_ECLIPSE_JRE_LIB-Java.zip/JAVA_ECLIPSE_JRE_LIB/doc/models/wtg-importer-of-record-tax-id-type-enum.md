
# Wtg Importer of Record Tax ID Type Enum

## Enumeration

`WtgImporterOfRecordTaxIDTypeEnum`

## Fields

| Name |
|  --- |
| `Enum1` |
| `Enum2` |

