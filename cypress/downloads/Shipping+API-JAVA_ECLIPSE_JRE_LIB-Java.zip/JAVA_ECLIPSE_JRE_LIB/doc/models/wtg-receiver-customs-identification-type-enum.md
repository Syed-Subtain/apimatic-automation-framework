
# Wtg Receiver Customs Identification Type Enum

## Enumeration

`WtgReceiverCustomsIdentificationTypeEnum`

## Fields

| Name |
|  --- |
| `Enum1` |
| `Enum2` |
| `Enum3` |

