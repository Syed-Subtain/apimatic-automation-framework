
# Wtg Charges 2

Container for all charges within the group associated with the transaction.

## Structure

`WtgCharges2`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Charge` | [`List<WtgCharge2>`](../../doc/models/wtg-charge-2.md) | Optional | Container for an individual charge within the group associated with the transaction. | List<WtgCharge2> getCharge() | setCharge(List<WtgCharge2> charge) |

## Example (as XML)

```xml
<wtg:Charges xmlns:wtg="https://www.wisetechglobal.com/" />
```

