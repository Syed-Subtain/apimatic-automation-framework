
# Wtg Pierbridge Route Response

Indicates the status of a route request.

## Structure

`WtgPierbridgeRouteResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `TransactionIdentifier` | `String` | Optional | The unique identifier for the transaction given in the request. | String getTransactionIdentifier() | setTransactionIdentifier(String transactionIdentifier) |
| `ControlIdentifier` | `String` | Optional | The control reference for the transaction given in the request. | String getControlIdentifier() | setControlIdentifier(String controlIdentifier) |
| `Routes` | [`WtgRoutes`](../../doc/models/wtg-routes.md) | Optional | Outer container for routes. | WtgRoutes getRoutes() | setRoutes(WtgRoutes routes) |
| `Status` | [`WtgStatus`](../../doc/models/wtg-status.md) | Required | Container for transaction errors and warning elements. | WtgStatus getStatus() | setStatus(WtgStatus status) |
| `Processing` | [`WtgProcessing`](../../doc/models/wtg-processing.md) | Required | Container element for transaction processing statistics. | WtgProcessing getProcessing() | setProcessing(WtgProcessing processing) |

## Example (as XML)

```xml
<wtg:PierbridgeRouteResponse xmlns:wtg="https://www.wisetechglobal.com/">
  <wtg:Routes xmlns:wtg="https://www.wisetechglobal.com/" />
  <wtg:Status xmlns:wtg="https://www.wisetechglobal.com/">
    <wtg:Code>108</wtg:Code>
    <wtg:Warnings />
    <wtg:Errors />
  </wtg:Status>
  <wtg:Processing xmlns:wtg="https://www.wisetechglobal.com/">
    <wtg:StartTime>StartTime4</wtg:StartTime>
    <wtg:EndTime>EndTime0</wtg:EndTime>
    <wtg:Duration>252.24</wtg:Duration>
    <wtg:External />
    <wtg:ServerName>ServerName6</wtg:ServerName>
  </wtg:Processing>
</wtg:PierbridgeRouteResponse>
```

