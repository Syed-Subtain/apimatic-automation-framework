
# Tns Pierbridge Ship Requisition Response

Indicates the status of a ShipRequisition request.

## Structure

`TnsPierbridgeShipRequisitionResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `TransactionIdentifier` | `String` | Optional | The unique identifier for the transaction given in the request. | String getTransactionIdentifier() | setTransactionIdentifier(String transactionIdentifier) |
| `ControlIdentifier` | `String` | Optional | The control reference for the transaction given in the request. | String getControlIdentifier() | setControlIdentifier(String controlIdentifier) |
| `ShipmentRequisitionID` | `Integer` | Optional | Shipment requisition to print output for. | Integer getShipmentRequisitionID() | setShipmentRequisitionID(Integer shipmentRequisitionID) |
| `Carrier` | `Integer` | Optional | Numeric identifier for the carrier.<br>**Default**: `0` | Integer getCarrier() | setCarrier(Integer carrier) |
| `CarrierName` | `String` | Optional | The name for the carrier. | String getCarrierName() | setCarrierName(String carrierName) |
| `ServiceType` | `Integer` | Optional | Numeric identifier for the carrier service assocaited with the transaction.<br>**Default**: `0` | Integer getServiceType() | setServiceType(Integer serviceType) |
| `ServiceTypeName` | `String` | Optional | Description of the service used for the transaction. | String getServiceTypeName() | setServiceTypeName(String serviceTypeName) |
| `CarrierScac` | `String` | Optional | The NMFTA (National Motor Freight Traffic Association) Standard Carrier Alpha Code of the carrier. | String getCarrierScac() | setCarrierScac(String carrierScac) |
| `Status` | [`TnsStatus`](../../doc/models/tns-status.md) | Required | Container for transaction errors and warning elements. | TnsStatus getStatus() | setStatus(TnsStatus status) |
| `PackageRequisitions` | [`TnsPackageRequisitions`](../../doc/models/tns-package-requisitions.md) | Optional | Container for all packages within the requisition. | TnsPackageRequisitions getPackageRequisitions() | setPackageRequisitions(TnsPackageRequisitions packageRequisitions) |
| `Packages` | [`TnsPackages`](../../doc/models/tns-packages.md) | Optional | Container for all packages associated with the transaction. | TnsPackages getPackages() | setPackages(TnsPackages packages) |
| `Documents` | [`TnsDocuments`](../../doc/models/tns-documents.md) | Optional | Container for documents to be printed by the caller of the transaction (client). | TnsDocuments getDocuments() | setDocuments(TnsDocuments documents) |
| `Weight` | `Double` | Optional | Total weight of the shipment.<br>**Default**: `0d` | Double getWeight() | setWeight(Double weight) |
| `Receiver` | [`TnsReceiver`](../../doc/models/tns-receiver.md) | Optional | Container for the receiver address details associated with the transaction. | TnsReceiver getReceiver() | setReceiver(TnsReceiver receiver) |
| `Processing` | [`TnsProcessing`](../../doc/models/tns-processing.md) | Required | Container element for transaction processing statistics. | TnsProcessing getProcessing() | setProcessing(TnsProcessing processing) |

## Example (as JSON)

```json
{
  "TransactionIdentifier": null,
  "ControlIdentifier": null,
  "ShipmentRequisitionID": null,
  "Carrier": null,
  "CarrierName": null,
  "ServiceType": null,
  "ServiceTypeName": null,
  "CarrierScac": null,
  "Status": {
    "Code": 108,
    "Description": null,
    "Warnings": null,
    "Errors": null
  },
  "PackageRequisitions": null,
  "Packages": null,
  "Documents": null,
  "Weight": null,
  "Receiver": null,
  "Processing": {
    "StartTime": "StartTime4",
    "EndTime": "EndTime0",
    "Duration": 252.24,
    "External": null,
    "ServerName": "ServerName6",
    "UserName": null
  }
}
```

