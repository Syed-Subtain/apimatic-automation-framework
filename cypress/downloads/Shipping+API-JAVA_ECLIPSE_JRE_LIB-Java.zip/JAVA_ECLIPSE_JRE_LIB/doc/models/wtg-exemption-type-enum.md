
# Wtg Exemption Type Enum

## Enumeration

`WtgExemptionTypeEnum`

## Fields

| Name |
|  --- |
| `Unknown` |
| `EX` |
| `CA` |
| `SP` |
| `VRI` |
| `EC` |

