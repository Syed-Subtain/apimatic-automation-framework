
# Wtg Content 8

Container for a individual content (line item) associated with the transaction.

## Structure

`WtgContent8`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `ContentRefNumber` | `String` | Required | Unique reference number for the content. | String getContentRefNumber() | setContentRefNumber(String contentRefNumber) |
| `Value` | `Double` | Optional | Unit value of the content. | Double getValue() | setValue(Double value) |
| `Description` | `String` | Optional | Name of the content. | String getDescription() | setDescription(String description) |
| `Quantity` | `Integer` | Optional | Quantity of the content. | Integer getQuantity() | setQuantity(Integer quantity) |
| `Weight` | `Double` | Optional | Weight of this single packed item.<br>**Default**: `0d` | Double getWeight() | setWeight(Double weight) |
| `Height` | `double` | Required | The dimensional height of the item. | double getHeight() | setHeight(double height) |
| `Width` | `double` | Required | The dimensional width of the item. | double getWidth() | setWidth(double width) |
| `Length` | `double` | Required | The dimensional lenth of the item. | double getLength() | setLength(double length) |

## Example (as XML)

```xml
<wtg:Content xmlns:wtg="https://www.wisetechglobal.com/">
  <wtg:ContentRefNumber xmlns:wtg="https://www.wisetechglobal.com/">ContentRefNumber4</wtg:ContentRefNumber>
  <wtg:Height xmlns:wtg="https://www.wisetechglobal.com/">36.2</wtg:Height>
  <wtg:Width xmlns:wtg="https://www.wisetechglobal.com/">34.84</wtg:Width>
  <wtg:Length xmlns:wtg="https://www.wisetechglobal.com/">218.76</wtg:Length>
</wtg:Content>
```

