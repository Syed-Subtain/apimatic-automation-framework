
# Wtg Third Party Hazardous 5

Container for details for processing by an external hazardous compliance system.

## Structure

`WtgThirdPartyHazardous5`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `UseThirdPartyHazardous` | `Boolean` | Optional | Indicates if the shipment was created using a third party hazardous package.<br>**Default**: `false` | Boolean getUseThirdPartyHazardous() | setUseThirdPartyHazardous(Boolean useThirdPartyHazardous) |
| `CarrierID` | `String` | Required | Numeric identifier for the carrier. | String getCarrierID() | setCarrierID(String carrierID) |
| `SessionID` | `String` | Optional | Third Party Hazardous Session Identifier. | String getSessionID() | setSessionID(String sessionID) |
| `PackageID` | `Integer` | Optional | Third Party Hazardous Package Identifier.<br>**Default**: `0` | Integer getPackageID() | setPackageID(Integer packageID) |
| `PackageUri` | `String` | Optional | Third Party Hazardous Package Uri. | String getPackageUri() | setPackageUri(String packageUri) |
| `ShipmentKey` | `String` | Required | Third Party Hazardous Shipment Key. | String getShipmentKey() | setShipmentKey(String shipmentKey) |

## Example (as XML)

```xml
<wtg:ThirdPartyHazardous xmlns:wtg="https://www.wisetechglobal.com/">
  <wtg:CarrierID xmlns:wtg="https://www.wisetechglobal.com/">CarrierID6</wtg:CarrierID>
  <wtg:ShipmentKey xmlns:wtg="https://www.wisetechglobal.com/">ShipmentKey6</wtg:ShipmentKey>
</wtg:ThirdPartyHazardous>
```

