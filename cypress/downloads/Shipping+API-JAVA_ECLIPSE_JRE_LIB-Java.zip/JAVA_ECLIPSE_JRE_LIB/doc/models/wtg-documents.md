
# Wtg Documents

Container for documents to be printed by the caller of the transaction (client).

## Structure

`WtgDocuments`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Output` | [`List<WtgOutput>`](../../doc/models/wtg-output.md) | Optional | Container for documents to be printed externally from the transaction. | List<WtgOutput> getOutput() | setOutput(List<WtgOutput> output) |

## Example (as XML)

```xml
<wtg:Documents xmlns:wtg="https://www.wisetechglobal.com/" />
```

