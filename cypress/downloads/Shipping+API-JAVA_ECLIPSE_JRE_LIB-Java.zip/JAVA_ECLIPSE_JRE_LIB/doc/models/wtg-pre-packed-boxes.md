
# Wtg Pre Packed Boxes

pre-packed boxes, including any items specified that will be packed and excess space used before any new boxes are created.

## Structure

`WtgPrePackedBoxes`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `PrePackedBox` | [`WtgPrePackedBox`](../../doc/models/wtg-pre-packed-box.md) | Optional | Individual pre-packed boxes | WtgPrePackedBox getPrePackedBox() | setPrePackedBox(WtgPrePackedBox prePackedBox) |

## Example (as XML)

```xml
<wtg:PrePackedBoxes xmlns:wtg="https://www.wisetechglobal.com/">
  <wtg:PrePackedBox xmlns:wtg="https://www.wisetechglobal.com/" />
</wtg:PrePackedBoxes>
```

