
# Wtg Charge Groups 8

Container for all charge groups associated with the transaction.

## Structure

`WtgChargeGroups8`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `ChargeGroup` | [`List<WtgChargeGroup8>`](../../doc/models/wtg-charge-group-8.md) | Optional | Container for an individual charge group associated with the transaction. | List<WtgChargeGroup8> getChargeGroup() | setChargeGroup(List<WtgChargeGroup8> chargeGroup) |

## Example (as XML)

```xml
<wtg:ChargeGroups xmlns:wtg="https://www.wisetechglobal.com/" />
```

