
# Wtg Receiver 2

Container for the receiver address details associated with the transaction.

## Structure

`WtgReceiver2`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `CompanyName` | `String` | Optional | The company name associated with the address. | String getCompanyName() | setCompanyName(String companyName) |
| `Street` | `String` | Optional | First line of the address. | String getStreet() | setStreet(String street) |
| `Locale` | `String` | Optional | Second line of the address. | String getLocale() | setLocale(String locale) |
| `Other` | `String` | Optional | Third line of the address. | String getOther() | setOther(String other) |
| `City` | `String` | Optional | City of the address. | String getCity() | setCity(String city) |
| `Region` | `String` | Optional | The state or region of the address. | String getRegion() | setRegion(String region) |
| `RegionName` | `String` | Optional | The name of the region associated with the address, this value will be automatically added if available. | String getRegionName() | setRegionName(String regionName) |
| `PostalCode` | `String` | Optional | The postal code or zip associated with the address. | String getPostalCode() | setPostalCode(String postalCode) |
| `Country` | `String` | Optional | The country code for the address. | String getCountry() | setCountry(String country) |
| `CountryName` | `String` | Optional | The name of the country associated with the address, this value will be automatically added if available. | String getCountryName() | setCountryName(String countryName) |
| `Residential` | `Boolean` | Optional | Indicates whether the address is residential or commercial.<br>**Default**: `false` | Boolean getResidential() | setResidential(Boolean residential) |
| `IDNumber` | `String` | Optional | Identification number of receiver. | String getIDNumber() | setIDNumber(String iDNumber) |
| `IDType` | [`WtgIDTypeEnum`](../../doc/models/wtg-id-type-enum.md) | Optional | ID Number Type | WtgIDTypeEnum getIDType() | setIDType(WtgIDTypeEnum iDType) |
| `TaxNumber` | `String` | Optional | Tax identification number of receiver. | String getTaxNumber() | setTaxNumber(String taxNumber) |
| `TaxType` | [`WtgTaxTypeEnum`](../../doc/models/wtg-tax-type-enum.md) | Optional | Tax Number Type | WtgTaxTypeEnum getTaxType() | setTaxType(WtgTaxTypeEnum taxType) |

## Example (as XML)

```xml
<wtg:Receiver xmlns:wtg="https://www.wisetechglobal.com/" />
```

