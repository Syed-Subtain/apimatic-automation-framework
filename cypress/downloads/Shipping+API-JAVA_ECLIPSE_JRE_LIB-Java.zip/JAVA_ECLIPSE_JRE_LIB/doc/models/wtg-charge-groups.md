
# Wtg Charge Groups

Container for all charge groups associated with the transaction.

## Structure

`WtgChargeGroups`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `ChargeGroup` | [`List<WtgChargeGroup>`](../../doc/models/wtg-charge-group.md) | Optional | Container for an individual charge group associated with the transaction. | List<WtgChargeGroup> getChargeGroup() | setChargeGroup(List<WtgChargeGroup> chargeGroup) |

## Example (as XML)

```xml
<wtg:ChargeGroups xmlns:wtg="https://www.wisetechglobal.com/" />
```

