
# Wtg Additional Handling Type Enum

## Enumeration

`WtgAdditionalHandlingTypeEnum`

## Fields

| Name |
|  --- |
| `Default` |
| `NoContainer` |
| `Liquids` |
| `NonStandardPackaging` |
| `DiscretionaryItems` |

