
# Wtg Label Detail Mask Enum

## Enumeration

`WtgLabelDetailMaskEnum`

## Fields

| Name |
|  --- |
| `Enum1` |
| `Enum2` |
| `Enum3` |
| `Enum4` |
| `Enum5` |
| `Enum6` |

