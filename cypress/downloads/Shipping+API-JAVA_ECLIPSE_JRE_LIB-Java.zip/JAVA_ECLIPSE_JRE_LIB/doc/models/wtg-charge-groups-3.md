
# Wtg Charge Groups 3

Container for all charge groups associated with the transaction.

## Structure

`WtgChargeGroups3`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `ChargeGroup` | [`List<WtgChargeGroup3>`](../../doc/models/wtg-charge-group-3.md) | Optional | Container for an individual charge group associated with the transaction. | List<WtgChargeGroup3> getChargeGroup() | setChargeGroup(List<WtgChargeGroup3> chargeGroup) |

## Example (as XML)

```xml
<wtg:ChargeGroups xmlns:wtg="https://www.wisetechglobal.com/" />
```

