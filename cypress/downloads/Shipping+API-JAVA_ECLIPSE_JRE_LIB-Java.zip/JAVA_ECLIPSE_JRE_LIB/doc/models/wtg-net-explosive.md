
# Wtg Net Explosive

Container for net explosive details.

## Structure

`WtgNetExplosive`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Amount` | [`WtgAmount`](../../doc/models/wtg-amount.md) | Optional | Container for net explosive amount details. | WtgAmount getAmount() | setAmount(WtgAmount amount) |
| `Abbreviation` | [`WtgAbbreviationEnum`](../../doc/models/wtg-abbreviation-enum.md) | Optional | Net explosive abbreviation | WtgAbbreviationEnum getAbbreviation() | setAbbreviation(WtgAbbreviationEnum abbreviation) |

## Example (as XML)

```xml
<wtg:NetExplosive xmlns:wtg="https://www.wisetechglobal.com/">
  <wtg:Amount xmlns:wtg="https://www.wisetechglobal.com/" />
</wtg:NetExplosive>
```

