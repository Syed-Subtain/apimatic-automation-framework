
# Wtg Cartonization 3

Container for cartonization data for this transaction.

## Structure

`WtgCartonization3`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Carrier` | `String` | Optional | The catonization carrier ID. | String getCarrier() | setCarrier(String carrier) |
| `UserName` | `String` | Optional | The originating username. | String getUserName() | setUserName(String userName) |
| `ControlIdentifier` | `String` | Optional | Control identifier for a cartonization request. | String getControlIdentifier() | setControlIdentifier(String controlIdentifier) |
| `DimensionsUOM` | `String` | Optional | The units of measure for the unit dimensions. | String getDimensionsUOM() | setDimensionsUOM(String dimensionsUOM) |
| `WeightUOM` | `String` | Optional | The units of measure for the unit weight. | String getWeightUOM() | setWeightUOM(String weightUOM) |
| `CurrencyCode` | `String` | Optional | Currency of the value of the comtent. | String getCurrencyCode() | setCurrencyCode(String currencyCode) |
| `LayFlat` | `Boolean` | Optional | Aligns all items laying flat. If possible, it may create a "brick-laying" pattern to increase stability. | Boolean getLayFlat() | setLayFlat(Boolean layFlat) |
| `Corners` | `Boolean` | Optional | Only pack items at valid corner points of other items (optimal) | Boolean getCorners() | setCorners(Boolean corners) |
| `UsableSpace` | `Double` | Optional | Estimate of percentage space in boxes that is usable, i.e., not packing material. | Double getUsableSpace() | setUsableSpace(Double usableSpace) |
| `ReservedSpace` | `Double` | Optional | Space in boxes that is reserved, i.e., for packing material.. | Double getReservedSpace() | setReservedSpace(Double reservedSpace) |
| `BoxTypeChoiceGoal` | `String` | Optional | The objective to evaluate boxTypeChoices by. ‘lowest-cost’ minimizes price or volume cost of boxTypes selected, ‘most-items’ maximizes item count per box opened, i.e., fewest total boxes used. | String getBoxTypeChoiceGoal() | setBoxTypeChoiceGoal(String boxTypeChoiceGoal) |
| `BoxTypeSets` | [`WtgBoxTypeSets`](../../doc/models/wtg-box-type-sets.md) | Optional | predefined box types to be used, separated by commas. Will be overridden by boxTypes. | WtgBoxTypeSets getBoxTypeSets() | setBoxTypeSets(WtgBoxTypeSets boxTypeSets) |
| `Rules` | `String` | Optional | a space-delimited array of packing rule strings. The only acceptable rule-type at the moment is "exclude", and it follows the form; exclude,[item-ref-id],[target-item-ref-id] | String getRules() | setRules(String rules) |
| `CartonizationGroupID` | `Integer` | Optional | Numeric identifier for a cartonization group.<br>**Default**: `0` | Integer getCartonizationGroupID() | setCartonizationGroupID(Integer cartonizationGroupID) |
| `PrePackedBoxes` | [`WtgPrePackedBoxes`](../../doc/models/wtg-pre-packed-boxes.md) | Optional | pre-packed boxes, including any items specified that will be packed and excess space used before any new boxes are created. | WtgPrePackedBoxes getPrePackedBoxes() | setPrePackedBoxes(WtgPrePackedBoxes prePackedBoxes) |
| `Contents` | [`WtgContents`](../../doc/models/wtg-contents.md) | Required | Container for all contents associated with the transaction. | WtgContents getContents() | setContents(WtgContents contents) |
| `PackageTemplate` | [`WtgPackageTemplate2`](../../doc/models/wtg-package-template-2.md) | Required | Container for elements to be applied to each package created from the cartonization response . | WtgPackageTemplate2 getPackageTemplate() | setPackageTemplate(WtgPackageTemplate2 packageTemplate) |

## Example (as XML)

```xml
<wtg:Cartonization xmlns:wtg="https://www.wisetechglobal.com/">
  <wtg:BoxTypeSets xmlns:wtg="https://www.wisetechglobal.com/" />
  <wtg:PrePackedBoxes xmlns:wtg="https://www.wisetechglobal.com/" />
  <wtg:Contents xmlns:wtg="https://www.wisetechglobal.com/">
    <wtg:Content>
      <wtg:ContentRefNumber>ContentRefNumber3</wtg:ContentRefNumber>
      <wtg:CenterOfMass />
    </wtg:Content>
    <wtg:Content>
      <wtg:ContentRefNumber>ContentRefNumber4</wtg:ContentRefNumber>
      <wtg:CenterOfMass />
    </wtg:Content>
  </wtg:Contents>
  <wtg:PackageTemplate xmlns:wtg="https://www.wisetechglobal.com/">
    <wtg:RecordIdentifiers />
    <wtg:SpecialCare />
    <wtg:LithiumBatteryDetails />
    <wtg:Insurance />
    <wtg:COD />
    <wtg:Holder />
    <wtg:Rates />
  </wtg:PackageTemplate>
</wtg:Cartonization>
```

