
# Tns Page

Container for an individual page to be printed by the caller of the transaction (client).

## Structure

`TnsPage`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Url` | `String` | Optional | The address to access to contents of the page. | String getUrl() | setUrl(String url) |
| `Width` | `Integer` | Optional | The width in pixels of the page.<br>**Default**: `0` | Integer getWidth() | setWidth(Integer width) |
| `Height` | `Integer` | Optional | The height in pixels of the page.<br>**Default**: `0` | Integer getHeight() | setHeight(Integer height) |
| `UsePercentage` | `Boolean` | Optional | Indicates if the width and height values are expressed in percentages rather than pixels.<br>**Default**: `false` | Boolean getUsePercentage() | setUsePercentage(Boolean usePercentage) |

## Example (as JSON)

```json
{
  "Url": null,
  "Width": null,
  "Height": null,
  "UsePercentage": null
}
```

