
# Wtg Content 5

Container for a individual content (line item) associated with the transaction.

## Structure

`WtgContent5`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `ContentRefNumber` | `String` | Required | Unique reference number for the content. | String getContentRefNumber() | setContentRefNumber(String contentRefNumber) |
| `Quantity` | `Double` | Optional | Quantity of the line item in the package.<br>**Default**: `0d` | Double getQuantity() | setQuantity(Double quantity) |
| `Value` | `Double` | Optional | Monetary value of a single line item.<br>**Default**: `0d` | Double getValue() | setValue(Double value) |
| `Weight` | `Double` | Optional | Weight of a single line item.<br>**Default**: `0d` | Double getWeight() | setWeight(Double weight) |
| `Length` | `Double` | Optional | Length of this line item.<br>**Default**: `0d` | Double getLength() | setLength(Double length) |
| `Width` | `Double` | Optional | Width of this line item.<br>**Default**: `0d` | Double getWidth() | setWidth(Double width) |
| `Height` | `Double` | Optional | Height of this line item.<br>**Default**: `0d` | Double getHeight() | setHeight(Double height) |
| `Description` | `String` | Optional | Description of the line item. | String getDescription() | setDescription(String description) |

## Example (as XML)

```xml
<wtg:Content xmlns:wtg="https://www.wisetechglobal.com/">
  <wtg:ContentRefNumber xmlns:wtg="https://www.wisetechglobal.com/">ContentRefNumber4</wtg:ContentRefNumber>
</wtg:Content>
```

