
# Wtg International 5

Container for international details associated with the shipment.

## Structure

`WtgInternational5`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `NonDutiable` | `Boolean` | Optional | Indicates whether the package contains only non-dutiable goods.  Defaults to no if omitted.<br>**Default**: `false` | Boolean getNonDutiable() | setNonDutiable(Boolean nonDutiable) |
| `DocumentsOnly` | `Boolean` | Optional | Indicates whether the package contains only documents.  Defaults to not documents only if omitted.<br>**Default**: `false` | Boolean getDocumentsOnly() | setDocumentsOnly(Boolean documentsOnly) |
| `Contents` | [`WtgContents6`](../../doc/models/wtg-contents-6.md) | Optional | Container for all contents (line items) associated with the transaction. | WtgContents6 getContents() | setContents(WtgContents6 contents) |

## Example (as XML)

```xml
<wtg:International xmlns:wtg="https://www.wisetechglobal.com/">
  <wtg:Contents xmlns:wtg="https://www.wisetechglobal.com/" />
</wtg:International>
```

