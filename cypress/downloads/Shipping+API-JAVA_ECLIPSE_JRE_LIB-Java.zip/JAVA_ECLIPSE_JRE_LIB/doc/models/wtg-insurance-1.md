
# Wtg Insurance 1

Container for insurance details.

## Structure

`WtgInsurance1`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Type` | `Integer` | Optional | Type of insurance.  Defaults to no insurance if not submitted.<br>**Constraints**: *Pattern*: `[1]` | Integer getType() | setType(Integer type) |
| `Value` | `Double` | Optional | Value the package is to be insured for.<br>**Default**: `0d` | Double getValue() | setValue(Double value) |
| `ValueCurrency` | `String` | Optional | Currency of the value the package is to be insured for. | String getValueCurrency() | setValueCurrency(String valueCurrency) |

## Example (as XML)

```xml
<wtg:Insurance xmlns:wtg="https://www.wisetechglobal.com/" />
```

