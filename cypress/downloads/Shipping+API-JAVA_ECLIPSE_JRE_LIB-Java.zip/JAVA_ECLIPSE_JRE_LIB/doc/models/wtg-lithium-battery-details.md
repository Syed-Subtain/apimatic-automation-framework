
# Wtg Lithium Battery Details

Outer container for Lithium Battery details for package.

## Structure

`WtgLithiumBatteryDetails`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Material` | [`WtgMaterialEnum`](../../doc/models/wtg-material-enum.md) | Optional | Describes the material composition of the battery or cell | WtgMaterialEnum getMaterial() | setMaterial(WtgMaterialEnum material) |
| `Packing` | [`WtgPackingEnum`](../../doc/models/wtg-packing-enum.md) | Optional | Describes the packing arrangement of the battery or cell with respect to other items within the same package | WtgPackingEnum getPacking() | setPacking(WtgPackingEnum packing) |

## Example (as XML)

```xml
<wtg:LithiumBatteryDetails xmlns:wtg="https://www.wisetechglobal.com/" />
```

