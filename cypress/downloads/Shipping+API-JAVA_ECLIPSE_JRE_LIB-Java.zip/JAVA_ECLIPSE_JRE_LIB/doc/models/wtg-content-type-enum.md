
# Wtg Content Type Enum

## Enumeration

`WtgContentTypeEnum`

## Fields

| Name |
|  --- |
| `Gift` |
| `Documents` |
| `Sample` |
| `Return` |
| `Merchandise` |
| `Other` |

