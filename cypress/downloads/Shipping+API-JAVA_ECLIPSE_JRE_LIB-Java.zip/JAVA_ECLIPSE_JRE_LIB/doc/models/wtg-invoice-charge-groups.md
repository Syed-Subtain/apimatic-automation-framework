
# Wtg Invoice Charge Groups

Container for invoice charges associated with the shipment.

## Structure

`WtgInvoiceChargeGroups`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `ChargeGroup` | [`List<WtgChargeGroup10>`](../../doc/models/wtg-charge-group-10.md) | Optional | Container for an individual charge group associated with the transaction. | List<WtgChargeGroup10> getChargeGroup() | setChargeGroup(List<WtgChargeGroup10> chargeGroup) |

## Example (as XML)

```xml
<wtg:InvoiceChargeGroups xmlns:wtg="https://www.wisetechglobal.com/" />
```

