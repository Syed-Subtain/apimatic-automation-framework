
# Wtg Pierbridge End of Day Action Response

Indicates the status the EndOfDayAction request.

## Structure

`WtgPierbridgeEndOfDayActionResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `TransactionIdentifier` | `String` | Optional | The unique identifier for the transaction given in the request. | String getTransactionIdentifier() | setTransactionIdentifier(String transactionIdentifier) |
| `ControlIdentifier` | `String` | Optional | The control reference for the transaction given in the request. | String getControlIdentifier() | setControlIdentifier(String controlIdentifier) |
| `Status` | [`WtgStatus`](../../doc/models/wtg-status.md) | Required | Container for transaction errors and warning elements. | WtgStatus getStatus() | setStatus(WtgStatus status) |
| `Carrier` | `Integer` | Optional | Numeric identifier for the carrier. | Integer getCarrier() | setCarrier(Integer carrier) |
| `CarrierName` | `String` | Optional | The name for the carrier. | String getCarrierName() | setCarrierName(String carrierName) |
| `CarrierSymbol` | `String` | Optional | The symbol associated with the carrier. | String getCarrierSymbol() | setCarrierSymbol(String carrierSymbol) |
| `CarrierScac` | `String` | Optional | The NMFTA (National Motor Freight Traffic Association) Standard Carrier Alpha Code of the carrier. | String getCarrierScac() | setCarrierScac(String carrierScac) |
| `ServiceType` | `String` | Optional | Numeric identifier for the carrier service associated with the transaction. | String getServiceType() | setServiceType(String serviceType) |
| `ServiceTypeName` | `String` | Optional | Description of the service used for the transaction. | String getServiceTypeName() | setServiceTypeName(String serviceTypeName) |
| `Weight` | `String` | Optional | Total weight of the shipment. | String getWeight() | setWeight(String weight) |
| `Identifier` | `String` | Optional | The carrier's end of day identifier of the item that has been closed. | String getIdentifier() | setIdentifier(String identifier) |
| `EndOfDayID` | `Integer` | Optional | Unique numeric identifier for the end of day record. | Integer getEndOfDayID() | setEndOfDayID(Integer endOfDayID) |
| `Account` | `String` | Optional | Account number to perform the end of day action for. | String getAccount() | setAccount(String account) |
| `AccountID` | `Integer` | Optional | Unique numeric identifier for the account. | Integer getAccountID() | setAccountID(Integer accountID) |
| `AccountTypeID` | `Integer` | Optional | Identifier for the type of account. | Integer getAccountTypeID() | setAccountTypeID(Integer accountTypeID) |
| `MailerID` | `String` | Optional | The mailer identifier associated with the carrier account that has been closed. | String getMailerID() | setMailerID(String mailerID) |
| `UserID` | `Integer` | Optional | The identifier for the user. | Integer getUserID() | setUserID(Integer userID) |
| `UserName` | `String` | Optional | An echo of the username used to process the transaction. | String getUserName() | setUserName(String userName) |
| `Processing` | [`WtgProcessing`](../../doc/models/wtg-processing.md) | Required | Container element for transaction processing statistics. | WtgProcessing getProcessing() | setProcessing(WtgProcessing processing) |

## Example (as XML)

```xml
<wtg:PierbridgeEndOfDayActionResponse xmlns:wtg="https://www.wisetechglobal.com/">
  <wtg:Status xmlns:wtg="https://www.wisetechglobal.com/">
    <wtg:Code>108</wtg:Code>
    <wtg:Warnings />
    <wtg:Errors />
  </wtg:Status>
  <wtg:Processing xmlns:wtg="https://www.wisetechglobal.com/">
    <wtg:StartTime>StartTime4</wtg:StartTime>
    <wtg:EndTime>EndTime0</wtg:EndTime>
    <wtg:Duration>252.24</wtg:Duration>
    <wtg:External />
    <wtg:ServerName>ServerName6</wtg:ServerName>
  </wtg:Processing>
</wtg:PierbridgeEndOfDayActionResponse>
```

