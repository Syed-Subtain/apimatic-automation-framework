
# Wtg Pierbridge Print Request

Prints one or more documents or labels that are have already been stored in the datbase.

## Structure

`WtgPierbridgePrintRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `TransactionIdentifier` | `String` | Optional | A unique identifier for the transaction, this value is not used during processing and will be returned in the response. | String getTransactionIdentifier() | setTransactionIdentifier(String transactionIdentifier) |
| `ControlIdentifier` | `String` | Optional | A reference to a control which generated the request, this value is not used during processing and will be returned in the response. | String getControlIdentifier() | setControlIdentifier(String controlIdentifier) |
| `UserName` | `String` | Required | The user name to use when processing the transaction.<br>**Constraints**: *Minimum Length*: `1` | String getUserName() | setUserName(String userName) |
| `OutputType` | `Integer` | Optional | Type of output to print.  Must provide an Output Type or an Output Base Type.<br>**Default**: `0` | Integer getOutputType() | setOutputType(Integer outputType) |
| `OutputBaseType` | `Integer` | Optional | Base type of output to print.  Must provide an Output Type or an Output Base Type.<br>**Default**: `0` | Integer getOutputBaseType() | setOutputBaseType(Integer outputBaseType) |
| `OutputCategory` | `Integer` | Optional | 1=Labels, 2=Documents.<br>**Default**: `0` | Integer getOutputCategory() | setOutputCategory(Integer outputCategory) |
| `PackageID` | `Integer` | Optional | Package to print output for.<br>**Default**: `0` | Integer getPackageID() | setPackageID(Integer packageID) |
| `ShipmentID` | `Integer` | Optional | Shipment to print output for.<br>**Default**: `0` | Integer getShipmentID() | setShipmentID(Integer shipmentID) |
| `ConsolidatedShipmentID` | `Integer` | Optional | The identifier of the consolidated shipment.<br>**Default**: `0` | Integer getConsolidatedShipmentID() | setConsolidatedShipmentID(Integer consolidatedShipmentID) |
| `PendingID` | `Integer` | Optional | Pending item to print output for.<br>**Default**: `0` | Integer getPendingID() | setPendingID(Integer pendingID) |
| `StatusDescription` | `String` | Optional | Description of package's status.  Typically contains a description of why a package failed to ship. | String getStatusDescription() | setStatusDescription(String statusDescription) |
| `WayBillNumber` | `String` | Optional | Tracking number to print output for. | String getWayBillNumber() | setWayBillNumber(String wayBillNumber) |
| `ShipmentRequisitionID` | `Integer` | Optional | Shipment requisition to print output for.<br>**Default**: `0` | Integer getShipmentRequisitionID() | setShipmentRequisitionID(Integer shipmentRequisitionID) |
| `PackItemID` | `Integer` | Optional | Unique numeric identifier for the pack item.<br>**Default**: `0` | Integer getPackItemID() | setPackItemID(Integer packItemID) |
| `ContentID` | `Integer` | Optional | Content Item to print output for.<br>**Default**: `0` | Integer getContentID() | setContentID(Integer contentID) |
| `CustomerID` | `Integer` | Optional | Customer to print output for.<br>**Default**: `0` | Integer getCustomerID() | setCustomerID(Integer customerID) |
| `IsLastPackage` | `Boolean` | Optional | Deprecated.  Do not use.<br>**Default**: `false` | Boolean getIsLastPackage() | setIsLastPackage(Boolean isLastPackage) |
| `EndOfDayID` | `Integer` | Optional | End Of Day to print output for.<br>**Default**: `0` | Integer getEndOfDayID() | setEndOfDayID(Integer endOfDayID) |
| `InsuranceID` | `Integer` | Optional | Insurance to print output for.<br>**Default**: `0` | Integer getInsuranceID() | setInsuranceID(Integer insuranceID) |
| `Guid` | `String` | Optional | Unique guid relating to the output item to print. | String getGuid() | setGuid(String guid) |
| `OutputHandling` | [`WtgOutputHandling`](../../doc/models/wtg-output-handling.md) | Optional | Container to allow handling of outputs to be specified. | WtgOutputHandling getOutputHandling() | setOutputHandling(WtgOutputHandling outputHandling) |
| `Outputs` | [`WtgOutputs`](../../doc/models/wtg-outputs.md) | Optional | Container for outputs the transaction should generate or customize the printing of. | WtgOutputs getOutputs() | setOutputs(WtgOutputs outputs) |
| `Diagnostics` | [`WtgDiagnostics`](../../doc/models/wtg-diagnostics.md) | Optional | Container for logging and diagnostic override elements. | WtgDiagnostics getDiagnostics() | setDiagnostics(WtgDiagnostics diagnostics) |
| `Identification` | [`WtgIdentification`](../../doc/models/wtg-identification.md) | Optional | Container for client identification elements. | WtgIdentification getIdentification() | setIdentification(WtgIdentification identification) |

## Example (as XML)

```xml
<wtg:PierbridgePrintRequest xmlns:wtg="https://www.wisetechglobal.com/">
  <wtg:UserName xmlns:wtg="https://www.wisetechglobal.com/">UserName6</wtg:UserName>
  <wtg:OutputHandling xmlns:wtg="https://www.wisetechglobal.com/" />
  <wtg:Outputs xmlns:wtg="https://www.wisetechglobal.com/" />
  <wtg:Diagnostics xmlns:wtg="https://www.wisetechglobal.com/" />
  <wtg:Identification xmlns:wtg="https://www.wisetechglobal.com/" />
</wtg:PierbridgePrintRequest>
```

