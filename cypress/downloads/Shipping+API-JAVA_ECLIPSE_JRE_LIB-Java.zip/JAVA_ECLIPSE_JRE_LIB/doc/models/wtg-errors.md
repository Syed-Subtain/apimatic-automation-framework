
# Wtg Errors

Container for all errors found whilst processing the transaction.

## Structure

`WtgErrors`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Error` | [`List<WtgError>`](../../doc/models/wtg-error.md) | Optional | Container for a single error found whilst processing the transaction. | List<WtgError> getError() | setError(List<WtgError> error) |

## Example (as XML)

```xml
<wtg:Errors xmlns:wtg="https://www.wisetechglobal.com/" />
```

