
# Wtg BOL Handling

Container to allow handling of BOL to be specified.

## Structure

`WtgBOLHandling`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Email` | `Boolean` | Optional | Specifies whether the BOL should be emailed. Defaults to false if not submitted.<br>**Default**: `false` | Boolean getEmail() | setEmail(Boolean email) |
| `EmailAddress` | `String` | Optional | Email address to send the BOL to. | String getEmailAddress() | setEmailAddress(String emailAddress) |

## Example (as XML)

```xml
<wtg:BOLHandling xmlns:wtg="https://www.wisetechglobal.com/" />
```

