
# Wtg Pages

Container for all pages to be printed by the caller of the transaction (client).

## Structure

`WtgPages`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Page` | [`List<WtgPage>`](../../doc/models/wtg-page.md) | Optional | Container for an individual page to be printed by the caller of the transaction (client). | List<WtgPage> getPage() | setPage(List<WtgPage> page) |

## Example (as XML)

```xml
<wtg:Pages xmlns:wtg="https://www.wisetechglobal.com/" />
```

