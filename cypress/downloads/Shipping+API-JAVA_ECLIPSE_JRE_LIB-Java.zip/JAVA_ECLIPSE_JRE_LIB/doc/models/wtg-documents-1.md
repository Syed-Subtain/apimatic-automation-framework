
# Wtg Documents 1

Container for documents to be printed by the caller of the transaction (client).

## Structure

`WtgDocuments1`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Output` | [`List<WtgOutput4>`](../../doc/models/wtg-output-4.md) | Optional | Container for documents to be printed externally from the transaction. | List<WtgOutput4> getOutput() | setOutput(List<WtgOutput4> output) |

## Example (as XML)

```xml
<wtg:Documents xmlns:wtg="https://www.wisetechglobal.com/" />
```

