
# Wtg Insurance 2

Container for insurance details.

## Structure

`WtgInsurance2`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Code` | `String` | Required | Code relating to the insurance. | String getCode() | setCode(String code) |

## Example (as XML)

```xml
<wtg:Insurance xmlns:wtg="https://www.wisetechglobal.com/">
  <wtg:Code xmlns:wtg="https://www.wisetechglobal.com/">Code0</wtg:Code>
</wtg:Insurance>
```

