
# Wtg Billing 5

Container for billing details associated with the transaction.

## Structure

`WtgBilling5`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `PayerType` | `Integer` | Optional | The unique numeric identifier for the type of payer.<br>**Default**: `0` | Integer getPayerType() | setPayerType(Integer payerType) |
| `AccountNumber` | `String` | Optional | An optional account number associated with the payer. | String getAccountNumber() | setAccountNumber(String accountNumber) |

## Example (as XML)

```xml
<wtg:Billing xmlns:wtg="https://www.wisetechglobal.com/" />
```

