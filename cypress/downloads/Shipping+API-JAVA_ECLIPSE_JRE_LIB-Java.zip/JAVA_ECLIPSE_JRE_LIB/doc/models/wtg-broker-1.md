
# Wtg Broker 1

Container for broker details.

## Structure

`WtgBroker1`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `BrokerID` | `Integer` | Optional | Export broker who will handle the shipment.<br>**Default**: `0` | Integer getBrokerID() | setBrokerID(Integer brokerID) |
| `BrokerType` | [`WtgBrokerTypeEnum`](../../doc/models/wtg-broker-type-enum.md) | Optional | Export broker who will handle the shipment. | WtgBrokerTypeEnum getBrokerType() | setBrokerType(WtgBrokerTypeEnum brokerType) |
| `Contact` | `String` | Optional | Broker contact who will handle the shipment. | String getContact() | setContact(String contact) |
| `Phone` | `String` | Optional | Export broker phone number. | String getPhone() | setPhone(String phone) |
| `EMail` | `String` | Optional | Export broker email address. | String getEMail() | setEMail(String eMail) |
| `Fax` | `String` | Optional | Export broker fax number. | String getFax() | setFax(String fax) |
| `AccountNumber` | `String` | Optional | Export broker account number. | String getAccountNumber() | setAccountNumber(String accountNumber) |
| `Organization` | `String` | Optional | Export broker organization name. | String getOrganization() | setOrganization(String organization) |
| `Street` | `String` | Optional | Export broker address street. | String getStreet() | setStreet(String street) |
| `Locale` | `String` | Optional | Export broker address locale. | String getLocale() | setLocale(String locale) |
| `City` | `String` | Optional | Export broker address city name. | String getCity() | setCity(String city) |
| `Region` | `String` | Optional | Export broker address region. | String getRegion() | setRegion(String region) |
| `PostalCode` | `String` | Optional | Export broker address postal code. | String getPostalCode() | setPostalCode(String postalCode) |
| `Country` | `String` | Optional | Export broker address country code. | String getCountry() | setCountry(String country) |
| `IdentificationNumber` | `String` | Optional | The Tax Identification Number of the individual acting as  broker. | String getIdentificationNumber() | setIdentificationNumber(String identificationNumber) |
| `IdentificationNumberType` | [`WtgIdentificationNumberTypeEnum`](../../doc/models/wtg-identification-number-type-enum.md) | Optional | The Tax Identification Number Type of the individual acting as broker. | WtgIdentificationNumberTypeEnum getIdentificationNumberType() | setIdentificationNumberType(WtgIdentificationNumberTypeEnum identificationNumberType) |

## Example (as XML)

```xml
<wtg:Broker xmlns:wtg="https://www.wisetechglobal.com/" />
```

