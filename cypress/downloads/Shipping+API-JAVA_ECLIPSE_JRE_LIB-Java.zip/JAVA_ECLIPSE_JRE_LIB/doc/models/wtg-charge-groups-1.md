
# Wtg Charge Groups 1

Container for all charge groups associated with the transaction.

## Structure

`WtgChargeGroups1`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `ChargeGroup` | [`List<WtgChargeGroup1>`](../../doc/models/wtg-charge-group-1.md) | Optional | Container for an individual charge group associated with the transaction. | List<WtgChargeGroup1> getChargeGroup() | setChargeGroup(List<WtgChargeGroup1> chargeGroup) |

## Example (as XML)

```xml
<wtg:ChargeGroups xmlns:wtg="https://www.wisetechglobal.com/" />
```

