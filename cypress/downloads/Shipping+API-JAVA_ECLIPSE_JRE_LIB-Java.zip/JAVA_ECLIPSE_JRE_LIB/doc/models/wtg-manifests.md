
# Wtg Manifests

Container for available manifests.

## Structure

`WtgManifests`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Manifest` | [`List<WtgManifest>`](../../doc/models/wtg-manifest.md) | Optional | Container for a single manifest. | List<WtgManifest> getManifest() | setManifest(List<WtgManifest> manifest) |

## Example (as XML)

```xml
<wtg:Manifests xmlns:wtg="https://www.wisetechglobal.com/" />
```

