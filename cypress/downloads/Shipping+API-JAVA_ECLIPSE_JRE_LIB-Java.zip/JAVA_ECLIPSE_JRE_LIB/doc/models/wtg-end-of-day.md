
# Wtg End of Day

Container for an individual end of day record.

## Structure

`WtgEndOfDay`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `EndOfDayID` | `int` | Required | The identifier for the end of day action. | int getEndOfDayID() | setEndOfDayID(int endOfDayID) |
| `UserName` | `String` | Optional | The name of the user associated with the end day record. | String getUserName() | setUserName(String userName) |
| `UserFullName` | `String` | Optional | The complete user description for the user that performed the end of day. | String getUserFullName() | setUserFullName(String userFullName) |
| `CarrierName` | `String` | Required | The name for the carrier. | String getCarrierName() | setCarrierName(String carrierName) |
| `AccountNumber` | `String` | Optional | The number associated with the end of day event. | String getAccountNumber() | setAccountNumber(String accountNumber) |
| `ShippingKey` | `String` | Optional | The shipping key associated with the end of day event. | String getShippingKey() | setShippingKey(String shippingKey) |
| `DateClosed` | `String` | Required | The date of the end of day event. | String getDateClosed() | setDateClosed(String dateClosed) |
| `State` | `String` | Required | The numeric identifier for the type of end of day event. | String getState() | setState(String state) |
| `Description` | `String` | Optional | The description of the end of day event. | String getDescription() | setDescription(String description) |
| `TimeLog` | `String` | Required | The date and time of the end of day event. | String getTimeLog() | setTimeLog(String timeLog) |
| `Identifier` | `String` | Optional | The carrier or system generated identifier for the end of day manifest. | String getIdentifier() | setIdentifier(String identifier) |
| `Packages` | [`WtgPackages1`](../../doc/models/wtg-packages-1.md) | Optional | Container for all packages associated with the transaction. | WtgPackages1 getPackages() | setPackages(WtgPackages1 packages) |

## Example (as XML)

```xml
<wtg:EndOfDay xmlns:wtg="https://www.wisetechglobal.com/">
  <wtg:EndOfDayID xmlns:wtg="https://www.wisetechglobal.com/">136</wtg:EndOfDayID>
  <wtg:CarrierName xmlns:wtg="https://www.wisetechglobal.com/">CarrierName6</wtg:CarrierName>
  <wtg:DateClosed xmlns:wtg="https://www.wisetechglobal.com/">DateClosed4</wtg:DateClosed>
  <wtg:State xmlns:wtg="https://www.wisetechglobal.com/">State8</wtg:State>
  <wtg:TimeLog xmlns:wtg="https://www.wisetechglobal.com/">TimeLog6</wtg:TimeLog>
  <wtg:Packages xmlns:wtg="https://www.wisetechglobal.com/" />
</wtg:EndOfDay>
```

