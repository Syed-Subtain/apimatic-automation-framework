
# Wtg Pickup Location Identifier Enum

## Enumeration

`WtgPickupLocationIdentifierEnum`

## Fields

| Name |
|  --- |
| `Enum1` |
| `Enum2` |
| `Enum3` |
| `Enum4` |

