
# Wtg Rates 1

Container all rates associated with the transaction.

## Structure

`WtgRates1`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Rate` | [`List<WtgRate1>`](../../doc/models/wtg-rate-1.md) | Optional | Container for an individual rate. | List<WtgRate1> getRate() | setRate(List<WtgRate1> rate) |

## Example (as XML)

```xml
<wtg:Rates xmlns:wtg="https://www.wisetechglobal.com/" />
```

