
# Wtg Disposition Method Enum

## Enumeration

`WtgDispositionMethodEnum`

## Fields

| Name |
|  --- |
| `Enum0` |
| `Enum1` |
| `Enum2` |
| `Enum3` |
| `Enum4` |
| `Enum5` |
| `Enum6` |
| `Enum7` |

