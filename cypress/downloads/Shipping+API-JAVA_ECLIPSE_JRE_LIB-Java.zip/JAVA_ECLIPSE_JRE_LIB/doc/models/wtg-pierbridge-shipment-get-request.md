
# Wtg Pierbridge Shipment Get Request

Finds details about a shipment with a given identifier.

## Structure

`WtgPierbridgeShipmentGetRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `ShipmentID` | `int` | Required | Identifier of the shipment. | int getShipmentID() | setShipmentID(int shipmentID) |
| `Carrier` | `Integer` | Optional | Numeric identifier for the carrier.<br>**Default**: `0` | Integer getCarrier() | setCarrier(Integer carrier) |
| `TransactionIdentifier` | `String` | Optional | A unique identifier for the transaction, this value is not used during processing and will be returned in the response. | String getTransactionIdentifier() | setTransactionIdentifier(String transactionIdentifier) |
| `ControlIdentifier` | `String` | Optional | A reference to a control which generated the request, this value is not used during processing and will be returned in the response. | String getControlIdentifier() | setControlIdentifier(String controlIdentifier) |
| `UserName` | `String` | Required | The user name to use when processing the transaction.<br>**Constraints**: *Minimum Length*: `1` | String getUserName() | setUserName(String userName) |
| `Diagnostics` | [`WtgDiagnostics`](../../doc/models/wtg-diagnostics.md) | Optional | Container for logging and diagnostic override elements. | WtgDiagnostics getDiagnostics() | setDiagnostics(WtgDiagnostics diagnostics) |
| `Identification` | [`WtgIdentification`](../../doc/models/wtg-identification.md) | Optional | Container for client identification elements. | WtgIdentification getIdentification() | setIdentification(WtgIdentification identification) |

## Example (as XML)

```xml
<wtg:PierbridgeShipmentGetRequest xmlns:wtg="https://www.wisetechglobal.com/">
  <wtg:ShipmentID xmlns:wtg="https://www.wisetechglobal.com/">40</wtg:ShipmentID>
  <wtg:UserName xmlns:wtg="https://www.wisetechglobal.com/">UserName6</wtg:UserName>
  <wtg:Diagnostics xmlns:wtg="https://www.wisetechglobal.com/" />
  <wtg:Identification xmlns:wtg="https://www.wisetechglobal.com/" />
</wtg:PierbridgeShipmentGetRequest>
```

