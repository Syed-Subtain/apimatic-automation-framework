
# Wtg Consolidation Data Type Enum

## Enumeration

`WtgConsolidationDataTypeEnum`

## Fields

| Name |
|  --- |
| `Enum1` |
| `Enum2` |
| `Enum3` |
| `Enum4` |
| `Enum5` |
| `Enum6` |
| `Enum7` |

