
# Tns Status 1

Container for transaction errors and warning elements.

## Structure

`TnsStatus1`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Code` | `int` | Required | If the transaction was successful this was will equal one, otherwise zero. | int getCode() | setCode(int code) |
| `Description` | `String` | Optional | Contains a description of the status, if the transaction failed this will contain an error message. | String getDescription() | setDescription(String description) |

## Example (as JSON)

```json
{
  "Code": 148,
  "Description": null
}
```

