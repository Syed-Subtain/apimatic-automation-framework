
# Wtg Pierbridge Shipment Detail Query Response

Contains details about the shipments that match the identifier given in the ShipmentGet request.

## Structure

`WtgPierbridgeShipmentDetailQueryResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `TransactionIdentifier` | `String` | Optional | The unique identifier for the transaction given in the request. | String getTransactionIdentifier() | setTransactionIdentifier(String transactionIdentifier) |
| `ControlIdentifier` | `String` | Optional | The control reference for the transaction given in the request. | String getControlIdentifier() | setControlIdentifier(String controlIdentifier) |
| `Shipments` | [`WtgShipments`](../../doc/models/wtg-shipments.md) | Optional | Container for all shipments assocaited with the transaction. | WtgShipments getShipments() | setShipments(WtgShipments shipments) |
| `PageSize` | `Integer` | Optional | The maximum number of records returned in the response.<br>**Constraints**: `<= 1000` | Integer getPageSize() | setPageSize(Integer pageSize) |
| `PageNumber` | `Integer` | Optional | The page number of data returned in the response. | Integer getPageNumber() | setPageNumber(Integer pageNumber) |
| `IncludeDefaultRates` | `Boolean` | Optional | Specifies whether to return negotiated rates in the response. | Boolean getIncludeDefaultRates() | setIncludeDefaultRates(Boolean includeDefaultRates) |
| `IncludeListRates` | `Boolean` | Optional | Specifies whether to reture list rates in the response. | Boolean getIncludeListRates() | setIncludeListRates(Boolean includeListRates) |
| `IncludeCustomRates` | `Boolean` | Optional | Specifies whether to reture custom rates in the response. | Boolean getIncludeCustomRates() | setIncludeCustomRates(Boolean includeCustomRates) |
| `SearchByField` | [`WtgSearchByFieldEnum`](../../doc/models/wtg-search-by-field-enum.md) | Optional | The field records serached by. | WtgSearchByFieldEnum getSearchByField() | setSearchByField(WtgSearchByFieldEnum searchByField) |
| `SearchByValue` | `String` | Optional | The value that the SearchByField was matched against. | String getSearchByValue() | setSearchByValue(String searchByValue) |
| `Status` | [`WtgStatus`](../../doc/models/wtg-status.md) | Required | Container for transaction errors and warning elements. | WtgStatus getStatus() | setStatus(WtgStatus status) |
| `Processing` | [`WtgProcessing`](../../doc/models/wtg-processing.md) | Required | Container element for transaction processing statistics. | WtgProcessing getProcessing() | setProcessing(WtgProcessing processing) |

## Example (as XML)

```xml
<wtg:PierbridgeShipmentDetailQueryResponse xmlns:wtg="https://www.wisetechglobal.com/">
  <wtg:Shipments xmlns:wtg="https://www.wisetechglobal.com/" />
  <wtg:Status xmlns:wtg="https://www.wisetechglobal.com/">
    <wtg:Code>108</wtg:Code>
    <wtg:Warnings />
    <wtg:Errors />
  </wtg:Status>
  <wtg:Processing xmlns:wtg="https://www.wisetechglobal.com/">
    <wtg:StartTime>StartTime4</wtg:StartTime>
    <wtg:EndTime>EndTime0</wtg:EndTime>
    <wtg:Duration>252.24</wtg:Duration>
    <wtg:External />
    <wtg:ServerName>ServerName6</wtg:ServerName>
  </wtg:Processing>
</wtg:PierbridgeShipmentDetailQueryResponse>
```

