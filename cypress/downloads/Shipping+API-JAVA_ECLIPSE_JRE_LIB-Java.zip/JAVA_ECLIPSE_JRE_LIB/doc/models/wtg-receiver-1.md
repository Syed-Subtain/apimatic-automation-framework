
# Wtg Receiver 1

Container for the receiver address details associated with the transaction.

## Structure

`WtgReceiver1`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `CompanyName` | `String` | Optional | The company name associated with the address. | String getCompanyName() | setCompanyName(String companyName) |
| `Street` | `String` | Optional | First line of the address. | String getStreet() | setStreet(String street) |
| `Locale` | `String` | Optional | Second line of the address. | String getLocale() | setLocale(String locale) |
| `Other` | `String` | Optional | Third line of the address. | String getOther() | setOther(String other) |
| `City` | `String` | Optional | City of the address. | String getCity() | setCity(String city) |
| `Region` | `String` | Optional | The state or region of the address. | String getRegion() | setRegion(String region) |
| `RegionName` | `String` | Optional | The name of the region associated with the address, this value will be automatically added if available. | String getRegionName() | setRegionName(String regionName) |
| `PostalCode` | `String` | Optional | The postal code or zip associated with the address. | String getPostalCode() | setPostalCode(String postalCode) |
| `Country` | `String` | Optional | The country code for the address. | String getCountry() | setCountry(String country) |
| `CountryName` | `String` | Optional | The name of the country associated with the address, this value will be automatically added if available. | String getCountryName() | setCountryName(String countryName) |
| `Residential` | `Boolean` | Optional | Indicates whether the address is residential or commercial.<br>**Default**: `false` | Boolean getResidential() | setResidential(Boolean residential) |
| `Phone` | `String` | Optional | The receiver's phone number. | String getPhone() | setPhone(String phone) |
| `DepartmentName` | `String` | Optional | Name of the department that the shipment is to be delivered to. Only used for special 'In-building' deliveries. | String getDepartmentName() | setDepartmentName(String departmentName) |

## Example (as XML)

```xml
<wtg:Receiver xmlns:wtg="https://www.wisetechglobal.com/" />
```

