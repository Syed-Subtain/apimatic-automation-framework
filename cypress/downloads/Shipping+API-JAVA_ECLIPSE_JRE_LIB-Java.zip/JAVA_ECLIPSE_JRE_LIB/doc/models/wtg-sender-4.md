
# Wtg Sender 4

Container to allow the customization of the sender address details associated with the transaction.

## Structure

`WtgSender4`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Name` | `String` | Required | The name of the sender. | String getName() | setName(String name) |
| `Account` | `String` | Optional | Account used to ship the shipment. | String getAccount() | setAccount(String account) |
| `Phone` | `String` | Optional | The phone number associated with the address. | String getPhone() | setPhone(String phone) |
| `Email` | `String` | Optional | An email address for the individual or company. | String getEmail() | setEmail(String email) |
| `MailStop` | `String` | Optional | Mail stop of the person the shipment is to be shipped from. | String getMailStop() | setMailStop(String mailStop) |
| `Building` | `String` | Optional | Building of the person the shipment is to be shipped from. | String getBuilding() | setBuilding(String building) |
| `Floor` | `String` | Optional | Floor of the person the shipment is to be shipped from. | String getFloor() | setFloor(String floor) |
| `Department` | `String` | Optional | Department of the person the shipment is to be shipped from. | String getDepartment() | setDepartment(String department) |
| `CompanyName` | `String` | Optional | The company name associated with the address. | String getCompanyName() | setCompanyName(String companyName) |
| `Street` | `String` | Optional | First line of the address. | String getStreet() | setStreet(String street) |
| `Locale` | `String` | Optional | Second line of the address. | String getLocale() | setLocale(String locale) |
| `Other` | `String` | Optional | Third line of the address. | String getOther() | setOther(String other) |
| `City` | `String` | Optional | City of the address. | String getCity() | setCity(String city) |
| `Region` | `String` | Optional | The state or region of the address. | String getRegion() | setRegion(String region) |
| `PostalCode` | `String` | Optional | The postal code or zip associated with the address. | String getPostalCode() | setPostalCode(String postalCode) |
| `Country` | `String` | Optional | The country code for the address. | String getCountry() | setCountry(String country) |

## Example (as XML)

```xml
<wtg:Sender xmlns:wtg="https://www.wisetechglobal.com/">
  <wtg:Name xmlns:wtg="https://www.wisetechglobal.com/">Name0</wtg:Name>
</wtg:Sender>
```

