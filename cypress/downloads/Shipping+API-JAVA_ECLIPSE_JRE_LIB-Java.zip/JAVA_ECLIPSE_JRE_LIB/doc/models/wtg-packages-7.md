
# Wtg Packages 7

Container for all packages associated with the transaction.

## Structure

`WtgPackages7`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Package` | [`List<WtgPackage8>`](../../doc/models/wtg-package-8.md) | Required | Container for an individual package associated with the transaction. | List<WtgPackage8> getPackage() | setPackage(List<WtgPackage8> mPackage) |

## Example (as XML)

```xml
<wtg:Packages xmlns:wtg="https://www.wisetechglobal.com/">
  <wtg:Package xmlns:wtg="https://www.wisetechglobal.com/">
    <wtg:Status>
      <wtg:Code>76</wtg:Code>
      <wtg:Warnings />
      <wtg:Errors />
    </wtg:Status>
    <wtg:International />
  </wtg:Package>
</wtg:Packages>
```

