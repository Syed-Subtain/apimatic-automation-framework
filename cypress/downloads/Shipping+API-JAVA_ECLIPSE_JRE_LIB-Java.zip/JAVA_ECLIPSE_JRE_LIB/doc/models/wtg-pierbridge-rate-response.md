
# Wtg Pierbridge Rate Response

Contains the charges associated with the shipment given in the Rate request.

## Structure

`WtgPierbridgeRateResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `TransactionIdentifier` | `String` | Optional | The unique identifier for the transaction given in the request. | String getTransactionIdentifier() | setTransactionIdentifier(String transactionIdentifier) |
| `ControlIdentifier` | `String` | Optional | The control reference for the transaction given in the request. | String getControlIdentifier() | setControlIdentifier(String controlIdentifier) |
| `Status` | [`WtgStatus`](../../doc/models/wtg-status.md) | Required | Container for transaction errors and warning elements. | WtgStatus getStatus() | setStatus(WtgStatus status) |
| `RecordIdentifiers` | [`WtgRecordIdentifiers`](../../doc/models/wtg-record-identifiers.md) | Optional | Outer container for transaction identifiers. | WtgRecordIdentifiers getRecordIdentifiers() | setRecordIdentifiers(WtgRecordIdentifiers recordIdentifiers) |
| `Carrier` | `Integer` | Optional | Numeric identifier for the carrier.<br>**Default**: `0` | Integer getCarrier() | setCarrier(Integer carrier) |
| `CarrierName` | `String` | Optional | The name for the carrier. | String getCarrierName() | setCarrierName(String carrierName) |
| `ServiceType` | `Integer` | Optional | Numeric identifier for the carrier service assocaited with the transaction.<br>**Default**: `0` | Integer getServiceType() | setServiceType(Integer serviceType) |
| `ServiceTypeName` | `String` | Optional | Description of the service used for the transaction. | String getServiceTypeName() | setServiceTypeName(String serviceTypeName) |
| `CarrierScac` | `String` | Optional | The NMFTA (National Motor Freight Traffic Association) Standard Carrier Alpha Code of the carrier. | String getCarrierScac() | setCarrierScac(String carrierScac) |
| `RateID` | `Integer` | Optional | Unique identifier for the rate.<br>**Default**: `0` | Integer getRateID() | setRateID(Integer rateID) |
| `DayOfWeek` | `String` | Optional | The description for the date of the shipment associated with the transaction. | String getDayOfWeek() | setDayOfWeek(String dayOfWeek) |
| `RequiredDate` | `String` | Optional | Date that the shipment is required to arrive at the receiver. | String getRequiredDate() | setRequiredDate(String requiredDate) |
| `Weight` | `Double` | Optional | Total weight of the shipment.<br>**Default**: `0d` | Double getWeight() | setWeight(Double weight) |
| `ServiceIsGuaranteed` | `Boolean` | Optional | Indicates if the carrier service has a guaranteed delivery window.<br>**Default**: `false` | Boolean getServiceIsGuaranteed() | setServiceIsGuaranteed(Boolean serviceIsGuaranteed) |
| `Localization` | [`WtgLocalization1`](../../doc/models/wtg-localization-1.md) | Optional | Container for localization information. | WtgLocalization1 getLocalization() | setLocalization(WtgLocalization1 localization) |
| `Shipping` | [`WtgShipping`](../../doc/models/wtg-shipping.md) | Optional | Container for shipping associated with the transaction. | WtgShipping getShipping() | setShipping(WtgShipping shipping) |
| `Customer` | [`WtgCustomer`](../../doc/models/wtg-customer.md) | Optional | Container for customer details. | WtgCustomer getCustomer() | setCustomer(WtgCustomer customer) |
| `CommitmentLevel` | `String` | Optional | Returned by the carrier indicating the expected delivery date and time. | String getCommitmentLevel() | setCommitmentLevel(String commitmentLevel) |
| `DeliverAfterTime` | `String` | Optional | Identifies a delivery window. | String getDeliverAfterTime() | setDeliverAfterTime(String deliverAfterTime) |
| `DeliveryIn` | `Integer` | Optional | Returned by the carrier indicating the number of days the shipment will take to reach its destination. | Integer getDeliveryIn() | setDeliveryIn(Integer deliveryIn) |
| `Zone` | `String` | Optional | The zone assosicated with the rate. | String getZone() | setZone(String zone) |
| `Receiver` | [`WtgReceiver1`](../../doc/models/wtg-receiver-1.md) | Optional | Container for the receiver address details associated with the transaction. | WtgReceiver1 getReceiver() | setReceiver(WtgReceiver1 receiver) |
| `Rates` | [`WtgRates`](../../doc/models/wtg-rates.md) | Optional | Container all rates associated with the transaction. | WtgRates getRates() | setRates(WtgRates rates) |
| `Packages` | [`WtgPackages3`](../../doc/models/wtg-packages-3.md) | Required | Container for all packages associated with the transaction. | WtgPackages3 getPackages() | setPackages(WtgPackages3 packages) |
| `Cartonization` | [`WtgCartonization2`](../../doc/models/wtg-cartonization-2.md) | Optional | Container for cartonization data for this transaction. | WtgCartonization2 getCartonization() | setCartonization(WtgCartonization2 cartonization) |
| `Processing` | [`WtgProcessing`](../../doc/models/wtg-processing.md) | Required | Container element for transaction processing statistics. | WtgProcessing getProcessing() | setProcessing(WtgProcessing processing) |

## Example (as XML)

```xml
<wtg:PierbridgeRateResponse xmlns:wtg="https://www.wisetechglobal.com/">
  <wtg:Status xmlns:wtg="https://www.wisetechglobal.com/">
    <wtg:Code>108</wtg:Code>
    <wtg:Warnings />
    <wtg:Errors />
  </wtg:Status>
  <wtg:RecordIdentifiers xmlns:wtg="https://www.wisetechglobal.com/" />
  <wtg:Localization xmlns:wtg="https://www.wisetechglobal.com/" />
  <wtg:Shipping xmlns:wtg="https://www.wisetechglobal.com/" />
  <wtg:Customer xmlns:wtg="https://www.wisetechglobal.com/" />
  <wtg:Receiver xmlns:wtg="https://www.wisetechglobal.com/" />
  <wtg:Rates xmlns:wtg="https://www.wisetechglobal.com/" />
  <wtg:Packages xmlns:wtg="https://www.wisetechglobal.com/">
    <wtg:Package>
      <wtg:Status>
        <wtg:Code>154</wtg:Code>
        <wtg:Warnings />
        <wtg:Errors />
      </wtg:Status>
      <wtg:RecordIdentifiers />
      <wtg:Shipping />
      <wtg:Customer />
      <wtg:International />
      <wtg:Rates />
    </wtg:Package>
    <wtg:Package>
      <wtg:Status>
        <wtg:Code>155</wtg:Code>
        <wtg:Warnings />
        <wtg:Errors />
      </wtg:Status>
      <wtg:RecordIdentifiers />
      <wtg:Shipping />
      <wtg:Customer />
      <wtg:International />
      <wtg:Rates />
    </wtg:Package>
    <wtg:Package>
      <wtg:Status>
        <wtg:Code>156</wtg:Code>
        <wtg:Warnings />
        <wtg:Errors />
      </wtg:Status>
      <wtg:RecordIdentifiers />
      <wtg:Shipping />
      <wtg:Customer />
      <wtg:International />
      <wtg:Rates />
    </wtg:Package>
  </wtg:Packages>
  <wtg:Cartonization xmlns:wtg="https://www.wisetechglobal.com/" />
  <wtg:Processing xmlns:wtg="https://www.wisetechglobal.com/">
    <wtg:StartTime>StartTime4</wtg:StartTime>
    <wtg:EndTime>EndTime0</wtg:EndTime>
    <wtg:Duration>252.24</wtg:Duration>
    <wtg:External />
    <wtg:ServerName>ServerName6</wtg:ServerName>
  </wtg:Processing>
</wtg:PierbridgeRateResponse>
```

