
# Wtg Contents

Container for all contents associated with the transaction.

## Structure

`WtgContents`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Content` | [`List<WtgContent>`](../../doc/models/wtg-content.md) | Required | Container for an individual content associated with the transaction. | List<WtgContent> getContent() | setContent(List<WtgContent> content) |

## Example (as XML)

```xml
<wtg:Contents xmlns:wtg="https://www.wisetechglobal.com/">
  <wtg:Content xmlns:wtg="https://www.wisetechglobal.com/">
    <wtg:ContentRefNumber>ContentRefNumber3</wtg:ContentRefNumber>
    <wtg:CenterOfMass />
  </wtg:Content>
</wtg:Contents>
```

