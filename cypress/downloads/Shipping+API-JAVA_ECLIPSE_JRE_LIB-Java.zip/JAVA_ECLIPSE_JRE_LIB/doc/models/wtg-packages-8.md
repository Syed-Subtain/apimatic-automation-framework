
# Wtg Packages 8

Container for all packages associated with the transaction.

## Structure

`WtgPackages8`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Package` | [`List<WtgPackage9>`](../../doc/models/wtg-package-9.md) | Required | Container for an individual package associated with the transaction. | List<WtgPackage9> getPackage() | setPackage(List<WtgPackage9> mPackage) |

## Example (as XML)

```xml
<wtg:Packages xmlns:wtg="https://www.wisetechglobal.com/">
  <wtg:Package xmlns:wtg="https://www.wisetechglobal.com/">
    <wtg:Status>
      <wtg:Code>76</wtg:Code>
      <wtg:Warnings />
      <wtg:Errors />
    </wtg:Status>
    <wtg:International />
  </wtg:Package>
</wtg:Packages>
```

