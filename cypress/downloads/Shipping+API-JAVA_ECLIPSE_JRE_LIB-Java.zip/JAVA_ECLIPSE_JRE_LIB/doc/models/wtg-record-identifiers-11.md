
# Wtg Record Identifiers 11

Outer container for transaction identifiers.

## Structure

`WtgRecordIdentifiers11`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `RecordIdentifier` | [`List<WtgRecordIdentifier8>`](../../doc/models/wtg-record-identifier-8.md) | Optional | Inner container for transaction identifiers. | List<WtgRecordIdentifier8> getRecordIdentifier() | setRecordIdentifier(List<WtgRecordIdentifier8> recordIdentifier) |

## Example (as XML)

```xml
<wtg:RecordIdentifiers xmlns:wtg="https://www.wisetechglobal.com/" />
```

