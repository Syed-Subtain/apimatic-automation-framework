
# Wtg Package 12

Container for an individual package associated with the transaction.

## Structure

`WtgPackage12`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Rates` | [`WtgRates9`](../../doc/models/wtg-rates-9.md) | Optional | Container all rates associated with the transaction. | WtgRates9 getRates() | setRates(WtgRates9 rates) |

## Example (as XML)

```xml
<wtg:Package xmlns:wtg="https://www.wisetechglobal.com/">
  <wtg:Rates xmlns:wtg="https://www.wisetechglobal.com/" />
</wtg:Package>
```

