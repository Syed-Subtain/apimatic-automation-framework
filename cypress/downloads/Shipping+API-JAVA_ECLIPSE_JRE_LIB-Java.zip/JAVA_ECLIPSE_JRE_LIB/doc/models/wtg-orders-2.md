
# Wtg Orders 2

Container all orders associated with the transaction.

## Structure

`WtgOrders2`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Order` | [`List<WtgOrder2>`](../../doc/models/wtg-order-2.md) | Optional | Container for an individual order. | List<WtgOrder2> getOrder() | setOrder(List<WtgOrder2> order) |

## Example (as XML)

```xml
<wtg:Orders xmlns:wtg="https://www.wisetechglobal.com/" />
```

