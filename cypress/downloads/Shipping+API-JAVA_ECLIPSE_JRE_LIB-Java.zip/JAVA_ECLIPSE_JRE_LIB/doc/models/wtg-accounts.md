
# Wtg Accounts

Container for accounts.

## Structure

`WtgAccounts`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Account` | `String` | Optional | Account number to list manifests for. | String getAccount() | setAccount(String account) |
| `AccountID` | `Integer` | Optional | Account identifier to list manifests for.<br>**Default**: `0` | Integer getAccountID() | setAccountID(Integer accountID) |

## Example (as XML)

```xml
<wtg:Accounts xmlns:wtg="https://www.wisetechglobal.com/" />
```

