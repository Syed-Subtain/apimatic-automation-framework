
# Wtg Record Identifiers 1

Outer container for transaction identifiers.

## Structure

`WtgRecordIdentifiers1`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `RecordIdentifier` | [`WtgRecordIdentifier`](../../doc/models/wtg-record-identifier.md) | Optional | Inner container for transaction identifiers. | WtgRecordIdentifier getRecordIdentifier() | setRecordIdentifier(WtgRecordIdentifier recordIdentifier) |

## Example (as XML)

```xml
<wtg:RecordIdentifiers xmlns:wtg="https://www.wisetechglobal.com/">
  <wtg:RecordIdentifier xmlns:wtg="https://www.wisetechglobal.com/" />
</wtg:RecordIdentifiers>
```

