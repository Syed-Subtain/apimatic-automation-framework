
# Wtg Hold Delivery Type Enum

## Enumeration

`WtgHoldDeliveryTypeEnum`

## Fields

| Name |
|  --- |
| `DeliverDirectToHoldLocation` |
| `AttemptCustomerDeliveryFirst` |

