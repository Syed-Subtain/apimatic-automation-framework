
# Wtg Package Template 2

Container for elements to be applied to each package created from the cartonization response .

## Structure

`WtgPackageTemplate2`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `RecordIdentifiers` | [`WtgRecordIdentifiers`](../../doc/models/wtg-record-identifiers.md) | Optional | Outer container for transaction identifiers. | WtgRecordIdentifiers getRecordIdentifiers() | setRecordIdentifiers(WtgRecordIdentifiers recordIdentifiers) |
| `ProactiveResponse` | `Boolean` | Optional | Indicates whether the package requires the Proactive Response special service.<br>**Default**: `false` | Boolean getProactiveResponse() | setProactiveResponse(Boolean proactiveResponse) |
| `SpecialCare` | [`WtgSpecialCare`](../../doc/models/wtg-special-care.md) | Optional | Outer container for special care details for package. | WtgSpecialCare getSpecialCare() | setSpecialCare(WtgSpecialCare specialCare) |
| `LithiumBattery` | `Boolean` | Optional | Indicates whether the shipment contains a lithium battery.  Defaults to no.<br>**Default**: `false` | Boolean getLithiumBattery() | setLithiumBattery(Boolean lithiumBattery) |
| `LithiumBatteryDetails` | [`WtgLithiumBatteryDetails`](../../doc/models/wtg-lithium-battery-details.md) | Optional | Outer container for Lithium Battery details for package. | WtgLithiumBatteryDetails getLithiumBatteryDetails() | setLithiumBatteryDetails(WtgLithiumBatteryDetails lithiumBatteryDetails) |
| `Copies` | `Integer` | Optional | Indicates the number of additional copies of the package that are to be shipped.  Defaults to zero additional copies if not submitted.<br>**Default**: `0` | Integer getCopies() | setCopies(Integer copies) |
| `PackageRequisitionID` | `Integer` | Optional | Package Requistion of the package to ship, use this element for better multi piece requisition handling.<br>**Default**: `0` | Integer getPackageRequisitionID() | setPackageRequisitionID(Integer packageRequisitionID) |
| `ExternalTrackingID` | `String` | Optional | Identifier associated with Third Party Tracking. | String getExternalTrackingID() | setExternalTrackingID(String externalTrackingID) |
| `PackItemID` | `Integer` | Optional | Unique numeric identifier for the pack item.<br>**Default**: `0` | Integer getPackItemID() | setPackItemID(Integer packItemID) |
| `PackageID` | `Integer` | Optional | Deprecated.  Do not use.<br>**Default**: `0` | Integer getPackageID() | setPackageID(Integer packageID) |
| `ShipperReference` | `String` | Optional | Primary reference number, which will be printed on the package's label. | String getShipperReference() | setShipperReference(String shipperReference) |
| `PackageReference` | `String` | Optional | Package reference number, which will be echoed back in the response. | String getPackageReference() | setPackageReference(String packageReference) |
| `ReferenceOne` | `String` | Optional | First additional reference number. | String getReferenceOne() | setReferenceOne(String referenceOne) |
| `ReferenceTwo` | `String` | Optional | Second additional reference number. | String getReferenceTwo() | setReferenceTwo(String referenceTwo) |
| `ReferenceThree` | `String` | Optional | Third additional reference number. | String getReferenceThree() | setReferenceThree(String referenceThree) |
| `ReferenceFour` | `String` | Optional | Fourth additional reference number. | String getReferenceFour() | setReferenceFour(String referenceFour) |
| `ReferenceFive` | `String` | Optional | Fifth additional reference number. | String getReferenceFive() | setReferenceFive(String referenceFive) |
| `ReferenceSix` | `String` | Optional | Sixth additional reference number. | String getReferenceSix() | setReferenceSix(String referenceSix) |
| `ReceiverName` | `String` | Optional | The name of for the receiver of the package. | String getReceiverName() | setReceiverName(String receiverName) |
| `ReceiverPhone` | `String` | Optional | The phone number for the receiver of the package. | String getReceiverPhone() | setReceiverPhone(String receiverPhone) |
| `ReceiverEmail` | `String` | Optional | The email address for the receiver of the package. | String getReceiverEmail() | setReceiverEmail(String receiverEmail) |
| `SenderName` | `String` | Optional | The name for the sender of the package. | String getSenderName() | setSenderName(String senderName) |
| `SenderPhone` | `String` | Optional | The phone number for the sender of the package. | String getSenderPhone() | setSenderPhone(String senderPhone) |
| `Cubic` | `Double` | Optional | Cubic feet or metres of the package.<br>**Default**: `0d` | Double getCubic() | setCubic(Double cubic) |
| `Linear` | `Double` | Optional | Linear feet or metres of the package.<br>**Default**: `0d` | Double getLinear() | setLinear(Double linear) |
| `ContentDescription` | `String` | Optional | Free form description of the package's content. | String getContentDescription() | setContentDescription(String contentDescription) |
| `WayBillNumber` | `String` | Optional | Tracking number to associate with the package. | String getWayBillNumber() | setWayBillNumber(String wayBillNumber) |
| `WayBillNumber2` | `String` | Optional | If appropriate the secondary tracking number of the package. | String getWayBillNumber2() | setWayBillNumber2(String wayBillNumber2) |
| `SecurityWayBillNumber` | `String` | Optional | Tracking number to associate with the package for chain of signature services. | String getSecurityWayBillNumber() | setSecurityWayBillNumber(String securityWayBillNumber) |
| `MailPieceNumber` | `String` | Optional | Mail piece number to associate with the package. Use in association with tracking number for postal services. | String getMailPieceNumber() | setMailPieceNumber(String mailPieceNumber) |
| `PriorityAlert` | `Boolean` | Optional | Indicates whether a priority alert is required for this package.  Defaults to no priority alert if not submitted.<br>**Default**: `false` | Boolean getPriorityAlert() | setPriorityAlert(Boolean priorityAlert) |
| `PriorityAlertPlus` | `Boolean` | Optional | Indicates whether a priority alert plus is required for this package.  Defaults to no priority alert plus if not submitted.<br>**Default**: `false` | Boolean getPriorityAlertPlus() | setPriorityAlertPlus(Boolean priorityAlertPlus) |
| `PriorityAlertContent` | `String` | Optional | Specifies any associated details for priority alert for this package.  Defaults to none. | String getPriorityAlertContent() | setPriorityAlertContent(String priorityAlertContent) |
| `InsideDelivery` | `Boolean` | Optional | Indicates use of FedEx service: Inside Delivery.<br>**Default**: `false` | Boolean getInsideDelivery() | setInsideDelivery(Boolean insideDelivery) |
| `Insurance` | [`WtgInsurance`](../../doc/models/wtg-insurance.md) | Optional | Container for insurance details. | WtgInsurance getInsurance() | setInsurance(WtgInsurance insurance) |
| `COD` | [`WtgCOD`](../../doc/models/wtg-cod.md) | Optional | Container for collect on delivery details. | WtgCOD getCOD() | setCOD(WtgCOD cOD) |
| `GuaranteedService` | `Integer` | Optional | Numeric identifer for the type of guaranteed service.  Defaults to no guaranteed service if not submitted.<br>**Default**: `0` | Integer getGuaranteedService() | setGuaranteedService(Integer guaranteedService) |
| `ECOD` | `Boolean` | Optional | Electronic COD indicator. Defaults to not ECOD.<br>**Default**: `false` | Boolean getECOD() | setECOD(Boolean eCOD) |
| `Hold` | `Boolean` | Optional | Indicates whether the package should be held for collection at a carrier's depot or some other location.<br>**Default**: `false` | Boolean getHold() | setHold(Boolean hold) |
| `Holder` | [`WtgHolder`](../../doc/models/wtg-holder.md) | Optional | Container for the holding location of the package. | WtgHolder getHolder() | setHolder(WtgHolder holder) |
| `HazardousPackaging` | `String` | Optional | Description of hazardous packaging. | String getHazardousPackaging() | setHazardousPackaging(String hazardousPackaging) |
| `HazardousPackageUnCode` | `String` | Optional | UN Code of hazardous packaging. | String getHazardousPackageUnCode() | setHazardousPackageUnCode(String hazardousPackageUnCode) |
| `HazardousPackagingQuantity` | `Integer` | Optional | Quantity of the outer packages.<br>**Default**: `0` | Integer getHazardousPackagingQuantity() | setHazardousPackagingQuantity(Integer hazardousPackagingQuantity) |
| `PackageNotes` | `String` | Optional | Package level notes. | String getPackageNotes() | setPackageNotes(String packageNotes) |
| `AdditionalHandling` | `Boolean` | Optional | Indicates that extra handling measures are required when loading the package.<br>**Default**: `false` | Boolean getAdditionalHandling() | setAdditionalHandling(Boolean additionalHandling) |
| `LargePackage` | `Boolean` | Optional | Indicates that package size exceeds carrier's normal limits.  Defaults to not large package if not submitted.<br>**Default**: `false` | Boolean getLargePackage() | setLargePackage(Boolean largePackage) |
| `DeliveryConfirmation` | `Integer` | Optional | Type of delivery confirmation required for the package.  Defaults to none if not submitted.<br>**Default**: `0` | Integer getDeliveryConfirmation() | setDeliveryConfirmation(Integer deliveryConfirmation) |
| `ContainerType` | `Integer` | Optional | Type of containerType required for the package.  Defaults to none if not submitted.<br>**Default**: `0` | Integer getContainerType() | setContainerType(Integer containerType) |
| `ExcessiveLengthType` | `Integer` | Optional | Type of excessive length required for the package.  Defaults to none if not submitted.<br>**Default**: `0` | Integer getExcessiveLengthType() | setExcessiveLengthType(Integer excessiveLengthType) |
| `VerbalConfirmation` | `Boolean` | Optional | Indicates verbal confirmation required. Defaults to no verbal confirmation.<br>**Default**: `false` | Boolean getVerbalConfirmation() | setVerbalConfirmation(Boolean verbalConfirmation) |
| `FreightClass` | `String` | Optional | The freight class of the package's content. | String getFreightClass() | setFreightClass(String freightClass) |
| `NMFC` | `String` | Optional | The National Motor Freight Classification of the package. | String getNMFC() | setNMFC(String nMFC) |
| `ItemsOnPallet` | `Integer` | Optional | Number of items on the pallet.<br>**Default**: `0` | Integer getItemsOnPallet() | setItemsOnPallet(Integer itemsOnPallet) |
| `NonStandardContainer` | `Boolean` | Optional | Indicates whether the package has non standard dimensions.  Defaults to standard dimensions if omitted.<br>**Default**: `false` | Boolean getNonStandardContainer() | setNonStandardContainer(Boolean nonStandardContainer) |
| `EmailNotification` | `Boolean` | Optional | Indicates whether an email notification should be sent to receiver's email address when package is shipped.  Defaults to not send email notification if omitted.<br>**Default**: `false` | Boolean getEmailNotification() | setEmailNotification(Boolean emailNotification) |
| `NonFlatMachinable` | `Boolean` | Optional | Indicates whether the package is non-flat and machinable.  Defaults to not non-flat and machinable if omitted.<br>**Default**: `false` | Boolean getNonFlatMachinable() | setNonFlatMachinable(Boolean nonFlatMachinable) |
| `NonMachinable` | `Boolean` | Optional | Indicates whether the package is non-machinable.  Defaults to machinable if omitted.<br>**Default**: `false` | Boolean getNonMachinable() | setNonMachinable(Boolean nonMachinable) |
| `NonRectangular` | `Boolean` | Optional | Indicates whether the package is non-rectangular.  Defaults to rectangular if omitted.<br>**Default**: `false` | Boolean getNonRectangular() | setNonRectangular(Boolean nonRectangular) |
| `Flat` | `Boolean` | Optional | Indicates whether the package is flat.  Defaults to not flat if omitted.<br>**Default**: `false` | Boolean getFlat() | setFlat(Boolean flat) |
| `Registered` | `Boolean` | Optional | Indicates whether the package is to be sent via registered mail.  Defaults to not registered if omitted.<br>**Default**: `false` | Boolean getRegistered() | setRegistered(Boolean registered) |
| `RestrictedDelivery` | `Boolean` | Optional | Indicates whether the package is to be sent using restricted delivery.  Defaults to not restricted if omitted.<br>**Default**: `false` | Boolean getRestrictedDelivery() | setRestrictedDelivery(Boolean restrictedDelivery) |
| `ReturnReceipt` | `Boolean` | Optional | Indicates whether a return receipt should be provided back to the shipper for this package.<br>**Default**: `false` | Boolean getReturnReceipt() | setReturnReceipt(Boolean returnReceipt) |
| `Certified` | `Boolean` | Optional | Indicates whether the package is to be sent via certified mail.  Defaults to not certified if omitted.<br>**Default**: `false` | Boolean getCertified() | setCertified(Boolean certified) |
| `DryIceWeight` | `Double` | Optional | Weight of dry ice in the package.<br>**Default**: `0d` | Double getDryIceWeight() | setDryIceWeight(Double dryIceWeight) |
| `DryIceWeightUOM` | `String` | Optional | Weight units of measure for the dry ice in the package. | String getDryIceWeightUOM() | setDryIceWeightUOM(String dryIceWeightUOM) |
| `LooseDryIce` | `Boolean` | Optional | Indicates overpacked or all-in-one hazardous package has loose dry ice<br>**Default**: `false` | Boolean getLooseDryIce() | setLooseDryIce(Boolean looseDryIce) |
| `ERR` | `Boolean` | Optional | Indicates that Electronic Return Receipt is required.<br>**Default**: `false` | Boolean getERR() | setERR(Boolean eRR) |
| `ReturnReceiptMerchandise` | `Boolean` | Optional | Indicates that Return Receipt Merchandise is required.<br>**Default**: `false` | Boolean getReturnReceiptMerchandise() | setReturnReceiptMerchandise(Boolean returnReceiptMerchandise) |
| `ElectronicCertified` | `Boolean` | Optional | Indicates that Electronic Certified Mail service is required.<br>**Default**: `false` | Boolean getElectronicCertified() | setElectronicCertified(Boolean electronicCertified) |
| `UniqueIdentifier` | `String` | Optional | Unique Identifier for a package. | String getUniqueIdentifier() | setUniqueIdentifier(String uniqueIdentifier) |
| `Exchange` | `Boolean` | Optional | Indicates whether the parcel is a consignment swap parcel. Default value is false.<br>**Default**: `false` | Boolean getExchange() | setExchange(Boolean exchange) |
| `AdmissibilityPackagingType` | `String` | Optional | Specific FedEx Ground non-standard container type used for domestic and cross border shipments. | String getAdmissibilityPackagingType() | setAdmissibilityPackagingType(String admissibilityPackagingType) |
| `Rates` | [`WtgRates4`](../../doc/models/wtg-rates-4.md) | Optional | Container all rates associated with the transaction. | WtgRates4 getRates() | setRates(WtgRates4 rates) |

## Example (as XML)

```xml
<wtg:PackageTemplate xmlns:wtg="https://www.wisetechglobal.com/">
  <wtg:RecordIdentifiers xmlns:wtg="https://www.wisetechglobal.com/" />
  <wtg:SpecialCare xmlns:wtg="https://www.wisetechglobal.com/" />
  <wtg:LithiumBatteryDetails xmlns:wtg="https://www.wisetechglobal.com/" />
  <wtg:Insurance xmlns:wtg="https://www.wisetechglobal.com/" />
  <wtg:COD xmlns:wtg="https://www.wisetechglobal.com/" />
  <wtg:Holder xmlns:wtg="https://www.wisetechglobal.com/" />
  <wtg:Rates xmlns:wtg="https://www.wisetechglobal.com/" />
</wtg:PackageTemplate>
```

