
# Wtg International 17

Container for international details associated with the shipment.

## Structure

`WtgInternational17`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `DocumentsOnly` | `Boolean` | Optional | Indicates if the item only contained documents.<br>**Default**: `false` | Boolean getDocumentsOnly() | setDocumentsOnly(Boolean documentsOnly) |
| `Contents` | [`WtgContents15`](../../doc/models/wtg-contents-15.md) | Optional | Container for all contents (line items) associated with the transaction. | WtgContents15 getContents() | setContents(WtgContents15 contents) |

## Example (as XML)

```xml
<wtg:International xmlns:wtg="https://www.wisetechglobal.com/">
  <wtg:Contents xmlns:wtg="https://www.wisetechglobal.com/" />
</wtg:International>
```

