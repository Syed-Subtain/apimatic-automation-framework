
# Wtg Record Identifier 8

Inner container for transaction identifiers.

## Structure

`WtgRecordIdentifier8`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `RecordIdentifierID` | `Integer` | Optional | The unique numeric identifier for the Key1 through Key6 record.<br>**Default**: `0` | Integer getRecordIdentifierID() | setRecordIdentifierID(Integer recordIdentifierID) |
| `Keys` | [`WtgKeys`](../../doc/models/wtg-keys.md) | Optional | Container for transaction identifiers to be stored. | WtgKeys getKeys() | setKeys(WtgKeys keys) |

## Example (as XML)

```xml
<wtg:RecordIdentifier xmlns:wtg="https://www.wisetechglobal.com/">
  <wtg:Keys xmlns:wtg="https://www.wisetechglobal.com/" />
</wtg:RecordIdentifier>
```

