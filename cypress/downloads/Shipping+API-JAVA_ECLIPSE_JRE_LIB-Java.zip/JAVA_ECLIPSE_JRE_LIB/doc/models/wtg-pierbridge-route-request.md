
# Wtg Pierbridge Route Request

Calculates the best carrier and service combination for a shipment.

## Structure

`WtgPierbridgeRouteRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `TransactionIdentifier` | `String` | Optional | A unique identifier for the transaction, this value is not used during processing and will be returned in the response. | String getTransactionIdentifier() | setTransactionIdentifier(String transactionIdentifier) |
| `ControlIdentifier` | `String` | Optional | A reference to a control which generated the request, this value is not used during processing and will be returned in the response. | String getControlIdentifier() | setControlIdentifier(String controlIdentifier) |
| `UserName` | `String` | Required | The user name to use when processing the transaction.<br>**Constraints**: *Minimum Length*: `1` | String getUserName() | setUserName(String userName) |
| `ShipDate` | `String` | Optional | Date the items are to be shipped. Defaults to current date if not submitted. | String getShipDate() | setShipDate(String shipDate) |
| `ShipTime` | `String` | Optional | Time that the items are to be shipped.  Defaults to current time if not submitted. | String getShipTime() | setShipTime(String shipTime) |
| `Weight` | `double` | Required | Weight of the items to be shipped. | double getWeight() | setWeight(double weight) |
| `PackageCount` | `Integer` | Optional | Number of items to be shipped.  Defaults to one if not submitted.<br>**Default**: `0` | Integer getPackageCount() | setPackageCount(Integer packageCount) |
| `DeclaredValue` | `Double` | Optional | Monetary value of the items to be shipped.  Default to zero if not submitted.<br>**Default**: `0d` | Double getDeclaredValue() | setDeclaredValue(Double declaredValue) |
| `Parameter1` | `String` | Optional | Extra parameter that identifies the items to be shipped. | String getParameter1() | setParameter1(String parameter1) |
| `Parameter2` | `String` | Optional | Extra parameter that identifies the items to be shipped. | String getParameter2() | setParameter2(String parameter2) |
| `Parameter3` | `String` | Optional | Extra parameter that identifies the items to be shipped. | String getParameter3() | setParameter3(String parameter3) |
| `CustomerIdentifier` | `String` | Optional | Identifier of the customer the items are to be shipped to. | String getCustomerIdentifier() | setCustomerIdentifier(String customerIdentifier) |
| `Destination` | `String` | Optional | Destination of the items to be shipped. | String getDestination() | setDestination(String destination) |
| `Diagnostics` | [`WtgDiagnostics`](../../doc/models/wtg-diagnostics.md) | Optional | Container for logging and diagnostic override elements. | WtgDiagnostics getDiagnostics() | setDiagnostics(WtgDiagnostics diagnostics) |
| `Identification` | [`WtgIdentification`](../../doc/models/wtg-identification.md) | Optional | Container for client identification elements. | WtgIdentification getIdentification() | setIdentification(WtgIdentification identification) |

## Example (as XML)

```xml
<wtg:PierbridgeRouteRequest xmlns:wtg="https://www.wisetechglobal.com/">
  <wtg:UserName xmlns:wtg="https://www.wisetechglobal.com/">UserName6</wtg:UserName>
  <wtg:Weight xmlns:wtg="https://www.wisetechglobal.com/">115.44</wtg:Weight>
  <wtg:Diagnostics xmlns:wtg="https://www.wisetechglobal.com/" />
  <wtg:Identification xmlns:wtg="https://www.wisetechglobal.com/" />
</wtg:PierbridgeRouteRequest>
```

