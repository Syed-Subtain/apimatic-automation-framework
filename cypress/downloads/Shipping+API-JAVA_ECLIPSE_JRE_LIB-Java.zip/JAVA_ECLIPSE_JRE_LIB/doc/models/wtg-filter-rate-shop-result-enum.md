
# Wtg Filter Rate Shop Result Enum

## Enumeration

`WtgFilterRateShopResultEnum`

## Fields

| Name |
|  --- |
| `SuccessOnly` |
| `SuccessAndPartialSuccess` |
| `All` |

