
# Wtg Out for Delivery Notification Detail

Container for out for delivery email notification.

## Structure

`WtgOutForDeliveryNotificationDetail`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `NotificationDeliveryMethod` | [`WtgNotificationDeliveryMethodEnum`](../../doc/models/wtg-notification-delivery-method-enum.md) | Optional | The method by which the notification will be sent. If it is not provided it is default to e-mail. | WtgNotificationDeliveryMethodEnum getNotificationDeliveryMethod() | setNotificationDeliveryMethod(WtgNotificationDeliveryMethodEnum notificationDeliveryMethod) |
| `Addresses` | `String` | Optional | Any email addresses / phone numbers that need to be sent to the carrier for the notifcations or key words RECEIVER / SENDER to pick the E-Mail / phone number from the data that is already entered. | String getAddresses() | setAddresses(String addresses) |

## Example (as XML)

```xml
<wtg:OutForDeliveryNotificationDetail xmlns:wtg="https://www.wisetechglobal.com/" />
```

