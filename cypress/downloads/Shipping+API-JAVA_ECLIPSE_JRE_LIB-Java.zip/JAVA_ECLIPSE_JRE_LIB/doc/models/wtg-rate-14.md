
# Wtg Rate 14

Container for an individual rate associated with the package

## Structure

`WtgRate14`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `RateType` | `Integer` | Optional | A numeric identifier that identifies the rate type.<br>**Default**: `0` | Integer getRateType() | setRateType(Integer rateType) |
| `Charges` | [`WtgCharges13`](../../doc/models/wtg-charges-13.md) | Required | Container for all charges within the group associated with the package | WtgCharges13 getCharges() | setCharges(WtgCharges13 charges) |

## Example (as XML)

```xml
<wtg:Rate xmlns:wtg="https://www.wisetechglobal.com/">
  <wtg:Charges xmlns:wtg="https://www.wisetechglobal.com/" />
</wtg:Rate>
```

