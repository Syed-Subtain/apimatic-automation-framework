
# Wtg Charges 11

Container for all charges within the group associated with the transaction.

## Structure

`WtgCharges11`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Charge` | [`List<WtgCharge11>`](../../doc/models/wtg-charge-11.md) | Optional | Container for an individual charge within the group associated with the transaction. | List<WtgCharge11> getCharge() | setCharge(List<WtgCharge11> charge) |

## Example (as XML)

```xml
<wtg:Charges xmlns:wtg="https://www.wisetechglobal.com/" />
```

