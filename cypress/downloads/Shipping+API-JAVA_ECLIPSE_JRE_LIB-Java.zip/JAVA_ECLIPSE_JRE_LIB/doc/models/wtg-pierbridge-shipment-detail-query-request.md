
# Wtg Pierbridge Shipment Detail Query Request

Searches for shipments that match a specified criteria.

## Structure

`WtgPierbridgeShipmentDetailQueryRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `TransactionIdentifier` | `String` | Optional | A unique identifier for the transaction, this value is not used during processing and will be returned in the response. | String getTransactionIdentifier() | setTransactionIdentifier(String transactionIdentifier) |
| `ControlIdentifier` | `String` | Optional | A reference to a control which generated the request, this value is not used during processing and will be returned in the response. | String getControlIdentifier() | setControlIdentifier(String controlIdentifier) |
| `UserName` | `String` | Required | The user name to use when processing the transaction.<br>**Constraints**: *Minimum Length*: `1` | String getUserName() | setUserName(String userName) |
| `PageSize` | `int` | Required | The maximum number of records to return in the response.<br>**Constraints**: `<= 1000` | int getPageSize() | setPageSize(int pageSize) |
| `PageNumber` | `int` | Required | The page number of data to return in the response. | int getPageNumber() | setPageNumber(int pageNumber) |
| `IncludeDefaultRates` | `Boolean` | Optional | Specifies whether to return negotiated rates in the response. | Boolean getIncludeDefaultRates() | setIncludeDefaultRates(Boolean includeDefaultRates) |
| `IncludeListRates` | `Boolean` | Optional | Specifies whether to reture list rates in the response. | Boolean getIncludeListRates() | setIncludeListRates(Boolean includeListRates) |
| `IncludeCustomRates` | `Boolean` | Optional | Specifies whether to reture custom rates in the response. | Boolean getIncludeCustomRates() | setIncludeCustomRates(Boolean includeCustomRates) |
| `SearchByField` | [`WtgSearchByFieldEnum`](../../doc/models/wtg-search-by-field-enum.md) | Required | The field to search records by. | WtgSearchByFieldEnum getSearchByField() | setSearchByField(WtgSearchByFieldEnum searchByField) |
| `SearchByValue` | `String` | Required | Specifies the value that the SearchByField will be matched against. | String getSearchByValue() | setSearchByValue(String searchByValue) |
| `Diagnostics` | [`WtgDiagnostics`](../../doc/models/wtg-diagnostics.md) | Optional | Container for logging and diagnostic override elements. | WtgDiagnostics getDiagnostics() | setDiagnostics(WtgDiagnostics diagnostics) |
| `Identification` | [`WtgIdentification`](../../doc/models/wtg-identification.md) | Optional | Container for client identification elements. | WtgIdentification getIdentification() | setIdentification(WtgIdentification identification) |

## Example (as XML)

```xml
<wtg:PierbridgeShipmentDetailQueryRequest xmlns:wtg="https://www.wisetechglobal.com/">
  <wtg:UserName xmlns:wtg="https://www.wisetechglobal.com/">UserName6</wtg:UserName>
  <wtg:PageSize xmlns:wtg="https://www.wisetechglobal.com/">30</wtg:PageSize>
  <wtg:PageNumber xmlns:wtg="https://www.wisetechglobal.com/">160</wtg:PageNumber>
  <wtg:SearchByField xmlns:wtg="https://www.wisetechglobal.com/">OrderNumber</wtg:SearchByField>
  <wtg:SearchByValue xmlns:wtg="https://www.wisetechglobal.com/">SearchByValue6</wtg:SearchByValue>
  <wtg:Diagnostics xmlns:wtg="https://www.wisetechglobal.com/" />
  <wtg:Identification xmlns:wtg="https://www.wisetechglobal.com/" />
</wtg:PierbridgeShipmentDetailQueryRequest>
```

