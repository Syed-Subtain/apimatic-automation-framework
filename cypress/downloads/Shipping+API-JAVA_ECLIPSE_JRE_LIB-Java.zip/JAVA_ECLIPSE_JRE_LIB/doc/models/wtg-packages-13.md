
# Wtg Packages 13

Container for all packages associated with the transaction.

## Structure

`WtgPackages13`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Package` | [`List<WtgPackage14>`](../../doc/models/wtg-package-14.md) | Required | Container for an individual package associated with the transaction. | List<WtgPackage14> getPackage() | setPackage(List<WtgPackage14> mPackage) |

## Example (as XML)

```xml
<wtg:Packages xmlns:wtg="https://www.wisetechglobal.com/" />
```

