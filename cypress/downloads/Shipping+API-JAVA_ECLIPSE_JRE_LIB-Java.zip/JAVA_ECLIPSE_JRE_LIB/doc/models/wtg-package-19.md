
# Wtg Package 19

Container for an individual package associated with the transaction.

## Structure

`WtgPackage19`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `PackageID` | `Integer` | Optional | Unique identifier for the package.<br>**Default**: `0` | Integer getPackageID() | setPackageID(Integer packageID) |
| `Weight` | `Double` | Optional | The weight of the package.<br>**Default**: `0d` | Double getWeight() | setWeight(Double weight) |
| `ContentDescription` | `String` | Optional | Free form description of the package's content. | String getContentDescription() | setContentDescription(String contentDescription) |
| `Pieces` | `String` | Optional | The number of pieces that make up the package. | String getPieces() | setPieces(String pieces) |
| `NMFC` | `String` | Optional | The National Motor Freight Classification of the package. | String getNMFC() | setNMFC(String nMFC) |
| `PackageType` | `String` | Optional | Numeric identifier for the carrier package type. | String getPackageType() | setPackageType(String packageType) |
| `WayBillNumber` | `String` | Optional | WayBill Number for the package. | String getWayBillNumber() | setWayBillNumber(String wayBillNumber) |
| `TrackingUrl` | `String` | Optional | Tracking URL for the package. | String getTrackingUrl() | setTrackingUrl(String trackingUrl) |

## Example (as XML)

```xml
<wtg:Package xmlns:wtg="https://www.wisetechglobal.com/" />
```

