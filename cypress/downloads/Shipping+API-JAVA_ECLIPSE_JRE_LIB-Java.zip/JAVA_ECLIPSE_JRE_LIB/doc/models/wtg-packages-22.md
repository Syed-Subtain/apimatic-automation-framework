
# Wtg Packages 22

Container for all packages associated with the transaction.

## Structure

`WtgPackages22`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Package` | [`List<WtgPackage23>`](../../doc/models/wtg-package-23.md) | Required | Container for an individual package associated with the transaction. | List<WtgPackage23> getPackage() | setPackage(List<WtgPackage23> mPackage) |

## Example (as XML)

```xml
<wtg:Packages xmlns:wtg="https://www.wisetechglobal.com/">
  <wtg:Package xmlns:wtg="https://www.wisetechglobal.com/">
    <wtg:Status>
      <wtg:Code>76</wtg:Code>
      <wtg:Description>Description4</wtg:Description>
      <wtg:Warnings />
      <wtg:Errors />
    </wtg:Status>
    <wtg:History />
  </wtg:Package>
</wtg:Packages>
```

