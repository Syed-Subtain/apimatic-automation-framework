
# Wtg Freight 2

Container for freight specific values

## Structure

`WtgFreight2`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Billing` | [`WtgBilling7`](../../doc/models/wtg-billing-7.md) | Optional | Container for freight billing details associated with the transaction. | WtgBilling7 getBilling() | setBilling(WtgBilling7 billing) |
| `CollectTermsType` | [`WtgCollectTermsTypeEnum`](../../doc/models/wtg-collect-terms-type-enum.md) | Optional | Parameter used to set collect terms type | WtgCollectTermsTypeEnum getCollectTermsType() | setCollectTermsType(WtgCollectTermsTypeEnum collectTermsType) |
| `LiabilityCoverageDetail` | `Double` | Optional | Identifies the Liability Coverage Amount per pound | Double getLiabilityCoverageDetail() | setLiabilityCoverageDetail(Double liabilityCoverageDetail) |
| `LiabilityCoverageType` | [`WtgLiabilityCoverageTypeEnum`](../../doc/models/wtg-liability-coverage-type-enum.md) | Optional | Parameter used to set liability coverage type | WtgLiabilityCoverageTypeEnum getLiabilityCoverageType() | setLiabilityCoverageType(WtgLiabilityCoverageTypeEnum liabilityCoverageType) |
| `PurposeOfShipment` | [`WtgPurposeOfShipmentEnum`](../../doc/models/wtg-purpose-of-shipment-enum.md) | Optional | Parameter used to set nature of shipment | WtgPurposeOfShipmentEnum getPurposeOfShipment() | setPurposeOfShipment(WtgPurposeOfShipmentEnum purposeOfShipment) |
| `ClientDiscountPercent` | `Double` | Optional | Estimated discount rate provided by client for unsecured rate quote. | Double getClientDiscountPercent() | setClientDiscountPercent(Double clientDiscountPercent) |
| `FreightCharge` | `Double` | Optional | Identifies the customer charge to assign to the freight shipment | Double getFreightCharge() | setFreightCharge(Double freightCharge) |
| `MiscellaneousCharges` | `Double` | Optional | Identifies an additional tax or miscellaneous charge the customer can assign to the freight shipment | Double getMiscellaneousCharges() | setMiscellaneousCharges(Double miscellaneousCharges) |
| `Comments` | `String` | Optional | Customer assigned comments for a freight shipment. | String getComments() | setComments(String comments) |

## Example (as XML)

```xml
<wtg:Freight xmlns:wtg="https://www.wisetechglobal.com/">
  <wtg:Billing xmlns:wtg="https://www.wisetechglobal.com/" />
</wtg:Freight>
```

