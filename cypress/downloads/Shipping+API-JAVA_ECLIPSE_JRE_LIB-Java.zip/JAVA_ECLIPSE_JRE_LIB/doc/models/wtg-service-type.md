
# Wtg Service Type

Container element for the carrier service.

## Structure

`WtgServiceType`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `ID` | `Integer` | Optional | Numeric identifier for the carrier service. | Integer getID() | setID(Integer iD) |
| `Description` | `String` | Optional | The name for the carrier service. | String getDescription() | setDescription(String description) |
| `IsGuaranteed` | `Boolean` | Optional | Indicates if the carrier service has a guaranteed delivery window.<br>**Default**: `false` | Boolean getIsGuaranteed() | setIsGuaranteed(Boolean isGuaranteed) |

## Example (as XML)

```xml
<wtg:ServiceType xmlns:wtg="https://www.wisetechglobal.com/" />
```

