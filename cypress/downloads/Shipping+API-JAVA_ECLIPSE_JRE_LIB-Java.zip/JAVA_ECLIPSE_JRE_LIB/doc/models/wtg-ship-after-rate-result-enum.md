
# Wtg Ship After Rate Result Enum

## Enumeration

`WtgShipAfterRateResultEnum`

## Fields

| Name |
|  --- |
| `SuccessOnly` |
| `SuccessAndPartialSuccess` |
| `All` |

