
# Wtg Charge 7

Container for an individual charge within the group associated with the transaction.

## Structure

`WtgCharge7`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `ChargeType` | `Integer` | Optional | An identifier for the type of the charge.<br>**Default**: `0` | Integer getChargeType() | setChargeType(Integer chargeType) |
| `ChargeDescription` | `String` | Optional | The description for the type of charge. | String getChargeDescription() | setChargeDescription(String chargeDescription) |
| `ChargeValue` | `Double` | Optional | The value of the charge associated with the transaction.<br>**Default**: `0d` | Double getChargeValue() | setChargeValue(Double chargeValue) |
| `ChargeCurrency` | `String` | Optional | A code indicating the type of currency for the charge. | String getChargeCurrency() | setChargeCurrency(String chargeCurrency) |
| `ChargeISOCurrency` | `Integer` | Optional | International standard code for the charge group currency.<br>**Default**: `0` | Integer getChargeISOCurrency() | setChargeISOCurrency(Integer chargeISOCurrency) |
| `ChargeExternalSystemCode` | `Integer` | Optional | A code to map to an external system.<br>**Default**: `0` | Integer getChargeExternalSystemCode() | setChargeExternalSystemCode(Integer chargeExternalSystemCode) |

## Example (as XML)

```xml
<wtg:Charge xmlns:wtg="https://www.wisetechglobal.com/" />
```

