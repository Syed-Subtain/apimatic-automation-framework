
# Wtg Pierbridge Ship Requisition Request

Adds a new shipment requisition record to the database.

## Structure

`WtgPierbridgeShipRequisitionRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `MeterSerialNumber` | `String` | Optional | Unique serial number for the meter to add. | String getMeterSerialNumber() | setMeterSerialNumber(String meterSerialNumber) |
| `Outputs` | [`WtgOutputs2`](../../doc/models/wtg-outputs-2.md) | Optional | Container for outputs the transaction should generate or customize the printing of. | WtgOutputs2 getOutputs() | setOutputs(WtgOutputs2 outputs) |
| `ControlIdentifier` | `String` | Optional | A reference to a control which generated the request, this value is not used during processing and will be returned in the response. | String getControlIdentifier() | setControlIdentifier(String controlIdentifier) |
| `TransactionIdentifier` | `String` | Optional | A unique identifier for the transaction, this value is not used during processing and will be returned in the response. | String getTransactionIdentifier() | setTransactionIdentifier(String transactionIdentifier) |
| `UserName` | `String` | Required | The user name to use when processing the transaction. | String getUserName() | setUserName(String userName) |
| `ShipForUserName` | `String` | Optional | The name of the user the shipment is being processed on behalf of. | String getShipForUserName() | setShipForUserName(String shipForUserName) |
| `AccountCode` | `String` | Optional | A freeform account code associated with the requisition. | String getAccountCode() | setAccountCode(String accountCode) |
| `CompanyCode` | `String` | Optional | A freeform company code associated with the requisition. | String getCompanyCode() | setCompanyCode(String companyCode) |
| `ShipmentRequisitionID` | `Integer` | Optional | Used to edit an existing requisition identifier.<br>**Default**: `0` | Integer getShipmentRequisitionID() | setShipmentRequisitionID(Integer shipmentRequisitionID) |
| `HistoryStateID` | `Integer` | Optional | Sets an existing requisition to the given history state.  If sumitted only the history state field is updated.<br>**Default**: `0` | Integer getHistoryStateID() | setHistoryStateID(Integer historyStateID) |
| `CustomStorageData` | `String` | Optional | Custom data that is to be stored with the requisition, this data can be retrieved through the API interface only. | String getCustomStorageData() | setCustomStorageData(String customStorageData) |
| `ShippingInstructions` | `String` | Optional | Instructions that will be printed on the ship requisition form. | String getShippingInstructions() | setShippingInstructions(String shippingInstructions) |
| `DeliveryDateStart` | `String` | Optional | Earliest date that the shipment is required to arrive at the receiver. | String getDeliveryDateStart() | setDeliveryDateStart(String deliveryDateStart) |
| `DeliveryDateEnd` | `String` | Optional | Latest date that the shipment is required to arrive at the receiver. | String getDeliveryDateEnd() | setDeliveryDateEnd(String deliveryDateEnd) |
| `Carrier` | `Integer` | Optional | Numeric identifier for the carrier.<br>**Default**: `0` | Integer getCarrier() | setCarrier(Integer carrier) |
| `ServiceType` | `Integer` | Optional | Carrier service (e.g. Next Day, Ground, Express) to ship with.<br>**Default**: `0` | Integer getServiceType() | setServiceType(Integer serviceType) |
| `CostCenterMode` | [`WtgCostCenterModeEnum`](../../doc/models/wtg-cost-center-mode-enum.md) | Optional | Indicates how cost centers are handled whilst processing the transaction. | WtgCostCenterModeEnum getCostCenterMode() | setCostCenterMode(WtgCostCenterModeEnum costCenterMode) |
| `CostCenterID` | `Integer` | Optional | Identifier of the cost center, should pass either this element or the Cost Center Code.<br>**Default**: `0` | Integer getCostCenterID() | setCostCenterID(Integer costCenterID) |
| `CostCenterCode` | `String` | Optional | Name of the cost center, should pass either this element or the Cost Center ID. | String getCostCenterCode() | setCostCenterCode(String costCenterCode) |
| `SaturdayDelivery` | `Boolean` | Optional | Indicates whether the shipment is intended for delivery on a Saturday.  Defaults to non-Saturday delivery if not submitted.<br>**Default**: `false` | Boolean getSaturdayDelivery() | setSaturdayDelivery(Boolean saturdayDelivery) |
| `SaturdayPickup` | `Boolean` | Optional | Indicates whether the shipment is intended for pickup on a Saturday.  Defaults to non-Saturday pickup if not submitted.<br>**Default**: `false` | Boolean getSaturdayPickup() | setSaturdayPickup(Boolean saturdayPickup) |
| `SundayPickup` | `Boolean` | Optional | Indicates whether the shipment is intended for pickup on a Sunday.  Defaults to non-Sunday pickup if not submitted.<br>**Default**: `false` | Boolean getSundayPickup() | setSundayPickup(Boolean sundayPickup) |
| `Unpack` | `Boolean` | Optional | Indicates whether the shipment requires an unpack delivery fee.<br>**Default**: `false` | Boolean getUnpack() | setUnpack(Boolean unpack) |
| `HealthInsurance` | `Boolean` | Optional | Indicates whether the shipment requires the package requires a Health Insurance fee.<br>**Default**: `false` | Boolean getHealthInsurance() | setHealthInsurance(Boolean healthInsurance) |
| `SpecialDelivery` | `Boolean` | Optional | Indicates whether the shipment requires a special delivery fee.<br>**Default**: `false` | Boolean getSpecialDelivery() | setSpecialDelivery(Boolean specialDelivery) |
| `ForkliftDelivery` | `Boolean` | Optional | Indicates whether the shipment requires a forklift delivery fee.<br>**Default**: `false` | Boolean getForkliftDelivery() | setForkliftDelivery(Boolean forkliftDelivery) |
| `InsidePickup` | `Boolean` | Optional | Indicates whether the shipment is to be picked up inside.  Defaults to not inside pickup if omitted.<br>**Default**: `false` | Boolean getInsidePickup() | setInsidePickup(Boolean insidePickup) |
| `InsideDelivery` | `Boolean` | Optional | Indicates whether the shipment is to be delivered inside.  Defaults to not inside delivery if omitted.<br>**Default**: `false` | Boolean getInsideDelivery() | setInsideDelivery(Boolean insideDelivery) |
| `ConstructionSitePickup` | `Boolean` | Optional | Indicates whether the address to be picked up from to is a construction site. Defaults to 'not a construction site' if not submitted.<br>**Default**: `false` | Boolean getConstructionSitePickup() | setConstructionSitePickup(Boolean constructionSitePickup) |
| `ConstructionSiteDelivery` | `Boolean` | Optional | Indicates whether the address to be delivered to is a construction site. Defaults to 'not a construction site' if not submitted.<br>**Default**: `false` | Boolean getConstructionSiteDelivery() | setConstructionSiteDelivery(Boolean constructionSiteDelivery) |
| `TradeShowPickup` | `Boolean` | Optional | Indicates whether the address to be picked up from to is a trade show. Defaults to 'not a trade show' if not submitted.<br>**Default**: `false` | Boolean getTradeShowPickup() | setTradeShowPickup(Boolean tradeShowPickup) |
| `TradeShowDelivery` | `Boolean` | Optional | Indicates whether the address to be delivered to is a trade show. Defaults to 'not a trade show' if not submitted.<br>**Default**: `false` | Boolean getTradeShowDelivery() | setTradeShowDelivery(Boolean tradeShowDelivery) |
| `LiftGateDelivery` | `Boolean` | Optional | Indicates whether the address to be delivered to requires a lift gate.  Defaults to no lift gate required if not submitted.<br>**Default**: `false` | Boolean getLiftGateDelivery() | setLiftGateDelivery(Boolean liftGateDelivery) |
| `LiftGatePickup` | `Boolean` | Optional | Indicates whether the address to be picked up from requires a lift gate.  Defaults to no lift gate required if not submitted.<br>**Default**: `false` | Boolean getLiftGatePickup() | setLiftGatePickup(Boolean liftGatePickup) |
| `AppointmentDelivery` | `Boolean` | Optional | Indicates whether an appointment must be made prior to delivery.  Defaults to no appointment needed if not submitted.<br>**Default**: `false` | Boolean getAppointmentDelivery() | setAppointmentDelivery(Boolean appointmentDelivery) |
| `AppointmentPickup` | `Boolean` | Optional | Indicates whether an appointment must be made prior to pick up.  Defaults to no appointment needed if not submitted.<br>**Default**: `false` | Boolean getAppointmentPickup() | setAppointmentPickup(Boolean appointmentPickup) |
| `NineAMDelivery` | `Boolean` | Optional | Indicates whether a shipment should be delivered before 9AM.<br>**Default**: `false` | Boolean getNineAMDelivery() | setNineAMDelivery(Boolean nineAMDelivery) |
| `DeliverToDoor` | `Boolean` | Optional | Indicates whether the package should be delivered to door.<br>**Default**: `false` | Boolean getDeliverToDoor() | setDeliverToDoor(Boolean deliverToDoor) |
| `DeliveryWindow` | `Boolean` | Optional | Indicates whether a delivery window has been specified for this shipment.<br>**Default**: `false` | Boolean getDeliveryWindow() | setDeliveryWindow(Boolean deliveryWindow) |
| `UnloadFreightAtDelivery` | `Boolean` | Optional | Indicates whether the shipment requires unloading on delivery.  Defaults to unloading not required if not submitted.<br>**Default**: `false` | Boolean getUnloadFreightAtDelivery() | setUnloadFreightAtDelivery(Boolean unloadFreightAtDelivery) |
| `LoadFreightAtPickup` | `Boolean` | Optional | Indicates whether the shipment requires loading on pick up.  Defaults to loading not required if not submitted.<br>**Default**: `false` | Boolean getLoadFreightAtPickup() | setLoadFreightAtPickup(Boolean loadFreightAtPickup) |
| `LoadingDockDelivery` | `Boolean` | Optional | Indicates whether the address to be delivered to has a loading dock.  Defaults to no loading dock if not submitted.<br>**Default**: `false` | Boolean getLoadingDockDelivery() | setLoadingDockDelivery(Boolean loadingDockDelivery) |
| `PriorDeliveryNotification` | `Boolean` | Optional | Indicates whether the shipment requires a prior delivery notification.<br>**Default**: `false` | Boolean getPriorDeliveryNotification() | setPriorDeliveryNotification(Boolean priorDeliveryNotification) |
| `WhiteGlove` | `Boolean` | Optional | Indicates whether the shipment requires white glove handling.  Defaults to white glove handling not required if not submitted.<br>**Default**: `false` | Boolean getWhiteGlove() | setWhiteGlove(Boolean whiteGlove) |
| `TwoManDelivery` | `Boolean` | Optional | Indicates whether the shipment requires a two man delivery.  Defaults to two man delivery not required if not submitted.<br>**Default**: `false` | Boolean getTwoManDelivery() | setTwoManDelivery(Boolean twoManDelivery) |
| `PalletExchange` | `Boolean` | Optional | Indicates whether the shipment requires pallet exchange.  Defaults to pallet exchange not required if not submitted.<br>**Default**: `false` | Boolean getPalletExchange() | setPalletExchange(Boolean palletExchange) |
| `SortAndSegregate` | `Boolean` | Optional | Indicates whether the shipment requires sorting and segregating.  Defaults to sorting and segregating not required if not submitted.<br>**Default**: `false` | Boolean getSortAndSegregate() | setSortAndSegregate(Boolean sortAndSegregate) |
| `Wholesaler` | `Boolean` | Optional | Indicates whether the shipment requires wholesaling.  Defaults to Wholesaling not required if not submitted.<br>**Default**: `false` | Boolean getWholesaler() | setWholesaler(Boolean wholesaler) |
| `TobaccoReportingCharge` | `Boolean` | Optional | Indicates whether the shipment requires tobacco reporting charge.  Defaults to tobacco reporting charge not required if not submitted.<br>**Default**: `false` | Boolean getTobaccoReportingCharge() | setTobaccoReportingCharge(Boolean tobaccoReportingCharge) |
| `Bulkhead` | `Boolean` | Optional | Indicates whether the shipment requires bulkhead.  Defaults to bulkhead not required if not submitted.<br>**Default**: `false` | Boolean getBulkhead() | setBulkhead(Boolean bulkhead) |
| `CallBeforeDelivery` | `Boolean` | Optional | Indicates whether the shipment requires call before delivery, arrival notice, notify charge.  Defaults to call before delivery not required if not submitted.<br>**Default**: `false` | Boolean getCallBeforeDelivery() | setCallBeforeDelivery(Boolean callBeforeDelivery) |
| `HighCostDeliverySurcharge` | `Boolean` | Optional | Indicates whether the shipment requires high cost delivery surcharge.  Defaults to high cost delivery surcharge not required if not submitted.<br>**Default**: `false` | Boolean getHighCostDeliverySurcharge() | setHighCostDeliverySurcharge(Boolean highCostDeliverySurcharge) |
| `LimitedAccessDelivery` | `Boolean` | Optional | Indicates whether the shipment requires limited access delivery charge.  Defaults to limited access delivery charge not required if not submitted.<br>**Default**: `false` | Boolean getLimitedAccessDelivery() | setLimitedAccessDelivery(Boolean limitedAccessDelivery) |
| `RemoteLocationSurcharge` | `Boolean` | Optional | Indicates whether the shipment requires remote location surcharge.  Defaults to remote location surcharge not required if not submitted.<br>**Default**: `false` | Boolean getRemoteLocationSurcharge() | setRemoteLocationSurcharge(Boolean remoteLocationSurcharge) |
| `AMDelivery` | `Boolean` | Optional | Indicates whether the shipment is an AM Delivery.  Defaults to false if not submitted.<br>**Default**: `false` | Boolean getAMDelivery() | setAMDelivery(Boolean aMDelivery) |
| `AddressChangeNotification` | `Boolean` | Optional | Used in conjunction with DispositionMethod for Ancillary Service Endorsements on DHL Global Mail Domestic Label.  Defaults to false if not submitted.<br>**Default**: `false` | Boolean getAddressChangeNotification() | setAddressChangeNotification(Boolean addressChangeNotification) |
| `DispositionMethod` | [`WtgDispositionMethodEnum`](../../doc/models/wtg-disposition-method-enum.md) | Optional | Used in conjunction with AddressChangeNotification for Ancillary Service Endorsements on DHL Global Mail Domestic Label.  Defaults to none if not submitted. | WtgDispositionMethodEnum getDispositionMethod() | setDispositionMethod(WtgDispositionMethodEnum dispositionMethod) |
| `AlcoholShipment` | `Integer` | Optional | Used to inform carrier of type of alcohol shipment.  Defaults to none if not submitted.<br>**Default**: `0` | Integer getAlcoholShipment() | setAlcoholShipment(Integer alcoholShipment) |
| `TemperatureService` | `Integer` | Optional | Indicates the type of temperature service selected for the shipment. Defaults to none if not submitted.<br>**Default**: `0` | Integer getTemperatureService() | setTemperatureService(Integer temperatureService) |
| `SmartPostAncillaryEndorsement` | `Integer` | Optional | Indicates the SmartPost Ancillary Endorsement type selected for the shipment.<br>**Default**: `0` | Integer getSmartPostAncillaryEndorsement() | setSmartPostAncillaryEndorsement(Integer smartPostAncillaryEndorsement) |
| `ColdChain` | `Boolean` | Optional | Indicates whether the shipment requires a cold chain service. This is for shipment freight level. Note cold chain is available for parcel at package level.<br>**Default**: `false` | Boolean getColdChain() | setColdChain(Boolean coldChain) |
| `HolidayDelivery` | `Boolean` | Optional | Indicates whether the shipment requires a holiday delivery service.<br>**Default**: `false` | Boolean getHolidayDelivery() | setHolidayDelivery(Boolean holidayDelivery) |
| `HolidayPickup` | `Boolean` | Optional | Indicates whether the shipment requires a holiday pickup.<br>**Default**: `false` | Boolean getHolidayPickup() | setHolidayPickup(Boolean holidayPickup) |
| `ProtectFromFreezing` | `Boolean` | Optional | Indicates that this is a protect from freezing delivery. Defaults to 'not a protect from freezing delivery' if not submitted.<br>**Default**: `false` | Boolean getProtectFromFreezing() | setProtectFromFreezing(Boolean protectFromFreezing) |
| `SundayDelivery` | `Boolean` | Optional | Indicates whether the shipment requires a sunday delivery service.<br>**Default**: `false` | Boolean getSundayDelivery() | setSundayDelivery(Boolean sundayDelivery) |
| `WeekendDelivery` | `Boolean` | Optional | Indicates whether the shipment requires a weekend delivery service.<br>**Default**: `false` | Boolean getWeekendDelivery() | setWeekendDelivery(Boolean weekendDelivery) |
| `WeekendPickup` | `Boolean` | Optional | Indicates whether the shipment requires a weekend pickup.<br>**Default**: `false` | Boolean getWeekendPickup() | setWeekendPickup(Boolean weekendPickup) |
| `ExcessDeclaredValue` | `Double` | Optional | Excess Declared Value amount.<br>**Default**: `0d` | Double getExcessDeclaredValue() | setExcessDeclaredValue(Double excessDeclaredValue) |
| `ReturnLegPickup` | `Boolean` | Optional | Indicates if an item should be picked up from the recipient and returned to the shipper. Default to false if not submitted.<br>**Default**: `false` | Boolean getReturnLegPickup() | setReturnLegPickup(Boolean returnLegPickup) |
| `BulkListID` | `Integer` | Optional | Bulk List Identifier.<br>**Default**: `0` | Integer getBulkListID() | setBulkListID(Integer bulkListID) |
| `Security` | `Boolean` | Optional | Indicates whether the shipment requires a security fee.<br>**Default**: `false` | Boolean getSecurity() | setSecurity(Boolean security) |
| `FirstDelivery` | `Boolean` | Optional | Indicates whether the shipment requires the First Delivery special service.<br>**Default**: `false` | Boolean getFirstDelivery() | setFirstDelivery(Boolean firstDelivery) |
| `FreeDomicile` | `Boolean` | Optional | Indicates whether the shipment requires the Free Domicile special service.<br>**Default**: `false` | Boolean getFreeDomicile() | setFreeDomicile(Boolean freeDomicile) |
| `NoonDelivery` | `Boolean` | Optional | Indicates whether the shipment requires the Noon Delivery special service.<br>**Default**: `false` | Boolean getNoonDelivery() | setNoonDelivery(Boolean noonDelivery) |
| `HomeDelivery` | [`WtgHomeDelivery1`](../../doc/models/wtg-home-delivery-1.md) | Optional | Container for home delivery details. | WtgHomeDelivery1 getHomeDelivery() | setHomeDelivery(WtgHomeDelivery1 homeDelivery) |
| `Sender` | [`WtgSender4`](../../doc/models/wtg-sender-4.md) | Optional | Container to allow the customization of the sender address details associated with the transaction. | WtgSender4 getSender() | setSender(WtgSender4 sender) |
| `Receiver` | [`WtgReceiver9`](../../doc/models/wtg-receiver-9.md) | Required | Container for the receiver address details associated with the transaction. | WtgReceiver9 getReceiver() | setReceiver(WtgReceiver9 receiver) |
| `ReturnTo` | [`WtgReturnTo4`](../../doc/models/wtg-return-to-4.md) | Optional | Container for any return address associated with the transaction. | WtgReturnTo4 getReturnTo() | setReturnTo(WtgReturnTo4 returnTo) |
| `Packages` | [`WtgPackages14`](../../doc/models/wtg-packages-14.md) | Required | Container for all packages associated with the transaction. | WtgPackages14 getPackages() | setPackages(WtgPackages14 packages) |
| `Diagnostics` | [`WtgDiagnostics`](../../doc/models/wtg-diagnostics.md) | Optional | Container for logging and diagnostic override elements. | WtgDiagnostics getDiagnostics() | setDiagnostics(WtgDiagnostics diagnostics) |
| `Identification` | [`WtgIdentification`](../../doc/models/wtg-identification.md) | Optional | Container for client identification elements. | WtgIdentification getIdentification() | setIdentification(WtgIdentification identification) |
| `SourceApplication` | [`WtgSourceApplication`](../../doc/models/wtg-source-application.md) | Optional | Container for app specific source identification elements. | WtgSourceApplication getSourceApplication() | setSourceApplication(WtgSourceApplication sourceApplication) |

## Example (as XML)

```xml
<wtg:PierbridgeShipRequisitionRequest xmlns:wtg="https://www.wisetechglobal.com/">
  <wtg:Receiver xmlns:wtg="https://www.wisetechglobal.com/" />
  <wtg:Packages xmlns:wtg="https://www.wisetechglobal.com/" />
</wtg:PierbridgeShipRequisitionRequest>
```

