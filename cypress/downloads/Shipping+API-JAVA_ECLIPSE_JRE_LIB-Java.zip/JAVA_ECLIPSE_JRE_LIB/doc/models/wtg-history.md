
# Wtg History

Container for all history details of the shipment.

## Structure

`WtgHistory`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `TrackStatus` | `List<String>` | Optional | Container for a single history detail. | List<String> getTrackStatus() | setTrackStatus(List<String> trackStatus) |
| `Status` | `String` | Optional | A free form name of the track status. | String getStatus() | setStatus(String status) |
| `Description` | `String` | Optional | A free form description for the track status. | String getDescription() | setDescription(String description) |
| `StatusDate` | `String` | Optional | The data of the status event. | String getStatusDate() | setStatusDate(String statusDate) |
| `TrackedDate` | `String` | Optional | The date of the tracking event. | String getTrackedDate() | setTrackedDate(String trackedDate) |

## Example (as XML)

```xml
<wtg:History xmlns:wtg="https://www.wisetechglobal.com/" />
```

