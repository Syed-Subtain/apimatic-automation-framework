
# Wtg Outputs

Container for outputs the transaction should generate or customize the printing of.

## Structure

`WtgOutputs`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Output` | [`List<WtgOutput1>`](../../doc/models/wtg-output-1.md) | Optional | Container for an output the transaction should generate or customize the printing of. | List<WtgOutput1> getOutput() | setOutput(List<WtgOutput1> output) |

## Example (as XML)

```xml
<wtg:Outputs xmlns:wtg="https://www.wisetechglobal.com/" />
```

