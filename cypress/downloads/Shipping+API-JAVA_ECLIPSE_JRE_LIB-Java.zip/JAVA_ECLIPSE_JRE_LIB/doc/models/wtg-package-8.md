
# Wtg Package 8

Container for an individual package associated with the transaction.

## Structure

`WtgPackage8`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Status` | [`WtgStatus`](../../doc/models/wtg-status.md) | Required | Container for transaction errors and warning elements. | WtgStatus getStatus() | setStatus(WtgStatus status) |
| `AdditionalHandling` | `Boolean` | Optional | Indicates that extra handling measures are required when loading the package.<br>**Default**: `false` | Boolean getAdditionalHandling() | setAdditionalHandling(Boolean additionalHandling) |
| `Oversize` | `Integer` | Optional | Indicates if the item is over standard size dimensions.<br>**Default**: `0` | Integer getOversize() | setOversize(Integer oversize) |
| `PackageType` | `Integer` | Optional | Numeric identifier for the carrier package type.<br>**Default**: `0` | Integer getPackageType() | setPackageType(Integer packageType) |
| `FreightClass` | `String` | Optional | The freight class of the package's content. | String getFreightClass() | setFreightClass(String freightClass) |
| `ShipperReference` | `String` | Optional | Primary shipping reference number. | String getShipperReference() | setShipperReference(String shipperReference) |
| `PackageReference` | `String` | Optional | Package reference number, which will be echoed back in the response. | String getPackageReference() | setPackageReference(String packageReference) |
| `International` | [`WtgInternational8`](../../doc/models/wtg-international-8.md) | Optional | Container for international details associated with the shipment. | WtgInternational8 getInternational() | setInternational(WtgInternational8 international) |

## Example (as XML)

```xml
<wtg:Package xmlns:wtg="https://www.wisetechglobal.com/">
  <wtg:Status xmlns:wtg="https://www.wisetechglobal.com/">
    <wtg:Code>108</wtg:Code>
    <wtg:Warnings />
    <wtg:Errors />
  </wtg:Status>
  <wtg:International xmlns:wtg="https://www.wisetechglobal.com/" />
</wtg:Package>
```

