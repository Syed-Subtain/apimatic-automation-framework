
# Wtg Material Exemptions

Container for material exemptions.

## Structure

`WtgMaterialExemptions`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `MaterialExemption` | [`List<WtgMaterialExemption>`](../../doc/models/wtg-material-exemption.md) | Optional | Container for material exemption. | List<WtgMaterialExemption> getMaterialExemption() | setMaterialExemption(List<WtgMaterialExemption> materialExemption) |

## Example (as XML)

```xml
<wtg:MaterialExemptions xmlns:wtg="https://www.wisetechglobal.com/" />
```

