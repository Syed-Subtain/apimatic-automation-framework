
# Wtg Tax Type Enum

## Enumeration

`WtgTaxTypeEnum`

## Fields

| Name |
|  --- |
| `Enum0` |
| `Enum1` |
| `Enum2` |
| `Enum3` |
| `Enum4` |

