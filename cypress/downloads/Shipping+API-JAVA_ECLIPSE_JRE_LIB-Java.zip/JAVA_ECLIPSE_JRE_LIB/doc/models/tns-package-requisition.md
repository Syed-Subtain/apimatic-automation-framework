
# Tns Package Requisition

Container for a single package within the requisition.

## Structure

`TnsPackageRequisition`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `PackageRequisitionID` | `int` | Required | Unique numeric identifier for the requistion package. | int getPackageRequisitionID() | setPackageRequisitionID(int packageRequisitionID) |
| `ReferenceNumber` | `String` | Required | A reference number associated with the package requisition. | String getReferenceNumber() | setReferenceNumber(String referenceNumber) |

## Example (as JSON)

```json
{
  "PackageRequisitionID": 66,
  "ReferenceNumber": "ReferenceNumber0"
}
```

