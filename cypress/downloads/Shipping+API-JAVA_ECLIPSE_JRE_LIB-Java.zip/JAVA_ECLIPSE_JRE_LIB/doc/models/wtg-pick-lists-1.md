
# Wtg Pick Lists 1

Container all order picklists.

## Structure

`WtgPickLists1`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `PickList` | [`List<WtgPickList1>`](../../doc/models/wtg-pick-list-1.md) | Optional | Container for an individual picklist. | List<WtgPickList1> getPickList() | setPickList(List<WtgPickList1> pickList) |

## Example (as XML)

```xml
<wtg:PickLists xmlns:wtg="https://www.wisetechglobal.com/" />
```

