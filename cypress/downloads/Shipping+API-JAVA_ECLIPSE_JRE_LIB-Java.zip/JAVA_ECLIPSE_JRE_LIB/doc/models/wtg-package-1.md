
# Wtg Package 1

Container for an individual package associated with the transaction.

## Structure

`WtgPackage1`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `PackageID` | `String` | Required | Unique identifier for the package. | String getPackageID() | setPackageID(String packageID) |
| `WayBillNumber` | `String` | Required | Tracking number of the package. | String getWayBillNumber() | setWayBillNumber(String wayBillNumber) |
| `Trailer` | `String` | Optional | Trailer group the package is in. | String getTrailer() | setTrailer(String trailer) |
| `AccessorialTotal` | `Double` | Optional | Total charge for accessorials. This figure will include post-consolidation/ re-rated discounts (if applicable) | Double getAccessorialTotal() | setAccessorialTotal(Double accessorialTotal) |
| `ShippingTotal` | `Double` | Optional | Total charge for shipping costs. This figure will include post-consolidation/ re-rated discounts (if applicable) | Double getShippingTotal() | setShippingTotal(Double shippingTotal) |
| `TotalCost` | `Double` | Optional | Total charge for the shipment. This figure will include post-consolidation/ re-rated discounts (if applicable) | Double getTotalCost() | setTotalCost(Double totalCost) |

## Example (as XML)

```xml
<wtg:Package xmlns:wtg="https://www.wisetechglobal.com/">
  <wtg:PackageID xmlns:wtg="https://www.wisetechglobal.com/">PackageID6</wtg:PackageID>
  <wtg:WayBillNumber xmlns:wtg="https://www.wisetechglobal.com/">WayBillNumber8</wtg:WayBillNumber>
</wtg:Package>
```

