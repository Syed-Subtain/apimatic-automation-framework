
# Wtg Charges

Container for all charges within the group associated with the transaction.

## Structure

`WtgCharges`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Charge` | [`List<WtgCharge>`](../../doc/models/wtg-charge.md) | Optional | Container for an individual charge within the group associated with the transaction. | List<WtgCharge> getCharge() | setCharge(List<WtgCharge> charge) |

## Example (as XML)

```xml
<wtg:Charges xmlns:wtg="https://www.wisetechglobal.com/" />
```

