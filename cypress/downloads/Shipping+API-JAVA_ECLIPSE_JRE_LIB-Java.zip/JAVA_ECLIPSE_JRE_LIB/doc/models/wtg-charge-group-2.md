
# Wtg Charge Group 2

Container for an individual charge group associated with the transaction.

## Structure

`WtgChargeGroup2`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `ChargeGroupType` | `Integer` | Optional | An identifier for the type of the charge group.<br>**Default**: `0` | Integer getChargeGroupType() | setChargeGroupType(Integer chargeGroupType) |
| `ChargeGroupDescription` | `String` | Optional | The description for the group of charges. | String getChargeGroupDescription() | setChargeGroupDescription(String chargeGroupDescription) |
| `ChargeGroupValue` | `Double` | Optional | The value of the charge group associated with the transaction.<br>**Default**: `0d` | Double getChargeGroupValue() | setChargeGroupValue(Double chargeGroupValue) |
| `ChargeGroupCurrency` | `String` | Optional | A code indicating the type of currency for the charges group. | String getChargeGroupCurrency() | setChargeGroupCurrency(String chargeGroupCurrency) |
| `Charges` | [`WtgCharges2`](../../doc/models/wtg-charges-2.md) | Required | Container for all charges within the group associated with the transaction. | WtgCharges2 getCharges() | setCharges(WtgCharges2 charges) |

## Example (as XML)

```xml
<wtg:ChargeGroup xmlns:wtg="https://www.wisetechglobal.com/">
  <wtg:Charges xmlns:wtg="https://www.wisetechglobal.com/" />
</wtg:ChargeGroup>
```

