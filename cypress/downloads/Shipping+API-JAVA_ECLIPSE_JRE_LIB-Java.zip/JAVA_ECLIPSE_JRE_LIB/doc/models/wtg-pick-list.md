
# Wtg Pick List

Container for an individual picklist.

## Structure

`WtgPickList`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `PickListID` | `Integer` | Optional | Identifier of the pick list being rated.<br>**Default**: `0` | Integer getPickListID() | setPickListID(Integer pickListID) |

## Example (as XML)

```xml
<wtg:PickList xmlns:wtg="https://www.wisetechglobal.com/" />
```

