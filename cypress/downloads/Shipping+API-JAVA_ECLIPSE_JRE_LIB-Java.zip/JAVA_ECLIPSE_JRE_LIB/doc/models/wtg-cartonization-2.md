
# Wtg Cartonization 2

Container for cartonization data for this transaction.

## Structure

`WtgCartonization2`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `CartonizationGroupID` | `Integer` | Optional | Numeric identifier for a cartonization group.<br>**Default**: `0` | Integer getCartonizationGroupID() | setCartonizationGroupID(Integer cartonizationGroupID) |
| `SVGData` | `String` | Optional | Html that contains the visualization web page that represents the cartonized items. | String getSVGData() | setSVGData(String sVGData) |
| `JSONBoxData` | `String` | Optional | Html that contains the json data that represents the cartonized items. | String getJSONBoxData() | setJSONBoxData(String jSONBoxData) |
| `Packages` | [`WtgPackages4`](../../doc/models/wtg-packages-4.md) | Optional | Container for all packages associated with the transaction. | WtgPackages4 getPackages() | setPackages(WtgPackages4 packages) |

## Example (as XML)

```xml
<wtg:Cartonization xmlns:wtg="https://www.wisetechglobal.com/">
  <wtg:Packages xmlns:wtg="https://www.wisetechglobal.com/" />
</wtg:Cartonization>
```

