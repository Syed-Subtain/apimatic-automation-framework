
# Tns Package

Container for an individual package associated with the transaction.

## Structure

`TnsPackage`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Status` | [`TnsStatus`](../../doc/models/tns-status.md) | Required | Container for transaction errors and warning elements. | TnsStatus getStatus() | setStatus(TnsStatus status) |

## Example (as JSON)

```json
{
  "Status": {
    "Code": 108,
    "Description": null,
    "Warnings": null,
    "Errors": null
  }
}
```

