
# Tns Warnings

Container for all warnings found whilst processing the transaction.

## Structure

`TnsWarnings`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Warning` | [`List<TnsWarning>`](../../doc/models/tns-warning.md) | Optional | Container for a single warning found whilst processing the transaction. | List<TnsWarning> getWarning() | setWarning(List<TnsWarning> warning) |

## Example (as JSON)

```json
{
  "Warning": null
}
```

