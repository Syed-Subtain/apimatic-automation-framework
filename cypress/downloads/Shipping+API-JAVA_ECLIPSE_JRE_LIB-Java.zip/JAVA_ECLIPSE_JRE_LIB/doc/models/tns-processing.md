
# Tns Processing

Container element for transaction processing statistics.

## Structure

`TnsProcessing`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `StartTime` | `String` | Required | The time the transaction started to be processed. | String getStartTime() | setStartTime(String startTime) |
| `EndTime` | `String` | Required | The time the transaction finished processing. | String getEndTime() | setEndTime(String endTime) |
| `Duration` | `double` | Required | The difference in milliseconds between the processing start and end times. | double getDuration() | setDuration(double duration) |
| `External` | [`TnsExternal`](../../doc/models/tns-external.md) | Optional | Container for the timings associated with external systems. | TnsExternal getExternal() | setExternal(TnsExternal external) |
| `ServerName` | `String` | Required | The Net BIOS name of the server which processed the transaction. | String getServerName() | setServerName(String serverName) |
| `UserName` | `String` | Optional | The authorized name of the user under which the transaction was processed. | String getUserName() | setUserName(String userName) |

## Example (as JSON)

```json
{
  "StartTime": "StartTime8",
  "EndTime": "EndTime4",
  "Duration": 234.88,
  "External": null,
  "ServerName": "ServerName2",
  "UserName": null
}
```

