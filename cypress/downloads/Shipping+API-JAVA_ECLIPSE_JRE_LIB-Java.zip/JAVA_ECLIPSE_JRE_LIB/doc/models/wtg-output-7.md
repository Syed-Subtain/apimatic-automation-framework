
# Wtg Output 7

Container for documents to be printed externally from the transaction.

## Structure

`WtgOutput7`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Guid` | `String` | Optional | A guid identifier that identifies the output. | String getGuid() | setGuid(String guid) |
| `PackageID` | `Integer` | Optional | A numeric identifier that identifies the Package of output.<br>**Default**: `0` | Integer getPackageID() | setPackageID(Integer packageID) |
| `Name` | `String` | Optional | The description of the output type. | String getName() | setName(String name) |
| `Type` | `Integer` | Optional | A numeric identifier that identifies the type of output.<br>**Default**: `0` | Integer getType() | setType(Integer type) |
| `BaseType` | `Integer` | Optional | A numeric identifier that identifies the base type of output.<br>**Default**: `0` | Integer getBaseType() | setBaseType(Integer baseType) |
| `Format` | `Integer` | Optional | A numeric identifier that identifies the format of the output.<br>**Default**: `0` | Integer getFormat() | setFormat(Integer format) |

## Example (as XML)

```xml
<wtg:Output xmlns:wtg="https://www.wisetechglobal.com/" />
```

