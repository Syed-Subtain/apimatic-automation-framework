
# Wtg Notifications 1

Container for email notifications.

## Structure

`WtgNotifications1`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `ReceiverShipmentNotification` | `Boolean` | Optional | Indicates the receiver should be notified when the shipment is shipped.<br>**Default**: `false` | Boolean getReceiverShipmentNotification() | setReceiverShipmentNotification(Boolean receiverShipmentNotification) |
| `SenderShipmentNotification` | `Boolean` | Optional | Indicates the sender should be notified when the shipment is shipped.<br>**Default**: `false` | Boolean getSenderShipmentNotification() | setSenderShipmentNotification(Boolean senderShipmentNotification) |
| `ShipmentNotificationDetail` | [`WtgShipmentNotificationDetail1`](../../doc/models/wtg-shipment-notification-detail-1.md) | Optional | Container for shipment notification deails. | WtgShipmentNotificationDetail1 getShipmentNotificationDetail() | setShipmentNotificationDetail(WtgShipmentNotificationDetail1 shipmentNotificationDetail) |
| `ReceiverDeliveryNotification` | `Boolean` | Optional | Indicates the receiver should be notified when the shipment is delivered.<br>**Default**: `false` | Boolean getReceiverDeliveryNotification() | setReceiverDeliveryNotification(Boolean receiverDeliveryNotification) |
| `SenderDeliveryNotification` | `Boolean` | Optional | Indicates the sender should be notified when the shipment is delivered.<br>**Default**: `false` | Boolean getSenderDeliveryNotification() | setSenderDeliveryNotification(Boolean senderDeliveryNotification) |
| `DeliveryNotificationDetail` | [`WtgDeliveryNotificationDetail`](../../doc/models/wtg-delivery-notification-detail.md) | Optional | Container for shipment delivery notification deails. | WtgDeliveryNotificationDetail getDeliveryNotificationDetail() | setDeliveryNotificationDetail(WtgDeliveryNotificationDetail deliveryNotificationDetail) |
| `ReceiverExceptionNotification` | `Boolean` | Optional | Indicates the receiver should be notified if there is an issue with the shipment.<br>**Default**: `false` | Boolean getReceiverExceptionNotification() | setReceiverExceptionNotification(Boolean receiverExceptionNotification) |
| `SenderExceptionNotification` | `Boolean` | Optional | Indicates the sender should be notified if there is an issue with the shipment.<br>**Default**: `false` | Boolean getSenderExceptionNotification() | setSenderExceptionNotification(Boolean senderExceptionNotification) |
| `ExceptionNotificationDetail` | [`WtgExceptionNotificationDetail1`](../../doc/models/wtg-exception-notification-detail-1.md) | Optional | Container for shipment exception notification deails. | WtgExceptionNotificationDetail1 getExceptionNotificationDetail() | setExceptionNotificationDetail(WtgExceptionNotificationDetail1 exceptionNotificationDetail) |
| `OutForDeliveryNotificationDetail` | [`WtgOutForDeliveryNotificationDetail`](../../doc/models/wtg-out-for-delivery-notification-detail.md) | Optional | Container for out for delivery email notification. | WtgOutForDeliveryNotificationDetail getOutForDeliveryNotificationDetail() | setOutForDeliveryNotificationDetail(WtgOutForDeliveryNotificationDetail outForDeliveryNotificationDetail) |
| `AtDepotNotificationDetail` | [`WtgAtDepotNotificationDetail`](../../doc/models/wtg-at-depot-notification-detail.md) | Optional | Container for at depot email notifications. | WtgAtDepotNotificationDetail getAtDepotNotificationDetail() | setAtDepotNotificationDetail(WtgAtDepotNotificationDetail atDepotNotificationDetail) |
| `ReceiverOnTenderNotification` | `Boolean` | Optional | Indicates the receiver should be notified when the shipment is tendered.<br>**Default**: `false` | Boolean getReceiverOnTenderNotification() | setReceiverOnTenderNotification(Boolean receiverOnTenderNotification) |
| `SenderOnTenderNotification` | `Boolean` | Optional | Indicates the sender should be notified when the shipment is tendered.<br>**Default**: `false` | Boolean getSenderOnTenderNotification() | setSenderOnTenderNotification(Boolean senderOnTenderNotification) |
| `OnTenderNotificationDetail` | [`WtgOnTenderNotificationDetail`](../../doc/models/wtg-on-tender-notification-detail.md) | Optional | Container for shipment tendering notification deails. | WtgOnTenderNotificationDetail getOnTenderNotificationDetail() | setOnTenderNotificationDetail(WtgOnTenderNotificationDetail onTenderNotificationDetail) |
| `PredictNotificationDetail` | [`WtgPredictNotificationDetail`](../../doc/models/wtg-predict-notification-detail.md) | Optional | Container for predict email notifications. | WtgPredictNotificationDetail getPredictNotificationDetail() | setPredictNotificationDetail(WtgPredictNotificationDetail predictNotificationDetail) |
| `OtherShipmentNotifications` | `Boolean` | Optional | Indicates other should be notified when the shipment is shipped.<br>**Default**: `false` | Boolean getOtherShipmentNotifications() | setOtherShipmentNotifications(Boolean otherShipmentNotifications) |
| `OtherDeliveryNotifications` | `Boolean` | Optional | Indicates other should be notified when the shipment is delivered.<br>**Default**: `false` | Boolean getOtherDeliveryNotifications() | setOtherDeliveryNotifications(Boolean otherDeliveryNotifications) |
| `OtherExceptionNotifications` | `Boolean` | Optional | Indicates other should be notified if there is an issue with the shipment.<br>**Default**: `false` | Boolean getOtherExceptionNotifications() | setOtherExceptionNotifications(Boolean otherExceptionNotifications) |
| `OtherOnTenderNotifications` | `Boolean` | Optional | Indicates other should be notified when the shipment is tendered.<br>**Default**: `false` | Boolean getOtherOnTenderNotifications() | setOtherOnTenderNotifications(Boolean otherOnTenderNotifications) |
| `OtherNotificationDetail` | [`WtgOtherNotificationDetail`](../../doc/models/wtg-other-notification-detail.md) | Optional | Container for other notification details. | WtgOtherNotificationDetail getOtherNotificationDetail() | setOtherNotificationDetail(WtgOtherNotificationDetail otherNotificationDetail) |
| `SenderPickupRequestConfirmationNotification` | `Boolean` | Optional | Indicates an email should be sent to the sender when a pickup request is received.<br>**Default**: `false` | Boolean getSenderPickupRequestConfirmationNotification() | setSenderPickupRequestConfirmationNotification(Boolean senderPickupRequestConfirmationNotification) |
| `SenderDriverOnRouteNotification` | `Boolean` | Optional | Indicates an email should be sent to the sender when a driver is on route to a pickup.<br>**Default**: `false` | Boolean getSenderDriverOnRouteNotification() | setSenderDriverOnRouteNotification(Boolean senderDriverOnRouteNotification) |
| `SenderPickupSecuredNotification` | `Boolean` | Optional | Indicates an email should be sent to the sender when a pickup has been loaded.<br>**Default**: `false` | Boolean getSenderPickupSecuredNotification() | setSenderPickupSecuredNotification(Boolean senderPickupSecuredNotification) |
| `SenderPickupExceptionNotification` | `Boolean` | Optional | Indicates an email should be sent to the sender when a pickup exception occurs.<br>**Default**: `false` | Boolean getSenderPickupExceptionNotification() | setSenderPickupExceptionNotification(Boolean senderPickupExceptionNotification) |
| `ReceiverPickupRequestConfirmationNotification` | `Boolean` | Optional | Indicates an email should be sent to the receiver when a pickup request is received.<br>**Default**: `false` | Boolean getReceiverPickupRequestConfirmationNotification() | setReceiverPickupRequestConfirmationNotification(Boolean receiverPickupRequestConfirmationNotification) |
| `ReceiverDriverOnRouteNotification` | `Boolean` | Optional | Indicates an email should be sent to the receiver when a driver is on route to a pickup.<br>**Default**: `false` | Boolean getReceiverDriverOnRouteNotification() | setReceiverDriverOnRouteNotification(Boolean receiverDriverOnRouteNotification) |
| `ReceiverPickupSecuredNotification` | `Boolean` | Optional | Indicates an email should be sent to the receiver when a pickup has been loaded.<br>**Default**: `false` | Boolean getReceiverPickupSecuredNotification() | setReceiverPickupSecuredNotification(Boolean receiverPickupSecuredNotification) |
| `ReceiverPickupExceptionNotification` | `Boolean` | Optional | Indicates an email should be sent to the receiver when a pickup exception occurs.<br>**Default**: `false` | Boolean getReceiverPickupExceptionNotification() | setReceiverPickupExceptionNotification(Boolean receiverPickupExceptionNotification) |
| `OtherPickupRequestConfirmationNotifications` | `Boolean` | Optional | Indicates an email should be sent to the addresses in the Other EMail Notifications Addresses when a pickup request is received.<br>**Default**: `false` | Boolean getOtherPickupRequestConfirmationNotifications() | setOtherPickupRequestConfirmationNotifications(Boolean otherPickupRequestConfirmationNotifications) |
| `OtherDriverOnRouteNotifications` | `Boolean` | Optional | Indicates an email should be sent to the addresses in the Other EMail Notifications Addresses when a driver is on route to a pickup.<br>**Default**: `false` | Boolean getOtherDriverOnRouteNotifications() | setOtherDriverOnRouteNotifications(Boolean otherDriverOnRouteNotifications) |
| `OtherPickupSecuredNotifications` | `Boolean` | Optional | Indicates an email should be sent to the addresses in the Other EMail Notifications Addresses when a pickup has been loaded.<br>**Default**: `false` | Boolean getOtherPickupSecuredNotifications() | setOtherPickupSecuredNotifications(Boolean otherPickupSecuredNotifications) |
| `OtherPickupExceptionNotifications` | `Boolean` | Optional | Indicates an email should be sent to the addresses in the Other EMail Notifications Addresses when a pickup exception occurs.<br>**Default**: `false` | Boolean getOtherPickupExceptionNotifications() | setOtherPickupExceptionNotifications(Boolean otherPickupExceptionNotifications) |

## Example (as XML)

```xml
<wtg:Notifications xmlns:wtg="https://www.wisetechglobal.com/">
  <wtg:ShipmentNotificationDetail xmlns:wtg="https://www.wisetechglobal.com/" />
  <wtg:DeliveryNotificationDetail xmlns:wtg="https://www.wisetechglobal.com/" />
  <wtg:ExceptionNotificationDetail xmlns:wtg="https://www.wisetechglobal.com/" />
  <wtg:OutForDeliveryNotificationDetail xmlns:wtg="https://www.wisetechglobal.com/" />
  <wtg:AtDepotNotificationDetail xmlns:wtg="https://www.wisetechglobal.com/" />
  <wtg:OnTenderNotificationDetail xmlns:wtg="https://www.wisetechglobal.com/" />
  <wtg:PredictNotificationDetail xmlns:wtg="https://www.wisetechglobal.com/" />
  <wtg:OtherNotificationDetail xmlns:wtg="https://www.wisetechglobal.com/" />
</wtg:Notifications>
```

