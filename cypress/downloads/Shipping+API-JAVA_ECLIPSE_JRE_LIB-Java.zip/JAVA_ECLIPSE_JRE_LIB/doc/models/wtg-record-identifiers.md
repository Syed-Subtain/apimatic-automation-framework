
# Wtg Record Identifiers

Outer container for transaction identifiers.

## Structure

`WtgRecordIdentifiers`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `RecordIdentifier` | [`List<WtgRecordIdentifier>`](../../doc/models/wtg-record-identifier.md) | Optional | Inner container for transaction identifiers. | List<WtgRecordIdentifier> getRecordIdentifier() | setRecordIdentifier(List<WtgRecordIdentifier> recordIdentifier) |

## Example (as XML)

```xml
<wtg:RecordIdentifiers xmlns:wtg="https://www.wisetechglobal.com/" />
```

