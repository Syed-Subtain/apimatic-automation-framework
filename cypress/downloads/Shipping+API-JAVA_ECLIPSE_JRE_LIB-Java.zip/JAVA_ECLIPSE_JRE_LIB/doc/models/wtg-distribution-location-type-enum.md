
# Wtg Distribution Location Type Enum

## Enumeration

`WtgDistributionLocationTypeEnum`

## Fields

| Name |
|  --- |
| `Enum1` |
| `Enum2` |
| `Enum3` |
| `Enum4` |

