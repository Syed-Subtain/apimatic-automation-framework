
# Wtg Packages 14

Container for all packages associated with the transaction.

## Structure

`WtgPackages14`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Package` | [`List<WtgPackage15>`](../../doc/models/wtg-package-15.md) | Required | Container for an individual package associated with the transaction. | List<WtgPackage15> getPackage() | setPackage(List<WtgPackage15> mPackage) |

## Example (as XML)

```xml
<wtg:Packages xmlns:wtg="https://www.wisetechglobal.com/" />
```

