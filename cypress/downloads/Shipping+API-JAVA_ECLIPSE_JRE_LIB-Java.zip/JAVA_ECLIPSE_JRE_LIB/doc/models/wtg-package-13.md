
# Wtg Package 13

Container for an individual package associated with the transaction.

## Structure

`WtgPackage13`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `RecordIdentifiers` | [`WtgRecordIdentifiers3`](../../doc/models/wtg-record-identifiers-3.md) | Optional | Outer container for transaction identifiers. | WtgRecordIdentifiers3 getRecordIdentifiers() | setRecordIdentifiers(WtgRecordIdentifiers3 recordIdentifiers) |
| `Status` | [`WtgStatus`](../../doc/models/wtg-status.md) | Required | Container for transaction errors and warning elements. | WtgStatus getStatus() | setStatus(WtgStatus status) |
| `MailPieceNumber` | `String` | Optional | Mail piece number to associate with the package. Use in association with tracking number for postal services. | String getMailPieceNumber() | setMailPieceNumber(String mailPieceNumber) |
| `UniqueIdentifier` | `String` | Optional | Free form identifier for the package. | String getUniqueIdentifier() | setUniqueIdentifier(String uniqueIdentifier) |
| `OtherIdentifier` | `String` | Optional | Free form identifier for the package. | String getOtherIdentifier() | setOtherIdentifier(String otherIdentifier) |
| `BillingCode` | `String` | Optional | Code relating to the billing. | String getBillingCode() | setBillingCode(String billingCode) |
| `SubmittedWeight` | `Double` | Optional | Indicates the weight that was submitted to the carrier in cases where weights are pre-processed by shipment server. | Double getSubmittedWeight() | setSubmittedWeight(Double submittedWeight) |
| `AdditionalHandling` | `Boolean` | Optional | Indicates that extra handling measures are required when loading the package.<br>**Default**: `false` | Boolean getAdditionalHandling() | setAdditionalHandling(Boolean additionalHandling) |
| `Oversize` | `Integer` | Optional | Indicates if the item is over standard size dimensions.<br>**Default**: `0` | Integer getOversize() | setOversize(Integer oversize) |
| `PackageType` | `Integer` | Optional | Numeric identifier for the carrier package type.<br>**Default**: `0` | Integer getPackageType() | setPackageType(Integer packageType) |
| `FreightClass` | `String` | Optional | The freight class of the package's content. | String getFreightClass() | setFreightClass(String freightClass) |
| `Weight` | `Double` | Optional | The weight of the package.<br>**Default**: `0d` | Double getWeight() | setWeight(Double weight) |
| `PackageUniqueIdentifier` | `String` | Optional | Package Unique Identifier. | String getPackageUniqueIdentifier() | setPackageUniqueIdentifier(String packageUniqueIdentifier) |
| `ShipperReference` | `String` | Optional | Primary shipping reference number. | String getShipperReference() | setShipperReference(String shipperReference) |
| `PackageReference` | `String` | Optional | Package reference number, which will be echoed back in the response. | String getPackageReference() | setPackageReference(String packageReference) |
| `FullIntelligentMailPackageBarcode` | `String` | Optional | IMpb barcode for the shipment. | String getFullIntelligentMailPackageBarcode() | setFullIntelligentMailPackageBarcode(String fullIntelligentMailPackageBarcode) |
| `WayBillNumber` | `String` | Optional | Tracking number of the package. | String getWayBillNumber() | setWayBillNumber(String wayBillNumber) |
| `WayBillNumber2` | `String` | Optional | If appropriate the secondary tracking number of the package. | String getWayBillNumber2() | setWayBillNumber2(String wayBillNumber2) |
| `OriginStation` | `String` | Optional | The carrier's station location for the origin shipper. | String getOriginStation() | setOriginStation(String originStation) |
| `RouteCode` | `String` | Optional | The universal route or sort aid (URSA) routing code provided by the carrier. | String getRouteCode() | setRouteCode(String routeCode) |
| `DestinationStation` | `String` | Optional | Contains the carrier's location identifier of the package destination, if available. | String getDestinationStation() | setDestinationStation(String destinationStation) |
| `ServiceCode` | `String` | Optional | Code for the service. | String getServiceCode() | setServiceCode(String serviceCode) |
| `BannerText` | `String` | Optional | Banner text for USPS barcodes. | String getBannerText() | setBannerText(String bannerText) |
| `FormID` | `String` | Optional | Tracking number of the package. | String getFormID() | setFormID(String formID) |
| `CODWayBillNumber` | `String` | Optional | Tracking number of the package. | String getCODWayBillNumber() | setCODWayBillNumber(String cODWayBillNumber) |
| `CODFormID` | `String` | Optional | The tracking number printed on the COD label. | String getCODFormID() | setCODFormID(String cODFormID) |
| `PackageID` | `Integer` | Optional | Unique identifier for the package. | Integer getPackageID() | setPackageID(Integer packageID) |
| `ShipToHoldState` | `Integer` | Optional | The status if the shipment has been processed using ship to hold.<br>**Default**: `0` | Integer getShipToHoldState() | setShipToHoldState(Integer shipToHoldState) |
| `Insurance` | [`WtgInsurance2`](../../doc/models/wtg-insurance-2.md) | Optional | Container for insurance details. | WtgInsurance2 getInsurance() | setInsurance(WtgInsurance2 insurance) |
| `International` | [`WtgInternational14`](../../doc/models/wtg-international-14.md) | Optional | Container for international details associated with the shipment. | WtgInternational14 getInternational() | setInternational(WtgInternational14 international) |
| `Labels` | [`WtgLabels`](../../doc/models/wtg-labels.md) | Optional | Container for labels to be printed by the caller of the transaction (client). | WtgLabels getLabels() | setLabels(WtgLabels labels) |
| `Documents` | [`WtgDocuments1`](../../doc/models/wtg-documents-1.md) | Optional | Container for documents to be printed by the caller of the transaction (client). | WtgDocuments1 getDocuments() | setDocuments(WtgDocuments1 documents) |
| `Shipping` | [`WtgShipping`](../../doc/models/wtg-shipping.md) | Optional | Container for shipping associated with the transaction. | WtgShipping getShipping() | setShipping(WtgShipping shipping) |
| `Customer` | [`WtgCustomer`](../../doc/models/wtg-customer.md) | Optional | Container for customer details. | WtgCustomer getCustomer() | setCustomer(WtgCustomer customer) |
| `Rates` | [`WtgRates11`](../../doc/models/wtg-rates-11.md) | Optional | Container all rates associated with the transaction. | WtgRates11 getRates() | setRates(WtgRates11 rates) |

## Example (as XML)

```xml
<wtg:Package xmlns:wtg="https://www.wisetechglobal.com/">
  <wtg:RecordIdentifiers xmlns:wtg="https://www.wisetechglobal.com/" />
  <wtg:Status xmlns:wtg="https://www.wisetechglobal.com/">
    <wtg:Code>108</wtg:Code>
    <wtg:Warnings />
    <wtg:Errors />
  </wtg:Status>
  <wtg:Insurance xmlns:wtg="https://www.wisetechglobal.com/" />
  <wtg:International xmlns:wtg="https://www.wisetechglobal.com/" />
  <wtg:Labels xmlns:wtg="https://www.wisetechglobal.com/" />
  <wtg:Documents xmlns:wtg="https://www.wisetechglobal.com/" />
  <wtg:Shipping xmlns:wtg="https://www.wisetechglobal.com/" />
  <wtg:Customer xmlns:wtg="https://www.wisetechglobal.com/" />
  <wtg:Rates xmlns:wtg="https://www.wisetechglobal.com/" />
</wtg:Package>
```

