
# Wtg Pierbridge End of Day Document Get Request

Fetches the documents assocaited with an existing end of day transaction started using the EndOfDayAction request.

## Structure

`WtgPierbridgeEndOfDayDocumentGetRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `TransactionIdentifier` | `String` | Optional | A unique identifier for the transaction, this value is not used during processing and will be returned in the response. | String getTransactionIdentifier() | setTransactionIdentifier(String transactionIdentifier) |
| `ControlIdentifier` | `String` | Optional | A reference to a control which generated the request, this value is not used during processing and will be returned in the response. | String getControlIdentifier() | setControlIdentifier(String controlIdentifier) |
| `UserName` | `String` | Required | The user name to use when processing the transaction. | String getUserName() | setUserName(String userName) |
| `NumberOfDays` | `Integer` | Optional | Number of days to return information for.  Defaults to 7 days if omitted.<br>**Default**: `0` | Integer getNumberOfDays() | setNumberOfDays(Integer numberOfDays) |
| `Carrier` | `Integer` | Optional | Numeric identifier for the carrier.<br>**Default**: `0` | Integer getCarrier() | setCarrier(Integer carrier) |
| `AccountID` | `Integer` | Optional | Account to return information for.<br>**Default**: `0` | Integer getAccountID() | setAccountID(Integer accountID) |
| `EndOfDayID` | `Integer` | Optional | End Of Day process to return information for.<br>**Default**: `0` | Integer getEndOfDayID() | setEndOfDayID(Integer endOfDayID) |
| `StartDate` | `String` | Optional | Date to use when filtering EOD Get Requests. | String getStartDate() | setStartDate(String startDate) |
| `Diagnostics` | [`WtgDiagnostics`](../../doc/models/wtg-diagnostics.md) | Optional | Container for logging and diagnostic override elements. | WtgDiagnostics getDiagnostics() | setDiagnostics(WtgDiagnostics diagnostics) |
| `Identification` | [`WtgIdentification`](../../doc/models/wtg-identification.md) | Optional | Container for client identification elements. | WtgIdentification getIdentification() | setIdentification(WtgIdentification identification) |

## Example (as XML)

```xml
<wtg:PierbridgeEndOfDayDocumentGetRequest xmlns:wtg="https://www.wisetechglobal.com/">
  <wtg:UserName xmlns:wtg="https://www.wisetechglobal.com/">UserName6</wtg:UserName>
  <wtg:Diagnostics xmlns:wtg="https://www.wisetechglobal.com/" />
  <wtg:Identification xmlns:wtg="https://www.wisetechglobal.com/" />
</wtg:PierbridgeEndOfDayDocumentGetRequest>
```

