
# Wtg Package 3

Container for an individual package associated with the transaction.

## Structure

`WtgPackage3`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Status` | [`WtgStatus`](../../doc/models/wtg-status.md) | Required | Container for transaction errors and warning elements. | WtgStatus getStatus() | setStatus(WtgStatus status) |
| `RecordIdentifiers` | [`WtgRecordIdentifiers`](../../doc/models/wtg-record-identifiers.md) | Optional | Outer container for transaction identifiers. | WtgRecordIdentifiers getRecordIdentifiers() | setRecordIdentifiers(WtgRecordIdentifiers recordIdentifiers) |
| `AdditionalHandling` | `Boolean` | Optional | Indicates that extra handling measures are required when loading the package.<br>**Default**: `false` | Boolean getAdditionalHandling() | setAdditionalHandling(Boolean additionalHandling) |
| `Oversize` | `Integer` | Optional | Indicates if the item is over standard size dimensions.<br>**Default**: `0` | Integer getOversize() | setOversize(Integer oversize) |
| `PackageType` | `Integer` | Optional | Numeric identifier for the carrier package type.<br>**Default**: `0` | Integer getPackageType() | setPackageType(Integer packageType) |
| `FreightClass` | `String` | Optional | The freight class of the package's content. | String getFreightClass() | setFreightClass(String freightClass) |
| `Currency` | `String` | Optional | The currency code associated with the transaction. | String getCurrency() | setCurrency(String currency) |
| `Weight` | `Double` | Optional | The weight of the package.<br>**Default**: `0d` | Double getWeight() | setWeight(Double weight) |
| `ISOCurrencyId` | `Integer` | Optional | The ID of the ISO Currency code in use.<br>**Default**: `0` | Integer getISOCurrencyId() | setISOCurrencyId(Integer iSOCurrencyId) |
| `ShipperReference` | `String` | Optional | Primary shipping reference number. | String getShipperReference() | setShipperReference(String shipperReference) |
| `PackageReference` | `String` | Optional | Package reference number. | String getPackageReference() | setPackageReference(String packageReference) |
| `PackageID` | `Integer` | Optional | Unique identifier for the package.<br>**Default**: `0` | Integer getPackageID() | setPackageID(Integer packageID) |
| `Shipping` | [`WtgShipping`](../../doc/models/wtg-shipping.md) | Optional | Container for shipping associated with the transaction. | WtgShipping getShipping() | setShipping(WtgShipping shipping) |
| `Customer` | [`WtgCustomer`](../../doc/models/wtg-customer.md) | Optional | Container for customer details. | WtgCustomer getCustomer() | setCustomer(WtgCustomer customer) |
| `International` | [`WtgInternational3`](../../doc/models/wtg-international-3.md) | Optional | Container for international details associated with the shipment. | WtgInternational3 getInternational() | setInternational(WtgInternational3 international) |
| `Rates` | [`WtgRates1`](../../doc/models/wtg-rates-1.md) | Optional | Container all rates associated with the transaction. | WtgRates1 getRates() | setRates(WtgRates1 rates) |

## Example (as XML)

```xml
<wtg:Package xmlns:wtg="https://www.wisetechglobal.com/">
  <wtg:Status xmlns:wtg="https://www.wisetechglobal.com/">
    <wtg:Code>108</wtg:Code>
    <wtg:Warnings />
    <wtg:Errors />
  </wtg:Status>
  <wtg:RecordIdentifiers xmlns:wtg="https://www.wisetechglobal.com/" />
  <wtg:Shipping xmlns:wtg="https://www.wisetechglobal.com/" />
  <wtg:Customer xmlns:wtg="https://www.wisetechglobal.com/" />
  <wtg:International xmlns:wtg="https://www.wisetechglobal.com/" />
  <wtg:Rates xmlns:wtg="https://www.wisetechglobal.com/" />
</wtg:Package>
```

