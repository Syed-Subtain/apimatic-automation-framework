
# Wtg Sender 8

Container to allow the tracking by Sender DepartmentName.

## Structure

`WtgSender8`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `DepartmentName` | `String` | Optional | Department name of the individual sending the shipment. | String getDepartmentName() | setDepartmentName(String departmentName) |

## Example (as XML)

```xml
<wtg:Sender xmlns:wtg="https://www.wisetechglobal.com/" />
```

