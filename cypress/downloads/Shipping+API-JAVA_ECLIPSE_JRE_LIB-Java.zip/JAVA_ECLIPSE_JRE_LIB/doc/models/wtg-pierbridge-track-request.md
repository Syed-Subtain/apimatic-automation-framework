
# Wtg Pierbridge Track Request

Requests the latest tracking status of a shipment with a carrier.

## Structure

`WtgPierbridgeTrackRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `TransactionIdentifier` | `String` | Optional | A unique identifier for the transaction, this value is not used during processing and will be returned in the response. | String getTransactionIdentifier() | setTransactionIdentifier(String transactionIdentifier) |
| `ControlIdentifier` | `String` | Optional | A reference to a control which generated the request, this value is not used during processing and will be returned in the response. | String getControlIdentifier() | setControlIdentifier(String controlIdentifier) |
| `UserName` | `String` | Required | The user name to use when processing the transaction.<br>**Constraints**: *Minimum Length*: `1` | String getUserName() | setUserName(String userName) |
| `Live` | `Boolean` | Optional | Indicates whether the transaction is a test or live.  Defaults to system configured value if not submitted.<br>**Default**: `false` | Boolean getLive() | setLive(Boolean live) |
| `Carrier` | `Integer` | Optional | Numeric identifier for the carrier.<br>**Default**: `0` | Integer getCarrier() | setCarrier(Integer carrier) |
| `BoLNumber` | `String` | Optional | BoL Number of the shipment to track. | String getBoLNumber() | setBoLNumber(String boLNumber) |
| `Sender` | [`WtgSender8`](../../doc/models/wtg-sender-8.md) | Optional | Container to allow the tracking by Sender DepartmentName. | WtgSender8 getSender() | setSender(WtgSender8 sender) |
| `Packages` | [`WtgPackages21`](../../doc/models/wtg-packages-21.md) | Required | Container for all packages associated with the transaction. | WtgPackages21 getPackages() | setPackages(WtgPackages21 packages) |
| `Diagnostics` | [`WtgDiagnostics`](../../doc/models/wtg-diagnostics.md) | Optional | Container for logging and diagnostic override elements. | WtgDiagnostics getDiagnostics() | setDiagnostics(WtgDiagnostics diagnostics) |
| `Identification` | [`WtgIdentification`](../../doc/models/wtg-identification.md) | Optional | Container for client identification elements. | WtgIdentification getIdentification() | setIdentification(WtgIdentification identification) |

## Example (as XML)

```xml
<wtg:PierbridgeTrackRequest xmlns:wtg="https://www.wisetechglobal.com/">
  <wtg:UserName xmlns:wtg="https://www.wisetechglobal.com/">UserName6</wtg:UserName>
  <wtg:Sender xmlns:wtg="https://www.wisetechglobal.com/" />
  <wtg:Packages xmlns:wtg="https://www.wisetechglobal.com/">
    <wtg:Package />
    <wtg:Package />
    <wtg:Package />
  </wtg:Packages>
  <wtg:Diagnostics xmlns:wtg="https://www.wisetechglobal.com/" />
  <wtg:Identification xmlns:wtg="https://www.wisetechglobal.com/" />
</wtg:PierbridgeTrackRequest>
```

