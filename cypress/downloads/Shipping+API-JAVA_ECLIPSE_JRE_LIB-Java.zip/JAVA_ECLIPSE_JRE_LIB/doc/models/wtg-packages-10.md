
# Wtg Packages 10

Container for all packages associated with the transaction.

## Structure

`WtgPackages10`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Package` | [`List<WtgPackage11>`](../../doc/models/wtg-package-11.md) | Required | Container for an individual package associated with the transaction. | List<WtgPackage11> getPackage() | setPackage(List<WtgPackage11> mPackage) |

## Example (as XML)

```xml
<wtg:Packages xmlns:wtg="https://www.wisetechglobal.com/">
  <wtg:Package xmlns:wtg="https://www.wisetechglobal.com/">
    <wtg:RecordIdentifiers />
    <wtg:SpecialCare />
    <wtg:LithiumBatteryDetails />
    <wtg:Insurance />
    <wtg:COD />
    <wtg:Holder />
    <wtg:International />
    <wtg:Rates />
  </wtg:Package>
</wtg:Packages>
```

