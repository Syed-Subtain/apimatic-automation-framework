
# Wtg Override Type Enum

## Enumeration

`WtgOverrideTypeEnum`

## Fields

| Name |
|  --- |
| `OverrideAll` |
| `OverrideNonessential` |
| `None` |

