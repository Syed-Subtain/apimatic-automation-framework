
# Wtg International

Container for international details associated with the shipment.

## Structure

`WtgInternational`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Contents` | [`WtgContents1`](../../doc/models/wtg-contents-1.md) | Optional | Container for all contents (line items) associated with the transaction. | WtgContents1 getContents() | setContents(WtgContents1 contents) |

## Example (as XML)

```xml
<wtg:International xmlns:wtg="https://www.wisetechglobal.com/">
  <wtg:Contents xmlns:wtg="https://www.wisetechglobal.com/" />
</wtg:International>
```

