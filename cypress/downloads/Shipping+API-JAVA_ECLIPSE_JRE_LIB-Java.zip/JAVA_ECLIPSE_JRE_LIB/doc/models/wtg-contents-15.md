
# Wtg Contents 15

Container for all contents (line items) associated with the transaction.

## Structure

`WtgContents15`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Content` | [`List<WtgContent15>`](../../doc/models/wtg-content-15.md) | Optional | Container for a individual content (line item) associated with the transaction. | List<WtgContent15> getContent() | setContent(List<WtgContent15> content) |

## Example (as XML)

```xml
<wtg:Contents xmlns:wtg="https://www.wisetechglobal.com/" />
```

