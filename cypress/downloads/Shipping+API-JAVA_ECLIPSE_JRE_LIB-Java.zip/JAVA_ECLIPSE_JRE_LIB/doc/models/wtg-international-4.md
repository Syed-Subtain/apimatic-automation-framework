
# Wtg International 4

Container for international details associated with the shipment.

## Structure

`WtgInternational4`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Contents` | [`WtgContents5`](../../doc/models/wtg-contents-5.md) | Optional | Container for all contents (line items) associated with the transaction. | WtgContents5 getContents() | setContents(WtgContents5 contents) |

## Example (as XML)

```xml
<wtg:International xmlns:wtg="https://www.wisetechglobal.com/">
  <wtg:Contents xmlns:wtg="https://www.wisetechglobal.com/" />
</wtg:International>
```

