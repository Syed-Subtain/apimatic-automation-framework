
# Wtg International 13

Container for international details associated with the shipment.

## Structure

`WtgInternational13`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `ReceiverCustomsIdentificationNumber` | `String` | Optional | Customs Identification number of the receiver. | String getReceiverCustomsIdentificationNumber() | setReceiverCustomsIdentificationNumber(String receiverCustomsIdentificationNumber) |
| `ReceiverCustomsIdentificationType` | [`WtgReceiverCustomsIdentificationTypeEnum`](../../doc/models/wtg-receiver-customs-identification-type-enum.md) | Optional | Customs Identification Type of the receiver.. | WtgReceiverCustomsIdentificationTypeEnum getReceiverCustomsIdentificationType() | setReceiverCustomsIdentificationType(WtgReceiverCustomsIdentificationTypeEnum receiverCustomsIdentificationType) |
| `CustomsInsuranceChargesValue` | `Double` | Optional | Customs Insurance Charges value. | Double getCustomsInsuranceChargesValue() | setCustomsInsuranceChargesValue(Double customsInsuranceChargesValue) |
| `CustomsInsuranceChargesCurrency` | `String` | Optional | Customs Insurance Charges currency. | String getCustomsInsuranceChargesCurrency() | setCustomsInsuranceChargesCurrency(String customsInsuranceChargesCurrency) |
| `IsInternational` | `Boolean` | Optional | Indicates whether the package is part of an international shipment.  Defaults to no if omitted.<br>**Default**: `false` | Boolean getIsInternational() | setIsInternational(Boolean isInternational) |
| `NonDutiable` | `Boolean` | Optional | Indicates whether the package contains only non-dutiable goods.  Defaults to no if omitted.<br>**Default**: `false` | Boolean getNonDutiable() | setNonDutiable(Boolean nonDutiable) |
| `DocumentsOnly` | `Boolean` | Optional | Indicates whether the package contains only documents.  Defaults to not documents only if omitted.<br>**Default**: `false` | Boolean getDocumentsOnly() | setDocumentsOnly(Boolean documentsOnly) |
| `PrePackedBoxes` | [`WtgPrePackedBoxes`](../../doc/models/wtg-pre-packed-boxes.md) | Optional | pre-packed boxes, including any items specified that will be packed and excess space used before any new boxes are created. | WtgPrePackedBoxes getPrePackedBoxes() | setPrePackedBoxes(WtgPrePackedBoxes prePackedBoxes) |
| `Contents` | [`WtgContents9`](../../doc/models/wtg-contents-9.md) | Optional | Container for all contents (line items) associated with the transaction. | WtgContents9 getContents() | setContents(WtgContents9 contents) |

## Example (as XML)

```xml
<wtg:International xmlns:wtg="https://www.wisetechglobal.com/">
  <wtg:PrePackedBoxes xmlns:wtg="https://www.wisetechglobal.com/" />
  <wtg:Contents xmlns:wtg="https://www.wisetechglobal.com/" />
</wtg:International>
```

