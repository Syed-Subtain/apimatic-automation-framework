
# Wtg Pierbridge End of Day List Request

Fetches a list of all open manifests that can be closed using the criteria given.

## Structure

`WtgPierbridgeEndOfDayListRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `TransactionIdentifier` | `String` | Optional | A unique identifier for the transaction, this value is not used during processing and will be returned in the response. | String getTransactionIdentifier() | setTransactionIdentifier(String transactionIdentifier) |
| `ControlIdentifier` | `String` | Optional | A reference to a control which generated the request, this value is not used during processing and will be returned in the response. | String getControlIdentifier() | setControlIdentifier(String controlIdentifier) |
| `UserName` | `String` | Required | The user name to use when processing the transaction. | String getUserName() | setUserName(String userName) |
| `Carrier` | `int` | Required | Numeric identifier for the carrier. | int getCarrier() | setCarrier(int carrier) |
| `Live` | `Boolean` | Optional | Indicates whether the transaction is a test or live.  Defaults to system configured value if not submitted.<br>**Default**: `false` | Boolean getLive() | setLive(Boolean live) |
| `Accounts` | [`WtgAccounts`](../../doc/models/wtg-accounts.md) | Optional | Container for accounts. | WtgAccounts getAccounts() | setAccounts(WtgAccounts accounts) |
| `Diagnostics` | [`WtgDiagnostics`](../../doc/models/wtg-diagnostics.md) | Optional | Container for logging and diagnostic override elements. | WtgDiagnostics getDiagnostics() | setDiagnostics(WtgDiagnostics diagnostics) |
| `Identification` | [`WtgIdentification`](../../doc/models/wtg-identification.md) | Optional | Container for client identification elements. | WtgIdentification getIdentification() | setIdentification(WtgIdentification identification) |

## Example (as XML)

```xml
<wtg:PierbridgeEndOfDayListRequest xmlns:wtg="https://www.wisetechglobal.com/">
  <wtg:UserName xmlns:wtg="https://www.wisetechglobal.com/">UserName6</wtg:UserName>
  <wtg:Carrier xmlns:wtg="https://www.wisetechglobal.com/">34</wtg:Carrier>
  <wtg:Accounts xmlns:wtg="https://www.wisetechglobal.com/" />
  <wtg:Diagnostics xmlns:wtg="https://www.wisetechglobal.com/" />
  <wtg:Identification xmlns:wtg="https://www.wisetechglobal.com/" />
</wtg:PierbridgeEndOfDayListRequest>
```

