
# Wtg Orders 3

Container all orders associated with the transaction.

## Structure

`WtgOrders3`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Order` | [`List<WtgOrder3>`](../../doc/models/wtg-order-3.md) | Optional | Container for an individual order. | List<WtgOrder3> getOrder() | setOrder(List<WtgOrder3> order) |

## Example (as XML)

```xml
<wtg:Orders xmlns:wtg="https://www.wisetechglobal.com/" />
```

