
# Wtg Cost Center Mode Enum

## Enumeration

`WtgCostCenterModeEnum`

## Fields

| Name |
|  --- |
| `Default` |
| `AutoValidate` |

