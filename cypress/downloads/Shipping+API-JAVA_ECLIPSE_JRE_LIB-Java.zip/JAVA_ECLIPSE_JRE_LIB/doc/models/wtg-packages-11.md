
# Wtg Packages 11

Container for all packages associated with the transaction.

## Structure

`WtgPackages11`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Package` | [`List<WtgPackage12>`](../../doc/models/wtg-package-12.md) | Required | Container for an individual package associated with the transaction. | List<WtgPackage12> getPackage() | setPackage(List<WtgPackage12> mPackage) |

## Example (as XML)

```xml
<wtg:Packages xmlns:wtg="https://www.wisetechglobal.com/">
  <wtg:Package xmlns:wtg="https://www.wisetechglobal.com/">
    <wtg:Rates />
  </wtg:Package>
</wtg:Packages>
```

