
# Wtg Amount

Container for net explosive amount details.

## Structure

`WtgAmount`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Quantity` | `Double` | Optional | Net explosive quantity. | Double getQuantity() | setQuantity(Double quantity) |
| `UOM` | `String` | Optional | Net explosive units of measure. | String getUOM() | setUOM(String uOM) |

## Example (as XML)

```xml
<wtg:Amount xmlns:wtg="https://www.wisetechglobal.com/" />
```

