
# Wtg Invoice Debtor

Container for invoice debtor details associated with the transaction.

## Structure

`WtgInvoiceDebtor`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `OrganizationCode` | `String` | Optional | Organization code for invoice debtor. | String getOrganizationCode() | setOrganizationCode(String organizationCode) |

## Example (as XML)

```xml
<wtg:InvoiceDebtor xmlns:wtg="https://www.wisetechglobal.com/" />
```

