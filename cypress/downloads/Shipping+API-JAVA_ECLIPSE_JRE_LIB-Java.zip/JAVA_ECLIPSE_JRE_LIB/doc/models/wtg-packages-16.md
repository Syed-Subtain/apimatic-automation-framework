
# Wtg Packages 16

Container for all packages associated with the transaction.

## Structure

`WtgPackages16`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Package` | [`List<WtgPackage17>`](../../doc/models/wtg-package-17.md) | Required | Container for an individual package associated with the transaction. | List<WtgPackage17> getPackage() | setPackage(List<WtgPackage17> mPackage) |

## Example (as XML)

```xml
<wtg:Packages xmlns:wtg="https://www.wisetechglobal.com/">
  <wtg:Package xmlns:wtg="https://www.wisetechglobal.com/">
    <wtg:Status>
      <wtg:Code>76</wtg:Code>
      <wtg:Warnings />
      <wtg:Errors />
    </wtg:Status>
  </wtg:Package>
</wtg:Packages>
```

