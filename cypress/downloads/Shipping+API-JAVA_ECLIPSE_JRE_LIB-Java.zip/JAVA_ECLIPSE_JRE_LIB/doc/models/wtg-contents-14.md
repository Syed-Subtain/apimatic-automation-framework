
# Wtg Contents 14

Container for all contents (line items) associated with the transaction.

## Structure

`WtgContents14`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Content` | [`List<WtgContent14>`](../../doc/models/wtg-content-14.md) | Optional | Container for a individual content (line item) associated with the transaction. | List<WtgContent14> getContent() | setContent(List<WtgContent14> content) |

## Example (as XML)

```xml
<wtg:Contents xmlns:wtg="https://www.wisetechglobal.com/" />
```

