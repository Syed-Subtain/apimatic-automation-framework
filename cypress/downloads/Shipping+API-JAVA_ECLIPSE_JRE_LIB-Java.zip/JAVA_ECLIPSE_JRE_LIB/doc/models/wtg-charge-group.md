
# Wtg Charge Group

Container for an individual charge group associated with the transaction.

## Structure

`WtgChargeGroup`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `ChargeGroupType` | `int` | Required | An identifier for the type of the charge group. | int getChargeGroupType() | setChargeGroupType(int chargeGroupType) |
| `ChargeGroupDescription` | `String` | Required | The description for the group of charges. | String getChargeGroupDescription() | setChargeGroupDescription(String chargeGroupDescription) |
| `ChargeGroupValue` | `double` | Required | The value of the charge group associated with the transaction.<br>**Default**: `0d` | double getChargeGroupValue() | setChargeGroupValue(double chargeGroupValue) |
| `ChargeGroupCurrency` | `String` | Optional | A code indicating the type of currency for the charges group. | String getChargeGroupCurrency() | setChargeGroupCurrency(String chargeGroupCurrency) |
| `ChargeGroupISOCurrency` | `Integer` | Optional | ISO code for the currency associated with the transaction.<br>**Default**: `0` | Integer getChargeGroupISOCurrency() | setChargeGroupISOCurrency(Integer chargeGroupISOCurrency) |
| `ChargeGroupISOCurrencySymbol` | `String` | Optional | Currency symbol for the charge group currency. | String getChargeGroupISOCurrencySymbol() | setChargeGroupISOCurrencySymbol(String chargeGroupISOCurrencySymbol) |
| `Charges` | [`WtgCharges`](../../doc/models/wtg-charges.md) | Required | Container for all charges within the group associated with the transaction. | WtgCharges getCharges() | setCharges(WtgCharges charges) |

## Example (as XML)

```xml
<wtg:ChargeGroup xmlns:wtg="https://www.wisetechglobal.com/">
  <wtg:ChargeGroupValue xmlns:wtg="https://www.wisetechglobal.com/">0</wtg:ChargeGroupValue>
  <wtg:Charges xmlns:wtg="https://www.wisetechglobal.com/" />
</wtg:ChargeGroup>
```

