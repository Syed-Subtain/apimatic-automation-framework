
# Wtg Abbreviation Enum

## Enumeration

`WtgAbbreviationEnum`

## Fields

| Name |
|  --- |
| `NEM` |
| `NEC` |
| `NEQ` |
| `NEW` |
| `Unknown` |

