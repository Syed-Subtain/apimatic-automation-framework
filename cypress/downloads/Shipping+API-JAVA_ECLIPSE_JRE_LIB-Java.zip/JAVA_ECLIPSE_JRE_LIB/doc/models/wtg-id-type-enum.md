
# Wtg ID Type Enum

## Enumeration

`WtgIDTypeEnum`

## Fields

| Name |
|  --- |
| `Enum1` |
| `Enum2` |
| `Enum3` |
| `Enum4` |

