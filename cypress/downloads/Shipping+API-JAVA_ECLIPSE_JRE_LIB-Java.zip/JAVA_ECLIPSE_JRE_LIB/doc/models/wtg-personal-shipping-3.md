
# Wtg Personal Shipping 3

Container for personal shipping elements.

## Structure

`WtgPersonalShipping3`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `PersonalShipment` | `Boolean` | Optional | Indicates that shipment is a personal shipment.<br>**Default**: `false` | Boolean getPersonalShipment() | setPersonalShipment(Boolean personalShipment) |
| `PaymentMethodID` | `String` | Optional | The id of the payment method used to pay for a personal shipment. | String getPaymentMethodID() | setPaymentMethodID(String paymentMethodID) |
| `ChargeID` | `String` | Optional | The id of the payment used to pay for a personal shipment. | String getChargeID() | setChargeID(String chargeID) |
| `TotalCharge` | `Double` | Optional | Cost that the customer will be charged for the personal shipment.<br>**Default**: `0d` | Double getTotalCharge() | setTotalCharge(Double totalCharge) |
| `ConvenienceFee` | `Double` | Optional | Cost to the user for processing a personal shipment. This cost is included in the total cost<br>**Default**: `0d` | Double getConvenienceFee() | setConvenienceFee(Double convenienceFee) |
| `CustomerID` | `String` | Optional | User specific cusetomer ID with payment processor<br>**Default**: `"false"` | String getCustomerID() | setCustomerID(String customerID) |

## Example (as XML)

```xml
<wtg:PersonalShipping xmlns:wtg="https://www.wisetechglobal.com/" />
```

