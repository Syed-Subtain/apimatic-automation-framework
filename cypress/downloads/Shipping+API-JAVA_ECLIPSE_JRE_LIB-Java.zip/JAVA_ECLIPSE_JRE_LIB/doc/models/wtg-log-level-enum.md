
# Wtg Log Level Enum

## Enumeration

`WtgLogLevelEnum`

## Fields

| Name |
|  --- |
| `Error` |
| `Warn` |
| `Info` |
| `Debug` |
| `Trace` |

