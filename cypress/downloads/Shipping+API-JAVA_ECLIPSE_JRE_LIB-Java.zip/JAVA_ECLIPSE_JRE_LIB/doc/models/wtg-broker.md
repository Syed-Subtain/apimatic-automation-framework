
# Wtg Broker

Container for broker details.

## Structure

`WtgBroker`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `BrokerID` | `Integer` | Optional | Export broker who will handle the shipment.<br>**Default**: `0` | Integer getBrokerID() | setBrokerID(Integer brokerID) |

## Example (as XML)

```xml
<wtg:Broker xmlns:wtg="https://www.wisetechglobal.com/" />
```

