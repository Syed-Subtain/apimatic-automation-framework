
# Wtg Packages 6

Container for all packages relating to the specific rate.

## Structure

`WtgPackages6`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Package` | [`List<WtgPackage6>`](../../doc/models/wtg-package-6.md) | Optional | Container for package level information about the rate returned. | List<WtgPackage6> getPackage() | setPackage(List<WtgPackage6> mPackage) |

## Example (as XML)

```xml
<wtg:Packages xmlns:wtg="https://www.wisetechglobal.com/" />
```

