
# Wtg Documents 2

Container for documents to be printed by the caller of the transaction (client).

## Structure

`WtgDocuments2`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Output` | [`List<WtgOutput5>`](../../doc/models/wtg-output-5.md) | Optional | Container for documents to be printed externally from the transaction. | List<WtgOutput5> getOutput() | setOutput(List<WtgOutput5> output) |

## Example (as XML)

```xml
<wtg:Documents xmlns:wtg="https://www.wisetechglobal.com/" />
```

