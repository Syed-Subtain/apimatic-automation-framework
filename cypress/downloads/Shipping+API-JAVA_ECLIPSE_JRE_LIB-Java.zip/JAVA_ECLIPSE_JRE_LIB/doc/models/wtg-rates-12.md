
# Wtg Rates 12

Container all rates associated with the transaction.

## Structure

`WtgRates12`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Rate` | [`List<WtgRate12>`](../../doc/models/wtg-rate-12.md) | Optional | Container for an individual rate. | List<WtgRate12> getRate() | setRate(List<WtgRate12> rate) |

## Example (as XML)

```xml
<wtg:Rates xmlns:wtg="https://www.wisetechglobal.com/" />
```

