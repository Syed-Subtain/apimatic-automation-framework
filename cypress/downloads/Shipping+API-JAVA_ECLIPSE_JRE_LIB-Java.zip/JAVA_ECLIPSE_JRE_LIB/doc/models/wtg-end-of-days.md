
# Wtg End of Days

Container for end of day details.

## Structure

`WtgEndOfDays`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `EndOfDay` | [`List<WtgEndOfDay>`](../../doc/models/wtg-end-of-day.md) | Optional | Container for an individual end of day record. | List<WtgEndOfDay> getEndOfDay() | setEndOfDay(List<WtgEndOfDay> endOfDay) |

## Example (as XML)

```xml
<wtg:EndOfDays xmlns:wtg="https://www.wisetechglobal.com/" />
```

