
# Wtg Cartonization 4

Container for cartonization data for the Cartonization Group.

## Structure

`WtgCartonization4`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `CartonizationGroupID` | `Integer` | Optional | Numeric identifier for a cartonization group.<br>**Default**: `0` | Integer getCartonizationGroupID() | setCartonizationGroupID(Integer cartonizationGroupID) |
| `SVGData` | `String` | Optional | Html that contains the visualization web page that represents the cartonized items. | String getSVGData() | setSVGData(String sVGData) |
| `JSONBoxData` | `String` | Optional | Html that contains the json data that represents the cartonized items. | String getJSONBoxData() | setJSONBoxData(String jSONBoxData) |
| `Packages` | [`WtgPackages9`](../../doc/models/wtg-packages-9.md) | Required | Container for all packages associated with the transaction. | WtgPackages9 getPackages() | setPackages(WtgPackages9 packages) |

## Example (as XML)

```xml
<wtg:Cartonization xmlns:wtg="https://www.wisetechglobal.com/">
  <wtg:Packages xmlns:wtg="https://www.wisetechglobal.com/" />
</wtg:Cartonization>
```

