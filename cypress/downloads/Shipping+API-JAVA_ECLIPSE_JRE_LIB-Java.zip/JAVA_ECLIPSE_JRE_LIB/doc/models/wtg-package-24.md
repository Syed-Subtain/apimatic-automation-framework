
# Wtg Package 24

Container for an individual package associated with the transaction.

## Structure

`WtgPackage24`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `PackageID` | `Integer` | Optional | Identifier of the package to void.  Must submit shipment identifier, shipment group identifier, package identifier or tracking number.<br>**Default**: `0` | Integer getPackageID() | setPackageID(Integer packageID) |
| `WayBillNumber` | `String` | Optional | Tracking Number of the package to void.  Must submit shipment identifier, shipment group identifier, package identifier or tracking number. | String getWayBillNumber() | setWayBillNumber(String wayBillNumber) |

## Example (as XML)

```xml
<wtg:Package xmlns:wtg="https://www.wisetechglobal.com/" />
```

