
# Wtg Order 2

Container for an individual order.

## Structure

`WtgOrder2`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `OrderID` | `Integer` | Optional | Identifier of the order being shipped.<br>**Default**: `0` | Integer getOrderID() | setOrderID(Integer orderID) |
| `OrderNumber` | `String` | Optional | Number of the order being shipped. | String getOrderNumber() | setOrderNumber(String orderNumber) |
| `ReleaseNumber` | `String` | Optional | Release number of the order being shipped. | String getReleaseNumber() | setReleaseNumber(String releaseNumber) |
| `OrderReference1` | `String` | Optional | First order reference number. | String getOrderReference1() | setOrderReference1(String orderReference1) |
| `OrderReference2` | `String` | Optional | Second order reference number. | String getOrderReference2() | setOrderReference2(String orderReference2) |
| `OrderReference3` | `String` | Optional | Third order reference number. | String getOrderReference3() | setOrderReference3(String orderReference3) |
| `SalesOrderNumber` | `String` | Optional | Sales order number of the order being shipped. | String getSalesOrderNumber() | setSalesOrderNumber(String salesOrderNumber) |
| `PurchaseOrderNumber` | `String` | Optional | Purchase order number of the order being shipped. | String getPurchaseOrderNumber() | setPurchaseOrderNumber(String purchaseOrderNumber) |
| `PickLists` | [`WtgPickLists1`](../../doc/models/wtg-pick-lists-1.md) | Optional | Container all order picklists. | WtgPickLists1 getPickLists() | setPickLists(WtgPickLists1 pickLists) |

## Example (as XML)

```xml
<wtg:Order xmlns:wtg="https://www.wisetechglobal.com/">
  <wtg:PickLists xmlns:wtg="https://www.wisetechglobal.com/" />
</wtg:Order>
```

