
# Wtg Broker Type Enum

## Enumeration

`WtgBrokerTypeEnum`

## Fields

| Name |
|  --- |
| `Enum0` |
| `Enum1` |
| `Enum2` |

