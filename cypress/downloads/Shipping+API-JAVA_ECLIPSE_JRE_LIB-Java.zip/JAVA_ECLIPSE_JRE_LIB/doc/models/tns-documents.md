
# Tns Documents

Container for documents to be printed by the caller of the transaction (client).

## Structure

`TnsDocuments`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Output` | [`List<TnsOutput>`](../../doc/models/tns-output.md) | Optional | Container for documents to be printed externally from the transaction. | List<TnsOutput> getOutput() | setOutput(List<TnsOutput> output) |

## Example (as JSON)

```json
{
  "Output": null
}
```

