
# Wtg Consolidation Data Source Type Enum

## Enumeration

`WtgConsolidationDataSourceTypeEnum`

## Fields

| Name |
|  --- |
| `Enum1` |
| `Enum2` |

