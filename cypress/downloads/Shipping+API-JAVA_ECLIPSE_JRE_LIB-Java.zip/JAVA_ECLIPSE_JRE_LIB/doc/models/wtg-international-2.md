
# Wtg International 2

Container for international details associated with the shipment.

## Structure

`WtgInternational2`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `IsInternational` | `Boolean` | Optional | Indicates whether the package is part of an international shipment.  Defaults to no if omitted.<br>**Default**: `false` | Boolean getIsInternational() | setIsInternational(Boolean isInternational) |
| `NonDutiable` | `Boolean` | Optional | Indicates whether the package contains only non-dutiable goods.  Defaults to no if omitted.<br>**Default**: `false` | Boolean getNonDutiable() | setNonDutiable(Boolean nonDutiable) |
| `DocumentsOnly` | `Boolean` | Optional | Indicates whether the package contains only documents.  Defaults to not documents only if omitted.<br>**Default**: `false` | Boolean getDocumentsOnly() | setDocumentsOnly(Boolean documentsOnly) |
| `PrePackedBoxes` | [`WtgPrePackedBoxes`](../../doc/models/wtg-pre-packed-boxes.md) | Optional | pre-packed boxes, including any items specified that will be packed and excess space used before any new boxes are created. | WtgPrePackedBoxes getPrePackedBoxes() | setPrePackedBoxes(WtgPrePackedBoxes prePackedBoxes) |
| `Contents` | [`WtgContents2`](../../doc/models/wtg-contents-2.md) | Optional | Container for all contents (line items) associated with the transaction. | WtgContents2 getContents() | setContents(WtgContents2 contents) |

## Example (as XML)

```xml
<wtg:International xmlns:wtg="https://www.wisetechglobal.com/">
  <wtg:PrePackedBoxes xmlns:wtg="https://www.wisetechglobal.com/" />
  <wtg:Contents xmlns:wtg="https://www.wisetechglobal.com/" />
</wtg:International>
```

