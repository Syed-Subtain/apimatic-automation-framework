
# Wtg Rate 13

Container for an individual rate associated with the transaction.

## Structure

`WtgRate13`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `RateType` | `Integer` | Optional | A numeric identifier that identifies the rate type.<br>**Default**: `0` | Integer getRateType() | setRateType(Integer rateType) |
| `Charges` | [`WtgCharges12`](../../doc/models/wtg-charges-12.md) | Required | Container for all charges within the group associated with the transaction. | WtgCharges12 getCharges() | setCharges(WtgCharges12 charges) |

## Example (as XML)

```xml
<wtg:Rate xmlns:wtg="https://www.wisetechglobal.com/">
  <wtg:Charges xmlns:wtg="https://www.wisetechglobal.com/" />
</wtg:Rate>
```

