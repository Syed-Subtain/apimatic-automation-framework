
# Wtg Charges 13

Container for all charges within the group associated with the package

## Structure

`WtgCharges13`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Charge` | [`List<WtgCharge13>`](../../doc/models/wtg-charge-13.md) | Optional | Container for an individual charge associated with the package | List<WtgCharge13> getCharge() | setCharge(List<WtgCharge13> charge) |

## Example (as XML)

```xml
<wtg:Charges xmlns:wtg="https://www.wisetechglobal.com/" />
```

