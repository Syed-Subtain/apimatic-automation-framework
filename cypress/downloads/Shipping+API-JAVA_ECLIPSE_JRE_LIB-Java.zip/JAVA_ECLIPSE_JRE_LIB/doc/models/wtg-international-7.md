
# Wtg International 7

Container for international details associated with the shipment.

## Structure

`WtgInternational7`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Contents` | [`WtgContents7`](../../doc/models/wtg-contents-7.md) | Optional | Container for all contents (line items) associated with the transaction. | WtgContents7 getContents() | setContents(WtgContents7 contents) |

## Example (as XML)

```xml
<wtg:International xmlns:wtg="https://www.wisetechglobal.com/">
  <wtg:Contents xmlns:wtg="https://www.wisetechglobal.com/" />
</wtg:International>
```

