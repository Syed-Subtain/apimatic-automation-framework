
# Wtg Charge 10

Container for an individual charge within the group associated with the transaction.

## Structure

`WtgCharge10`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `RateType` | `Integer` | Optional | The rate type associated with the charge for the package.<br>**Default**: `0` | Integer getRateType() | setRateType(Integer rateType) |
| `ChargeType` | `Integer` | Optional | The charge type associated with the charge for the package.<br>**Default**: `0` | Integer getChargeType() | setChargeType(Integer chargeType) |
| `ChargeValue` | `Double` | Optional | The charge value associated with the charge for the package.<br>**Default**: `0d` | Double getChargeValue() | setChargeValue(Double chargeValue) |
| `ChargeCurrency` | `String` | Optional | The charge currency associated with the charge for the package. | String getChargeCurrency() | setChargeCurrency(String chargeCurrency) |

## Example (as XML)

```xml
<wtg:Charge xmlns:wtg="https://www.wisetechglobal.com/" />
```

