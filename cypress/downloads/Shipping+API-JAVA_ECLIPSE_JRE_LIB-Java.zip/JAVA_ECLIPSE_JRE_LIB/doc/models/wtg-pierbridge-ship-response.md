
# Wtg Pierbridge Ship Response

Indicates the status of a Ship request.

## Structure

`WtgPierbridgeShipResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `TransactionIdentifier` | `String` | Optional | The unique identifier for the transaction given in the request. | String getTransactionIdentifier() | setTransactionIdentifier(String transactionIdentifier) |
| `ControlIdentifier` | `String` | Optional | The control reference for the transaction given in the request. | String getControlIdentifier() | setControlIdentifier(String controlIdentifier) |
| `CustomerVendorNumber` | `String` | Optional | A customer vendor number associated with the transaction. | String getCustomerVendorNumber() | setCustomerVendorNumber(String customerVendorNumber) |
| `Status` | [`WtgStatus`](../../doc/models/wtg-status.md) | Required | Container for transaction errors and warning elements. | WtgStatus getStatus() | setStatus(WtgStatus status) |
| `Orders` | [`WtgOrders3`](../../doc/models/wtg-orders-3.md) | Optional | Container all orders associated with the transaction. | WtgOrders3 getOrders() | setOrders(WtgOrders3 orders) |
| `Carrier` | `Integer` | Optional | Numeric identifier for the carrier.<br>**Default**: `0` | Integer getCarrier() | setCarrier(Integer carrier) |
| `CarrierName` | `String` | Optional | The name for the carrier. | String getCarrierName() | setCarrierName(String carrierName) |
| `ServiceType` | `Integer` | Optional | Numeric identifier for the carrier service assocaited with the transaction.<br>**Default**: `0` | Integer getServiceType() | setServiceType(Integer serviceType) |
| `ServiceTypeName` | `String` | Optional | Description of the service used for the transaction. | String getServiceTypeName() | setServiceTypeName(String serviceTypeName) |
| `CarrierScac` | `String` | Optional | The NMFTA (National Motor Freight Traffic Association) Standard Carrier Alpha Code of the carrier. | String getCarrierScac() | setCarrierScac(String carrierScac) |
| `BrokerReference` | `String` | Optional | Broker reference. | String getBrokerReference() | setBrokerReference(String brokerReference) |
| `ConsolidatedShipmentApiIdentifier` | `String` | Optional | An identifier from an external source that identifies the consolidated shipment. | String getConsolidatedShipmentApiIdentifier() | setConsolidatedShipmentApiIdentifier(String consolidatedShipmentApiIdentifier) |
| `ExternalCarrierIdentifier` | `String` | Optional | An identifier for an external system associated with the carrier. | String getExternalCarrierIdentifier() | setExternalCarrierIdentifier(String externalCarrierIdentifier) |
| `ExternalServiceIdentifier` | `String` | Optional | An identifier for an external system associated with the carrier service. | String getExternalServiceIdentifier() | setExternalServiceIdentifier(String externalServiceIdentifier) |
| `LocationExternalSystemCode` | `String` | Optional | Code used to map the Senders location to a location in an external system. | String getLocationExternalSystemCode() | setLocationExternalSystemCode(String locationExternalSystemCode) |
| `BoLNumber` | `String` | Optional | The bill of lading number for the shipment. | String getBoLNumber() | setBoLNumber(String boLNumber) |
| `MasterBoLNumber` | `String` | Optional | The master bill of lading number for the shipment. | String getMasterBoLNumber() | setMasterBoLNumber(String masterBoLNumber) |
| `WorldEaseID` | `String` | Optional | The unique identifier for the use with UPS World Ease. | String getWorldEaseID() | setWorldEaseID(String worldEaseID) |
| `Zone` | `String` | Optional | The zone assosicated with the shipment. | String getZone() | setZone(String zone) |
| `Weight` | `Double` | Optional | Total weight of the shipment.<br>**Default**: `0d` | Double getWeight() | setWeight(Double weight) |
| `ServiceIsGuaranteed` | `Boolean` | Optional | Indicates if the carrier service has a guaranteed delivery window.<br>**Default**: `false` | Boolean getServiceIsGuaranteed() | setServiceIsGuaranteed(Boolean serviceIsGuaranteed) |
| `EDIMessageID` | `Integer` | Optional | Unique identifier for the EDI message produced during the shipment.<br>**Default**: `0` | Integer getEDIMessageID() | setEDIMessageID(Integer eDIMessageID) |
| `CommitmentLevel` | `String` | Optional | Returned by the carrier indicating the expected delivery date and time. | String getCommitmentLevel() | setCommitmentLevel(String commitmentLevel) |
| `VICSBoLNumber` | `String` | Optional | The VICS billing of lading number. | String getVICSBoLNumber() | setVICSBoLNumber(String vICSBoLNumber) |
| `RecordIdentifiers` | [`WtgRecordIdentifiers3`](../../doc/models/wtg-record-identifiers-3.md) | Optional | Outer container for transaction identifiers. | WtgRecordIdentifiers3 getRecordIdentifiers() | setRecordIdentifiers(WtgRecordIdentifiers3 recordIdentifiers) |
| `Localization` | [`WtgLocalization1`](../../doc/models/wtg-localization-1.md) | Optional | Container for localization information. | WtgLocalization1 getLocalization() | setLocalization(WtgLocalization1 localization) |
| `Receiver` | [`WtgReceiver8`](../../doc/models/wtg-receiver-8.md) | Optional | Container for the receiver address details associated with the transaction. | WtgReceiver8 getReceiver() | setReceiver(WtgReceiver8 receiver) |
| `CorrectedReceiverAddress` | [`WtgCorrectedReceiverAddress`](../../doc/models/wtg-corrected-receiver-address.md) | Optional | Container for the receiver address returned by the carrier if address corrections have been made. | WtgCorrectedReceiverAddress getCorrectedReceiverAddress() | setCorrectedReceiverAddress(WtgCorrectedReceiverAddress correctedReceiverAddress) |
| `ThirdPartyHazardous` | [`WtgThirdPartyHazardous5`](../../doc/models/wtg-third-party-hazardous-5.md) | Optional | Container for details for processing by an external hazardous compliance system. | WtgThirdPartyHazardous5 getThirdPartyHazardous() | setThirdPartyHazardous(WtgThirdPartyHazardous5 thirdPartyHazardous) |
| `Shipping` | [`WtgShipping`](../../doc/models/wtg-shipping.md) | Optional | Container for shipping associated with the transaction. | WtgShipping getShipping() | setShipping(WtgShipping shipping) |
| `Customer` | [`WtgCustomer`](../../doc/models/wtg-customer.md) | Optional | Container for customer details. | WtgCustomer getCustomer() | setCustomer(WtgCustomer customer) |
| `Rates` | [`WtgRates10`](../../doc/models/wtg-rates-10.md) | Optional | Container all rates associated with the transaction. | WtgRates10 getRates() | setRates(WtgRates10 rates) |
| `ClientID` | `String` | Optional | Identifier for the client. | String getClientID() | setClientID(String clientID) |
| `ShipmentIdentifier` | `String` | Optional | The unique identifier assigned to the shipment. | String getShipmentIdentifier() | setShipmentIdentifier(String shipmentIdentifier) |
| `ShippingTrackingNumber` | `String` | Optional | Tracking number associated with the entire shipment. | String getShippingTrackingNumber() | setShippingTrackingNumber(String shippingTrackingNumber) |
| `EstDelivery` | `String` | Optional | The estimated date of delivery if available from the carrier. | String getEstDelivery() | setEstDelivery(String estDelivery) |
| `EstDeliveryDay` | `String` | Optional | The estimated delivery day of week if available from the carrier. | String getEstDeliveryDay() | setEstDeliveryDay(String estDeliveryDay) |
| `ShipmentID` | `Integer` | Optional | Unique identifier for the shipment.<br>**Default**: `0` | Integer getShipmentID() | setShipmentID(Integer shipmentID) |
| `DayOfWeek` | `String` | Optional | Day for the shipment. | String getDayOfWeek() | setDayOfWeek(String dayOfWeek) |
| `RequiredDate` | `String` | Optional | Date the items where required to be delivered by. | String getRequiredDate() | setRequiredDate(String requiredDate) |
| `SuggestedCarrier` | `Integer` | Optional | Carrier that was recommended by e.g. rate shopping.<br>**Default**: `0` | Integer getSuggestedCarrier() | setSuggestedCarrier(Integer suggestedCarrier) |
| `SuggestedCarrierName` | `String` | Optional | The name for the carrier. | String getSuggestedCarrierName() | setSuggestedCarrierName(String suggestedCarrierName) |
| `SuggestedServiceType` | `Integer` | Optional | Carrier service (e.g. Next Day, Ground, Express) that was recommended by e.g. rate shopping.<br>**Default**: `0` | Integer getSuggestedServiceType() | setSuggestedServiceType(Integer suggestedServiceType) |
| `SuggestedServiceTypeName` | `String` | Optional | Carrier service (e.g. Next Day, Ground, Express) that was recommended by e.g. rate shopping. | String getSuggestedServiceTypeName() | setSuggestedServiceTypeName(String suggestedServiceTypeName) |
| `CustomCarrierCode` | `String` | Optional | The customer's internal carrier code, if one was available that matched the carrier and service details. | String getCustomCarrierCode() | setCustomCarrierCode(String customCarrierCode) |
| `SmartPostMachinable` | `Boolean` | Optional | Indicates whether the SmartPost shipment is deemed to be machinable, based on dimensions, weight, and packaging.<br>**Default**: `false` | Boolean getSmartPostMachinable() | setSmartPostMachinable(Boolean smartPostMachinable) |
| `SmartPostPickupCarrier` | `String` | Optional | Identifies the carrier that will pick up the SmartPost shipment. | String getSmartPostPickupCarrier() | setSmartPostPickupCarrier(String smartPostPickupCarrier) |
| `Packages` | [`WtgPackages12`](../../doc/models/wtg-packages-12.md) | Optional | Container for all packages associated with the transaction. | WtgPackages12 getPackages() | setPackages(WtgPackages12 packages) |
| `RouteCode` | `String` | Optional | The universal route or sort aid (URSA) routing code provided by the carrier. | String getRouteCode() | setRouteCode(String routeCode) |
| `Documents` | [`WtgDocuments2`](../../doc/models/wtg-documents-2.md) | Optional | Container for documents to be printed by the caller of the transaction (client). | WtgDocuments2 getDocuments() | setDocuments(WtgDocuments2 documents) |
| `AutomatedPostageAdd` | [`WtgAutomatedPostageAdd`](../../doc/models/wtg-automated-postage-add.md) | Optional | Container for postal meter details. | WtgAutomatedPostageAdd getAutomatedPostageAdd() | setAutomatedPostageAdd(WtgAutomatedPostageAdd automatedPostageAdd) |
| `PersonalShipping` | [`WtgPersonalShipping2`](../../doc/models/wtg-personal-shipping-2.md) | Optional | Container for personal shipping elements. | WtgPersonalShipping2 getPersonalShipping() | setPersonalShipping(WtgPersonalShipping2 personalShipping) |
| `Cartonization` | [`WtgCartonization6`](../../doc/models/wtg-cartonization-6.md) | Optional | Container for cartonization data for this transaction. | WtgCartonization6 getCartonization() | setCartonization(WtgCartonization6 cartonization) |
| `ServiceTypeExternalSystemCode` | `String` | Optional | Carrier and service level code for external system. | String getServiceTypeExternalSystemCode() | setServiceTypeExternalSystemCode(String serviceTypeExternalSystemCode) |
| `BillToExternalSystemCode` | `String` | Optional | Bill to code for external system. | String getBillToExternalSystemCode() | setBillToExternalSystemCode(String billToExternalSystemCode) |
| `OutputHandling` | [`WtgOutputHandling`](../../doc/models/wtg-output-handling.md) | Optional | Container indicating handling of outputs. | WtgOutputHandling getOutputHandling() | setOutputHandling(WtgOutputHandling outputHandling) |
| `Processing` | [`WtgProcessing`](../../doc/models/wtg-processing.md) | Required | Container element for transaction processing statistics. | WtgProcessing getProcessing() | setProcessing(WtgProcessing processing) |

## Example (as XML)

```xml
<wtg:PierbridgeShipResponse xmlns:wtg="https://www.wisetechglobal.com/">
  <wtg:Status xmlns:wtg="https://www.wisetechglobal.com/">
    <wtg:Code>108</wtg:Code>
    <wtg:Warnings />
    <wtg:Errors />
  </wtg:Status>
  <wtg:Orders xmlns:wtg="https://www.wisetechglobal.com/" />
  <wtg:RecordIdentifiers xmlns:wtg="https://www.wisetechglobal.com/" />
  <wtg:Localization xmlns:wtg="https://www.wisetechglobal.com/" />
  <wtg:Receiver xmlns:wtg="https://www.wisetechglobal.com/" />
  <wtg:CorrectedReceiverAddress xmlns:wtg="https://www.wisetechglobal.com/" />
  <wtg:ThirdPartyHazardous xmlns:wtg="https://www.wisetechglobal.com/" />
  <wtg:Shipping xmlns:wtg="https://www.wisetechglobal.com/" />
  <wtg:Customer xmlns:wtg="https://www.wisetechglobal.com/" />
  <wtg:Rates xmlns:wtg="https://www.wisetechglobal.com/" />
  <wtg:Packages xmlns:wtg="https://www.wisetechglobal.com/" />
  <wtg:Documents xmlns:wtg="https://www.wisetechglobal.com/" />
  <wtg:AutomatedPostageAdd xmlns:wtg="https://www.wisetechglobal.com/" />
  <wtg:PersonalShipping xmlns:wtg="https://www.wisetechglobal.com/" />
  <wtg:Cartonization xmlns:wtg="https://www.wisetechglobal.com/" />
  <wtg:OutputHandling xmlns:wtg="https://www.wisetechglobal.com/" />
  <wtg:Processing xmlns:wtg="https://www.wisetechglobal.com/">
    <wtg:StartTime>StartTime4</wtg:StartTime>
    <wtg:EndTime>EndTime0</wtg:EndTime>
    <wtg:Duration>252.24</wtg:Duration>
    <wtg:External />
    <wtg:ServerName>ServerName6</wtg:ServerName>
  </wtg:Processing>
</wtg:PierbridgeShipResponse>
```

