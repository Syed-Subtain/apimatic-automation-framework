
# Tns Package Requisitions

Container for all packages within the requisition.

## Structure

`TnsPackageRequisitions`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `PackageRequisition` | [`List<TnsPackageRequisition>`](../../doc/models/tns-package-requisition.md) | Required | Container for a single package within the requisition. | List<TnsPackageRequisition> getPackageRequisition() | setPackageRequisition(List<TnsPackageRequisition> packageRequisition) |

## Example (as JSON)

```json
{
  "PackageRequisition": [
    {
      "PackageRequisitionID": 154,
      "ReferenceNumber": "ReferenceNumber0"
    },
    {
      "PackageRequisitionID": 155,
      "ReferenceNumber": "ReferenceNumber9"
    },
    {
      "PackageRequisitionID": 156,
      "ReferenceNumber": "ReferenceNumber8"
    }
  ]
}
```

