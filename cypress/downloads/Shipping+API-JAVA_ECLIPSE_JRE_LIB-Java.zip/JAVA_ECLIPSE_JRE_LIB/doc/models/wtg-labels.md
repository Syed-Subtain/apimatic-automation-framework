
# Wtg Labels

Container for labels to be printed by the caller of the transaction (client).

## Structure

`WtgLabels`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Output` | [`List<WtgOutput3>`](../../doc/models/wtg-output-3.md) | Optional | Container for labels to be printed externally from the transaction. | List<WtgOutput3> getOutput() | setOutput(List<WtgOutput3> output) |

## Example (as XML)

```xml
<wtg:Labels xmlns:wtg="https://www.wisetechglobal.com/" />
```

