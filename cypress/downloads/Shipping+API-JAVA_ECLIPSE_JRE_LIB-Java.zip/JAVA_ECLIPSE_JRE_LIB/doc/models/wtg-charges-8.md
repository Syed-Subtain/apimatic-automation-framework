
# Wtg Charges 8

Container for all charges within the group associated with the transaction.

## Structure

`WtgCharges8`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Charge` | [`List<WtgCharge8>`](../../doc/models/wtg-charge-8.md) | Optional | Container for an individual charge within the group associated with the transaction. | List<WtgCharge8> getCharge() | setCharge(List<WtgCharge8> charge) |

## Example (as XML)

```xml
<wtg:Charges xmlns:wtg="https://www.wisetechglobal.com/" />
```

