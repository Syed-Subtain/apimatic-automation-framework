
# Wtg Identification Number Type Enum

## Enumeration

`WtgIdentificationNumberTypeEnum`

## Fields

| Name |
|  --- |
| `Enum1` |
| `Enum2` |

