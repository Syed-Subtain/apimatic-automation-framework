
# Wtg Home Delivery

Container for home delivery details.

## Structure

`WtgHomeDelivery`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Type` | `Integer` | Optional | Type of home delivery required for the shipment.<br>**Constraints**: *Pattern*: `[1-3]` | Integer getType() | setType(Integer type) |

## Example (as XML)

```xml
<wtg:HomeDelivery xmlns:wtg="https://www.wisetechglobal.com/" />
```

