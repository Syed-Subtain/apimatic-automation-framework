
# Wtg Contents 13

Container for all contents (line items) associated with the transaction.

## Structure

`WtgContents13`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Content` | [`List<WtgContent13>`](../../doc/models/wtg-content-13.md) | Required | Container for a individual content (line item) associated with the transaction. | List<WtgContent13> getContent() | setContent(List<WtgContent13> content) |

## Example (as XML)

```xml
<wtg:Contents xmlns:wtg="https://www.wisetechglobal.com/">
  <wtg:Content xmlns:wtg="https://www.wisetechglobal.com/">
    <wtg:RecordIdentifiers />
  </wtg:Content>
</wtg:Contents>
```

