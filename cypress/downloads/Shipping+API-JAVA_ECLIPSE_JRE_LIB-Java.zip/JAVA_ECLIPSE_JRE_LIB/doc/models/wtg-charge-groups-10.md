
# Wtg Charge Groups 10

Container for all charge groups associated with the transaction.

## Structure

`WtgChargeGroups10`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `ChargeGroup` | [`List<WtgChargeGroup10>`](../../doc/models/wtg-charge-group-10.md) | Optional | Container for an individual charge group associated with the transaction. | List<WtgChargeGroup10> getChargeGroup() | setChargeGroup(List<WtgChargeGroup10> chargeGroup) |

## Example (as XML)

```xml
<wtg:ChargeGroups xmlns:wtg="https://www.wisetechglobal.com/" />
```

