
# Wtg Warnings 1

Container for all warnings found whilst processing the transaction.

## Structure

`WtgWarnings1`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Warning` | [`List<WtgWarning1>`](../../doc/models/wtg-warning-1.md) | Required | Container for a single warning found whilst processing the transaction. | List<WtgWarning1> getWarning() | setWarning(List<WtgWarning1> warning) |

## Example (as XML)

```xml
<wtg:Warnings xmlns:wtg="https://www.wisetechglobal.com/">
  <wtg:Warning xmlns:wtg="https://www.wisetechglobal.com/">
    <wtg:Code>134</wtg:Code>
    <wtg:Description>Description4</wtg:Description>
  </wtg:Warning>
</wtg:Warnings>
```

