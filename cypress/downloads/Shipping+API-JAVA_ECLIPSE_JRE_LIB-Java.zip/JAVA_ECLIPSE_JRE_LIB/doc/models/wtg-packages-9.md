
# Wtg Packages 9

Container for all packages associated with the transaction.

## Structure

`WtgPackages9`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Package` | [`List<WtgPackage10>`](../../doc/models/wtg-package-10.md) | Required | Container for an individual package associated with the transaction. | List<WtgPackage10> getPackage() | setPackage(List<WtgPackage10> mPackage) |

## Example (as XML)

```xml
<wtg:Packages xmlns:wtg="https://www.wisetechglobal.com/" />
```

