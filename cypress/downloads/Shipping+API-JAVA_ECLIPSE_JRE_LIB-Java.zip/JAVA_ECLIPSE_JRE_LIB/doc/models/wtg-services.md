
# Wtg Services

Container for the carrier services.

## Structure

`WtgServices`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Service` | [`List<WtgService>`](../../doc/models/wtg-service.md) | Required | Container for a single service. | List<WtgService> getService() | setService(List<WtgService> service) |

## Example (as XML)

```xml
<wtg:Services xmlns:wtg="https://www.wisetechglobal.com/">
  <wtg:Service xmlns:wtg="https://www.wisetechglobal.com/">
    <wtg:ServiceName>ServiceName0</wtg:ServiceName>
    <wtg:ServiceCode>ServiceCode8</wtg:ServiceCode>
    <wtg:Commitment>
      <wtg:DeliveryDate>DeliveryDate2</wtg:DeliveryDate>
      <wtg:DeliveryTime>DeliveryTime0</wtg:DeliveryTime>
      <wtg:PickupDate>PickupDate6</wtg:PickupDate>
      <wtg:DaysTransit>DaysTransit0</wtg:DaysTransit>
    </wtg:Commitment>
    <wtg:Guaranteed>false</wtg:Guaranteed>
  </wtg:Service>
  <wtg:Service xmlns:wtg="https://www.wisetechglobal.com/">
    <wtg:ServiceName>ServiceName1</wtg:ServiceName>
    <wtg:ServiceCode>ServiceCode7</wtg:ServiceCode>
    <wtg:Commitment>
      <wtg:DeliveryDate>DeliveryDate3</wtg:DeliveryDate>
      <wtg:DeliveryTime>DeliveryTime1</wtg:DeliveryTime>
      <wtg:PickupDate>PickupDate7</wtg:PickupDate>
      <wtg:DaysTransit>DaysTransit1</wtg:DaysTransit>
    </wtg:Commitment>
    <wtg:Guaranteed>true</wtg:Guaranteed>
  </wtg:Service>
</wtg:Services>
```

