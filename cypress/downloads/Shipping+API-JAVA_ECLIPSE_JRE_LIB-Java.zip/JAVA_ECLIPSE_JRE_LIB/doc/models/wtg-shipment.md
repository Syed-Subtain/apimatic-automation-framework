
# Wtg Shipment

Container for a single shipment.

## Structure

`WtgShipment`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `ShipmentID` | `Integer` | Optional | Unique identifier for the shipment.<br>**Default**: `0` | Integer getShipmentID() | setShipmentID(Integer shipmentID) |
| `ShipDate` | `String` | Optional | Date the items where shipped. | String getShipDate() | setShipDate(String shipDate) |
| `ProcessedDate` | `String` | Optional | Date the shipment was processed. | String getProcessedDate() | setProcessedDate(String processedDate) |
| `DeliveryDate` | `String` | Optional | The requested delivery date for the shipment. | String getDeliveryDate() | setDeliveryDate(String deliveryDate) |
| `BolNumber` | `String` | Optional | The bill of lading number for the shipment. | String getBolNumber() | setBolNumber(String bolNumber) |
| `SalesOrderNumber` | `String` | Optional | The salse order number for the shipment. | String getSalesOrderNumber() | setSalesOrderNumber(String salesOrderNumber) |
| `PurchaseOrderNumber` | `String` | Optional | The purchase order number for the shipment. | String getPurchaseOrderNumber() | setPurchaseOrderNumber(String purchaseOrderNumber) |
| `EstimatedDeliveryCode` | `String` | Optional | The estimated delivery code for the shipment. | String getEstimatedDeliveryCode() | setEstimatedDeliveryCode(String estimatedDeliveryCode) |
| `EstimatedDeliveryDayCode` | `String` | Optional | The estimated delivery day code for the shipment. | String getEstimatedDeliveryDayCode() | setEstimatedDeliveryDayCode(String estimatedDeliveryDayCode) |
| `FreightCost` | `Double` | Optional | The freight cost for the shipment. | Double getFreightCost() | setFreightCost(Double freightCost) |
| `AccessorialCost` | `Double` | Optional | The accessorial cost for the shipment. | Double getAccessorialCost() | setAccessorialCost(Double accessorialCost) |
| `OtherCost` | `Double` | Optional | The other costs for the shipment. | Double getOtherCost() | setOtherCost(Double otherCost) |
| `TotalCost` | `Double` | Optional | The total cost for the shipment. | Double getTotalCost() | setTotalCost(Double totalCost) |
| `CustomerFreightCost` | `Double` | Optional | The customer freight cost for the shipment. | Double getCustomerFreightCost() | setCustomerFreightCost(Double customerFreightCost) |
| `CustomerAccessorialCost` | `Double` | Optional | The customer accessorial cost for the shipment. | Double getCustomerAccessorialCost() | setCustomerAccessorialCost(Double customerAccessorialCost) |
| `CustomerOtherCost` | `Double` | Optional | The customer other costs for the shipment. | Double getCustomerOtherCost() | setCustomerOtherCost(Double customerOtherCost) |
| `CustomerTotalCost` | `Double` | Optional | The customer total cost for the shipment. | Double getCustomerTotalCost() | setCustomerTotalCost(Double customerTotalCost) |
| `Carrier` | `Integer` | Optional | The ID for the carrier. | Integer getCarrier() | setCarrier(Integer carrier) |
| `CarrierName` | `String` | Optional | The name for the carrier. | String getCarrierName() | setCarrierName(String carrierName) |
| `CarrierSCAC` | `String` | Optional | Code for the carrier. | String getCarrierSCAC() | setCarrierSCAC(String carrierSCAC) |
| `CustomCarrierCode` | `String` | Optional | Custom Code for the carrier. | String getCustomCarrierCode() | setCustomCarrierCode(String customCarrierCode) |
| `CarrierService` | `String` | Optional | The name for the carrier service. | String getCarrierService() | setCarrierService(String carrierService) |
| `ApplicationName` | `String` | Optional | Application that was used to create the shipment.<br>**Default**: `"0"` | String getApplicationName() | setApplicationName(String applicationName) |
| `Residential` | `Boolean` | Optional | Indicates whether the receipient address is residential or commercial.<br>**Default**: `false` | Boolean getResidential() | setResidential(Boolean residential) |
| `IsReturn` | `Boolean` | Optional | Indicates whether the shipment is a return.<br>**Default**: `false` | Boolean getIsReturn() | setIsReturn(Boolean isReturn) |
| `Receiver` | [`WtgReceiver12`](../../doc/models/wtg-receiver-12.md) | Optional | Container for the receiver address details associated with the transaction. | WtgReceiver12 getReceiver() | setReceiver(WtgReceiver12 receiver) |
| `Sender` | [`WtgSender6`](../../doc/models/wtg-sender-6.md) | Optional | Container for the sender address details associated with the transaction. | WtgSender6 getSender() | setSender(WtgSender6 sender) |
| `ReturnTo` | [`WtgReturnTo5`](../../doc/models/wtg-return-to-5.md) | Optional | Container for the return to address details associated with the transaction. | WtgReturnTo5 getReturnTo() | setReturnTo(WtgReturnTo5 returnTo) |
| `Billing` | [`WtgBilling8`](../../doc/models/wtg-billing-8.md) | Optional | Container for billing details associated with the transaction. | WtgBilling8 getBilling() | setBilling(WtgBilling8 billing) |
| `Rates` | [`WtgRates13`](../../doc/models/wtg-rates-13.md) | Optional | Container for all rates associated with the transaction. | WtgRates13 getRates() | setRates(WtgRates13 rates) |
| `Outputs` | [`WtgOutputs3`](../../doc/models/wtg-outputs-3.md) | Optional | Container for outputs the transaction should generate or customize the printing of. | WtgOutputs3 getOutputs() | setOutputs(WtgOutputs3 outputs) |
| `RecordIdentifiers` | [`WtgRecordIdentifiers3`](../../doc/models/wtg-record-identifiers-3.md) | Optional | Outer container for transaction identifiers. | WtgRecordIdentifiers3 getRecordIdentifiers() | setRecordIdentifiers(WtgRecordIdentifiers3 recordIdentifiers) |
| `Packages` | [`WtgPackages17`](../../doc/models/wtg-packages-17.md) | Optional | Container for all packages associated with the transaction. | WtgPackages17 getPackages() | setPackages(WtgPackages17 packages) |
| `Orders` | [`WtgOrders4`](../../doc/models/wtg-orders-4.md) | Optional | Container all orders associated with the transaction. | WtgOrders4 getOrders() | setOrders(WtgOrders4 orders) |

## Example (as XML)

```xml
<wtg:Shipment xmlns:wtg="https://www.wisetechglobal.com/">
  <wtg:Receiver xmlns:wtg="https://www.wisetechglobal.com/" />
  <wtg:Sender xmlns:wtg="https://www.wisetechglobal.com/" />
  <wtg:ReturnTo xmlns:wtg="https://www.wisetechglobal.com/" />
  <wtg:Billing xmlns:wtg="https://www.wisetechglobal.com/" />
  <wtg:Rates xmlns:wtg="https://www.wisetechglobal.com/" />
  <wtg:Outputs xmlns:wtg="https://www.wisetechglobal.com/" />
  <wtg:RecordIdentifiers xmlns:wtg="https://www.wisetechglobal.com/" />
  <wtg:Packages xmlns:wtg="https://www.wisetechglobal.com/" />
  <wtg:Orders xmlns:wtg="https://www.wisetechglobal.com/" />
</wtg:Shipment>
```

