
# Wtg Freight Handling Type Enum

## Enumeration

`WtgFreightHandlingTypeEnum`

## Fields

| Name |
|  --- |
| `Enum0` |
| `Enum1` |
| `Enum2` |
| `Enum3` |
| `Enum4` |
| `Enum5` |

