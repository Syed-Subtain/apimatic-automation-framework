
# Wtg Order 1

Container for an individual order.

## Structure

`WtgOrder1`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `OrderID` | `Integer` | Optional | Identifier of the order being rated.<br>**Default**: `0` | Integer getOrderID() | setOrderID(Integer orderID) |
| `PickLists` | [`WtgPickLists`](../../doc/models/wtg-pick-lists.md) | Optional | Container all order picklists. | WtgPickLists getPickLists() | setPickLists(WtgPickLists pickLists) |

## Example (as XML)

```xml
<wtg:Order xmlns:wtg="https://www.wisetechglobal.com/">
  <wtg:PickLists xmlns:wtg="https://www.wisetechglobal.com/" />
</wtg:Order>
```

