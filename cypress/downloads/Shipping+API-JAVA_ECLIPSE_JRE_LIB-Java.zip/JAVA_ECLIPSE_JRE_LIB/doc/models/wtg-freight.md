
# Wtg Freight

Container for freight specific values

## Structure

`WtgFreight`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Billing` | [`WtgBilling1`](../../doc/models/wtg-billing-1.md) | Optional | Container for billing details associated with the transaction. | WtgBilling1 getBilling() | setBilling(WtgBilling1 billing) |

## Example (as XML)

```xml
<wtg:Freight xmlns:wtg="https://www.wisetechglobal.com/">
  <wtg:Billing xmlns:wtg="https://www.wisetechglobal.com/" />
</wtg:Freight>
```

