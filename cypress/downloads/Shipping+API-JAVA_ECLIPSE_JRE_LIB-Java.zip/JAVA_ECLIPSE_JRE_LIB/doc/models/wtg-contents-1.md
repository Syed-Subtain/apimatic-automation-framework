
# Wtg Contents 1

Container for all contents (line items) associated with the transaction.

## Structure

`WtgContents1`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Content` | [`List<WtgContent1>`](../../doc/models/wtg-content-1.md) | Optional | Container for a individual content (line item) associated with the transaction. | List<WtgContent1> getContent() | setContent(List<WtgContent1> content) |

## Example (as XML)

```xml
<wtg:Contents xmlns:wtg="https://www.wisetechglobal.com/" />
```

