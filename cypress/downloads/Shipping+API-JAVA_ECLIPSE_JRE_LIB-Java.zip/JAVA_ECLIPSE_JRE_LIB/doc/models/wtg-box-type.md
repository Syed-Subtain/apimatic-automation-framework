
# Wtg Box Type

box type

## Structure

`WtgBoxType`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Name` | `String` | Optional | Box type name | String getName() | setName(String name) |
| `Weight` | `Double` | Optional | Maximum weight for box type | Double getWeight() | setWeight(Double weight) |
| `Width` | `Double` | Optional | Box width | Double getWidth() | setWidth(Double width) |
| `Height` | `Double` | Optional | Box height | Double getHeight() | setHeight(Double height) |
| `Length` | `Double` | Optional | Box length | Double getLength() | setLength(Double length) |

## Example (as XML)

```xml
<wtg:BoxType xmlns:wtg="https://www.wisetechglobal.com/" />
```

