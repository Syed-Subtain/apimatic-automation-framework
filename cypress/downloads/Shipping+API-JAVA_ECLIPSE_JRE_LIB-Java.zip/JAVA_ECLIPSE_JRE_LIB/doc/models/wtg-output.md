
# Wtg Output

Container for documents to be printed externally from the transaction.

## Structure

`WtgOutput`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `EndOfDayID` | `int` | Required | Unique numeric identifier for the end of day record. | int getEndOfDayID() | setEndOfDayID(int endOfDayID) |
| `Type` | `int` | Required | A numeric identifier that identifies the type of document. | int getType() | setType(int type) |
| `TypeDescription` | `String` | Required | The description of the document type. | String getTypeDescription() | setTypeDescription(String typeDescription) |
| `TimeLog` | `String` | Required | The date and time the document was stored. | String getTimeLog() | setTimeLog(String timeLog) |
| `UserName` | `String` | Required | The name of the user that stored the document. | String getUserName() | setUserName(String userName) |
| `UserFullName` | `String` | Required | The complete user description for the user that stored the document. | String getUserFullName() | setUserFullName(String userFullName) |
| `CarrierName` | `String` | Required | The name for the carrier. | String getCarrierName() | setCarrierName(String carrierName) |
| `AccountNumber` | `String` | Required | The number associated with the account that stored the document. | String getAccountNumber() | setAccountNumber(String accountNumber) |
| `ShippingKey` | `String` | Optional | The shipping key associated with the account that stored the document. | String getShippingKey() | setShippingKey(String shippingKey) |
| `Guid` | `String` | Required | Unique identifier for the printed output can be used to reprint. | String getGuid() | setGuid(String guid) |
| `DateClosed` | `String` | Required | The date the shipments associated with this output were closed. | String getDateClosed() | setDateClosed(String dateClosed) |

## Example (as XML)

```xml
<wtg:Output xmlns:wtg="https://www.wisetechglobal.com/">
  <wtg:EndOfDayID xmlns:wtg="https://www.wisetechglobal.com/">136</wtg:EndOfDayID>
  <wtg:Type xmlns:wtg="https://www.wisetechglobal.com/">190</wtg:Type>
  <wtg:TypeDescription xmlns:wtg="https://www.wisetechglobal.com/">TypeDescription6</wtg:TypeDescription>
  <wtg:TimeLog xmlns:wtg="https://www.wisetechglobal.com/">TimeLog6</wtg:TimeLog>
  <wtg:UserName xmlns:wtg="https://www.wisetechglobal.com/">UserName6</wtg:UserName>
  <wtg:UserFullName xmlns:wtg="https://www.wisetechglobal.com/">UserFullName4</wtg:UserFullName>
  <wtg:CarrierName xmlns:wtg="https://www.wisetechglobal.com/">CarrierName6</wtg:CarrierName>
  <wtg:AccountNumber xmlns:wtg="https://www.wisetechglobal.com/">AccountNumber4</wtg:AccountNumber>
  <wtg:Guid xmlns:wtg="https://www.wisetechglobal.com/">Guid8</wtg:Guid>
  <wtg:DateClosed xmlns:wtg="https://www.wisetechglobal.com/">DateClosed4</wtg:DateClosed>
</wtg:Output>
```

