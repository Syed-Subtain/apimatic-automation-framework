
# Wtg Record Identifier

Inner container for transaction identifiers.

## Structure

`WtgRecordIdentifier`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Keys` | [`WtgKeys`](../../doc/models/wtg-keys.md) | Optional | Container for transaction identifiers to be stored. | WtgKeys getKeys() | setKeys(WtgKeys keys) |

## Example (as XML)

```xml
<wtg:RecordIdentifier xmlns:wtg="https://www.wisetechglobal.com/">
  <wtg:Keys xmlns:wtg="https://www.wisetechglobal.com/" />
</wtg:RecordIdentifier>
```

