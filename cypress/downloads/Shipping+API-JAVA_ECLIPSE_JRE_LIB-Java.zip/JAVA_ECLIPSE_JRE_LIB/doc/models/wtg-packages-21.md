
# Wtg Packages 21

Container for all packages associated with the transaction.

## Structure

`WtgPackages21`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Package` | [`List<WtgPackage22>`](../../doc/models/wtg-package-22.md) | Required | Container for an individual package associated with the transaction. | List<WtgPackage22> getPackage() | setPackage(List<WtgPackage22> mPackage) |

## Example (as XML)

```xml
<wtg:Packages xmlns:wtg="https://www.wisetechglobal.com/">
  <wtg:Package xmlns:wtg="https://www.wisetechglobal.com/" />
</wtg:Packages>
```

