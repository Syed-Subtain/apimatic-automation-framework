
# Wtg Expedite Method Enum

## Enumeration

`WtgExpediteMethodEnum`

## Fields

| Name |
|  --- |
| `Enum64` |
| `Enum128` |
| `Enum256` |

