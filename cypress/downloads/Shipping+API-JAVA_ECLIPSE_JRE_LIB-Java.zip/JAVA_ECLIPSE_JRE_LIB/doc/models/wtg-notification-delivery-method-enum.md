
# Wtg Notification Delivery Method Enum

## Enumeration

`WtgNotificationDeliveryMethodEnum`

## Fields

| Name |
|  --- |
| `Enum1` |
| `Enum2` |
| `Enum3` |

