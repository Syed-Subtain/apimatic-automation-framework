
# Wtg Status

Container for transaction errors and warning elements.

## Structure

`WtgStatus`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Code` | `int` | Required | If the transaction was successful this was will equal one, otherwise zero. | int getCode() | setCode(int code) |
| `Description` | `String` | Optional | Contains a description of the status, if the transaction failed this will contain an error message. | String getDescription() | setDescription(String description) |
| `Warnings` | [`WtgWarnings`](../../doc/models/wtg-warnings.md) | Optional | Container for all warnings found whilst processing the transaction. | WtgWarnings getWarnings() | setWarnings(WtgWarnings warnings) |
| `Errors` | [`WtgErrors`](../../doc/models/wtg-errors.md) | Optional | Container for all errors found whilst processing the transaction. | WtgErrors getErrors() | setErrors(WtgErrors errors) |

## Example (as XML)

```xml
<wtg:Status xmlns:wtg="https://www.wisetechglobal.com/">
  <wtg:Code xmlns:wtg="https://www.wisetechglobal.com/">148</wtg:Code>
  <wtg:Warnings xmlns:wtg="https://www.wisetechglobal.com/" />
  <wtg:Errors xmlns:wtg="https://www.wisetechglobal.com/" />
</wtg:Status>
```

