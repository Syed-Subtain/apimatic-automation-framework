
# Wtg Pick Lists

Container all order picklists.

## Structure

`WtgPickLists`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `PickList` | [`List<WtgPickList>`](../../doc/models/wtg-pick-list.md) | Optional | Container for an individual picklist. | List<WtgPickList> getPickList() | setPickList(List<WtgPickList> pickList) |

## Example (as XML)

```xml
<wtg:PickLists xmlns:wtg="https://www.wisetechglobal.com/" />
```

