
# Wtg Pre Packed Box

## Structure

`WtgPrePackedBox`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Name` | `String` | Optional | name for the type of box. | String getName() | setName(String name) |
| `WeightTare` | `Double` | Optional | weight of the container when empty or otherwise unladen, i.e., of the box itself. | Double getWeightTare() | setWeightTare(Double weightTare) |
| `WeightMax` | `Double` | Optional | maximum allowable gross weight for the box, i.e., all packed item weights plus the WeightTare. | Double getWeightMax() | setWeightMax(Double weightMax) |
| `Height` | `Double` | Optional | Height of the box. | Double getHeight() | setHeight(Double height) |
| `Width` | `Double` | Optional | Width of the box. | Double getWidth() | setWidth(Double width) |
| `Length` | `Double` | Optional | Length of the box. | Double getLength() | setLength(Double length) |
| `CenterOfMass` | [`WtgPoint`](../../doc/models/wtg-point.md) | Optional | 3-dimensional Coordinates of the box's center of mass | WtgPoint getCenterOfMass() | setCenterOfMass(WtgPoint centerOfMass) |
| `ID` | `Integer` | Optional | box ID<br>**Default**: `0` | Integer getID() | setID(Integer iD) |
| `Items` | [`WtgItems`](../../doc/models/wtg-items.md) | Optional | Items already packed into box | WtgItems getItems() | setItems(WtgItems items) |
| `BoxType` | [`WtgBoxType`](../../doc/models/wtg-box-type.md) | Required | box type | WtgBoxType getBoxType() | setBoxType(WtgBoxType boxType) |

## Example (as XML)

```xml
<wtg:PrePackedBox xmlns:wtg="https://www.wisetechglobal.com/">
  <wtg:CenterOfMass xmlns:wtg="https://www.wisetechglobal.com/" />
  <wtg:Items xmlns:wtg="https://www.wisetechglobal.com/" />
  <wtg:BoxType xmlns:wtg="https://www.wisetechglobal.com/" />
</wtg:PrePackedBox>
```

