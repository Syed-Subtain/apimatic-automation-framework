
# Wtg Package 7

Container for an individual package associated with the transaction.

## Structure

`WtgPackage7`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Weight` | `Double` | Optional | The weight of the package.<br>**Default**: `0d` | Double getWeight() | setWeight(Double weight) |
| `Length` | `Double` | Optional | The dimensional lenth of the package.<br>**Default**: `0d` | Double getLength() | setLength(Double length) |
| `Width` | `Double` | Optional | The dimensional width of the package.<br>**Default**: `0d` | Double getWidth() | setWidth(Double width) |
| `Height` | `Double` | Optional | The dimensional height of the package.<br>**Default**: `0d` | Double getHeight() | setHeight(Double height) |
| `FreightClass` | `String` | Optional | The freight class of the package's content. | String getFreightClass() | setFreightClass(String freightClass) |
| `NMFC` | `String` | Optional | The National Motor Freight Classification of the package. | String getNMFC() | setNMFC(String nMFC) |
| `PalletCount` | `Integer` | Optional | Number of pallets.<br>**Default**: `0` | Integer getPalletCount() | setPalletCount(Integer palletCount) |
| `ItemsOnPallet` | `Integer` | Optional | Number of items on the pallet.<br>**Default**: `0` | Integer getItemsOnPallet() | setItemsOnPallet(Integer itemsOnPallet) |
| `International` | [`WtgInternational7`](../../doc/models/wtg-international-7.md) | Optional | Container for international details associated with the shipment. | WtgInternational7 getInternational() | setInternational(WtgInternational7 international) |

## Example (as XML)

```xml
<wtg:Package xmlns:wtg="https://www.wisetechglobal.com/">
  <wtg:International xmlns:wtg="https://www.wisetechglobal.com/" />
</wtg:Package>
```

