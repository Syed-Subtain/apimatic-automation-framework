
# Wtg Rates 11

Container all rates associated with the transaction.

## Structure

`WtgRates11`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Rate` | [`List<WtgRate11>`](../../doc/models/wtg-rate-11.md) | Optional | Container for an individual rate. | List<WtgRate11> getRate() | setRate(List<WtgRate11> rate) |

## Example (as XML)

```xml
<wtg:Rates xmlns:wtg="https://www.wisetechglobal.com/" />
```

