
# Wtg Commitment

Container for the carrier commitment details.

## Structure

`WtgCommitment`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `DeliveryDate` | `String` | Required | The requested delivery date for the shipment. | String getDeliveryDate() | setDeliveryDate(String deliveryDate) |
| `DeliveryTime` | `String` | Required | If available the delivery time for the item. | String getDeliveryTime() | setDeliveryTime(String deliveryTime) |
| `PickupDate` | `String` | Required | Date that the shipment is required to be picked up. | String getPickupDate() | setPickupDate(String pickupDate) |
| `DaysTransit` | `String` | Required | The number of days the shipment will be in transit. | String getDaysTransit() | setDaysTransit(String daysTransit) |

## Example (as XML)

```xml
<wtg:Commitment xmlns:wtg="https://www.wisetechglobal.com/">
  <wtg:DeliveryDate xmlns:wtg="https://www.wisetechglobal.com/">DeliveryDate2</wtg:DeliveryDate>
  <wtg:DeliveryTime xmlns:wtg="https://www.wisetechglobal.com/">DeliveryTime6</wtg:DeliveryTime>
  <wtg:PickupDate xmlns:wtg="https://www.wisetechglobal.com/">PickupDate2</wtg:PickupDate>
  <wtg:DaysTransit xmlns:wtg="https://www.wisetechglobal.com/">DaysTransit6</wtg:DaysTransit>
</wtg:Commitment>
```

