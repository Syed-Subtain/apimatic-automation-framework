
# Wtg Inclusion Specifications Service Category Enum

## Enumeration

`WtgInclusionSpecificationsServiceCategoryEnum`

## Fields

| Name |
|  --- |
| `Enum1` |
| `Enum2` |

