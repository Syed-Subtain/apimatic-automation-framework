
# Wtg Temperature Enum

## Enumeration

`WtgTemperatureEnum`

## Fields

| Name |
|  --- |
| `Enum1` |
| `Enum2` |
| `Enum4` |
| `Enum8` |
| `Enum16` |

