
# Tns Warning

Container for a single warning found whilst processing the transaction.

## Structure

`TnsWarning`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Code` | `Integer` | Optional | A code indicating the warning status.<br>**Default**: `0` | Integer getCode() | setCode(Integer code) |
| `Description` | `String` | Required | A description of the warning. | String getDescription() | setDescription(String description) |

## Example (as JSON)

```json
{
  "Code": null,
  "Description": "Description6"
}
```

