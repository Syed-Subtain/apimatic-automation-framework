
# Tns Output

Container for documents to be printed externally from the transaction.

## Structure

`TnsOutput`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Status` | [`TnsStatus1`](../../doc/models/tns-status-1.md) | Optional | Container for transaction errors and warning elements. | TnsStatus1 getStatus() | setStatus(TnsStatus1 status) |
| `HubCappServerUri` | `String` | Optional | HubCapp Server Uri used to in the request. | String getHubCappServerUri() | setHubCappServerUri(String hubCappServerUri) |
| `HubCappLicenseKey` | `String` | Optional | HubCapp Server License Key used in the request. | String getHubCappLicenseKey() | setHubCappLicenseKey(String hubCappLicenseKey) |
| `HubCappMachineID` | `String` | Optional | HubCapp Machine ID used in the request. | String getHubCappMachineID() | setHubCappMachineID(String hubCappMachineID) |
| `Printed` | `Boolean` | Optional | Indicates that an output has already been printed. | Boolean getPrinted() | setPrinted(Boolean printed) |
| `Guid` | `String` | Required | Unique identifier for the printed output can be used to reprint. | String getGuid() | setGuid(String guid) |
| `Type` | `int` | Required | A numeric identifier that identifies the type of document. | int getType() | setType(int type) |
| `Description` | `String` | Required | Description of the output that has been produced, e.g. Label. | String getDescription() | setDescription(String description) |
| `Format` | `int` | Required | A numeric identifier that identifies the format of the document. | int getFormat() | setFormat(int format) |
| `MimeType` | `String` | Optional | If appropriate the internet media type associated with the document format. | String getMimeType() | setMimeType(String mimeType) |
| `Content` | `String` | Optional | If appropriate for the printing type, a base 64 encoded value for the document. | String getContent() | setContent(String content) |
| `Stock` | `Integer` | Optional | A numeric identifier for the stock type of the output.<br>**Default**: `0` | Integer getStock() | setStock(Integer stock) |
| `Pages` | [`TnsPages`](../../doc/models/tns-pages.md) | Optional | Container for all pages to be printed by the caller of the transaction (client). | TnsPages getPages() | setPages(TnsPages pages) |

## Example (as JSON)

```json
{
  "Status": null,
  "HubCappServerUri": null,
  "HubCappLicenseKey": null,
  "HubCappMachineID": null,
  "Printed": null,
  "Guid": "Guid8",
  "Type": 190,
  "Description": "Description6",
  "Format": 164,
  "MimeType": null,
  "Content": null,
  "Stock": null,
  "Pages": null
}
```

