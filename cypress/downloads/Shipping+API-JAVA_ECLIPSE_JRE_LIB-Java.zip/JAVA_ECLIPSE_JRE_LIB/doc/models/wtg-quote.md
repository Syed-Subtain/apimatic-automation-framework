
# Wtg Quote

Container for quote information.

## Structure

`WtgQuote`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `QuoteID` | `String` | Optional | Identifier of the rate quote selected for the shipment.<br>**Default**: `"0"` | String getQuoteID() | setQuoteID(String quoteID) |
| `OptionID` | `String` | Optional | Identifier of the rate option selected for the shipment.<br>**Default**: `"0"` | String getOptionID() | setOptionID(String optionID) |
| `SCAC` | `String` | Optional | Identifier of the rate scac selected for the shipment. | String getSCAC() | setSCAC(String sCAC) |

## Example (as XML)

```xml
<wtg:Quote xmlns:wtg="https://www.wisetechglobal.com/" />
```

