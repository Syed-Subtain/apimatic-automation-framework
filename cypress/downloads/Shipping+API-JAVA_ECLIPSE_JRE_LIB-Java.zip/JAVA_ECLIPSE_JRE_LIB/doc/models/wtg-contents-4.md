
# Wtg Contents 4

Container for all contents (line items) associated with the transaction.

## Structure

`WtgContents4`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Content` | [`List<WtgContent4>`](../../doc/models/wtg-content-4.md) | Optional | Container for a individual content (line item) associated with the transaction. | List<WtgContent4> getContent() | setContent(List<WtgContent4> content) |

## Example (as XML)

```xml
<wtg:Contents xmlns:wtg="https://www.wisetechglobal.com/" />
```

