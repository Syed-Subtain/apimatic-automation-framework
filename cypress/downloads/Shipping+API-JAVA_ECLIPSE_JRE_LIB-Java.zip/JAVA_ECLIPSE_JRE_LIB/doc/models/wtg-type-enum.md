
# Wtg Type Enum

## Enumeration

`WtgTypeEnum`

## Fields

| Name |
|  --- |
| `Enum1` |
| `Enum2` |
| `Enum3` |

