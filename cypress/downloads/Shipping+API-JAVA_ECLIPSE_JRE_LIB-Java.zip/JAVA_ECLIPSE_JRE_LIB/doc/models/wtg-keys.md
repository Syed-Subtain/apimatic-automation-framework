
# Wtg Keys

Container for transaction identifiers to be stored.

## Structure

`WtgKeys`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Key1` | `String` | Optional | Shipment-level record identifier. | String getKey1() | setKey1(String key1) |
| `Key2` | `String` | Optional | Shipment-level record identifier. | String getKey2() | setKey2(String key2) |
| `Key3` | `String` | Optional | Shipment-level record identifier. | String getKey3() | setKey3(String key3) |
| `Key4` | `String` | Optional | Shipment-level record identifier. | String getKey4() | setKey4(String key4) |
| `Key5` | `String` | Optional | Shipment-level record identifier. | String getKey5() | setKey5(String key5) |
| `Key6` | `String` | Optional | Shipment-level record identifier. | String getKey6() | setKey6(String key6) |

## Example (as XML)

```xml
<wtg:Keys xmlns:wtg="https://www.wisetechglobal.com/" />
```

