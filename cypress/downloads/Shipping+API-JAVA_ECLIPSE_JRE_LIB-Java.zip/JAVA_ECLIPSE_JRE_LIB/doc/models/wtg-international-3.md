
# Wtg International 3

Container for international details associated with the shipment.

## Structure

`WtgInternational3`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `DocumentsOnly` | `Boolean` | Optional | Indicates if the item only contained documents.<br>**Default**: `false` | Boolean getDocumentsOnly() | setDocumentsOnly(Boolean documentsOnly) |
| `Contents` | [`WtgContents4`](../../doc/models/wtg-contents-4.md) | Optional | Container for all contents (line items) associated with the transaction. | WtgContents4 getContents() | setContents(WtgContents4 contents) |

## Example (as XML)

```xml
<wtg:International xmlns:wtg="https://www.wisetechglobal.com/">
  <wtg:Contents xmlns:wtg="https://www.wisetechglobal.com/" />
</wtg:International>
```

