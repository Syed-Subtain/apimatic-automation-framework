
# Wtg Content 14

Container for a individual content (line item) associated with the transaction.

## Structure

`WtgContent14`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `ContentID` | `Integer` | Optional | The unique numeric identifier for the content record.<br>**Default**: `0` | Integer getContentID() | setContentID(Integer contentID) |
| `PartNumber` | `String` | Optional | Part number for the line item. | String getPartNumber() | setPartNumber(String partNumber) |
| `Description` | `String` | Optional | Description for the line item. | String getDescription() | setDescription(String description) |
| `Quantity` | `Integer` | Optional | Quantity of the line item in the package.<br>**Default**: `0` | Integer getQuantity() | setQuantity(Integer quantity) |
| `OrderedQuantity` | `Integer` | Optional | Quantity of the line item that was ordered.<br>**Default**: `0` | Integer getOrderedQuantity() | setOrderedQuantity(Integer orderedQuantity) |
| `MonetaryValue` | `Double` | Optional | MonetaryValue of the line item.<br>**Default**: `0d` | Double getMonetaryValue() | setMonetaryValue(Double monetaryValue) |
| `WeightExact` | `Double` | Optional | WeightExact of the line item.<br>**Default**: `0d` | Double getWeightExact() | setWeightExact(Double weightExact) |
| `PurchaseOrderNumber` | `String` | Optional | Purchase order number associated with the line items. | String getPurchaseOrderNumber() | setPurchaseOrderNumber(String purchaseOrderNumber) |
| `BinNumber` | `String` | Optional | Bin number for the line item. | String getBinNumber() | setBinNumber(String binNumber) |
| `LotNumber` | `String` | Optional | Lot number for the line item. | String getLotNumber() | setLotNumber(String lotNumber) |
| `OriginCountryCode` | `String` | Optional | Origin country code for the line item. | String getOriginCountryCode() | setOriginCountryCode(String originCountryCode) |
| `ContentCode` | `String` | Optional | Content code for the line item. | String getContentCode() | setContentCode(String contentCode) |
| `ItemCode` | `String` | Optional | Item code for the line item. | String getItemCode() | setItemCode(String itemCode) |
| `ItemDescription` | `String` | Optional | Item description for the line item. | String getItemDescription() | setItemDescription(String itemDescription) |
| `RecordIdentifiers` | [`WtgRecordIdentifiers3`](../../doc/models/wtg-record-identifiers-3.md) | Optional | Outer container for transaction identifiers. | WtgRecordIdentifiers3 getRecordIdentifiers() | setRecordIdentifiers(WtgRecordIdentifiers3 recordIdentifiers) |

## Example (as XML)

```xml
<wtg:Content xmlns:wtg="https://www.wisetechglobal.com/">
  <wtg:RecordIdentifiers xmlns:wtg="https://www.wisetechglobal.com/" />
</wtg:Content>
```

