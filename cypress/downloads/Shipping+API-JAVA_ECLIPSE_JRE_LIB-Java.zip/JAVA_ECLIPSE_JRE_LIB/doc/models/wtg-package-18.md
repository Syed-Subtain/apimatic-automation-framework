
# Wtg Package 18

Container for an individual package associated with the transaction.

## Structure

`WtgPackage18`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `PackageID` | `Integer` | Optional | Unique identifier for the package.<br>**Default**: `0` | Integer getPackageID() | setPackageID(Integer packageID) |
| `Weight` | `Double` | Optional | The weight of the package.<br>**Default**: `0d` | Double getWeight() | setWeight(Double weight) |
| `Length` | `Double` | Optional | The dimensional lenth of the package.<br>**Default**: `0d` | Double getLength() | setLength(Double length) |
| `Width` | `Double` | Optional | The dimensional width of the package.<br>**Default**: `0d` | Double getWidth() | setWidth(Double width) |
| `Height` | `Double` | Optional | The dimensional height of the package.<br>**Default**: `0d` | Double getHeight() | setHeight(Double height) |
| `ContentDescription` | `String` | Optional | Free form description of the package's content. | String getContentDescription() | setContentDescription(String contentDescription) |
| `Pieces` | `String` | Optional | The number of pieces that make up the package. | String getPieces() | setPieces(String pieces) |
| `NMFC` | `String` | Optional | The National Motor Freight Classification of the package. | String getNMFC() | setNMFC(String nMFC) |
| `FreightClass` | `String` | Optional | The freight class of the package. | String getFreightClass() | setFreightClass(String freightClass) |
| `PackageType` | `String` | Optional | Numeric identifier for the carrier package type. | String getPackageType() | setPackageType(String packageType) |
| `WayBillNumber` | `String` | Optional | WayBill Number for the package. | String getWayBillNumber() | setWayBillNumber(String wayBillNumber) |
| `TrackingUrl` | `String` | Optional | Tracking URL for the package. | String getTrackingUrl() | setTrackingUrl(String trackingUrl) |
| `ShipperReference` | `String` | Optional | Primary shipping reference number. | String getShipperReference() | setShipperReference(String shipperReference) |
| `PackageReference` | `String` | Optional | Package reference number. | String getPackageReference() | setPackageReference(String packageReference) |
| `Reference1` | `String` | Optional | Package reference 1. | String getReference1() | setReference1(String reference1) |
| `Reference2` | `String` | Optional | Package reference 2. | String getReference2() | setReference2(String reference2) |
| `Reference3` | `String` | Optional | Package reference 3. | String getReference3() | setReference3(String reference3) |
| `Reference4` | `String` | Optional | Package reference 4. | String getReference4() | setReference4(String reference4) |
| `Reference5` | `String` | Optional | Package reference 5. | String getReference5() | setReference5(String reference5) |
| `Reference6` | `String` | Optional | Package reference 6. | String getReference6() | setReference6(String reference6) |
| `HistoryState` | `String` | Optional | Package history state. | String getHistoryState() | setHistoryState(String historyState) |
| `FreightCost` | `Double` | Optional | The freight cost for the package | Double getFreightCost() | setFreightCost(Double freightCost) |
| `AccessorialCost` | `Double` | Optional | The accessorial cost for the package | Double getAccessorialCost() | setAccessorialCost(Double accessorialCost) |
| `OtherCost` | `Double` | Optional | The other costs for the package | Double getOtherCost() | setOtherCost(Double otherCost) |
| `TotalCost` | `Double` | Optional | The total cost for the package | Double getTotalCost() | setTotalCost(Double totalCost) |
| `CustomerFreightCost` | `Double` | Optional | The customer freight cost for the package | Double getCustomerFreightCost() | setCustomerFreightCost(Double customerFreightCost) |
| `CustomerAccessorialCost` | `Double` | Optional | The customer accessorial cost for the package | Double getCustomerAccessorialCost() | setCustomerAccessorialCost(Double customerAccessorialCost) |
| `CustomerOtherCost` | `Double` | Optional | The customer other costs for the package | Double getCustomerOtherCost() | setCustomerOtherCost(Double customerOtherCost) |
| `CustomerTotalCost` | `Double` | Optional | The customer total cost for the package | Double getCustomerTotalCost() | setCustomerTotalCost(Double customerTotalCost) |
| `Contents` | [`WtgContents14`](../../doc/models/wtg-contents-14.md) | Optional | Container for all contents (line items) associated with the transaction. | WtgContents14 getContents() | setContents(WtgContents14 contents) |
| `RecordIdentifiers` | [`WtgRecordIdentifiers3`](../../doc/models/wtg-record-identifiers-3.md) | Optional | Outer container for transaction identifiers. | WtgRecordIdentifiers3 getRecordIdentifiers() | setRecordIdentifiers(WtgRecordIdentifiers3 recordIdentifiers) |
| `Rates` | [`WtgRates14`](../../doc/models/wtg-rates-14.md) | Optional | Container for all rates associated with the package | WtgRates14 getRates() | setRates(WtgRates14 rates) |

## Example (as XML)

```xml
<wtg:Package xmlns:wtg="https://www.wisetechglobal.com/">
  <wtg:Contents xmlns:wtg="https://www.wisetechglobal.com/" />
  <wtg:RecordIdentifiers xmlns:wtg="https://www.wisetechglobal.com/" />
  <wtg:Rates xmlns:wtg="https://www.wisetechglobal.com/" />
</wtg:Package>
```

