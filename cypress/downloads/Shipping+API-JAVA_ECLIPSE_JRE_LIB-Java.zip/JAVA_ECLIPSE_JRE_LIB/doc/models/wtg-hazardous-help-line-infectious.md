
# Wtg Hazardous Help Line Infectious

Container for the Infectious Helpline details associated with the transaction.

## Structure

`WtgHazardousHelpLineInfectious`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Phone` | `String` | Optional | Phone number of the Infectious Helpline. | String getPhone() | setPhone(String phone) |
| `Name` | `String` | Optional | Contact name for the Infectious Helpline. | String getName() | setName(String name) |
| `ContractNumber` | `String` | Optional | Contract number for the Infectious Helpline. | String getContractNumber() | setContractNumber(String contractNumber) |

## Example (as XML)

```xml
<wtg:HazardousHelpLineInfectious xmlns:wtg="https://www.wisetechglobal.com/" />
```

