
# Wtg Purpose Enum

## Enumeration

`WtgPurposeEnum`

## Fields

| Name |
|  --- |
| `Enum1` |
| `Enum2` |
| `Enum3` |
| `Enum4` |
| `Enum5` |
| `Enum6` |

