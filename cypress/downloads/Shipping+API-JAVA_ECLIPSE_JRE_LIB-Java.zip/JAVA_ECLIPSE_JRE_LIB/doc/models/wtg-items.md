
# Wtg Items

Items already packed into box

## Structure

`WtgItems`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Item` | [`List<WtgPrePackedItem>`](../../doc/models/wtg-pre-packed-item.md) | Optional | Item already packed into box | List<WtgPrePackedItem> getItem() | setItem(List<WtgPrePackedItem> item) |

## Example (as XML)

```xml
<wtg:Items xmlns:wtg="https://www.wisetechglobal.com/" />
```

