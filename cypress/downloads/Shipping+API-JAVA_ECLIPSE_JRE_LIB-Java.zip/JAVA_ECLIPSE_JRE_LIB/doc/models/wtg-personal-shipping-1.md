
# Wtg Personal Shipping 1

Container for personal shipping elements.

## Structure

`WtgPersonalShipping1`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `PersonalShipment` | `Boolean` | Optional | Indicates that shipment is a personal shipment.<br>**Default**: `false` | Boolean getPersonalShipment() | setPersonalShipment(Boolean personalShipment) |
| `PaymentMethodID` | `String` | Optional | The id of the payment method used to pay for a personal shipment. | String getPaymentMethodID() | setPaymentMethodID(String paymentMethodID) |
| `PaymentIntentID` | `String` | Optional | The id of the payment intent used to pay for a personal shipment. | String getPaymentIntentID() | setPaymentIntentID(String paymentIntentID) |
| `TotalCharge` | `Double` | Optional | Cost that the customer will be charged for the personal shipment.<br>**Default**: `0d` | Double getTotalCharge() | setTotalCharge(Double totalCharge) |
| `ConvenienceFee` | `Double` | Optional | Cost to the user for processing a personal shipment. This cost is included in the total cost<br>**Default**: `0d` | Double getConvenienceFee() | setConvenienceFee(Double convenienceFee) |
| `SavePaymentMethod` | `Boolean` | Optional | Whether or not to save the payment method..<br>**Default**: `false` | Boolean getSavePaymentMethod() | setSavePaymentMethod(Boolean savePaymentMethod) |
| `UpdatePaymentMethod` | `Boolean` | Optional | Whether or not to update the payment method..<br>**Default**: `false` | Boolean getUpdatePaymentMethod() | setUpdatePaymentMethod(Boolean updatePaymentMethod) |
| `ExpMonth` | `Long` | Optional | The expiry month for the credit card. | Long getExpMonth() | setExpMonth(Long expMonth) |
| `ExpYear` | `Long` | Optional | The expiry year for the credit card. | Long getExpYear() | setExpYear(Long expYear) |
| `RequestEmailNotification` | `Boolean` | Optional | Request an email notification on successful shipment.<br>**Default**: `false` | Boolean getRequestEmailNotification() | setRequestEmailNotification(Boolean requestEmailNotification) |
| `Packages` | [`WtgPackages11`](../../doc/models/wtg-packages-11.md) | Optional | Container for all packages associated with the transaction. | WtgPackages11 getPackages() | setPackages(WtgPackages11 packages) |

## Example (as XML)

```xml
<wtg:PersonalShipping xmlns:wtg="https://www.wisetechglobal.com/">
  <wtg:Packages xmlns:wtg="https://www.wisetechglobal.com/" />
</wtg:PersonalShipping>
```

