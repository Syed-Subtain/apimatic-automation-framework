
# Wtg Collect Terms Type Enum

## Enumeration

`WtgCollectTermsTypeEnum`

## Fields

| Name |
|  --- |
| `Enum1` |
| `Enum2` |

