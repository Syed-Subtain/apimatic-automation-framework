
# Wtg Output 1

Container for an output the transaction should generate or customize the printing of.

## Structure

`WtgOutput1`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `OutputType` | `Integer` | Optional | Type of output.  Defaults to all output types if not submitted.<br>**Default**: `0` | Integer getOutputType() | setOutputType(Integer outputType) |
| `Copies` | `Integer` | Optional | Number of copies of the specified output.  Defaults to one if not submitted.<br>**Default**: `0` | Integer getCopies() | setCopies(Integer copies) |
| `Pieces` | `Integer` | Optional | Number of pieces (e.g. packages, pallets) to produce the output for.  For example, produces labels with ' 1 of 2' and '2 or 2' indicators.  Defaults to one if not submitted.<br>**Default**: `0` | Integer getPieces() | setPieces(Integer pieces) |
| `PrintLater` | `Boolean` | Optional | Indicates whether the output should be printed at a later time. Defaults to false if not submitted.<br>**Default**: `false` | Boolean getPrintLater() | setPrintLater(Boolean printLater) |
| `PrinterID` | `Integer` | Optional | Printer to use when producing the output.  Default printer used if not submitted.<br>**Default**: `0` | Integer getPrinterID() | setPrinterID(Integer printerID) |
| `PrintToClient` | `Boolean` | Optional | Forces the return of the output to the client.  Default printing method used if not submitted.<br>**Default**: `false` | Boolean getPrintToClient() | setPrintToClient(Boolean printToClient) |

## Example (as XML)

```xml
<wtg:Output xmlns:wtg="https://www.wisetechglobal.com/" />
```

