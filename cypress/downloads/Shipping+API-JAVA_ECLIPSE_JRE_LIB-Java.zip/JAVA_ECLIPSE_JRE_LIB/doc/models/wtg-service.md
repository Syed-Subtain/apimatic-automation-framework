
# Wtg Service

Container for a single service.

## Structure

`WtgService`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `ServiceName` | `String` | Required | The carrier service description. | String getServiceName() | setServiceName(String serviceName) |
| `ServiceCode` | `String` | Required | Code associated with the service. | String getServiceCode() | setServiceCode(String serviceCode) |
| `Commitment` | [`WtgCommitment`](../../doc/models/wtg-commitment.md) | Required | Container for the carrier commitment details. | WtgCommitment getCommitment() | setCommitment(WtgCommitment commitment) |
| `Guaranteed` | `boolean` | Required | Indicates if the carrier service has a guaranteed delivery window. | boolean getGuaranteed() | setGuaranteed(boolean guaranteed) |

## Example (as XML)

```xml
<wtg:Service xmlns:wtg="https://www.wisetechglobal.com/">
  <wtg:ServiceName xmlns:wtg="https://www.wisetechglobal.com/">ServiceName4</wtg:ServiceName>
  <wtg:ServiceCode xmlns:wtg="https://www.wisetechglobal.com/">ServiceCode4</wtg:ServiceCode>
  <wtg:Commitment xmlns:wtg="https://www.wisetechglobal.com/">
    <wtg:DeliveryDate>DeliveryDate6</wtg:DeliveryDate>
    <wtg:DeliveryTime>DeliveryTime4</wtg:DeliveryTime>
    <wtg:PickupDate>PickupDate0</wtg:PickupDate>
    <wtg:DaysTransit>DaysTransit4</wtg:DaysTransit>
  </wtg:Commitment>
  <wtg:Guaranteed xmlns:wtg="https://www.wisetechglobal.com/">false</wtg:Guaranteed>
</wtg:Service>
```

