
# Wtg Record Identifiers 6

Outer container for transaction identifiers.

## Structure

`WtgRecordIdentifiers6`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `RecordIdentifier` | [`WtgRecordIdentifier1`](../../doc/models/wtg-record-identifier-1.md) | Optional | Inner container for transaction identifiers. | WtgRecordIdentifier1 getRecordIdentifier() | setRecordIdentifier(WtgRecordIdentifier1 recordIdentifier) |

## Example (as XML)

```xml
<wtg:RecordIdentifiers xmlns:wtg="https://www.wisetechglobal.com/">
  <wtg:RecordIdentifier xmlns:wtg="https://www.wisetechglobal.com/" />
</wtg:RecordIdentifiers>
```

