
# Wtg Order 3

Container for an individual order.

## Structure

`WtgOrder3`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `OrderID` | `Integer` | Optional | Identifier of the order being shipped.<br>**Default**: `0` | Integer getOrderID() | setOrderID(Integer orderID) |
| `OrderNumber` | `String` | Optional | Number of the order being shipped. | String getOrderNumber() | setOrderNumber(String orderNumber) |
| `ReleaseNumber` | `String` | Optional | Release number of the order being shipped. | String getReleaseNumber() | setReleaseNumber(String releaseNumber) |
| `OrderReference1` | `String` | Optional | First order reference number. | String getOrderReference1() | setOrderReference1(String orderReference1) |
| `OrderReference2` | `String` | Optional | Second order reference number. | String getOrderReference2() | setOrderReference2(String orderReference2) |
| `OrderReference3` | `String` | Optional | Third order reference number. | String getOrderReference3() | setOrderReference3(String orderReference3) |
| `SalesOrderNumber` | `String` | Optional | Sales order number of the order being shipped. | String getSalesOrderNumber() | setSalesOrderNumber(String salesOrderNumber) |
| `PurchaseOrderNumber` | `String` | Optional | Purchase order number of the order being shipped. | String getPurchaseOrderNumber() | setPurchaseOrderNumber(String purchaseOrderNumber) |
| `RecordIdentifiers` | [`WtgRecordIdentifiers3`](../../doc/models/wtg-record-identifiers-3.md) | Optional | Outer container for transaction identifiers. | WtgRecordIdentifiers3 getRecordIdentifiers() | setRecordIdentifiers(WtgRecordIdentifiers3 recordIdentifiers) |

## Example (as XML)

```xml
<wtg:Order xmlns:wtg="https://www.wisetechglobal.com/">
  <wtg:RecordIdentifiers xmlns:wtg="https://www.wisetechglobal.com/" />
</wtg:Order>
```

