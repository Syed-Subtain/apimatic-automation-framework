
# Wtg Package 6

Container for package level information about the rate returned.

## Structure

`WtgPackage6`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Rates` | [`WtgRates2`](../../doc/models/wtg-rates-2.md) | Required | Container for rates returned for the shipment packages. | WtgRates2 getRates() | setRates(WtgRates2 rates) |

## Example (as XML)

```xml
<wtg:Package xmlns:wtg="https://www.wisetechglobal.com/">
  <wtg:Rates xmlns:wtg="https://www.wisetechglobal.com/" />
</wtg:Package>
```

