
# Wtg Rates 4

Container all rates associated with the transaction.

## Structure

`WtgRates4`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Rate` | [`List<WtgRate4>`](../../doc/models/wtg-rate-4.md) | Optional | Container for an individual rate. | List<WtgRate4> getRate() | setRate(List<WtgRate4> rate) |

## Example (as XML)

```xml
<wtg:Rates xmlns:wtg="https://www.wisetechglobal.com/" />
```

