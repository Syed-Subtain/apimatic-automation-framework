
# Wtg International 11

Container for international details associated with the shipment.

## Structure

`WtgInternational11`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Contents` | [`WtgContents8`](../../doc/models/wtg-contents-8.md) | Optional | Container for all contents (line items) associated with the transaction. | WtgContents8 getContents() | setContents(WtgContents8 contents) |

## Example (as XML)

```xml
<wtg:International xmlns:wtg="https://www.wisetechglobal.com/">
  <wtg:Contents xmlns:wtg="https://www.wisetechglobal.com/" />
</wtg:International>
```

