
# Wtg Pierbridge Shipment Add Request

Adds shipment details to the database, does not notify any carriers about the shipment.

## Structure

`WtgPierbridgeShipmentAddRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `TransactionIdentifier` | `String` | Optional | A unique identifier for the transaction, this value is not used during processing and will be returned in the response. | String getTransactionIdentifier() | setTransactionIdentifier(String transactionIdentifier) |
| `ControlIdentifier` | `String` | Optional | A reference to a control which generated the request, this value is not used during processing and will be returned in the response. | String getControlIdentifier() | setControlIdentifier(String controlIdentifier) |
| `UserName` | `String` | Required | The user name to use when processing the transaction.<br>**Constraints**: *Minimum Length*: `1` | String getUserName() | setUserName(String userName) |
| `ISOCurrencyId` | `Integer` | Optional | The ID of the ISO Currency code in use.<br>**Default**: `0` | Integer getISOCurrencyId() | setISOCurrencyId(Integer iSOCurrencyId) |
| `Sender` | [`WtgSender2`](../../doc/models/wtg-sender-2.md) | Optional | Container to allow the customization of the sender address details associated with the transaction. | WtgSender2 getSender() | setSender(WtgSender2 sender) |
| `Receiver` | [`WtgReceiver10`](../../doc/models/wtg-receiver-10.md) | Required | Container for the receiver address details associated with the transaction. | WtgReceiver10 getReceiver() | setReceiver(WtgReceiver10 receiver) |
| `Carrier` | `int` | Required | Numeric identifier for the carrier. | int getCarrier() | setCarrier(int carrier) |
| `ServiceType` | `int` | Required | Carrier service (e.g. Next Day, Ground, Express) to ship with. | int getServiceType() | setServiceType(int serviceType) |
| `PurchaseOrderNumber` | `String` | Optional | Purchase order number associated with the transaction. | String getPurchaseOrderNumber() | setPurchaseOrderNumber(String purchaseOrderNumber) |
| `SalesOrderNumber` | `String` | Optional | Sales order number associated with the transaction. | String getSalesOrderNumber() | setSalesOrderNumber(String salesOrderNumber) |
| `BoLNumber` | `String` | Optional | Bill of Lading number associated with the shipment. | String getBoLNumber() | setBoLNumber(String boLNumber) |
| `AccountID` | `Integer` | Optional | Overrides the sender's account to allow shipping using any account.<br>**Default**: `0` | Integer getAccountID() | setAccountID(Integer accountID) |
| `ShipDate` | `String` | Optional | Date the items are to be shipped. Defaults to current date if not submitted. | String getShipDate() | setShipDate(String shipDate) |
| `Packages` | [`WtgPackages15`](../../doc/models/wtg-packages-15.md) | Required | Container for all packages associated with the transaction. | WtgPackages15 getPackages() | setPackages(WtgPackages15 packages) |
| `Charges` | [`WtgCharges11`](../../doc/models/wtg-charges-11.md) | Optional | Container for all charges within the group associated with the transaction. | WtgCharges11 getCharges() | setCharges(WtgCharges11 charges) |
| `PersonalShipping` | [`WtgPersonalShipping3`](../../doc/models/wtg-personal-shipping-3.md) | Optional | Container for personal shipping elements. | WtgPersonalShipping3 getPersonalShipping() | setPersonalShipping(WtgPersonalShipping3 personalShipping) |
| `Diagnostics` | [`WtgDiagnostics`](../../doc/models/wtg-diagnostics.md) | Optional | Container for logging and diagnostic override elements. | WtgDiagnostics getDiagnostics() | setDiagnostics(WtgDiagnostics diagnostics) |
| `Identification` | [`WtgIdentification`](../../doc/models/wtg-identification.md) | Optional | Container for client identification elements. | WtgIdentification getIdentification() | setIdentification(WtgIdentification identification) |
| `SourceApplication` | [`WtgSourceApplication`](../../doc/models/wtg-source-application.md) | Optional | Container for app specific source identification elements. | WtgSourceApplication getSourceApplication() | setSourceApplication(WtgSourceApplication sourceApplication) |

## Example (as XML)

```xml
<wtg:PierbridgeShipmentAddRequest xmlns:wtg="https://www.wisetechglobal.com/">
  <wtg:UserName xmlns:wtg="https://www.wisetechglobal.com/">UserName6</wtg:UserName>
  <wtg:Sender xmlns:wtg="https://www.wisetechglobal.com/" />
  <wtg:Receiver xmlns:wtg="https://www.wisetechglobal.com/">
    <wtg:CompanyName>CompanyName8</wtg:CompanyName>
    <wtg:Street>Street6</wtg:Street>
    <wtg:City>City4</wtg:City>
    <wtg:Region>Region8</wtg:Region>
    <wtg:PostalCode>PostalCode0</wtg:PostalCode>
    <wtg:Country>Country2</wtg:Country>
  </wtg:Receiver>
  <wtg:Carrier xmlns:wtg="https://www.wisetechglobal.com/">34</wtg:Carrier>
  <wtg:ServiceType xmlns:wtg="https://www.wisetechglobal.com/">150</wtg:ServiceType>
  <wtg:Packages xmlns:wtg="https://www.wisetechglobal.com/">
    <wtg:Package>
      <wtg:ReceiverName>ReceiverName4</wtg:ReceiverName>
      <wtg:PackageType>154</wtg:PackageType>
      <wtg:Charges />
    </wtg:Package>
    <wtg:Package>
      <wtg:ReceiverName>ReceiverName5</wtg:ReceiverName>
      <wtg:PackageType>153</wtg:PackageType>
      <wtg:Charges />
    </wtg:Package>
    <wtg:Package>
      <wtg:ReceiverName>ReceiverName6</wtg:ReceiverName>
      <wtg:PackageType>152</wtg:PackageType>
      <wtg:Charges />
    </wtg:Package>
  </wtg:Packages>
  <wtg:Charges xmlns:wtg="https://www.wisetechglobal.com/" />
  <wtg:PersonalShipping xmlns:wtg="https://www.wisetechglobal.com/" />
  <wtg:Diagnostics xmlns:wtg="https://www.wisetechglobal.com/" />
  <wtg:Identification xmlns:wtg="https://www.wisetechglobal.com/" />
  <wtg:SourceApplication xmlns:wtg="https://www.wisetechglobal.com/" />
</wtg:PierbridgeShipmentAddRequest>
```

