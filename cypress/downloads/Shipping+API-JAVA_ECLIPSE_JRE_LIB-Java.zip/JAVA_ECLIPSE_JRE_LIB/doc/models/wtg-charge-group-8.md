
# Wtg Charge Group 8

Container for an individual charge group associated with the transaction.

## Structure

`WtgChargeGroup8`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `ChargeGroupType` | `int` | Required | An identifier for the type of the charge group. | int getChargeGroupType() | setChargeGroupType(int chargeGroupType) |
| `ChargeGroupDescription` | `String` | Required | The description for the group of charges. | String getChargeGroupDescription() | setChargeGroupDescription(String chargeGroupDescription) |
| `ChargeGroupValue` | `Double` | Optional | The value of the charge group associated with the transaction.<br>**Default**: `0d` | Double getChargeGroupValue() | setChargeGroupValue(Double chargeGroupValue) |
| `ChargeGroupCurrency` | `String` | Optional | A code indicating the type of currency for the charges group. | String getChargeGroupCurrency() | setChargeGroupCurrency(String chargeGroupCurrency) |
| `ChargeGroupISOCurrency` | `Integer` | Optional | ISO code for the currency associated with the transaction.<br>**Default**: `0` | Integer getChargeGroupISOCurrency() | setChargeGroupISOCurrency(Integer chargeGroupISOCurrency) |
| `ChargeGroupISOCurrencySymbol` | `String` | Optional | Currency symbol for the charge group currency. | String getChargeGroupISOCurrencySymbol() | setChargeGroupISOCurrencySymbol(String chargeGroupISOCurrencySymbol) |
| `Charges` | [`WtgCharges8`](../../doc/models/wtg-charges-8.md) | Required | Container for all charges within the group associated with the transaction. | WtgCharges8 getCharges() | setCharges(WtgCharges8 charges) |

## Example (as XML)

```xml
<wtg:ChargeGroup xmlns:wtg="https://www.wisetechglobal.com/">
  <wtg:ChargeGroupType xmlns:wtg="https://www.wisetechglobal.com/">28</wtg:ChargeGroupType>
  <wtg:ChargeGroupDescription xmlns:wtg="https://www.wisetechglobal.com/">ChargeGroupDescription8</wtg:ChargeGroupDescription>
  <wtg:Charges xmlns:wtg="https://www.wisetechglobal.com/" />
</wtg:ChargeGroup>
```

