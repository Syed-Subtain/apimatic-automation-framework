
# Wtg Source Application

Container for app specific source identification elements.

## Structure

`WtgSourceApplication`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `ApplicationName` | `String` | Optional | The named instance of the app used to create the transaction. | String getApplicationName() | setApplicationName(String applicationName) |
| `ApplicationBaseName` | `String` | Optional | The base name of the app used to create the transaction. | String getApplicationBaseName() | setApplicationBaseName(String applicationBaseName) |
| `ApplicationVersion` | `String` | Optional | The submitting apps version number. | String getApplicationVersion() | setApplicationVersion(String applicationVersion) |

## Example (as XML)

```xml
<wtg:SourceApplication xmlns:wtg="https://www.wisetechglobal.com/" />
```

