
# Wtg Packages 1

Container for all packages associated with the transaction.

## Structure

`WtgPackages1`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Package` | [`List<WtgPackage1>`](../../doc/models/wtg-package-1.md) | Required | Container for an individual package associated with the transaction. | List<WtgPackage1> getPackage() | setPackage(List<WtgPackage1> mPackage) |

## Example (as XML)

```xml
<wtg:Packages xmlns:wtg="https://www.wisetechglobal.com/">
  <wtg:Package xmlns:wtg="https://www.wisetechglobal.com/">
    <wtg:PackageID>PackageID8</wtg:PackageID>
    <wtg:WayBillNumber>WayBillNumber6</wtg:WayBillNumber>
  </wtg:Package>
</wtg:Packages>
```

