
# Wtg Packages 15

Container for all packages associated with the transaction.

## Structure

`WtgPackages15`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Package` | [`List<WtgPackage16>`](../../doc/models/wtg-package-16.md) | Required | Container for an individual package associated with the transaction. | List<WtgPackage16> getPackage() | setPackage(List<WtgPackage16> mPackage) |

## Example (as XML)

```xml
<wtg:Packages xmlns:wtg="https://www.wisetechglobal.com/">
  <wtg:Package xmlns:wtg="https://www.wisetechglobal.com/">
    <wtg:ReceiverName>ReceiverName0</wtg:ReceiverName>
    <wtg:PackageType>232</wtg:PackageType>
    <wtg:Charges />
  </wtg:Package>
</wtg:Packages>
```

