
# Wtg Charge Groups 2

Container for all charge groups associated with the transaction.

## Structure

`WtgChargeGroups2`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `ChargeGroup` | [`List<WtgChargeGroup2>`](../../doc/models/wtg-charge-group-2.md) | Optional | Container for an individual charge group associated with the transaction. | List<WtgChargeGroup2> getChargeGroup() | setChargeGroup(List<WtgChargeGroup2> chargeGroup) |

## Example (as XML)

```xml
<wtg:ChargeGroups xmlns:wtg="https://www.wisetechglobal.com/" />
```

