
# Wtg Rates

Container all rates associated with the transaction.

## Structure

`WtgRates`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Rate` | [`List<WtgRate>`](../../doc/models/wtg-rate.md) | Optional | Container for an individual rate. | List<WtgRate> getRate() | setRate(List<WtgRate> rate) |

## Example (as XML)

```xml
<wtg:Rates xmlns:wtg="https://www.wisetechglobal.com/" />
```

