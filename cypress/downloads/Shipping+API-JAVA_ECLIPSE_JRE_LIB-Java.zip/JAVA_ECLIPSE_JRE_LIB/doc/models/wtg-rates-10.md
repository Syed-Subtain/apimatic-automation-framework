
# Wtg Rates 10

Container all rates associated with the transaction.

## Structure

`WtgRates10`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Rate` | [`List<WtgRate10>`](../../doc/models/wtg-rate-10.md) | Optional | Container for an individual rate. | List<WtgRate10> getRate() | setRate(List<WtgRate10> rate) |

## Example (as XML)

```xml
<wtg:Rates xmlns:wtg="https://www.wisetechglobal.com/" />
```

