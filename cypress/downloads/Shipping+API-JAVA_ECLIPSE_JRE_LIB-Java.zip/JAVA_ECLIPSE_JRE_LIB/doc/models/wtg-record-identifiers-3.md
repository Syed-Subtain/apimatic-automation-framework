
# Wtg Record Identifiers 3

Outer container for transaction identifiers.

## Structure

`WtgRecordIdentifiers3`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `RecordIdentifier` | [`List<WtgRecordIdentifier1>`](../../doc/models/wtg-record-identifier-1.md) | Optional | Inner container for transaction identifiers. | List<WtgRecordIdentifier1> getRecordIdentifier() | setRecordIdentifier(List<WtgRecordIdentifier1> recordIdentifier) |

## Example (as XML)

```xml
<wtg:RecordIdentifiers xmlns:wtg="https://www.wisetechglobal.com/" />
```

