
# Wtg Special Care

Outer container for special care details for package.

## Structure

`WtgSpecialCare`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Type` | [`WtgTypeEnum`](../../doc/models/wtg-type-enum.md) | Optional | Describes the special care required | WtgTypeEnum getType() | setType(WtgTypeEnum type) |
| `Temperature` | [`WtgTemperatureEnum`](../../doc/models/wtg-temperature-enum.md) | Optional | Describes the storage temperature for the special care package | WtgTemperatureEnum getTemperature() | setTemperature(WtgTemperatureEnum temperature) |
| `ExpediteMethod` | [`WtgExpediteMethodEnum`](../../doc/models/wtg-expedite-method-enum.md) | Optional | Describes the method used to expedite delivery of the special care package | WtgExpediteMethodEnum getExpediteMethod() | setExpediteMethod(WtgExpediteMethodEnum expediteMethod) |
| `Instructions` | [`WtgInstructionsEnum`](../../doc/models/wtg-instructions-enum.md) | Optional | Describes the which contact method to be used to communicate problems delivering the special care package | WtgInstructionsEnum getInstructions() | setInstructions(WtgInstructionsEnum instructions) |
| `ReturnToShipper` | `Boolean` | Optional | Indicates whether a special care package should be returned to shipper if problems arise.<br>**Default**: `false` | Boolean getReturnToShipper() | setReturnToShipper(Boolean returnToShipper) |
| `PackageIdentifier` | `String` | Optional | The identifier of the attached tracking device. | String getPackageIdentifier() | setPackageIdentifier(String packageIdentifier) |

## Example (as XML)

```xml
<wtg:SpecialCare xmlns:wtg="https://www.wisetechglobal.com/" />
```

