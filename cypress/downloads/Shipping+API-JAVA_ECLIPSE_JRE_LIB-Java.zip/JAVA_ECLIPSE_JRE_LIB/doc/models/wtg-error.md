
# Wtg Error

Container for a single error found whilst processing the transaction.

## Structure

`WtgError`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Code` | `Integer` | Optional | A code indicating the error status.<br>**Default**: `0` | Integer getCode() | setCode(Integer code) |
| `Description` | `String` | Required | A description of the error. | String getDescription() | setDescription(String description) |

## Example (as XML)

```xml
<wtg:Error xmlns:wtg="https://www.wisetechglobal.com/">
  <wtg:Description xmlns:wtg="https://www.wisetechglobal.com/">Description6</wtg:Description>
</wtg:Error>
```

