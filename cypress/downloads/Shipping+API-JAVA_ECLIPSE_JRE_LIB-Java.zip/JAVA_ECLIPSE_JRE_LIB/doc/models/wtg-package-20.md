
# Wtg Package 20

Container for an individual package associated with the transaction.

## Structure

`WtgPackage20`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Weight` | `double` | Required | The weight of the package.<br>**Default**: `0d` | double getWeight() | setWeight(double weight) |
| `MajorWeight` | `double` | Required | Major Weight of the package.<br>**Default**: `0d` | double getMajorWeight() | setMajorWeight(double majorWeight) |
| `MinorWeight` | `double` | Required | Minor Weight of the package.<br>**Default**: `0d` | double getMinorWeight() | setMinorWeight(double minorWeight) |
| `WeightUOM` | `String` | Optional | The units of measure for the package weight. | String getWeightUOM() | setWeightUOM(String weightUOM) |
| `PackageType` | `int` | Required | Carrier package (e.g. letter, package, pallet) that is to be rated for. | int getPackageType() | setPackageType(int packageType) |
| `Quantity` | `Double` | Optional | Quantity of the line item in the package.<br>**Default**: `0d` | Double getQuantity() | setQuantity(Double quantity) |
| `Value` | `Double` | Optional | Monetary value of a single line item.<br>**Default**: `0d` | Double getValue() | setValue(Double value) |

## Example (as XML)

```xml
<wtg:Package xmlns:wtg="https://www.wisetechglobal.com/">
  <wtg:Weight xmlns:wtg="https://www.wisetechglobal.com/">0</wtg:Weight>
  <wtg:MajorWeight xmlns:wtg="https://www.wisetechglobal.com/">0</wtg:MajorWeight>
  <wtg:MinorWeight xmlns:wtg="https://www.wisetechglobal.com/">0</wtg:MinorWeight>
</wtg:Package>
```

