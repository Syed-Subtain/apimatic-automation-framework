
# Wtg Rate 2

Container for individual rates associated with the package.

## Structure

`WtgRate2`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `RateType` | `String` | Optional | An identifier for the type of rate. | String getRateType() | setRateType(String rateType) |
| `TotalAccessorialCharges` | `String` | Optional | Total accessorial charge at package level for the rate type. | String getTotalAccessorialCharges() | setTotalAccessorialCharges(String totalAccessorialCharges) |
| `TotalShippingCharges` | `String` | Optional | Total shipping charge at package level for the rate type. | String getTotalShippingCharges() | setTotalShippingCharges(String totalShippingCharges) |
| `TotalCharges` | `String` | Optional | Total charge at package level for the rate type. | String getTotalCharges() | setTotalCharges(String totalCharges) |

## Example (as XML)

```xml
<wtg:Rate xmlns:wtg="https://www.wisetechglobal.com/" />
```

