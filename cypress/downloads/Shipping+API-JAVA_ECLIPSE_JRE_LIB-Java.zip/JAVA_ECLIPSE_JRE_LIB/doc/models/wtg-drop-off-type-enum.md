
# Wtg Drop Off Type Enum

## Enumeration

`WtgDropOffTypeEnum`

## Fields

| Name |
|  --- |
| `RegularPickup` |
| `RequestCourier` |
| `DropBox` |
| `BusinessServiceCenter` |
| `Station` |

