
# Wtg Packages 4

Container for all packages associated with the transaction.

## Structure

`WtgPackages4`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Package` | [`List<WtgPackage4>`](../../doc/models/wtg-package-4.md) | Required | Container for an individual package associated with the transaction. | List<WtgPackage4> getPackage() | setPackage(List<WtgPackage4> mPackage) |

## Example (as XML)

```xml
<wtg:Packages xmlns:wtg="https://www.wisetechglobal.com/" />
```

