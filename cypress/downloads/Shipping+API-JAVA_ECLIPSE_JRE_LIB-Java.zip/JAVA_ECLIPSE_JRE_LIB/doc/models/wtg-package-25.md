
# Wtg Package 25

Container for an individual package associated with the transaction.

## Structure

`WtgPackage25`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `PackageID` | `Integer` | Optional | Unique identifier for the package.<br>**Default**: `0` | Integer getPackageID() | setPackageID(Integer packageID) |
| `PackageHistoryState` | `String` | Optional | Description of the package history status.<br>**Default**: `"0"` | String getPackageHistoryState() | setPackageHistoryState(String packageHistoryState) |
| `ShipperReference` | `String` | Optional | Primary shipping reference number. | String getShipperReference() | setShipperReference(String shipperReference) |
| `ReferenceOne` | `String` | Optional | First additional reference number. | String getReferenceOne() | setReferenceOne(String referenceOne) |
| `ReferenceTwo` | `String` | Optional | Second additional reference number. | String getReferenceTwo() | setReferenceTwo(String referenceTwo) |
| `ReferenceThree` | `String` | Optional | Third additional reference number. | String getReferenceThree() | setReferenceThree(String referenceThree) |
| `ReferenceFour` | `String` | Optional | Fourth additional reference number. | String getReferenceFour() | setReferenceFour(String referenceFour) |
| `ReferenceFive` | `String` | Optional | Fifth additional reference number. | String getReferenceFive() | setReferenceFive(String referenceFive) |
| `ReferenceSix` | `String` | Optional | Sixth additional reference number. | String getReferenceSix() | setReferenceSix(String referenceSix) |
| `WayBillNumber` | `String` | Optional | Tracking number of the package. | String getWayBillNumber() | setWayBillNumber(String wayBillNumber) |
| `RecordIdentifiers` | [`WtgRecordIdentifiers11`](../../doc/models/wtg-record-identifiers-11.md) | Optional | Outer container for transaction identifiers. | WtgRecordIdentifiers11 getRecordIdentifiers() | setRecordIdentifiers(WtgRecordIdentifiers11 recordIdentifiers) |
| `International` | [`WtgInternational17`](../../doc/models/wtg-international-17.md) | Optional | Container for international details associated with the shipment. | WtgInternational17 getInternational() | setInternational(WtgInternational17 international) |
| `Status` | [`WtgStatus7`](../../doc/models/wtg-status-7.md) | Required | Container for transaction errors and warning elements. | WtgStatus7 getStatus() | setStatus(WtgStatus7 status) |

## Example (as XML)

```xml
<wtg:Package xmlns:wtg="https://www.wisetechglobal.com/">
  <wtg:RecordIdentifiers xmlns:wtg="https://www.wisetechglobal.com/" />
  <wtg:International xmlns:wtg="https://www.wisetechglobal.com/" />
  <wtg:Status xmlns:wtg="https://www.wisetechglobal.com/">
    <wtg:Code>108</wtg:Code>
    <wtg:Description>Description8</wtg:Description>
    <wtg:Warnings />
    <wtg:Errors />
  </wtg:Status>
</wtg:Package>
```

