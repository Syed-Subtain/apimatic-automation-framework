
# Wtg Instructions Enum

## Enumeration

`WtgInstructionsEnum`

## Fields

| Name |
|  --- |
| `Enum512` |
| `Enum1024` |
| `Enum2048` |
| `Enum4096` |

