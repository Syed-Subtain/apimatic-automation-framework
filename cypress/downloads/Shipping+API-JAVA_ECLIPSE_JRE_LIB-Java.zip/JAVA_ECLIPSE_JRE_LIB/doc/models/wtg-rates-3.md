
# Wtg Rates 3

Container all rates associated with the transaction.

## Structure

`WtgRates3`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Rate` | [`List<WtgRate3>`](../../doc/models/wtg-rate-3.md) | Optional | Container for an individual rate. | List<WtgRate3> getRate() | setRate(List<WtgRate3> rate) |

## Example (as XML)

```xml
<wtg:Rates xmlns:wtg="https://www.wisetechglobal.com/" />
```

