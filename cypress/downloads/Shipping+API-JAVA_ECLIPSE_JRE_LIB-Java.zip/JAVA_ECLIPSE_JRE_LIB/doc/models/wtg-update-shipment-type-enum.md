
# Wtg Update Shipment Type Enum

## Enumeration

`WtgUpdateShipmentTypeEnum`

## Fields

| Name |
|  --- |
| `None` |
| `FullUpdate` |

