
# Wtg Packages

Container for all packages associated with the transaction.

## Structure

`WtgPackages`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Package` | [`List<WtgPackage>`](../../doc/models/wtg-package.md) | Required | Container for an individual package associated with the transaction. | List<WtgPackage> getPackage() | setPackage(List<WtgPackage> mPackage) |

## Example (as XML)

```xml
<wtg:Packages xmlns:wtg="https://www.wisetechglobal.com/" />
```

