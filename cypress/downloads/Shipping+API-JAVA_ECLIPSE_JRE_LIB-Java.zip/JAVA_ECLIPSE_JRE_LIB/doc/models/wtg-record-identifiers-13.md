
# Wtg Record Identifiers 13

Outer container for transaction identifiers.

## Structure

`WtgRecordIdentifiers13`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `RecordIdentifier` | [`WtgRecordIdentifier8`](../../doc/models/wtg-record-identifier-8.md) | Optional | Inner container for transaction identifiers. | WtgRecordIdentifier8 getRecordIdentifier() | setRecordIdentifier(WtgRecordIdentifier8 recordIdentifier) |

## Example (as XML)

```xml
<wtg:RecordIdentifiers xmlns:wtg="https://www.wisetechglobal.com/">
  <wtg:RecordIdentifier xmlns:wtg="https://www.wisetechglobal.com/" />
</wtg:RecordIdentifiers>
```

