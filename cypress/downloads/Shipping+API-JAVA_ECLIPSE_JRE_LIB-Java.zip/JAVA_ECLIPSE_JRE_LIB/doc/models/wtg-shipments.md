
# Wtg Shipments

Container for all shipments assocaited with the transaction.

## Structure

`WtgShipments`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Shipment` | [`List<WtgShipment>`](../../doc/models/wtg-shipment.md) | Optional | Container for a single shipment. | List<WtgShipment> getShipment() | setShipment(List<WtgShipment> shipment) |

## Example (as XML)

```xml
<wtg:Shipments xmlns:wtg="https://www.wisetechglobal.com/" />
```

