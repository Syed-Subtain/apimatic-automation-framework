
# Wtg Freight Packages

Container for all packages associated with the transaction.

## Structure

`WtgFreightPackages`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Package` | [`List<WtgPackage7>`](../../doc/models/wtg-package-7.md) | Required | Container for an individual package associated with the transaction. | List<WtgPackage7> getPackage() | setPackage(List<WtgPackage7> mPackage) |

## Example (as XML)

```xml
<wtg:FreightPackages xmlns:wtg="https://www.wisetechglobal.com/">
  <wtg:Package xmlns:wtg="https://www.wisetechglobal.com/">
    <wtg:International />
  </wtg:Package>
</wtg:FreightPackages>
```

