
# Tns Pages

Container for all pages to be printed by the caller of the transaction (client).

## Structure

`TnsPages`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Page` | [`List<TnsPage>`](../../doc/models/tns-page.md) | Optional | Container for an individual page to be printed by the caller of the transaction (client). | List<TnsPage> getPage() | setPage(List<TnsPage> page) |

## Example (as JSON)

```json
{
  "Page": null
}
```

