
# Wtg Rate 9

Container for an individual rate.

## Structure

`WtgRate9`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `RateType` | `int` | Required | Numeric identifier for the rate type. | int getRateType() | setRateType(int rateType) |
| `TotalAccessorialCharges` | `Double` | Optional | Total accessorial charges for the rate type. | Double getTotalAccessorialCharges() | setTotalAccessorialCharges(Double totalAccessorialCharges) |
| `TotalShippingCharges` | `Double` | Optional | Total shipping charges for the rate type. | Double getTotalShippingCharges() | setTotalShippingCharges(Double totalShippingCharges) |
| `TotalCharges` | `Double` | Optional | Total packages charge for the rate type. | Double getTotalCharges() | setTotalCharges(Double totalCharges) |

## Example (as XML)

```xml
<wtg:Rate xmlns:wtg="https://www.wisetechglobal.com/">
  <wtg:RateType xmlns:wtg="https://www.wisetechglobal.com/">10</wtg:RateType>
</wtg:Rate>
```

