
# Wtg Pierbridge End of Day Action Request

Starts the end of day process for an open carrier manifest.

## Structure

`WtgPierbridgeEndOfDayActionRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `TransactionIdentifier` | `String` | Optional | A unique identifier for the transaction, this value is not used during processing and will be returned in the response. | String getTransactionIdentifier() | setTransactionIdentifier(String transactionIdentifier) |
| `ControlIdentifier` | `String` | Optional | A reference to a control which generated the request, this value is not used during processing and will be returned in the response. | String getControlIdentifier() | setControlIdentifier(String controlIdentifier) |
| `UserName` | `String` | Required | The user name to use when processing the transaction. | String getUserName() | setUserName(String userName) |
| `Carrier` | `int` | Required | Numeric identifier for the carrier.<br>**Default**: `0` | int getCarrier() | setCarrier(int carrier) |
| `Identifier` | `String` | Optional | Identifies what to do an end of day for. | String getIdentifier() | setIdentifier(String identifier) |
| `Live` | `Boolean` | Optional | Indicates whether the transaction is a test or live.  Defaults to system configured value if not submitted.<br>**Default**: `false` | Boolean getLive() | setLive(Boolean live) |
| `DateClosed` | `String` | Required | Shipping date that is being closed. | String getDateClosed() | setDateClosed(String dateClosed) |
| `Account` | `String` | Optional | Account number to perform the end of day action for. | String getAccount() | setAccount(String account) |
| `AccountID` | `Integer` | Optional | Account identifier to list manifests for.<br>**Default**: `0` | Integer getAccountID() | setAccountID(Integer accountID) |
| `RateReconcile` | `Boolean` | Optional | Causes Shipment Server to retrieve any revised rates from the carrier and reconile them against the ship time rates.<br>**Default**: `false` | Boolean getRateReconcile() | setRateReconcile(Boolean rateReconcile) |
| `ShippingKeys` | [`WtgShippingKeys`](../../doc/models/wtg-shipping-keys.md) | Optional | Container for shipping keys. | WtgShippingKeys getShippingKeys() | setShippingKeys(WtgShippingKeys shippingKeys) |
| `Diagnostics` | [`WtgDiagnostics`](../../doc/models/wtg-diagnostics.md) | Optional | Container for logging and diagnostic override elements. | WtgDiagnostics getDiagnostics() | setDiagnostics(WtgDiagnostics diagnostics) |
| `Identification` | [`WtgIdentification`](../../doc/models/wtg-identification.md) | Optional | Container for client identification elements. | WtgIdentification getIdentification() | setIdentification(WtgIdentification identification) |

## Example (as XML)

```xml
<wtg:PierbridgeEndOfDayActionRequest xmlns:wtg="https://www.wisetechglobal.com/">
  <wtg:Carrier xmlns:wtg="https://www.wisetechglobal.com/">0</wtg:Carrier>
</wtg:PierbridgeEndOfDayActionRequest>
```

