
# Wtg Orders 1

Container all orders associated with the transaction.

## Structure

`WtgOrders1`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Order` | [`List<WtgOrder1>`](../../doc/models/wtg-order-1.md) | Optional | Container for an individual order. | List<WtgOrder1> getOrder() | setOrder(List<WtgOrder1> order) |

## Example (as XML)

```xml
<wtg:Orders xmlns:wtg="https://www.wisetechglobal.com/" />
```

