
# Wtg Packages 17

Container for all packages associated with the transaction.

## Structure

`WtgPackages17`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Package` | [`List<WtgPackage18>`](../../doc/models/wtg-package-18.md) | Optional | Container for an individual package associated with the transaction. | List<WtgPackage18> getPackage() | setPackage(List<WtgPackage18> mPackage) |

## Example (as XML)

```xml
<wtg:Packages xmlns:wtg="https://www.wisetechglobal.com/" />
```

