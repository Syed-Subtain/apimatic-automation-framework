
# Wtg Package 22

Container for an individual package associated with the transaction.

## Structure

`WtgPackage22`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `AccountID` | `Integer` | Optional | The account identifier that identifies the carrier account used for tracking.<br>**Default**: `0` | Integer getAccountID() | setAccountID(Integer accountID) |
| `PackageID` | `Integer` | Optional | Identifier of the package to track.  Must submit BoL number, package identifier or tracking number.<br>**Default**: `0` | Integer getPackageID() | setPackageID(Integer packageID) |
| `WayBillNumber` | `String` | Optional | Tracking number of the package to track.  Must submit BoL number, package identifier or tracking number. | String getWayBillNumber() | setWayBillNumber(String wayBillNumber) |
| `ShipperReference` | `String` | Optional | Track by Shipper reference number, supported by FedEx Web Services. | String getShipperReference() | setShipperReference(String shipperReference) |
| `ReferenceOne` | `String` | Optional | Track by reference number 1, supported by FedEx Web Services. | String getReferenceOne() | setReferenceOne(String referenceOne) |
| `ReferenceTwo` | `String` | Optional | Track by reference number 2, supported by FedEx Web Services. | String getReferenceTwo() | setReferenceTwo(String referenceTwo) |

## Example (as XML)

```xml
<wtg:Package xmlns:wtg="https://www.wisetechglobal.com/" />
```

