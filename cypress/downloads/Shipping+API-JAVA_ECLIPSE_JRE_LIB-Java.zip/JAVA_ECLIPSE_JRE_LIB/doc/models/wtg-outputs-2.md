
# Wtg Outputs 2

Container for outputs the transaction should generate or customize the printing of.

## Structure

`WtgOutputs2`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Output` | [`List<WtgOutput6>`](../../doc/models/wtg-output-6.md) | Optional | Container for an output the transaction should generate or customize the printing of. | List<WtgOutput6> getOutput() | setOutput(List<WtgOutput6> output) |

## Example (as XML)

```xml
<wtg:Outputs xmlns:wtg="https://www.wisetechglobal.com/" />
```

