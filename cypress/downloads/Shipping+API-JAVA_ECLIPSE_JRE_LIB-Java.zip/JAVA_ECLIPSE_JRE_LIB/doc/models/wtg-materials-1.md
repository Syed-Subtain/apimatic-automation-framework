
# Wtg Materials 1

Container for all material details.

## Structure

`WtgMaterials1`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Material` | [`List<WtgMaterial2>`](../../doc/models/wtg-material-2.md) | Optional | Container for material details. | List<WtgMaterial2> getMaterial() | setMaterial(List<WtgMaterial2> material) |

## Example (as XML)

```xml
<wtg:Materials xmlns:wtg="https://www.wisetechglobal.com/" />
```

