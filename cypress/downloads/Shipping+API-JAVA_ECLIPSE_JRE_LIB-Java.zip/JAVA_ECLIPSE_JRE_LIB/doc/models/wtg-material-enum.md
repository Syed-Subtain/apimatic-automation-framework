
# Wtg Material Enum

## Enumeration

`WtgMaterialEnum`

## Fields

| Name |
|  --- |
| `Enum1` |
| `Enum2` |

