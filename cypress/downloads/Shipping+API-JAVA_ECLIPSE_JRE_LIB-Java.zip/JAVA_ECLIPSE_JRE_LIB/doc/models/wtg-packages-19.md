
# Wtg Packages 19

Container for all packages associated with the transaction.

## Structure

`WtgPackages19`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Package` | [`List<WtgPackage20>`](../../doc/models/wtg-package-20.md) | Required | Container for an individual package associated with the transaction. | List<WtgPackage20> getPackage() | setPackage(List<WtgPackage20> mPackage) |

## Example (as XML)

```xml
<wtg:Packages xmlns:wtg="https://www.wisetechglobal.com/" />
```

