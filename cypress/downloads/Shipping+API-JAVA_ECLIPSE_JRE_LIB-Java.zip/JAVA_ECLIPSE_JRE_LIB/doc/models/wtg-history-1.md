
# Wtg History 1

Container for the package history status entries.

## Structure

`WtgHistory1`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `TrackStatus` | [`List<WtgTrackStatus>`](../../doc/models/wtg-track-status.md) | Optional | Container for tracking history state details. | List<WtgTrackStatus> getTrackStatus() | setTrackStatus(List<WtgTrackStatus> trackStatus) |

## Example (as XML)

```xml
<wtg:History xmlns:wtg="https://www.wisetechglobal.com/" />
```

