
# Wtg Warnings 2

Container for all warnings found whilst processing the transaction.

## Structure

`WtgWarnings2`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Warning` | [`List<WtgWarning1>`](../../doc/models/wtg-warning-1.md) | Optional | Container for a single warning found whilst processing the transaction. | List<WtgWarning1> getWarning() | setWarning(List<WtgWarning1> warning) |

## Example (as XML)

```xml
<wtg:Warnings xmlns:wtg="https://www.wisetechglobal.com/" />
```

