# Shipping API

```java
ShippingAPIController shippingAPIController = client.getShippingAPIController();
```

## Class Name

`ShippingAPIController`

## Methods

* [Cartonize](../../doc/controllers/shipping-api.md#cartonize)
* [End of Day Action](../../doc/controllers/shipping-api.md#end-of-day-action)
* [End of Day Document Get](../../doc/controllers/shipping-api.md#end-of-day-document-get)
* [End of Day Get](../../doc/controllers/shipping-api.md#end-of-day-get)
* [End of Day List](../../doc/controllers/shipping-api.md#end-of-day-list)
* [Print](../../doc/controllers/shipping-api.md#print)
* [Rate](../../doc/controllers/shipping-api.md#rate)
* [Rate Shop](../../doc/controllers/shipping-api.md#rate-shop)
* [Rate Shop With Cartonize](../../doc/controllers/shipping-api.md#rate-shop-with-cartonize)
* [Route](../../doc/controllers/shipping-api.md#route)
* [Ship](../../doc/controllers/shipping-api.md#ship)
* [Ship Requisition](../../doc/controllers/shipping-api.md#ship-requisition)
* [Shipment Add](../../doc/controllers/shipping-api.md#shipment-add)
* [Shipment Detail Query](../../doc/controllers/shipping-api.md#shipment-detail-query)
* [Shipment Get](../../doc/controllers/shipping-api.md#shipment-get)
* [Time in Transit](../../doc/controllers/shipping-api.md#time-in-transit)
* [Track](../../doc/controllers/shipping-api.md#track)
* [Void](../../doc/controllers/shipping-api.md#void)


# Cartonize

```java
CompletableFuture<WtgPierbridgeCartonizeResponse> cartonizeAsync(
    final WtgPierbridgeCartonizeRequest body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`WtgPierbridgeCartonizeRequest`](../../doc/models/wtg-pierbridge-cartonize-request.md) | Body, Required | - |

## Response Type

[`WtgPierbridgeCartonizeResponse`](../../doc/models/wtg-pierbridge-cartonize-response.md)

## Example Usage

```java
WtgPierbridgeCartonizeRequest body = new WtgPierbridgeCartonizeRequest();
body.setUserName("UserName2");
body.setCarrier(0);
body.setShippingCarrier(0);
body.setCartonization(new WtgCartonization());
body.getCartonization().setCartonizationGroupID(0);
body.getCartonization().setContents(new WtgContents());
body.getCartonization().getContents().setContent(new LinkedList<>());

WtgContent bodyCartonizationContentsContent0 = new WtgContent();
bodyCartonizationContentsContent0.setContentRefNumber("ContentRefNumber3");
body.getCartonization().getContents().getContent().add(bodyCartonizationContentsContent0);

body.getCartonization().setPackageTemplate(new WtgPackageTemplate());

shippingAPIController.cartonizeAsync(body).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```


# End of Day Action

```java
CompletableFuture<WtgPierbridgeEndOfDayActionResponse> endOfDayActionAsync(
    final WtgPierbridgeEndOfDayActionRequest body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`WtgPierbridgeEndOfDayActionRequest`](../../doc/models/wtg-pierbridge-end-of-day-action-request.md) | Body, Required | - |

## Response Type

[`WtgPierbridgeEndOfDayActionResponse`](../../doc/models/wtg-pierbridge-end-of-day-action-response.md)

## Example Usage

```java
WtgPierbridgeEndOfDayActionRequest body = new WtgPierbridgeEndOfDayActionRequest();
body.setUserName("UserName2");
body.setCarrier(0);
body.setDateClosed("DateClosed0");

shippingAPIController.endOfDayActionAsync(body).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```


# End of Day Document Get

```java
CompletableFuture<WtgPierbridgeEndOfDayDocumentGetResponse> endOfDayDocumentGetAsync(
    final WtgPierbridgeEndOfDayDocumentGetRequest body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`WtgPierbridgeEndOfDayDocumentGetRequest`](../../doc/models/wtg-pierbridge-end-of-day-document-get-request.md) | Body, Required | - |

## Response Type

[`WtgPierbridgeEndOfDayDocumentGetResponse`](../../doc/models/wtg-pierbridge-end-of-day-document-get-response.md)

## Example Usage

```java
WtgPierbridgeEndOfDayDocumentGetRequest body = new WtgPierbridgeEndOfDayDocumentGetRequest();
body.setUserName("UserName2");

shippingAPIController.endOfDayDocumentGetAsync(body).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```


# End of Day Get

```java
CompletableFuture<WtgPierbridgeEndOfDayGetResponse> endOfDayGetAsync(
    final WtgPierbridgeEndOfDayGetRequest body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`WtgPierbridgeEndOfDayGetRequest`](../../doc/models/wtg-pierbridge-end-of-day-get-request.md) | Body, Required | - |

## Response Type

[`WtgPierbridgeEndOfDayGetResponse`](../../doc/models/wtg-pierbridge-end-of-day-get-response.md)

## Example Usage

```java
WtgPierbridgeEndOfDayGetRequest body = new WtgPierbridgeEndOfDayGetRequest();
body.setUserName("UserName2");

shippingAPIController.endOfDayGetAsync(body).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```


# End of Day List

```java
CompletableFuture<WtgPierbridgeEndOfDayListResponse> endOfDayListAsync(
    final WtgPierbridgeEndOfDayListRequest body,
    final String apikey)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`WtgPierbridgeEndOfDayListRequest`](../../doc/models/wtg-pierbridge-end-of-day-list-request.md) | Body, Required | - |
| `apikey` | `String` | Query, Optional | - |

## Response Type

[`WtgPierbridgeEndOfDayListResponse`](../../doc/models/wtg-pierbridge-end-of-day-list-response.md)

## Example Usage

```java
WtgPierbridgeEndOfDayListRequest body = new WtgPierbridgeEndOfDayListRequest();
body.setUserName("UserName2");
body.setCarrier(42);

shippingAPIController.endOfDayListAsync(body, null).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```


# Print

```java
CompletableFuture<String> printAsync(
    final WtgPierbridgePrintRequest body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`WtgPierbridgePrintRequest`](../../doc/models/wtg-pierbridge-print-request.md) | Body, Required | - |

## Response Type

`String`

## Example Usage

```java
WtgPierbridgePrintRequest body = new WtgPierbridgePrintRequest();
body.setUserName("UserName2");

shippingAPIController.printAsync(body).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```


# Rate

```java
CompletableFuture<WtgPierbridgeRateResponse> rateAsync(
    final WtgPierbridgeRateRequest body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`WtgPierbridgeRateRequest`](../../doc/models/wtg-pierbridge-rate-request.md) | Body, Required | - |

## Response Type

[`WtgPierbridgeRateResponse`](../../doc/models/wtg-pierbridge-rate-response.md)

## Example Usage

```java
WtgPierbridgeRateRequest body = new WtgPierbridgeRateRequest();
body.setUserName("UserName2");
body.setCarrier(0);
body.setServiceType(0);
body.setReceiver(new WtgReceiver());

shippingAPIController.rateAsync(body).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```


# Rate Shop

```java
CompletableFuture<WtgPierbridgeRateShopResponse> rateShopAsync(
    final WtgPierbridgeRateShopRequest body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`WtgPierbridgeRateShopRequest`](../../doc/models/wtg-pierbridge-rate-shop-request.md) | Body, Required | - |

## Response Type

[`WtgPierbridgeRateShopResponse`](../../doc/models/wtg-pierbridge-rate-shop-response.md)

## Example Usage

```java
WtgPierbridgeRateShopRequest body = new WtgPierbridgeRateShopRequest();
body.setUserName("UserName2");
body.setReceiver(new WtgReceiver2());

shippingAPIController.rateShopAsync(body).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```


# Rate Shop With Cartonize

```java
CompletableFuture<WtgPierbridgeRateShopWithCartonizeResponse> rateShopWithCartonizeAsync(
    final WtgPierbridgeRateShopWithCartonizeRequest body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`WtgPierbridgeRateShopWithCartonizeRequest`](../../doc/models/wtg-pierbridge-rate-shop-with-cartonize-request.md) | Body, Required | - |

## Response Type

[`WtgPierbridgeRateShopWithCartonizeResponse`](../../doc/models/wtg-pierbridge-rate-shop-with-cartonize-response.md)

## Example Usage

```java
WtgPierbridgeRateShopWithCartonizeRequest body = new WtgPierbridgeRateShopWithCartonizeRequest();
body.setUserName("UserName2");
body.setReceiver(new WtgReceiver3());

shippingAPIController.rateShopWithCartonizeAsync(body).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```


# Route

```java
CompletableFuture<WtgPierbridgeRouteResponse> routeAsync(
    final WtgPierbridgeRouteRequest body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`WtgPierbridgeRouteRequest`](../../doc/models/wtg-pierbridge-route-request.md) | Body, Required | - |

## Response Type

[`WtgPierbridgeRouteResponse`](../../doc/models/wtg-pierbridge-route-response.md)

## Example Usage

```java
WtgPierbridgeRouteRequest body = new WtgPierbridgeRouteRequest();
body.setUserName("UserName2");
body.setWeight(251.2);

shippingAPIController.routeAsync(body).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```


# Ship

```java
CompletableFuture<WtgPierbridgeShipResponse> shipAsync(
    final WtgPierbridgeShipRequest body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`WtgPierbridgeShipRequest`](../../doc/models/wtg-pierbridge-ship-request.md) | Body, Required | - |

## Response Type

[`WtgPierbridgeShipResponse`](../../doc/models/wtg-pierbridge-ship-response.md)

## Example Usage

```java
WtgPierbridgeShipRequest body = new WtgPierbridgeShipRequest();
body.setUserName("UserName2");
body.setCarrier(0);
body.setServiceType(0);
body.setReceiver(new WtgReceiver7());
body.getReceiver().setStreet("Street0");
body.getReceiver().setCity("City0");
body.getReceiver().setRegion("Region2");
body.getReceiver().setPostalCode("PostalCode6");
body.getReceiver().setCountry("Country6");

shippingAPIController.shipAsync(body).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```


# Ship Requisition

```java
CompletableFuture<String> shipRequisitionAsync(
    final WtgPierbridgeShipRequisitionRequest body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`WtgPierbridgeShipRequisitionRequest`](../../doc/models/wtg-pierbridge-ship-requisition-request.md) | Body, Required | - |

## Response Type

`String`

## Example Usage

```java
WtgPierbridgeShipRequisitionRequest body = new WtgPierbridgeShipRequisitionRequest();
body.setUserName("UserName2");
body.setReceiver(new WtgReceiver9());
body.getReceiver().setName("Name2");
body.getReceiver().setStreet("Street0");
body.getReceiver().setCity("City0");
body.getReceiver().setCountry("Country6");
body.setPackages(new WtgPackages14());
body.getPackages().setPackage(new LinkedList<>());

WtgPackage15 bodyPackagesPackage0 = new WtgPackage15();
bodyPackagesPackage0.setPackageType(0);
body.getPackages().getPackage().add(bodyPackagesPackage0);


shippingAPIController.shipRequisitionAsync(body).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```


# Shipment Add

```java
CompletableFuture<WtgPierbridgeShipmentAddResponse> shipmentAddAsync(
    final WtgPierbridgeShipmentAddRequest body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`WtgPierbridgeShipmentAddRequest`](../../doc/models/wtg-pierbridge-shipment-add-request.md) | Body, Required | - |

## Response Type

[`WtgPierbridgeShipmentAddResponse`](../../doc/models/wtg-pierbridge-shipment-add-response.md)

## Example Usage

```java
WtgPierbridgeShipmentAddRequest body = new WtgPierbridgeShipmentAddRequest();
body.setUserName("UserName2");
body.setReceiver(new WtgReceiver10());
body.getReceiver().setCompanyName("CompanyName2");
body.getReceiver().setStreet("Street0");
body.getReceiver().setCity("City0");
body.getReceiver().setRegion("Region2");
body.getReceiver().setPostalCode("PostalCode6");
body.getReceiver().setCountry("Country6");
body.setCarrier(42);
body.setServiceType(158);
body.setPackages(new WtgPackages15());
body.getPackages().setPackage(new LinkedList<>());

WtgPackage16 bodyPackagesPackage0 = new WtgPackage16();
bodyPackagesPackage0.setReceiverName("ReceiverName0");
bodyPackagesPackage0.setPackageType(62);
body.getPackages().getPackage().add(bodyPackagesPackage0);


shippingAPIController.shipmentAddAsync(body).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```


# Shipment Detail Query

This query can be used to return shipments for a defined criteria. Please use the examples below, using the field definitions to enter your own criteria for your query.

```java
CompletableFuture<WtgPierbridgeShipmentDetailQueryResponse> shipmentDetailQueryAsync(
    final WtgPierbridgeShipmentDetailQueryRequest body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`WtgPierbridgeShipmentDetailQueryRequest`](../../doc/models/wtg-pierbridge-shipment-detail-query-request.md) | Body, Required | - |

## Response Type

[`WtgPierbridgeShipmentDetailQueryResponse`](../../doc/models/wtg-pierbridge-shipment-detail-query-response.md)

## Example Usage

```java
WtgPierbridgeShipmentDetailQueryRequest body = new WtgPierbridgeShipmentDetailQueryRequest();
body.setUserName("BlackBoxAPI");
body.setPageSize(10);
body.setPageNumber(3);
body.setSearchByField(WtgSearchByFieldEnum.SALESORDERNUMBER);
body.setSearchByValue("M51989");
body.setIncludeDefaultRates(true);
body.setIncludeListRates(true);
body.setIncludeCustomRates(true);

shippingAPIController.shipmentDetailQueryAsync(body).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```


# Shipment Get

```java
CompletableFuture<WtgPierbridgeShipmentGetResponse> shipmentGetAsync(
    final WtgPierbridgeShipmentGetRequest body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`WtgPierbridgeShipmentGetRequest`](../../doc/models/wtg-pierbridge-shipment-get-request.md) | Body, Required | - |

## Response Type

[`WtgPierbridgeShipmentGetResponse`](../../doc/models/wtg-pierbridge-shipment-get-response.md)

## Example Usage

```java
WtgPierbridgeShipmentGetRequest body = new WtgPierbridgeShipmentGetRequest();
body.setShipmentID(48);
body.setUserName("UserName2");

shippingAPIController.shipmentGetAsync(body).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```


# Time in Transit

```java
CompletableFuture<WtgPierbridgeTimeInTransitResponse> timeInTransitAsync(
    final WtgPierbridgeTimeInTransitRequest body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`WtgPierbridgeTimeInTransitRequest`](../../doc/models/wtg-pierbridge-time-in-transit-request.md) | Body, Required | - |

## Response Type

[`WtgPierbridgeTimeInTransitResponse`](../../doc/models/wtg-pierbridge-time-in-transit-response.md)

## Example Usage

```java
WtgPierbridgeTimeInTransitRequest body = new WtgPierbridgeTimeInTransitRequest();
body.setUserName("UserName2");
body.setCarrier(42);
body.setServiceType(158);
body.setReceiver(new WtgReceiver14());
body.getReceiver().setCity("City0");
body.getReceiver().setRegion("Region2");
body.getReceiver().setPostalCode("PostalCode6");
body.getReceiver().setCountry("Country6");
body.setPackages(new WtgPackages19());
body.getPackages().setPackage(new LinkedList<>());

WtgPackage20 bodyPackagesPackage0 = new WtgPackage20();
bodyPackagesPackage0.setWeight(255.06);
bodyPackagesPackage0.setMajorWeight(121.32);
bodyPackagesPackage0.setMinorWeight(214.32);
bodyPackagesPackage0.setPackageType(62);
body.getPackages().getPackage().add(bodyPackagesPackage0);


shippingAPIController.timeInTransitAsync(body).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```


# Track

```java
CompletableFuture<WtgPierbridgeTrackResponse> trackAsync(
    final WtgPierbridgeTrackRequest body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`WtgPierbridgeTrackRequest`](../../doc/models/wtg-pierbridge-track-request.md) | Body, Required | - |

## Response Type

[`WtgPierbridgeTrackResponse`](../../doc/models/wtg-pierbridge-track-response.md)

## Example Usage

```java
WtgPierbridgeTrackRequest body = new WtgPierbridgeTrackRequest();
body.setUserName("UserName2");
body.setPackages(new WtgPackages21());
body.getPackages().setPackage(new LinkedList<>());

WtgPackage22 bodyPackagesPackage0 = new WtgPackage22();
body.getPackages().getPackage().add(bodyPackagesPackage0);


shippingAPIController.trackAsync(body).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```


# Void

```java
CompletableFuture<WtgPierbridgeVoidResponse> voidAsync(
    final WtgPierbridgeVoidRequest body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`WtgPierbridgeVoidRequest`](../../doc/models/wtg-pierbridge-void-request.md) | Body, Required | - |

## Response Type

[`WtgPierbridgeVoidResponse`](../../doc/models/wtg-pierbridge-void-response.md)

## Example Usage

```java
WtgPierbridgeVoidRequest body = new WtgPierbridgeVoidRequest();
body.setUserName("UserName2");

shippingAPIController.voidAsync(body).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

