
# TMS Warehouse

## Structure

`TMSWarehouse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `code` | `string` | Required | warehouse code | getCode(): string | setCode(string code): void |
| `description` | `string` | Required | Warehouse description | getDescription(): string | setDescription(string description): void |
| `environment` | `string` | Required | TMS environemnt | getEnvironment(): string | setEnvironment(string environment): void |
| `active` | `string` | Required | status warehouse 1 active 0 not active | getActive(): string | setActive(string active): void |

## Example (as JSON)

```json
{
  "code": "HKG",
  "description": "Hong Kong Warehouse test",
  "environment": "1",
  "active": "1"
}
```

