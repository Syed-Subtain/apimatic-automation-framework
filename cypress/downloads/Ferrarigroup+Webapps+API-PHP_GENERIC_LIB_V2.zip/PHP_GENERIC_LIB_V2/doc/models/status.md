
# Status

description of the status change event

## Structure

`Status`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `date` | `string` | Required | date of event (could have time information as well) | getDate(): string | setDate(string date): void |
| `statusInfo` | `string` | Required | description of the status<br>**Constraints**: *Maximum Length*: `30` | getStatusInfo(): string | setStatusInfo(string statusInfo): void |
| `tracking` | `?string` | Optional | tracking information linked to the status (i.e carrier number)<br>**Constraints**: *Maximum Length*: `20` | getTracking(): ?string | setTracking(?string tracking): void |
| `officeInCharge` | `?string` | Optional | Ferrari office in charge of the event<br>**Constraints**: *Maximum Length*: `20` | getOfficeInCharge(): ?string | setOfficeInCharge(?string officeInCharge): void |

## Example (as JSON)

```json
{
  "date": "2020-08-05 12:00 or 2020-08-05",
  "status_info": "processing by Ferrari"
}
```

