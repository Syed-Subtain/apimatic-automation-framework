
# Tms Shipment Post

## Structure

`TmsShipmentPost`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `orderNum` | `string` | Required | - | getOrderNum(): string | setOrderNum(string orderNum): void |
| `type` | `string` | Required | Tipo spedizione P = pickup D =delivery C = Completa<br>**Constraints**: *Minimum Length*: `1` | getType(): string | setType(string type): void |
| `serviceType` | `string` | Required | **Constraints**: *Maximum Length*: `45` | getServiceType(): string | setServiceType(string serviceType): void |
| `priority` | `int` | Required | priorità per ordinamento lista ePod | getPriority(): int | setPriority(int priority): void |
| `customerName` | `string` | Required | - | getCustomerName(): string | setCustomerName(string customerName): void |
| `customerAddress` | `string` | Required | - | getCustomerAddress(): string | setCustomerAddress(string customerAddress): void |
| `customerZip` | `string` | Required | - | getCustomerZip(): string | setCustomerZip(string customerZip): void |
| `customerCity` | `string` | Required | - | getCustomerCity(): string | setCustomerCity(string customerCity): void |
| `customerProv` | `string` | Required | - | getCustomerProv(): string | setCustomerProv(string customerProv): void |
| `customerCountry` | `string` | Required | - | getCustomerCountry(): string | setCustomerCountry(string customerCountry): void |
| `customerPhone` | `string` | Required | - | getCustomerPhone(): string | setCustomerPhone(string customerPhone): void |
| `customerContact` | `string` | Required | - | getCustomerContact(): string | setCustomerContact(string customerContact): void |
| `customerPassportId` | `string` | Required | - | getCustomerPassportId(): string | setCustomerPassportId(string customerPassportId): void |
| `pickupName` | `string` | Required | - | getPickupName(): string | setPickupName(string pickupName): void |
| `pickupAddress` | `string` | Required | - | getPickupAddress(): string | setPickupAddress(string pickupAddress): void |
| `pickupZip` | `string` | Required | - | getPickupZip(): string | setPickupZip(string pickupZip): void |
| `pickupDistrict` | `string` | Required | - | getPickupDistrict(): string | setPickupDistrict(string pickupDistrict): void |
| `pickupCity` | `string` | Required | - | getPickupCity(): string | setPickupCity(string pickupCity): void |
| `pickupProv` | `string` | Required | - | getPickupProv(): string | setPickupProv(string pickupProv): void |
| `pickupCountry` | `string` | Required | - | getPickupCountry(): string | setPickupCountry(string pickupCountry): void |
| `pickupPhone` | `string` | Required | - | getPickupPhone(): string | setPickupPhone(string pickupPhone): void |
| `pickupContact` | `string` | Required | - | getPickupContact(): string | setPickupContact(string pickupContact): void |
| `pickupPassportId` | `string` | Required | - | getPickupPassportId(): string | setPickupPassportId(string pickupPassportId): void |
| `deliveryName` | `string` | Required | - | getDeliveryName(): string | setDeliveryName(string deliveryName): void |
| `deliveryAddress` | `string` | Required | - | getDeliveryAddress(): string | setDeliveryAddress(string deliveryAddress): void |
| `deliveryZip` | `string` | Required | - | getDeliveryZip(): string | setDeliveryZip(string deliveryZip): void |
| `deliveryDistrict` | `string` | Required | - | getDeliveryDistrict(): string | setDeliveryDistrict(string deliveryDistrict): void |
| `deliveryCity` | `string` | Required | - | getDeliveryCity(): string | setDeliveryCity(string deliveryCity): void |
| `deliveryProv` | `string` | Required | - | getDeliveryProv(): string | setDeliveryProv(string deliveryProv): void |
| `deliveryCountry` | `string` | Required | - | getDeliveryCountry(): string | setDeliveryCountry(string deliveryCountry): void |
| `deliveryPhone` | `string` | Required | - | getDeliveryPhone(): string | setDeliveryPhone(string deliveryPhone): void |
| `deliveryContact` | `string` | Required | destinatario della consegna, viene aggiornato dall'ePod<br>**Constraints**: *Maximum Length*: `45` | getDeliveryContact(): string | setDeliveryContact(string deliveryContact): void |
| `deliveryPassportId` | `string` | Required | documento del destinatario della consegna, viene aggiornato dall'ePod<br>**Constraints**: *Maximum Length*: `45` | getDeliveryPassportId(): string | setDeliveryPassportId(string deliveryPassportId): void |
| `remarks` | `string` | Required | note del pickup, possono essere modificate dall'ePod<br>**Constraints**: *Maximum Length*: `1024` | getRemarks(): string | setRemarks(string remarks): void |
| `internalRemarks` | `string` | Required | **Constraints**: *Maximum Length*: `1024` | getInternalRemarks(): string | setInternalRemarks(string internalRemarks): void |
| `controlRemarks` | `string` | Required | **Constraints**: *Maximum Length*: `1024` | getControlRemarks(): string | setControlRemarks(string controlRemarks): void |
| `expParcelNum` | `string` | Required | numero di collo previsti<br>**Constraints**: *Maximum Length*: `45` | getExpParcelNum(): string | setExpParcelNum(string expParcelNum): void |
| `actParcelNum` | `string` | Required | numero di colli effettivi, aggiornato dall'ePod<br>**Constraints**: *Maximum Length*: `45` | getActParcelNum(): string | setActParcelNum(string actParcelNum): void |
| `status` | `string` | Required | stato TBP = to be processed, P = processed, EXP = Exported<br>**Default**: `'TBP'` | getStatus(): string | setStatus(string status): void |
| `timeLastUpdate` | `\DateTime` | Required | datetime ultimo aggiornamento spedizione | getTimeLastUpdate(): \DateTime | setTimeLastUpdate(\DateTime timeLastUpdate): void |
| `timeSchedulePickup` | `\DateTime` | Required | data di previsto pickup | getTimeSchedulePickup(): \DateTime | setTimeSchedulePickup(\DateTime timeSchedulePickup): void |
| `timeSchedulePickupT` | `string` | Required | ora prevista di pickup | getTimeSchedulePickupT(): string | setTimeSchedulePickupT(string timeSchedulePickupT): void |
| `timeScheduleDelivery` | `\DateTime` | Required | data di prevista consegna | getTimeScheduleDelivery(): \DateTime | setTimeScheduleDelivery(\DateTime timeScheduleDelivery): void |
| `timeScheduleDeliveryT` | `string` | Required | ora di prevista consegna | getTimeScheduleDeliveryT(): string | setTimeScheduleDeliveryT(string timeScheduleDeliveryT): void |
| `timeActualPickup` | `\DateTime` | Required | Datetime effettivo di pickup, aggiornato dall'ePod | getTimeActualPickup(): \DateTime | setTimeActualPickup(\DateTime timeActualPickup): void |
| `timeActualDelivery` | `\DateTime` | Required | - | getTimeActualDelivery(): \DateTime | setTimeActualDelivery(\DateTime timeActualDelivery): void |
| `actualContactName` | `string` | Required | come delivery contact da aggiornare insieme | getActualContactName(): string | setActualContactName(string actualContactName): void |
| `actualId` | `string` | Required | - | getActualId(): string | setActualId(string actualId): void |
| `customerRef` | `string` | Required | riferimenti<br>**Constraints**: *Maximum Length*: `45` | getCustomerRef(): string | setCustomerRef(string customerRef): void |
| `house` | `string` | Required | **Constraints**: *Maximum Length*: `45` | getHouse(): string | setHouse(string house): void |
| `mawb` | `string` | Required | **Constraints**: *Maximum Length*: `45` | getMawb(): string | setMawb(string mawb): void |
| `manifest` | `string` | Required | manifest generato dal backend<br>**Constraints**: *Maximum Length*: `45` | getManifest(): string | setManifest(string manifest): void |
| `crewId` | `int` | Required | id dell'equipaggio (crew) a cui è assegnata la spedizione | getCrewId(): int | setCrewId(int crewId): void |
| `warehouseId` | `string` | Required | id del magazzino | getWarehouseId(): string | setWarehouseId(string warehouseId): void |
| `reason` | `string` | Required | - | getReason(): string | setReason(string reason): void |
| `customerRequest` | `string` | Required | - | getCustomerRequest(): string | setCustomerRequest(string customerRequest): void |
| `signature` | `string` | Required | i della signature di pickup | getSignature(): string | setSignature(string signature): void |
| `pickable` | `string` | Required | valore inserito se il pickup va a buon fine<br>**Constraints**: *Maximum Length*: `1` | getPickable(): string | setPickable(string pickable): void |
| `deliverable` | `string` | Required | valore inserito se la delivery va a buon fine<br>**Constraints**: *Maximum Length*: `1` | getDeliverable(): string | setDeliverable(string deliverable): void |
| `isSynchro` | `string` | Required | - | getIsSynchro(): string | setIsSynchro(string isSynchro): void |
| `synchroDate` | `string` | Required | - | getSynchroDate(): string | setSynchroDate(string synchroDate): void |
| `deliveryReason` | `string` | Required | - | getDeliveryReason(): string | setDeliveryReason(string deliveryReason): void |
| `deliveryCustomerRequest` | `string` | Required | - | getDeliveryCustomerRequest(): string | setDeliveryCustomerRequest(string deliveryCustomerRequest): void |
| `deliveryRemarks` | `string` | Required | valore modificabile dall'epod<br>**Constraints**: *Maximum Length*: `1024` | getDeliveryRemarks(): string | setDeliveryRemarks(string deliveryRemarks): void |
| `deliverySignature` | `string` | Required | id firma di delivery | getDeliverySignature(): string | setDeliverySignature(string deliverySignature): void |
| `cashOnDelivery` | `int` | Required | valore contrassegno | getCashOnDelivery(): int | setCashOnDelivery(int cashOnDelivery): void |
| `incoterm` | `string` | Required | - | getIncoterm(): string | setIncoterm(string incoterm): void |
| `cites` | `string` | Required | - | getCites(): string | setCites(string cites): void |
| `atacarnet` | `string` | Required | - | getAtacarnet(): string | setAtacarnet(string atacarnet): void |
| `kimberly` | `string` | Required | - | getKimberly(): string | setKimberly(string kimberly): void |
| `environment` | `int` | Required | environment ufficio es HKG = 1 | getEnvironment(): int | setEnvironment(int environment): void |
| `updateWeight` | `string` | Required | flag utilizzato per aggiornamento lato server | getUpdateWeight(): string | setUpdateWeight(string updateWeight): void |
| `destAirport` | `string` | Required | - | getDestAirport(): string | setDestAirport(string destAirport): void |
| `idAreaPickup` | `string` | Required | - | getIdAreaPickup(): string | setIdAreaPickup(string idAreaPickup): void |
| `idAreaDelivery` | `string` | Required | - | getIdAreaDelivery(): string | setIdAreaDelivery(string idAreaDelivery): void |
| `orderTags` | `string` | Required | - | getOrderTags(): string | setOrderTags(string orderTags): void |
| `bookingRef` | `string` | Required | codice spedizione in altro sistema es shipping order<br>**Constraints**: *Maximum Length*: `54` | getBookingRef(): string | setBookingRef(string bookingRef): void |
| `podExported` | `string` | Required | - | getPodExported(): string | setPodExported(string podExported): void |
| `pickupExported` | `string` | Required | - | getPickupExported(): string | setPickupExported(string pickupExported): void |
| `seal` | `string` | Required | sigilli presenti a sistema dovrebbero essere presenti anche nei dati dei colli<br>**Constraints**: *Maximum Length*: `255` | getSeal(): string | setSeal(string seal): void |
| `cashOnDeliveryCur` | `string` | Required | - | getCashOnDeliveryCur(): string | setCashOnDeliveryCur(string cashOnDeliveryCur): void |
| `wrhHold` | `int` | Required | se fermo in magazzino | getWrhHold(): int | setWrhHold(int wrhHold): void |
| `prerefno` | `string` | Required | - | getPrerefno(): string | setPrerefno(string prerefno): void |
| `consolidationId` | `string` | Required | - | getConsolidationId(): string | setConsolidationId(string consolidationId): void |
| `trackingExport` | `string` | Required | - | getTrackingExport(): string | setTrackingExport(string trackingExport): void |
| `exported` | `string` | Required | - | getExported(): string | setExported(string exported): void |
| `pickupGuardRef` | `string` | Required | guardia che ha effettuato il pickup | getPickupGuardRef(): string | setPickupGuardRef(string pickupGuardRef): void |
| `deliveryGuardRef` | `string` | Required | guardia che ha effettuato la delivery | getDeliveryGuardRef(): string | setDeliveryGuardRef(string deliveryGuardRef): void |
| `prExported` | `string` | Required | - | getPrExported(): string | setPrExported(string prExported): void |
| `fm3000PodExported` | `string` | Required | - | getFm3000PodExported(): string | setFm3000PodExported(string fm3000PodExported): void |
| `fm3000PkExported` | `string` | Required | - | getFm3000PkExported(): string | setFm3000PkExported(string fm3000PkExported): void |
| `airexpParcelUpdate` | `string` | Required | - | getAirexpParcelUpdate(): string | setAirexpParcelUpdate(string airexpParcelUpdate): void |
| `as400Exp` | `string` | Required | - | getAs400Exp(): string | setAs400Exp(string as400Exp): void |
| `contact` | `string` | Required | - | getContact(): string | setContact(string contact): void |
| `contact2` | `string` | Required | - | getContact2(): string | setContact2(string contact2): void |
| `attn` | `string` | Required | - | getAttn(): string | setAttn(string attn): void |
| `attn2` | `string` | Required | - | getAttn2(): string | setAttn2(string attn2): void |
| `manifestTms` | `string` | Required | - | getManifestTms(): string | setManifestTms(string manifestTms): void |
| `truckp` | `string` | Required | - | getTruckp(): string | setTruckp(string truckp): void |
| `truckd` | `string` | Required | - | getTruckd(): string | setTruckd(string truckd): void |
| `timeScanIn` | `string` | Required | - | getTimeScanIn(): string | setTimeScanIn(string timeScanIn): void |
| `deliveries` | `string` | Required | - | getDeliveries(): string | setDeliveries(string deliveries): void |
| `deliveryPhone2` | `string` | Required | - | getDeliveryPhone2(): string | setDeliveryPhone2(string deliveryPhone2): void |
| `declaredValue` | `string` | Required | - | getDeclaredValue(): string | setDeclaredValue(string declaredValue): void |
| `insuredValue` | `string` | Required | - | getInsuredValue(): string | setInsuredValue(string insuredValue): void |
| `hideshp` | `string` | Required | - | getHideshp(): string | setHideshp(string hideshp): void |
| `hidecne` | `string` | Required | - | getHidecne(): string | setHidecne(string hidecne): void |
| `hidesrv` | `string` | Required | - | getHidesrv(): string | setHidesrv(string hidesrv): void |
| `timeTruckOut` | `string` | Required | - | getTimeTruckOut(): string | setTimeTruckOut(string timeTruckOut): void |
| `deviceTruckOut` | `string` | Required | - | getDeviceTruckOut(): string | setDeviceTruckOut(string deviceTruckOut): void |
| `returnStatus` | `string` | Required | - | getReturnStatus(): string | setReturnStatus(string returnStatus): void |
| `timestampReturnStatus` | `string` | Required | - | getTimestampReturnStatus(): string | setTimestampReturnStatus(string timestampReturnStatus): void |
| `reasonReturnStatus` | `string` | Required | - | getReasonReturnStatus(): string | setReasonReturnStatus(string reasonReturnStatus): void |
| `expReturnStatus` | `string` | Required | - | getExpReturnStatus(): string | setExpReturnStatus(string expReturnStatus): void |
| `deliverySmsAlert` | `string` | Required | - | getDeliverySmsAlert(): string | setDeliverySmsAlert(string deliverySmsAlert): void |
| `deliveryEmailAlert` | `string` | Required | - | getDeliveryEmailAlert(): string | setDeliveryEmailAlert(string deliveryEmailAlert): void |
| `flowTag` | `string` | Required | - | getFlowTag(): string | setFlowTag(string flowTag): void |
| `validationDatetime` | `string` | Required | - | getValidationDatetime(): string | setValidationDatetime(string validationDatetime): void |
| `smsDeliveryCodeSent` | `string` | Required | - | getSmsDeliveryCodeSent(): string | setSmsDeliveryCodeSent(string smsDeliveryCodeSent): void |
| `deliveryBarcodeScan` | `string` | Required | - | getDeliveryBarcodeScan(): string | setDeliveryBarcodeScan(string deliveryBarcodeScan): void |

## Example (as JSON)

```json
{
  "order_num": "HKGAE087622, \n210324374",
  "type": "P",
  "service_type": "IMPORT-AIRFREIGHT",
  "priority": 10,
  "customer_name": null,
  "customer_address": null,
  "customer_zip": null,
  "customer_city": null,
  "customer_prov": null,
  "customer_country": null,
  "customer_phone": null,
  "customer_contact": null,
  "customer_passport_id": null,
  "pickup_name": null,
  "pickup_address": null,
  "pickup_zip": null,
  "pickup_district": null,
  "pickup_city": null,
  "pickup_prov": null,
  "pickup_country": null,
  "pickup_phone": null,
  "pickup_contact": null,
  "pickup_passport_id": null,
  "delivery_name": null,
  "delivery_address": null,
  "delivery_zip": null,
  "delivery_district": null,
  "delivery_city": null,
  "delivery_prov": null,
  "delivery_country": null,
  "delivery_phone": null,
  "delivery_contact": null,
  "delivery_passport_id": null,
  "remarks": null,
  "internal_remarks": null,
  "control_remarks": null,
  "exp_parcel_num": null,
  "act_parcel_num": null,
  "status": "TBP",
  "time_last_update": "2020-03-26 17:35:20",
  "time_schedule_pickup": "2022-02-18 00:00:00",
  "time_schedule_pickup_t": "11:00,\nASAP",
  "time_schedule_delivery": "2022-02-18 00:00:00",
  "time_schedule_delivery_t": "10:00,\nASAP",
  "time_actual_pickup": "2022-02-01 16:56:23",
  "time_actual_delivery": "2022-02-01 16:56:23",
  "actual_contact_name": null,
  "actual_id": null,
  "customer_ref": null,
  "house": null,
  "mawb": null,
  "manifest": null,
  "crew_id": null,
  "warehouse_id": null,
  "reason": null,
  "customer_request": null,
  "signature": null,
  "pickable": "Y",
  "deliverable": "Y",
  "is_synchro": null,
  "synchro_date": null,
  "delivery_reason": null,
  "delivery_customer_request": null,
  "delivery_remarks": null,
  "delivery_signature": null,
  "cash_on_delivery": null,
  "incoterm": null,
  "cites": null,
  "atacarnet": null,
  "kimberly": null,
  "environment": 1,
  "update_weight": null,
  "dest_airport": null,
  "id_area_pickup": null,
  "id_area_delivery": null,
  "order_tags": null,
  "booking_ref": null,
  "pod_exported": null,
  "pickup_exported": null,
  "seal": null,
  "cash_on_delivery_cur": null,
  "wrh_hold": 1,
  "prerefno": null,
  "consolidation_id": null,
  "tracking_export": null,
  "exported": null,
  "pickup_guard_ref": null,
  "delivery_guard_ref": null,
  "pr_exported": null,
  "fm3000_pod_exported": null,
  "fm3000_pk_exported": null,
  "airexp_parcel_update": null,
  "as400_exp": null,
  "contact": null,
  "contact2": null,
  "attn": null,
  "attn2": null,
  "manifest_tms": null,
  "truckp": null,
  "truckd": null,
  "time_scan_in": null,
  "deliveries": null,
  "delivery_phone2": null,
  "declared_value": null,
  "insured_value": null,
  "hideshp": null,
  "hidecne": null,
  "hidesrv": null,
  "time_truck_out": null,
  "device_truck_out": null,
  "return_status": null,
  "timestamp_return_status": null,
  "reason_return_status": null,
  "exp_return_status": null,
  "delivery_sms_alert": null,
  "delivery_email_alert": null,
  "flow_tag": null,
  "validation_datetime": null,
  "sms_delivery_code_sent": null,
  "delivery_barcode_scan": null
}
```

