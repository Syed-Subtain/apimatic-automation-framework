
# TMS Device

## Structure

`TMSDevice`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `environment` | `string` | Required | - | getEnvironment(): string | setEnvironment(string environment): void |
| `phonenumber` | `string` | Required | - | getPhonenumber(): string | setPhonenumber(string phonenumber): void |
| `number` | `string` | Required | - | getNumber(): string | setNumber(string number): void |
| `serialNr` | `?string` | Optional | - | getSerialNr(): ?string | setSerialNr(?string serialNr): void |
| `latitude` | `?string` | Optional | - | getLatitude(): ?string | setLatitude(?string latitude): void |
| `longitude` | `?string` | Optional | - | getLongitude(): ?string | setLongitude(?string longitude): void |
| `timeGeolocation` | `?string` | Optional | - | getTimeGeolocation(): ?string | setTimeGeolocation(?string timeGeolocation): void |
| `active` | `?string` | Optional | - | getActive(): ?string | setActive(?string active): void |
| `needsync` | `string` | Required | - | getNeedsync(): string | setNeedsync(string needsync): void |
| `pushToken` | `string` | Required | - | getPushToken(): string | setPushToken(string pushToken): void |
| `databaseToken` | `string` | Required | - | getDatabaseToken(): string | setDatabaseToken(string databaseToken): void |

## Example (as JSON)

```json
{
  "environment": "1",
  "phonenumber": null,
  "number": null,
  "needsync": "1",
  "push_token": null,
  "database_token": null
}
```

