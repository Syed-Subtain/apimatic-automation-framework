
# TMS Attachment

## Structure

`TMSAttachment`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `orderNum` | `string` | Required | - | getOrderNum(): string | setOrderNum(string orderNum): void |
| `type` | `string` | Required | - | getType(): string | setType(string type): void |
| `fileId` | `string` | Required | - | getFileId(): string | setFileId(string fileId): void |
| `timestamp` | `string` | Required | - | getTimestamp(): string | setTimestamp(string timestamp): void |
| `environment` | `string` | Required | - | getEnvironment(): string | setEnvironment(string environment): void |

## Example (as JSON)

```json
{
  "order_num": "order_num2",
  "type": "type0",
  "file_id": "file_id6",
  "timestamp": "timestamp2",
  "environment": "environment6"
}
```

