
# Add Shipment Parceldata

## Structure

`AddShipmentParceldata`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `seal` | `string` | Required | sigillo inserito | getSeal(): string | setSeal(string seal): void |
| `weight` | `?string` | Optional | peso collo | getWeight(): ?string | setWeight(?string weight): void |

## Example (as JSON)

```json
{
  "seal": "seal2",
  "weight": null
}
```

