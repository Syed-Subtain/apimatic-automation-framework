
# Add Shipment Shipdata

## Structure

`AddShipmentShipdata`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `shipperCode` | `string` | Required | id indirizzo shipper | getShipperCode(): string | setShipperCode(string shipperCode): void |
| `consigneeCode` | `string` | Required | id indirizzo shipper | getConsigneeCode(): string | setConsigneeCode(string consigneeCode): void |
| `orderNum` | `string` | Required | - | getOrderNum(): string | setOrderNum(string orderNum): void |
| `seal` | `?string` | Optional | - | getSeal(): ?string | setSeal(?string seal): void |
| `timeActualPickup` | `string` | Required | timestamp operazione | getTimeActualPickup(): string | setTimeActualPickup(string timeActualPickup): void |
| `remarks` | `?string` | Optional | - | getRemarks(): ?string | setRemarks(?string remarks): void |
| `reference` | `?string` | Optional | - | getReference(): ?string | setReference(?string reference): void |

## Example (as JSON)

```json
{
  "shipper-code": "shipper-code8",
  "consignee-code": "consignee-code4",
  "order_num": "order_num2",
  "seal": null,
  "time_actual_pickup": "time_actual_pickup8",
  "remarks": null,
  "reference": null
}
```

