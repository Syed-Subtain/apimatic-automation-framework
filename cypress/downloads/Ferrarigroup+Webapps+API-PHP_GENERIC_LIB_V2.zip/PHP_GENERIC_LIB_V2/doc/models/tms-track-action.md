
# TMS Track Action

## Structure

`TMSTrackAction`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `action` | `string` | Required | codice operazione | getAction(): string | setAction(string action): void |
| `objectId` | `string` | Required | valore da inserire | getObjectId(): string | setObjectId(string objectId): void |
| `place` | `string` | Required | codice azione se previsto | getPlace(): string | setPlace(string place): void |
| `latitude` | `string` | Required | coordinata operazione | getLatitude(): string | setLatitude(string latitude): void |
| `longitude` | `string` | Required | coordinata operazione | getLongitude(): string | setLongitude(string longitude): void |
| `userId` | `string` | Required | codice operatore che fa l'azione | getUserId(): string | setUserId(string userId): void |
| `timestamp` | `string` | Required | timestamp orario operazione device | getTimestamp(): string | setTimestamp(string timestamp): void |
| `device` | `string` | Required | codice dispositivo | getDevice(): string | setDevice(string device): void |
| `name` | `?string` | Required | - | getName(): ?string | setName(?string name): void |
| `remarks` | `?string` | Required | - | getRemarks(): ?string | setRemarks(?string remarks): void |
| `environment` | `string` | Required | environment operazione | getEnvironment(): string | setEnvironment(string environment): void |
| `tag` | `string` | Required | tag operazione svolta | getTag(): string | setTag(string tag): void |
| `seal` | `?string` | Required | - | getSeal(): ?string | setSeal(?string seal): void |
| `attachments` | `?string` | Required | id allegato | getAttachments(): ?string | setAttachments(?string attachments): void |
| `manifestId` | `string` | Required | codice manifest | getManifestId(): string | setManifestId(string manifestId): void |

## Example (as JSON)

```json
{
  "action": "PS",
  "object_id": "123456789",
  "place": null,
  "latitude": "40.8356714",
  "longitude": "-74.4410216",
  "user_id": null,
  "timestamp": "1654791804433",
  "device": "CC123",
  "name": null,
  "remarks": null,
  "environment": "20",
  "tag": "POSTE",
  "seal": null,
  "attachments": null,
  "manifest_id": "Ferr00000000"
}
```

