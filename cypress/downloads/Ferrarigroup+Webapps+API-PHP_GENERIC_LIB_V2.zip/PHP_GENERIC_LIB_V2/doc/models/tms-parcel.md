
# TMS Parcel

## Structure

`TMSParcel`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `parcelNum` | `string` | Required | - | getParcelNum(): string | setParcelNum(string parcelNum): void |
| `orderNum` | `string` | Required | - | getOrderNum(): string | setOrderNum(string orderNum): void |
| `boxNum` | `string` | Required | - | getBoxNum(): string | setBoxNum(string boxNum): void |
| `grossWeight` | `string` | Required | - | getGrossWeight(): string | setGrossWeight(string grossWeight): void |
| `mark` | `string` | Required | - | getMark(): string | setMark(string mark): void |
| `itemNum` | `string` | Required | - | getItemNum(): string | setItemNum(string itemNum): void |
| `seal` | `string` | Required | - | getSeal(): string | setSeal(string seal): void |
| `dim1` | `string` | Required | - | getDim1(): string | setDim1(string dim1): void |
| `dim2` | `string` | Required | - | getDim2(): string | setDim2(string dim2): void |
| `dim3` | `string` | Required | - | getDim3(): string | setDim3(string dim3): void |
| `label` | `string` | Required | - | getLabel(): string | setLabel(string label): void |
| `seal2` | `string` | Required | - | getSeal2(): string | setSeal2(string seal2): void |
| `seal3` | `string` | Required | - | getSeal3(): string | setSeal3(string seal3): void |
| `dlvScan` | `string` | Required | - | getDlvScan(): string | setDlvScan(string dlvScan): void |
| `pkScan` | `string` | Required | - | getPkScan(): string | setPkScan(string pkScan): void |
| `environment` | `string` | Required | - | getEnvironment(): string | setEnvironment(string environment): void |
| `markOrig` | `string` | Required | - | getMarkOrig(): string | setMarkOrig(string markOrig): void |

## Example (as JSON)

```json
{
  "parcel_num": "parcel_num4",
  "order_num": "order_num2",
  "box_num": "box_num8",
  "gross_weight": "gross_weight4",
  "mark": "mark4",
  "item_num": "item_num2",
  "seal": "seal2",
  "dim1": "dim18",
  "dim2": "dim28",
  "dim3": "dim34",
  "label": "label0",
  "seal2": "seal28",
  "seal3": "seal34",
  "dlv_scan": "dlv_scan6",
  "pk_scan": "pk_scan4",
  "environment": "environment6",
  "mark_orig": "mark_orig4"
}
```

