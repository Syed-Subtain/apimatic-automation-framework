
# Shipment Status Return

return for the ShipmentStatus endpoint

## Structure

`ShipmentStatusReturn`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `shipmentId` | `string` | Required | key for the shipment | getShipmentId(): string | setShipmentId(string shipmentId): void |
| `statusList` | [`Status[]`](../../doc/models/status.md) | Required | - | getStatusList(): array | setStatusList(array statusList): void |

## Example (as JSON)

```json
{
  "shipment_id": "20NE1231233312",
  "status_list": {
    "date": "2020-08-05 12:00 or 2020-08-05",
    "status_info": "processing by Ferrari"
  }
}
```

