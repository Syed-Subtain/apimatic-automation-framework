
# T Ms Scan In

## Structure

`TMsScanIn`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `orderNum` | `string` | Required | shiment's order number | getOrderNum(): string | setOrderNum(string orderNum): void |
| `device` | `string` | Required | Device number (setting epod) | getDevice(): string | setDevice(string device): void |
| `timeActualScan` | `string` | Required | - | getTimeActualScan(): string | setTimeActualScan(string timeActualScan): void |

## Example (as JSON)

```json
{
  "order_num": "19GV210E91H",
  "device": "G0011",
  "time_actual_scan": "2022-04-21 12:11:07"
}
```

