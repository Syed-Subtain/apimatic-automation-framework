
# Geolocation

## Structure

`Geolocation`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `longitude` | `string` | Required | - | getLongitude(): string | setLongitude(string longitude): void |
| `latitude` | `string` | Required | - | getLatitude(): string | setLatitude(string latitude): void |
| `device` | `string` | Required | - | getDevice(): string | setDevice(string device): void |

## Example (as JSON)

```json
{
  "longitude": "longitude4",
  "latitude": "latitude6",
  "device": "device6"
}
```

