
# TMS Address

## Structure

`TMSAddress`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `code` | `string` | Required | - | getCode(): string | setCode(string code): void |
| `companyname` | `string` | Required | - | getCompanyname(): string | setCompanyname(string companyname): void |
| `address` | `string` | Required | - | getAddress(): string | setAddress(string address): void |
| `city` | `string` | Required | - | getCity(): string | setCity(string city): void |
| `district` | `?string` | Optional | - | getDistrict(): ?string | setDistrict(?string district): void |
| `postalcode` | `?string` | Optional | - | getPostalcode(): ?string | setPostalcode(?string postalcode): void |
| `statepro` | `?string` | Optional | - | getStatepro(): ?string | setStatepro(?string statepro): void |
| `country` | `string` | Required | - | getCountry(): string | setCountry(string country): void |
| `phone` | `?string` | Optional | - | getPhone(): ?string | setPhone(?string phone): void |
| `email` | `?string` | Optional | - | getEmail(): ?string | setEmail(?string email): void |
| `contact` | `?string` | Optional | - | getContact(): ?string | setContact(?string contact): void |
| `wso` | `?string` | Optional | - | getWso(): ?string | setWso(?string wso): void |

## Example (as JSON)

```json
{
  "code": "F123456",
  "companyname": null,
  "address": null,
  "city": null,
  "country": "IT"
}
```

