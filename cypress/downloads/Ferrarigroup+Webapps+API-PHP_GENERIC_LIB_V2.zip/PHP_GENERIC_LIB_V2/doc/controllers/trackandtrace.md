# Trackandtrace

```php
$trackandtraceController = $client->getTrackandtraceController();
```

## Class Name

`TrackandtraceController`


# Shipment Status

Get the status of a given shipment ID

```php
function shipmentStatus(string $id): ShipmentStatusReturn
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `string` | Query, Required | Tracking ID of the shipment |

## Response Type

[`ShipmentStatusReturn`](../../doc/models/shipment-status-return.md)

## Example Usage

```php
$id = '/tracking/shipment-status?id=20NXXXXXXXX';

$result = $trackandtraceController->shipmentStatus($id);
```

## Example Response *(as JSON)*

```json
{
  "shipment_id": "20NEXXXXXXX",
  "status_list": [
    {
      "date": "2020-08-05 12:00",
      "status_info": "Delivered To Name and Surname",
      "tracking": " ",
      "office_in_charge": "Neuchatel"
    },
    {
      "date": "2020-08-05",
      "status_info": "Processing By Ferrari",
      "tracking": "20NEXXXXXXX ",
      "office_in_charge": "Monaco"
    },
    {
      "date": "2020-08-04",
      "status_info": "Processing By Ferrari",
      "tracking": "20NEXXXXXXX ",
      "office_in_charge": "Alessandria"
    },
    {
      "date": "2020-08-03",
      "status_info": "Shipped",
      "tracking": "20NEXXXXXXX ",
      "office_in_charge": ""
    },
    {
      "date": "2020-07-31",
      "status_info": "Processing By Ferrari",
      "tracking": "20NEXXXXXXX ",
      "office_in_charge": "Neuchatel"
    }
  ]
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 403 | You are not allowed to view this shipment | `ApiException` |
| 404 | Shipment not found | `ApiException` |

