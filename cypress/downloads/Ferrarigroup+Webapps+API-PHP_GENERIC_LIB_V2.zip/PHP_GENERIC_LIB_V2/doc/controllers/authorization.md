# Authorization

```php
$authorizationController = $client->getAuthorizationController();
```

## Class Name

`AuthorizationController`


# Authorization

```php
function authorization(string $grantType, string $username, string $password, string $authorization): string
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `grantType` | `string` | Query, Required | - |
| `username` | `string` | Query, Required | - |
| `password` | `string` | Query, Required | - |
| `authorization` | `string` | Header, Required | basic auth app |

## Response Type

`string`

## Example Usage

```php
$grantType = 'password';
$username = 'username';
$password = 'password';
$authorization = 'Basic ZXdtc2FwcDowZHVmT3VPeSR0V3g=';

$result = $authorizationController->authorization($grantType, $username, $password, $authorization);
```

## Example Response

```
"{\n    \"access_token\": \"b8895ea855e65b64e179c6dfb26a50792803a27f\",\n    \"expires_in\": 3600,\n    \"token_type\": \"Bearer\",\n    \"scope\": \"\",\n    \"refresh_token\": \"f3df703dae98c5e76eee79d38156e636b12f1c97\"\n}"
```

