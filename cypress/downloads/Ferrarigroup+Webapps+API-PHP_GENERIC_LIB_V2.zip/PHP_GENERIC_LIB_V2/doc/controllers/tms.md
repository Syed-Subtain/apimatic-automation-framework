# Tms

```php
$tmsController = $client->getTmsController();
```

## Class Name

`TmsController`

## Methods

* [TMS Shipments Collection](../../doc/controllers/tms.md#tms-shipments-collection)
* [TMS Shipments](../../doc/controllers/tms.md#tms-shipments)
* [TMS Shipments 1](../../doc/controllers/tms.md#tms-shipments-1)
* [TMS Shipments 2](../../doc/controllers/tms.md#tms-shipments-2)
* [TMS Device Entity](../../doc/controllers/tms.md#tms-device-entity)
* [TMS Device](../../doc/controllers/tms.md#tms-device)
* [TMS Device Collection](../../doc/controllers/tms.md#tms-device-collection)
* [TMS Device 1](../../doc/controllers/tms.md#tms-device-1)
* [TMS Device 2](../../doc/controllers/tms.md#tms-device-2)
* [TMS Shipments Entity](../../doc/controllers/tms.md#tms-shipments-entity)
* [TMS Crew Entity](../../doc/controllers/tms.md#tms-crew-entity)
* [TMS Parcel Entity](../../doc/controllers/tms.md#tms-parcel-entity)
* [TMS Parcel](../../doc/controllers/tms.md#tms-parcel)
* [TMS Parcel Collection](../../doc/controllers/tms.md#tms-parcel-collection)
* [TMS Parcel 1](../../doc/controllers/tms.md#tms-parcel-1)
* [TMS Parcel 2](../../doc/controllers/tms.md#tms-parcel-2)
* [TMS Attachment Upload](../../doc/controllers/tms.md#tms-attachment-upload)
* [TMS Attachment Upload Public](../../doc/controllers/tms.md#tms-attachment-upload-public)
* [TMS Login Info](../../doc/controllers/tms.md#tms-login-info)
* [TMS Attachment Entity](../../doc/controllers/tms.md#tms-attachment-entity)
* [TMS Attachment Collection](../../doc/controllers/tms.md#tms-attachment-collection)
* [TMS Attachment](../../doc/controllers/tms.md#tms-attachment)
* [TMS Attachment 1](../../doc/controllers/tms.md#tms-attachment-1)
* [TMS Attachment 2](../../doc/controllers/tms.md#tms-attachment-2)
* [TMS Scan Parcel List](../../doc/controllers/tms.md#tms-scan-parcel-list)
* [TMS Scan In](../../doc/controllers/tms.md#tms-scan-in)
* [TMS Warehouse Collection](../../doc/controllers/tms.md#tms-warehouse-collection)
* [TMS Warehouse Entity](../../doc/controllers/tms.md#tms-warehouse-entity)
* [TMS Warehouse](../../doc/controllers/tms.md#tms-warehouse)
* [TMS Warehouse 1](../../doc/controllers/tms.md#tms-warehouse-1)
* [TMS Manifest Create](../../doc/controllers/tms.md#tms-manifest-create)
* [TMS Track Action](../../doc/controllers/tms.md#tms-track-action)
* [TMS Tracking Place](../../doc/controllers/tms.md#tms-tracking-place)
* [TMS Return Status](../../doc/controllers/tms.md#tms-return-status)
* [TMS Get Addresses](../../doc/controllers/tms.md#tms-get-addresses)
* [TMS Get Countires](../../doc/controllers/tms.md#tms-get-countires)
* [TMS Add Address](../../doc/controllers/tms.md#tms-add-address)
* [TMS Shipment Add](../../doc/controllers/tms.md#tms-shipment-add)
* [TMS Geolocation](../../doc/controllers/tms.md#tms-geolocation)


# TMS Shipments Collection

```php
function tMSShipmentsCollection(
    ?string $environment = null,
    ?string $orderNum = null,
    ?string $serviceType = null,
    ?string $crewId = null,
    ?string $manifest = null,
    ?string $manifestTms = null,
    ?string $status = null,
    ?string $timeLastUpdate = null,
    ?string $timeSchedulePickup = null,
    ?string $timeScheduleDelivery = null,
    ?string $timeActualPickup = null,
    ?string $timeActualDelivery = null,
    ?string $bookingRef = null,
    ?string $seal = null,
    ?string $house = null,
    ?string $mawb = null
): string
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `environment` | `?string` | Query, Optional | - |
| `orderNum` | `?string` | Query, Optional | - |
| `serviceType` | `?string` | Query, Optional | - |
| `crewId` | `?string` | Query, Optional | - |
| `manifest` | `?string` | Query, Optional | - |
| `manifestTms` | `?string` | Query, Optional | - |
| `status` | `?string` | Query, Optional | - |
| `timeLastUpdate` | `?string` | Query, Optional | - |
| `timeSchedulePickup` | `?string` | Query, Optional | - |
| `timeScheduleDelivery` | `?string` | Query, Optional | - |
| `timeActualPickup` | `?string` | Query, Optional | - |
| `timeActualDelivery` | `?string` | Query, Optional | - |
| `bookingRef` | `?string` | Query, Optional | - |
| `seal` | `?string` | Query, Optional | - |
| `house` | `?string` | Query, Optional | - |
| `mawb` | `?string` | Query, Optional | - |

## Response Type

`string`

## Example Usage

```php
$result = $tmsController->tMSShipmentsCollection();
```

## Example Response

```
"{\n   \"_links\": {\n       \"self\": {\n           \"href\": \"/tms/shipment\"\n       },\n       \"first\": {\n           \"href\": \"/tms/shipment?page={page}\"\n       },\n       \"prev\": {\n           \"href\": \"/tms/shipment?page={page}\"\n       },\n       \"next\": {\n           \"href\": \"/tms/shipment?page={page}\"\n       },\n       \"last\": {\n           \"href\": \"/tms/shipment?page={page}\"\n       }\n   }\n   \"_embedded\": {\n       \"shipment\": [\n           {\n               \"_links\": {\n                   \"self\": {\n                       \"href\": \"/tms/shipment[/:shipment_id]\"\n                   }\n               }\n              \"order_num\": \"\",\n              \"type\": \"\",\n              \"service_type\": \"\",\n              \"priority\": \"\",\n              \"customer_name\": \"\",\n              \"customer_address\": \"\",\n              \"customer_zip\": \"\",\n              \"customer_city\": \"\",\n              \"customer_prov\": \"\",\n              \"customer_country\": \"\",\n              \"customer_phone\": \"\",\n              \"customer_contact\": \"\",\n              \"customer_passport_id\": \"\",\n              \"pickup_name\": \"\",\n              \"pickup_address\": \"\",\n              \"pickup_zip\": \"\",\n              \"pickup_district\": \"\",\n              \"pickup_city\": \"\",\n              \"pickup_prov\": \"\",\n              \"pickup_country\": \"\",\n              \"pickup_phone\": \"\",\n              \"pickup_contact\": \"\",\n              \"pickup_passport_id\": \"\",\n              \"delivery_name\": \"\",\n              \"delivery_address\": \"\",\n              \"delivery_zip\": \"\",\n              \"delivery_district\": \"\",\n              \"delivery_city\": \"\",\n              \"delivery_prov\": \"\",\n              \"delivery_country\": \"\",\n              \"delivery_phone\": \"\",\n              \"delivery_contact\": \"\",\n              \"delivery_passport_id\": \"\",\n              \"remarks\": \"\",\n              \"internal_remarks\": \"\",\n              \"control_remarks\": \"\",\n              \"exp_parcel_num\": \"\",\n              \"act_parcel_num\": \"\",\n              \"status\": \"\",\n              \"time_last_update\": \"\",\n              \"time_schedule_pickup\": \"\",\n              \"time_schedule_pickup_t\": \"\",\n              \"time_schedule_delivery\": \"\",\n              \"time_schedule_delivery_t\": \"\",\n              \"time_actual_pickup\": \"\",\n              \"time_actual_delivery\": \"\",\n              \"actual_contact_name\": \"\",\n              \"actual_id\": \"\",\n              \"customer_ref\": \"\",\n              \"house\": \"\",\n              \"mawb\": \"\",\n              \"manifest\": \"\",\n              \"crew_id\": \"\",\n              \"warehouse_id\": \"\",\n              \"reason\": \"\",\n              \"customer_request\": \"\",\n              \"signature\": \"\",\n              \"pickable\": \"\",\n              \"deliverable\": \"\",\n              \"is_synchro\": \"\",\n              \"synchro_date\": \"\",\n              \"delivery_reason\": \"\",\n              \"delivery_customer_request\": \"\",\n              \"delivery_remarks\": \"\",\n              \"delivery_signature\": \"\",\n              \"cash_on_delivery\": \"\",\n              \"incoterm\": \"\",\n              \"cites\": \"\",\n              \"atacarnet\": \"\",\n              \"kimberly\": \"\",\n              \"environment\": \"\",\n              \"update_weight\": \"\",\n              \"dest_airport\": \"\",\n              \"id_area_pickup\": \"\",\n              \"id_area_delivery\": \"\",\n              \"order_tags\": \"\",\n              \"booking_ref\": \"\",\n              \"pod_exported\": \"\",\n              \"pickup_exported\": \"\",\n              \"seal\": \"\",\n              \"cash_on_delivery_cur\": \"\",\n              \"wrh_hold\": \"\",\n              \"prerefno\": \"\",\n              \"consolidation_id\": \"\",\n              \"tracking_export\": \"\",\n              \"exported\": \"\",\n              \"pickup_guard_ref\": \"\",\n              \"delivery_guard_ref\": \"\",\n              \"pr_exported\": \"\",\n              \"fm3000_pod_exported\": \"\",\n              \"fm3000_pk_exported\": \"\",\n              \"airexp_parcel_update\": \"\",\n              \"as400_exp\": \"\",\n              \"contact\": \"\",\n              \"contact2\": \"\",\n              \"attn\": \"\",\n              \"attn2\": \"\",\n              \"manifest_tms\": \"\",\n              \"truckp\": \"\",\n              \"truckd\": \"\",\n              \"time_scan_in\": \"\",\n              \"deliveries\": \"\",\n              \"delivery_phone2\": \"\"\n           }\n       ]\n   }\n}"
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | `ApiException` |
| 403 | Forbidden | `ApiException` |
| 404 | Not Found | `ApiException` |
| 422 | Unprocessable entity | `ApiException` |


# TMS Shipments

```php
function tMSShipments(TmsShipmentPost $pARAMS): string
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `pARAMS` | [`TmsShipmentPost`](../../doc/models/tms-shipment-post.md) | Body, Required | - |

## Response Type

`string`

## Example Usage

```php
$pARAMS_orderNum = 'HKGAE087622, 
210324374';
$pARAMS_type = 'P';
$pARAMS_serviceType = 'IMPORT-AIRFREIGHT';
$pARAMS_priority = 10;
$pARAMS_customerName = 'customer_name6';
$pARAMS_customerAddress = 'customer_address2';
$pARAMS_customerZip = 'customer_zip6';
$pARAMS_customerCity = 'customer_city8';
$pARAMS_customerProv = 'customer_prov6';
$pARAMS_customerCountry = 'customer_country4';
$pARAMS_customerPhone = 'customer_phone8';
$pARAMS_customerContact = 'customer_contact2';
$pARAMS_customerPassportId = 'customer_passport_id6';
$pARAMS_pickupName = 'pickup_name6';
$pARAMS_pickupAddress = 'pickup_address0';
$pARAMS_pickupZip = 'pickup_zip6';
$pARAMS_pickupDistrict = 'pickup_district4';
$pARAMS_pickupCity = 'pickup_city0';
$pARAMS_pickupProv = 'pickup_prov4';
$pARAMS_pickupCountry = 'pickup_country0';
$pARAMS_pickupPhone = 'pickup_phone4';
$pARAMS_pickupContact = 'pickup_contact8';
$pARAMS_pickupPassportId = 'pickup_passport_id8';
$pARAMS_deliveryName = 'delivery_name8';
$pARAMS_deliveryAddress = 'delivery_address0';
$pARAMS_deliveryZip = 'delivery_zip6';
$pARAMS_deliveryDistrict = 'delivery_district4';
$pARAMS_deliveryCity = 'delivery_city2';
$pARAMS_deliveryProv = 'delivery_prov0';
$pARAMS_deliveryCountry = 'delivery_country6';
$pARAMS_deliveryPhone = 'delivery_phone4';
$pARAMS_deliveryContact = 'delivery_contact6';
$pARAMS_deliveryPassportId = 'delivery_passport_id4';
$pARAMS_remarks = 'remarks0';
$pARAMS_internalRemarks = 'internal_remarks6';
$pARAMS_controlRemarks = 'control_remarks6';
$pARAMS_expParcelNum = 'exp_parcel_num4';
$pARAMS_actParcelNum = 'act_parcel_num8';
$pARAMS_status = 'TBP';
$pARAMS_timeLastUpdate = DateTimeHelper::fromRfc3339DateTime('2020-03-26 17:35:20');
$pARAMS_timeSchedulePickup = DateTimeHelper::fromRfc3339DateTime('2022-02-18 00:00:00');
$pARAMS_timeSchedulePickupT = '11:00,
ASAP';
$pARAMS_timeScheduleDelivery = DateTimeHelper::fromRfc3339DateTime('2022-02-18 00:00:00');
$pARAMS_timeScheduleDeliveryT = '10:00,
ASAP';
$pARAMS_timeActualPickup = DateTimeHelper::fromRfc3339DateTime('2022-02-01 16:56:23');
$pARAMS_timeActualDelivery = DateTimeHelper::fromRfc3339DateTime('2022-02-01 16:56:23');
$pARAMS_actualContactName = 'actual_contact_name6';
$pARAMS_actualId = 'actual_id4';
$pARAMS_customerRef = 'customer_ref8';
$pARAMS_house = 'house8';
$pARAMS_mawb = 'mawb2';
$pARAMS_manifest = 'manifest2';
$pARAMS_crewId = 30;
$pARAMS_warehouseId = 'warehouse_id2';
$pARAMS_reason = 'reason0';
$pARAMS_customerRequest = 'customer_request2';
$pARAMS_signature = 'signature2';
$pARAMS_pickable = 'Y';
$pARAMS_deliverable = 'Y';
$pARAMS_isSynchro = 'is_synchro8';
$pARAMS_synchroDate = 'synchro_date0';
$pARAMS_deliveryReason = 'delivery_reason2';
$pARAMS_deliveryCustomerRequest = 'delivery_customer_request8';
$pARAMS_deliveryRemarks = 'delivery_remarks4';
$pARAMS_deliverySignature = 'delivery_signature6';
$pARAMS_cashOnDelivery = 152;
$pARAMS_incoterm = 'incoterm8';
$pARAMS_cites = 'cites8';
$pARAMS_atacarnet = 'atacarnet8';
$pARAMS_kimberly = 'kimberly2';
$pARAMS_environment = 1;
$pARAMS_updateWeight = 'update_weight2';
$pARAMS_destAirport = 'dest_airport2';
$pARAMS_idAreaPickup = 'id_area_pickup8';
$pARAMS_idAreaDelivery = 'id_area_delivery6';
$pARAMS_orderTags = 'order_tags4';
$pARAMS_bookingRef = 'booking_ref2';
$pARAMS_podExported = 'pod_exported6';
$pARAMS_pickupExported = 'pickup_exported8';
$pARAMS_seal = 'seal6';
$pARAMS_cashOnDeliveryCur = 'cash_on_delivery_cur0';
$pARAMS_wrhHold = 1;
$pARAMS_prerefno = 'prerefno8';
$pARAMS_consolidationId = 'consolidation_id2';
$pARAMS_trackingExport = 'tracking_export8';
$pARAMS_exported = 'exported0';
$pARAMS_pickupGuardRef = 'pickup_guard_ref2';
$pARAMS_deliveryGuardRef = 'delivery_guard_ref4';
$pARAMS_prExported = 'pr_exported6';
$pARAMS_fm3000PodExported = 'fm3000_pod_exported0';
$pARAMS_fm3000PkExported = 'fm3000_pk_exported2';
$pARAMS_airexpParcelUpdate = 'airexp_parcel_update2';
$pARAMS_as400Exp = 'as400_exp8';
$pARAMS_contact = 'contact8';
$pARAMS_contact2 = 'contact24';
$pARAMS_attn = 'attn4';
$pARAMS_attn2 = 'attn22';
$pARAMS_manifestTms = 'manifest_tms0';
$pARAMS_truckp = 'truckp6';
$pARAMS_truckd = 'truckd0';
$pARAMS_timeScanIn = 'time_scan_in6';
$pARAMS_deliveries = 'deliveries4';
$pARAMS_deliveryPhone2 = 'delivery_phone28';
$pARAMS_declaredValue = 'declared_value0';
$pARAMS_insuredValue = 'insured_value6';
$pARAMS_hideshp = 'hideshp2';
$pARAMS_hidecne = 'hidecne0';
$pARAMS_hidesrv = 'hidesrv8';
$pARAMS_timeTruckOut = 'time_truck_out6';
$pARAMS_deviceTruckOut = 'device_truck_out2';
$pARAMS_returnStatus = 'return_status4';
$pARAMS_timestampReturnStatus = 'timestamp_return_status0';
$pARAMS_reasonReturnStatus = 'reason_return_status0';
$pARAMS_expReturnStatus = 'exp_return_status2';
$pARAMS_deliverySmsAlert = 'delivery_sms_alert8';
$pARAMS_deliveryEmailAlert = 'delivery_email_alert4';
$pARAMS_flowTag = 'flow_tag6';
$pARAMS_validationDatetime = 'validation_datetime2';
$pARAMS_smsDeliveryCodeSent = 'sms_delivery_code_sent8';
$pARAMS_deliveryBarcodeScan = 'delivery_barcode_scan4';
$pARAMS = new Models\TmsShipmentPost(
    $pARAMS_orderNum,
    $pARAMS_type,
    $pARAMS_serviceType,
    $pARAMS_priority,
    $pARAMS_customerName,
    $pARAMS_customerAddress,
    $pARAMS_customerZip,
    $pARAMS_customerCity,
    $pARAMS_customerProv,
    $pARAMS_customerCountry,
    $pARAMS_customerPhone,
    $pARAMS_customerContact,
    $pARAMS_customerPassportId,
    $pARAMS_pickupName,
    $pARAMS_pickupAddress,
    $pARAMS_pickupZip,
    $pARAMS_pickupDistrict,
    $pARAMS_pickupCity,
    $pARAMS_pickupProv,
    $pARAMS_pickupCountry,
    $pARAMS_pickupPhone,
    $pARAMS_pickupContact,
    $pARAMS_pickupPassportId,
    $pARAMS_deliveryName,
    $pARAMS_deliveryAddress,
    $pARAMS_deliveryZip,
    $pARAMS_deliveryDistrict,
    $pARAMS_deliveryCity,
    $pARAMS_deliveryProv,
    $pARAMS_deliveryCountry,
    $pARAMS_deliveryPhone,
    $pARAMS_deliveryContact,
    $pARAMS_deliveryPassportId,
    $pARAMS_remarks,
    $pARAMS_internalRemarks,
    $pARAMS_controlRemarks,
    $pARAMS_expParcelNum,
    $pARAMS_actParcelNum,
    $pARAMS_status,
    $pARAMS_timeLastUpdate,
    $pARAMS_timeSchedulePickup,
    $pARAMS_timeSchedulePickupT,
    $pARAMS_timeScheduleDelivery,
    $pARAMS_timeScheduleDeliveryT,
    $pARAMS_timeActualPickup,
    $pARAMS_timeActualDelivery,
    $pARAMS_actualContactName,
    $pARAMS_actualId,
    $pARAMS_customerRef,
    $pARAMS_house,
    $pARAMS_mawb,
    $pARAMS_manifest,
    $pARAMS_crewId,
    $pARAMS_warehouseId,
    $pARAMS_reason,
    $pARAMS_customerRequest,
    $pARAMS_signature,
    $pARAMS_pickable,
    $pARAMS_deliverable,
    $pARAMS_isSynchro,
    $pARAMS_synchroDate,
    $pARAMS_deliveryReason,
    $pARAMS_deliveryCustomerRequest,
    $pARAMS_deliveryRemarks,
    $pARAMS_deliverySignature,
    $pARAMS_cashOnDelivery,
    $pARAMS_incoterm,
    $pARAMS_cites,
    $pARAMS_atacarnet,
    $pARAMS_kimberly,
    $pARAMS_environment,
    $pARAMS_updateWeight,
    $pARAMS_destAirport,
    $pARAMS_idAreaPickup,
    $pARAMS_idAreaDelivery,
    $pARAMS_orderTags,
    $pARAMS_bookingRef,
    $pARAMS_podExported,
    $pARAMS_pickupExported,
    $pARAMS_seal,
    $pARAMS_cashOnDeliveryCur,
    $pARAMS_wrhHold,
    $pARAMS_prerefno,
    $pARAMS_consolidationId,
    $pARAMS_trackingExport,
    $pARAMS_exported,
    $pARAMS_pickupGuardRef,
    $pARAMS_deliveryGuardRef,
    $pARAMS_prExported,
    $pARAMS_fm3000PodExported,
    $pARAMS_fm3000PkExported,
    $pARAMS_airexpParcelUpdate,
    $pARAMS_as400Exp,
    $pARAMS_contact,
    $pARAMS_contact2,
    $pARAMS_attn,
    $pARAMS_attn2,
    $pARAMS_manifestTms,
    $pARAMS_truckp,
    $pARAMS_truckd,
    $pARAMS_timeScanIn,
    $pARAMS_deliveries,
    $pARAMS_deliveryPhone2,
    $pARAMS_declaredValue,
    $pARAMS_insuredValue,
    $pARAMS_hideshp,
    $pARAMS_hidecne,
    $pARAMS_hidesrv,
    $pARAMS_timeTruckOut,
    $pARAMS_deviceTruckOut,
    $pARAMS_returnStatus,
    $pARAMS_timestampReturnStatus,
    $pARAMS_reasonReturnStatus,
    $pARAMS_expReturnStatus,
    $pARAMS_deliverySmsAlert,
    $pARAMS_deliveryEmailAlert,
    $pARAMS_flowTag,
    $pARAMS_validationDatetime,
    $pARAMS_smsDeliveryCodeSent,
    $pARAMS_deliveryBarcodeScan
);

$result = $tmsController->tMSShipments($pARAMS);
```

## Example Response

```
"{\n   \"order_num\": \"\",\n   \"type\": \"\",\n   \"service_type\": \"\",\n   \"priority\": \"\",\n   \"customer_name\": \"\",\n   \"customer_address\": \"\",\n   \"customer_zip\": \"\",\n   \"customer_city\": \"\",\n   \"customer_prov\": \"\",\n   \"customer_country\": \"\",\n   \"customer_phone\": \"\",\n   \"customer_contact\": \"\",\n   \"customer_passport_id\": \"\",\n   \"pickup_name\": \"\",\n   \"pickup_address\": \"\",\n   \"pickup_zip\": \"\",\n   \"pickup_district\": \"\",\n   \"pickup_city\": \"\",\n   \"pickup_prov\": \"\",\n   \"pickup_country\": \"\",\n   \"pickup_phone\": \"\",\n   \"pickup_contact\": \"\",\n   \"pickup_passport_id\": \"\",\n   \"delivery_name\": \"\",\n   \"delivery_address\": \"\",\n   \"delivery_zip\": \"\",\n   \"delivery_district\": \"\",\n   \"delivery_city\": \"\",\n   \"delivery_prov\": \"\",\n   \"delivery_country\": \"\",\n   \"delivery_phone\": \"\",\n   \"delivery_contact\": \"\",\n   \"delivery_passport_id\": \"\",\n   \"remarks\": \"\",\n   \"internal_remarks\": \"\",\n   \"control_remarks\": \"\",\n   \"exp_parcel_num\": \"\",\n   \"act_parcel_num\": \"\",\n   \"status\": \"\",\n   \"time_last_update\": \"\",\n   \"time_schedule_pickup\": \"\",\n   \"time_schedule_pickup_t\": \"\",\n   \"time_schedule_delivery\": \"\",\n   \"time_schedule_delivery_t\": \"\",\n   \"time_actual_pickup\": \"\",\n   \"time_actual_delivery\": \"\",\n   \"actual_contact_name\": \"\",\n   \"actual_id\": \"\",\n   \"customer_ref\": \"\",\n   \"house\": \"\",\n   \"manifest\": \"\",\n   \"crew_id\": \"\",\n   \"warehouse_id\": \"\",\n   \"reason\": \"\",\n   \"customer_request\": \"\",\n   \"signature\": \"\",\n   \"pickable\": \"\",\n   \"deliverable\": \"\",\n   \"is_synchro\": \"\",\n   \"synchro_date\": \"\",\n   \"delivery_reason\": \"\",\n   \"delivery_customer_request\": \"\",\n   \"delivery_remarks\": \"\",\n   \"delivery_signature\": \"\",\n   \"cash_on_delivery\": \"\",\n   \"incoterm\": \"\",\n   \"cites\": \"\",\n   \"atacarnet\": \"\",\n   \"kimberly\": \"\",\n   \"environment\": \"\",\n   \"update_weight\": \"\",\n   \"dest_airport\": \"\",\n   \"id_area_pickup\": \"\",\n   \"id_area_delivery\": \"\",\n   \"order_tags\": \"\",\n   \"booking_ref\": \"\",\n   \"pod_exported\": \"\",\n   \"pickup_exported\": \"\",\n   \"seal\": \"\",\n   \"cash_on_delivery_cur\": \"\",\n   \"wrh_hold\": \"\",\n   \"prerefno\": \"\",\n   \"consolidation_id\": \"\",\n   \"tracking_export\": \"\",\n   \"exported\": \"\",\n   \"pickup_guard_ref\": \"\",\n   \"delivery_guard_ref\": \"\",\n   \"pr_exported\": \"\",\n   \"fm3000_pod_exported\": \"\",\n   \"fm3000_pk_exported\": \"\",\n   \"airexp_parcel_update\": \"\",\n   \"as400_exp\": \"\",\n   \"contact\": \"\",\n   \"contact2\": \"\",\n   \"attn\": \"\",\n   \"attn2\": \"\",\n   \"manifest_tms\": \"\",\n   \"truckp\": \"\",\n   \"truckd\": \"\",\n   \"time_scan_in\": \"\",\n   \"deliveries\": \"\",\n   \"delivery_phone2\": \"\",\n   \"declared_value\": \"\",\n   \"insured_value\": \"\",\n   \"hideshp\": \"\",\n   \"hidecne\": \"\",\n   \"hidesrv\": \"\",\n   \"time_truck_out\": \"\",\n   \"device_truck_out\": \"\",\n   \"return_status\": \"\",\n   \"timestamp_return_status\": \"\",\n   \"reason_return_status\": \"\",\n   \"exp_return_status\": \"\",\n   \"delivery_sms_alert\": \"\",\n   \"delivery_email_alert\": \"\",\n   \"flow_tag\": \"\",\n   \"validation_datetime\": \"\",\n   \"sms_delivery_code_sent\": \"\",\n   \"delivery_barcode_scan\": \"\",\n   \"delivery_barcode_scan\": \"\"\n}"
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | `ApiException` |
| 403 | Forbidden | `ApiException` |
| 404 | Not Found | `ApiException` |
| 422 | Unprocessable entity | `ApiException` |


# TMS Shipments 1

```php
function tMSShipments1(TmsShipmentPost $params, string $id): string
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `params` | [`TmsShipmentPost`](../../doc/models/tms-shipment-post.md) | Body, Required | - |
| `id` | `string` | Template, Required | - |

## Response Type

`string`

## Example Usage

```php
$params_orderNum = 'HKGAE087622, 
210324374';
$params_type = 'P';
$params_serviceType = 'IMPORT-AIRFREIGHT';
$params_priority = 10;
$params_customerName = 'customer_name6';
$params_customerAddress = 'customer_address2';
$params_customerZip = 'customer_zip6';
$params_customerCity = 'customer_city8';
$params_customerProv = 'customer_prov6';
$params_customerCountry = 'customer_country4';
$params_customerPhone = 'customer_phone8';
$params_customerContact = 'customer_contact2';
$params_customerPassportId = 'customer_passport_id6';
$params_pickupName = 'pickup_name6';
$params_pickupAddress = 'pickup_address0';
$params_pickupZip = 'pickup_zip6';
$params_pickupDistrict = 'pickup_district4';
$params_pickupCity = 'pickup_city0';
$params_pickupProv = 'pickup_prov4';
$params_pickupCountry = 'pickup_country0';
$params_pickupPhone = 'pickup_phone4';
$params_pickupContact = 'pickup_contact8';
$params_pickupPassportId = 'pickup_passport_id8';
$params_deliveryName = 'delivery_name8';
$params_deliveryAddress = 'delivery_address0';
$params_deliveryZip = 'delivery_zip6';
$params_deliveryDistrict = 'delivery_district4';
$params_deliveryCity = 'delivery_city2';
$params_deliveryProv = 'delivery_prov0';
$params_deliveryCountry = 'delivery_country6';
$params_deliveryPhone = 'delivery_phone6';
$params_deliveryContact = 'delivery_contact6';
$params_deliveryPassportId = 'delivery_passport_id4';
$params_remarks = 'remarks0';
$params_internalRemarks = 'internal_remarks6';
$params_controlRemarks = 'control_remarks6';
$params_expParcelNum = 'exp_parcel_num4';
$params_actParcelNum = 'act_parcel_num2';
$params_status = 'TBP';
$params_timeLastUpdate = DateTimeHelper::fromRfc3339DateTime('2020-03-26 17:35:20');
$params_timeSchedulePickup = DateTimeHelper::fromRfc3339DateTime('2022-02-18 00:00:00');
$params_timeSchedulePickupT = '11:00,
ASAP';
$params_timeScheduleDelivery = DateTimeHelper::fromRfc3339DateTime('2022-02-18 00:00:00');
$params_timeScheduleDeliveryT = '10:00,
ASAP';
$params_timeActualPickup = DateTimeHelper::fromRfc3339DateTime('2022-02-01 16:56:23');
$params_timeActualDelivery = DateTimeHelper::fromRfc3339DateTime('2022-02-01 16:56:23');
$params_actualContactName = 'actual_contact_name6';
$params_actualId = 'actual_id4';
$params_customerRef = 'customer_ref8';
$params_house = 'house8';
$params_mawb = 'mawb2';
$params_manifest = 'manifest2';
$params_crewId = 0;
$params_warehouseId = 'warehouse_id2';
$params_reason = 'reason0';
$params_customerRequest = 'customer_request8';
$params_signature = 'signature2';
$params_pickable = 'Y';
$params_deliverable = 'Y';
$params_isSynchro = 'is_synchro8';
$params_synchroDate = 'synchro_date0';
$params_deliveryReason = 'delivery_reason2';
$params_deliveryCustomerRequest = 'delivery_customer_request8';
$params_deliveryRemarks = 'delivery_remarks4';
$params_deliverySignature = 'delivery_signature6';
$params_cashOnDelivery = 122;
$params_incoterm = 'incoterm8';
$params_cites = 'cites8';
$params_atacarnet = 'atacarnet8';
$params_kimberly = 'kimberly8';
$params_environment = 1;
$params_updateWeight = 'update_weight2';
$params_destAirport = 'dest_airport8';
$params_idAreaPickup = 'id_area_pickup8';
$params_idAreaDelivery = 'id_area_delivery6';
$params_orderTags = 'order_tags4';
$params_bookingRef = 'booking_ref2';
$params_podExported = 'pod_exported6';
$params_pickupExported = 'pickup_exported8';
$params_seal = 'seal6';
$params_cashOnDeliveryCur = 'cash_on_delivery_cur0';
$params_wrhHold = 1;
$params_prerefno = 'prerefno2';
$params_consolidationId = 'consolidation_id2';
$params_trackingExport = 'tracking_export8';
$params_exported = 'exported0';
$params_pickupGuardRef = 'pickup_guard_ref2';
$params_deliveryGuardRef = 'delivery_guard_ref6';
$params_prExported = 'pr_exported6';
$params_fm3000PodExported = 'fm3000_pod_exported0';
$params_fm3000PkExported = 'fm3000_pk_exported2';
$params_airexpParcelUpdate = 'airexp_parcel_update8';
$params_as400Exp = 'as400_exp8';
$params_contact = 'contact8';
$params_contact2 = 'contact24';
$params_attn = 'attn4';
$params_attn2 = 'attn22';
$params_manifestTms = 'manifest_tms0';
$params_truckp = 'truckp6';
$params_truckd = 'truckd0';
$params_timeScanIn = 'time_scan_in6';
$params_deliveries = 'deliveries6';
$params_deliveryPhone2 = 'delivery_phone28';
$params_declaredValue = 'declared_value0';
$params_insuredValue = 'insured_value6';
$params_hideshp = 'hideshp8';
$params_hidecne = 'hidecne0';
$params_hidesrv = 'hidesrv2';
$params_timeTruckOut = 'time_truck_out6';
$params_deviceTruckOut = 'device_truck_out2';
$params_returnStatus = 'return_status4';
$params_timestampReturnStatus = 'timestamp_return_status0';
$params_reasonReturnStatus = 'reason_return_status0';
$params_expReturnStatus = 'exp_return_status2';
$params_deliverySmsAlert = 'delivery_sms_alert8';
$params_deliveryEmailAlert = 'delivery_email_alert6';
$params_flowTag = 'flow_tag6';
$params_validationDatetime = 'validation_datetime2';
$params_smsDeliveryCodeSent = 'sms_delivery_code_sent8';
$params_deliveryBarcodeScan = 'delivery_barcode_scan4';
$params = new Models\TmsShipmentPost(
    $params_orderNum,
    $params_type,
    $params_serviceType,
    $params_priority,
    $params_customerName,
    $params_customerAddress,
    $params_customerZip,
    $params_customerCity,
    $params_customerProv,
    $params_customerCountry,
    $params_customerPhone,
    $params_customerContact,
    $params_customerPassportId,
    $params_pickupName,
    $params_pickupAddress,
    $params_pickupZip,
    $params_pickupDistrict,
    $params_pickupCity,
    $params_pickupProv,
    $params_pickupCountry,
    $params_pickupPhone,
    $params_pickupContact,
    $params_pickupPassportId,
    $params_deliveryName,
    $params_deliveryAddress,
    $params_deliveryZip,
    $params_deliveryDistrict,
    $params_deliveryCity,
    $params_deliveryProv,
    $params_deliveryCountry,
    $params_deliveryPhone,
    $params_deliveryContact,
    $params_deliveryPassportId,
    $params_remarks,
    $params_internalRemarks,
    $params_controlRemarks,
    $params_expParcelNum,
    $params_actParcelNum,
    $params_status,
    $params_timeLastUpdate,
    $params_timeSchedulePickup,
    $params_timeSchedulePickupT,
    $params_timeScheduleDelivery,
    $params_timeScheduleDeliveryT,
    $params_timeActualPickup,
    $params_timeActualDelivery,
    $params_actualContactName,
    $params_actualId,
    $params_customerRef,
    $params_house,
    $params_mawb,
    $params_manifest,
    $params_crewId,
    $params_warehouseId,
    $params_reason,
    $params_customerRequest,
    $params_signature,
    $params_pickable,
    $params_deliverable,
    $params_isSynchro,
    $params_synchroDate,
    $params_deliveryReason,
    $params_deliveryCustomerRequest,
    $params_deliveryRemarks,
    $params_deliverySignature,
    $params_cashOnDelivery,
    $params_incoterm,
    $params_cites,
    $params_atacarnet,
    $params_kimberly,
    $params_environment,
    $params_updateWeight,
    $params_destAirport,
    $params_idAreaPickup,
    $params_idAreaDelivery,
    $params_orderTags,
    $params_bookingRef,
    $params_podExported,
    $params_pickupExported,
    $params_seal,
    $params_cashOnDeliveryCur,
    $params_wrhHold,
    $params_prerefno,
    $params_consolidationId,
    $params_trackingExport,
    $params_exported,
    $params_pickupGuardRef,
    $params_deliveryGuardRef,
    $params_prExported,
    $params_fm3000PodExported,
    $params_fm3000PkExported,
    $params_airexpParcelUpdate,
    $params_as400Exp,
    $params_contact,
    $params_contact2,
    $params_attn,
    $params_attn2,
    $params_manifestTms,
    $params_truckp,
    $params_truckd,
    $params_timeScanIn,
    $params_deliveries,
    $params_deliveryPhone2,
    $params_declaredValue,
    $params_insuredValue,
    $params_hideshp,
    $params_hidecne,
    $params_hidesrv,
    $params_timeTruckOut,
    $params_deviceTruckOut,
    $params_returnStatus,
    $params_timestampReturnStatus,
    $params_reasonReturnStatus,
    $params_expReturnStatus,
    $params_deliverySmsAlert,
    $params_deliveryEmailAlert,
    $params_flowTag,
    $params_validationDatetime,
    $params_smsDeliveryCodeSent,
    $params_deliveryBarcodeScan
);
$id = 'id0';

$result = $tmsController->tMSShipments1($params, $id);
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | `ApiException` |
| 403 | Forbidden | `ApiException` |
| 404 | Not Found | `ApiException` |
| 422 | Unprocessable entity | `ApiException` |


# TMS Shipments 2

```php
function tMSShipments2(string $id): string
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `string` | Template, Required | - |

## Response Type

`string`

## Example Usage

```php
$id = 'id0';

$result = $tmsController->tMSShipments2($id);
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | `ApiException` |
| 403 | Forbidden | `ApiException` |
| 404 | Not Found | `ApiException` |
| 422 | Unprocessable entity | `ApiException` |


# TMS Device Entity

```php
function tMSDeviceEntity(string $id): string
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `string` | Template, Required | - |

## Response Type

`string`

## Example Usage

```php
$id = '1';

$result = $tmsController->tMSDeviceEntity($id);
```

## Example Response

```
"{\n   \"_links\": {\n       \"self\": {\n           \"href\": \"/tms/device[/:device_id]\"\n       }\n   }\n   \"environment\": \"\",\n   \"phonenumber\": \"\",\n   \"number\": \"\",\n   \"serial_nr\": \"\",\n   \"latitude\": \"\",\n   \"longitude\": \"\",\n   \"time_geolocation\": \"\",\n   \"active\": \"\",\n   \"needsync\": \"\",\n   \"push_token\": \"\",\n   \"database_token\": \"\"\n}"
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | `ApiException` |
| 403 | Forbidden | `ApiException` |
| 404 | Not Found | `ApiException` |
| 422 | Unprocessable entity | `ApiException` |


# TMS Device

```php
function tMSDevice(TMSDevice $params): string
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `params` | [`TMSDevice`](../../doc/models/tms-device.md) | Query, Required | - |

## Response Type

`string`

## Example Usage

```php
$params_environment = '1';
$params_phonenumber = 'phonenumber2';
$params_number = 'number8';
$params_needsync = '1';
$params_pushToken = 'push_token0';
$params_databaseToken = 'database_token4';
$params = new Models\TMSDevice(
    $params_environment,
    $params_phonenumber,
    $params_number,
    $params_needsync,
    $params_pushToken,
    $params_databaseToken
);

$result = $tmsController->tMSDevice($params);
```

## Example Response

```
"{\n   \"_links\": {\n       \"self\": {\n           \"href\": \"/tms/device[/:device_id]\"\n       }\n   }\n   \"environment\": \"\",\n   \"phonenumber\": \"\",\n   \"number\": \"\",\n   \"serial_nr\": \"\",\n   \"latitude\": \"\",\n   \"longitude\": \"\",\n   \"time_geolocation\": \"\",\n   \"active\": \"\",\n   \"needsync\": \"\",\n   \"push_token\": \"\",\n   \"database_token\": \"\"\n}"
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | `ApiException` |
| 403 | Forbidden | `ApiException` |
| 404 | Not Found | `ApiException` |
| 422 | Unprocessable entity | `ApiException` |


# TMS Device Collection

```php
function tMSDeviceCollection(
    ?string $environment = null,
    ?string $number = null,
    ?string $active = null,
    ?string $needsync = null
): string
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `environment` | `?string` | Query, Optional | - |
| `number` | `?string` | Query, Optional | - |
| `active` | `?string` | Query, Optional | - |
| `needsync` | `?string` | Query, Optional | - |

## Response Type

`string`

## Example Usage

```php
$environment = '1';
$number = 'A0021';
$active = '1';
$needsync = '1';

$result = $tmsController->tMSDeviceCollection($environment, $number, $active, $needsync);
```

## Example Response

```
"{\n   \"_links\": {\n       \"self\": {\n           \"href\": \"/tms/device\"\n       },\n       \"first\": {\n           \"href\": \"/tms/device?page={page}\"\n       },\n       \"prev\": {\n           \"href\": \"/tms/device?page={page}\"\n       },\n       \"next\": {\n           \"href\": \"/tms/device?page={page}\"\n       },\n       \"last\": {\n           \"href\": \"/tms/device?page={page}\"\n       }\n   }\n   \"_embedded\": {\n       \"device\": [\n           {\n               \"_links\": {\n                   \"self\": {\n                       \"href\": \"/tms/device[/:device_id]\"\n                   }\n               }\n              \"environment\": \"\",\n              \"phonenumber\": \"\",\n              \"number\": \"\",\n              \"serial_nr\": \"\",\n              \"latitude\": \"\",\n              \"longitude\": \"\",\n              \"time_geolocation\": \"\",\n              \"active\": \"\",\n              \"needsync\": \"\",\n              \"push_token\": \"\",\n              \"database_token\": \"\"\n           }\n       ]\n   }\n}"
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | `ApiException` |
| 403 | Forbidden | `ApiException` |
| 404 | Not Found | `ApiException` |
| 422 | Unprocessable entity | `ApiException` |


# TMS Device 1

```php
function tMSDevice1(TMSDevice $params, string $id): string
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `params` | [`TMSDevice`](../../doc/models/tms-device.md) | Body, Required | - |
| `id` | `string` | Template, Required | - |

## Response Type

`string`

## Example Usage

```php
$params_environment = '1';
$params_phonenumber = 'phonenumber2';
$params_number = 'number8';
$params_needsync = '1';
$params_pushToken = 'push_token0';
$params_databaseToken = 'database_token4';
$params = new Models\TMSDevice(
    $params_environment,
    $params_phonenumber,
    $params_number,
    $params_needsync,
    $params_pushToken,
    $params_databaseToken
);
$id = '1';

$result = $tmsController->tMSDevice1($params, $id);
```

## Example Response

```
"{\n   \"_links\": {\n       \"self\": {\n           \"href\": \"/tms/device[/:device_id]\"\n       }\n   }\n   \"environment\": \"\",\n   \"phonenumber\": \"\",\n   \"number\": \"\",\n   \"serial_nr\": \"\",\n   \"latitude\": \"\",\n   \"longitude\": \"\",\n   \"time_geolocation\": \"\",\n   \"active\": \"\",\n   \"needsync\": \"\",\n   \"push_token\": \"\",\n   \"database_token\": \"\"\n}"
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | `ApiException` |
| 403 | Forbidden | `ApiException` |
| 404 | Not Found | `ApiException` |
| 422 | Unprocessable entity | `ApiException` |


# TMS Device 2

```php
function tMSDevice2(string $id): string
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `string` | Template, Required | - |

## Response Type

`string`

## Example Usage

```php
$id = '1';

$result = $tmsController->tMSDevice2($id);
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | `ApiException` |
| 403 | Forbidden | `ApiException` |
| 404 | Not Found | `ApiException` |
| 422 | Unprocessable entity | `ApiException` |


# TMS Shipments Entity

```php
function tMSShipmentsEntity(string $id): string
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `string` | Template, Required | - |

## Response Type

`string`

## Example Usage

```php
$id = '1';

$result = $tmsController->tMSShipmentsEntity($id);
```

## Example Response

```
"{\n   \"_links\": {\n       \"self\": {\n           \"href\": \"/tms/shipment\"\n       },\n       \"first\": {\n           \"href\": \"/tms/shipment?page={page}\"\n       },\n       \"prev\": {\n           \"href\": \"/tms/shipment?page={page}\"\n       },\n       \"next\": {\n           \"href\": \"/tms/shipment?page={page}\"\n       },\n       \"last\": {\n           \"href\": \"/tms/shipment?page={page}\"\n       }\n   }\n   \"_embedded\": {\n       \"shipment\": [\n           {\n               \"_links\": {\n                   \"self\": {\n                       \"href\": \"/tms/shipment[/:shipment_id]\"\n                   }\n               }\n              \"order_num\": \"\",\n              \"type\": \"\",\n              \"service_type\": \"\",\n              \"priority\": \"\",\n              \"customer_name\": \"\",\n              \"customer_address\": \"\",\n              \"customer_zip\": \"\",\n              \"customer_city\": \"\",\n              \"customer_prov\": \"\",\n              \"customer_country\": \"\",\n              \"customer_phone\": \"\",\n              \"customer_contact\": \"\",\n              \"customer_passport_id\": \"\",\n              \"pickup_name\": \"\",\n              \"pickup_address\": \"\",\n              \"pickup_zip\": \"\",\n              \"pickup_district\": \"\",\n              \"pickup_city\": \"\",\n              \"pickup_prov\": \"\",\n              \"pickup_country\": \"\",\n              \"pickup_phone\": \"\",\n              \"pickup_contact\": \"\",\n              \"pickup_passport_id\": \"\",\n              \"delivery_name\": \"\",\n              \"delivery_address\": \"\",\n              \"delivery_zip\": \"\",\n              \"delivery_district\": \"\",\n              \"delivery_city\": \"\",\n              \"delivery_prov\": \"\",\n              \"delivery_country\": \"\",\n              \"delivery_phone\": \"\",\n              \"delivery_contact\": \"\",\n              \"delivery_passport_id\": \"\",\n              \"remarks\": \"\",\n              \"internal_remarks\": \"\",\n              \"control_remarks\": \"\",\n              \"exp_parcel_num\": \"\",\n              \"act_parcel_num\": \"\",\n              \"status\": \"\",\n              \"time_last_update\": \"\",\n              \"time_schedule_pickup\": \"\",\n              \"time_schedule_pickup_t\": \"\",\n              \"time_schedule_delivery\": \"\",\n              \"time_schedule_delivery_t\": \"\",\n              \"time_actual_pickup\": \"\",\n              \"time_actual_delivery\": \"\",\n              \"actual_contact_name\": \"\",\n              \"actual_id\": \"\",\n              \"customer_ref\": \"\",\n              \"house\": \"\",\n              \"mawb\": \"\",\n              \"manifest\": \"\",\n              \"crew_id\": \"\",\n              \"warehouse_id\": \"\",\n              \"reason\": \"\",\n              \"customer_request\": \"\",\n              \"signature\": \"\",\n              \"pickable\": \"\",\n              \"deliverable\": \"\",\n              \"is_synchro\": \"\",\n              \"synchro_date\": \"\",\n              \"delivery_reason\": \"\",\n              \"delivery_customer_request\": \"\",\n              \"delivery_remarks\": \"\",\n              \"delivery_signature\": \"\",\n              \"cash_on_delivery\": \"\",\n              \"incoterm\": \"\",\n              \"cites\": \"\",\n              \"atacarnet\": \"\",\n              \"kimberly\": \"\",\n              \"environment\": \"\",\n              \"update_weight\": \"\",\n              \"dest_airport\": \"\",\n              \"id_area_pickup\": \"\",\n              \"id_area_delivery\": \"\",\n              \"order_tags\": \"\",\n              \"booking_ref\": \"\",\n              \"pod_exported\": \"\",\n              \"pickup_exported\": \"\",\n              \"seal\": \"\",\n              \"cash_on_delivery_cur\": \"\",\n              \"wrh_hold\": \"\",\n              \"prerefno\": \"\",\n              \"consolidation_id\": \"\",\n              \"tracking_export\": \"\",\n              \"exported\": \"\",\n              \"pickup_guard_ref\": \"\",\n              \"delivery_guard_ref\": \"\",\n              \"pr_exported\": \"\",\n              \"fm3000_pod_exported\": \"\",\n              \"fm3000_pk_exported\": \"\",\n              \"airexp_parcel_update\": \"\",\n              \"as400_exp\": \"\",\n              \"contact\": \"\",\n              \"contact2\": \"\",\n              \"attn\": \"\",\n              \"attn2\": \"\",\n              \"manifest_tms\": \"\",\n              \"truckp\": \"\",\n              \"truckd\": \"\",\n              \"time_scan_in\": \"\",\n              \"deliveries\": \"\",\n              \"delivery_phone2\": \"\"\n           }\n       ]\n   }\n}"
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | `ApiException` |
| 403 | Forbidden | `ApiException` |
| 404 | Not Found | `ApiException` |
| 422 | Unprocessable entity | `ApiException` |


# TMS Crew Entity

```php
function tMSCrewEntity(string $id): string
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `string` | Template, Required | - |

## Response Type

`string`

## Example Usage

```php
$id = '1';

$result = $tmsController->tMSCrewEntity($id);
```

## Example Response

```
"{\n   \"_links\": {\n       \"self\": {\n           \"href\": \"/tms/crew[/:crew_id]\"\n       }\n   }\n   \"environment\": \"\",\n   \"valid_day\": \"\",\n   \"notes\": \"\",\n   \"truck_id\": \"\",\n   \"device_id\": \"\",\n   \"device2_id\": \"\"\n}"
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | `ApiException` |
| 403 | Forbidden | `ApiException` |
| 404 | Not Found | `ApiException` |
| 422 | Unprocessable entity | `ApiException` |


# TMS Parcel Entity

```php
function tMSParcelEntity(string $id): string
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `string` | Template, Required | - |

## Response Type

`string`

## Example Usage

```php
$id = '1';

$result = $tmsController->tMSParcelEntity($id);
```

## Example Response

```
"{\n   \"_links\": {\n       \"self\": {\n           \"href\": \"/tms/parcel[/:parcel_id]\"\n       }\n   }\n   \"parcel_num\": \"\",\n   \"order_num\": \"\",\n   \"box_num\": \"\",\n   \"gross_weight\": \"\",\n   \"mark\": \"\",\n   \"item_num\": \"\",\n   \"seal\": \"\",\n   \"dim1\": \"\",\n   \"dim2\": \"\",\n   \"dim3\": \"\",\n   \"label\": \"\",\n   \"seal2\": \"\",\n   \"seal3\": \"\",\n   \"dlv_scan\": \"\",\n   \"pk_scan\": \"\",\n   \"environment\": \"\",\n   \"mark_orig\": \"\"\n}"
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | `ApiException` |
| 403 | Forbidden | `ApiException` |
| 404 | Not Found | `ApiException` |
| 422 | Unprocessable entity | `ApiException` |


# TMS Parcel

```php
function tMSParcel(string $id): string
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `string` | Template, Required | - |

## Response Type

`string`

## Example Usage

```php
$id = '1';

$result = $tmsController->tMSParcel($id);
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | `ApiException` |
| 403 | Forbidden | `ApiException` |
| 404 | Not Found | `ApiException` |
| 422 | Unprocessable entity | `ApiException` |


# TMS Parcel Collection

```php
function tMSParcelCollection(
    ?string $environment = null,
    ?string $orderNum = null,
    ?string $mark = null,
    ?string $seal3 = null,
    ?string $seal2 = null,
    ?string $seal = null,
    ?string $markOrig = null
): string
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `environment` | `?string` | Query, Optional | - |
| `orderNum` | `?string` | Query, Optional | - |
| `mark` | `?string` | Query, Optional | - |
| `seal3` | `?string` | Query, Optional | - |
| `seal2` | `?string` | Query, Optional | - |
| `seal` | `?string` | Query, Optional | - |
| `markOrig` | `?string` | Query, Optional | - |

## Response Type

`string`

## Example Usage

```php
$environment = '1';

$result = $tmsController->tMSParcelCollection($environment);
```

## Example Response

```
"{\n   \"_links\": {\n       \"self\": {\n           \"href\": \"/tms/parcel\"\n       },\n       \"first\": {\n           \"href\": \"/tms/parcel?page={page}\"\n       },\n       \"prev\": {\n           \"href\": \"/tms/parcel?page={page}\"\n       },\n       \"next\": {\n           \"href\": \"/tms/parcel?page={page}\"\n       },\n       \"last\": {\n           \"href\": \"/tms/parcel?page={page}\"\n       }\n   }\n   \"_embedded\": {\n       \"parcel\": [\n           {\n               \"_links\": {\n                   \"self\": {\n                       \"href\": \"/tms/parcel[/:parcel_id]\"\n                   }\n               }\n              \"parcel_num\": \"\",\n              \"order_num\": \"\",\n              \"box_num\": \"\",\n              \"gross_weight\": \"\",\n              \"mark\": \"\",\n              \"item_num\": \"\",\n              \"seal\": \"\",\n              \"dim1\": \"\",\n              \"dim2\": \"\",\n              \"dim3\": \"\",\n              \"label\": \"\",\n              \"seal2\": \"\",\n              \"seal3\": \"\",\n              \"dlv_scan\": \"\",\n              \"pk_scan\": \"\",\n              \"environment\": \"\",\n              \"mark_orig\": \"\"\n           }\n       ]\n   }\n}"
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | `ApiException` |
| 403 | Forbidden | `ApiException` |
| 404 | Not Found | `ApiException` |
| 422 | Unprocessable entity | `ApiException` |


# TMS Parcel 1

```php
function tMSParcel1(string $id, TMSParcel $params): string
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `string` | Template, Required | - |
| `params` | [`TMSParcel`](../../doc/models/tms-parcel.md) | Body, Required | - |

## Response Type

`string`

## Example Usage

```php
$id = 'id0';
$params_parcelNum = 'parcel_num8';
$params_orderNum = 'order_num6';
$params_boxNum = 'box_num6';
$params_grossWeight = 'gross_weight0';
$params_mark = 'mark0';
$params_itemNum = 'item_num8';
$params_seal = 'seal6';
$params_dim1 = 'dim12';
$params_dim2 = 'dim24';
$params_dim3 = 'dim38';
$params_label = 'label4';
$params_seal2 = 'seal26';
$params_seal3 = 'seal30';
$params_dlvScan = 'dlv_scan8';
$params_pkScan = 'pk_scan8';
$params_environment = 'environment0';
$params_markOrig = 'mark_orig0';
$params = new Models\TMSParcel(
    $params_parcelNum,
    $params_orderNum,
    $params_boxNum,
    $params_grossWeight,
    $params_mark,
    $params_itemNum,
    $params_seal,
    $params_dim1,
    $params_dim2,
    $params_dim3,
    $params_label,
    $params_seal2,
    $params_seal3,
    $params_dlvScan,
    $params_pkScan,
    $params_environment,
    $params_markOrig
);

$result = $tmsController->tMSParcel1($id, $params);
```

## Example Response

```
"{\n   \"_links\": {\n       \"self\": {\n           \"href\": \"/tms/parcel\"\n       },\n       \"first\": {\n           \"href\": \"/tms/parcel?page={page}\"\n       },\n       \"prev\": {\n           \"href\": \"/tms/parcel?page={page}\"\n       },\n       \"next\": {\n           \"href\": \"/tms/parcel?page={page}\"\n       },\n       \"last\": {\n           \"href\": \"/tms/parcel?page={page}\"\n       }\n   }\n   \"_embedded\": {\n       \"parcel\": [\n           {\n               \"_links\": {\n                   \"self\": {\n                       \"href\": \"/tms/parcel[/:parcel_id]\"\n                   }\n               }\n              \"parcel_num\": \"\",\n              \"order_num\": \"\",\n              \"box_num\": \"\",\n              \"gross_weight\": \"\",\n              \"mark\": \"\",\n              \"item_num\": \"\",\n              \"seal\": \"\",\n              \"dim1\": \"\",\n              \"dim2\": \"\",\n              \"dim3\": \"\",\n              \"label\": \"\",\n              \"seal2\": \"\",\n              \"seal3\": \"\",\n              \"dlv_scan\": \"\",\n              \"pk_scan\": \"\",\n              \"environment\": \"\",\n              \"mark_orig\": \"\"\n           }\n       ]\n   }\n}"
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | `ApiException` |
| 403 | Forbidden | `ApiException` |
| 404 | Not Found | `ApiException` |
| 422 | Unprocessable entity | `ApiException` |


# TMS Parcel 2

```php
function tMSParcel2(TMSParcel $params): string
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `params` | [`TMSParcel`](../../doc/models/tms-parcel.md) | Query, Required | - |

## Response Type

`string`

## Example Usage

```php
$params_parcelNum = 'parcel_num8';
$params_orderNum = 'order_num6';
$params_boxNum = 'box_num6';
$params_grossWeight = 'gross_weight0';
$params_mark = 'mark0';
$params_itemNum = 'item_num8';
$params_seal = 'seal6';
$params_dim1 = 'dim12';
$params_dim2 = 'dim24';
$params_dim3 = 'dim38';
$params_label = 'label4';
$params_seal2 = 'seal26';
$params_seal3 = 'seal30';
$params_dlvScan = 'dlv_scan8';
$params_pkScan = 'pk_scan8';
$params_environment = 'environment0';
$params_markOrig = 'mark_orig0';
$params = new Models\TMSParcel(
    $params_parcelNum,
    $params_orderNum,
    $params_boxNum,
    $params_grossWeight,
    $params_mark,
    $params_itemNum,
    $params_seal,
    $params_dim1,
    $params_dim2,
    $params_dim3,
    $params_label,
    $params_seal2,
    $params_seal3,
    $params_dlvScan,
    $params_pkScan,
    $params_environment,
    $params_markOrig
);

$result = $tmsController->tMSParcel2($params);
```

## Example Response

```
"{\n   \"_links\": {\n       \"self\": {\n           \"href\": \"/tms/parcel[/:parcel_id]\"\n       }\n   }\n   \"parcel_num\": \"\",\n   \"order_num\": \"\",\n   \"box_num\": \"\",\n   \"gross_weight\": \"\",\n   \"mark\": \"\",\n   \"item_num\": \"\",\n   \"seal\": \"\",\n   \"dim1\": \"\",\n   \"dim2\": \"\",\n   \"dim3\": \"\",\n   \"label\": \"\",\n   \"seal2\": \"\",\n   \"seal3\": \"\",\n   \"dlv_scan\": \"\",\n   \"pk_scan\": \"\",\n   \"environment\": \"\",\n   \"mark_orig\": \"\"\n}"
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | `ApiException` |
| 403 | Forbidden | `ApiException` |
| 404 | Not Found | `ApiException` |
| 422 | Unprocessable entity | `ApiException` |


# TMS Attachment Upload

```php
function tMSAttachmentUpload(string $filename, string $base64): string
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `filename` | `string` | Query, Required | - |
| `base64` | `string` | Query, Required | - |

## Response Type

`string`

## Example Usage

```php
$filename = 'filename2';
$base64 = 'base642';

$result = $tmsController->tMSAttachmentUpload($filename, $base64);
```

## Example Response

```
"{\n    \"token\": \"a94a8fe5ccb19ba61c4c0873d391e987982fbbd3623442e48f6ad\"\n}"
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | `ApiException` |
| 403 | Forbidden | `ApiException` |
| 404 | Not Found | `ApiException` |
| 422 | Unprocessable entity | `ApiException` |


# TMS Attachment Upload Public

```php
function tMSAttachmentUploadPublic(string $filename, string $tokenFile): string
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `filename` | `string` | Query, Required | - |
| `tokenFile` | `string` | Query, Required | - |

## Response Type

`string`

## Example Usage

```php
$filename = 'filename2';
$tokenFile = 'token_file2';

$result = $tmsController->tMSAttachmentUploadPublic($filename, $tokenFile);
```

## Example Response

```
"{\n    \"attachment_id\": 20199,\n    \"nome_file\": \"test.jpg\"\n}"
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | `ApiException` |
| 403 | Forbidden | `ApiException` |
| 404 | Not Found | `ApiException` |
| 422 | Unprocessable entity | `ApiException` |


# TMS Login Info

```php
function tMSLoginInfo(string $device): string
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `device` | `string` | Query, Required | - |

## Response Type

`string`

## Example Usage

```php
$device = 'device6';

$result = $tmsController->tMSLoginInfo($device);
```

## Example Response

```
"{\n    \"staff_id\": \"marco-tms.test\",\n    \"environment\": \"1\",\n    \"guard_id\": \"TMS-id-82\",\n    \"device_id\": 1,\n    \"database_token\": \"Ferrari2019!1\",\n    \"settings\": [\n        {\n            \"addesses\": \"1\"\n        },\n        {\n            \"branch_visible\": \"0\"\n        },\n        {\n            \"bulk_seal_pickup\": \"0\"\n        },\n        {\n            \"buono_presa\": \"0\"\n        },\n        {\n            \"confirm_all_pickup\": \"1\"\n        },\n        {\n            \"confirm_manifest\": \"0\"\n        },\n        {\n            \"copyright_signature\": \"1\"\n        },\n        {\n            \"crew_managment\": \"0\"\n        },\n        {\n            \"delivery_contact\": \"1\"\n        },\n        {\n            \"delivery_copyright\": \"By signing this document, I hereby confirm the parcels are received in good condition and without any visible sign of tampering.\"\n        },\n        {\n            \"hawb_in_list\": \"0\"\n        },\n        {\n            \"head_print\": \"Ferrari Logistics (ASIA) Ltd\"\n        },\n        {\n            \"home\": \"view/home.html\"\n        },\n        {\n            \"home_ferrari\": \"0\"\n        },\n        {\n            \"keypress\": \"0\"\n        },\n        {\n            \"language\": \"en\"\n        },\n        {\n            \"mandatory_passport_id\": \"1\"\n        },\n        {\n            \"mandatory_signature\": \"1\"\n        },\n        {\n            \"manifest_marks\": \"1\"\n        },\n        {\n            \"manifest_operation\": \"1\"\n        },\n        {\n            \"manifest_select_ship\": \"1\"\n        },\n        {\n            \"manifest_simple\": \"0\"\n        },\n        {\n            \"mark_pickup_list\": \"0\"\n        },\n        {\n            \"mawb_hawb_print_label\": \"1\"\n        },\n        {\n            \"order_list\": \"1\"\n        },\n        {\n            \"pickup_copyright\": \"By signing this document, I hereby confirm the information indicated in this document is accurate. I also accept and acknowledge the General Conditions of Ferrari Group/Agents for International Carriage as published on the web site  www.ferrarigroup.net\"\n        },\n        {\n            \"pickup_manifest_seal_insert\": \"0\"\n        },\n        {\n            \"pickup_parcels_data\": \"0\"\n        },\n        {\n            \"poste_visible\": \"0\"\n        },\n        {\n            \"prefix_order\": \"0\"\n        },\n        {\n            \"print_bookink_ref_pickup\": \"0\"\n        },\n        {\n            \"print_confirm_order\": \"1\"\n        },\n        {\n            \"print_label\": \"1\"\n        },\n        {\n            \"rolex_functionality\": \"0\"\n        },\n        {\n            \"row1\": \"Hong Kong\"\n        },\n        {\n            \"scan_in_auto\": \"0\"\n        },\n        {\n            \"scan_in_new\": \"1\"\n        },\n        {\n            \"shared_signature\": \"1\"\n        },\n        {\n            \"signature\": \"1\"\n        },\n        {\n            \"signature_pickup\": \"1\"\n        },\n        {\n            \"simsun\": \"1\"\n        },\n        {\n            \"syncro_kcc_address\": \"1\"\n        },\n        {\n            \"syncro_tms\": \"1\"\n        },\n        {\n            \"syncro_tracking_place\": \"0\"\n        },\n        {\n            \"tms\": \"Hong kong\"\n        },\n        {\n            \"tracking_events\": \"0\"\n        },\n        {\n            \"tracking_events_daily_delete\": \"0\"\n        },\n        {\n            \"tracking_events_prov\": \"0\"\n        },\n        {\n            \"tracking_places\": \"0\"\n        },\n        {\n            \"truck_utilities\": \"1\"\n        },\n        {\n            \"wso_addresses\": \"TMS\"\n        }\n    ]\n}"
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | `ApiException` |
| 403 | Forbidden | `ApiException` |
| 404 | Not Found | `ApiException` |
| 422 | Unprocessable entity | `ApiException` |


# TMS Attachment Entity

```php
function tMSAttachmentEntity(string $id): string
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `string` | Template, Required | - |

## Response Type

`string`

## Example Usage

```php
$id = 'id0';

$result = $tmsController->tMSAttachmentEntity($id);
```

## Example Response

```
"{\n   \"_links\": {\n       \"self\": {\n           \"href\": \"/tms/attachment[/:attachment_id]\"\n       }\n   }\n   \"order_num\": \"\",\n   \"type\": \"\",\n   \"file_id\": \"\",\n   \"timestamp\": \"\",\n   \"environment\": \"\"\n}"
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | `ApiException` |
| 403 | Forbidden | `ApiException` |
| 404 | Not Found | `ApiException` |
| 422 | Unprocessable entity | `ApiException` |


# TMS Attachment Collection

```php
function tMSAttachmentCollection(
    ?string $orderNum = null,
    ?string $environment = null,
    ?string $fileId = null,
    ?string $type = null
): string
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `orderNum` | `?string` | Query, Optional | - |
| `environment` | `?string` | Query, Optional | - |
| `fileId` | `?string` | Query, Optional | - |
| `type` | `?string` | Query, Optional | - |

## Response Type

`string`

## Example Usage

```php
$result = $tmsController->tMSAttachmentCollection();
```

## Example Response

```
"{\n   \"_links\": {\n       \"self\": {\n           \"href\": \"/tms/attachment\"\n       },\n       \"first\": {\n           \"href\": \"/tms/attachment?page={page}\"\n       },\n       \"prev\": {\n           \"href\": \"/tms/attachment?page={page}\"\n       },\n       \"next\": {\n           \"href\": \"/tms/attachment?page={page}\"\n       },\n       \"last\": {\n           \"href\": \"/tms/attachment?page={page}\"\n       }\n   }\n   \"_embedded\": {\n       \"attachment\": [\n           {\n               \"_links\": {\n                   \"self\": {\n                       \"href\": \"/tms/attachment[/:attachment_id]\"\n                   }\n               }\n              \"order_num\": \"\",\n              \"type\": \"\",\n              \"file_id\": \"\",\n              \"timestamp\": \"\",\n              \"environment\": \"\"\n           }\n       ]\n   }\n}"
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | `ApiException` |
| 403 | Forbidden | `ApiException` |
| 404 | Not Found | `ApiException` |
| 422 | Unprocessable entity | `ApiException` |


# TMS Attachment

```php
function tMSAttachment(string $id, TMSAttachment $params): string
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `string` | Template, Required | - |
| `params` | [`TMSAttachment`](../../doc/models/tms-attachment.md) | Body, Required | - |

## Response Type

`string`

## Example Usage

```php
$id = 'id0';
$params_orderNum = 'order_num6';
$params_type = 'type6';
$params_fileId = 'file_id0';
$params_timestamp = 'timestamp2';
$params_environment = 'environment0';
$params = new Models\TMSAttachment(
    $params_orderNum,
    $params_type,
    $params_fileId,
    $params_timestamp,
    $params_environment
);

$result = $tmsController->tMSAttachment($id, $params);
```

## Example Response

```
"{\n   \"_links\": {\n       \"self\": {\n           \"href\": \"/tms/attachment\"\n       },\n       \"first\": {\n           \"href\": \"/tms/attachment?page={page}\"\n       },\n       \"prev\": {\n           \"href\": \"/tms/attachment?page={page}\"\n       },\n       \"next\": {\n           \"href\": \"/tms/attachment?page={page}\"\n       },\n       \"last\": {\n           \"href\": \"/tms/attachment?page={page}\"\n       }\n   }\n   \"_embedded\": {\n       \"attachment\": [\n           {\n               \"_links\": {\n                   \"self\": {\n                       \"href\": \"/tms/attachment[/:attachment_id]\"\n                   }\n               }\n              \"order_num\": \"\",\n              \"type\": \"\",\n              \"file_id\": \"\",\n              \"timestamp\": \"\",\n              \"environment\": \"\"\n           }\n       ]\n   }\n}"
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | `ApiException` |
| 403 | Forbidden | `ApiException` |
| 404 | Not Found | `ApiException` |
| 422 | Unprocessable entity | `ApiException` |


# TMS Attachment 1

```php
function tMSAttachment1(string $id): string
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `string` | Template, Required | - |

## Response Type

`string`

## Example Usage

```php
$id = 'id0';

$result = $tmsController->tMSAttachment1($id);
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | `ApiException` |
| 403 | Forbidden | `ApiException` |
| 404 | Not Found | `ApiException` |
| 422 | Unprocessable entity | `ApiException` |


# TMS Attachment 2

```php
function tMSAttachment2(TMSAttachment $params): string
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `params` | [`TMSAttachment`](../../doc/models/tms-attachment.md) | Body, Required | - |

## Response Type

`string`

## Example Usage

```php
$params_orderNum = 'order_num6';
$params_type = 'type6';
$params_fileId = 'file_id0';
$params_timestamp = 'timestamp2';
$params_environment = 'environment0';
$params = new Models\TMSAttachment(
    $params_orderNum,
    $params_type,
    $params_fileId,
    $params_timestamp,
    $params_environment
);

$result = $tmsController->tMSAttachment2($params);
```

## Example Response

```
"{\n   \"_links\": {\n       \"self\": {\n           \"href\": \"/tms/attachment[/:attachment_id]\"\n       }\n   }\n   \"order_num\": \"\",\n   \"type\": \"\",\n   \"file_id\": \"\",\n   \"timestamp\": \"\",\n   \"environment\": \"\"\n}"
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | `ApiException` |
| 403 | Forbidden | `ApiException` |
| 404 | Not Found | `ApiException` |
| 422 | Unprocessable entity | `ApiException` |


# TMS Scan Parcel List

```php
function tMSScanParcelList(string $id): string
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `string` | Body, Required | - |

## Response Type

`string`

## Example Usage

```php
$id = '19GV210E91H001';

$result = $tmsController->tMSScanParcelList($id);
```

## Example Response

```
"{\n    \"0\": {\n        \"order_num\": \"19GV210E91H\",\n        \"type\": \"D\",\n        \"delivery_remarks\": \"\",\n        \"seal\": \"921443\",\n        \"service_type\": \"\",\n        \"prerefno\": \"\",\n        \"mawb\": \"72405808342\",\n        \"house\": \"19PA110D62Q\",\n        \"parcels\": [\n            {\n                \"id\": 9948831,\n                \"parcel_num\": \"19GV210E91H001\",\n                \"order_num\": \"19GV210E91H\",\n                \"box_num\": 1,\n                \"gross_weight\": 0,\n                \"mark\": \"\",\n                \"item_num\": 1,\n                \"seal\": \"\",\n                \"dim1\": 0,\n                \"dim2\": 0,\n                \"dim3\": 0,\n                \"label\": \"\",\n                \"seal2\": \"\",\n                \"seal3\": \"\",\n                \"ext_seal\": \"\",\n                \"dlv_scan\": 0,\n                \"pk_scan\": 0,\n                \"environment\": 7,\n                \"mark_orig\": \"\"\n            },\n            {\n                \"id\": 9948832,\n                \"parcel_num\": \"19GV210E91H002\",\n                \"order_num\": \"19GV210E91H\",\n                \"box_num\": 1,\n                \"gross_weight\": 0,\n                \"mark\": \"\",\n                \"item_num\": 1,\n                \"seal\": \"\",\n                \"dim1\": 0,\n                \"dim2\": 0,\n                \"dim3\": 0,\n                \"label\": \"\",\n                \"seal2\": \"\",\n                \"seal3\": \"\",\n                \"ext_seal\": \"\",\n                \"dlv_scan\": 0,\n                \"pk_scan\": 0,\n                \"environment\": 7,\n                \"mark_orig\": \"\"\n            },\n            {\n                \"id\": 9948833,\n                \"parcel_num\": \"19GV210E91H003\",\n                \"order_num\": \"19GV210E91H\",\n                \"box_num\": 1,\n                \"gross_weight\": 0,\n                \"mark\": \"\",\n                \"item_num\": 1,\n                \"seal\": \"\",\n                \"dim1\": 0,\n                \"dim2\": 0,\n                \"dim3\": 0,\n                \"label\": \"\",\n                \"seal2\": \"\",\n                \"seal3\": \"\",\n                \"ext_seal\": \"\",\n                \"dlv_scan\": 0,\n                \"pk_scan\": 0,\n                \"environment\": 7,\n                \"mark_orig\": \"\"\n            }\n        ]\n    }\n}"
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | `ApiException` |
| 403 | Forbidden | `ApiException` |
| 404 | Not Found | `ApiException` |
| 422 | Unprocessable entity | `ApiException` |


# TMS Scan In

```php
function tMSScanIn(TMsScanIn $params): void
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `params` | [`TMsScanIn`](../../doc/models/t-ms-scan-in.md) | Body, Required | - |

## Response Type

`void`

## Example Usage

```php
$params_orderNum = '19GV210E91H';
$params_device = 'G0011';
$params_timeActualScan = '2022-04-21 12:11:07';
$params = new Models\TMsScanIn(
    $params_orderNum,
    $params_device,
    $params_timeActualScan
);

$tmsController->tMSScanIn($params);
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | `ApiException` |
| 403 | Forbidden | `ApiException` |
| 404 | Not Found | `ApiException` |
| 422 | Unprocessable entity | `ApiException` |


# TMS Warehouse Collection

```php
function tMSWarehouseCollection(?string $environment = null, ?string $code = null, ?int $active = null): string
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `environment` | `?string` | Query, Optional | - |
| `code` | `?string` | Query, Optional | - |
| `active` | `?int` | Query, Optional | - |

## Response Type

`string`

## Example Usage

```php
$active = 1;

$result = $tmsController->tMSWarehouseCollection(null, null, $active);
```

## Example Response

```
"{\n    \"_links\": {\n        \"self\": {\n            \"href\": \"https://fundoni.webapps2-backend.test.ferrarigroup.net/tms/warehouse?page=1\"\n        },\n        \"first\": {\n            \"href\": \"https://fundoni.webapps2-backend.test.ferrarigroup.net/tms/warehouse\"\n        },\n        \"last\": {\n            \"href\": \"https://fundoni.webapps2-backend.test.ferrarigroup.net/tms/warehouse?page=2\"\n        },\n        \"next\": {\n            \"href\": \"https://fundoni.webapps2-backend.test.ferrarigroup.net/tms/warehouse?page=2\"\n        }\n    },\n    \"_embedded\": {\n        \"warehouse\": [\n            {\n                \"id\": 1,\n                \"code\": \"HKG\",\n                \"description\": \"Hong Kong Warehouse\",\n                \"environment\": 1,\n                \"active\": 1,\n                \"_links\": {\n                    \"self\": {\n                        \"href\": \"https://fundoni.webapps2-backend.test.ferrarigroup.net/tms/warehouse/1\"\n                    }\n                }\n            },\n            {\n                \"id\": 2,\n                \"code\": \"BV1\",\n                \"description\": \"Buffer vehicle 1 KCC\",\n                \"environment\": 1,\n                \"active\": 1,\n                \"_links\": {\n                    \"self\": {\n                        \"href\": \"https://fundoni.webapps2-backend.test.ferrarigroup.net/tms/warehouse/2\"\n                    }\n                }\n            },\n            {\n                \"id\": 3,\n                \"code\": \"BV2\",\n                \"description\": \"Buffer vehicle 2 KCC\",\n                \"environment\": 1,\n                \"active\": 1,\n                \"_links\": {\n                    \"self\": {\n                        \"href\": \"https://fundoni.webapps2-backend.test.ferrarigroup.net/tms/warehouse/3\"\n                    }\n                }\n            },\n            {\n                \"id\": 4,\n                \"code\": \"BV3\",\n                \"description\": \"Buffer vehicle 3 KCC\",\n                \"environment\": 1,\n                \"active\": 1,\n                \"_links\": {\n                    \"self\": {\n                        \"href\": \"https://fundoni.webapps2-backend.test.ferrarigroup.net/tms/warehouse/4\"\n                    }\n                }\n            },\n            {\n                \"id\": 6,\n                \"code\": \"BOF1\",\n                \"description\": \"CENTRAL OFFICE\",\n                \"environment\": 1,\n                \"active\": 1,\n                \"_links\": {\n                    \"self\": {\n                        \"href\": \"https://fundoni.webapps2-backend.test.ferrarigroup.net/tms/warehouse/6\"\n                    }\n                }\n            },\n            {\n                \"id\": 7,\n                \"code\": \"BOF2\",\n                \"description\": \"HUNGHOM OFFICE\",\n                \"environment\": 1,\n                \"active\": 1,\n                \"_links\": {\n                    \"self\": {\n                        \"href\": \"https://fundoni.webapps2-backend.test.ferrarigroup.net/tms/warehouse/7\"\n                    }\n                }\n            },\n            {\n                \"id\": 43,\n                \"code\": \"test2\",\n                \"description\": \"warehouse di test 2\",\n                \"environment\": 1,\n                \"active\": 1,\n                \"_links\": {\n                    \"self\": {\n                        \"href\": \"https://fundoni.webapps2-backend.test.ferrarigroup.net/tms/warehouse/43\"\n                    }\n                }\n            },\n            {\n                \"id\": 44,\n                \"code\": \"01\",\n                \"description\": \"test\",\n                \"environment\": 9,\n                \"active\": 1,\n                \"_links\": {\n                    \"self\": {\n                        \"href\": \"https://fundoni.webapps2-backend.test.ferrarigroup.net/tms/warehouse/44\"\n                    }\n                }\n            },\n            {\n                \"id\": 45,\n                \"code\": \"01\",\n                \"description\": \"test\",\n                \"environment\": 8,\n                \"active\": 1,\n                \"_links\": {\n                    \"self\": {\n                        \"href\": \"https://fundoni.webapps2-backend.test.ferrarigroup.net/tms/warehouse/45\"\n                    }\n                }\n            },\n            {\n                \"id\": 46,\n                \"code\": \"02\",\n                \"description\": \"test2\",\n                \"environment\": 8,\n                \"active\": 1,\n                \"_links\": {\n                    \"self\": {\n                        \"href\": \"https://fundoni.webapps2-backend.test.ferrarigroup.net/tms/warehouse/46\"\n                    }\n                }\n            },\n            {\n                \"id\": 47,\n                \"code\": \"TEST ARI\",\n                \"description\": \"TEST ARI\",\n                \"environment\": 14,\n                \"active\": 1,\n                \"_links\": {\n                    \"self\": {\n                        \"href\": \"https://fundoni.webapps2-backend.test.ferrarigroup.net/tms/warehouse/47\"\n                    }\n                }\n            },\n            {\n                \"id\": 48,\n                \"code\": \"T\",\n                \"description\": \"Buffer truck\",\n                \"environment\": 8,\n                \"active\": 1,\n                \"_links\": {\n                    \"self\": {\n                        \"href\": \"https://fundoni.webapps2-backend.test.ferrarigroup.net/tms/warehouse/48\"\n                    }\n                }\n            },\n            {\n                \"id\": 49,\n                \"code\": \"S-2\",\n                \"description\": \"Shanghai downtown 608\",\n                \"environment\": 8,\n                \"active\": 1,\n                \"_links\": {\n                    \"self\": {\n                        \"href\": \"https://fundoni.webapps2-backend.test.ferrarigroup.net/tms/warehouse/49\"\n                    }\n                }\n            },\n            {\n                \"id\": 50,\n                \"code\": \"RCCL1\",\n                \"description\": \"线路一\",\n                \"environment\": 8,\n                \"active\": 1,\n                \"_links\": {\n                    \"self\": {\n                        \"href\": \"https://fundoni.webapps2-backend.test.ferrarigroup.net/tms/warehouse/50\"\n                    }\n                }\n            },\n            {\n                \"id\": 51,\n                \"code\": \"RCCL2\",\n                \"description\": \"线路二\",\n                \"environment\": 8,\n                \"active\": 1,\n                \"_links\": {\n                    \"self\": {\n                        \"href\": \"https://fundoni.webapps2-backend.test.ferrarigroup.net/tms/warehouse/51\"\n                    }\n                }\n            },\n            {\n                \"id\": 52,\n                \"code\": \"RCCL3\",\n                \"description\": \"线路三\",\n                \"environment\": 8,\n                \"active\": 1,\n                \"_links\": {\n                    \"self\": {\n                        \"href\": \"https://fundoni.webapps2-backend.test.ferrarigroup.net/tms/warehouse/52\"\n                    }\n                }\n            },\n            {\n                \"id\": 53,\n                \"code\": \"CN_01\",\n                \"description\": \"Test Warehouse\",\n                \"environment\": 8,\n                \"active\": 1,\n                \"_links\": {\n                    \"self\": {\n                        \"href\": \"https://fundoni.webapps2-backend.test.ferrarigroup.net/tms/warehouse/53\"\n                    }\n                }\n            },\n            {\n                \"id\": 54,\n                \"code\": \"GVATEST\",\n                \"description\": \"Test GVA\",\n                \"environment\": 7,\n                \"active\": 1,\n                \"_links\": {\n                    \"self\": {\n                        \"href\": \"https://fundoni.webapps2-backend.test.ferrarigroup.net/tms/warehouse/54\"\n                    }\n                }\n            },\n            {\n                \"id\": 55,\n                \"code\": \"VAULT\",\n                \"description\": \"unit 6\",\n                \"environment\": 1,\n                \"active\": 1,\n                \"_links\": {\n                    \"self\": {\n                        \"href\": \"https://fundoni.webapps2-backend.test.ferrarigroup.net/tms/warehouse/55\"\n                    }\n                }\n            },\n            {\n                \"id\": 56,\n                \"code\": \"VAULT 2\",\n                \"description\": \"UNIT 3\",\n                \"environment\": 1,\n                \"active\": 1,\n                \"_links\": {\n                    \"self\": {\n                        \"href\": \"https://fundoni.webapps2-backend.test.ferrarigroup.net/tms/warehouse/56\"\n                    }\n                }\n            },\n            {\n                \"id\": 57,\n                \"code\": \"SHOW(1)\",\n                \"description\": \"UNIT 3 (SHOW)\",\n                \"environment\": 1,\n                \"active\": 1,\n                \"_links\": {\n                    \"self\": {\n                        \"href\": \"https://fundoni.webapps2-backend.test.ferrarigroup.net/tms/warehouse/57\"\n                    }\n                }\n            },\n            {\n                \"id\": 58,\n                \"code\": \"SHOW(2)\",\n                \"description\": \"UNIT 6(SHOW)\",\n                \"environment\": 1,\n                \"active\": 1,\n                \"_links\": {\n                    \"self\": {\n                        \"href\": \"https://fundoni.webapps2-backend.test.ferrarigroup.net/tms/warehouse/58\"\n                    }\n                }\n            },\n            {\n                \"id\": 59,\n                \"code\": \"D\",\n                \"description\": \"SDE safe room\",\n                \"environment\": 8,\n                \"active\": 1,\n                \"_links\": {\n                    \"self\": {\n                        \"href\": \"https://fundoni.webapps2-backend.test.ferrarigroup.net/tms/warehouse/59\"\n                    }\n                }\n            },\n            {\n                \"id\": 60,\n                \"code\": \"S\",\n                \"description\": \"Shanghai downtown 708\",\n                \"environment\": 8,\n                \"active\": 1,\n                \"_links\": {\n                    \"self\": {\n                        \"href\": \"https://fundoni.webapps2-backend.test.ferrarigroup.net/tms/warehouse/60\"\n                    }\n                }\n            },\n            {\n                \"id\": 61,\n                \"code\": \"W\",\n                \"description\": \"Shanghai ALC\",\n                \"environment\": 8,\n                \"active\": 1,\n                \"_links\": {\n                    \"self\": {\n                        \"href\": \"https://fundoni.webapps2-backend.test.ferrarigroup.net/tms/warehouse/61\"\n                    }\n                }\n            }\n        ]\n    },\n    \"page_count\": 2,\n    \"page_size\": 25,\n    \"total_items\": 36,\n    \"page\": 1\n}"
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | `ApiException` |
| 403 | Forbidden | `ApiException` |
| 404 | Not Found | `ApiException` |
| 422 | Unprocessable entity | `ApiException` |


# TMS Warehouse Entity

```php
function tMSWarehouseEntity(string $id): string
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `string` | Template, Required | - |

## Response Type

`string`

## Example Usage

```php
$id = 'id0';

$result = $tmsController->tMSWarehouseEntity($id);
```

## Example Response

```
"{\n    \"id\": 1,\n    \"code\": \"HKG\",\n    \"description\": \"Hong Kong Warehouse\",\n    \"environment\": 1,\n    \"active\": 1,\n    \"_links\": {\n        \"self\": {\n            \"href\": \"https://fundoni.webapps2-backend.test.ferrarigroup.net/tms/warehouse/1\"\n        }\n    }\n}"
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | `ApiException` |
| 403 | Forbidden | `ApiException` |
| 404 | Not Found | `ApiException` |
| 422 | Unprocessable entity | `ApiException` |


# TMS Warehouse

```php
function tMSWarehouse(string $id): string
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `string` | Template, Required | - |

## Response Type

`string`

## Example Usage

```php
$id = 'id0';

$result = $tmsController->tMSWarehouse($id);
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | `ApiException` |
| 403 | Forbidden | `ApiException` |
| 404 | Not Found | `ApiException` |
| 422 | Unprocessable entity | `ApiException` |


# TMS Warehouse 1

```php
function tMSWarehouse1(string $id, TMSWarehouse $params): string
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `string` | Template, Required | - |
| `params` | [`TMSWarehouse`](../../doc/models/tms-warehouse.md) | Body, Required | - |

## Response Type

`string`

## Example Usage

```php
$id = 'id0';
$params_code = 'HKG';
$params_description = 'Hong Kong Warehouse test';
$params_environment = '1';
$params_active = '1';
$params = new Models\TMSWarehouse(
    $params_code,
    $params_description,
    $params_environment,
    $params_active
);

$result = $tmsController->tMSWarehouse1($id, $params);
```

## Example Response

```
"{\n    \"id\": 1,\n    \"code\": \"HKG\",\n    \"description\": \"Hong Kong Warehouse test\",\n    \"environment\": 1,\n    \"active\": 1,\n    \"_links\": {\n        \"self\": {\n            \"href\": \"https://fundoni.webapps2-backend.test.ferrarigroup.net/tms/warehouse/1\"\n        }\n    }\n}"
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | `ApiException` |
| 403 | Forbidden | `ApiException` |
| 404 | Not Found | `ApiException` |
| 422 | Unprocessable entity | `ApiException` |


# TMS Manifest Create

```php
function tMSManifestCreate(): string
```

## Response Type

`string`

## Example Usage

```php
$result = $tmsController->tMSManifestCreate();
```

## Example Response

```
"{\n    \"manifest_number\": \"TMSM1202255568242\"\n}"
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | `ApiException` |
| 403 | Forbidden | `ApiException` |
| 404 | Not Found | `ApiException` |
| 422 | Unprocessable entity | `ApiException` |


# TMS Track Action

```php
function tMSTrackAction(TMSTrackAction $params): string
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `params` | [`TMSTrackAction`](../../doc/models/tms-track-action.md) | Query, Required | - |

## Response Type

`string`

## Example Usage

```php
$params_action = 'PS';
$params_objectId = '123456789';
$params_place = 'place6';
$params_latitude = '40.8356714';
$params_longitude = '-74.4410216';
$params_userId = 'user_id2';
$params_timestamp = '1654791804433';
$params_device = 'CC123';
$params_environment = '20';
$params_tag = 'POSTE';
$params_manifestId = 'Ferr00000000';
$params = new Models\TMSTrackAction(
    $params_action,
    $params_objectId,
    $params_place,
    $params_latitude,
    $params_longitude,
    $params_userId,
    $params_timestamp,
    $params_device,
    $params_environment,
    $params_tag,
    $params_manifestId
);
$params->setName('name4');
$params->setRemarks('remarks0');
$params->setSeal('seal6');
$params->setAttachments('attachments4');

$result = $tmsController->tMSTrackAction($params);
```

## Example Response

```
"{\n   \"action\": \"\",\n   \"object_id\": \"\",\n   \"place\": \"\",\n   \"latitude\": \"\",\n   \"longitude\": \"\",\n   \"user_id\": \"\",\n   \"timestamp\": \"\",\n   \"ferrari_branch\": \"\",\n   \"device\": \"\",\n   \"environment\": \"\",\n   \"tag\": \"\",\n   \"name\": \"\",\n   \"remarks\": \"\",\n   \"seal\": \"\",\n   \"manifest_id\": \"\",\n   \"attachments\": \"\"\n}"
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | `ApiException` |
| 403 | Forbidden | `ApiException` |
| 404 | Not Found | `ApiException` |
| 422 | Unprocessable entity | `ApiException` |


# TMS Tracking Place

```php
function tMSTrackingPlace(
    ?string $placeId = null,
    ?string $tag = null,
    ?string $ferrariBranch = null,
    ?string $placeCity = null,
    ?string $placeState = null,
    ?string $partnerBranch = null
): string
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `placeId` | `?string` | Query, Optional | - |
| `tag` | `?string` | Query, Optional | - |
| `ferrariBranch` | `?string` | Query, Optional | - |
| `placeCity` | `?string` | Query, Optional | - |
| `placeState` | `?string` | Query, Optional | - |
| `partnerBranch` | `?string` | Query, Optional | - |

## Response Type

`string`

## Example Usage

```php
$result = $tmsController->tMSTrackingPlace();
```

## Example Response

```
"{\n   \"_links\": {\n       \"self\": {\n           \"href\": \"/tms/tracking-place\"\n       },\n       \"first\": {\n           \"href\": \"/tms/tracking-place?page={page}\"\n       },\n       \"prev\": {\n           \"href\": \"/tms/tracking-place?page={page}\"\n       },\n       \"next\": {\n           \"href\": \"/tms/tracking-place?page={page}\"\n       },\n       \"last\": {\n           \"href\": \"/tms/tracking-place?page={page}\"\n       }\n   }\n   \"_embedded\": {\n       \"tracking_place\": [\n           {\n               \"_links\": {\n                   \"self\": {\n                       \"href\": \"/tms/tracking-place[/:tracking_place_id]\"\n                   }\n               }\n              \"place_id\": \"\",\n              \"place_name\": \"\",\n              \"place_address\": \"\",\n              \"place_city\": \"\",\n              \"place_state\": \"\",\n              \"place_country\": \"\",\n              \"ferrari_branch\": \"\",\n              \"partner_branch\": \"\",\n              \"tag\": \"\"\n           }\n       ]\n   }\n}"
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | `ApiException` |
| 403 | Forbidden | `ApiException` |
| 404 | Not Found | `ApiException` |
| 422 | Unprocessable entity | `ApiException` |


# TMS Return Status

```php
function tMSReturnStatus(?string $code = null, ?string $flowTag = null, ?string $type = null): string
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `code` | `?string` | Query, Optional | - |
| `flowTag` | `?string` | Query, Optional | - |
| `type` | `?string` | Query, Optional | - |

## Response Type

`string`

## Example Usage

```php
$result = $tmsController->tMSReturnStatus();
```

## Example Response

```
"{\n   \"_links\": {\n       \"self\": {\n           \"href\": \"/return-status\"\n       },\n       \"first\": {\n           \"href\": \"/return-status?page={page}\"\n       },\n       \"prev\": {\n           \"href\": \"/return-status?page={page}\"\n       },\n       \"next\": {\n           \"href\": \"/return-status?page={page}\"\n       },\n       \"last\": {\n           \"href\": \"/return-status?page={page}\"\n       }\n   }\n   \"_embedded\": {\n       \"return_status\": [\n           {\n               \"_links\": {\n                   \"self\": {\n                       \"href\": \"/return-status[/:return_status_id]\"\n                   }\n               }\n              \"code\": \"\",\n              \"description\": \"\",\n              \"flow_tag\": \"\",\n              \"type\": \"\",\n              \"id\": \"\"\n           }\n       ]\n   }\n}"
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | `ApiException` |
| 403 | Forbidden | `ApiException` |
| 404 | Not Found | `ApiException` |
| 422 | Unprocessable entity | `ApiException` |


# TMS Get Addresses

```php
function tMSGetAddresses(): string
```

## Response Type

`string`

## Example Usage

```php
$result = $tmsController->tMSGetAddresses();
```

## Example Response

```
"{\n    \"0\": {\n        \"id\": \"227613\",\n        \"companyname\": \"\",\n        \"address\": \"\",\n        \"city\": \"COMPANS\",\n        \"district\": \"\",\n        \"postalcode\": \"77290\",\n        \"statepro\": \"\",\n        \"country\": \"FR\",\n        \"phone\": \"\",\n        \"email\": \"\",\n        \"contact\": \"\",\n        \"code\": \"C009178303\"\n    },\n    \"1\": {\n        \"id\": \"227027\",\n        \"companyname\": \"\",\n        \"address\": \"\",\n        \"city\": \"\",\n        \"district\": \"\",\n        \"postalcode\": \"\",\n        \"statepro\": \"\",\n        \"country\": \"\",\n        \"phone\": \"\",\n        \"email\": \"\",\n        \"contact\": \"\",\n        \"code\": \"d41d8cd98f00b204e9800998ecf8427e\"\n    }\n}"
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | `ApiException` |
| 403 | Forbidden | `ApiException` |
| 404 | Not Found | `ApiException` |
| 422 | Unprocessable entity | `ApiException` |


# TMS Get Countires

```php
function tMSGetCountires(): string
```

## Response Type

`string`

## Example Usage

```php
$result = $tmsController->tMSGetCountires();
```

## Example Response

```
"{\n    \"0\": {\n        \"id\": \"1\",\n        \"F2\": \"AD\",\n        \"F1\": \"Andorra\"\n    },\n    \"1\": {\n        \"id\": \"2\",\n        \"F2\": \"AE\",\n        \"F1\": \"United Arab Emirates\"\n    },\n    \"2\": {\n        \"id\": \"3\",\n        \"F2\": \"AF\",\n        \"F1\": \"Afghanistan\"\n    },\n    \"3\": {\n        \"id\": \"4\",\n        \"F2\": \"AG\",\n        \"F1\": \"Antigua and Barbuda\"\n    }\n}"
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | `ApiException` |
| 403 | Forbidden | `ApiException` |
| 404 | Not Found | `ApiException` |
| 422 | Unprocessable entity | `ApiException` |


# TMS Add Address

```php
function tMSAddAddress(TMSAddress $params): Status
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `params` | [`TMSAddress`](../../doc/models/tms-address.md) | Body, Required | - |

## Response Type

[`Status`](../../doc/models/status.md)

## Example Usage

```php
$params_code = 'F123456';
$params_companyname = 'companyname8';
$params_address = 'address0';
$params_city = 'city6';
$params_country = 'IT';
$params = new Models\TMSAddress(
    $params_code,
    $params_companyname,
    $params_address,
    $params_city,
    $params_country
);

$result = $tmsController->tMSAddAddress($params);
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | `ApiException` |
| 403 | Forbidden | `ApiException` |
| 404 | Not Found | `ApiException` |
| 422 | Unprocessable entity | `ApiException` |


# TMS Shipment Add

```php
function tMSShipmentAdd(AddShipmentBody $params): string
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `params` | [`AddShipmentBody`](../../doc/models/add-shipment-body.md) | Body, Required | - |

## Response Type

`string`

## Example Usage

```php
$params_shipment_shipperCode = 'shipper-code6';
$params_shipment_consigneeCode = 'consignee-code2';
$params_shipment_orderNum = 'order_num0';
$params_shipment_timeActualPickup = 'time_actual_pickup6';
$params_shipment = new Models\AddShipmentShipdata(
    $params_shipment_shipperCode,
    $params_shipment_consigneeCode,
    $params_shipment_orderNum,
    $params_shipment_timeActualPickup
);
$params_parcels_seal = 'seal8';
$params_parcels = new Models\AddShipmentParceldata(
    $params_parcels_seal
);
$params_guard = 'guard8';
$params_truck = 'truck4';
$params_crewId = 'crew_id6';
$params = new Models\AddShipmentBody(
    $params_shipment,
    $params_parcels,
    $params_guard,
    $params_truck,
    $params_crewId
);

$result = $tmsController->tMSShipmentAdd($params);
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | `ApiException` |
| 403 | Forbidden | `ApiException` |
| 404 | Not Found | `ApiException` |
| 422 | Unprocessable entity | `ApiException` |


# TMS Geolocation

```php
function tMSGeolocation(Geolocation $params): void
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `params` | [`Geolocation`](../../doc/models/geolocation.md) | Body, Required | - |

## Response Type

`void`

## Example Usage

```php
$params_longitude = 'longitude8';
$params_latitude = 'latitude2';
$params_device = 'device0';
$params = new Models\Geolocation(
    $params_longitude,
    $params_latitude,
    $params_device
);

$tmsController->tMSGeolocation($params);
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | `ApiException` |
| 403 | Forbidden | `ApiException` |
| 404 | Not Found | `ApiException` |
| 422 | Unprocessable entity | `ApiException` |

