
# Order Numbers List

List of order numbers

## Structure

`OrderNumbersList`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `orderNumbers` | `string[]` | Required | - | getOrderNumbers(): array | setOrderNumbers(array orderNumbers): void |

## Example (as JSON)

```json
{
  "order_numbers": [
    "SHW12345678",
    "SHW12345679"
  ]
}
```

