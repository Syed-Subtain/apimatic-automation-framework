
# Attachment

File attached to the order request

## Structure

`Attachment`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `fileName` | `string` | Required | name of the file with extension<br>**Constraints**: *Maximum Length*: `50` | getFileName(): string | setFileName(string fileName): void |
| `fileDescription` | `?string` | Optional | description of the file attached<br>**Constraints**: *Maximum Length*: `30` | getFileDescription(): ?string | setFileDescription(?string fileDescription): void |
| `fileBase64` | `string` | Required | base64 encoded file data | getFileBase64(): string | setFileBase64(string fileBase64): void |

## Example (as JSON)

```json
{
  "file_name": "invoice_233123.pdf",
  "file_base64": null
}
```

