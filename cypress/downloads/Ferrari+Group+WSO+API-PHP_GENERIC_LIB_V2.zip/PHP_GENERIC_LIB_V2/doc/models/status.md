
# Status

Status of the order

## Structure

`Status`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `description` | [`string (StatusDescriptionEnum)`](../../doc/models/status-description-enum.md) | Required | Possible descriptions of the status of the shipping order | getDescription(): string | setDescription(string description): void |
| `trackingNumber` | `string` | Required | Tracking number<br>**Constraints**: *Maximum Length*: `25` | getTrackingNumber(): string | setTrackingNumber(string trackingNumber): void |
| `courier` | `string` | Required | Courier name<br>**Constraints**: *Maximum Length*: `25` | getCourier(): string | setCourier(string courier): void |
| `date` | `string` | Required | Date (YYYY-MM-DD) | getDate(): string | setDate(string date): void |
| `time` | `?string` | Optional | Time (hh:mm:ss) | getTime(): ?string | setTime(?string time): void |
| `notes` | `string` | Required | Additional info<br>**Constraints**: *Maximum Length*: `30` | getNotes(): string | setNotes(string notes): void |

## Example (as JSON)

```json
{
  "description": null,
  "tracking_number": "20MI1234567",
  "courier": "Ferrari",
  "date": "2020-05-20",
  "notes": "Delivered to John Doe"
}
```

