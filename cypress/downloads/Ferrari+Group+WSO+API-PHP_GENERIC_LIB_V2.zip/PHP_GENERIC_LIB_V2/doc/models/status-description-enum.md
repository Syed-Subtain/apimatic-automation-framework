
# Status Description Enum

Possible descriptions of the status of the shipping order

## Enumeration

`StatusDescriptionEnum`

## Fields

| Name |
|  --- |
| `ENUM_ORDER_RECEIVED` |
| `ENUM_PICKED_UP` |
| `ENUM_PROCESSING_BY_FERRARI` |
| `SHIPPED` |
| `ENUM_IN_TRANSIT` |
| `ENUM_OUT_FOR_DELIVERY` |
| `DELIVERED` |
| `CANCELLED` |
| `ENTRUSTED_TO_3P_INTEGRATOR` |

