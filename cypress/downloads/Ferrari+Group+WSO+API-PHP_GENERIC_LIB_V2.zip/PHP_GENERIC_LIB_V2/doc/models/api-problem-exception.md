
# Api Problem Exception

## Structure

`ApiProblemException`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `type` | `string` | Required | A URI reference [RFC3986] that identifies the problem type | getType(): string | setType(string type): void |
| `title` | `string` | Required | A short, human-readable summary of the problem type. | getTitle(): string | setTitle(string title): void |
| `status` | `int` | Required | The HTTP status code | getStatus(): int | setStatus(int status): void |
| `detail` | `string` | Required | A human-readable explanation specific to this occurrence of the problem | getDetail(): string | setDetail(string detail): void |

## Example (as JSON)

```json
{
  "type": "http://www.w3.org/Protocols/rfc2616/rfc2616-sec10.html",
  "title": "Unprocessable entity",
  "status": 422,
  "detail": "Failed validation"
}
```

