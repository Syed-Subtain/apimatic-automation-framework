
# Get Laber Response

Base 64 labels

## Structure

`GetLaberResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `base64Labels` | `string` | Required | base64 encoded labels | getBase64Labels(): string | setBase64Labels(string base64Labels): void |

## Example (as JSON)

```json
{
  "base64_labels": "base64_labels8"
}
```

