
# Order Address

Party Address information

## Structure

`OrderAddress`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `code` | `?string` | Optional | Party Code<br>**Constraints**: *Maximum Length*: `20` | getCode(): ?string | setCode(?string code): void |
| `name` | `string` | Required | Party Name (legal entity for companies, full name for private)<br>**Constraints**: *Maximum Length*: `45` | getName(): string | setName(string name): void |
| `address` | `string` | Required | Party Full Address<br>**Constraints**: *Maximum Length*: `255` | getAddress(): string | setAddress(string address): void |
| `city` | `string` | Required | Party City<br>**Constraints**: *Maximum Length*: `45` | getCity(): string | setCity(string city): void |
| `zipCode` | `?string` | Optional | Party ZipCode<br>**Constraints**: *Maximum Length*: `15` | getZipCode(): ?string | setZipCode(?string zipCode): void |
| `state` | `?string` | Optional | Party State/Province<br>**Constraints**: *Maximum Length*: `2` | getState(): ?string | setState(?string state): void |
| `area` | `?string` | Optional | Party Area/District<br>**Constraints**: *Maximum Length*: `30` | getArea(): ?string | setArea(?string area): void |
| `country` | `string` | Required | Party Country (ISO 3166-1 alpha-2)<br>**Constraints**: *Maximum Length*: `2` | getCountry(): string | setCountry(string country): void |
| `contact` | `?string` | Optional | Party Contact<br>**Constraints**: *Maximum Length*: `45` | getContact(): ?string | setContact(?string contact): void |
| `phone` | `?string` | Optional | Party Phone<br>**Constraints**: *Maximum Length*: `20` | getPhone(): ?string | setPhone(?string phone): void |
| `email` | `?string` | Optional | Party email<br>**Constraints**: *Maximum Length*: `50` | getEmail(): ?string | setEmail(?string email): void |
| `notes` | `?string` | Optional | Party notes | getNotes(): ?string | setNotes(?string notes): void |
| `kcNumber` | `?string` | Optional | Known consignor number | getKcNumber(): ?string | setKcNumber(?string kcNumber): void |
| `eori` | `?string` | Optional | EORI  - Economic Operator Registration and Identification (for EU) | getEori(): ?string | setEori(?string eori): void |

## Example (as JSON)

```json
{
  "name": "Cartwright-Simonis",
  "address": "1600 Pennsylvania Avenue",
  "city": "Lisbon",
  "country": "DE"
}
```

