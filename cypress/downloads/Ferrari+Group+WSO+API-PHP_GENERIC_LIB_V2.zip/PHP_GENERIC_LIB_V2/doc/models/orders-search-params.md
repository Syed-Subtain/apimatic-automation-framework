
# Orders Search Params

Shipping orders search parameters

## Structure

`OrdersSearchParams`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `page` | `?int` | Optional | Number of the page request in the collection<br>**Default**: `1` | getPage(): ?int | setPage(?int page): void |
| `orderDateFrom` | `?string` | Optional | Starting order date (YYYY-MM-DD) | getOrderDateFrom(): ?string | setOrderDateFrom(?string orderDateFrom): void |
| `orderDateTo` | `?string` | Optional | Ending order date (YYYY-MM-DD) | getOrderDateTo(): ?string | setOrderDateTo(?string orderDateTo): void |
| `confirmed` | `?string` | Optional | Y -> only confirmed, 'N' -> to be confirmed, everything otherwise<br>**Default**: `'\'Y\''` | getConfirmed(): ?string | setConfirmed(?string confirmed): void |
| `confirmedDatetimeFrom` | `?string` | Optional | Starting confirmation date/time (YYYY-MM-DD hh:mm:ss) | getConfirmedDatetimeFrom(): ?string | setConfirmedDatetimeFrom(?string confirmedDatetimeFrom): void |
| `confirmedDatetimeTo` | `?string` | Optional | Ending confirmation date/time (YYYY-MM-DD hh:mm:ss) | getConfirmedDatetimeTo(): ?string | setConfirmedDatetimeTo(?string confirmedDatetimeTo): void |

## Example (as JSON)

```json
{
  "page": null,
  "order_date_from": null,
  "order_date_to": null,
  "confirmed": null,
  "confirmed_datetime_from": null,
  "confirmed_datetime_to": null
}
```

