
# Shipment Prealert Request

## Structure

`ShipmentPrealertRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `recipients` | `string[]` | Required | Collection of e-mail addresses of the recipients of the prealert | getRecipients(): array | setRecipients(array recipients): void |
| `includeAttachments` | `?string` | Optional | The prealert should contain the documents attached to the order (Y/N)<br>**Constraints**: *Maximum Length*: `1` | getIncludeAttachments(): ?string | setIncludeAttachments(?string includeAttachments): void |

## Example (as JSON)

```json
{
  "recipients": [
    "john@example.com",
    "mary@example.com"
  ]
}
```

