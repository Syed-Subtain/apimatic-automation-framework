
# Groupage Number

Groupage number

## Structure

`GroupageNumber`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `number` | `string` | Required | Groupage number | getNumber(): string | setNumber(string number): void |

## Example (as JSON)

```json
{
  "number": "GR12345678"
}
```

