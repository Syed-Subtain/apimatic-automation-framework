
# O Auth Scope Enum

OAuth 2 scopes supported by the API

## Enumeration

`OAuthScopeEnum`

## Fields

| Name | Description |
|  --- | --- |
| `WSO_CREATEORDER` | Order creation permission |
| `WSO_GETORDER` | Order retrieval permission |
| `WSO_UPDATEORDER` | Order update permission |
| `WSO_DELETEORDER` | Order deletion permission |
| `WSO_SEARCHORDERS` | Search for orders permission |
| `WSO_PRINTORDER` | Order print permission |
| `WSO_CREATEPICKUPMANIFEST` | Pickup manifest creation permission |
| `WSO_DELETEPICKUPMANIFEST` | Pickup manifest deletion permission |
| `WSO_PRINTPICKUPMANIFEST` | Pickup manifest print permission |
| `WSO_GETLABEL` | Print parcels label |
| `WSO_CREATEGROUPAGE` | Groupage creation permission |
| `WSO_DELETEGROUPAGE` | Groupage deletion permission |

