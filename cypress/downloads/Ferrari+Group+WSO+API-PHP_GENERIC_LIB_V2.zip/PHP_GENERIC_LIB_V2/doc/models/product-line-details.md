
# Product Line Details

Product Line Details

## Structure

`ProductLineDetails`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `productCode` | `string` | Required | Product  / Material Number<br>**Constraints**: *Maximum Length*: `25` | getProductCode(): string | setProductCode(string productCode): void |
| `productDescription` | `string` | Required | Product description<br>**Constraints**: *Maximum Length*: `70` | getProductDescription(): string | setProductDescription(string productDescription): void |
| `reference` | `?string` | Optional | Additional information<br>**Constraints**: *Maximum Length*: `20` | getReference(): ?string | setReference(?string reference): void |
| `quantity` | `int` | Required | Quantity | getQuantity(): int | setQuantity(int quantity): void |
| `customsCode` | `?string` | Optional | Customs Code<br>**Constraints**: *Maximum Length*: `16` | getCustomsCode(): ?string | setCustomsCode(?string customsCode): void |
| `isCites` | `?string` | Optional | Cites (Y/N)<br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1` | getIsCites(): ?string | setIsCites(?string isCites): void |
| `isMop` | `?string` | Optional | Mother Of Pearl (Y/N)<br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1` | getIsMop(): ?string | setIsMop(?string isMop): void |
| `isHallmarking` | `?string` | Optional | Hallmarking required (Y/N)<br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1` | getIsHallmarking(): ?string | setIsHallmarking(?string isHallmarking): void |
| `isSaber` | `?string` | Optional | SABER certification required (Y/N) | getIsSaber(): ?string | setIsSaber(?string isSaber): void |
| `originCountry` | `?string` | Optional | Goods origin country<br>**Constraints**: *Minimum Length*: `2`, *Maximum Length*: `2` | getOriginCountry(): ?string | setOriginCountry(?string originCountry): void |
| `productValue` | `?float` | Optional | Product value<br>**Constraints**: *Total Digits*: `11`, *Fraction Digits*: `2` | getProductValue(): ?float | setProductValue(?float productValue): void |
| `productValueCurrency` | `?string` | Optional | Product value currency<br>**Constraints**: *Maximum Length*: `3` | getProductValueCurrency(): ?string | setProductValueCurrency(?string productValueCurrency): void |
| `netWeight` | `?float` | Optional | Product Net Weight | getNetWeight(): ?float | setNetWeight(?float netWeight): void |
| `netWeightUnit` | `?string` | Optional | Unit of measure for net weight (grams or carats) (g, ct)<br>**Default**: `'g'` | getNetWeightUnit(): ?string | setNetWeightUnit(?string netWeightUnit): void |
| `barcode` | `?string` | Optional | Barcoded key to identify the parcel<br>**Constraints**: *Maximum Length*: `20` | getBarcode(): ?string | setBarcode(?string barcode): void |
| `additionalInfo1` | `?string` | Optional | Additional info (1) | getAdditionalInfo1(): ?string | setAdditionalInfo1(?string additionalInfo1): void |
| `additionalInfo2` | `?string` | Optional | Additional info (2) | getAdditionalInfo2(): ?string | setAdditionalInfo2(?string additionalInfo2): void |
| `additionalInfo3` | `?string` | Optional | Additional info (3) | getAdditionalInfo3(): ?string | setAdditionalInfo3(?string additionalInfo3): void |

## Example (as JSON)

```json
{
  "product_code": null,
  "product_description": null,
  "quantity": 10
}
```

