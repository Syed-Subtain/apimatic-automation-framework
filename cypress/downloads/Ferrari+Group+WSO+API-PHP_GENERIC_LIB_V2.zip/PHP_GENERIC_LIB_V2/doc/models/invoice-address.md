
# Invoice Address

Party Address information

## Structure

`InvoiceAddress`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `code` | `?string` | Optional | Party Code<br>**Constraints**: *Maximum Length*: `20` | getCode(): ?string | setCode(?string code): void |
| `name` | `string` | Required | Party Name (Legal Entity)<br>**Constraints**: *Maximum Length*: `45` | getName(): string | setName(string name): void |
| `address` | `string` | Required | Party Address<br>**Constraints**: *Maximum Length*: `255` | getAddress(): string | setAddress(string address): void |
| `city` | `string` | Required | Party City<br>**Constraints**: *Maximum Length*: `45` | getCity(): string | setCity(string city): void |
| `zipCode` | `?string` | Optional | Party ZipCode<br>**Constraints**: *Maximum Length*: `15` | getZipCode(): ?string | setZipCode(?string zipCode): void |
| `state` | `?string` | Optional | Party State/Province<br>**Constraints**: *Maximum Length*: `2` | getState(): ?string | setState(?string state): void |
| `area` | `?string` | Optional | Party area/district<br>**Constraints**: *Maximum Length*: `30` | getArea(): ?string | setArea(?string area): void |
| `country` | `string` | Required | Party Country (ISO 3166-1 alpha-2)<br>**Constraints**: *Maximum Length*: `2` | getCountry(): string | setCountry(string country): void |
| `contact` | `?string` | Optional | Party Contact<br>**Constraints**: *Maximum Length*: `45` | getContact(): ?string | setContact(?string contact): void |
| `phone` | `?string` | Optional | Party Phone<br>**Constraints**: *Maximum Length*: `20` | getPhone(): ?string | setPhone(?string phone): void |
| `email` | `?string` | Optional | Party email<br>**Constraints**: *Maximum Length*: `50` | getEmail(): ?string | setEmail(?string email): void |
| `vatNumber` | `?string` | Optional | VAT Registration Number<br>**Constraints**: *Maximum Length*: `20` | getVatNumber(): ?string | setVatNumber(?string vatNumber): void |

## Example (as JSON)

```json
{
  "name": "Cartwright-Simonis",
  "address": "1600 Pennsylvania Avenue",
  "city": "Lisbon",
  "country": "DE"
}
```

