
# Pickup Manifest Number

Pickup manifest number

## Structure

`PickupManifestNumber`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `number` | `string` | Required | Pickup manifest number | getNumber(): string | setNumber(string number): void |

## Example (as JSON)

```json
{
  "number": "PM12345678"
}
```

