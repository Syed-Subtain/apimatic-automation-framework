
# Order Parcel

Parcel information

## Structure

`OrderParcel`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `dim1` | `?float` | Optional | Dimension 1 | getDim1(): ?float | setDim1(?float dim1): void |
| `dim2` | `?float` | Optional | Dimension 2 | getDim2(): ?float | setDim2(?float dim2): void |
| `dim3` | `?float` | Optional | Dimension 3 | getDim3(): ?float | setDim3(?float dim3): void |
| `dimensionUnit` | `?string` | Optional | Unit of measure for dimension (cm/in)<br>**Default**: `'cm'`<br>**Constraints**: *Maximum Length*: `2` | getDimensionUnit(): ?string | setDimensionUnit(?string dimensionUnit): void |
| `grossWeight` | `float` | Required | Parcel Weight | getGrossWeight(): float | setGrossWeight(float grossWeight): void |
| `grossWeightUnit` | `string` | Required | unit of measure for gross weight (Kg, lb)<br>**Default**: `'Kg'`<br>**Constraints**: *Maximum Length*: `2` | getGrossWeightUnit(): string | setGrossWeightUnit(string grossWeightUnit): void |
| `value` | `?float` | Optional | Parcel Value (currency is specified in Order)<br>**Constraints**: *Total Digits*: `11`, *Fraction Digits*: `2` | getValue(): ?float | setValue(?float value): void |
| `seals` | `?string` | Optional | Parcel Seals<br>**Constraints**: *Maximum Length*: `30` | getSeals(): ?string | setSeals(?string seals): void |
| `marks` | `?string` | Optional | Parcel Marks<br>**Constraints**: *Maximum Length*: `30` | getMarks(): ?string | setMarks(?string marks): void |
| `description` | `?string` | Optional | Goods Description<br>**Constraints**: *Maximum Length*: `50` | getDescription(): ?string | setDescription(?string description): void |
| `productDetails` | [`?(ProductLineDetails[])`](../../doc/models/product-line-details.md) | Optional | product details for customs scope | getProductDetails(): ?array | setProductDetails(?array productDetails): void |
| `barcode` | `?string` | Optional | Barcoded key to identifiy the parcel<br>**Constraints**: *Maximum Length*: `20` | getBarcode(): ?string | setBarcode(?string barcode): void |

## Example (as JSON)

```json
{
  "gross_weight": 3.79,
  "gross_weight_unit": "lb"
}
```

