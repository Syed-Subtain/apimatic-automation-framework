
# Invoice

## Structure

`Invoice`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `number` | `string` | Required | Invoice Number<br>**Constraints**: *Maximum Length*: `20` | getNumber(): string | setNumber(string number): void |
| `date` | `string` | Required | format (YYYY-MM-DD) | getDate(): string | setDate(string date): void |
| `type` | `?string` | Optional | commercial, pro-forma, etc. etc.<br>**Constraints**: *Maximum Length*: `15` | getType(): ?string | setType(?string type): void |
| `value` | `float` | Required | Invoice Value<br>**Constraints**: *Total Digits*: `11`, *Fraction Digits*: `2` | getValue(): float | setValue(float value): void |
| `currency` | `string` | Required | Invoice Currency<br>**Constraints**: *Minimum Length*: `3`, *Maximum Length*: `3` | getCurrency(): string | setCurrency(string currency): void |
| `issuer` | [`InvoiceAddress`](../../doc/models/invoice-address.md) | Required | Party Address information | getIssuer(): InvoiceAddress | setIssuer(InvoiceAddress issuer): void |
| `fiscalAgent` | [`?InvoiceAddress`](../../doc/models/invoice-address.md) | Optional | Party Address information | getFiscalAgent(): ?InvoiceAddress | setFiscalAgent(?InvoiceAddress fiscalAgent): void |
| `billTo` | [`InvoiceAddress`](../../doc/models/invoice-address.md) | Required | Party Address information | getBillTo(): InvoiceAddress | setBillTo(InvoiceAddress billTo): void |
| `shipTo` | [`OrderAddress`](../../doc/models/order-address.md) | Required | Party Address information | getShipTo(): OrderAddress | setShipTo(OrderAddress shipTo): void |
| `details` | [`?(ProductLineDetails[])`](../../doc/models/product-line-details.md) | Optional | Invoice details | getDetails(): ?array | setDetails(?array details): void |

## Example (as JSON)

```json
{
  "number": "100200",
  "date": "2020-01-12",
  "value": 12000,
  "currency": "EUR",
  "issuer": {
    "name": "Cartwright-Simonis",
    "address": "1600 Pennsylvania Avenue",
    "city": "Lisbon",
    "country": "DE"
  },
  "bill_to": {
    "name": "Cartwright-Simonis",
    "address": "1600 Pennsylvania Avenue",
    "city": "Lisbon",
    "country": "DE"
  },
  "ship_to": {
    "name": "Cartwright-Simonis",
    "address": "1600 Pennsylvania Avenue",
    "city": "Lisbon",
    "country": "DE"
  }
}
```

