
# Orders Collection

Paginated collection of shipping orders

## Structure

`OrdersCollection`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `orders` | [`OrderOutput[]`](../../doc/models/order-output.md) | Required | Shipping orders details for the current page in the collection | getOrders(): array | setOrders(array orders): void |
| `pageCount` | `int` | Required | Number of total pages in the collection | getPageCount(): int | setPageCount(int pageCount): void |
| `pageSize` | `int` | Required | Number of orders in each page | getPageSize(): int | setPageSize(int pageSize): void |
| `totalItems` | `int` | Required | Number of the shipping orders in the collection | getTotalItems(): int | setTotalItems(int totalItems): void |
| `page` | `int` | Required | Current page of the collection | getPage(): int | setPage(int page): void |

## Example (as JSON)

```json
{
  "orders": {
    "number": "SHW12345678",
    "date": "2020-05-20",
    "consignor_address": {
      "name": "Cartwright-Simonis",
      "address": "1600 Pennsylvania Avenue",
      "city": "Lisbon",
      "country": "DE"
    },
    "consignee_address": {
      "name": "Cartwright-Simonis",
      "address": "1600 Pennsylvania Avenue",
      "city": "Lisbon",
      "country": "DE"
    },
    "insured": "Y",
    "service": "STD",
    "confirmed": "Y",
    "pickup_date": "2020-05-22",
    "parcels": {
      "gross_weight": 3.79,
      "gross_weight_unit": "lb"
    },
    "statuses": {
      "description": null,
      "tracking_number": "20MI1234567",
      "courier": "Ferrari",
      "date": "2020-05-20",
      "notes": "Delivered to John Doe"
    },
    "confirmed_datetime": "2020-11-10 16:15:12"
  },
  "page_count": 3,
  "page_size": 10,
  "total_items": 45,
  "page": 2
}
```

