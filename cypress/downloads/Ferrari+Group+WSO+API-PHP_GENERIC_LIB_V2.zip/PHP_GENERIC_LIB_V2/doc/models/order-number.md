
# Order Number

Shipping order number

## Structure

`OrderNumber`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `number` | `string` | Required | Shipping order number<br>**Constraints**: *Maximum Length*: `15` | getNumber(): string | setNumber(string number): void |

## Example (as JSON)

```json
{
  "number": "SHW12345678"
}
```

