
# Order Output

Shipping order information

## Structure

`OrderOutput`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `number` | `string` | Required | Ferrari shipping order number<br>**Constraints**: *Maximum Length*: `15` | getNumber(): string | setNumber(string number): void |
| `date` | `string` | Required | Date (YYYY-MM-DD) | getDate(): string | setDate(string date): void |
| `customerRefNo` | `?string` | Optional | Customer Reference<br>**Constraints**: *Maximum Length*: `20` | getCustomerRefNo(): ?string | setCustomerRefNo(?string customerRefNo): void |
| `consignorAddress` | [`OrderAddress`](../../doc/models/order-address.md) | Required | Party Address information | getConsignorAddress(): OrderAddress | setConsignorAddress(OrderAddress consignorAddress): void |
| `pickupAddress` | [`?OrderAddress`](../../doc/models/order-address.md) | Optional | Party Address information | getPickupAddress(): ?OrderAddress | setPickupAddress(?OrderAddress pickupAddress): void |
| `consigneeAddress` | [`OrderAddress`](../../doc/models/order-address.md) | Required | Party Address information | getConsigneeAddress(): OrderAddress | setConsigneeAddress(OrderAddress consigneeAddress): void |
| `deliveryAddress` | [`?OrderAddress`](../../doc/models/order-address.md) | Optional | Party Address information | getDeliveryAddress(): ?OrderAddress | setDeliveryAddress(?OrderAddress deliveryAddress): void |
| `incoterm` | `?string` | Optional | Incoterm<br>**Constraints**: *Maximum Length*: `3` | getIncoterm(): ?string | setIncoterm(?string incoterm): void |
| `ataCarnetNo` | `?string` | Optional | ATA Carnet No.<br>**Constraints**: *Maximum Length*: `20` | getAtaCarnetNo(): ?string | setAtaCarnetNo(?string ataCarnetNo): void |
| `citesNo` | `?string` | Optional | Cites Certificate No.<br>**Constraints**: *Maximum Length*: `20` | getCitesNo(): ?string | setCitesNo(?string citesNo): void |
| `kimberlyNo` | `?string` | Optional | Kimberly Certificate No.<br>**Constraints**: *Maximum Length*: `20` | getKimberlyNo(): ?string | setKimberlyNo(?string kimberlyNo): void |
| `mop` | `?string` | Optional | Orders include Mother of Pearls product (Y/N) | getMop(): ?string | setMop(?string mop): void |
| `hallmarking` | `?string` | Optional | Order includes products that require hallmarking (Y/N) | getHallmarking(): ?string | setHallmarking(?string hallmarking): void |
| `saber` | `?string` | Optional | Order includes products that require SABER certification (Y/N) | getSaber(): ?string | setSaber(?string saber): void |
| `insured` | `string` | Required | Describe if insured by Ferrari (values: Y/N) | getInsured(): string | setInsured(string insured): void |
| `insuredValue` | `?float` | Optional | Insured value | getInsuredValue(): ?float | setInsuredValue(?float insuredValue): void |
| `cargoValue` | `?float` | Optional | Shipment value | getCargoValue(): ?float | setCargoValue(?float cargoValue): void |
| `currency` | `?string` | Optional | Currency of the values specified in the request<br>**Constraints**: *Maximum Length*: `3` | getCurrency(): ?string | setCurrency(?string currency): void |
| `instructions` | `?string` | Optional | Special instructions and notes | getInstructions(): ?string | setInstructions(?string instructions): void |
| `service` | `string` | Required | Service type code (STD)<br>**Constraints**: *Maximum Length*: `3` | getService(): string | setService(string service): void |
| `confirmed` | `string` | Required | Order confirmed (values: Y/N). If confirmed=Y, no further modifications will be allowed<br>**Constraints**: *Maximum Length*: `1` | getConfirmed(): string | setConfirmed(string confirmed): void |
| `pickupDate` | `string` | Required | Date the pickup is requested for (format YYYY-MM-DD) | getPickupDate(): string | setPickupDate(string pickupDate): void |
| `pickupTime` | `?string` | Optional | Time the pickup is requested for (format hh:mm) | getPickupTime(): ?string | setPickupTime(?string pickupTime): void |
| `parcels` | [`OrderParcel[]`](../../doc/models/order-parcel.md) | Required | Parcels array | getParcels(): array | setParcels(array parcels): void |
| `statuses` | [`Status[]`](../../doc/models/status.md) | Required | Details of alla the statuses the order has changed | getStatuses(): array | setStatuses(array statuses): void |
| `attachments` | [`?(Attachment[])`](../../doc/models/attachment.md) | Optional | documents attached to the order request | getAttachments(): ?array | setAttachments(?array attachments): void |
| `options` | `?string` | Optional | Serialized key=>value array to be defined for each customer | getOptions(): ?string | setOptions(?string options): void |
| `confirmedDatetime` | `string` | Required | confirmation timestamp (YYYY-MM-DD hh:mm:ss)<br>**Constraints**: *Minimum Length*: `19`, *Maximum Length*: `19` | getConfirmedDatetime(): string | setConfirmedDatetime(string confirmedDatetime): void |
| `customerCode` | `?string` | Optional | Customer code | getCustomerCode(): ?string | setCustomerCode(?string customerCode): void |
| `costCenter` | `?string` | Optional | Cost center | getCostCenter(): ?string | setCostCenter(?string costCenter): void |
| `dangerousGoods` | `?string` | Optional | Order contains dangerous goods (Y/N) | getDangerousGoods(): ?string | setDangerousGoods(?string dangerousGoods): void |
| `secureCargo` | `?string` | Optional | Secure cargo (Y/N) | getSecureCargo(): ?string | setSecureCargo(?string secureCargo): void |
| `customs` | `?string` | Optional | Customs operation description | getCustoms(): ?string | setCustoms(?string customs): void |

## Example (as JSON)

```json
{
  "number": "SHW12345678",
  "date": "2020-05-20",
  "consignor_address": {
    "name": "Cartwright-Simonis",
    "address": "1600 Pennsylvania Avenue",
    "city": "Lisbon",
    "country": "DE"
  },
  "consignee_address": {
    "name": "Cartwright-Simonis",
    "address": "1600 Pennsylvania Avenue",
    "city": "Lisbon",
    "country": "DE"
  },
  "insured": "Y",
  "service": "STD",
  "confirmed": "Y",
  "pickup_date": "2020-05-22",
  "parcels": {
    "gross_weight": 3.79,
    "gross_weight_unit": "lb"
  },
  "statuses": {
    "description": null,
    "tracking_number": "20MI1234567",
    "courier": "Ferrari",
    "date": "2020-05-20",
    "notes": "Delivered to John Doe"
  },
  "confirmed_datetime": "2020-11-10 16:15:12"
}
```

