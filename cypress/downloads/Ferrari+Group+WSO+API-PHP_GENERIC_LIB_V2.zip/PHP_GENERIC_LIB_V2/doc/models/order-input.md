
# Order Input

Shipping order information for creation

## Structure

`OrderInput`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `customerRefNo` | `?string` | Optional | Customer Reference<br>**Constraints**: *Maximum Length*: `20` | getCustomerRefNo(): ?string | setCustomerRefNo(?string customerRefNo): void |
| `consignorAddress` | [`OrderAddress`](../../doc/models/order-address.md) | Required | Party Address information | getConsignorAddress(): OrderAddress | setConsignorAddress(OrderAddress consignorAddress): void |
| `pickupAddress` | [`?OrderAddress`](../../doc/models/order-address.md) | Optional | Party Address information | getPickupAddress(): ?OrderAddress | setPickupAddress(?OrderAddress pickupAddress): void |
| `consigneeAddress` | [`OrderAddress`](../../doc/models/order-address.md) | Required | Party Address information | getConsigneeAddress(): OrderAddress | setConsigneeAddress(OrderAddress consigneeAddress): void |
| `deliveryAddress` | [`?OrderAddress`](../../doc/models/order-address.md) | Optional | Party Address information | getDeliveryAddress(): ?OrderAddress | setDeliveryAddress(?OrderAddress deliveryAddress): void |
| `incoterm` | `?string` | Optional | Incoterm<br>**Constraints**: *Maximum Length*: `3` | getIncoterm(): ?string | setIncoterm(?string incoterm): void |
| `ataCarnetNo` | `?string` | Optional | Ata Carnet No. related to the order if available, otherwise information if the order include Carnet Ata. (Y/N)<br>**Constraints**: *Maximum Length*: `20` | getAtaCarnetNo(): ?string | setAtaCarnetNo(?string ataCarnetNo): void |
| `citesNo` | `?string` | Optional | Cites Certificate No. included in the order if available, otherwise information if the order contains products requiring Cites certificate (Y/N)<br>**Constraints**: *Maximum Length*: `20` | getCitesNo(): ?string | setCitesNo(?string citesNo): void |
| `kimberlyNo` | `?string` | Optional | Kimbelry Certificate No. included in the order if available, otherwise information if the order contains products requiring Kimberly certificate (Y/N)<br>**Constraints**: *Maximum Length*: `20` | getKimberlyNo(): ?string | setKimberlyNo(?string kimberlyNo): void |
| `mop` | `?string` | Optional | Orders include Mother of Pearls product (Y/N) | getMop(): ?string | setMop(?string mop): void |
| `hallmarking` | `?string` | Optional | Order includes products that require hallmarking (Y/N) | getHallmarking(): ?string | setHallmarking(?string hallmarking): void |
| `saber` | `?string` | Optional | Order includes products that require SABER certification (Y/N) | getSaber(): ?string | setSaber(?string saber): void |
| `insured` | `string` | Required | Describe if insured by Ferrari (values: Y/N)<br>**Constraints**: *Maximum Length*: `1` | getInsured(): string | setInsured(string insured): void |
| `insuredValue` | `?float` | Optional | Insured value<br>**Constraints**: *Total Digits*: `13`, *Fraction Digits*: `2` | getInsuredValue(): ?float | setInsuredValue(?float insuredValue): void |
| `cargoValue` | `?float` | Optional | Shipment value<br>**Constraints**: *Total Digits*: `13`, *Fraction Digits*: `2` | getCargoValue(): ?float | setCargoValue(?float cargoValue): void |
| `currency` | `?string` | Optional | Currency of the values specified in the request<br>**Constraints**: *Maximum Length*: `3` | getCurrency(): ?string | setCurrency(?string currency): void |
| `instructions` | `?string` | Optional | Special instructions and notes | getInstructions(): ?string | setInstructions(?string instructions): void |
| `service` | `string` | Required | Service type code requested. The service codes available depend on the country of pickup. Please ask for a list of valid codes<br>**Constraints**: *Maximum Length*: `3` | getService(): string | setService(string service): void |
| `confirmed` | `string` | Required | Order confirmed (values: Y/N). If confirmed=Y, no further modifications will be allowed<br>**Constraints**: *Maximum Length*: `1` | getConfirmed(): string | setConfirmed(string confirmed): void |
| `pickupDate` | `string` | Required | Date the pickup is requested for (format YYYY-MM-DD) | getPickupDate(): string | setPickupDate(string pickupDate): void |
| `pickupTime` | `?string` | Optional | Time the pickup is requested for (format hh:mm) | getPickupTime(): ?string | setPickupTime(?string pickupTime): void |
| `parcels` | [`OrderParcel[]`](../../doc/models/order-parcel.md) | Required | Parcels array | getParcels(): array | setParcels(array parcels): void |
| `invoices` | [`?(Invoice[])`](../../doc/models/invoice.md) | Optional | Invoices Details | getInvoices(): ?array | setInvoices(?array invoices): void |
| `options` | `?string` | Optional | Seriallized key=>value array to be defined for each customer<br>**Constraints**: *Maximum Length*: `200` | getOptions(): ?string | setOptions(?string options): void |
| `attachments` | [`?(Attachment[])`](../../doc/models/attachment.md) | Optional | documents attached to the order request | getAttachments(): ?array | setAttachments(?array attachments): void |
| `deliveries` | `?(string[])` | Optional | collection of customer delivery/order numbers<br>**Constraints**: *Maximum Length*: `20` | getDeliveries(): ?array | setDeliveries(?array deliveries): void |
| `shipmentPrealert` | [`?ShipmentPrealertRequest`](../../doc/models/shipment-prealert-request.md) | Optional | This element enables the automatic sending of a pre-alert via email when the shipment is performed | getShipmentPrealert(): ?ShipmentPrealertRequest | setShipmentPrealert(?ShipmentPrealertRequest shipmentPrealert): void |

## Example (as JSON)

```json
{
  "consignor_address": {
    "name": "Cartwright-Simonis",
    "address": "1600 Pennsylvania Avenue",
    "city": "Lisbon",
    "country": "DE"
  },
  "consignee_address": {
    "name": "Cartwright-Simonis",
    "address": "1600 Pennsylvania Avenue",
    "city": "Lisbon",
    "country": "DE"
  },
  "insured": "Y",
  "service": "STD",
  "confirmed": "Y",
  "pickup_date": "2020-05-22",
  "parcels": {
    "gross_weight": 3.79,
    "gross_weight_unit": "lb"
  }
}
```

