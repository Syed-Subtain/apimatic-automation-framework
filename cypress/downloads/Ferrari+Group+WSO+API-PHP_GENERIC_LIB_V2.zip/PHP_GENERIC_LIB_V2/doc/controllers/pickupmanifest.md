# Pickupmanifest

```php
$pickupmanifestController = $client->getPickupmanifestController();
```

## Class Name

`PickupmanifestController`

## Methods

* [Create Pickup Manifest](../../doc/controllers/pickupmanifest.md#create-pickup-manifest)
* [Delete Pickup Manifest](../../doc/controllers/pickupmanifest.md#delete-pickup-manifest)
* [Print Pickup Manifest](../../doc/controllers/pickupmanifest.md#print-pickup-manifest)


# Create Pickup Manifest

Allows to create a pickup manifest containing one or more shipping orders

```php
function createPickupManifest(OrderNumbersList $orderNumbers): PickupManifestNumber
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `orderNumbers` | [`OrderNumbersList`](../../doc/models/order-numbers-list.md) | Body, Required | - |

## Requires scope

`WSO_CREATEPICKUPMANIFEST`

## Response Type

[`PickupManifestNumber`](../../doc/models/pickup-manifest-number.md)

## Example Usage

```php
$orderNumbers_orderNumbers = ['SHW12345678', 'SHW12345679'];
$orderNumbers = new Models\OrderNumbersList(
    $orderNumbers_orderNumbers
);

$result = $pickupManifestController->createPickupManifest($orderNumbers);
```

## Example Response *(as JSON)*

```json
{
  "number": "PM12345678"
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 409 | Conflict | [`ApiProblemException`](../../doc/models/api-problem-exception.md) |
| 422 | Unprocessable entity | [`ApiProblemException`](../../doc/models/api-problem-exception.md) |
| Default | Bad Request | [`ApiProblemException`](../../doc/models/api-problem-exception.md) |


# Delete Pickup Manifest

Allows to cancel a pickup manifest

```php
function deletePickupManifest(PickupManifestNumber $number): void
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `number` | [`PickupManifestNumber`](../../doc/models/pickup-manifest-number.md) | Body, Required | Number of the pickup manifest to delete |

## Requires scope

`WSO_DELETEPICKUPMANIFEST`

## Response Type

`void`

## Example Usage

```php
$number_number = 'PM12345678';
$number = new Models\PickupManifestNumber(
    $number_number
);

$pickupManifestController->deletePickupManifest($number);
```


# Print Pickup Manifest

Returns the print of the pickup manifest in pdf format

```php
function printPickupManifest(PickupManifestNumber $number): Attachment
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `number` | [`PickupManifestNumber`](../../doc/models/pickup-manifest-number.md) | Body, Required | Number of the pickup manifest to print |

## Requires scope

`WSO_PRINTPICKUPMANIFEST`

## Response Type

[`Attachment`](../../doc/models/attachment.md)

## Example Usage

```php
$number_number = 'PM12345678';
$number = new Models\PickupManifestNumber(
    $number_number
);

$result = $pickupManifestController->printPickupManifest($number);
```

