# Groupage

```php
$groupageController = $client->getGroupageController();
```

## Class Name

`GroupageController`

## Methods

* [Create Groupage](../../doc/controllers/groupage.md#create-groupage)
* [Delete Groupage](../../doc/controllers/groupage.md#delete-groupage)


# Create Groupage

Allows to create a groupage containing one or more shipping orders for the same consignee (UNDER CONSTRUCTION)

```php
function createGroupage(OrderNumbersList $orderNumbers): GroupageNumber
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `orderNumbers` | [`OrderNumbersList`](../../doc/models/order-numbers-list.md) | Body, Required | - |

## Requires scope

`WSO_CREATEGROUPAGE`

## Response Type

[`GroupageNumber`](../../doc/models/groupage-number.md)

## Example Usage

```php
$orderNumbers_orderNumbers = ['SHW12345678', 'SHW12345679'];
$orderNumbers = new Models\OrderNumbersList(
    $orderNumbers_orderNumbers
);

$result = $groupageController->createGroupage($orderNumbers);
```

## Example Response *(as JSON)*

```json
{
  "number": "GR12345678"
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 409 | Conflict | [`ApiProblemException`](../../doc/models/api-problem-exception.md) |
| 422 | Unprocessable entity | [`ApiProblemException`](../../doc/models/api-problem-exception.md) |
| Default | Bad Request | [`ApiProblemException`](../../doc/models/api-problem-exception.md) |


# Delete Groupage

Allows to cancel a groupage (UNDER CONSTRUCTION)

```php
function deleteGroupage(GroupageNumber $number): void
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `number` | [`GroupageNumber`](../../doc/models/groupage-number.md) | Body, Required | Number of the groupage to delete |

## Requires scope

`WSO_DELETEGROUPAGE`

## Response Type

`void`

## Example Usage

```php
$number_number = 'GR12345678';
$number = new Models\GroupageNumber(
    $number_number
);

$groupageController->deleteGroupage($number);
```

