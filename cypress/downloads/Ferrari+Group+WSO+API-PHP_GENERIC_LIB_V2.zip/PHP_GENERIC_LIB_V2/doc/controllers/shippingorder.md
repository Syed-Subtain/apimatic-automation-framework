# Shippingorder

```php
$shippingorderController = $client->getShippingorderController();
```

## Class Name

`ShippingorderController`

## Methods

* [Update Order](../../doc/controllers/shippingorder.md#update-order)
* [Get Order](../../doc/controllers/shippingorder.md#get-order)
* [Create Order](../../doc/controllers/shippingorder.md#create-order)
* [Delete Order](../../doc/controllers/shippingorder.md#delete-order)
* [Search Orders](../../doc/controllers/shippingorder.md#search-orders)
* [Print Order](../../doc/controllers/shippingorder.md#print-order)
* [Get Label](../../doc/controllers/shippingorder.md#get-label)


# Update Order

Allows to update the shipping order information if not yet confirmed by Ferrari, in case of confirmed shipment it will be necessary to contact the assigned office

```php
function updateOrder(string $number, OrderInput $order): OrderOutput
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `number` | `string` | Query, Required | - |
| `order` | [`OrderInput`](../../doc/models/order-input.md) | Body, Required | - |

## Requires scope

`WSO_UPDATEORDER`

## Response Type

[`OrderOutput`](../../doc/models/order-output.md)

## Example Usage

```php
$number = 'number2';
$order_consignorAddress_name = 'Cartwright-Simonis';
$order_consignorAddress_address = '1600 Pennsylvania Avenue';
$order_consignorAddress_city = 'Lisbon';
$order_consignorAddress_country = 'DE';
$order_consignorAddress = new Models\OrderAddress(
    $order_consignorAddress_name,
    $order_consignorAddress_address,
    $order_consignorAddress_city,
    $order_consignorAddress_country
);
$order_consigneeAddress_name = 'Cartwright-Simonis';
$order_consigneeAddress_address = '1600 Pennsylvania Avenue';
$order_consigneeAddress_city = 'Lisbon';
$order_consigneeAddress_country = 'DE';
$order_consigneeAddress = new Models\OrderAddress(
    $order_consigneeAddress_name,
    $order_consigneeAddress_address,
    $order_consigneeAddress_city,
    $order_consigneeAddress_country
);
$order_insured = 'Y';
$order_service = 'STD';
$order_confirmed = 'Y';
$order_pickupDate = '2020-05-22';
$order_parcels = [];

$order_parcels_0_grossWeight = 3.79;
$order_parcels_0_grossWeightUnit = 'lb';
$order_parcels[0] = new Models\OrderParcel(
    $order_parcels_0_grossWeight,
    $order_parcels_0_grossWeightUnit
);

$order_parcels_1_grossWeight = 3.79;
$order_parcels_1_grossWeightUnit = 'lb';
$order_parcels[1] = new Models\OrderParcel(
    $order_parcels_1_grossWeight,
    $order_parcels_1_grossWeightUnit
);

$order = new Models\OrderInput(
    $order_consignorAddress,
    $order_consigneeAddress,
    $order_insured,
    $order_service,
    $order_confirmed,
    $order_pickupDate,
    $order_parcels
);

$result = $shippingOrderController->updateOrder($number, $order);
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 409 | Conflict | [`ApiProblemException`](../../doc/models/api-problem-exception.md) |
| 422 | Unprocessable entity | [`ApiProblemException`](../../doc/models/api-problem-exception.md) |


# Get Order

Returns the shipping order

```php
function getOrder(string $number): OrderOutput
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `number` | `string` | Query, Required | Order Number |

## Requires scope

`WSO_GETORDER`

## Response Type

[`OrderOutput`](../../doc/models/order-output.md)

## Example Usage

```php
$number = 'number2';

$result = $shippingOrderController->getOrder($number);
```


# Create Order

Allows to insert a new shipping order into the Ferrari Web Shipping Order system

```php
function createOrder(OrderInput $order): OrderNumber
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `order` | [`OrderInput`](../../doc/models/order-input.md) | Body, Required | - |

## Requires scope

`WSO_CREATEORDER`

## Response Type

[`OrderNumber`](../../doc/models/order-number.md)

## Example Usage

```php
$order_consignorAddress_name = 'Cartwright-Simonis';
$order_consignorAddress_address = '1600 Pennsylvania Avenue';
$order_consignorAddress_city = 'Lisbon';
$order_consignorAddress_country = 'DE';
$order_consignorAddress = new Models\OrderAddress(
    $order_consignorAddress_name,
    $order_consignorAddress_address,
    $order_consignorAddress_city,
    $order_consignorAddress_country
);
$order_consigneeAddress_name = 'Cartwright-Simonis';
$order_consigneeAddress_address = '1600 Pennsylvania Avenue';
$order_consigneeAddress_city = 'Lisbon';
$order_consigneeAddress_country = 'DE';
$order_consigneeAddress = new Models\OrderAddress(
    $order_consigneeAddress_name,
    $order_consigneeAddress_address,
    $order_consigneeAddress_city,
    $order_consigneeAddress_country
);
$order_insured = 'Y';
$order_service = 'STD';
$order_confirmed = 'Y';
$order_pickupDate = '2020-05-22';
$order_parcels = [];

$order_parcels_0_grossWeight = 3.79;
$order_parcels_0_grossWeightUnit = 'lb';
$order_parcels[0] = new Models\OrderParcel(
    $order_parcels_0_grossWeight,
    $order_parcels_0_grossWeightUnit
);

$order_parcels_1_grossWeight = 3.79;
$order_parcels_1_grossWeightUnit = 'lb';
$order_parcels[1] = new Models\OrderParcel(
    $order_parcels_1_grossWeight,
    $order_parcels_1_grossWeightUnit
);

$order = new Models\OrderInput(
    $order_consignorAddress,
    $order_consigneeAddress,
    $order_insured,
    $order_service,
    $order_confirmed,
    $order_pickupDate,
    $order_parcels
);

$result = $shippingOrderController->createOrder($order);
```

## Example Response *(as JSON)*

```json
{
  "number": "SHW12345678"
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 409 | Conflict | [`ApiProblemException`](../../doc/models/api-problem-exception.md) |
| 422 | Unprocessable entity | [`ApiProblemException`](../../doc/models/api-problem-exception.md) |
| Default | Bad Request | [`ApiProblemException`](../../doc/models/api-problem-exception.md) |


# Delete Order

Allows to cancel a shipping order if not yet confirmed by Ferrari, in case of confirmed shipment it will be necessary to contact the assigned office

```php
function deleteOrder(OrderNumber $number): void
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `number` | [`OrderNumber`](../../doc/models/order-number.md) | Body, Required | Shipping order number to delete |

## Requires scope

`WSO_DELETEORDER`

## Response Type

`void`

## Example Usage

```php
$number_number = 'SHW12345678';
$number = new Models\OrderNumber(
    $number_number
);

$shippingOrderController->deleteOrder($number);
```


# Search Orders

Returns a collection of full-detailed shipping orders matching the search parameters

```php
function searchOrders(OrdersSearchParams $searchParams): OrdersCollection
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `searchParams` | [`OrdersSearchParams`](../../doc/models/orders-search-params.md) | Body, Required | Shipping orders search parameters |

## Requires scope

`WSO_SEARCHORDERS`

## Response Type

[`OrdersCollection`](../../doc/models/orders-collection.md)

## Example Usage

```php
$searchParams = new Models\OrdersSearchParams;

$result = $shippingOrderController->searchOrders($searchParams);
```


# Print Order

Returns the print of the order in pdf format

```php
function printOrder(OrderNumber $number): Attachment
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `number` | [`OrderNumber`](../../doc/models/order-number.md) | Body, Required | Shipping order number to print |

## Requires scope

`WSO_PRINTORDER`

## Response Type

[`Attachment`](../../doc/models/attachment.md)

## Example Usage

```php
$number_number = 'SHW12345678';
$number = new Models\OrderNumber(
    $number_number
);

$result = $shippingOrderController->printOrder($number);
```


# Get Label

Allows to get labels for the specified order

```php
function getLabel(string $orderNumber, string $format, string $type, ?int $parcelNumber = 0): GetLaberResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `orderNumber` | `string` | Query, Required | - |
| `format` | `string` | Query, Required | format of label printing<br>**Constraints**: *Maximum Length*: `3` |
| `type` | `string` | Query, Required | type of labels (anonymous or complete)<br>**Constraints**: *Maximum Length*: `10` |
| `parcelNumber` | `?int` | Query, Optional | progressive parcel number to be printed (0 for all the parcels)<br>**Default**: `0` |

## Requires scope

`WSO_GETLABEL`

## Response Type

[`GetLaberResponse`](../../doc/models/get-laber-response.md)

## Example Usage

```php
$orderNumber = 'order_number2';
$format = 'zpl';
$type = 'complete';
$parcelNumber = 1;

$result = $shippingOrderController->getLabel($orderNumber, $format, $type, $parcelNumber);
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 409 | Conflict | [`ApiProblemException`](../../doc/models/api-problem-exception.md) |
| 422 | Unprocessable entity | [`ApiProblemException`](../../doc/models/api-problem-exception.md) |

