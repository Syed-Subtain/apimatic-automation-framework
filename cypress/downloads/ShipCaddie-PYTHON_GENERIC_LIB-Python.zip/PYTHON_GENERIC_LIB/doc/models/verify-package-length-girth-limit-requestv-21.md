
# Verify Package Length Girth Limit Requestv 21

## Structure

`VerifyPackageLengthGirthLimitRequestv21`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `access_token` | `string` | Optional | Required.<br>An authorization token is necessary to call this method.<br><remarks><br>The token can be obtained by calling the GetToken or RefreshToken methods.<br></remarks> |
| `request` | [`PackageLengthGirthModelV21`](/doc/models/package-length-girth-model-v21.md) | Optional | - |

## Example (as JSON)

```json
{
  "accessToken": "<YOUR ACCESS TOKEN>",
  "request": {
    "carrierServiceLevelId": 12,
    "packageList": [
      {
        "length": 6.0,
        "width": 8.0,
        "height": 12.0
      },
      {
        "length": 6.0,
        "width": 8.0,
        "height": 12.0
      }
    ]
  }
}
```

