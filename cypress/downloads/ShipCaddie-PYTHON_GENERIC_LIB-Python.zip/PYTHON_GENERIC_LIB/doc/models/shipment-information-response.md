
# Shipment Information Response

## Structure

`ShipmentInformationResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `shipment_id` | `int` | Optional | Id used to identify shipment. |
| `error` | [`RequestError`](/doc/models/request-error.md) | Required | This information can be used to determine if an error has occurred when a request was processed. |
| `shipment` | [`ShipmentInformation`](/doc/models/shipment-information.md) | Optional | All necessary shipping information |

## Example (as JSON)

```json
{
  "shipmentId": null,
  "error": {
    "details": null,
    "hasError": false
  },
  "shipment": null
}
```

