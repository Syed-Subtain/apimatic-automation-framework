
# Data Block

## Structure

`DataBlock`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `data_source_name` | `string` | Optional | - |
| `mtype` | `string` | Optional | - |
| `data` | `string` | Optional | - |
| `data_uri` | `string` | Optional | - |

## Example (as JSON)

```json
{
  "dataSourceName": null,
  "type": null,
  "data": null,
  "dataURI": null
}
```

