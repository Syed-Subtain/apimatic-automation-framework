
# Print Job

## Structure

`PrintJob`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `print_template_type` | `string` | Optional | - |
| `data_blocks` | [`List of DataBlock`](/doc/models/data-block.md) | Optional | - |

## Example (as JSON)

```json
{
  "printTemplateType": null,
  "dataBlocks": null
}
```

