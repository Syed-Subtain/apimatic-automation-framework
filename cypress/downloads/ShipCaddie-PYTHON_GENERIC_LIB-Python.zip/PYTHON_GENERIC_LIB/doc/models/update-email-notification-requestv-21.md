
# Update Email Notification Requestv 21

## Structure

`UpdateEmailNotificationRequestv21`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `access_token` | `string` | Required | Required.<br>An authorization token is necessary to call this method.<br><remarks><br>The token can be obtained by calling the GetToken or RefreshToken methods.<br></remarks> |
| `as_client_id` | `int` | Optional | Optional.<br>When empty or null, this field is ignored.<br>When set, actions will be taken for the client specified by the id. |
| `carrier_client_contract_id` | `int` | Required | Required.<br>Turn email notifications on or off for the carrier specified by CarrierClientContractId. |
| `notify_by_email` | `bool` | Required | Required.<br>Set to true if you want to recieve email notifictions.  Set to false otherwise. |

## Example (as JSON)

```json
{
  "accessToken": "<YOUR ACCESS TOKEN>",
  "asClientId": 12,
  "carrierClientContractId": 19,
  "notifyByEmail": true
}
```

