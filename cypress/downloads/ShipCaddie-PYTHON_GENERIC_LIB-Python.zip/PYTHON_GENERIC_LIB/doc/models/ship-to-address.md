
# Ship to Address

## Structure

`ShipToAddress`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `attention_of` | `string` | Optional | Attention of the person accepting the parcels.<br>This field is required by some Carriers. |
| `company_name` | `string` | Optional | Optional Company Name.<br>This field is required by some Carriers. |
| `email` | `string` | Optional | This field is required by some Carriers. |
| `phone_number` | `string` | Optional | This field is required by some Carriers. |
| `address_1` | `string` | Optional | Street Address |
| `address_2` | `string` | Optional | Optional additional Street Address. |
| `is_residential` | `bool` | Optional | Specifies if the address is a residential address. |
| `city` | `string` | Optional | City to which the parcels will be sent. |
| `state_or_province` | `string` | Optional | Use Province or other appropriate value<br>for international addresses. |
| `postal_code` | `string` | Optional | Zip Code if address in in the United States.<br>Postal Code if the address is international. |
| `country_code` | `string` | Optional | Code which indicates to which<br>country the parcels will be sent.<br>Obtained from GetContryCodes. |

## Example (as JSON)

```json
{
  "attentionOf": null,
  "companyName": null,
  "email": null,
  "phoneNumber": null,
  "address1": null,
  "address2": null,
  "isResidential": null,
  "city": null,
  "stateOrProvince": null,
  "postalCode": null,
  "countryCode": null
}
```

