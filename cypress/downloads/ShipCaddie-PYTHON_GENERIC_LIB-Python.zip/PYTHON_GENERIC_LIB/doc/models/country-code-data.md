
# Country Code Data

Country information necessary to construct addresses.

## Structure

`CountryCodeData`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `country_id` | `int` | Required | Unique ID used to identify a country. |
| `country_name` | `string` | Required | Friendly Country name. |
| `alpha_2_country_code` | `string` | Required | Standardized Country Codes. |

## Example (as JSON)

```json
{
  "countryId": 8,
  "countryName": "countryName6",
  "alpha2CountryCode": "alpha2CountryCode6"
}
```

