
# Carrier Information

## Structure

`CarrierInformation`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `carrier_client_contract_id` | `int` | Required | This id is used to identify a carrier.<br>Various API methods require this id. |
| `affillate_name` | `string` | Required | Affillate Name |
| `carrier_name` | `string` | Required | Offical name of carrier. |
| `nick_name` | `string` | Required | Descriptive Name |
| `service_levels` | [`List of ServiceLevelDetail`](/doc/models/service-level-detail.md) | Required | Describes service details such as parcel weight limits. |
| `error` | [`RequestError`](/doc/models/request-error.md) | Optional | This information can be used to determine if an error has occurred when a request was processed. |

## Example (as JSON)

```json
{
  "carrierClientContractId": 190,
  "affillateName": "affillateName8",
  "carrierName": "carrierName2",
  "nickName": "nickName4",
  "serviceLevels": [
    {
      "carrierServiceLevelID": 34,
      "name": "name2",
      "parcelWeightLimit": 225.12,
      "isInternational": false
    },
    {
      "carrierServiceLevelID": 35,
      "name": "name3",
      "parcelWeightLimit": 225.13,
      "isInternational": true
    }
  ],
  "error": null
}
```

