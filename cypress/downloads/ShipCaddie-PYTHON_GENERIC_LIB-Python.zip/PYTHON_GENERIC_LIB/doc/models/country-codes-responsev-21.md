
# Country Codes Responsev 21

Country code information used to contruct addresses.

## Structure

`CountryCodesResponsev21`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `country_code_list` | [`List of CountryCodeData`](/doc/models/country-code-data.md) | Required | List of Country Codes, Country Names and CountryIds. |
| `error` | [`RequestError`](/doc/models/request-error.md) | Required | This information can be used to determine if an error has occurred when a request was processed. |

## Example (as JSON)

```json
{
  "countryCodeList": [
    {
      "countryId": 144,
      "countryName": "countryName6",
      "alpha2CountryCode": "alpha2CountryCode8"
    },
    {
      "countryId": 145,
      "countryName": "countryName7",
      "alpha2CountryCode": "alpha2CountryCode9"
    }
  ],
  "error": {
    "details": null,
    "hasError": false
  }
}
```

