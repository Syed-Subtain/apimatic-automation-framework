
# Security Token

A valid Token is necessary to get a response from an API method call.

## Structure

`SecurityToken`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `access_token` | `string` | Required | Use this authorization token when calling other API methods. |
| `refresh_token` | `string` | Required | Use the Refresh Token to obtain a new token after the Access Token has expired. |
| `refresh_token_expiration_date` | `datetime` | Required | After this time it will be neccessary to obtain a new token using a valid username and password by calling GetToken.<br>The time is expressed in Universal Time. (UTC) |
| `access_token_expiration_date` | `datetime` | Required | After this time a new token can be obtained by calling RefreshToken using a valid RefreshToken.<br>The time is expressed in Universal Time. (UTC) |
| `error` | [`RequestError`](/doc/models/request-error.md) | Required | This information can be used to determine if an error has occurred when a request was processed. |

## Example (as JSON)

```json
{
  "accessToken": "accessToken2",
  "refreshToken": "refreshToken2",
  "refreshTokenExpirationDate": "2016-03-13T12:52:32.123Z",
  "accessTokenExpirationDate": "2016-03-13T12:52:32.123Z",
  "error": {
    "details": null,
    "hasError": false
  }
}
```

