
# Shipping Cost Informationv 21

Cost details related to shipping.

## Structure

`ShippingCostInformationv21`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `shipment_id` | `int` | Optional | Internal shipment identifier.<br>Read Only. |
| `order_reference_number` | `string` | Optional | Optional order reference tag that was set when adding a shipment or getting rates. |
| `parcel_charge_details` | [`List of ParcelChargeDetails`](/doc/models/parcel-charge-details.md) | Optional | Shipping charges relating to individual parcels. |
| `shipping_charge_details` | [`List of CostDetailv21`](/doc/models/cost-detailv-21.md) | Optional | Shipping charges relating to a shipment as a whole. |
| `transit_days_min` | `int` | Optional | The Days in transit as defined by the carrier for the service level chosen.<br>The number may or may not include non-business days. |
| `transit_days_max` | `int` | Optional | The Days in transit as defined by the carrier for the service level chosen.<br>The number may or may not include non-business days. |
| `total_charge_amount` | `float` | Optional | - |
| `total_charge_amount_3_pl` | `float` | Optional | This is the sum of all accessorialCharges.chargeAmount3pl fields in all packages |
| `delivery_date_time` | `datetime` | Optional | - |
| `is_delivery_guaranteed` | `bool` | Optional | - |

## Example (as JSON)

```json
{
  "shipmentId": null,
  "orderReferenceNumber": null,
  "parcelChargeDetails": null,
  "shippingChargeDetails": null,
  "transitDaysMin": null,
  "transitDaysMax": null,
  "totalChargeAmount": null,
  "totalChargeAmount3pl": null,
  "deliveryDateTime": null,
  "isDeliveryGuaranteed": null
}
```

