
# Packages V21

## Structure

`PackagesV21`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `length` | `float` | Optional | Required - Length |
| `width` | `float` | Optional | Required - Width |
| `height` | `float` | Optional | Required - Height |

## Example (as JSON)

```json
{
  "length": null,
  "width": null,
  "height": null
}
```

