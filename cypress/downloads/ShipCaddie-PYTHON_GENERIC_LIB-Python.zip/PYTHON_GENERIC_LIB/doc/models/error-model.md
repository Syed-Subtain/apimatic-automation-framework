
# Error Model

Model for the errors

## Structure

`ErrorModel`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `error_code` | `string` | Optional | Error Code |
| `error_description` | `string` | Optional | Description of the error |

## Example (as JSON)

```json
{
  "errorCode": null,
  "errorDescription": null
}
```

