
# Available Shipments Responsev 21

## Structure

`AvailableShipmentsResponsev21`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `error` | [`RequestError`](/doc/models/request-error.md) | Optional | This information can be used to determine if an error has occurred when a request was processed. |
| `available_shipments` | [`List of AvailableShipment`](/doc/models/available-shipment.md) | Optional | - |

## Example (as JSON)

```json
{
  "error": null,
  "availableShipments": null
}
```

