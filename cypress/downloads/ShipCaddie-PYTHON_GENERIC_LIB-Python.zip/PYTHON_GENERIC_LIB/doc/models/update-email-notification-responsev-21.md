
# Update Email Notification Responsev 21

## Structure

`UpdateEmailNotificationResponsev21`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `successfully_updated_email_notification` | `bool` | Required | True if update has completed successfully.<br>False otherwise. |
| `error` | [`RequestError`](/doc/models/request-error.md) | Required | This information can be used to determine if an error has occurred when a request was processed. |

## Example (as JSON)

```json
{
  "successfullyUpdatedEmailNotification": false,
  "error": {
    "details": null,
    "hasError": false
  }
}
```

