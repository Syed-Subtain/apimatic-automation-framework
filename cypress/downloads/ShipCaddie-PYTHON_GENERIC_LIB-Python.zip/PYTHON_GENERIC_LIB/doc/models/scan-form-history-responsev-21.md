
# Scan Form History Responsev 21

## Structure

`ScanFormHistoryResponsev21`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `error` | [`RequestError`](/doc/models/request-error.md) | Optional | This information can be used to determine if an error has occurred when a request was processed. |
| `scan_form_list` | [`List of ScanFormModel`](/doc/models/scan-form-model.md) | Optional | List of ScanForm Data |

## Example (as JSON)

```json
{
  "error": null,
  "scanFormList": null
}
```

