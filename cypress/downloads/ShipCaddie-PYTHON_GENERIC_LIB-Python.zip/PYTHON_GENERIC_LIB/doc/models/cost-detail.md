
# Cost Detail

Specific break down of cost.

## Structure

`CostDetail`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `name` | `string` | Required | Name of a specific Charge. |
| `amount` | `float` | Required | Cost in United States Currency. |
| `amount_display` | `float` | Optional | Total Charge Amount Display |

## Example (as JSON)

```json
{
  "name": "name0",
  "amount": 56.78,
  "AmountDisplay": null
}
```

