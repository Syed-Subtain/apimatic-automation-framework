
# Cost Detailv 21

Specific break down of cost.

## Structure

`CostDetailv21`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `name` | `string` | Optional | Name of a specific Charge. |
| `amount` | `float` | Optional | Cost in United States Currency. |
| `amount_display` | `float` | Optional | Total Charge Amount Display |

## Example (as JSON)

```json
{
  "name": null,
  "amount": null,
  "amountDisplay": null
}
```

