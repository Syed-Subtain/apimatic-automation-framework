
# Get Carrier Balance Responsev 21

## Structure

`GetCarrierBalanceResponsev21`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `threshold` | `float` | Required | Account Threshold |
| `recharge_amount` | `float` | Required | Account Recharge Amount |
| `balance` | `float` | Required | Account Balance |
| `error` | [`RequestError`](/doc/models/request-error.md) | Optional | This information can be used to determine if an error has occurred when a request was processed. |

## Example (as JSON)

```json
{
  "threshold": 204.48,
  "rechargeAmount": 51.02,
  "balance": 26.24,
  "error": null
}
```

