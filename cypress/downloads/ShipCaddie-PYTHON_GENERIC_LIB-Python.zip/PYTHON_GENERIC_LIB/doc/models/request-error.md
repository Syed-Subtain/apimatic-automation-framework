
# Request Error

This information can be used to determine if an error has occurred when a request was processed.

## Structure

`RequestError`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `details` | `List of string` | Optional | Describes the error that occurred during the request. |
| `has_error` | `bool` | Required | Set to true in the case that an error has occurred while processing the request.<br>Set to false otherwise. |

## Example (as JSON)

```json
{
  "details": null,
  "hasError": false
}
```

