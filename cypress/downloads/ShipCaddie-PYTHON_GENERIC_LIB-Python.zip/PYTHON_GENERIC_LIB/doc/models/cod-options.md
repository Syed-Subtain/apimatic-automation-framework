
# COD Options

Optional Cash on Demand

## Structure

`CODOptions`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `cod_type` | [`CodTypeEnum`](/doc/models/cod-type-enum.md) | Optional | - |
| `cod_amount` | `float` | Optional | If COD is used,<br>specify the amount in<br>US Currency. |

## Example (as JSON)

```json
{
  "codType": null,
  "codAmount": null
}
```

