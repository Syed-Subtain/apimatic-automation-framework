
# Register Account Limit Requestv 21

## Structure

`RegisterAccountLimitRequestv21`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `registration_information` | [`UserRegisterModelv21`](/doc/models/user-register-modelv-21.md) | Optional | - |

## Example (as JSON)

```json
{
  "registrationInformation": {
    "systemCountryId": 840,
    "nameFirst": "Tom",
    "nameLast": "Thomson",
    "companyName": "Ace",
    "phoneNumber": "123 456-7890",
    "userName": "User Name",
    "password": "Password",
    "passwordVerify": "Password",
    "promoCode": "",
    "subscriptionTierId": 1,
    "iAgree": "yes"
  }
}
```

