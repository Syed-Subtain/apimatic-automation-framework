
# Key Values

## Structure

`KeyValues`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `label_key` | `string` | Optional | - |
| `tracking_number` | `string` | Optional | - |
| `package_id` | `int` | Optional | - |

## Example (as JSON)

```json
{
  "labelKey": null,
  "trackingNumber": null,
  "packageId": null
}
```

