
# Addressv 21

## Structure

`Addressv21`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `address_1` | `string` | Required | Required |
| `address_2` | `string` | Optional | Optional |
| `city` | `string` | Required | Required |
| `country_code` | `string` | Required | Required |
| `state_or_providence` | `string` | Required | Required - StateOrProvidence |
| `postal_code` | `string` | Required | Required - PostalCode |
| `is_residential` | `bool` | Optional | Optional - Is Residencial flag |
| `attention_of` | `string` | Optional | Optional - Attention of,<br>some Carriers will require this parameter to be set |
| `company_name` | `string` | Optional | Optional - Company Name,<br>some Carriers will require this parameter to be set |
| `email` | `string` | Optional | Optional - Email, some Carriers will require this parameter to be set |
| `phone_number` | `string` | Optional | Optional - Phone Number,<br>some Carriers will require this parameter to be set |

## Example (as JSON)

```json
{
  "address1": "address12",
  "address2": null,
  "city": "city0",
  "countryCode": "countryCode4",
  "stateOrProvidence": "stateOrProvidence4",
  "postalCode": "postalCode8",
  "isResidential": null,
  "attentionOf": null,
  "companyName": null,
  "email": null,
  "phoneNumber": null
}
```

