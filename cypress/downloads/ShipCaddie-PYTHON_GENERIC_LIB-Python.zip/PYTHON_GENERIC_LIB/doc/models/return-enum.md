
# Return Enum

Indicates if this is a return parcel.
and if so what type of return should be used.

## Enumeration

`ReturnEnum`

## Fields

| Name |
|  --- |
| `NOT_APPLICABLE` |
| `RETURN_LABEL` |
| `RETURN_LABEL_SHIP` |
| `RETURN_LABEL_ON_USE` |

