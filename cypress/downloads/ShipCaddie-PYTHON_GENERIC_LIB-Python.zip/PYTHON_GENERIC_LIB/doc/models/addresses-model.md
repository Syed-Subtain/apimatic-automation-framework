
# Addresses Model

Common model for Requested and Suggested Addresses

## Structure

`AddressesModel`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `address_1` | `string` | Optional | Address Line1 of the address |
| `address_2` | `string` | Optional | Address Line2 of the address |
| `address_type_id` | [`AddressTypeId1Enum`](/doc/models/address-type-id-1-enum.md) | Optional | Id of the address type |
| `city` | `string` | Optional | City |
| `company_name` | `string` | Optional | Name of the Company / Organisation |
| `country_code` | `string` | Optional | Code of the country provided in address |
| `country_id` | `int` | Optional | Id of the country specified. |
| `countryname` | `string` | Optional | Name of the country with which address relates |
| `postal_code` | `string` | Optional | Postal Code |
| `province` | `string` | Optional | Province / State |
| `province_code` | `string` | Optional | Code the Province |
| `row_key_hash` | `string` | Optional | Row Key Hash |
| `is_selected` | `bool` | Optional | Is Selected |

## Example (as JSON)

```json
{
  "address1": null,
  "address2": null,
  "addressTypeId": null,
  "city": null,
  "companyName": null,
  "countryCode": null,
  "countryId": null,
  "countryname": null,
  "postalCode": null,
  "province": null,
  "provinceCode": null,
  "rowKeyHash": null,
  "isSelected": null
}
```

