
# Shipment Inventory by Sku Response Model

## Structure

`ShipmentInventoryBySkuResponseModel`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `shipment_inventory_by_sku_response` | [`List of ShipmentInventoryBySkuResponse`](/doc/models/shipment-inventory-by-sku-response.md) | Optional | - |
| `error` | [`RequestError`](/doc/models/request-error.md) | Optional | This information can be used to determine if an error has occurred when a request was processed. |

## Example (as JSON)

```json
{
  "shipmentInventoryBySku_Response": null,
  "error": null
}
```

