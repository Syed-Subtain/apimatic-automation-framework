
# Api Error Model

The error model that is used throughout all the api's

## Structure

`ApiErrorModel`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `error` | `string` | Optional | The code that identifies the error. |
| `developer_message` | `string` | Optional | The message that should go back to the developer. |
| `user_message` | `string` | Optional | The message if any that should go back to the user. |
| `misc` | `object` | Optional | Other misc objects that need to be passed to controller for return with other methods |

## Example (as JSON)

```json
{
  "error": null,
  "developerMessage": null,
  "userMessage": null,
  "misc": null
}
```

