
# Cod Type Enum

## Enumeration

`CodTypeEnum`

## Fields

| Name |
|  --- |
| `NOT_APPLICABLE` |
| `COD_SECURED_FUNDS` |
| `COD_CASH` |
| `COD_CHECK` |
| `COD_ANY` |

