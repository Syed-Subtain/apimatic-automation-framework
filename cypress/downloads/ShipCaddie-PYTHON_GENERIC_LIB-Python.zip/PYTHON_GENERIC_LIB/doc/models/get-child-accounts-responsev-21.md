
# Get Child Accounts Responsev 21

## Structure

`GetChildAccountsResponsev21`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `error` | [`RequestError`](/doc/models/request-error.md) | Optional | This information can be used to determine if an error has occurred when a request was processed. |
| `child_accounts` | [`List of ChildAccountsv21`](/doc/models/child-accountsv-21.md) | Optional | List of associated child accounts |

## Example (as JSON)

```json
{
  "error": null,
  "childAccounts": null
}
```

