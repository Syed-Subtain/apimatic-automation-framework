
# Available Shipments Requestv 21

## Structure

`AvailableShipmentsRequestv21`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `access_token` | `string` | Required | Required.<br>An authorization token is necessary to call this method.<br><remarks><br>The token can be obtained by calling the GetToken or RefreshToken methods.<br></remarks> |
| `as_client_id` | `int` | Optional | Optional.<br>When empty or null, this field is ignored.<br>When set, actions will be taken for the client specified by the id. |
| `carrier_client_contract_id` | `int` | Optional | Carrier Client Contract Identifier used to identify a carrier for this client. |
| `address_id` | `int` | Optional | Address identifier |
| `ship_date` | `datetime` | Optional | Date of Shipment |

## Example (as JSON)

```json
{
  "accessToken": "<YOUR ACCESS TOKEN>",
  "asClientId": 12,
  "carrierClientContractId": 34,
  "addressId": 23,
  "shipDate": "2020-12-23T23:54:10.1554517+00:00"
}
```

