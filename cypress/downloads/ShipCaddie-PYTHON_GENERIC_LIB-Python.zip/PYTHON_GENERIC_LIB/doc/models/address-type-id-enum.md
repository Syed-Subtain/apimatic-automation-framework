
# Address Type Id Enum

Type of address
Values :
- NotDefined
- Residential
- Commercial
- NotVerified
- Invalid

## Enumeration

`AddressTypeIdEnum`

## Fields

| Name |
|  --- |
| `NOTDEFINED` |
| `RESIDENTIAL` |
| `COMMERCIAL` |
| `NOTVERIFIED` |
| `INVALID` |
| `FAILEDADDRESS` |
| `USERVERIFIED` |
| `PROCESSING` |
| `MILITARY` |
| `INTERNATIONAL` |
| `USTERRITORY` |
| `POBOX` |

