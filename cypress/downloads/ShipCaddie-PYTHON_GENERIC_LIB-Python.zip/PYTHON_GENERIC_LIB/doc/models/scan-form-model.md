
# Scan Form Model

## Structure

`ScanFormModel`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Optional | - |
| `scan_form_id` | `string` | Optional | - |
| `batch_id` | `string` | Optional | - |
| `client_id` | `int` | Optional | - |
| `shipment_client_address_id` | `int` | Optional | - |
| `ship_date` | `datetime` | Optional | - |
| `scan_form_data_type` | [`ScanFormDataTypeEnum`](/doc/models/scan-form-data-type-enum.md) | Optional | - |
| `carrier_client_contract_id` | `int` | Optional | - |
| `carrier_client_contract_name` | `string` | Optional | - |
| `shipment_client_address_line_1` | `string` | Optional | - |
| `shipment_client_address_line_2` | `string` | Optional | - |
| `shipment_client_address_province` | `string` | Optional | - |
| `shipment_client_address_city` | `string` | Optional | - |
| `shipment_client_address_postal_code` | `string` | Optional | - |
| `shipping_site_name` | `string` | Optional | - |
| `date_created` | `datetime` | Optional | - |
| `print_jobs` | [`List of PrintJob`](/doc/models/print-job.md) | Optional | - |
| `excluded_items` | `dict` | Optional | This is the list of items that are ignored or already manifested by easypost. |

## Example (as JSON)

```json
{
  "id": null,
  "scanFormId": null,
  "batchId": null,
  "clientId": null,
  "shipmentClientAddressId": null,
  "shipDate": null,
  "scanFormDataType": null,
  "carrierClientContractId": null,
  "carrierClientContractName": null,
  "shipmentClientAddressLine1": null,
  "shipmentClientAddressLine2": null,
  "shipmentClientAddressProvince": null,
  "shipmentClientAddressCity": null,
  "shipmentClientAddressPostalCode": null,
  "shippingSiteName": null,
  "dateCreated": null,
  "printJobs": null,
  "excludedItems": null
}
```

