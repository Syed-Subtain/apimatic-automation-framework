
# Packaging Detail

Carrier Packaging Specifications

## Structure

`PackagingDetail`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `parcel_id` | `string` | Optional | This ID can be used when specifing a Parcel type. |
| `name` | `string` | Optional | Parcel Type |
| `description` | `string` | Optional | Parcel Description |
| `length_in_inches` | `float` | Optional | Length of one side of parcel in inches. |
| `width_in_inches` | `float` | Optional | Width of one side of parcel in inches. |
| `height_in_inches` | `float` | Optional | Height of one side of parcel in inches. |
| `weight_limit` | `float` | Optional | Carrier Weight limit for the parcel |
| `packaging_weight` | `float` | Optional | Container weight |

## Example (as JSON)

```json
{
  "parcelId": null,
  "name": null,
  "description": null,
  "lengthInInches": null,
  "widthInInches": null,
  "heightInInches": null,
  "weightLimit": null,
  "packagingWeight": null
}
```

