
# Scan Form Generate Responsev 21

## Structure

`ScanFormGenerateResponsev21`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `error` | [`RequestError`](/doc/models/request-error.md) | Optional | This information can be used to determine if an error has occurred when a request was processed. |
| `scan_form_information` | [`ScanFormModel`](/doc/models/scan-form-model.md) | Optional | - |

## Example (as JSON)

```json
{
  "error": null,
  "scanFormInformation": null
}
```

