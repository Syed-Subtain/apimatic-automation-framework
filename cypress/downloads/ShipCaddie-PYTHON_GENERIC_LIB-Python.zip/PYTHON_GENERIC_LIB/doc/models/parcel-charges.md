
# Parcel Charges

Break down of charges per parcel.

## Structure

`ParcelCharges`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `parcel_id` | `uuid\|string` | Required | A unique ID used to match<br>parcels with cost details. |
| `cost_details` | [`List of CostDetail`](/doc/models/cost-detail.md) | Optional | Detailed shipping charges. |
| `packaging_id` | `string` | Optional | - |

## Example (as JSON)

```json
{
  "parcelID": "00001f04-0000-0000-0000-000000000000",
  "costDetails": null,
  "packagingId": null
}
```

