
# Delete Shipment Result

Results of a Delete Shipment request.

## Structure

`DeleteShipmentResult`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `shipment_id` | `int` | Optional | ID uniquely identifying the shipment that was requested to be deleted. |
| `is_deleted` | `bool` | Optional | Set to true if the shipment was deleted successfully. |
| `error` | [`RequestError`](/doc/models/request-error.md) | Optional | This information can be used to determine if an error has occurred when a request was processed. |

## Example (as JSON)

```json
{
  "shipmentId": null,
  "isDeleted": null,
  "error": null
}
```

