
# Parcel Content

Itemized packaging content used by customs.

## Structure

`ParcelContent`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `sku` | `string` | Optional | Product identifier. |
| `name` | `string` | Required | Descriptive item name. |
| `description` | `string` | Optional | Optional item description. |
| `quantity` | `int` | Required | Number of items. |
| `price` | `float` | Required | Price of item. |
| `weight_in_pounds` | `float` | Required | Weight of the item. |
| `harmonize_code` | `string` | Optional | Optional Harmonize code |
| `origin_country` | `string` | Required | Country where product was made. |

## Example (as JSON)

```json
{
  "sku": null,
  "name": "name0",
  "description": null,
  "quantity": 68,
  "price": 207.52,
  "weightInPounds": 168.18,
  "harmonizeCode": null,
  "originCountry": "originCountry4"
}
```

