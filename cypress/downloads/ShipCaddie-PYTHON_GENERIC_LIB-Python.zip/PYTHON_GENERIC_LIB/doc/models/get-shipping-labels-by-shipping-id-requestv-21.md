
# Get Shipping Labels by Shipping ID Requestv 21

## Structure

`GetShippingLabelsByShippingIDRequestv21`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `access_token` | `string` | Required | Required.<br>An authorization token is necessary to call this method.<br><remarks><br>The token can be obtained by calling the GetToken or RefreshToken methods.<br></remarks> |
| `as_client_id` | `int` | Optional | Optional.<br>When empty or null, this field is ignored.<br>When set, actions will be taken for the client specified by the id. |
| `shipment_id` | `int` | Required | Shipment identifier. |
| `print_format` | [`PrintFormatEnum`](/doc/models/print-format-enum.md) | Required | Format used for printing labels. |
| `certify_test_override` | [`CertifyTestOverrideEnum`](/doc/models/certify-test-override-enum.md) | Optional | CertifyTestOverride : Force a Label to overriding what is in the contract |

## Example (as JSON)

```json
{
  "accessToken": "<YOUR ACCESS TOKEN>",
  "asClientId": 12,
  "shipmentID": 19,
  "printFormat": "PNG_4x6",
  "certifyTestOverride": "Contract"
}
```

