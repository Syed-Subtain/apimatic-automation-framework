
# Available Shipment

## Structure

`AvailableShipment`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `carrier_client_contract_id` | `int` | Optional | - |
| `shipment_id` | `int` | Optional | - |
| `package_id` | `int` | Optional | - |
| `shipment_client_address_id` | `int` | Optional | - |
| `date_shipped` | `datetime` | Optional | - |
| `from_shipping_site_name` | `string` | Optional | - |
| `to_address_line_1` | `string` | Optional | - |
| `to_address_line_2` | `string` | Optional | - |
| `to_postal_code` | `string` | Optional | - |
| `to_province` | `string` | Optional | - |
| `to_city` | `string` | Optional | - |
| `account_alias` | `string` | Optional | - |
| `label_key` | `string` | Optional | - |
| `tracking_number` | `string` | Optional | - |

## Example (as JSON)

```json
{
  "carrierClientContractId": null,
  "shipmentId": null,
  "packageId": null,
  "shipmentClientAddressId": null,
  "dateShipped": null,
  "fromShippingSiteName": null,
  "toAddressLine1": null,
  "toAddressLine2": null,
  "toPostalCode": null,
  "toProvince": null,
  "toCity": null,
  "accountAlias": null,
  "labelKey": null,
  "trackingNumber": null
}
```

