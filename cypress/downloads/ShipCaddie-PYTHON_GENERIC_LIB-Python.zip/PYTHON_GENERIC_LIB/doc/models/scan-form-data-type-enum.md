
# Scan Form Data Type Enum

## Enumeration

`ScanFormDataTypeEnum`

## Fields

| Name |
|  --- |
| `UNDEFINED` |
| `IMAGEURL` |
| `IMAGEPNG` |
| `IMAGETIFF` |
| `PDF` |
| `PDFURL` |

