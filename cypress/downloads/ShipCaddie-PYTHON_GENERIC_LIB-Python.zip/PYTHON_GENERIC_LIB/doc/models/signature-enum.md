
# Signature Enum

Indicates if a signature is required,
and if so what type of signature should be used.

## Enumeration

`SignatureEnum`

## Fields

| Name |
|  --- |
| `NOT_APPLICABLE` |
| `SIGNATURE_ADULT` |
| `SIGNATURE_ADULT_RESTRICTED` |
| `SIGNATURE_REQUIRED` |
| `SIGNATURE_NO_REQUIRED` |
| `SIGNATURE_DIRECT` |
| `SIGNATURE_INDIRECT` |

