
# Scan Form Model Request

## Structure

`ScanFormModelRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `carrier_client_contract_id` | `int` | Optional | - |
| `shipment_client_address_id` | `int` | Optional | - |
| `ship_date` | `datetime` | Optional | - |
| `key_list` | [`List of KeyValues`](/doc/models/key-values.md) | Optional | - |
| `recent_scan_form_id` | `int` | Optional | - |

## Example (as JSON)

```json
{
  "carrierClientContractId": null,
  "shipmentClientAddressId": null,
  "shipDate": null,
  "keyList": null,
  "recentScanFormId": null
}
```

