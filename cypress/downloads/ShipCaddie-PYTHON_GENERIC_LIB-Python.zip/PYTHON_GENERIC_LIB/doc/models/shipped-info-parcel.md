
# Shipped Info Parcel

## Structure

`ShippedInfoParcel`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `cost` | `float` | Optional | The cost of shipping the package |
| `reference_field_1` | `string` | Optional | Optional - Reference Field 1 |
| `reference_field_2` | `string` | Optional | Optional - Reference Field 2 |
| `reference_field_3` | `string` | Optional | Optional - Reference Field 3 |
| `weight_in_pounds` | `float` | Optional | Parcel Weight in Pounds. |
| `length_in_inches` | `float` | Optional | Length of one side of parcel in inches. |
| `width_in_inches` | `float` | Optional | Width of one side of parcel in inches. |
| `height_in_inches` | `float` | Optional | Height of one side of parcel in inches. |
| `tracking_number` | `string` | Optional | The tracking number of the package. |
| `options` | [`ParcelOptions`](/doc/models/parcel-options.md) | Optional | Specifies additional parcel options such as COD and required Signatures. |
| `parcel_items` | [`List of ParcelContent`](/doc/models/parcel-content.md) | Optional | Type of parcel contents. |

## Example (as JSON)

```json
{
  "cost": null,
  "referenceField1": null,
  "referenceField2": null,
  "referenceField3": null,
  "weightInPounds": null,
  "lengthInInches": null,
  "widthInInches": null,
  "heightInInches": null,
  "trackingNumber": null,
  "options": null,
  "parcelItems": null
}
```

