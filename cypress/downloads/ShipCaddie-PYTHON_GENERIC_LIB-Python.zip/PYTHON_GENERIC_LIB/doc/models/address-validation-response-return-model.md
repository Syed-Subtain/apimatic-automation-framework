
# Address Validation Response Return Model

The data for return dataset

## Structure

`AddressValidationResponseReturnModel`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `data` | [`AddressValidatationResponseModel`](/doc/models/address-validatation-response-model.md) | Optional | Address Validation Response Model |
| `success` | `bool` | Optional | Flag to indicate success or failure |
| `error` | [`ApiErrorModel`](/doc/models/api-error-model.md) | Optional | The error model that is used throughout all the api's |
| `v_2_error` | [`RequestError`](/doc/models/request-error.md) | Optional | This information can be used to determine if an error has occurred when a request was processed. |

## Example (as JSON)

```json
{
  "data": null,
  "success": null,
  "error": null,
  "v2Error": null
}
```

