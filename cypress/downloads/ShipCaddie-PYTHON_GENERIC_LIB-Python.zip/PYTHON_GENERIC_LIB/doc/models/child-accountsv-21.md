
# Child Accountsv 21

## Structure

`ChildAccountsv21`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `client_id` | `int` | Optional | - |
| `name` | `string` | Optional | - |
| `is_enabled` | `bool` | Optional | - |

## Example (as JSON)

```json
{
  "clientId": null,
  "name": null,
  "isEnabled": null
}
```

