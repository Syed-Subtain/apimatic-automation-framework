
# Shipment Inventory by Sku Response

## Structure

`ShipmentInventoryBySkuResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `sku` | `string` | Optional | - |
| `name` | `string` | Optional | - |
| `qty` | `int` | Optional | - |
| `date_shipped` | `datetime` | Optional | - |
| `order_reference_number` | `string` | Optional | - |
| `shipment_number` | `string` | Optional | - |

## Example (as JSON)

```json
{
  "sku": null,
  "name": null,
  "qty": null,
  "dateShipped": null,
  "orderReferenceNumber": null,
  "shipmentNumber": null
}
```

