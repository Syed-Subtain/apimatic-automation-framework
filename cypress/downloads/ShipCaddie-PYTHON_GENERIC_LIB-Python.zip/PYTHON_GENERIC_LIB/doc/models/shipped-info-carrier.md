
# Shipped Info Carrier

## Structure

`ShippedInfoCarrier`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `carrier_client_contract_id` | `int` | Optional | Indicates which Carrier was used. |
| `carrier_name` | `string` | Optional | The name of the carrier used for the shipment. |
| `carrier_service_level_id` | `int` | Optional | Indicates which Carrier Service Level was used. |
| `carrier_service_level_name` | `string` | Optional | The name of the service level used. |

## Example (as JSON)

```json
{
  "carrierClientContractId": null,
  "carrierName": null,
  "carrierServiceLevelId": null,
  "carrierServiceLevelName": null
}
```

