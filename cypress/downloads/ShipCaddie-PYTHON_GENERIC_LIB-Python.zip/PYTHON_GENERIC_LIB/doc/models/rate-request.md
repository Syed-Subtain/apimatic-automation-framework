
# Rate Request

Shipment Information used to request a rate.

## Structure

`RateRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `access_token` | `string` | Optional | Authorization Token obtained from Security Token. |
| `as_client_id` | `int` | Optional | Optional.  When present, the request will be made for the specified client. |
| `shipping_info` | [`ShippingInformation`](/doc/models/shipping-information.md) | Optional | Shipment Information used to request a rate. |

## Example (as JSON)

```json
{
  "accessToken": "YOUR ACCESS TOKEN",
  "shippingInfo": {
    "carrierClientContractId": 2526,
    "serviceLevelId": 0,
    "dateShipped": "2020-12-23T23:54:10.2649036Z",
    "options": {
      "isAPO_FPO_DPO_USTerritory": false,
      "isInternationalShipment": false,
      "shipmentContentType": "CONTENT_TYPE_SAMPLE"
    },
    "addressFrom": {
      "companyName": "iDrive Logistics",
      "email": "sales@idrivelogistics.com",
      "phoneNumber": "(888) 797-0929",
      "address1": "2600 Executive Pkwy #160",
      "address2": "",
      "city": "Lehi",
      "stateOrProvince": "UT",
      "postalCode": "84043",
      "countryCode": "US"
    },
    "addressTo": {
      "attentionOf": "Mr. Jones",
      "companyName": "iDrive Logistics",
      "email": "",
      "phoneNumber": "",
      "address1": "2605 Executive Pkwy #160",
      "address2": "",
      "isResidential": false,
      "city": "Lehi",
      "stateOrProvince": "UT",
      "postalCode": "84043",
      "countryCode": "US"
    },
    "parcels": [
      {
        "packagingId": "",
        "weightInPounds": 0.4,
        "lengthInInches": 5.0,
        "widthInInches": 4.0,
        "heightInInches": 12.0,
        "options": {
          "return": "NOT_APPLICABLE",
          "insuranceAmount": 0.0,
          "signature": "NOT_APPLICABLE",
          "cod": {
            "codType": "NOT_APPLICABLE",
            "codAmount": 0.0
          },
          "machinable": true,
          "holdForPickup": false
        }
      }
    ]
  }
}
```

