
# Duties Paid by Enum

Indicates who will pay for any applicable duties.

## Enumeration

`DutiesPaidByEnum`

## Fields

| Name |
|  --- |
| `NOT_APPLICABLE` |
| `PAID_BY_SHIPPER` |
| `PAID_BY_RECIPIENT` |
| `PAID_BY_THIRD_PARTY` |

