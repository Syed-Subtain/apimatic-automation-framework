
# User Register Modelv 21

## Structure

`UserRegisterModelv21`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `system_country_id` | `int` | Optional | Country of Origin |
| `name_first` | `string` | Optional | Required.<br>First Name<br>Max Length: 25 |
| `name_last` | `string` | Optional | Required.<br>Last Name<br>Max Length: 35 |
| `company_name` | `string` | Optional | Company Name<br>Max Length: 50 |
| `phone_number` | `string` | Optional | Phone Number |
| `user_name` | `string` | Optional | Required.<br>User name |
| `password` | `string` | Optional | Required.<br>Max Length: 100<br>Min Length: 8<br>Password |
| `password_verify` | `string` | Optional | Confirm password |
| `promo_code` | `string` | Optional | Promo Code |
| `subscription_tier_id` | `int` | Optional | Subscription Tier |
| `i_agree` | `string` | Optional | - |

## Example (as JSON)

```json
{
  "systemCountryId": null,
  "nameFirst": null,
  "nameLast": null,
  "companyName": null,
  "phoneNumber": null,
  "userName": null,
  "password": null,
  "passwordVerify": null,
  "promoCode": null,
  "subscriptionTierId": null,
  "iAgree": null
}
```

