
# Validate Address Responsev 21

## Structure

`ValidateAddressResponsev21`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `address_is_validated` | `bool` | Required | True if address is valid.  False otherwise. |
| `validation_messages` | [`List of AddressValidationInformation`](/doc/models/address-validation-information.md) | Required | Informative Messages regarding Address Validation. |
| `validated_address` | [`Addressv21`](/doc/models/addressv-21.md) | Required | - |
| `error` | [`RequestError`](/doc/models/request-error.md) | Required | This information can be used to determine if an error has occurred when a request was processed. |

## Example (as JSON)

```json
{
  "addressIsValidated": false,
  "validationMessages": [
    {
      "code": "code6",
      "message": "message8"
    },
    {
      "code": "code7",
      "message": "message9"
    }
  ],
  "validatedAddress": {
    "address1": "address12",
    "address2": null,
    "city": "city6",
    "countryCode": "countryCode0",
    "stateOrProvidence": "stateOrProvidence0",
    "postalCode": "postalCode4",
    "isResidential": null,
    "attentionOf": null,
    "companyName": null,
    "email": null,
    "phoneNumber": null
  },
  "error": {
    "details": null,
    "hasError": false
  }
}
```

