
# Shipment Content Type Enum

Indicates the type of content that is in the parcels.
Will be used for customs declarations if shipping internationally.

## Enumeration

`ShipmentContentTypeEnum`

## Fields

| Name |
|  --- |
| `NOT_APPLICABLE` |
| `CONTENT_TYPE_SAMPLE` |
| `CONTENT_TYPE_DOCUMENTS` |
| `CONTENT_TYPE_GIFT` |
| `CONTENT_TYPE_MERCHANDISE` |
| `CONTENT_TYPE_RETURNEDGOODS` |
| `CONTENT_TYPE_OTHER` |

