
# Certify Test Override Enum

CertifyTestOverride : Force a Label to overriding what is in the contract

## Enumeration

`CertifyTestOverrideEnum`

## Fields

| Name |
|  --- |
| `CONTRACT` |
| `FORCELIVE` |
| `FORCETEST` |

