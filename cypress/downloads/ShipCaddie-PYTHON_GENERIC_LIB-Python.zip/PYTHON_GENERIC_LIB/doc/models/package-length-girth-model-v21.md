
# Package Length Girth Model V21

## Structure

`PackageLengthGirthModelV21`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `carrier_service_level_id` | `int` | Optional | Required - CarrierServiceLevelId |
| `package_list` | [`List of PackagesV21`](/doc/models/packages-v21.md) | Optional | List of Packages |

## Example (as JSON)

```json
{
  "carrierServiceLevelId": null,
  "packageList": null
}
```

