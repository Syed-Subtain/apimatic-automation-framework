
# Parcel Options

Specifies additional parcel options such as COD and required Signatures.

## Structure

`ParcelOptions`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `mreturn` | [`ReturnEnum`](/doc/models/return-enum.md) | Optional | Indicates if this is a return parcel.<br>and if so what type of return should be used. |
| `insurance_amount` | `float` | Optional | Amount of insurance in US currency |
| `signature` | [`SignatureEnum`](/doc/models/signature-enum.md) | Optional | Indicates if a signature is required,<br>and if so what type of signature should be used. |
| `cod` | [`CODOptions`](/doc/models/cod-options.md) | Optional | Optional Cash on Demand |
| `machinable` | `bool` | Optional | If True, package is machinable. (Default). If false, package is non-machinable.<br>Default null |
| `hold_for_pickup` | `bool` | Optional | The Hold For Pickup service allows mailpieces to be held at a designated Post Office location for pickup by a specified addressee or designee<br>Default null |

## Example (as JSON)

```json
{
  "return": null,
  "insuranceAmount": null,
  "signature": null,
  "cod": null,
  "machinable": null,
  "holdForPickup": null
}
```

