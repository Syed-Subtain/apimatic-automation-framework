# Address Validation Shipment

```python
address_validation_shipment_controller = client.address_validation_shipment
```

## Class Name

`AddressValidationShipmentController`


# Validate Shipment Address

Use this function to validate an address.

```python
def validate_shipment_address(self,
                             input=None)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `input` | [`ValidateShipmentAddressRequest`](/doc/models/validate-shipment-address-request.md) | Body, Optional | - |

## Response Type

[`AddressValidationResponseReturnModel`](/doc/models/address-validation-response-return-model.md)

## Example Usage

```python
input = ValidateShipmentAddressRequest()
input.access_token = '<YOUR ACCESS TOKEN>'
input.as_client_id = 14
input.shipment_address_to_validate = AddressValidationRequestModel()
input.shipment_address_to_validate.carrier_id = 4
input.shipment_address_to_validate.carrier_contract_id = 2324
input.shipment_address_to_validate.addresses = []

input.shipment_address_to_validate.addresses.append(AddressValidationModel())
input.shipment_address_to_validate.addresses[0].address_1 = '2600 Executive Parkway'
input.shipment_address_to_validate.addresses[0].address_2 = 'Suite 160'
input.shipment_address_to_validate.addresses[0].province_code = 'UT'
input.shipment_address_to_validate.addresses[0].city = 'Lehi'
input.shipment_address_to_validate.addresses[0].country_code = 'US'
input.shipment_address_to_validate.addresses[0].postal_code = '84043'
input.shipment_address_to_validate.addresses[0].address_type_id = AddressTypeIdEnum.COMMERCIAL
input.shipment_address_to_validate.addresses[0].company_name = 'iDrive Logistics'
input.shipment_address_to_validate.addresses[0].country_id = 0
input.shipment_address_to_validate.addresses[0].address_status = False


result = address_validation_shipment_controller.validate_shipment_address(input)
```

