# Registration

```python
registration_controller = client.registration
```

## Class Name

`RegistrationController`


# Register Account

Allows a registration of a new account.

```python
def register_account(self,
                    input=None)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `input` | [`RegisterAccountLimitRequestv21`](/doc/models/register-account-limit-requestv-21.md) | Body, Optional | - |

## Response Type

[`RegisterAccountResponsev21`](/doc/models/register-account-responsev-21.md)

## Example Usage

```python
input = RegisterAccountLimitRequestv21()
input.registration_information = UserRegisterModelv21()
input.registration_information.system_country_id = 840
input.registration_information.name_first = 'Tom'
input.registration_information.name_last = 'Thomson'
input.registration_information.company_name = 'Ace'
input.registration_information.phone_number = '123 456-7890'
input.registration_information.user_name = 'User Name'
input.registration_information.password = 'Password'
input.registration_information.password_verify = 'Password'
input.registration_information.promo_code = ''
input.registration_information.subscription_tier_id = 1
input.registration_information.i_agree = 'yes'

result = registration_controller.register_account(input)
```

## Example Response *(as JSON)*

```json
{
  "error": {
    "details": [],
    "hasError": false
  },
  "success": true
}
```

