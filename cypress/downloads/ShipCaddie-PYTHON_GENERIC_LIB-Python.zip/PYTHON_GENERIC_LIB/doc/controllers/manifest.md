# Manifest

```python
manifest_controller = client.manifest
```

## Class Name

`ManifestController`

## Methods

* [Manifest](/doc/controllers/manifest.md#manifest)
* [Generate](/doc/controllers/manifest.md#generate)
* [Regenerate](/doc/controllers/manifest.md#regenerate)
* [Scan Form History](/doc/controllers/manifest.md#scan-form-history)
* [Available Shipments](/doc/controllers/manifest.md#available-shipments)
* [Scan Form Generate](/doc/controllers/manifest.md#scan-form-generate)


# Manifest

Manifest:    Create end-of-day Manifest / Scan Form (USPS).

```python
def manifest(self,
            input=None)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `input` | [`ScanFormHistoryByIDRequestv21`](/doc/models/scan-form-history-by-id-requestv-21.md) | Body, Optional | - |

## Response Type

[`ScanFormHistoryByIDResponsev21`](/doc/models/scan-form-history-by-id-responsev-21.md)

## Example Usage

```python
input = ScanFormHistoryByIDRequestv21()
input.access_token = '<YOUR ACCESS TOKEN>'
input.scan_form_id = 23

result = manifest_controller.manifest(input)
```

## Example Response *(as JSON)*

```json
{
  "error": {
    "details": [],
    "hasError": false
  },
  "scanFormInformation": {
    "id": 12,
    "scanFormId": "ScanFormID",
    "batchId": "BatchID",
    "clientId": 12,
    "shipmentClientAddressId": 747,
    "shipDate": "2020-12-23T23:54:10.3273331+00:00",
    "scanFormDataType": "imagePng",
    "carrierClientContractId": 2526,
    "carrierClientContractName": "Test",
    "shipmentClientAddressLine1": "",
    "shipmentClientAddressLine2": "",
    "shipmentClientAddressProvince": "",
    "shipmentClientAddressCity": "",
    "shipmentClientAddressPostalCode": "",
    "shippingSiteName": "",
    "dateCreated": "2020-12-23T23:54:10.3273331+00:00",
    "printJobs": [
      {
        "printTemplateType": "Template Type",
        "dataBlocks": []
      }
    ],
    "excludedItems": {}
  }
}
```


# Generate

Generate:    Obtain a ScanForm

```python
def generate(self,
            input=None)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `input` | [`GenerateRequestv21`](/doc/models/generate-requestv-21.md) | Body, Optional | - |

## Response Type

[`GenerateResponsev21`](/doc/models/generate-responsev-21.md)

## Example Usage

```python
input = GenerateRequestv21()
input.access_token = '<YOUR ACCESS TOKEN>'
input.scan_form_request = ScanFormModelRequest()
input.scan_form_request.carrier_client_contract_id = 2526
input.scan_form_request.shipment_client_address_id = 747
input.scan_form_request.ship_date = dateutil.parser.parse('2017-11-29T00:00:00')
input.scan_form_request.key_list = []

input.scan_form_request.key_list.append(KeyValues())
input.scan_form_request.key_list[0].label_key = 'shp_810c212e2dcf4863a1bd8495f9a54d81'
input.scan_form_request.key_list[0].tracking_number = '9400136895239112753275'
input.scan_form_request.key_list[0].package_id = 366974

input.scan_form_request.recent_scan_form_id = 0

result = manifest_controller.generate(input)
```

## Example Response *(as JSON)*

```json
{
  "error": {
    "details": [],
    "hasError": false
  },
  "scanFormInformation": {
    "id": 12,
    "scanFormId": "ScanFormID",
    "batchId": "BatchID",
    "clientId": 12,
    "shipmentClientAddressId": 747,
    "shipDate": "2020-12-23T23:54:10.1867682+00:00",
    "scanFormDataType": "imagePng",
    "carrierClientContractId": 2526,
    "carrierClientContractName": "Test",
    "shipmentClientAddressLine1": "",
    "shipmentClientAddressLine2": "",
    "shipmentClientAddressProvince": "",
    "shipmentClientAddressCity": "",
    "shipmentClientAddressPostalCode": "",
    "shippingSiteName": "",
    "dateCreated": "2020-12-23T23:54:10.1867682+00:00",
    "printJobs": [
      {
        "printTemplateType": "Template Type",
        "dataBlocks": []
      }
    ],
    "excludedItems": {}
  }
}
```


# Regenerate

Regenerate:    Obtain a ScanForm

```python
def regenerate(self,
              input=None)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `input` | [`RegenerateRequestv21`](/doc/models/regenerate-requestv-21.md) | Body, Optional | - |

## Response Type

[`RegenerateResponsev21`](/doc/models/regenerate-responsev-21.md)

## Example Usage

```python
input = RegenerateRequestv21()
input.access_token = '<YOUR ACCESS TOKEN>'
input.is_regenerate = False
input.scan_form_request = ScanFormModelRequest()
input.scan_form_request.carrier_client_contract_id = 2526
input.scan_form_request.shipment_client_address_id = 747
input.scan_form_request.ship_date = dateutil.parser.parse('2017-11-29T00:00:00')
input.scan_form_request.key_list = []

input.scan_form_request.key_list.append(KeyValues())
input.scan_form_request.key_list[0].label_key = 'shp_810c212e2dcf4863a1bd8495f9a54d81'
input.scan_form_request.key_list[0].tracking_number = '9400136895239112753275'
input.scan_form_request.key_list[0].package_id = 366974

input.scan_form_request.recent_scan_form_id = 0

result = manifest_controller.regenerate(input)
```

## Example Response *(as JSON)*

```json
{
  "error": {
    "details": [],
    "hasError": false
  },
  "scanFormInformation": {
    "id": 12,
    "scanFormId": "ScanFormID",
    "batchId": "BatchID",
    "clientId": 12,
    "shipmentClientAddressId": 747,
    "shipDate": "2020-12-23T23:54:10.3273331+00:00",
    "scanFormDataType": "imagePng",
    "carrierClientContractId": 2526,
    "carrierClientContractName": "Test",
    "shipmentClientAddressLine1": "",
    "shipmentClientAddressLine2": "",
    "shipmentClientAddressProvince": "",
    "shipmentClientAddressCity": "",
    "shipmentClientAddressPostalCode": "",
    "shippingSiteName": "",
    "dateCreated": "2020-12-23T23:54:10.3273331+00:00",
    "printJobs": [
      {
        "printTemplateType": "Template Type",
        "dataBlocks": []
      }
    ],
    "excludedItems": {}
  }
}
```


# Scan Form History

ScanForm_History:         Get the end-of-day Manifests / Scan Forms (USPS)

```python
def scan_form_history(self,
                     input=None)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `input` | [`ScanFormHistoryRequestv21`](/doc/models/scan-form-history-requestv-21.md) | Body, Optional | - |

## Response Type

[`ScanFormHistoryResponsev21`](/doc/models/scan-form-history-responsev-21.md)

## Example Usage

```python
input = ScanFormHistoryRequestv21()
input.access_token = '<YOUR ACCESS TOKEN>'

result = manifest_controller.scan_form_history(input)
```

## Example Response *(as JSON)*

```json
{
  "error": {
    "details": [],
    "hasError": false
  },
  "scanFormList": [
    {
      "id": 12,
      "scanFormId": "ScanFormID",
      "batchId": "BatchID",
      "clientId": 12,
      "shipmentClientAddressId": 747,
      "shipDate": "2020-12-23T23:54:10.3585858+00:00",
      "scanFormDataType": "imagePng",
      "carrierClientContractId": 2526,
      "carrierClientContractName": "Test",
      "shipmentClientAddressLine1": "",
      "shipmentClientAddressLine2": "",
      "shipmentClientAddressProvince": "",
      "shipmentClientAddressCity": "",
      "shipmentClientAddressPostalCode": "",
      "shippingSiteName": "",
      "dateCreated": "2020-12-23T23:54:10.3585858+00:00",
      "printJobs": [
        {
          "printTemplateType": "Template Type",
          "dataBlocks": []
        }
      ],
      "excludedItems": {}
    }
  ]
}
```


# Available Shipments

AvailableShipments:    Gets Available Shipments

```python
def available_shipments(self,
                       input=None)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `input` | [`AvailableShipmentsRequestv21`](/doc/models/available-shipments-requestv-21.md) | Body, Optional | - |

## Response Type

[`AvailableShipmentsResponsev21`](/doc/models/available-shipments-responsev-21.md)

## Example Usage

```python
input = AvailableShipmentsRequestv21()
input.access_token = '<YOUR ACCESS TOKEN>'
input.as_client_id = 12
input.carrier_client_contract_id = 34
input.address_id = 23
input.ship_date = dateutil.parser.parse('2020-12-23T23:54:10.1554517+00:00')

result = manifest_controller.available_shipments(input)
```

## Example Response *(as JSON)*

```json
{
  "error": {
    "details": [],
    "hasError": false
  },
  "availableShipments": [
    {
      "carrierClientContractId": 14,
      "shipmentId": 23,
      "packageId": 45,
      "shipmentClientAddressId": 52,
      "dateShipped": "2020-12-23T23:54:10.1554517+00:00",
      "fromShippingSiteName": "Shipping Site Name",
      "toAddressLine1": "564 Drury Lane",
      "toAddressLine2": "",
      "toPostalCode": "95654",
      "toProvince": "CA",
      "toCity": "LA",
      "accountAlias": "",
      "labelKey": "fds32y4rddaf",
      "trackingNumber": "565489079094"
    }
  ]
}
```


# Scan Form Generate

ScanForm_Generate:         Get Manifests / Scan Forms (USPS)

```python
def scan_form_generate(self,
                      input=None)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `input` | [`ScanFormGenerateRequestv21`](/doc/models/scan-form-generate-requestv-21.md) | Body, Optional | - |

## Response Type

[`ScanFormGenerateResponsev21`](/doc/models/scan-form-generate-responsev-21.md)

## Example Usage

```python
input = ScanFormGenerateRequestv21()
input.access_token = '<YOUR ACCESS TOKEN>'
input.scan_form_request = ScanFormModelRequest()
input.scan_form_request.carrier_client_contract_id = 2526
input.scan_form_request.shipment_client_address_id = 747
input.scan_form_request.ship_date = dateutil.parser.parse('2017-11-29T00:00:00')
input.scan_form_request.key_list = []

input.scan_form_request.key_list.append(KeyValues())
input.scan_form_request.key_list[0].label_key = 'shp_810c212e2dcf4863a1bd8495f9a54d81'
input.scan_form_request.key_list[0].tracking_number = '9400136895239112753275'
input.scan_form_request.key_list[0].package_id = 366974

input.scan_form_request.recent_scan_form_id = 0

result = manifest_controller.scan_form_generate(input)
```

## Example Response *(as JSON)*

```json
{
  "error": {
    "details": [],
    "hasError": false
  },
  "scanFormInformation": {
    "id": 12,
    "scanFormId": "ScanFormID",
    "batchId": "BatchID",
    "clientId": 12,
    "shipmentClientAddressId": 747,
    "shipDate": "2020-12-23T23:54:10.3585858+00:00",
    "scanFormDataType": "imagePng",
    "carrierClientContractId": 2526,
    "carrierClientContractName": "Test",
    "shipmentClientAddressLine1": "",
    "shipmentClientAddressLine2": "",
    "shipmentClientAddressProvince": "",
    "shipmentClientAddressCity": "",
    "shipmentClientAddressPostalCode": "",
    "shippingSiteName": "",
    "dateCreated": "2020-12-23T23:54:10.3585858+00:00",
    "printJobs": [
      {
        "printTemplateType": "Template Type",
        "dataBlocks": []
      }
    ],
    "excludedItems": {}
  }
}
```

