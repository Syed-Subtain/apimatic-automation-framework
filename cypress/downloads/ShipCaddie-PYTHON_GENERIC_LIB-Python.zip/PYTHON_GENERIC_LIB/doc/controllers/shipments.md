# Shipments

```python
shipments_controller = client.shipments
```

## Class Name

`ShipmentsController`

## Methods

* [Update Shipment](/doc/controllers/shipments.md#update-shipment)
* [Delete Shipment by ID](/doc/controllers/shipments.md#delete-shipment-by-id)
* [Get Shipment Items by Sku](/doc/controllers/shipments.md#get-shipment-items-by-sku)
* [Add Shipment](/doc/controllers/shipments.md#add-shipment)
* [Get Shipment Information](/doc/controllers/shipments.md#get-shipment-information)
* [Get Shipped Info](/doc/controllers/shipments.md#get-shipped-info)


# Update Shipment

UpdateShipment:    Updates existing Shipment information

```python
def update_shipment(self,
                   input=None)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `input` | [`UpdateShipmentRequest`](/doc/models/update-shipment-request.md) | Body, Optional | - |

## Response Type

[`ShippingCostData`](/doc/models/shipping-cost-data.md)

## Example Usage

```python
input = UpdateShipmentRequest()
input.access_token = '<YOUR ACCESS TOKEN>'
input.as_client_id = 12
input.shipment_id = 37
input.shipment = ShipmentInformation()
input.shipment.order_reference_number = 'test order'
input.shipment.date_shipped = dateutil.parser.parse('2020-12-23T23:54:10.3585858Z')
input.shipment.options = ShippingOptions()
input.shipment.options.is_apo_fpo_dpo_us_territory = False
input.shipment.options.is_international_shipment = False
input.shipment.options.billing = BillingOptions()
input.shipment.options.billing.shipping_paid_by = ShippingPaidByEnum.NOT_APPLICABLE
input.shipment.options.billing.account_number = ''
input.shipment.options.billing.postal_code = ''
input.shipment.options.billing.country_alpha_2_code = ''
input.shipment.options.billing.duties_paid_by = DutiesPaidByEnum.NOT_APPLICABLE
input.shipment.options.shipment_content_type = ShipmentContentTypeEnum.CONTENT_TYPE_SAMPLE
input.shipment.carrier_client_contract_id = 2404
input.shipment.carrier_service_level_id = 1115
input.shipment.address_from = ShipFromAddress()
input.shipment.address_from.company_name = 'iDrive Logistics'
input.shipment.address_from.email = 'sales@idrivelogistics.com'
input.shipment.address_from.phone_number = '(888) 797-0929'
input.shipment.address_from.address_1 = '2600 Executive Pkwy #160'
input.shipment.address_from.address_2 = ''
input.shipment.address_from.city = 'Lehi'
input.shipment.address_from.state_or_province = 'UT'
input.shipment.address_from.postal_code = '84043'
input.shipment.address_from.country_code = 'US'
input.shipment.address_to = ShipToAddress()
input.shipment.address_to.attention_of = 'Mr. Jones'
input.shipment.address_to.company_name = 'iDrive Logistics'
input.shipment.address_to.email = 'sales@idrivelogistics.com'
input.shipment.address_to.phone_number = '(888) 797-0929'
input.shipment.address_to.address_1 = '2605 Executive Pkwy #160'
input.shipment.address_to.address_2 = ''
input.shipment.address_to.is_residential = False
input.shipment.address_to.city = 'Lehi'
input.shipment.address_to.state_or_province = 'UT'
input.shipment.address_to.postal_code = '84043'
input.shipment.address_to.country_code = 'US'
input.shipment.parcels = []

input.shipment.parcels.append(ParcelDetail())
input.shipment.parcels[0].reference_field_1 = '1'
input.shipment.parcels[0].reference_field_2 = ''
input.shipment.parcels[0].reference_field_3 = ''
input.shipment.parcels[0].parcel_id = '1'
input.shipment.parcels[0].packaging_id = ''
input.shipment.parcels[0].weight_in_pounds = 0.4
input.shipment.parcels[0].length_in_inches = 5
input.shipment.parcels[0].width_in_inches = 4
input.shipment.parcels[0].height_in_inches = 12
input.shipment.parcels[0].options = ParcelOptions()
input.shipment.parcels[0].options.mreturn = ReturnEnum.NOT_APPLICABLE
input.shipment.parcels[0].options.insurance_amount = 0
input.shipment.parcels[0].options.signature = SignatureEnum.NOT_APPLICABLE
input.shipment.parcels[0].options.cod = CODOptions()
input.shipment.parcels[0].options.cod.cod_type = CodTypeEnum.NOT_APPLICABLE
input.shipment.parcels[0].options.cod.cod_amount = 0
input.shipment.parcels[0].parcel_items = []

input.shipment.parcels[0].parcel_items.append(ParcelContent())
input.shipment.parcels[0].parcel_items[0].sku = 'none'
input.shipment.parcels[0].parcel_items[0].name = 'chocolate'
input.shipment.parcels[0].parcel_items[0].description = 'candy'
input.shipment.parcels[0].parcel_items[0].quantity = 7
input.shipment.parcels[0].parcel_items[0].price = 1.03
input.shipment.parcels[0].parcel_items[0].weight_in_pounds = 0.5
input.shipment.parcels[0].parcel_items[0].harmonize_code = ''
input.shipment.parcels[0].parcel_items[0].origin_country = 'US'



result = shipments_controller.update_shipment(input)
```

## Example Response *(as JSON)*

```json
{
  "shippingCost": {
    "shipmentId": 12,
    "orderReferenceNumber": "123",
    "parcelChargeDetails": [
      {
        "parcelID": "1",
        "costDetails": [
          {
            "name": "FREIGHT",
            "amount": 3.23,
            "amountDisplay": 0.0
          }
        ]
      }
    ],
    "shippingChargeDetails": [
      {
        "name": "Charge",
        "amount": 2.34,
        "amountDisplay": 0.0
      }
    ],
    "transitDaysMin": -1,
    "transitDaysMax": -1,
    "totalChargeAmount": -1.0,
    "isDeliveryGuaranteed": false
  },
  "error": {
    "details": [],
    "hasError": false
  }
}
```


# Delete Shipment by ID

```python
def delete_shipment_by_id(self,
                         input=None)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `input` | [`ShipmentRequestByID`](/doc/models/shipment-request-by-id.md) | Body, Optional | - |

## Response Type

[`DeleteShipmentResult`](/doc/models/delete-shipment-result.md)

## Example Usage

```python
input = ShipmentRequestByID()
input.access_token = '<YOUR ACCESS TOKEN>'
input.as_client_id = 12
input.shipment_id = 37

result = shipments_controller.delete_shipment_by_id(input)
```

## Example Response *(as JSON)*

```json
{
  "shipmentId": 23,
  "isDeleted": true,
  "error": {
    "details": [],
    "hasError": false
  }
}
```


# Get Shipment Items by Sku

This method can be used to get the shipments inventeries by sku within given date range.

```python
def get_shipment_items_by_sku(self,
                             input=None)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `input` | [`ShipmentRequestByDate`](/doc/models/shipment-request-by-date.md) | Body, Optional | - |

## Response Type

[`ShipmentInventoryBySkuResponseModel`](/doc/models/shipment-inventory-by-sku-response-model.md)

## Example Usage

```python
input = ShipmentRequestByDate()
input.access_token = '<YOUR ACCESS TOKEN>'
input.as_client_id = 12
input.start_date = dateutil.parser.parse('2020-12-23T23:54:10.2804606+00:00')
input.end_date = dateutil.parser.parse('2020-12-23T23:54:10.2804606+00:00')

result = shipments_controller.get_shipment_items_by_sku(input)
```

## Example Response *(as JSON)*

```json
{
  "shipmentInventoryBySku_Response": [
    {
      "sku": "TestSku1",
      "name": "TestName",
      "qty": 2,
      "dateShipped": "0001-01-01T00:00:00"
    },
    {
      "sku": "TestSku2",
      "name": "TestName2",
      "qty": 5,
      "dateShipped": "0001-01-01T00:00:00"
    }
  ],
  "error": {
    "details": [],
    "hasError": false
  }
}
```


# Add Shipment

After successfully adding a shipment request,
use the Get Shipping Labels by ShippingID
to get the shipping label.

```python
def add_shipment(self,
                input=None)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `input` | [`AddShipmentRequest`](/doc/models/add-shipment-request.md) | Body, Optional | - |

## Response Type

[`ShippingCostData`](/doc/models/shipping-cost-data.md)

## Example Usage

```python
input = AddShipmentRequest()
input.access_token = '<YOUR ACCESS TOKEN>'
input.as_client_id = 12
input.shipment = ShipmentInformation()
input.shipment.order_reference_number = 'test order'
input.shipment.date_shipped = dateutil.parser.parse('2020-12-23T23:54:10.0929416Z')
input.shipment.options = ShippingOptions()
input.shipment.options.is_apo_fpo_dpo_us_territory = False
input.shipment.options.is_international_shipment = False
input.shipment.options.billing = BillingOptions()
input.shipment.options.billing.shipping_paid_by = ShippingPaidByEnum.NOT_APPLICABLE
input.shipment.options.billing.account_number = ''
input.shipment.options.billing.postal_code = ''
input.shipment.options.billing.country_alpha_2_code = ''
input.shipment.options.billing.duties_paid_by = DutiesPaidByEnum.NOT_APPLICABLE
input.shipment.options.shipment_content_type = ShipmentContentTypeEnum.CONTENT_TYPE_SAMPLE
input.shipment.carrier_client_contract_id = 2404
input.shipment.carrier_service_level_id = 1115
input.shipment.address_from = ShipFromAddress()
input.shipment.address_from.company_name = 'iDrive Logistics'
input.shipment.address_from.email = 'sales@idrivelogistics.com'
input.shipment.address_from.phone_number = '(888) 797-0929'
input.shipment.address_from.address_1 = '2600 Executive Pkwy #160'
input.shipment.address_from.address_2 = ''
input.shipment.address_from.city = 'Lehi'
input.shipment.address_from.state_or_province = 'UT'
input.shipment.address_from.postal_code = '84043'
input.shipment.address_from.country_code = 'US'
input.shipment.address_to = ShipToAddress()
input.shipment.address_to.attention_of = 'Mr. Jones'
input.shipment.address_to.company_name = 'iDrive Logistics'
input.shipment.address_to.email = 'sales@idrivelogistics.com'
input.shipment.address_to.phone_number = '(888) 797-0929'
input.shipment.address_to.address_1 = '2605 Executive Pkwy #160'
input.shipment.address_to.address_2 = ''
input.shipment.address_to.is_residential = False
input.shipment.address_to.city = 'Lehi'
input.shipment.address_to.state_or_province = 'UT'
input.shipment.address_to.postal_code = '84043'
input.shipment.address_to.country_code = 'US'
input.shipment.parcels = []

input.shipment.parcels.append(ParcelDetail())
input.shipment.parcels[0].reference_field_1 = '1'
input.shipment.parcels[0].reference_field_2 = ''
input.shipment.parcels[0].reference_field_3 = ''
input.shipment.parcels[0].parcel_id = '1'
input.shipment.parcels[0].packaging_id = ''
input.shipment.parcels[0].weight_in_pounds = 0.4
input.shipment.parcels[0].length_in_inches = 5
input.shipment.parcels[0].width_in_inches = 4
input.shipment.parcels[0].height_in_inches = 12
input.shipment.parcels[0].options = ParcelOptions()
input.shipment.parcels[0].options.mreturn = ReturnEnum.NOT_APPLICABLE
input.shipment.parcels[0].options.insurance_amount = 0
input.shipment.parcels[0].options.signature = SignatureEnum.NOT_APPLICABLE
input.shipment.parcels[0].options.cod = CODOptions()
input.shipment.parcels[0].options.cod.cod_type = CodTypeEnum.NOT_APPLICABLE
input.shipment.parcels[0].options.cod.cod_amount = 0
input.shipment.parcels[0].parcel_items = []

input.shipment.parcels[0].parcel_items.append(ParcelContent())
input.shipment.parcels[0].parcel_items[0].sku = 'none'
input.shipment.parcels[0].parcel_items[0].name = 'chocolate'
input.shipment.parcels[0].parcel_items[0].description = 'candy'
input.shipment.parcels[0].parcel_items[0].quantity = 7
input.shipment.parcels[0].parcel_items[0].price = 1.03
input.shipment.parcels[0].parcel_items[0].weight_in_pounds = 0.5
input.shipment.parcels[0].parcel_items[0].harmonize_code = ''
input.shipment.parcels[0].parcel_items[0].origin_country = 'US'



result = shipments_controller.add_shipment(input)
```

## Example Response *(as JSON)*

```json
{
  "shippingCost": {
    "shipmentId": 12,
    "orderReferenceNumber": "123",
    "parcelChargeDetails": [
      {
        "parcelID": "1",
        "costDetails": [
          {
            "name": "FREIGHT",
            "amount": 3.23,
            "amountDisplay": 0.0
          }
        ]
      }
    ],
    "shippingChargeDetails": [
      {
        "name": "Charge",
        "amount": 2.34,
        "amountDisplay": 0.0
      }
    ],
    "transitDaysMin": -1,
    "transitDaysMax": -1,
    "totalChargeAmount": -1.0,
    "isDeliveryGuaranteed": false
  },
  "error": {
    "details": [],
    "hasError": false
  }
}
```


# Get Shipment Information

This method can be used to get the information necessary to update a shipment.

```python
def get_shipment_information(self,
                            input=None)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `input` | [`ShipmentRequestByID`](/doc/models/shipment-request-by-id.md) | Body, Optional | - |

## Response Type

[`ShipmentInformationResponse`](/doc/models/shipment-information-response.md)

## Example Usage

```python
input = ShipmentRequestByID()
input.access_token = '<YOUR ACCESS TOKEN>'
input.as_client_id = 12
input.shipment_id = 37

result = shipments_controller.get_shipment_information(input)
```

## Example Response *(as JSON)*

```json
{
  "shipmentId": 37,
  "error": {
    "details": [],
    "hasError": false
  },
  "shipment": {
    "orderReferenceNumber": "test order",
    "dateShipped": "2020-12-23T23:54:10.2804606Z",
    "options": {
      "isAPO_FPO_DPO_USTerritory": false,
      "isInternationalShipment": false,
      "billing": {
        "shippingPaidBy": "NOT_APPLICABLE",
        "accountNumber": "",
        "postalCode": "",
        "country_Alpha2Code": "",
        "dutiesPaidBy": "NOT_APPLICABLE"
      },
      "shipmentContentType": "CONTENT_TYPE_SAMPLE"
    },
    "carrierClientContractId": 2404,
    "carrierServiceLevelId": 1115,
    "addressFrom": {
      "companyName": "iDrive Logistics",
      "email": "sales@idrivelogistics.com",
      "phoneNumber": "(888) 797-0929",
      "address1": "2600 Executive Pkwy #160",
      "address2": "",
      "city": "Lehi",
      "stateOrProvince": "UT",
      "postalCode": "84043",
      "countryCode": "US"
    },
    "addressTo": {
      "attentionOf": "Mr. Jones",
      "companyName": "iDrive Logistics",
      "email": "sales@idrivelogistics.com",
      "phoneNumber": "(888) 797-0929",
      "address1": "2605 Executive Pkwy #160",
      "address2": "",
      "isResidential": false,
      "city": "Lehi",
      "stateOrProvince": "UT",
      "postalCode": "84043",
      "countryCode": "US"
    },
    "parcels": [
      {
        "referenceField1": "1",
        "referenceField2": "",
        "referenceField3": "",
        "parcelID": "1",
        "packagingId": "",
        "weightInPounds": 0.4,
        "lengthInInches": 5.0,
        "widthInInches": 4.0,
        "heightInInches": 12.0,
        "options": {
          "return": "NOT_APPLICABLE",
          "insuranceAmount": 0.0,
          "signature": "NOT_APPLICABLE",
          "cod": {
            "codType": "NOT_APPLICABLE",
            "codAmount": 0.0
          }
        },
        "parcelItems": [
          {
            "sku": "none",
            "name": "chocolate",
            "description": "candy",
            "quantity": 7,
            "price": 1.03,
            "weightInPounds": 0.5,
            "harmonizeCode": "",
            "originCountry": "US"
          }
        ]
      }
    ]
  }
}
```


# Get Shipped Info

This method can be used to get the information about a shipped shipment.

```python
def get_shipped_info(self,
                    input=None)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `input` | [`ShippedInfoRequest`](/doc/models/shipped-info-request.md) | Body, Optional | - |

## Response Type

[`ShippedInfoResponse`](/doc/models/shipped-info-response.md)

## Example Usage

```python
result = shipments_controller.get_shipped_info()
```

## Example Response *(as JSON)*

```json
{
  "shipmentId": 37,
  "error": {
    "details": [],
    "hasError": false
  },
  "shipment": {
    "orderReferenceNumber": "test order",
    "dateShipped": "2020-12-23T23:54:10.2960842Z",
    "options": {
      "isAPO_FPO_DPO_USTerritory": false,
      "isInternationalShipment": false,
      "billing": {
        "shippingPaidBy": "NOT_APPLICABLE",
        "accountNumber": "",
        "postalCode": "",
        "country_Alpha2Code": "",
        "dutiesPaidBy": "NOT_APPLICABLE"
      },
      "shipmentContentType": "CONTENT_TYPE_SAMPLE"
    },
    "carrierClientContractId": 2404,
    "carrierServiceLevelId": 1115,
    "addressFrom": {
      "companyName": "iDrive Logistics",
      "email": "sales@idrivelogistics.com",
      "phoneNumber": "(888) 797-0929",
      "address1": "2600 Executive Pkwy #160",
      "address2": "",
      "city": "Lehi",
      "stateOrProvince": "UT",
      "postalCode": "84043",
      "countryCode": "US"
    },
    "addressTo": {
      "attentionOf": "Mr. Jones",
      "companyName": "iDrive Logistics",
      "email": "sales@idrivelogistics.com",
      "phoneNumber": "(888) 797-0929",
      "address1": "2605 Executive Pkwy #160",
      "address2": "",
      "isResidential": false,
      "city": "Lehi",
      "stateOrProvince": "UT",
      "postalCode": "84043",
      "countryCode": "US"
    },
    "parcels": [
      {
        "referenceField1": "1",
        "referenceField2": "",
        "referenceField3": "",
        "parcelID": "1",
        "packagingId": "",
        "weightInPounds": 0.4,
        "lengthInInches": 5.0,
        "widthInInches": 4.0,
        "heightInInches": 12.0,
        "options": {
          "return": "NOT_APPLICABLE",
          "insuranceAmount": 0.0,
          "signature": "NOT_APPLICABLE",
          "cod": {
            "codType": "NOT_APPLICABLE",
            "codAmount": 0.0
          }
        },
        "parcelItems": [
          {
            "sku": "none",
            "name": "chocolate",
            "description": "candy",
            "quantity": 7,
            "price": 1.03,
            "weightInPounds": 0.5,
            "harmonizeCode": "",
            "originCountry": "US"
          }
        ]
      }
    ]
  }
}
```

