# Account Information

```python
account_information_controller = client.account_information
```

## Class Name

`AccountInformationController`


# Get Carrier Balance

Includes:Threshold, Recharge Amount, and Balance.

```python
def get_carrier_balance(self,
                       input=None)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `input` | [`GetCarrierBalanceRequestv21`](/doc/models/get-carrier-balance-requestv-21.md) | Body, Optional | - |

## Response Type

[`GetCarrierBalanceResponsev21`](/doc/models/get-carrier-balance-responsev-21.md)

## Example Usage

```python
input = GetCarrierBalanceRequestv21()
input.access_token = '<YOUR ACCESS TOKEN>'
input.as_client_id = 12
input.carrier_client_contract_id = 34

result = account_information_controller.get_carrier_balance(input)
```

## Example Response *(as JSON)*

```json
{
  "threshold": 20.0,
  "rechargeAmount": 10.0,
  "balance": 23.45,
  "error": {
    "details": [],
    "hasError": false
  }
}
```

