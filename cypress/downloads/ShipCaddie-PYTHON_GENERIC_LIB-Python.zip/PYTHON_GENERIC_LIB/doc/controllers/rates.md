# Rates

```python
rates_controller = client.rates
```

## Class Name

`RatesController`

## Methods

* [Get Rates for All Carriers](/doc/controllers/rates.md#get-rates-for-all-carriers)
* [Get Rates](/doc/controllers/rates.md#get-rates)
* [Get Rates by Carrier](/doc/controllers/rates.md#get-rates-by-carrier)
* [Get Multiple Rates](/doc/controllers/rates.md#get-multiple-rates)


# Get Rates for All Carriers

Before creating a shipping label,
you can use this method to get a
break down of all shipping charges.
This allows you to determine
how much it would cost if you were to
actually send the parcels.

If the CarrierClientContractId is set to 0,
all carriers and service levels will be returned.

If the CarrierClientContractId is supplied but
the ServiceLevelId is set to 0 or not supplied,
only the specified carrier with all associated
service levels will be returned.

If the CarrierClientContractId is supplied and
the ServiceLevelId is also supplied,
only the specified carrier and service level
will be returned.

NOTE: HTTPS is Required to recieve a response.

```python
def get_rates_for_all_carriers(self,
                              rate_request=None)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `rate_request` | [`RateRequest`](/doc/models/rate-request.md) | Body, Optional | Shipping and parcel information<br>neccessary to calculate rates. |

## Response Type

[`List of RateResponse`](/doc/models/rate-response.md)

## Example Usage

```python
rate_request = RateRequest()
rate_request.access_token = 'YOUR ACCESS TOKEN'
rate_request.shipping_info = ShippingInformation()
rate_request.shipping_info.carrier_client_contract_id = 2526
rate_request.shipping_info.service_level_id = 0
rate_request.shipping_info.date_shipped = dateutil.parser.parse('2020-12-23T23:54:10.2649036Z')
rate_request.shipping_info.options = CustomsOptions()
rate_request.shipping_info.options.is_apo_fpo_dpo_us_territory = False
rate_request.shipping_info.options.is_international_shipment = False
rate_request.shipping_info.options.shipment_content_type = ShipmentContentTypeEnum.CONTENT_TYPE_SAMPLE
rate_request.shipping_info.address_from = ShipFromAddress()
rate_request.shipping_info.address_from.company_name = 'iDrive Logistics'
rate_request.shipping_info.address_from.email = 'sales@idrivelogistics.com'
rate_request.shipping_info.address_from.phone_number = '(888) 797-0929'
rate_request.shipping_info.address_from.address_1 = '2600 Executive Pkwy #160'
rate_request.shipping_info.address_from.address_2 = ''
rate_request.shipping_info.address_from.city = 'Lehi'
rate_request.shipping_info.address_from.state_or_province = 'UT'
rate_request.shipping_info.address_from.postal_code = '84043'
rate_request.shipping_info.address_from.country_code = 'US'
rate_request.shipping_info.address_to = ShipToAddress()
rate_request.shipping_info.address_to.attention_of = 'Mr. Jones'
rate_request.shipping_info.address_to.company_name = 'iDrive Logistics'
rate_request.shipping_info.address_to.email = ''
rate_request.shipping_info.address_to.phone_number = ''
rate_request.shipping_info.address_to.address_1 = '2605 Executive Pkwy #160'
rate_request.shipping_info.address_to.address_2 = ''
rate_request.shipping_info.address_to.is_residential = False
rate_request.shipping_info.address_to.city = 'Lehi'
rate_request.shipping_info.address_to.state_or_province = 'UT'
rate_request.shipping_info.address_to.postal_code = '84043'
rate_request.shipping_info.address_to.country_code = 'US'
rate_request.shipping_info.parcels = []

rate_request.shipping_info.parcels.append(ParcelInformation())
rate_request.shipping_info.parcels[0].packaging_id = ''
rate_request.shipping_info.parcels[0].weight_in_pounds = 0.4
rate_request.shipping_info.parcels[0].length_in_inches = 5
rate_request.shipping_info.parcels[0].width_in_inches = 4
rate_request.shipping_info.parcels[0].height_in_inches = 12
rate_request.shipping_info.parcels[0].options = ParcelOptions()
rate_request.shipping_info.parcels[0].options.mreturn = ReturnEnum.NOT_APPLICABLE
rate_request.shipping_info.parcels[0].options.insurance_amount = 0
rate_request.shipping_info.parcels[0].options.signature = SignatureEnum.NOT_APPLICABLE
rate_request.shipping_info.parcels[0].options.cod = CODOptions()
rate_request.shipping_info.parcels[0].options.cod.cod_type = CodTypeEnum.NOT_APPLICABLE
rate_request.shipping_info.parcels[0].options.cod.cod_amount = 0
rate_request.shipping_info.parcels[0].options.machinable = True
rate_request.shipping_info.parcels[0].options.hold_for_pickup = False


result = rates_controller.get_rates_for_all_carriers(rate_request)
```


# Get Rates

Before creating a shipping label,
you can use this method to get a
break down of all shipping charges.
This allows you to determine
how much it would cost if you were to
actually send the parcels.

NOTE: HTTPS is Required to recieve a response.

```python
def get_rates(self,
             rate_request=None)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `rate_request` | [`RateRequest`](/doc/models/rate-request.md) | Body, Optional | Shipping and parcel information<br>neccessary to calculate rates. |

## Response Type

[`RateResponse`](/doc/models/rate-response.md)

## Example Usage

```python
rate_request = RateRequest()
rate_request.access_token = 'YOUR ACCESS TOKEN'
rate_request.shipping_info = ShippingInformation()
rate_request.shipping_info.carrier_client_contract_id = 2526
rate_request.shipping_info.service_level_id = 0
rate_request.shipping_info.date_shipped = dateutil.parser.parse('2020-12-23T23:54:10.2649036Z')
rate_request.shipping_info.options = CustomsOptions()
rate_request.shipping_info.options.is_apo_fpo_dpo_us_territory = False
rate_request.shipping_info.options.is_international_shipment = False
rate_request.shipping_info.options.shipment_content_type = ShipmentContentTypeEnum.CONTENT_TYPE_SAMPLE
rate_request.shipping_info.address_from = ShipFromAddress()
rate_request.shipping_info.address_from.company_name = 'iDrive Logistics'
rate_request.shipping_info.address_from.email = 'sales@idrivelogistics.com'
rate_request.shipping_info.address_from.phone_number = '(888) 797-0929'
rate_request.shipping_info.address_from.address_1 = '2600 Executive Pkwy #160'
rate_request.shipping_info.address_from.address_2 = ''
rate_request.shipping_info.address_from.city = 'Lehi'
rate_request.shipping_info.address_from.state_or_province = 'UT'
rate_request.shipping_info.address_from.postal_code = '84043'
rate_request.shipping_info.address_from.country_code = 'US'
rate_request.shipping_info.address_to = ShipToAddress()
rate_request.shipping_info.address_to.attention_of = 'Mr. Jones'
rate_request.shipping_info.address_to.company_name = 'iDrive Logistics'
rate_request.shipping_info.address_to.email = ''
rate_request.shipping_info.address_to.phone_number = ''
rate_request.shipping_info.address_to.address_1 = '2605 Executive Pkwy #160'
rate_request.shipping_info.address_to.address_2 = ''
rate_request.shipping_info.address_to.is_residential = False
rate_request.shipping_info.address_to.city = 'Lehi'
rate_request.shipping_info.address_to.state_or_province = 'UT'
rate_request.shipping_info.address_to.postal_code = '84043'
rate_request.shipping_info.address_to.country_code = 'US'
rate_request.shipping_info.parcels = []

rate_request.shipping_info.parcels.append(ParcelInformation())
rate_request.shipping_info.parcels[0].packaging_id = ''
rate_request.shipping_info.parcels[0].weight_in_pounds = 0.4
rate_request.shipping_info.parcels[0].length_in_inches = 5
rate_request.shipping_info.parcels[0].width_in_inches = 4
rate_request.shipping_info.parcels[0].height_in_inches = 12
rate_request.shipping_info.parcels[0].options = ParcelOptions()
rate_request.shipping_info.parcels[0].options.mreturn = ReturnEnum.NOT_APPLICABLE
rate_request.shipping_info.parcels[0].options.insurance_amount = 0
rate_request.shipping_info.parcels[0].options.signature = SignatureEnum.NOT_APPLICABLE
rate_request.shipping_info.parcels[0].options.cod = CODOptions()
rate_request.shipping_info.parcels[0].options.cod.cod_type = CodTypeEnum.NOT_APPLICABLE
rate_request.shipping_info.parcels[0].options.cod.cod_amount = 0
rate_request.shipping_info.parcels[0].options.machinable = True
rate_request.shipping_info.parcels[0].options.hold_for_pickup = False


result = rates_controller.get_rates(rate_request)
```


# Get Rates by Carrier

Before creating a shipping label,
you can use this method to get a
break down of all shipping charges.
This allows you to determine
how much it would cost if you were to
actually send the parcels.

NOTE: HTTPS is Required to recieve a response.

```python
def get_rates_by_carrier(self,
                        rate_request=None)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `rate_request` | [`RateRequest`](/doc/models/rate-request.md) | Body, Optional | Shipping and parcel information<br>neccessary to calculate rates. |

## Response Type

[`RateResponse`](/doc/models/rate-response.md)

## Example Usage

```python
rate_request = RateRequest()
rate_request.access_token = 'YOUR ACCESS TOKEN'
rate_request.shipping_info = ShippingInformation()
rate_request.shipping_info.carrier_client_contract_id = 2526
rate_request.shipping_info.service_level_id = 0
rate_request.shipping_info.date_shipped = dateutil.parser.parse('2020-12-23T23:54:10.2649036Z')
rate_request.shipping_info.options = CustomsOptions()
rate_request.shipping_info.options.is_apo_fpo_dpo_us_territory = False
rate_request.shipping_info.options.is_international_shipment = False
rate_request.shipping_info.options.shipment_content_type = ShipmentContentTypeEnum.CONTENT_TYPE_SAMPLE
rate_request.shipping_info.address_from = ShipFromAddress()
rate_request.shipping_info.address_from.company_name = 'iDrive Logistics'
rate_request.shipping_info.address_from.email = 'sales@idrivelogistics.com'
rate_request.shipping_info.address_from.phone_number = '(888) 797-0929'
rate_request.shipping_info.address_from.address_1 = '2600 Executive Pkwy #160'
rate_request.shipping_info.address_from.address_2 = ''
rate_request.shipping_info.address_from.city = 'Lehi'
rate_request.shipping_info.address_from.state_or_province = 'UT'
rate_request.shipping_info.address_from.postal_code = '84043'
rate_request.shipping_info.address_from.country_code = 'US'
rate_request.shipping_info.address_to = ShipToAddress()
rate_request.shipping_info.address_to.attention_of = 'Mr. Jones'
rate_request.shipping_info.address_to.company_name = 'iDrive Logistics'
rate_request.shipping_info.address_to.email = ''
rate_request.shipping_info.address_to.phone_number = ''
rate_request.shipping_info.address_to.address_1 = '2605 Executive Pkwy #160'
rate_request.shipping_info.address_to.address_2 = ''
rate_request.shipping_info.address_to.is_residential = False
rate_request.shipping_info.address_to.city = 'Lehi'
rate_request.shipping_info.address_to.state_or_province = 'UT'
rate_request.shipping_info.address_to.postal_code = '84043'
rate_request.shipping_info.address_to.country_code = 'US'
rate_request.shipping_info.parcels = []

rate_request.shipping_info.parcels.append(ParcelInformation())
rate_request.shipping_info.parcels[0].packaging_id = ''
rate_request.shipping_info.parcels[0].weight_in_pounds = 0.4
rate_request.shipping_info.parcels[0].length_in_inches = 5
rate_request.shipping_info.parcels[0].width_in_inches = 4
rate_request.shipping_info.parcels[0].height_in_inches = 12
rate_request.shipping_info.parcels[0].options = ParcelOptions()
rate_request.shipping_info.parcels[0].options.mreturn = ReturnEnum.NOT_APPLICABLE
rate_request.shipping_info.parcels[0].options.insurance_amount = 0
rate_request.shipping_info.parcels[0].options.signature = SignatureEnum.NOT_APPLICABLE
rate_request.shipping_info.parcels[0].options.cod = CODOptions()
rate_request.shipping_info.parcels[0].options.cod.cod_type = CodTypeEnum.NOT_APPLICABLE
rate_request.shipping_info.parcels[0].options.cod.cod_amount = 0
rate_request.shipping_info.parcels[0].options.machinable = True
rate_request.shipping_info.parcels[0].options.hold_for_pickup = False


result = rates_controller.get_rates_by_carrier(rate_request)
```


# Get Multiple Rates

Before creating a shipping label,
you can use this method to get multiple
break downs of all shipping charges.
This allows you to determine
how much it would cost if you were to
actually send the parcels.

NOTE: HTTPS is Required to recieve a response.

```python
def get_multiple_rates(self,
                      rate_request=None)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `rate_request` | [`List of RateRequest`](/doc/models/rate-request.md) | Body, Optional | Shipping and parcel information<br>neccessary to calculate rates. |

## Response Type

[`List of RateResponse`](/doc/models/rate-response.md)

## Example Usage

```python
rate_request = []

rate_request.append(RateRequest())
rate_request[0].access_token = 'YOUR ACCESS TOKEN'
rate_request[0].shipping_info = ShippingInformation()
rate_request[0].shipping_info.carrier_client_contract_id = 2526
rate_request[0].shipping_info.service_level_id = 0
rate_request[0].shipping_info.date_shipped = dateutil.parser.parse('2020-12-23T23:54:10.2649036Z')
rate_request[0].shipping_info.options = CustomsOptions()
rate_request[0].shipping_info.options.is_apo_fpo_dpo_us_territory = False
rate_request[0].shipping_info.options.is_international_shipment = False
rate_request[0].shipping_info.options.shipment_content_type = ShipmentContentTypeEnum.CONTENT_TYPE_SAMPLE
rate_request[0].shipping_info.address_from = ShipFromAddress()
rate_request[0].shipping_info.address_from.company_name = 'iDrive Logistics'
rate_request[0].shipping_info.address_from.email = 'sales@idrivelogistics.com'
rate_request[0].shipping_info.address_from.phone_number = '(888) 797-0929'
rate_request[0].shipping_info.address_from.address_1 = '2600 Executive Pkwy #160'
rate_request[0].shipping_info.address_from.address_2 = ''
rate_request[0].shipping_info.address_from.city = 'Lehi'
rate_request[0].shipping_info.address_from.state_or_province = 'UT'
rate_request[0].shipping_info.address_from.postal_code = '84043'
rate_request[0].shipping_info.address_from.country_code = 'US'
rate_request[0].shipping_info.address_to = ShipToAddress()
rate_request[0].shipping_info.address_to.attention_of = 'Mr. Jones'
rate_request[0].shipping_info.address_to.company_name = 'iDrive Logistics'
rate_request[0].shipping_info.address_to.email = ''
rate_request[0].shipping_info.address_to.phone_number = ''
rate_request[0].shipping_info.address_to.address_1 = '2605 Executive Pkwy #160'
rate_request[0].shipping_info.address_to.address_2 = ''
rate_request[0].shipping_info.address_to.is_residential = False
rate_request[0].shipping_info.address_to.city = 'Lehi'
rate_request[0].shipping_info.address_to.state_or_province = 'UT'
rate_request[0].shipping_info.address_to.postal_code = '84043'
rate_request[0].shipping_info.address_to.country_code = 'US'
rate_request[0].shipping_info.parcels = []

rate_request[0].shipping_info.parcels.append(ParcelInformation())
rate_request[0].shipping_info.parcels[0].packaging_id = ''
rate_request[0].shipping_info.parcels[0].weight_in_pounds = 0.4
rate_request[0].shipping_info.parcels[0].length_in_inches = 5
rate_request[0].shipping_info.parcels[0].width_in_inches = 4
rate_request[0].shipping_info.parcels[0].height_in_inches = 12
rate_request[0].shipping_info.parcels[0].options = ParcelOptions()
rate_request[0].shipping_info.parcels[0].options.mreturn = ReturnEnum.NOT_APPLICABLE
rate_request[0].shipping_info.parcels[0].options.insurance_amount = 0
rate_request[0].shipping_info.parcels[0].options.signature = SignatureEnum.NOT_APPLICABLE
rate_request[0].shipping_info.parcels[0].options.cod = CODOptions()
rate_request[0].shipping_info.parcels[0].options.cod.cod_type = CodTypeEnum.NOT_APPLICABLE
rate_request[0].shipping_info.parcels[0].options.cod.cod_amount = 0
rate_request[0].shipping_info.parcels[0].options.machinable = True
rate_request[0].shipping_info.parcels[0].options.hold_for_pickup = False


rate_request.append(RateRequest())
rate_request[1].access_token = 'YOUR ACCESS TOKEN'
rate_request[1].shipping_info = ShippingInformation()
rate_request[1].shipping_info.carrier_client_contract_id = 2526
rate_request[1].shipping_info.service_level_id = 0
rate_request[1].shipping_info.date_shipped = dateutil.parser.parse('2020-12-23T23:54:10.2649036Z')
rate_request[1].shipping_info.options = CustomsOptions()
rate_request[1].shipping_info.options.is_apo_fpo_dpo_us_territory = False
rate_request[1].shipping_info.options.is_international_shipment = False
rate_request[1].shipping_info.options.shipment_content_type = ShipmentContentTypeEnum.CONTENT_TYPE_SAMPLE
rate_request[1].shipping_info.address_from = ShipFromAddress()
rate_request[1].shipping_info.address_from.company_name = 'iDrive Logistics'
rate_request[1].shipping_info.address_from.email = 'sales@idrivelogistics.com'
rate_request[1].shipping_info.address_from.phone_number = '(888) 797-0929'
rate_request[1].shipping_info.address_from.address_1 = '2600 Executive Pkwy #160'
rate_request[1].shipping_info.address_from.address_2 = ''
rate_request[1].shipping_info.address_from.city = 'Lehi'
rate_request[1].shipping_info.address_from.state_or_province = 'UT'
rate_request[1].shipping_info.address_from.postal_code = '84043'
rate_request[1].shipping_info.address_from.country_code = 'US'
rate_request[1].shipping_info.address_to = ShipToAddress()
rate_request[1].shipping_info.address_to.attention_of = 'Mr. Jones'
rate_request[1].shipping_info.address_to.company_name = 'iDrive Logistics'
rate_request[1].shipping_info.address_to.email = ''
rate_request[1].shipping_info.address_to.phone_number = ''
rate_request[1].shipping_info.address_to.address_1 = '2605 Executive Pkwy #160'
rate_request[1].shipping_info.address_to.address_2 = ''
rate_request[1].shipping_info.address_to.is_residential = False
rate_request[1].shipping_info.address_to.city = 'Lehi'
rate_request[1].shipping_info.address_to.state_or_province = 'UT'
rate_request[1].shipping_info.address_to.postal_code = '84043'
rate_request[1].shipping_info.address_to.country_code = 'US'
rate_request[1].shipping_info.parcels = []

rate_request[1].shipping_info.parcels.append(ParcelInformation())
rate_request[1].shipping_info.parcels[0].packaging_id = ''
rate_request[1].shipping_info.parcels[0].weight_in_pounds = 0.4
rate_request[1].shipping_info.parcels[0].length_in_inches = 5
rate_request[1].shipping_info.parcels[0].width_in_inches = 4
rate_request[1].shipping_info.parcels[0].height_in_inches = 12
rate_request[1].shipping_info.parcels[0].options = ParcelOptions()
rate_request[1].shipping_info.parcels[0].options.mreturn = ReturnEnum.NOT_APPLICABLE
rate_request[1].shipping_info.parcels[0].options.insurance_amount = 0
rate_request[1].shipping_info.parcels[0].options.signature = SignatureEnum.NOT_APPLICABLE
rate_request[1].shipping_info.parcels[0].options.cod = CODOptions()
rate_request[1].shipping_info.parcels[0].options.cod.cod_type = CodTypeEnum.NOT_APPLICABLE
rate_request[1].shipping_info.parcels[0].options.cod.cod_amount = 0
rate_request[1].shipping_info.parcels[0].options.machinable = True
rate_request[1].shipping_info.parcels[0].options.hold_for_pickup = False


rate_request.append(RateRequest())
rate_request[2].access_token = 'YOUR ACCESS TOKEN'
rate_request[2].shipping_info = ShippingInformation()
rate_request[2].shipping_info.carrier_client_contract_id = 2526
rate_request[2].shipping_info.service_level_id = 0
rate_request[2].shipping_info.date_shipped = dateutil.parser.parse('2020-12-23T23:54:10.2649036Z')
rate_request[2].shipping_info.options = CustomsOptions()
rate_request[2].shipping_info.options.is_apo_fpo_dpo_us_territory = False
rate_request[2].shipping_info.options.is_international_shipment = False
rate_request[2].shipping_info.options.shipment_content_type = ShipmentContentTypeEnum.CONTENT_TYPE_SAMPLE
rate_request[2].shipping_info.address_from = ShipFromAddress()
rate_request[2].shipping_info.address_from.company_name = 'iDrive Logistics'
rate_request[2].shipping_info.address_from.email = 'sales@idrivelogistics.com'
rate_request[2].shipping_info.address_from.phone_number = '(888) 797-0929'
rate_request[2].shipping_info.address_from.address_1 = '2600 Executive Pkwy #160'
rate_request[2].shipping_info.address_from.address_2 = ''
rate_request[2].shipping_info.address_from.city = 'Lehi'
rate_request[2].shipping_info.address_from.state_or_province = 'UT'
rate_request[2].shipping_info.address_from.postal_code = '84043'
rate_request[2].shipping_info.address_from.country_code = 'US'
rate_request[2].shipping_info.address_to = ShipToAddress()
rate_request[2].shipping_info.address_to.attention_of = 'Mr. Jones'
rate_request[2].shipping_info.address_to.company_name = 'iDrive Logistics'
rate_request[2].shipping_info.address_to.email = ''
rate_request[2].shipping_info.address_to.phone_number = ''
rate_request[2].shipping_info.address_to.address_1 = '2605 Executive Pkwy #160'
rate_request[2].shipping_info.address_to.address_2 = ''
rate_request[2].shipping_info.address_to.is_residential = False
rate_request[2].shipping_info.address_to.city = 'Lehi'
rate_request[2].shipping_info.address_to.state_or_province = 'UT'
rate_request[2].shipping_info.address_to.postal_code = '84043'
rate_request[2].shipping_info.address_to.country_code = 'US'
rate_request[2].shipping_info.parcels = []

rate_request[2].shipping_info.parcels.append(ParcelInformation())
rate_request[2].shipping_info.parcels[0].packaging_id = ''
rate_request[2].shipping_info.parcels[0].weight_in_pounds = 0.4
rate_request[2].shipping_info.parcels[0].length_in_inches = 5
rate_request[2].shipping_info.parcels[0].width_in_inches = 4
rate_request[2].shipping_info.parcels[0].height_in_inches = 12
rate_request[2].shipping_info.parcels[0].options = ParcelOptions()
rate_request[2].shipping_info.parcels[0].options.mreturn = ReturnEnum.NOT_APPLICABLE
rate_request[2].shipping_info.parcels[0].options.insurance_amount = 0
rate_request[2].shipping_info.parcels[0].options.signature = SignatureEnum.NOT_APPLICABLE
rate_request[2].shipping_info.parcels[0].options.cod = CODOptions()
rate_request[2].shipping_info.parcels[0].options.cod.cod_type = CodTypeEnum.NOT_APPLICABLE
rate_request[2].shipping_info.parcels[0].options.cod.cod_amount = 0
rate_request[2].shipping_info.parcels[0].options.machinable = True
rate_request[2].shipping_info.parcels[0].options.hold_for_pickup = False



result = rates_controller.get_multiple_rates(rate_request)
```

