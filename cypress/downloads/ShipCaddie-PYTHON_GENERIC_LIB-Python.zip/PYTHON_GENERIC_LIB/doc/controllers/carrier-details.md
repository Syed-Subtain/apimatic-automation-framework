# Carrier Details

```python
carrier_details_controller = client.carrier_details
```

## Class Name

`CarrierDetailsController`

## Methods

* [Get Carrier Service Information](/doc/controllers/carrier-details.md#get-carrier-service-information)
* [Verify Package Length Girth Limit](/doc/controllers/carrier-details.md#verify-package-length-girth-limit)
* [Get Carrier Parcel Specification](/doc/controllers/carrier-details.md#get-carrier-parcel-specification)


# Get Carrier Service Information

Multiple API methods require this information.

```python
def get_carrier_service_information(self,
                                   input=None)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `input` | [`GetCarrierServiceInformationRequestv21`](/doc/models/get-carrier-service-information-requestv-21.md) | Body, Optional | - |

## Response Type

[`GetCarrierServiceInformationResponsev21`](/doc/models/get-carrier-service-information-responsev-21.md)

## Example Usage

```python
input = GetCarrierServiceInformationRequestv21()
input.access_token = '<YOUR ACCESS TOKEN>'
input.as_client_id = 12

result = carrier_details_controller.get_carrier_service_information(input)
```

## Example Response *(as JSON)*

```json
{
  "carrierServiceList": [
    {
      "carrierClientContractId": 123,
      "affillateName": "USPS",
      "carrierName": "USPS",
      "nickName": "United States Postal Service",
      "serviceLevels": [
        {
          "carrierServiceLevelID": 23,
          "name": "Priority Mail",
          "parcelWeightLimit": 70.0,
          "isInternational": false
        },
        {
          "carrierServiceLevelID": 34,
          "name": "Express Mail Int'l",
          "parcelWeightLimit": 70.0,
          "isInternational": true
        }
      ],
      "error": {
        "details": [],
        "hasError": false
      }
    }
  ],
  "error": {
    "details": [],
    "hasError": false
  }
}
```


# Verify Package Length Girth Limit

Verifies packages height, length, and width.

```python
def verify_package_length_girth_limit(self,
                                     input=None)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `input` | [`VerifyPackageLengthGirthLimitRequestv21`](/doc/models/verify-package-length-girth-limit-requestv-21.md) | Body, Optional | - |

## Response Type

[`VerifyPackageLengthGirthLimitResponsev21`](/doc/models/verify-package-length-girth-limit-responsev-21.md)

## Example Usage

```python
input = VerifyPackageLengthGirthLimitRequestv21()
input.access_token = '<YOUR ACCESS TOKEN>'
input.request = PackageLengthGirthModelV21()
input.request.carrier_service_level_id = 12
input.request.package_list = []

input.request.package_list.append(PackagesV21())
input.request.package_list[0].length = 6
input.request.package_list[0].width = 8
input.request.package_list[0].height = 12

input.request.package_list.append(PackagesV21())
input.request.package_list[1].length = 6
input.request.package_list[1].width = 8
input.request.package_list[1].height = 12


result = carrier_details_controller.verify_package_length_girth_limit(input)
```

## Example Response *(as JSON)*

```json
{
  "error": {
    "details": [],
    "hasError": false
  },
  "valid": true
}
```


# Get Carrier Parcel Specification

Details include parcel weight limits and maximum dimensions.

```python
def get_carrier_parcel_specification(self,
                                    input=None)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `input` | [`GetCarrierParcelSpecificationRequestv21`](/doc/models/get-carrier-parcel-specification-requestv-21.md) | Body, Optional | - |

## Response Type

[`GetCarrierParcelSpecificationResponsev21`](/doc/models/get-carrier-parcel-specification-responsev-21.md)

## Example Usage

```python
input = GetCarrierParcelSpecificationRequestv21()
input.access_token = '<YOUR ACCESS TOKEN>'
input.as_client_id = 12
input.carrier_client_contract_id = 24

result = carrier_details_controller.get_carrier_parcel_specification(input)
```

## Example Response *(as JSON)*

```json
{
  "parcelDetails": [
    {
      "parcelId": "102-0",
      "name": "Large Envelope or Flat",
      "description": "Large Envelope or Flat",
      "lengthInInches": 12.0,
      "widthInInches": 0.75,
      "heightInInches": 4.0,
      "weightLimit": 0.8,
      "packagingWeight": 0.0
    },
    {
      "parcelId": "115-0",
      "name": "Flat Rate Large Box",
      "description": "Large Flat Rate Box",
      "lengthInInches": 12.0,
      "widthInInches": 5.5,
      "heightInInches": 4.0,
      "weightLimit": 70.0,
      "packagingWeight": 0.0
    }
  ],
  "error": {
    "details": [],
    "hasError": false
  }
}
```

