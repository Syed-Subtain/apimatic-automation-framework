
# Client Class Documentation

The following parameters are configurable for the API Client:

| Parameter | Type | Description |
|  --- | --- | --- |
| `pushServerUrl` | `String` | In some API call BookingPal will send POST request (push message) to the PMS for URL which you provide in API 'Push Notification'. You can test these calls to in this documentation, just you will need to set your URL here on specific API call, on Configure button in the right section of specific API function<br>*Default*: `"https://www.yourEndpoint.url"` |
| `environment` | Environment | The API environment. <br> **Default: `Environment.PRODUCTION`** |
| `httpClientConfig` | `ReadonlyHttpClientConfiguration` | Http Client Configuration instance. |
| `jwt` | `String` | Token which need to be passed in every request as GET parameter. You will get this token in authorization response. Token is valid 1 hour. |

The API client can be initialized as follows:

```java
SupplierAPIClient client = new SupplierAPIClient.Builder()
    .httpClientConfig(configBuilder -> configBuilder
            .timeout(0))
    .customQueryAuthenticationCredentials("jwt")
    .environment(Environment.PRODUCTION)
    .pushServerUrl("https://www.yourEndpoint.url")
    .build();
```

## Supplier APIClient Class

The gateway for the SDK. This class acts as a factory for the Controllers and also holds the configuration of the SDK.

### Controllers

| Name | Description | Return Type |
|  --- | --- | --- |
| `getPropertyManagersController()` | Provides access to PropertyManagers controller. | `PropertyManagersController` |
| `getAuthorizationController()` | Provides access to Authorization controller. | `AuthorizationController` |
| `getImagesController()` | Provides access to Images controller. | `ImagesController` |
| `getRatesAndAvailabilityController()` | Provides access to RatesAndAvailability controller. | `RatesAndAvailabilityController` |
| `getFeeAndTaxController()` | Provides access to FeeAndTax controller. | `FeeAndTaxController` |
| `getFeeAndTaxMandatoryAtThePropertyLevelController()` | Provides access to FeeAndTaxMandatoryAtThePropertyLevel controller. | `FeeAndTaxMandatoryAtThePropertyLevelController` |
| `getYieldsController()` | Provides access to Yields controller. | `YieldsController` |
| `getTestingOfMessageAPICallsController()` | Provides access to TestingOfMessageAPICalls controller. | `TestingOfMessageAPICallsController` |
| `getMessagingController()` | Provides access to Messaging controller. | `MessagingController` |
| `getPushNotificationController()` | Provides access to PushNotification controller. | `PushNotificationController` |
| `getReservationNotificationsController()` | Provides access to ReservationNotifications controller. | `ReservationNotificationsController` |
| `getAsynchronousPushMessagesController()` | Provides access to AsynchronousPushMessages controller. | `AsynchronousPushMessagesController` |
| `getLicensesController()` | Provides access to Licenses controller. | `LicensesController` |
| `getProductController()` | Provides access to Product controller. | `ProductController` |
| `getValidationController()` | Provides access to Validation controller. | `ValidationController` |
| `getRequestToBookController()` | Provides access to RequestToBook controller. | `RequestToBookController` |
| `getLOSPricingController()` | Provides access to LOSPricing controller. | `LOSPricingController` |
| `getConfigurationInSupplierAPIController()` | Provides access to ConfigurationInSupplierAPI controller. | `ConfigurationInSupplierAPIController` |

### Methods

| Name | Description | Return Type |
|  --- | --- | --- |
| `shutdown()` | Shutdown the underlying HttpClient instance. | `void` |
| `getEnvironment()` | Current API environment. | `Environment` |
| `getPushServerUrl()` | In some API call BookingPal will send POST request (push message) to the PMS for URL which you provide in API 'Push Notification'. You can test these calls to in this documentation, just you will need to set your URL here on specific API call, on Configure button in the right section of specific API function | `String` |
| `getHttpClient()` | The HTTP Client instance to use for making HTTP requests. | `HttpClient` |
| `getHttpClientConfig()` | Http Client Configuration instance. | `ReadonlyHttpClientConfiguration` |
| `getBaseUri(Server server)` | Get base URI by current environment | `String` |
| `getBaseUri()` | Get base URI by current environment | `String` |

