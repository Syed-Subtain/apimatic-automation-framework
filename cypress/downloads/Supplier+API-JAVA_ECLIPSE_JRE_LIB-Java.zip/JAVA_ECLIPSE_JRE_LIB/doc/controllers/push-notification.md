# Push Notification

```java
PushNotificationController pushNotificationController = client.getPushNotificationController();
```

## Class Name

`PushNotificationController`

## Methods

* [Push Notification Links](../../doc/controllers/push-notification.md#push-notification-links)
* [Get Notification Links](../../doc/controllers/push-notification.md#get-notification-links)


# Push Notification Links

Provide the links on which the requests about reservation notification will be sent. Links should be https.
These links should be set on PMS level, so please use your PMS credentials.

IMPORTANT: If you set 'reservationLink' value - all reservation push notifications will go on this endpoint (so any new reservation, cancel reservation, update reservation, request to book, request to book cancel). And before you do this - you should implement a new push reservation API call 'General Reservation Notification - PUSH' - since you will get then all reservation notifications over this method.

```java
CompletableFuture<PushNotificationLinksResponse> pushNotificationLinksAsync(
    final PushNotificationLinksRequest body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`PushNotificationLinksRequest`](../../doc/models/push-notification-links-request.md) | Body, Required | - |

## Response Type

[`PushNotificationLinksResponse`](../../doc/models/push-notification-links-response.md)

## Example Usage

```java
PushNotificationLinksRequest body = new PushNotificationLinksRequest();
body.setData(new PushNotificationLinksModel());
body.getData().setBookLink("https://newreservationnotification.link");
body.getData().setCancelLink("https://cancelreservation.link");
body.getData().setAsyncPush("https://asyncpush.link");
body.getData().setRequestToBook("https://requestToBook.link");
body.getData().setReservationLink("https://reservation.link");

pushNotificationController.pushNotificationLinksAsync(body).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

## Example Response *(as JSON)*

```json
{
  "message": "",
  "errorMessage": [],
  "is_error": false,
  "code": "",
  "data": [
    {
      "bookLink": "https://newreservationnotification.link",
      "cancelLink": "https://cancelreservation.link",
      "asyncPush": "https://asyncpush.link",
      "requestToBook": "https://requestToBook.link"
    }
  ]
}
```


# Get Notification Links

This will return all notification URLs which are set. It will work on PMS level, so use PMS credentials.

```java
CompletableFuture<PushNotificationLinksResponse> getNotificationLinksAsync()
```

## Response Type

[`PushNotificationLinksResponse`](../../doc/models/push-notification-links-response.md)

## Example Usage

```java
pushNotificationController.getNotificationLinksAsync().thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

## Example Response *(as JSON)*

```json
{
  "message": "",
  "errorMessage": [],
  "is_error": false,
  "code": "",
  "data": [
    {
      "bookLink": "https://newreservationnotification.link",
      "cancelLink": "https://cancelreservation.link",
      "asyncPush": "https://asyncpush.link",
      "requestToBook": "https://requestToBook.link",
      "reservationLink": "https://reservation.link"
    }
  ]
}
```

