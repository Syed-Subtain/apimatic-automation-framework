# Ratesand Availability

```java
RatesandAvailabilityController ratesandAvailabilityController = client.getRatesandAvailabilityController();
```

## Class Name

`RatesandAvailabilityController`

## Methods

* [Create and Update Rates and Availability](../../doc/controllers/ratesand-availability.md#create-and-update-rates-and-availability)
* [Get Rates and Availability Product ID](../../doc/controllers/ratesand-availability.md#get-rates-and-availability-product-id)


# Create and Update Rates and Availability

Create and update calls are the same. When data is sent, if the data already exists in BookingPal - that data will be updated. Otherwise it will be created (inserted). If you want to update data for some period, you should just send data for these dates. All other data (for other dates) will remain untouched. This allows you to update only changed periods and we will not delete previously sent data for other periods.

In the case of a first data push, all data for one property should be sent in one request.  When making updates or changes to existing data, then all changed data should be sent in one request.

Note: Even property is set on LOS rates - you can use this call and send rates per day with all restrictions. These rates with restrictions will be used on channels which do not allow LOS rates.
This API call can not be used for OWN properties.
Important: Maximum allowed end date in any data type is 3 years in future.

Every API call in this section should be with PM credentials.

```java
CompletableFuture<RatesAvailabilityResponse> createAndUpdateRatesAndAvailabilityAsync(
    final CreateandUpdateRatesandAvailabilityRequest body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`CreateandUpdateRatesandAvailabilityRequest`](../../doc/models/createand-update-ratesand-availability-request.md) | Body, Required | - |

## Response Type

[`RatesAvailabilityResponse`](../../doc/models/rates-availability-response.md)

## Example Usage

```java
CreateandUpdateRatesandAvailabilityRequest body = new CreateandUpdateRatesandAvailabilityRequest();
body.setData(new RatesAvailability());
body.getData().setProductId(192);

ratesAndAvailabilityController.createAndUpdateRatesAndAvailabilityAsync(body).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```


# Get Rates and Availability Product ID

This function allows logged in users to get rates and availability for the specific product.
Every API call in this section should be with PM credentials.

```java
CompletableFuture<RatesAvailabilityResponse> getRatesAndAvailabilityProductIDAsync(
    final String contentType,
    final String productId)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `contentType` | `String` | Header, Required | - |
| `productId` | `String` | Template, Required | ID of the property |

## Response Type

[`RatesAvailabilityResponse`](../../doc/models/rates-availability-response.md)

## Example Usage

```java
String contentType = "application/json";
String productId = "1235124634";

ratesAndAvailabilityController.getRatesAndAvailabilityProductIDAsync(contentType, productId).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

