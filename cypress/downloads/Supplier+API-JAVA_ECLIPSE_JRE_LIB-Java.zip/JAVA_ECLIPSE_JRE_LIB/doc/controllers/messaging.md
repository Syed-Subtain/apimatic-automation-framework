# Messaging

```java
MessagingController messagingController = client.getMessagingController();
```

## Class Name

`MessagingController`

## Methods

* [Get Message Threads](../../doc/controllers/messaging.md#get-message-threads)
* [Post New Message for Specific Thread](../../doc/controllers/messaging.md#post-new-message-for-specific-thread)
* [Get Message List for Specific Thread](../../doc/controllers/messaging.md#get-message-list-for-specific-thread)


# Get Message Threads

This function allows the logged in user to get all message threads or message threads with unresponded message from guest for whole PM. You need to use PM credentials. There is also paging as optional values. If you do not pass this value, we will return first page and 10 threads per page. And in heading you will get a link for the next page.

```java
CompletableFuture<GetMessageThreadsResponse> getMessageThreadsAsync(
    final int page,
    final int limit,
    final String threadType)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `page` | `int` | Query, Required | Number of current page |
| `limit` | `int` | Query, Required | Limit of how many threads will be showed at one page |
| `threadType` | `String` | Template, Required | Request all threads or only threads with  unanswered message {new,all} |

## Response Type

[`GetMessageThreadsResponse`](../../doc/models/get-message-threads-response.md)

## Example Usage

```java
int page = 1;
int limit = 5;
String threadType = "all";

messagingController.getMessageThreadsAsync(page, limit, threadType).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```


# Post New Message for Specific Thread

This function will allow PM to post new messages in already existing threads.

```java
CompletableFuture<APIResponseWithoutData> postNewMessageForSpecificThreadAsync(
    final PostNewMessageForSpecificThreadRequest body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`PostNewMessageForSpecificThreadRequest`](../../doc/models/post-new-message-for-specific-thread-request.md) | Body, Required | - |

## Response Type

[`APIResponseWithoutData`](../../doc/models/api-response-without-data.md)

## Example Usage

```java
PostNewMessageForSpecificThreadRequest body = new PostNewMessageForSpecificThreadRequest();
body.setData(new MessageRequestFromSupplier());
body.getData().setThreadId(5656);
body.getData().setMessage("New message");

messagingController.postNewMessageForSpecificThreadAsync(body).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

## Example Response *(as JSON)*

```json
{
  "message": "Your request was received and put in queue",
  "errorMessage": [],
  "is_error": false,
  "code": ""
}
```


# Get Message List for Specific Thread

This function allows the logged in user to get a list of all messages from passed thread Id. You need to use PM credentials.

```java
CompletableFuture<GetMessageListForSpecificThreadResponse> getMessageListForSpecificThreadAsync(
    final String threadId)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `threadId` | `String` | Template, Required | ID of the thread |

## Response Type

[`GetMessageListForSpecificThreadResponse`](../../doc/models/get-message-list-for-specific-thread-response.md)

## Example Usage

```java
String threadId = "123";

messagingController.getMessageListForSpecificThreadAsync(threadId).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

## Example Response *(as JSON)*

```json
{
  "message": "",
  "errorMessage": [],
  "code": "",
  "data": [
    {
      "messages": [
        {
          "id": 68233,
          "message": "Message pmuNXJFzWQ",
          "createdAt": "2019-12-03T12:31:47.000+0000",
          "user": "GUEST",
          "channelMessageId": "2221139318748986368"
        },
        {
          "id": 68234,
          "message": "i would like to know soon so i can know whether to get another bnb or hotel",
          "createdAt": "2019-10-21T16:49:30.000+0000",
          "user": "GUEST",
          "channelMessageId": "2221139318748986369"
        },
        {
          "id": 68235,
          "message": "??",
          "createdAt": "2019-10-21T16:49:31.000+0000",
          "user": "GUEST",
          "channelMessageId": "2221139318748986370"
        },
        {
          "id": 68236,
          "message": "Hello, How does the chalet work? Will we be staying with other people? I see there are 5 apartments. So someone will be living above us below us? Thank you. ",
          "createdAt": "2019-10-21T16:49:31.000+0000",
          "user": "GUEST",
          "channelMessageId": "2221139318748986371"
        }
      ]
    }
  ],
  "is_error": false
}
```

