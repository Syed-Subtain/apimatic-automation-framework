# Asynchronous Push Messages

```java
AsynchronousPushMessagesController asynchronousPushMessagesController = client.getAsynchronousPushMessagesController();
```

## Class Name

`AsynchronousPushMessagesController`

## Methods

* [Validation Push Asynchronous Message](../../doc/controllers/asynchronous-push-messages.md#validation-push-asynchronous-message)
* [Product Image Push Asynchronous Message](../../doc/controllers/asynchronous-push-messages.md#product-image-push-asynchronous-message)


# Validation Push Asynchronous Message

This is POST request - push notifications (webhooks) which BookingPal will send on PMS endpoint (which is set in push notification API, field - asyncPush) after something is executed in BP. This is necessary since some API calls like validation, onboarding, etc are done over queue in our system, so you will get an asynchronous response.

In these requests, we do not have expected responses from the PMS system. Since these are just notifications.

Important note: In this doc to be able to test this - you need to set a full URL on the Configure button in the right section.

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<Void> validationPushAsynchronousMessageAsync(
    final ValidationAsynchronousPushMessageRequest body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`ValidationAsynchronousPushMessageRequest`](../../doc/models/validation-asynchronous-push-message-request.md) | Body, Required | - |

## Server

`Server.PUSHSERVER`

## Response Type

`void`

## Example Usage

```java
ValidationAsynchronousPushMessageRequest body = new ValidationAsynchronousPushMessageRequest();
body.setSupplierId(636753);
body.setType("BP_VALIDATION");
body.setValidation(new LinkedList<>());

AsynchronousValidationModel bodyValidation0 = new AsynchronousValidationModel();
bodyValidation0.setProductId(291358);
bodyValidation0.setValid(true);
bodyValidation0.setValidationErrors("null");
body.getValidation().add(bodyValidation0);

AsynchronousValidationModel bodyValidation1 = new AsynchronousValidationModel();
bodyValidation1.setProductId(291356);
bodyValidation1.setValid(false);
bodyValidation1.setValidationErrors("noPrice;");
body.getValidation().add(bodyValidation1);


asynchronousPushMessagesController.validationPushAsynchronousMessageAsync(body).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```


# Product Image Push Asynchronous Message

This is POST request - push notifications (webhooks) which BookingPal will send on PMS endpoint (which is set in push notification API, field - asyncPush) after something is executed in BP. This is necessary since some API calls like validation, onboarding, etc are done over queue in our system, so you will get an asynchronous response.

In these requests, we do not have expected responses from the PMS system. Since these are just notifications.

Important note: In this doc to be able to test this - you need to set a full URL on the Configure button in the right section.

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<Void> productImagePushAsynchronousMessageAsync(
    final ProductImageAsynchronousPushMessageRequest body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`ProductImageAsynchronousPushMessageRequest`](../../doc/models/product-image-asynchronous-push-message-request.md) | Body, Required | - |

## Server

`Server.PUSHSERVER`

## Response Type

`void`

## Example Usage

```java
ProductImageAsynchronousPushMessageRequest body = new ProductImageAsynchronousPushMessageRequest();
body.setSupplierId(61692827);
body.setType("PROCESSING_IMAGES");
body.setProcessingImage(new LinkedList<>());

ProductImagePushNotification bodyProcessingImage0 = new ProductImagePushNotification();
bodyProcessingImage0.setName("Riverwalk Inn Wizard");
bodyProcessingImage0.setProductId("1235138415");
bodyProcessingImage0.setImages(new LinkedList<>());

ImagePushNotification bodyProcessingImage0Images0 = new ImagePushNotification();
bodyProcessingImage0Images0.setSuccess(true);
bodyProcessingImage0Images0.setType(TypeEnum.IMPORT);
bodyProcessingImage0Images0.setUrl("https://www.staymarquis.com/uploads/homeaway/1570665600_odQZP_bedroom62.jpg");
bodyProcessingImage0Images0.setVersion("2021-01-29T11:53:31.000+0000");
bodyProcessingImage0.getImages().add(bodyProcessingImage0Images0);

bodyProcessingImage0.setAltId("123");
body.getProcessingImage().add(bodyProcessingImage0);


asynchronousPushMessagesController.productImagePushAsynchronousMessageAsync(body).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

