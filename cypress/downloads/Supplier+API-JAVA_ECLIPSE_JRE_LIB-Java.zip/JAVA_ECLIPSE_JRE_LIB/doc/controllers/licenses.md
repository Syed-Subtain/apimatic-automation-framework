# Licenses

```java
LicensesController licensesController = client.getLicensesController();
```

## Class Name

`LicensesController`

## Methods

* [Put License Req](../../doc/controllers/licenses.md#put-license-req)
* [Get License Req](../../doc/controllers/licenses.md#get-license-req)
* [Bdc License Requirements](../../doc/controllers/licenses.md#bdc-license-requirements)


# Put License Req

This function allows system to send license information for a property, so channel can use it.

```java
CompletableFuture<LicenseUpdateResponse> putLicenseReqAsync(
    final String productId,
    final LicenseUpdate body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `productId` | `String` | Template, Required | Product ID |
| `body` | [`LicenseUpdate`](../../doc/models/license-update.md) | Body, Required | - |

## Response Type

[`LicenseUpdateResponse`](../../doc/models/license-update-response.md)

## Example Usage

```java
String productId = "61692799";
LicenseUpdate body = new LicenseUpdate();
body.setData(new LinkedList<>());

LicenseData bodyData0 = new LicenseData();
bodyData0.setContentData(new LinkedList<>());

LicenseDataContent bodyData0ContentData0 = new LicenseDataContent();
bodyData0.getContentData().add(bodyData0ContentData0);

bodyData0.setVariantId("variantId1");
body.getData().add(bodyData0);

LicenseData bodyData1 = new LicenseData();
bodyData1.setContentData(new LinkedList<>());

LicenseDataContent bodyData1ContentData0 = new LicenseDataContent();
bodyData1.getContentData().add(bodyData1ContentData0);

LicenseDataContent bodyData1ContentData1 = new LicenseDataContent();
bodyData1.getContentData().add(bodyData1ContentData1);

bodyData1.setVariantId("variantId2");
body.getData().add(bodyData1);

LicenseData bodyData2 = new LicenseData();
bodyData2.setContentData(new LinkedList<>());

LicenseDataContent bodyData2ContentData0 = new LicenseDataContent();
bodyData2.getContentData().add(bodyData2ContentData0);

LicenseDataContent bodyData2ContentData1 = new LicenseDataContent();
bodyData2.getContentData().add(bodyData2ContentData1);

LicenseDataContent bodyData2ContentData2 = new LicenseDataContent();
bodyData2.getContentData().add(bodyData2ContentData2);

bodyData2.setVariantId("variantId3");
body.getData().add(bodyData2);


licensesController.putLicenseReqAsync(productId, body).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```


# Get License Req

This function allows system to get licenses information for a property.

```java
CompletableFuture<LicenseGetResponse> getLicenseReqAsync(
    final String productId)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `productId` | `String` | Template, Required | Product ID |

## Response Type

[`LicenseGetResponse`](../../doc/models/license-get-response.md)

## Example Usage

```java
String productId = "61692799";

licensesController.getLicenseReqAsync(productId).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```


# Bdc License Requirements

This function will get the BDC License Requirements

```java
CompletableFuture<LicenseRequirementResponse> bdcLicenseRequirementsAsync(
    final String productId)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `productId` | `String` | Template, Required | Product ID |

## Response Type

[`LicenseRequirementResponse`](../../doc/models/license-requirement-response.md)

## Example Usage

```java
String productId = "61692799";

licensesController.bdcLicenseRequirementsAsync(productId).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

