# Property Managers

```java
PropertyManagersController propertyManagersController = client.getPropertyManagersController();
```

## Class Name

`PropertyManagersController`

## Methods

* [PM List](../../doc/controllers/property-managers.md#pm-list)
* [Create New Property Manager](../../doc/controllers/property-managers.md#create-new-property-manager)
* [Get Property Manager Detail Data](../../doc/controllers/property-managers.md#get-property-manager-detail-data)
* [Update Property Manager Details](../../doc/controllers/property-managers.md#update-property-manager-details)


# PM List

This API call will return a list of property managers (PM) that have been created in the BookingPal platform that is associated with your PMS.
In all requests in this API section, you need to use your PMS credentials.

```java
CompletableFuture<GetPMsList> pMListAsync()
```

## Response Type

[`GetPMsList`](../../doc/models/get-p-ms-list.md)

## Example Usage

```java
propertyManagersController.pMListAsync().thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

## Example Response *(as JSON)*

```json
{
  "message": "",
  "errorMessage": [],
  "is_error": false,
  "code": "",
  "data": [
    {
      "id": 61690133,
      "name": "Test name",
      "extraName": "Test fullname",
      "emailAddress": "test001@gmail.com"
    },
    {
      "id": 61690517,
      "name": "Test",
      "extraName": "Test",
      "emailAddress": "testa002@gmail.com"
    },
    {
      "id": 61690534,
      "name": "Test",
      "extraName": "Test",
      "emailAddress": "testa003@gmail.com"
    },
    {
      "id": 61691075,
      "name": "Test",
      "extraName": "Test",
      "emailAddress": "testa004@gmail.com"
    },
    {
      "id": 61691076,
      "name": "Test",
      "extraName": "Test",
      "emailAddress": "testa005@gmail.com"
    },
    {
      "id": 61691729,
      "name": "Test",
      "extraName": "Test",
      "emailAddress": "testa103@gmail.com"
    },
    {
      "id": 61691731,
      "name": "Update Name",
      "extraName": "Update Full Name",
      "emailAddress": "te@gmail.com"
    },
    {
      "id": 61691732,
      "name": "Update Name",
      "extraName": "Update Full Name",
      "emailAddress": "testa026@gmail.com"
    },
    {
      "id": 61691733,
      "name": "Test",
      "extraName": "Test",
      "emailAddress": "testa027@gmail.com"
    },
    {
      "id": 61691734,
      "name": "Test",
      "extraName": "Test",
      "emailAddress": "testa028@gmail.com"
    },
    {
      "id": 61691735,
      "name": "Test",
      "extraName": "Test",
      "emailAddress": "testa029@gmail.com"
    },
    {
      "id": 61691736,
      "name": "Update Name",
      "extraName": "Update Full Name",
      "emailAddress": "testa0031@gmail.com"
    },
    {
      "id": 61691737,
      "name": "Update Name",
      "extraName": "Update Full Name",
      "emailAddress": "testa0032@gmail.com"
    },
    {
      "id": 61691803,
      "name": "Update Name",
      "extraName": "Update Full Name",
      "emailAddress": "testa035@gmail.com"
    },
    {
      "id": 61691852,
      "name": "Test",
      "extraName": "Test",
      "emailAddress": "testa036@gmail.com"
    },
    {
      "id": 61691861,
      "name": "Auto-lyxpz company name",
      "extraName": "Auto-dzvjr full name",
      "emailAddress": "wnvuyqfya213@pqclbzs.rli"
    },
    {
      "id": 61691868,
      "name": "Update Name",
      "extraName": "Update Full Name",
      "emailAddress": "testa038@gmail.com"
    },
    {
      "id": 61691875,
      "name": "Test",
      "extraName": "Test",
      "emailAddress": "TestPM001@gmail.com"
    },
    {
      "id": 61691876,
      "name": "Test",
      "extraName": "Test",
      "emailAddress": "TestPM002@gmail.com"
    },
    {
      "id": 61691877,
      "name": "Test",
      "extraName": "Test",
      "emailAddress": "TestPM003@gmail.com"
    },
    {
      "id": 61691878,
      "name": "Test",
      "extraName": "Test",
      "emailAddress": "TestPM004@gmail.com"
    },
    {
      "id": 61691879,
      "name": "Test",
      "extraName": "Test",
      "emailAddress": "TestPM005@gmail.com"
    },
    {
      "id": 61691880,
      "name": "Test",
      "extraName": "Test",
      "emailAddress": "TestPM006@gmail.com"
    },
    {
      "id": 61691881,
      "name": "Test",
      "extraName": "Test",
      "emailAddress": "TestPM007@gmail.com"
    },
    {
      "id": 61691882,
      "name": "Test",
      "extraName": "Test",
      "emailAddress": "TestPM008@gmail.com"
    },
    {
      "id": 61691883,
      "name": "Test",
      "extraName": "Test",
      "emailAddress": "TestPM009@gmail.com"
    },
    {
      "id": 61691884,
      "name": "Test",
      "extraName": "Test",
      "emailAddress": "TestPM010@gmail.com"
    },
    {
      "id": 61691885,
      "name": "Test",
      "extraName": "Test",
      "emailAddress": "TestPM011@gmail.com"
    },
    {
      "id": 61691886,
      "name": "Test",
      "extraName": "Test",
      "emailAddress": "TestPM012@gmail.com"
    },
    {
      "id": 61691887,
      "name": "Test",
      "extraName": "Test",
      "emailAddress": "TestPM014@gmail.com"
    },
    {
      "id": 61691888,
      "name": "Test",
      "extraName": "Test",
      "emailAddress": "TestPM015@gmail.com"
    },
    {
      "id": 61691889,
      "name": "Test",
      "extraName": "Test",
      "emailAddress": "TestPM016@gmail.com"
    },
    {
      "id": 61691896,
      "name": "Test",
      "extraName": "Test",
      "emailAddress": "TestPM017@gmail.com"
    },
    {
      "id": 61691897,
      "name": "Test",
      "extraName": "Test",
      "emailAddress": "TestPM018@gmail.com"
    },
    {
      "id": 61691898,
      "name": "Test",
      "extraName": "Test",
      "emailAddress": "TestPM019@gmail.com"
    },
    {
      "id": 61691899,
      "name": "Test",
      "extraName": "Test",
      "emailAddress": "TestPM020@gmail.com"
    },
    {
      "id": 61691900,
      "name": "Test",
      "extraName": "Test",
      "emailAddress": "TestPM021@gmail.com"
    },
    {
      "id": 61691903,
      "name": "Test",
      "extraName": "Test",
      "emailAddress": "testa0141234@gmail.com"
    },
    {
      "id": 61691904,
      "name": "Test",
      "extraName": "Test",
      "emailAddress": "testa01412345@gmail.com"
    },
    {
      "id": 61691905,
      "name": "Test",
      "extraName": "Test",
      "emailAddress": "TestPM022@gmail.com"
    },
    {
      "id": 61691906,
      "name": "Test",
      "extraName": "Test",
      "emailAddress": "TestPM023@gmail.com"
    },
    {
      "id": 61691907,
      "name": "Test",
      "extraName": "Test",
      "emailAddress": "testa014123452@gmail.com"
    },
    {
      "id": 61691908,
      "name": "Test",
      "extraName": "Test",
      "emailAddress": "testa0141234521@gmail.com"
    },
    {
      "id": 61691909,
      "name": "Test",
      "extraName": "Test",
      "emailAddress": "TestPM024@gmail.com"
    },
    {
      "id": 61691910,
      "name": "Test",
      "extraName": "Test",
      "emailAddress": "TestPM025@gmail.com"
    },
    {
      "id": 61691911,
      "name": "Test",
      "extraName": "Test",
      "emailAddress": "TestPM026@gmail.com"
    },
    {
      "id": 61691979,
      "name": "Test",
      "extraName": "Test",
      "emailAddress": "TestPM028@gmail.com"
    },
    {
      "id": 61692003,
      "name": "Test",
      "extraName": "Test",
      "emailAddress": "TestPM030@gmail.com"
    },
    {
      "id": 61692065,
      "name": "Test",
      "extraName": "Test",
      "emailAddress": "TestPM031@gmail.com"
    },
    {
      "id": 61692066,
      "name": "Test",
      "extraName": "Test",
      "emailAddress": "TestPM032@gmail.com"
    },
    {
      "id": 61692067,
      "name": "Test",
      "extraName": "Test",
      "emailAddress": "TestPM033@gmail.com"
    },
    {
      "id": 61692068,
      "name": "Update Name",
      "extraName": "Update Full Name",
      "emailAddress": "TestPM034@gmail.com"
    },
    {
      "id": 61692418,
      "name": "Test",
      "extraName": "Test",
      "emailAddress": "TestPM01130@gmail.com"
    },
    {
      "id": 61692455,
      "name": "Test",
      "extraName": "Test",
      "emailAddress": "TestPM035@gmail.com"
    },
    {
      "id": 61692456,
      "name": "Test",
      "extraName": "Test",
      "emailAddress": "TestPM036@gmail.com"
    },
    {
      "id": 61692457,
      "name": "Test",
      "extraName": "Test",
      "emailAddress": "TestPM037@gmail.com"
    },
    {
      "id": 61692552,
      "name": "Update Name",
      "extraName": "Update Full Name",
      "emailAddress": "TestPM038@gmail.com"
    },
    {
      "id": 61692554,
      "name": "Test",
      "extraName": "Test",
      "emailAddress": "TestPM999MJ@gmail.com"
    },
    {
      "id": 61692695,
      "name": "Test",
      "extraName": "Test",
      "emailAddress": "testa133@gmail.com"
    },
    {
      "id": 61692769,
      "name": "Test",
      "extraName": "Test",
      "emailAddress": "TestPM050@gmail.com"
    },
    {
      "id": 61692782,
      "name": "Test",
      "extraName": "Test",
      "emailAddress": "TestPMCreateProduct@gmail.com"
    },
    {
      "id": 61692785,
      "name": "Test",
      "extraName": "Test",
      "emailAddress": "TestPM055@gmail.com"
    },
    {
      "id": 61692787,
      "name": "Test",
      "extraName": "Test",
      "emailAddress": "TestPM056@gmail.com"
    },
    {
      "id": 61692789,
      "name": "Test",
      "extraName": "Test",
      "emailAddress": "TestPM057@gmail.com"
    },
    {
      "id": 61692790,
      "name": "Test Wiz",
      "extraName": "Test Wiz",
      "emailAddress": "TestPM058@gmail.com"
    },
    {
      "id": 61692791,
      "name": "Test wiz1",
      "extraName": "Test wiz1",
      "emailAddress": "TestPM059@gmail.com"
    },
    {
      "id": 61692793,
      "name": "Test wiz1",
      "extraName": "Test wiz1",
      "emailAddress": "TestPM060@gmail.com"
    },
    {
      "id": 61692794,
      "name": "Test wiz1",
      "extraName": "Test wiz1",
      "emailAddress": "TestPM061@gmail.com"
    },
    {
      "id": 61692795,
      "name": "Test wiz",
      "extraName": "Test wiz",
      "emailAddress": "TestPM062@gmail.com"
    },
    {
      "id": 61692797,
      "name": "Wizard Demo",
      "extraName": "Wizard Demo",
      "emailAddress": "wizarddemo@gmail.com"
    },
    {
      "id": 61692799,
      "name": "Test PM",
      "extraName": "Test PM",
      "emailAddress": "apimaticTest@test.com"
    }
  ]
}
```


# Create New Property Manager

This API call will allow the PMS to pass all data to BookingPal that is required for registering a new PM (Property Manager). All fields are mandatory - PMS must pass this data in order for a PM account to be created. You need to use PMS credentials for this request.

```java
CompletableFuture<PropertyManagerDetailsResponse> createNewPropertyManagerAsync(
    final CreateNewUpdatePropertyManagerRequest body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`CreateNewUpdatePropertyManagerRequest`](../../doc/models/create-new-update-property-manager-request.md) | Body, Required | - |

## Response Type

[`PropertyManagerDetailsResponse`](../../doc/models/property-manager-details-response.md)

## Example Usage

```java
CreateNewUpdatePropertyManagerRequest body = new CreateNewUpdatePropertyManagerRequest();
body.setData(new Company());
body.getData().setCompanyDetails(new CompanyDetails());
body.getData().getCompanyDetails().setAccountId("132");
body.getData().getCompanyDetails().setCompanyName("Test PM");
body.getData().getCompanyDetails().setLanguage("en");
body.getData().getCompanyDetails().setFullName("Test PM");
body.getData().getCompanyDetails().setCompanyAddress(new CompanyAddress());
body.getData().getCompanyDetails().getCompanyAddress().setCountry("US");
body.getData().getCompanyDetails().getCompanyAddress().setState("Test State");
body.getData().getCompanyDetails().getCompanyAddress().setStreetAddress("Test Street");
body.getData().getCompanyDetails().getCompanyAddress().setCity("Test City");
body.getData().getCompanyDetails().getCompanyAddress().setZip("13245");
body.getData().getCompanyDetails().setWebsite("www.testsite.com");
body.getData().getCompanyDetails().setEmail("apimaticPMemail@test.com");
body.getData().getCompanyDetails().setPhone(new Phone());
body.getData().getCompanyDetails().getPhone().setCountryCode("321");
body.getData().getCompanyDetails().getPhone().setNumber("132456");
body.getData().getCompanyDetails().setCurrency("USD");
body.getData().getCompanyDetails().setPassword("password");
body.getData().setPolicies(new Policies());
body.getData().getPolicies().setPaymentPolicy(new PaymentPolicy());
body.getData().getPolicies().getPaymentPolicy().setType(PaymentPolicyTypeEnum.SPLIT);
body.getData().getPolicies().getPaymentPolicy().setSplitPayment(new SplitPayment());
body.getData().getPolicies().getPaymentPolicy().getSplitPayment().setDepositType(DepositTypeEnum.FLAT);
body.getData().getPolicies().getPaymentPolicy().getSplitPayment().setValue(98.84);
body.getData().getPolicies().getPaymentPolicy().getSplitPayment().setSecondPaymentDays(30);
body.getData().getPolicies().setCancellationPolicy(new CancellationPolicy());
body.getData().getPolicies().getCancellationPolicy().setType(CancellationPolicyTypeEnum.MANUAL);
body.getData().getPolicies().getCancellationPolicy().setManualPolicy(new ManualPolicy());
body.getData().getPolicies().getCancellationPolicy().getManualPolicy().setType(ManualPolicyTypeEnum.FLAT);
body.getData().getPolicies().getCancellationPolicy().getManualPolicy().setManualPolicies(new LinkedList<>());

ManualPolicies bodyDataPoliciesCancellationPolicyManualPolicyManualPolicies0 = new ManualPolicies();
bodyDataPoliciesCancellationPolicyManualPolicyManualPolicies0.setChargeValue(20);
bodyDataPoliciesCancellationPolicyManualPolicyManualPolicies0.setBeforeDays(34);
bodyDataPoliciesCancellationPolicyManualPolicyManualPolicies0.setCancellationFee(80.47);
body.getData().getPolicies().getCancellationPolicy().getManualPolicy().getManualPolicies().add(bodyDataPoliciesCancellationPolicyManualPolicyManualPolicies0);

ManualPolicies bodyDataPoliciesCancellationPolicyManualPolicyManualPolicies1 = new ManualPolicies();
bodyDataPoliciesCancellationPolicyManualPolicyManualPolicies1.setChargeValue(12);
bodyDataPoliciesCancellationPolicyManualPolicyManualPolicies1.setBeforeDays(45);
bodyDataPoliciesCancellationPolicyManualPolicyManualPolicies1.setCancellationFee(80.48);
body.getData().getPolicies().getCancellationPolicy().getManualPolicy().getManualPolicies().add(bodyDataPoliciesCancellationPolicyManualPolicyManualPolicies1);

body.getData().getPolicies().setFeeTaxMandatory(new FeeTaxMandatory());
body.getData().getPolicies().getFeeTaxMandatory().setIsFeeMandatory(true);
body.getData().getPolicies().getFeeTaxMandatory().setIsTaxMandatory(true);
body.getData().getPolicies().setTerms("www.test.com");
body.getData().getPolicies().setCheckInTime("36000");
body.getData().getPolicies().setCheckOutTime("57600");
body.getData().getPolicies().setLeadTime(2);
body.getData().setPayment(new Payment());
body.getData().getPayment().setPaymentType(PaymentTypeEnum.MAIL_CHECK);
body.getData().getPayment().setCreditCard(new CreditCard());
body.getData().getPayment().getCreditCard().setCreditCardType(CreditCardTypeEnum.POST);
body.getData().getPayment().getCreditCard().setPaymentGateways(new PaymentGateways());
body.getData().getPayment().getCreditCard().getPaymentGateways().setPaymentGatewaysType(PaymentGatewaysTypeEnum.AUTHORIZE_NET);
body.getData().getPayment().getCreditCard().getPaymentGateways().setUser("test");
body.getData().getPayment().getCreditCard().getPaymentGateways().setSecret("test");
body.getData().getPayment().getCreditCard().getPaymentGateways().setAdditionalField1("");
body.getData().getPayment().getCreditCard().getPaymentGateways().setAdditionalField2("");
body.getData().getPayment().getCreditCard().setCreditCardList(new LinkedList<>());
body.getData().getPayment().getCreditCard().getCreditCardList().add(CreditCardListEnum.AMERICAN_EXPRESS);
body.getData().getPayment().getCreditCard().getCreditCardList().add(CreditCardListEnum.DINERS_CLUB);
body.getData().setIsCompany(true);
body.getData().setOwnerInfo(new Text());
body.getData().getOwnerInfo().setLanguage("EN");
body.getData().getOwnerInfo().setValue("ownerInfo on EN");
body.getData().setNeighborhoodOverview(new Text());
body.getData().getNeighborhoodOverview().setLanguage("EN");
body.getData().getNeighborhoodOverview().setValue("neighborhoodOverview on EN");

propertyManagersController.createNewPropertyManagerAsync(body).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

## Example Response *(as JSON)*

```json
{
  "message": "",
  "errorMessage": [],
  "is_error": false,
  "code": "",
  "data": [
    {
      "companyDetails": {
        "accountId": "132",
        "companyName": "Test PM",
        "language": "en",
        "fullName": "Test PM",
        "companyAddress": {
          "country": "US",
          "state": "Test State",
          "streetAddress": "Test Street",
          "city": "Test City",
          "zip": "13245"
        },
        "website": "www.testsite.com",
        "email": "apimaticPMemail@test.com",
        "phone": {
          "countryCode": "321",
          "number": "132456"
        },
        "password": "password",
        "currency": "USD"
      },
      "policies": {
        "paymentPolicy": {
          "type": "SPLIT",
          "splitPayment": {
            "depositType": "FLAT",
            "value": 4,
            "secondPaymentDays": 30
          }
        },
        "cancellationPolicy": {
          "type": "MANUAL",
          "manualPolicy": {
            "type": "FLAT",
            "manualPolicies": [
              {
                "chargeValue": 20,
                "beforeDays": 34,
                "cancellationFee": 1
              },
              {
                "chargeValue": 12,
                "beforeDays": 45,
                "cancellationFee": 2
              }
            ]
          }
        },
        "feeTaxMandatory": {
          "isFeeMandatory": true,
          "isTaxMandatory": true
        },
        "terms": "www.test.com",
        "checkInTime": "36000",
        "checkOutTime": "57600",
        "leadTime": 2
      },
      "payment": {
        "paymentType": "MAIL_CHECK",
        "creditCard": {
          "creditCardType": "POST",
          "creditCardList": [
            "AMERICAN_EXPRESS",
            "DINERS_CLUB",
            "DISCOVER",
            "MASTER_CARD",
            "VISA"
          ],
          "paymentGateways": {
            "paymentGatewaysType": "AUTHORIZE_NET"
          }
        }
      },
      "id": 61692801,
      "isCompany": true,
      "ownerInfo": {
        "language": "EN",
        "value": "ownerInfo on EN"
      },
      "neighborhoodOverview": {
        "language": "EN",
        "value": "neighborhoodOverview on EN"
      }
    }
  ]
}
```


# Get Property Manager Detail Data

This function will return a property manager’s details that belong to the current user. You need to use your PMS API credentials.

Request Body parameters are the same as for creating PM.

Response is the same as in creating a Property Manager function. Here you do not need to pass all root level fields, but if some are used - all fields inside are mandatory:

- in CompanyDetails Model you can pass any field, and none of them is mandatory
- in Policies Model - you can pass any field,  and none of them is mandatory
- if you do use PaymentPolicy - all fields inside are mandatory
- if you do use CancellationPolicy - all fields inside are mandatory
- if you use Payment Model - all fields inside are mandatory

```java
CompletableFuture<PropertyManagerDetailsResponse> getPropertyManagerDetailDataAsync(
    final String contentType,
    final String id)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `contentType` | `String` | Header, Required | - |
| `id` | `String` | Template, Required | Property Manager ID |

## Response Type

[`PropertyManagerDetailsResponse`](../../doc/models/property-manager-details-response.md)

## Example Usage

```java
String contentType = "application/json";
String id = "61692799";

propertyManagersController.getPropertyManagerDetailDataAsync(contentType, id).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

## Example Response *(as JSON)*

```json
{
  "message": "",
  "errorMessage": [],
  "is_error": false,
  "code": "",
  "data": [
    {
      "isCompany": false,
      "companyDetails": {
        "accountId": "132",
        "companyName": "Test PM",
        "language": "en",
        "fullName": "Test PM",
        "companyAddress": {
          "country": "US",
          "state": "Test State",
          "streetAddress": "Test Street",
          "city": "Test City",
          "zip": "13245"
        },
        "website": "www.testsite.com",
        "email": "apimaticTest@test.com",
        "phone": {
          "countryCode": "321",
          "number": "132456"
        },
        "currency": "USD"
      },
      "policies": {
        "paymentPolicy": {
          "type": "SPLIT",
          "splitPayment": {
            "depositType": "FLAT",
            "value": 4,
            "secondPaymentDays": 30
          }
        },
        "cancellationPolicy": {
          "type": "MANUAL",
          "manualPolicy": {
            "type": "FLAT",
            "manualPolicies": [
              {
                "chargeValue": 20,
                "beforeDays": 34,
                "cancellationFee": 1
              },
              {
                "chargeValue": 12,
                "beforeDays": 45,
                "cancellationFee": 2
              }
            ]
          }
        },
        "feeTaxMandatory": {
          "isFeeMandatory": true,
          "isTaxMandatory": true
        },
        "terms": "www.test.com",
        "checkInTime": "36000",
        "checkOutTime": "57600",
        "leadTime": 2
      },
      "payment": {
        "paymentType": "MAIL_CHECK",
        "creditCard": {
          "creditCardType": "POST",
          "creditCardList": [
            "AMERICAN_EXPRESS",
            "DINERS_CLUB",
            "DISCOVER",
            "MASTER_CARD",
            "VISA"
          ],
          "paymentGateways": {
            "paymentGatewaysType": "AUTHORIZE_NET"
          }
        }
      },
      "id": 61692799,
      "ownerInfo": {
        "language": "EN",
        "value": "ownerInfo on EN"
      },
      "neighborhoodOverview": {
        "language": "EN",
        "value": "neighborhoodOverview on EN"
      }
    }
  ]
}
```


# Update Property Manager Details

This function will update a property manager’s details. In case of an update you do not need to pass all information, but if you have values in one section - all fields inside are mandatory.

```java
CompletableFuture<PropertyManagerDetailsResponse> updatePropertyManagerDetailsAsync(
    final String id,
    final CreateNewUpdatePropertyManagerRequest body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `String` | Template, Required | Property Manager ID |
| `body` | [`CreateNewUpdatePropertyManagerRequest`](../../doc/models/create-new-update-property-manager-request.md) | Body, Required | - |

## Response Type

[`PropertyManagerDetailsResponse`](../../doc/models/property-manager-details-response.md)

## Example Usage

```java
String id = "61692799";
CreateNewUpdatePropertyManagerRequest body = new CreateNewUpdatePropertyManagerRequest();
body.setData(new Company());
body.getData().setCompanyDetails(new CompanyDetails());
body.getData().getCompanyDetails().setAccountId("132");
body.getData().getCompanyDetails().setCompanyName("Update Name");
body.getData().getCompanyDetails().setLanguage("en");
body.getData().getCompanyDetails().setFullName("Update Full Name");
body.getData().getCompanyDetails().setCompanyAddress(new CompanyAddress());
body.getData().getCompanyDetails().getCompanyAddress().setCountry("US");
body.getData().getCompanyDetails().getCompanyAddress().setState("Update State");
body.getData().getCompanyDetails().getCompanyAddress().setStreetAddress("Update Street");
body.getData().getCompanyDetails().getCompanyAddress().setCity("Update City");
body.getData().getCompanyDetails().getCompanyAddress().setZip("13245");
body.getData().getCompanyDetails().setWebsite("www.updatesite.com");
body.getData().getCompanyDetails().setEmail("apimaticTest@test.com");
body.getData().getCompanyDetails().setPhone(new Phone());
body.getData().getCompanyDetails().getPhone().setCountryCode("321");
body.getData().getCompanyDetails().getPhone().setNumber("132456");
body.getData().getCompanyDetails().setCurrency("USD");
body.getData().getCompanyDetails().setPassword("password");
body.getData().setPolicies(new Policies());
body.getData().getPolicies().setPaymentPolicy(new PaymentPolicy());
body.getData().getPolicies().getPaymentPolicy().setType(PaymentPolicyTypeEnum.SPLIT);
body.getData().getPolicies().getPaymentPolicy().setSplitPayment(new SplitPayment());
body.getData().getPolicies().getPaymentPolicy().getSplitPayment().setDepositType(DepositTypeEnum.FLAT);
body.getData().getPolicies().getPaymentPolicy().getSplitPayment().setValue(98.84);
body.getData().getPolicies().getPaymentPolicy().getSplitPayment().setSecondPaymentDays(30);
body.getData().getPolicies().setCancellationPolicy(new CancellationPolicy());
body.getData().getPolicies().getCancellationPolicy().setType(CancellationPolicyTypeEnum.MANUAL);
body.getData().getPolicies().getCancellationPolicy().setManualPolicy(new ManualPolicy());
body.getData().getPolicies().getCancellationPolicy().getManualPolicy().setType(ManualPolicyTypeEnum.FLAT);
body.getData().getPolicies().getCancellationPolicy().getManualPolicy().setManualPolicies(new LinkedList<>());

ManualPolicies bodyDataPoliciesCancellationPolicyManualPolicyManualPolicies0 = new ManualPolicies();
bodyDataPoliciesCancellationPolicyManualPolicyManualPolicies0.setChargeValue(20);
bodyDataPoliciesCancellationPolicyManualPolicyManualPolicies0.setBeforeDays(34);
bodyDataPoliciesCancellationPolicyManualPolicyManualPolicies0.setCancellationFee(80.47);
body.getData().getPolicies().getCancellationPolicy().getManualPolicy().getManualPolicies().add(bodyDataPoliciesCancellationPolicyManualPolicyManualPolicies0);

ManualPolicies bodyDataPoliciesCancellationPolicyManualPolicyManualPolicies1 = new ManualPolicies();
bodyDataPoliciesCancellationPolicyManualPolicyManualPolicies1.setChargeValue(12);
bodyDataPoliciesCancellationPolicyManualPolicyManualPolicies1.setBeforeDays(45);
bodyDataPoliciesCancellationPolicyManualPolicyManualPolicies1.setCancellationFee(80.48);
body.getData().getPolicies().getCancellationPolicy().getManualPolicy().getManualPolicies().add(bodyDataPoliciesCancellationPolicyManualPolicyManualPolicies1);

body.getData().getPolicies().setFeeTaxMandatory(new FeeTaxMandatory());
body.getData().getPolicies().getFeeTaxMandatory().setIsFeeMandatory(true);
body.getData().getPolicies().getFeeTaxMandatory().setIsTaxMandatory(true);
body.getData().getPolicies().setTerms("www.test.com");
body.getData().getPolicies().setCheckInTime("36000");
body.getData().getPolicies().setCheckOutTime("57600");
body.getData().getPolicies().setLeadTime(2);
body.getData().setPayment(new Payment());
body.getData().getPayment().setPaymentType(PaymentTypeEnum.MAIL_CHECK);
body.getData().getPayment().setCreditCard(new CreditCard());
body.getData().getPayment().getCreditCard().setCreditCardType(CreditCardTypeEnum.POST);
body.getData().getPayment().getCreditCard().setPaymentGateways(new PaymentGateways());
body.getData().getPayment().getCreditCard().getPaymentGateways().setPaymentGatewaysType(PaymentGatewaysTypeEnum.AUTHORIZE_NET);
body.getData().getPayment().getCreditCard().getPaymentGateways().setUser("test");
body.getData().getPayment().getCreditCard().getPaymentGateways().setSecret("test");
body.getData().getPayment().getCreditCard().getPaymentGateways().setAdditionalField1("");
body.getData().getPayment().getCreditCard().getPaymentGateways().setAdditionalField2("");
body.getData().getPayment().getCreditCard().setCreditCardList(new LinkedList<>());
body.getData().getPayment().getCreditCard().getCreditCardList().add(CreditCardListEnum.AMERICAN_EXPRESS);
body.getData().getPayment().getCreditCard().getCreditCardList().add(CreditCardListEnum.DINERS_CLUB);
body.getData().setIsCompany(true);
body.getData().setOwnerInfo(new Text());
body.getData().getOwnerInfo().setLanguage("EN");
body.getData().getOwnerInfo().setValue("ownerInfo on EN");
body.getData().setNeighborhoodOverview(new Text());
body.getData().getNeighborhoodOverview().setLanguage("EN");
body.getData().getNeighborhoodOverview().setValue("neighborhoodOverview on EN");

propertyManagersController.updatePropertyManagerDetailsAsync(id, body).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

## Example Response *(as JSON)*

```json
{
  "message": "",
  "errorMessage": [],
  "is_error": false,
  "code": "",
  "data": [
    {
      "companyDetails": {
        "accountId": "132",
        "companyName": "Update Name",
        "language": "en",
        "fullName": "Update Full Name",
        "companyAddress": {
          "country": "US",
          "state": "Update State",
          "streetAddress": "Update Street",
          "city": "Update City",
          "zip": "13245"
        },
        "website": "www.updatesite.com",
        "email": "apimaticTest@test.com",
        "phone": {
          "countryCode": "321",
          "number": "132456"
        },
        "currency": "USD"
      },
      "policies": {
        "paymentPolicy": {
          "type": "SPLIT",
          "splitPayment": {
            "depositType": "FLAT",
            "value": 4,
            "secondPaymentDays": 30
          }
        },
        "cancellationPolicy": {
          "type": "MANUAL",
          "manualPolicy": {
            "type": "FLAT",
            "manualPolicies": [
              {
                "chargeValue": 20,
                "beforeDays": 34,
                "cancellationFee": 1
              },
              {
                "chargeValue": 12,
                "beforeDays": 45,
                "cancellationFee": 2
              }
            ]
          }
        },
        "feeTaxMandatory": {
          "isFeeMandatory": true,
          "isTaxMandatory": true
        },
        "terms": "www.test.com",
        "checkInTime": "36000",
        "checkOutTime": "57600",
        "leadTime": 2
      },
      "payment": {
        "paymentType": "MAIL_CHECK",
        "creditCard": {
          "creditCardType": "POST",
          "creditCardList": [
            "AMERICAN_EXPRESS",
            "DINERS_CLUB",
            "DISCOVER",
            "MASTER_CARD",
            "VISA"
          ],
          "paymentGateways": {
            "paymentGatewaysType": "AUTHORIZE_NET"
          }
        }
      },
      "id": 61692799,
      "isCompany": true,
      "ownerInfo": {
        "language": "EN",
        "value": "ownerInfo on EN"
      },
      "neighborhoodOverview": {
        "language": "EN",
        "value": "neighborhoodOverview on EN"
      }
    }
  ]
}
```

