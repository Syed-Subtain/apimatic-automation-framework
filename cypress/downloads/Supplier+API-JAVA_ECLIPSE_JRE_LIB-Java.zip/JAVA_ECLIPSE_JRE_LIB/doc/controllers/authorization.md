# Authorization

```java
AuthorizationController authorizationController = client.getAuthorizationController();
```

## Class Name

`AuthorizationController`


# Login

In order to begin utilizing the platform APIs, your application must be authenticated and authorized to access domain resources. Follow the URL with your credentials and obtain an authorization token which is used in every request.
You will have 2 types of tokens. One is on the PMS level, and this one should be used when you send requests related to PMS/PM data. For managing properties, you will need a token on PM level, with PM credentials. For every API call it will be noted which API credentials you should use.

```java
CompletableFuture<Authorization> loginAsync(
    final String username,
    final String password)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `username` | `String` | Query, Required | Your account email address (for PMS or PM) |
| `password` | `String` | Query, Required | Your password |

## Response Type

[`Authorization`](../../doc/models/authorization.md)

## Example Usage

```java
String username = "apimaticTest@test.com";
String password = "password";

authorizationController.loginAsync(username, password).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

## Example Response *(as JSON)*

```json
{
  "message": "",
  "errorMessage": [],
  "is_error": false,
  "code": "",
  "token": "a9eaf5b0-c433-450e-991d-8011fc4aa264",
  "partyId": 61692799,
  "organizationId": 61690131,
  "name": "Update Name",
  "currency": "USD",
  "supplierId": 61692799
}
```

