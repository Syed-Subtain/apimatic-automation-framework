# Reservation Notifications

```java
ReservationNotificationsController reservationNotificationsController = client.getReservationNotificationsController();
```

## Class Name

`ReservationNotificationsController`

## Methods

* [Get Reservation by Product](../../doc/controllers/reservation-notifications.md#get-reservation-by-product)
* [Get Reservation by Id](../../doc/controllers/reservation-notifications.md#get-reservation-by-id)
* [Get Reservation by PM](../../doc/controllers/reservation-notifications.md#get-reservation-by-pm)
* [General Reservation Notification-PUSH](../../doc/controllers/reservation-notifications.md#general-reservation-notification-push)
* [New Reservation Notification-PUSH](../../doc/controllers/reservation-notifications.md#new-reservation-notification-push)
* [Reservation Cancellation Notification-PUSH](../../doc/controllers/reservation-notifications.md#reservation-cancellation-notification-push)


# Get Reservation by Product

This function allows logged-in users to get all reservations for the specific product.

```java
CompletableFuture<ReservationGetResponse> getReservationByProductAsync(
    final String productId)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `productId` | `String` | Template, Required | Product ID |

## Response Type

[`ReservationGetResponse`](../../doc/models/reservation-get-response.md)

## Example Usage

```java
String productId = "1235124634";

reservationNotificationsController.getReservationByProductAsync(productId).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```


# Get Reservation by Id

This function allows logged-in users to get reservation data by its reservation ID.

```java
CompletableFuture<ReservationGetResponse> getReservationByIdAsync(
    final String reservationId)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `reservationId` | `String` | Template, Required | Reservation ID |

## Response Type

[`ReservationGetResponse`](../../doc/models/reservation-get-response.md)

## Example Usage

```java
String reservationId = "1235124634";

reservationNotificationsController.getReservationByIdAsync(reservationId).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```


# Get Reservation by PM

This API call will return a list of reservations that belong to the current user.

```java
CompletableFuture<ReservationGetResponse> getReservationByPMAsync(
    final Double page,
    final Double limit)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `page` | `Double` | Query, Optional | The page number for the query |
| `limit` | `Double` | Query, Optional | The limit of records per each page (max 50 records per page) |

## Response Type

[`ReservationGetResponse`](../../doc/models/reservation-get-response.md)

## Example Usage

```java
Double page = 110.38;
Double limit = 237.24;

reservationNotificationsController.getReservationByPMAsync(page, limit).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```


# General Reservation Notification-PUSH

This function sends reservation notification requests to the provided link "reservationLink" in the Push Notification API call.
This is a new API cal added instead of deprecated separate API calls for sending a new reservation request and sending cancel reservation request.

So when BookingPal gets a new reservation, or when some existing reservation is updated or canceled - we will push this POST request to the "reservationLink" link which you set in BookingPal for your PMS (in the Push Notification section).
VERY IMPORTANT: Set "reservationLink" in the Push Notification section only when you implement a new Push function API call. This will be a flag for us that you switched to the new Reservation function.

Important note: In this doc to be able to test this - you need to set a full URL on the Configure button in the right section.

Note: Credit card data will be sent only if PMS should process payment in their system.
Also, data that will be passed to PMS depends on channels - and do we get all of this data. So you should be aware that some data like for example customer address data maybe be mising.
Additional note: Some channels support modification. When you implement this function we will process modification over action type 'UPDATE' and you will get the same reservation ID as you got when the reservation is created, so you will know which reservation should be modified.

```java
CompletableFuture<ReservationPushResponse> generalReservationNotificationPUSHAsync(
    final GeneralReservationNotificationRequest body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`GeneralReservationNotificationRequest`](../../doc/models/general-reservation-notification-request.md) | Body, Required | - |

## Response Type

[`ReservationPushResponse`](../../doc/models/reservation-push-response.md)

## Example Usage

```java
GeneralReservationNotificationRequest body = new GeneralReservationNotificationRequest();
body.setReservationNotificationRequest(new NewReservationNotificationObject());
body.getReservationNotificationRequest().setReservationId("107");
body.getReservationNotificationRequest().setProductId("1234816374");
body.getReservationNotificationRequest().setSupplierId("3731837");
body.getReservationNotificationRequest().setChannelName("Airbnb");
body.getReservationNotificationRequest().setConfirmationId("dasdasd");
body.getReservationNotificationRequest().setUniqueKey("uniqueKey4");
body.getReservationNotificationRequest().setNewState(ReservationStateEnum.CANCELLED);
body.getReservationNotificationRequest().setCustomerName("John Smith");
body.getReservationNotificationRequest().setFromDate(LocalDate.parse("2016-03-13"));
body.getReservationNotificationRequest().setToDate(LocalDate.parse("2016-03-13"));
body.getReservationNotificationRequest().setAdult(2);
body.getReservationNotificationRequest().setChild(0);
body.getReservationNotificationRequest().setEmail("andrewtesttest222@gmail.com");
body.getReservationNotificationRequest().setTotal(105.94);
body.setAction(GeneralReservationNotificationActionTypeEnum.CREATE);

reservationNotificationsController.generalReservationNotificationPUSHAsync(body).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

## Example Response *(as JSON)*

```json
{
  "altId": "45717",
  "is_error": false,
  "code": "",
  "message": "Reservation is processed."
}
```


# New Reservation Notification-PUSH

DEPRECATED. Instead, check General Reservation Notification.

This function sends the request to the provided link about a new reservation. So when BookingPal gets a new reservation - we will push this POST request to the link which you set in BookingPal for your PMS (in Push Notification section).

Important note: In this doc to be able to test this - you need to set a full URL on the Configure button in the right section.

Note: Credit card data will be sent only if PMS should process payment in their system.
Also, data that will be passed to PMS depends on channels - and do we get all of this data. So we have column ‘Mandatory’ to be aware that some data will be missing if we do not get them from a channel (like some guest address data).
Additional note: Some channels support modification. At this moment we will process modification first by canceling the current reservation and then we will process the new regular reservation. In these cases for tracking purposes, you can use channel reservation ID (confirmationID) which should be the same in these cases.

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<ReservationPushResponse> newReservationNotificationPUSHAsync(
    final ReservationNotificationObject body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`ReservationNotificationObject`](../../doc/models/reservation-notification-object.md) | Body, Required | - |

## Response Type

[`ReservationPushResponse`](../../doc/models/reservation-push-response.md)

## Example Usage

```java
ReservationNotificationObject body = new ReservationNotificationObject();
body.setReservationId("107");
body.setProductId("1234816374");
body.setSupplierId("3731837");
body.setChannelName("Airbnb");
body.setConfirmationId("dasdasd");
body.setUniqueKey("uniqueKey4");
body.setNewState(ReservationStateEnum.CANCELLED);
body.setCustomerName("John Smith");
body.setFromDate(LocalDate.parse("2016-03-13"));
body.setToDate(LocalDate.parse("2016-03-13"));
body.setAdult(2);
body.setChild(0);
body.setEmail("andrewtesttest222@gmail.com");
body.setTotal(248.34);
body.setFees(new LinkedList<>());

ReservationFeeNotificationModel bodyFees0 = new ReservationFeeNotificationModel();
bodyFees0.setName("Cleaning Fee");
bodyFees0.setValue(128.43);
bodyFees0.setId("937-4");
body.getFees().add(bodyFees0);

body.setTaxes(new LinkedList<>());

ReservationTaxNotificationModel bodyTaxes0 = new ReservationTaxNotificationModel();
bodyTaxes0.setName("State of Florida-Lake County State Tax");
bodyTaxes0.setValue(34.71);
bodyTaxes0.setId("22");
body.getTaxes().add(bodyTaxes0);

body.setCommission(new ReservationCommissionsNotificationModel());
body.getCommission().setChannelCommission(66.2);
body.getCommission().setCommission(135.76);
body.setRate(new ReservationRateNotifcationModel());
body.getRate().setOriginalRackRate(62.3);
body.getRate().setNetRate(93.18);
body.getRate().setNewPublishedRackRate(41.54);

reservationNotificationsController.newReservationNotificationPUSHAsync(body).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

## Example Response *(as JSON)*

```json
{
  "altId": "45717",
  "is_error": false,
  "code": "",
  "message": "Reservation is processed."
}
```


# Reservation Cancellation Notification-PUSH

DEPRECATED. Instead, check General Reservation Notification.

This function sends the request to the provided link about the reservation cancellation. So when BookingPal gets a cancel reservation request from the channel - we will push this POST request to the link which you set in BookingPal for your PMS (in Push Notification section).

Important note: In this doc to be able to test this - you need to set a full URL on the Configure button in the right section.

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<ReservationPushResponse> reservationCancellationNotificationPUSHAsync(
    final CancelReservationNotificationObject body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`CancelReservationNotificationObject`](../../doc/models/cancel-reservation-notification-object.md) | Body, Required | - |

## Response Type

[`ReservationPushResponse`](../../doc/models/reservation-push-response.md)

## Example Usage

```java
CancelReservationNotificationObject body = new CancelReservationNotificationObject();
body.setReservationId("107");
body.setProductId("1234816374");
body.setSupplierId(3731837);
body.setChannelName("TestAndrew");
body.setConfirmationId("dasdasd");
body.setUniqueKey("uniqueKey4");
body.setNewState("newState8");
body.setCustomerName("John Smith");
body.setFromDate(LocalDate.parse("2016-03-13"));
body.setToDate(LocalDate.parse("2016-03-13"));
body.setAdult(2);
body.setChild(0);
body.setEmail("andrewtesttest222@gmail.com");
body.setTotal(248.34);

reservationNotificationsController.reservationCancellationNotificationPUSHAsync(body).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

## Example Response *(as JSON)*

```json
{
  "altId": "45717",
  "is_error": false,
  "code": "",
  "message": "Cancellation accepted"
}
```

