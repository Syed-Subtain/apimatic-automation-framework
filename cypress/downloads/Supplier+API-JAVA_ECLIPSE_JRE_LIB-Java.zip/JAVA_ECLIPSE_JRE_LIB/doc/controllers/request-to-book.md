# Request to Book

```java
RequestToBookController requestToBookController = client.getRequestToBookController();
```

## Class Name

`RequestToBookController`

## Methods

* [Request to Book-Request](../../doc/controllers/request-to-book.md#request-to-book-request)
* [Request to Book-Answer From PMS](../../doc/controllers/request-to-book.md#request-to-book-answer-from-pms)
* [Request to Book-Test](../../doc/controllers/request-to-book.md#request-to-book-test)


# Request to Book-Request

This will be a request which we will send to PMS when we get a request to book from the channel.
So when BookingPal gets a new request to book request - we will push this POST request to the link which you set in BookingPal for your PMS (in Push Notification section if you set link "reservationLink" - notification will be sent on this link. Otherwise it will be set on link "requestToBook").

Important note: In this doc to be able to test this - you need to set a full URL on the Configure button in the right section.

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<ReservationPushResponse> requestToBookRequestAsync(
    final RequestToBookRequestModel body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`RequestToBookRequestModel`](../../doc/models/request-to-book-request-model.md) | Body, Required | - |

## Response Type

[`ReservationPushResponse`](../../doc/models/reservation-push-response.md)

## Example Usage

```java
RequestToBookRequestModel body = new RequestToBookRequestModel();
body.setRezcasterNotificationRequest(new ReservationNotificationObject());
body.getRezcasterNotificationRequest().setReservationId("107");
body.getRezcasterNotificationRequest().setProductId("1234816374");
body.getRezcasterNotificationRequest().setSupplierId("3731837");
body.getRezcasterNotificationRequest().setChannelName("Airbnb");
body.getRezcasterNotificationRequest().setConfirmationId("dasdasd");
body.getRezcasterNotificationRequest().setUniqueKey("uniqueKey4");
body.getRezcasterNotificationRequest().setNewState(ReservationStateEnum.CANCELLED);
body.getRezcasterNotificationRequest().setCustomerName("John Smith");
body.getRezcasterNotificationRequest().setFromDate(LocalDate.parse("2016-03-13"));
body.getRezcasterNotificationRequest().setToDate(LocalDate.parse("2016-03-13"));
body.getRezcasterNotificationRequest().setAdult(2);
body.getRezcasterNotificationRequest().setChild(0);
body.getRezcasterNotificationRequest().setEmail("andrewtesttest222@gmail.com");
body.getRezcasterNotificationRequest().setTotal(23.76);
body.getRezcasterNotificationRequest().setFees(new LinkedList<>());

ReservationFeeNotificationModel bodyRezcasterNotificationRequestFees0 = new ReservationFeeNotificationModel();
bodyRezcasterNotificationRequestFees0.setName("Cleaning Fee");
bodyRezcasterNotificationRequestFees0.setValue(144.53);
bodyRezcasterNotificationRequestFees0.setId("937-4");
body.getRezcasterNotificationRequest().getFees().add(bodyRezcasterNotificationRequestFees0);

ReservationFeeNotificationModel bodyRezcasterNotificationRequestFees1 = new ReservationFeeNotificationModel();
bodyRezcasterNotificationRequestFees1.setName("Cleaning Fee");
bodyRezcasterNotificationRequestFees1.setValue(144.54);
bodyRezcasterNotificationRequestFees1.setId("937-4");
body.getRezcasterNotificationRequest().getFees().add(bodyRezcasterNotificationRequestFees1);

body.getRezcasterNotificationRequest().setTaxes(new LinkedList<>());

ReservationTaxNotificationModel bodyRezcasterNotificationRequestTaxes0 = new ReservationTaxNotificationModel();
bodyRezcasterNotificationRequestTaxes0.setName("State of Florida-Lake County State Tax");
bodyRezcasterNotificationRequestTaxes0.setValue(134.53);
bodyRezcasterNotificationRequestTaxes0.setId("22");
body.getRezcasterNotificationRequest().getTaxes().add(bodyRezcasterNotificationRequestTaxes0);

ReservationTaxNotificationModel bodyRezcasterNotificationRequestTaxes1 = new ReservationTaxNotificationModel();
bodyRezcasterNotificationRequestTaxes1.setName("State of Florida-Lake County State Tax");
bodyRezcasterNotificationRequestTaxes1.setValue(134.54);
bodyRezcasterNotificationRequestTaxes1.setId("22");
body.getRezcasterNotificationRequest().getTaxes().add(bodyRezcasterNotificationRequestTaxes1);

body.getRezcasterNotificationRequest().setCommission(new ReservationCommissionsNotificationModel());
body.getRezcasterNotificationRequest().getCommission().setChannelCommission(69.7);
body.getRezcasterNotificationRequest().getCommission().setCommission(0.14);
body.getRezcasterNotificationRequest().setRate(new ReservationRateNotifcationModel());
body.getRezcasterNotificationRequest().getRate().setOriginalRackRate(16.12);
body.getRezcasterNotificationRequest().getRate().setNetRate(47);
body.getRezcasterNotificationRequest().getRate().setNewPublishedRackRate(87.72);
body.setAction("RESERVATION_REQUEST");
body.setReservationId(252);
body.setExpiresAt(LocalDate.parse("2016-03-13"));

requestToBookController.requestToBookRequestAsync(body).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

## Example Response *(as JSON)*

```json
{
  "altId": "45717",
  "is_error": false,
  "code": "",
  "message": "Request to book is accepted."
}
```


# Request to Book-Answer From PMS

This is an API call that you should use for accepting on avoiding requests to book.

```java
CompletableFuture<APIResponseWithoutData> requestToBookAnswerFromPMSAsync(
    final RequestToBookAnswerFromPMSRequest body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`RequestToBookAnswerFromPMSRequest`](../../doc/models/request-to-book-answer-from-pms-request.md) | Body, Required | - |

## Response Type

[`APIResponseWithoutData`](../../doc/models/api-response-without-data.md)

## Example Usage

```java
RequestToBookAnswerFromPMSRequest body = new RequestToBookAnswerFromPMSRequest();
body.setData(new FunctionsRequestToBook());
body.getData().setRequestToBookType(RequestToBookTypeEnum.DENY);
body.getData().setReservationId(1235124634);
body.getData().setRequestToBookDeclineReasonType(RequestToBookDeclineReasonTypeEnum.DATES_NOT_AVAILABLE);
body.getData().setDeclineMessageToGuest("these dates are not available any more. ");

requestToBookController.requestToBookAnswerFromPMSAsync(body).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

## Example Response *(as JSON)*

```json
{
  "message": "Request to book answer accepted",
  "errorMessage": [],
  "is_error": false,
  "code": ""
}
```


# Request to Book-Test

Since you can not get the request to book on our test environment (since this first needs to be created on the channel) We provide the possibility for PMS to test this request with some random filled data in our system. So when you call this API function - we will send you push notification for the request to book for a provided property ID.

```java
CompletableFuture<APIResponseWithoutData> requestToBookTestAsync(
    final RequestToBookTestRequest body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`RequestToBookTestRequest`](../../doc/models/request-to-book-test-request.md) | Body, Required | - |

## Response Type

[`APIResponseWithoutData`](../../doc/models/api-response-without-data.md)

## Example Usage

```java
RequestToBookTestRequest body = new RequestToBookTestRequest();
body.setData(new FunctionsRequestToBookTest());
body.getData().setAction(RequestToBookTestActionEnum.RESERVATION_REQUEST_VOIDED);
body.getData().setProductId(1235124634);

requestToBookController.requestToBookTestAsync(body).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

## Example Response *(as JSON)*

```json
{
  "message": "Request to book test accepted",
  "errorMessage": [],
  "is_error": false,
  "code": "",
  "data": []
}
```

