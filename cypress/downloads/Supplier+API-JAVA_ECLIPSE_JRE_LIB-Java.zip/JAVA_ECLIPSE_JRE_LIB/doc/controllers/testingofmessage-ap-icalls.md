# Testingofmessage AP Icalls

```java
TestingofmessageAPIcallsController testingofmessageAPIcallsController = client.getTestingofmessageAPIcallsController();
```

## Class Name

`TestingofmessageAPIcallsController`

## Methods

* [Get Test Message Threads](../../doc/controllers/testingofmessage-ap-icalls.md#get-test-message-threads)
* [Get Test Message List for Specific Thread](../../doc/controllers/testingofmessage-ap-icalls.md#get-test-message-list-for-specific-thread)
* [Post New Test Message for Specific Thread](../../doc/controllers/testingofmessage-ap-icalls.md#post-new-test-message-for-specific-thread)


# Get Test Message Threads

This function allows the logged in user to get all message threads or message threads with an unresponded message from guest for the whole PM. You need to use PM credentials. There is also paging as optional values. If you do not pass this value, we will return the first page and 10 threads per page.

Since API calls for messages depend on channel connections and these values will exist in BookingPal only if guests on channel create some message, these calls can work only on production. So for testing purposes we’ve  built an additional endpoint with the same API calls where you will be able to test these calls.

Note: To be able to test these calls, you need to have at least 1 property, since we will in response return you messages for 1 property from your PM.

```java
CompletableFuture<GetMessageThreadsResponse> getTestMessageThreadsAsync(
    final int page,
    final int limit,
    final String threadType)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `page` | `int` | Query, Required | - |
| `limit` | `int` | Query, Required | - |
| `threadType` | `String` | Template, Required | Request all threads or only threads with unanswered message {new,all} |

## Response Type

[`GetMessageThreadsResponse`](../../doc/models/get-message-threads-response.md)

## Example Usage

```java
int page = 2;
int limit = 5;
String threadType = "threadType6";

testingOfMessageAPICallsController.getTestMessageThreadsAsync(page, limit, threadType).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```


# Get Test Message List for Specific Thread

Since API calls for messages depend on channel connections and these values will exist in BookingPal only if guests on channel create some message, these calls can work only on production. So for testing purposes, we’ve built an additional endpoint with the same API calls where you will be able to test these calls.

This function allows the logged-in user to get a list of all messages from passed thread Id. You need to use PM credentials

Note: To be able to test these calls, you need to have at least 1 property, since we will in response return you messages for 1 property from your PM.

```java
CompletableFuture<GetMessageListForSpecificThreadResponse> getTestMessageListForSpecificThreadAsync(
    final String threadId)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `threadId` | `String` | Template, Required | ID of thread |

## Response Type

[`GetMessageListForSpecificThreadResponse`](../../doc/models/get-message-list-for-specific-thread-response.md)

## Example Usage

```java
String threadId = "123";

testingOfMessageAPICallsController.getTestMessageListForSpecificThreadAsync(threadId).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

## Example Response *(as JSON)*

```json
{
  "message": "",
  "errorMessage": [],
  "is_error": false,
  "code": "",
  "data": [
    {
      "messages": [
        {
          "message": "Test message",
          "createdAt": "2019-11-25T12:32:39.000+0000",
          "user": "PROPERTY_MANAGER"
        }
      ]
    }
  ]
}
```


# Post New Test Message for Specific Thread

This function will allow PM to post new messages in already existing threads. Since this call is only for testing - we will not actually save these passed values.

Since API calls for messages depend on channel connections and these values will exist in BookingPal only if guests on channel create some message, these calls can work only on production. So for testing purposes, we’ve built an additional endpoint with the same API calls where you will be able to test these calls.

Note: To be able to test these calls, you need to have at least 1 property, since we will in response return to you messages for 1 property from your PM.

```java
CompletableFuture<APIResponseWithoutData> postNewTestMessageForSpecificThreadAsync(
    final PostNewMessageForSpecificThreadRequest body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`PostNewMessageForSpecificThreadRequest`](../../doc/models/post-new-message-for-specific-thread-request.md) | Body, Required | - |

## Response Type

[`APIResponseWithoutData`](../../doc/models/api-response-without-data.md)

## Example Usage

```java
PostNewMessageForSpecificThreadRequest body = new PostNewMessageForSpecificThreadRequest();
body.setData(new MessageRequestFromSupplier());
body.getData().setThreadId(5656);
body.getData().setMessage("new message");

testingOfMessageAPICallsController.postNewTestMessageForSpecificThreadAsync(body).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

## Example Response *(as JSON)*

```json
{
  "message": "Your request was received and put in queue",
  "errorMessage": [],
  "is_error": false,
  "code": ""
}
```

