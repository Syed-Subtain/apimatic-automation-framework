
# Fee Tax Mandatory Setting

## Structure

`FeeTaxMandatorySetting`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `ProductId` | `int` | Required | Product id | int getProductId() | setProductId(int productId) |
| `IsFeeMandatory` | `boolean` | Required | Fee is mandatory | boolean getIsFeeMandatory() | setIsFeeMandatory(boolean isFeeMandatory) |
| `IsTaxMandatory` | `boolean` | Required | Tax is mandatory | boolean getIsTaxMandatory() | setIsTaxMandatory(boolean isTaxMandatory) |

## Example (as JSON)

```json
{
  "productId": 1235124634,
  "isFeeMandatory": false,
  "isTaxMandatory": false
}
```

