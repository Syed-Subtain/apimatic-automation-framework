
# Bedroom

## Structure

`Bedroom`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Beds` | [`Beds`](../../doc/models/beds.md) | Required | - | Beds getBeds() | setBeds(Beds beds) |
| `Type` | [`BedroomTypeEnum`](../../doc/models/bedroom-type-enum.md) | Required | - | BedroomTypeEnum getType() | setType(BedroomTypeEnum type) |
| `PrivateBathroom` | `boolean` | Required | Room have private bathroom | boolean getPrivateBathroom() | setPrivateBathroom(boolean privateBathroom) |

## Example (as JSON)

```json
{
  "beds": {
    "bed": [
      {
        "bedType": "RMA113",
        "count": 1
      },
      {
        "bedType": "RMA58",
        "count": 1
      }
    ]
  },
  "type": "Bedroom",
  "privateBathroom": false
}
```

