
# Key Collection Checkinmethod Enum

## Enumeration

`KeyCollectionCheckinmethodEnum`

## Fields

| Name |
|  --- |
| `Doorman` |
| `LockBox` |
| `SmartLock` |
| `Keypad` |
| `InPersonMeet` |
| `Other` |
| `FrontDesk` |
| `SecretSpot` |
| `InstructionContactUs` |

## Example

```
doorman
```

