
# Yield Modifier Enum

## Enumeration

`YieldModifierEnum`

## Fields

| Name |
|  --- |
| `INCREASEPERCENT` |
| `DECREASEPERCENT` |
| `INCREASEAMOUNT` |
| `DECREASEAMOUNT` |

## Example

```
INCREASE_PERCENT
```

