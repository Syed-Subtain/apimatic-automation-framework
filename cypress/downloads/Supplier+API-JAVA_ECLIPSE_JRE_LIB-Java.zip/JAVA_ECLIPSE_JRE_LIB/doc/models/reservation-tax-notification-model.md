
# Reservation Tax Notification Model

Model used for taxes in reservation push notification

## Structure

`ReservationTaxNotificationModel`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Id` | `String` | Optional | Tax altID (alt ID which PMS sent over API) | String getId() | setId(String id) |
| `Name` | `String` | Required | Tax name | String getName() | setName(String name) |
| `Value` | `double` | Required | Tax value | double getValue() | setValue(double value) |

## Example (as JSON)

```json
{
  "id": "22",
  "name": "State of Florida-Lake County State Tax",
  "value": 5
}
```

