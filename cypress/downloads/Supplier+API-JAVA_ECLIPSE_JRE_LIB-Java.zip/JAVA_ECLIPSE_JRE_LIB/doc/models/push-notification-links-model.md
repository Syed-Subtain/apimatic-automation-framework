
# Push Notification Links Model

Model for push notification links

## Structure

`PushNotificationLinksModel`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `BookLink` | `String` | Optional | DEPRECATED. Check "reservationLink" field instead.  -  Link for getting notifications about new reservations | String getBookLink() | setBookLink(String bookLink) |
| `CancelLink` | `String` | Optional | DEPRECATED. Check "reservationLink" field instead. - Link for getting notification about cancel reservation | String getCancelLink() | setCancelLink(String cancelLink) |
| `AsyncPush` | `String` | Optional | Link for push data for async messages | String getAsyncPush() | setAsyncPush(String asyncPush) |
| `RequestToBook` | `String` | Optional | DEPRECATED. Check "reservationLink" field instead. Link for request to book for AirBnb | String getRequestToBook() | setRequestToBook(String requestToBook) |
| `ReservationLink` | `String` | Optional | Link for notifications for reservations. It is added instead of deprecated fields bookLink, cancelLink and requestToBook. On this link it will be pushed all reservation notification (new, cancel and update, and request to book requests) when you set this link. It is very important that you first implement slightly changed reservation notification and to accept new modified object of this push message. When you add this link - we will assume that you finish new implementation and you will get all reservation request on this endpoint with slight changed reservation object. | String getReservationLink() | setReservationLink(String reservationLink) |
| `UseJson` | `Boolean` | Optional | optional boolean field to get the response in JSON or XML format. | Boolean getUseJson() | setUseJson(Boolean useJson) |

## Example (as JSON)

```json
{
  "bookLink": "https://newreservationnotification.link",
  "cancelLink": "https://cancelreservation.link",
  "asyncPush": "https://asyncpush.link",
  "requestToBook": "https://requestToBook.link",
  "reservationLink": "https://reservation.link",
  "useJson": true
}
```

