
# Cancellation Policy Type Enum

## Enumeration

`CancellationPolicyTypeEnum`

## Fields

| Name |
|  --- |
| `FULLYREFUNDABLE` |
| `NONREFUNDABLE` |
| `MANUAL` |

## Example

```
FULLY_REFUNDABLE
```

