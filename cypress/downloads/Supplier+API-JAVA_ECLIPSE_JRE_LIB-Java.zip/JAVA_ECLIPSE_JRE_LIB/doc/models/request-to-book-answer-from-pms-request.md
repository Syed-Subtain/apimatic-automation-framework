
# Request to Book Answer From PMS Request

## Structure

`RequestToBookAnswerFromPMSRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Data` | [`FunctionsRequestToBook`](../../doc/models/functions-request-to-book.md) | Required | Request to book answer model | FunctionsRequestToBook getData() | setData(FunctionsRequestToBook data) |

## Example (as JSON)

```json
{
  "data": {
    "requestToBookType": "DENY",
    "requestToBookDeclineReasonType": "DATES_NOT_AVAILABLE",
    "declineMessageToGuest": "these dates are not available any more. ",
    "reservationId": 1235124634
  }
}
```

