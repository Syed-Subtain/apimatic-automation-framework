
# License Requirement Meta

## Structure

`LicenseRequirementMeta`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Ruid` | `String` | Optional | requirement unique id meta data | String getRuid() | setRuid(String ruid) |

## Example (as JSON)

```json
{
  "ruid": null
}
```

