
# Booking Type Enum

Channel booking Type

## Enumeration

`BookingTypeEnum`

## Fields

| Name |
|  --- |
| `Instant` |
| `RequestToBook` |
| `Both` |

## Example

```
Instant
```

