
# Fullupdate Images Request

## Structure

`FullupdateImagesRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Data` | [`ImagesURLForFullUpdate`](../../doc/models/images-url-for-full-update.md) | Required | Model with one image URL for one property used for inserting new image | ImagesURLForFullUpdate getData() | setData(ImagesURLForFullUpdate data) |

## Example (as JSON)

```json
{
  "data": {
    "productId": 1234893572,
    "images": [
      {
        "url": "http://aff.bstatic.com/images/hotel/max500/110/11069097.jpg",
        "tags": [
          1,
          2,
          3
        ]
      },
      {
        "url": "http://aff.bstatic.com/images/hotel/max500/110/11069097.jpg",
        "tags": [
          1,
          2,
          3
        ]
      }
    ]
  }
}
```

