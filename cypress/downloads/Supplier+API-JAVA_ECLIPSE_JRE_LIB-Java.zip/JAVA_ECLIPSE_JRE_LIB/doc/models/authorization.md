
# Authorization

Authorization (Login) response

## Structure

`Authorization`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Token` | `String` | Required | Generated token for authorization. It must be used in every request to API as param jwt. Token is valid for 1h | String getToken() | setToken(String token) |
| `Message` | `String` | Required | Message | String getMessage() | setMessage(String message) |
| `IsError` | `boolean` | Required | Is request success or not | boolean getIsError() | setIsError(boolean isError) |
| `ErrorMessage` | `List<String>` | Required | Error Message(s) in Array format | List<String> getErrorMessage() | setErrorMessage(List<String> errorMessage) |
| `Code` | `String` | Optional | Response code | String getCode() | setCode(String code) |
| `OrganizationId` | `int` | Required | Organization id - PMS ID | int getOrganizationId() | setOrganizationId(int organizationId) |
| `SupplierId` | `int` | Required | Supplier ID (Property Manager ID - or PMS ID - depend on account on which you are logged in) | int getSupplierId() | setSupplierId(int supplierId) |
| `PartyId` | `int` | Required | Deprecated field. It will be removed in version 3.3. Please use supplierId field instead | int getPartyId() | setPartyId(int partyId) |
| `Name` | `String` | Required | Account name | String getName() | setName(String name) |
| `Currency` | `String` | Required | Account currency | String getCurrency() | setCurrency(String currency) |

## Example (as JSON)

```json
{
  "message": "",
  "errorMessage": [],
  "is_error": false,
  "code": "",
  "token": "a9eaf5b0-c433-450e-991d-8011fc4aa264",
  "partyId": 61692799,
  "organizationId": 61690131,
  "name": "Update Name",
  "currency": "USD",
  "supplierId": 61692799
}
```

