
# Reservation Rate Notifcation Model

## Structure

`ReservationRateNotifcationModel`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `OriginalRackRate` | `Double` | Optional | Original rack rate. Rate received from PMS (rate without additional channel commission or any additional markup) | Double getOriginalRackRate() | setOriginalRackRate(Double originalRackRate) |
| `NetRate` | `Double` | Optional | Net rate (rate which PM will get - so without any additional commissions). | Double getNetRate() | setNetRate(Double netRate) |
| `NewPublishedRackRate` | `Double` | Optional | New published rack rate (rate which guest paid - rate with all commissions). | Double getNewPublishedRackRate() | setNewPublishedRackRate(Double newPublishedRackRate) |

## Example (as JSON)

```json
{
  "originalRackRate": 400,
  "netRate": 400,
  "newPublishedRackRate": 422
}
```

