
# Manual Policy Type Enum

## Enumeration

`ManualPolicyTypeEnum`

## Fields

| Name |
|  --- |
| `PERCENTAGE` |
| `FLAT` |

## Example

```
PERCENTAGE
```

