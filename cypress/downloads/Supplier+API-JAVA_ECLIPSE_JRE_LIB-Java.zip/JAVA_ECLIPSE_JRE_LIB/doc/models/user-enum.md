
# User Enum

## Enumeration

`UserEnum`

## Fields

| Name |
|  --- |
| `PROPERTYMANAGER` |
| `GUEST` |

## Example

```
PROPERTY_MANAGER
```

