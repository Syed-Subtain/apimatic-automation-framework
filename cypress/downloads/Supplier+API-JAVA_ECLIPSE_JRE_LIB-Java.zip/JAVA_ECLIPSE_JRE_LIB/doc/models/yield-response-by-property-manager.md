
# Yield Response by Property Manager

## Structure

`YieldResponseByPropertyManager`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Message` | `String` | Required | text info message | String getMessage() | setMessage(String message) |
| `ErrorMessage` | `List<String>` | Required | List of error messages | List<String> getErrorMessage() | setErrorMessage(List<String> errorMessage) |
| `IsError` | `boolean` | Required | Is error (default = false) | boolean getIsError() | setIsError(boolean isError) |
| `Code` | `String` | Required | Code of message | String getCode() | setCode(String code) |
| `Data` | [`ChannelMarkUpYield`](../../doc/models/channel-mark-up-yield.md) | Required | - | ChannelMarkUpYield getData() | setData(ChannelMarkUpYield data) |

## Example (as JSON)

```json
{
  "message": "message0",
  "errorMessage": [
    "errorMessage2",
    "errorMessage3",
    "errorMessage4"
  ],
  "is_error": false,
  "code": "code8",
  "data": {
    "channelMarkup": {
      "beginDate": "beginDate6",
      "endDate": "endDate2",
      "amount": 5.22,
      "modifier": "modifier6",
      "channelAbbreviation": "channelAbbreviation4"
    }
  }
}
```

