
# Create Yield Request

## Structure

`CreateYieldRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Data` | [`TransportYield`](../../doc/models/transport-yield.md) | Required | - | TransportYield getData() | setData(TransportYield data) |

## Example (as JSON)

```json
{
  "data": {
    "productId": 184,
    "weekend": null,
    "lengthOfStay": null,
    "dateRange": null,
    "channelMarkup": null
  }
}
```

