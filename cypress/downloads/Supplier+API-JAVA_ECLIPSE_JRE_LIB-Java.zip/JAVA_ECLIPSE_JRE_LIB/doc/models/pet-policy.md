
# Pet Policy

## Structure

`PetPolicy`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `AllowedPets` | [`AllowedPetsTypeEnum`](../../doc/models/allowed-pets-type-enum.md) | Required | - | AllowedPetsTypeEnum getAllowedPets() | setAllowedPets(AllowedPetsTypeEnum allowedPets) |
| `ChargePets` | `String` | Optional | Charge parking. Example: “Free”, “$ 100”. | String getChargePets() | setChargePets(String chargePets) |

## Example (as JSON)

```json
{
  "allowedPets": "Allowed",
  "chargePets": "Free"
}
```

