
# License Requirement Response Object

## Structure

`LicenseRequirementResponseObject`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Data` | [`List<LicenseRequirementsDataObjectDetail>`](../../doc/models/license-requirements-data-object-detail.md) | Optional | - | List<LicenseRequirementsDataObjectDetail> getData() | setData(List<LicenseRequirementsDataObjectDetail> data) |
| `Meta` | [`List<LicenseRequirementMeta>`](../../doc/models/license-requirement-meta.md) | Optional | - | List<LicenseRequirementMeta> getMeta() | setMeta(List<LicenseRequirementMeta> meta) |
| `Warnings` | `List<String>` | Optional | List of warning messages | List<String> getWarnings() | setWarnings(List<String> warnings) |
| `Errors` | `List<String>` | Optional | List of error messages | List<String> getErrors() | setErrors(List<String> errors) |

## Example (as JSON)

```json
{
  "data": null,
  "meta": null,
  "warnings": null,
  "errors": null
}
```

