
# License Response Indicator Data

## Structure

`LicenseResponseIndicatorData`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Success` | `String` | Optional | success indicator | String getSuccess() | setSuccess(String success) |

## Example (as JSON)

```json
{
  "success": null
}
```

