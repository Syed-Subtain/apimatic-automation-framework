
# Add Image Request

## Structure

`AddImageRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Data` | [`ImageURLForAdd`](../../doc/models/image-url-for-add.md) | Required | Model with one image URL for one property used for inserting new image | ImageURLForAdd getData() | setData(ImageURLForAdd data) |

## Example (as JSON)

```json
{
  "data": {
    "productId": 1234879670,
    "image": {
      "url": "http://www.pm-name.com/prop_img/1_2345_5_19.jpg",
      "tags": [
        1,
        2,
        3
      ]
    }
  }
}
```

