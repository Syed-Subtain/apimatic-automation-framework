
# Kind of Internet Type Enum

## Enumeration

`KindOfInternetTypeEnum`

## Fields

| Name |
|  --- |
| `WiFi` |
| `Wired` |

## Example

```
WiFi
```

