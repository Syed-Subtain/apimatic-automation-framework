
# Channel Mark up Yield Info

## Structure

`ChannelMarkUpYieldInfo`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `BeginDate` | `String` | Required | begin date | String getBeginDate() | setBeginDate(String beginDate) |
| `EndDate` | `String` | Required | end date | String getEndDate() | setEndDate(String endDate) |
| `Amount` | `double` | Required | the amount | double getAmount() | setAmount(double amount) |
| `Modifier` | `String` | Required | modifier | String getModifier() | setModifier(String modifier) |
| `ChannelAbbreviation` | `String` | Required | channel abbreviation | String getChannelAbbreviation() | setChannelAbbreviation(String channelAbbreviation) |

## Example (as JSON)

```json
{
  "beginDate": "beginDate6",
  "endDate": "endDate2",
  "amount": 56.78,
  "modifier": "modifier6",
  "channelAbbreviation": "channelAbbreviation6"
}
```

