
# Taxis Type Enum

## Enumeration

`TaxisTypeEnum`

## Fields

| Name |
|  --- |
| `SalesTaxIncluded` |
| `SalesTaxExcluded` |

## Example

```
SalesTaxIncluded
```

