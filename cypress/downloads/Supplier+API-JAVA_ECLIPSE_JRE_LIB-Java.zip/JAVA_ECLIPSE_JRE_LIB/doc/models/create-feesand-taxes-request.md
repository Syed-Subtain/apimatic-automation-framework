
# Create Feesand Taxes Request

## Structure

`CreateFeesandTaxesRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Data` | [`FeesandTaxes`](../../doc/models/feesand-taxes.md) | Required | - | FeesandTaxes getData() | setData(FeesandTaxes data) |

## Example (as JSON)

```json
{
  "data": {
    "productId": 184,
    "fees": null,
    "taxes": null
  }
}
```

