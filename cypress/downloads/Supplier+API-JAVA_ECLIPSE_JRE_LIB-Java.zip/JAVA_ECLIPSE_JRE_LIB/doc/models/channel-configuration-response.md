
# Channel Configuration Response

## Structure

`ChannelConfigurationResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Message` | `String` | Required | text info message | String getMessage() | setMessage(String message) |
| `ErrorMessage` | `List<String>` | Required | List of error messages | List<String> getErrorMessage() | setErrorMessage(List<String> errorMessage) |
| `IsError` | `boolean` | Required | Is error (default = false) | boolean getIsError() | setIsError(boolean isError) |
| `Code` | `String` | Required | Code of message | String getCode() | setCode(String code) |
| `Data` | [`List<ChannelConfigurationDetail>`](../../doc/models/channel-configuration-detail.md) | Required | - | List<ChannelConfigurationDetail> getData() | setData(List<ChannelConfigurationDetail> data) |

## Example (as JSON)

```json
{
  "message": "message0",
  "errorMessage": [
    "errorMessage2",
    "errorMessage3",
    "errorMessage4"
  ],
  "is_error": false,
  "code": "code8",
  "data": [
    {
      "name": null,
      "abbreviation": null,
      "logo": null,
      "state": null,
      "supportValidation": null,
      "supportCreate": null,
      "supportConnect": null,
      "supportOpenClose": null,
      "supportStaticUpdate": null,
      "supportDynamicUpdate": null,
      "supportSynchronization": null,
      "supportCreateChannelAccount": null,
      "supportAuthorization": null,
      "supportCancelFormPm": null,
      "supportModificationFromPm": null,
      "supportGather": null,
      "supportChannelCancellationPolicy": null,
      "bookingType": null,
      "ratesAndAvailabilityMapping": null,
      "acceptsPropertyType": null,
      "nativePropertyType": null,
      "minimumProperties": null
    },
    {
      "name": null,
      "abbreviation": null,
      "logo": null,
      "state": null,
      "supportValidation": null,
      "supportCreate": null,
      "supportConnect": null,
      "supportOpenClose": null,
      "supportStaticUpdate": null,
      "supportDynamicUpdate": null,
      "supportSynchronization": null,
      "supportCreateChannelAccount": null,
      "supportAuthorization": null,
      "supportCancelFormPm": null,
      "supportModificationFromPm": null,
      "supportGather": null,
      "supportChannelCancellationPolicy": null,
      "bookingType": null,
      "ratesAndAvailabilityMapping": null,
      "acceptsPropertyType": null,
      "nativePropertyType": null,
      "minimumProperties": null
    }
  ]
}
```

