
# Key Collectionadditionalinformationinstruction

## Structure

`KeyCollectionadditionalinformationinstruction`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `How` | `String` | Required | how key should be collected | String getHow() | setHow(String how) |
| `When` | `String` | Required | when key should be collected | String getWhen() | setWhen(String when) |

## Example (as JSON)

```json
{
  "how": "how example",
  "when": "when example"
}
```

