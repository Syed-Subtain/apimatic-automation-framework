
# Check In

## Structure

`CheckIn`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Monday` | `boolean` | Required | Determines if check in could be made on monday | boolean getMonday() | setMonday(boolean monday) |
| `Tuesday` | `boolean` | Required | Determines if check in could be made on tuesday | boolean getTuesday() | setTuesday(boolean tuesday) |
| `Wednesday` | `boolean` | Required | Determines if check in could be made on wednesday | boolean getWednesday() | setWednesday(boolean wednesday) |
| `Thursday` | `boolean` | Required | Determines if check in could be made on thursday | boolean getThursday() | setThursday(boolean thursday) |
| `Friday` | `boolean` | Required | Determines if check in could be made on friday | boolean getFriday() | setFriday(boolean friday) |
| `Saturday` | `boolean` | Required | Determines if check in could be made on saturday | boolean getSaturday() | setSaturday(boolean saturday) |
| `Sunday` | `boolean` | Required | Determines if check in could be made on sunday | boolean getSunday() | setSunday(boolean sunday) |

## Example (as JSON)

```json
{
  "monday": false,
  "tuesday": false,
  "wednesday": false,
  "thursday": false,
  "friday": false,
  "saturday": true,
  "sunday": true
}
```

