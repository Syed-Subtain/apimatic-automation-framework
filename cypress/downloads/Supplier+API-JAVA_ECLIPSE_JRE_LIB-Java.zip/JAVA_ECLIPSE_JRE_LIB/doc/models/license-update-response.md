
# License Update Response

## Structure

`LicenseUpdateResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Message` | `String` | Optional | text info message | String getMessage() | setMessage(String message) |
| `ErrorMessage` | `List<String>` | Optional | List of error messages | List<String> getErrorMessage() | setErrorMessage(List<String> errorMessage) |
| `IsError` | `Boolean` | Optional | Is error (default = false) | Boolean getIsError() | setIsError(Boolean isError) |
| `Code` | `String` | Optional | Code of message | String getCode() | setCode(String code) |
| `Data` | [`List<LicenseUpdateResponseData>`](../../doc/models/license-update-response-data.md) | Optional | License Update Response Data | List<LicenseUpdateResponseData> getData() | setData(List<LicenseUpdateResponseData> data) |

## Example (as JSON)

```json
{
  "message": null,
  "errorMessage": null,
  "is_error": null,
  "code": null,
  "data": null
}
```

