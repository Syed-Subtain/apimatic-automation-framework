
# Policy

## Structure

`Policy`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `InternetPolicy` | [`InternetPolicy`](../../doc/models/internet-policy.md) | Optional | - | InternetPolicy getInternetPolicy() | setInternetPolicy(InternetPolicy internetPolicy) |
| `ParkingPolicy` | [`ParkingPolicy`](../../doc/models/parking-policy.md) | Optional | - | ParkingPolicy getParkingPolicy() | setParkingPolicy(ParkingPolicy parkingPolicy) |
| `PetPolicy` | [`PetPolicy`](../../doc/models/pet-policy.md) | Optional | - | PetPolicy getPetPolicy() | setPetPolicy(PetPolicy petPolicy) |
| `ChildrenAllowed` | `boolean` | Required | Children policy | boolean getChildrenAllowed() | setChildrenAllowed(boolean childrenAllowed) |
| `SmokingAllowed` | `boolean` | Required | Smoking policy | boolean getSmokingAllowed() | setSmokingAllowed(boolean smokingAllowed) |

## Example (as JSON)

```json
{
  "internetPolicy": {
    "accessInternet": true,
    "kindOfInternet": "WiFi",
    "availableInternet": "AllAreas",
    "chargeInternet": "Free"
  },
  "parkingPolicy": {
    "accessParking": true,
    "locatedParking": "OnSite",
    "privateParking": true,
    "chargeParking": "$ 150",
    "timeCostParking": "PerStay",
    "necessaryReservationParking": "NotPossible"
  },
  "petPolicy": {
    "allowedPets": "Allowed",
    "chargePets": "Free"
  },
  "childrenAllowed": true,
  "smokingAllowed": false
}
```

