
# Available Count

## Structure

`AvailableCount`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `BeginDate` | `LocalDate` | Required | Beginning date of date range for which count is applied. Date should be in format "yyyy-MM-dd" | LocalDate getBeginDate() | setBeginDate(LocalDate beginDate) |
| `EndDate` | `LocalDate` | Required | End date of date range for which count  is applied. Date should be in format "yyyy-MM-dd" | LocalDate getEndDate() | setEndDate(LocalDate endDate) |
| `Count` | `int` | Required | Number of available rooms | int getCount() | setCount(int count) |

## Example (as JSON)

```json
{
  "beginDate": "2016-03-13",
  "endDate": "2016-03-13",
  "count": 60
}
```

