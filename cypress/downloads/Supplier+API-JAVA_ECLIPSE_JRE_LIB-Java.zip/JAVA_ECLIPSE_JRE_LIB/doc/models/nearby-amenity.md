
# Nearby Amenity

## Structure

`NearbyAmenity`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `AttributeId` | [`NearbyAmenitiesEnum`](../../doc/models/nearby-amenities-enum.md) | Required | List of allowed Nearby Amenities codes | NearbyAmenitiesEnum getAttributeId() | setAttributeId(NearbyAmenitiesEnum attributeId) |
| `Distance` | `Integer` | Optional | Will be set to 0 by default | Integer getDistance() | setDistance(Integer distance) |

## Example (as JSON)

```json
{
  "attributeId": "ACC203",
  "distance": 3
}
```

