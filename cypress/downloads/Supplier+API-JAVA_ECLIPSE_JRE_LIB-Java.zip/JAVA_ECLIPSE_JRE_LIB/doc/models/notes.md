
# Notes

Model where you can define different kinds of text values. If you need to delete some kind of texts, for example short description, you can do this on Update call (PUT), and you need to pass empty array for texts value, for example :  "shortDescription": {  "texts": [  ] }

## Structure

`Notes`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Description` | [`DescriptionTextModel`](../../doc/models/description-text-model.md) | Required | Model for any kind of description text in Property object | DescriptionTextModel getDescription() | setDescription(DescriptionTextModel description) |
| `HouseRules` | [`DescriptionTextModel`](../../doc/models/description-text-model.md) | Optional | Model for any kind of description text in Property object | DescriptionTextModel getHouseRules() | setHouseRules(DescriptionTextModel houseRules) |
| `FinePrint` | [`DescriptionTextModel`](../../doc/models/description-text-model.md) | Optional | Model for any kind of description text in Property object | DescriptionTextModel getFinePrint() | setFinePrint(DescriptionTextModel finePrint) |
| `ShortDescription` | [`DescriptionTextModel`](../../doc/models/description-text-model.md) | Optional | Model for any kind of description text in Property object | DescriptionTextModel getShortDescription() | setShortDescription(DescriptionTextModel shortDescription) |
| `Name` | [`DescriptionTextModel`](../../doc/models/description-text-model.md) | Optional | Model for any kind of description text in Property object | DescriptionTextModel getName() | setName(DescriptionTextModel name) |

## Example (as JSON)

```json
{
  "description": {
    "texts": [
      {
        "language": "EN",
        "value": "Main description on EN!"
      },
      {
        "language": "ES",
        "value": "Main description on ES!"
      }
    ]
  },
  "houseRules": {
    "texts": [
      {
        "language": "EN",
        "value": "House Rules on EN!"
      },
      {
        "language": "SR",
        "value": "House Rules on SR!"
      }
    ]
  },
  "name": {
    "texts": [
      {
        "language": "EN",
        "value": "House Rules on EN!"
      },
      {
        "language": "SR",
        "value": "House Rules on SR!"
      }
    ]
  },
  "shortDescription": {
    "texts": [
      {
        "language": "EN",
        "value": "House Rules on EN!"
      },
      {
        "language": "SR",
        "value": "House Rules on SR!"
      }
    ]
  },
  "finePrint": {
    "texts": [
      {
        "language": "EN",
        "value": "House Rules on EN!"
      },
      {
        "language": "SR",
        "value": "House Rules on SR!"
      }
    ]
  }
}
```

