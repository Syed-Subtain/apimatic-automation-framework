
# License Info Response

## Structure

`LicenseInfoResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Data` | [`List<LicenseResponseDataDetail>`](../../doc/models/license-response-data-detail.md) | Optional | - | List<LicenseResponseDataDetail> getData() | setData(List<LicenseResponseDataDetail> data) |
| `Meta` | [`List<LicenseRequirementMeta>`](../../doc/models/license-requirement-meta.md) | Optional | - | List<LicenseRequirementMeta> getMeta() | setMeta(List<LicenseRequirementMeta> meta) |
| `Warnings` | `List<String>` | Optional | List of warning messages | List<String> getWarnings() | setWarnings(List<String> warnings) |
| `Errors` | `List<String>` | Optional | List of error messages | List<String> getErrors() | setErrors(List<String> errors) |

## Example (as JSON)

```json
{
  "data": null,
  "meta": null,
  "warnings": null,
  "errors": null
}
```

