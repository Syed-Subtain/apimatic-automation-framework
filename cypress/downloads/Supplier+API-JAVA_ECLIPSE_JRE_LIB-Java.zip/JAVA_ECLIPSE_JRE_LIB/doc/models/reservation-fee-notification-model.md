
# Reservation Fee Notification Model

Model used for fees in reservation push notification

## Structure

`ReservationFeeNotificationModel`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Id` | `String` | Optional | Fee altID (alt ID which PMS sent over API) | String getId() | setId(String id) |
| `Name` | `String` | Required | Fee name | String getName() | setName(String name) |
| `Value` | `double` | Required | Fee value | double getValue() | setValue(double value) |

## Example (as JSON)

```json
{
  "id": "937-4",
  "name": "Cleaning Fee",
  "value": 110
}
```

