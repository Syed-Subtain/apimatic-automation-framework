
# Asynchronous Validation Model

Model for Validation messages

## Structure

`AsynchronousValidationModel`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `ProductId` | `int` | Required | Id of product in BookingPal | int getProductId() | setProductId(int productId) |
| `ValidationErrors` | `String` | Optional | Error message - explanation what are problems if validation failed. | String getValidationErrors() | setValidationErrors(String validationErrors) |
| `Valid` | `boolean` | Required | Is product valid | boolean getValid() | setValid(boolean valid) |

## Example (as JSON)

```json
{
  "productId": 291356,
  "validationErrors": "noPrice;",
  "valid": false
}
```

