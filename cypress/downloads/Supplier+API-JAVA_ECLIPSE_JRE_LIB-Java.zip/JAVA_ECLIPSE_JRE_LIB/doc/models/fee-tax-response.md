
# Fee Tax Response

Response for Create or Get FeeTax API call

## Structure

`FeeTaxResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Message` | `String` | Required | Text info message | String getMessage() | setMessage(String message) |
| `ErrorMessage` | `List<String>` | Required | List of error messages | List<String> getErrorMessage() | setErrorMessage(List<String> errorMessage) |
| `IsError` | `boolean` | Required | Is error (default = false) | boolean getIsError() | setIsError(boolean isError) |
| `Code` | `String` | Required | Code of message | String getCode() | setCode(String code) |
| `Data` | [`List<FeesandTaxes>`](../../doc/models/feesand-taxes.md) | Required | List of models | List<FeesandTaxes> getData() | setData(List<FeesandTaxes> data) |

## Example (as JSON)

```json
{
  "message": "message0",
  "errorMessage": [
    "errorMessage2",
    "errorMessage3",
    "errorMessage4"
  ],
  "is_error": false,
  "code": "code8",
  "data": [
    {
      "productId": 69,
      "fees": null,
      "taxes": null
    },
    {
      "productId": 70,
      "fees": null,
      "taxes": null
    }
  ]
}
```

