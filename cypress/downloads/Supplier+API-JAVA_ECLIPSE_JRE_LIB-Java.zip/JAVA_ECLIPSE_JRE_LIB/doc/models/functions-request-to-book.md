
# Functions Request to Book

Request to book answer model

## Structure

`FunctionsRequestToBook`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `RequestToBookType` | [`RequestToBookTypeEnum`](../../doc/models/request-to-book-type-enum.md) | Required | - | RequestToBookTypeEnum getRequestToBookType() | setRequestToBookType(RequestToBookTypeEnum requestToBookType) |
| `RequestToBookDeclineReasonType` | [`RequestToBookDeclineReasonTypeEnum`](../../doc/models/request-to-book-decline-reason-type-enum.md) | Optional | - | RequestToBookDeclineReasonTypeEnum getRequestToBookDeclineReasonType() | setRequestToBookDeclineReasonType(RequestToBookDeclineReasonTypeEnum requestToBookDeclineReasonType) |
| `DeclineMessageToGuest` | `String` | Optional | Message to guest | String getDeclineMessageToGuest() | setDeclineMessageToGuest(String declineMessageToGuest) |
| `ReservationId` | `int` | Required | Reservation for request to book | int getReservationId() | setReservationId(int reservationId) |

## Example (as JSON)

```json
{
  "requestToBookType": "DENY",
  "requestToBookDeclineReasonType": "DATES_NOT_AVAILABLE",
  "declineMessageToGuest": "these dates are not available any more. ",
  "reservationId": 1235124634
}
```

