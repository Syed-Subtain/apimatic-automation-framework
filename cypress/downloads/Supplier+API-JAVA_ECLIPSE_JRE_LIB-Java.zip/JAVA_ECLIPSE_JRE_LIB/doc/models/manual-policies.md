
# Manual Policies

## Structure

`ManualPolicies`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `ChargeValue` | `int` | Required | Percentage or flat value which will be charged in case of cancellation | int getChargeValue() | setChargeValue(int chargeValue) |
| `BeforeDays` | `int` | Required | Days before check-in when cancellation policy will be charged | int getBeforeDays() | setBeforeDays(int beforeDays) |
| `CancellationFee` | `double` | Required | Cancellation transaction fee - additional fee on cancellation | double getCancellationFee() | setCancellationFee(double cancellationFee) |

## Example (as JSON)

```json
{
  "chargeValue": 20,
  "beforeDays": 34,
  "cancellationFee": 1
}
```

