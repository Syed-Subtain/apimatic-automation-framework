
# Images URL for Full Update

Model with one image URL for one property used for inserting new image

## Structure

`ImagesURLForFullUpdate`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `ProductId` | `int` | Required | Id of the product | int getProductId() | setProductId(int productId) |
| `Images` | [`List<AddImage>`](../../doc/models/add-image.md) | Required | - | List<AddImage> getImages() | setImages(List<AddImage> images) |

## Example (as JSON)

```json
{
  "productId": 1234893572,
  "images": [
    {
      "url": "http://aff.bstatic.com/images/hotel/max500/110/11069097.jpg",
      "tags": [
        1,
        2,
        3
      ]
    },
    {
      "url": "http://aff.bstatic.com/images/hotel/max500/110/11069097.jpg",
      "tags": [
        1,
        2,
        3
      ]
    }
  ]
}
```

