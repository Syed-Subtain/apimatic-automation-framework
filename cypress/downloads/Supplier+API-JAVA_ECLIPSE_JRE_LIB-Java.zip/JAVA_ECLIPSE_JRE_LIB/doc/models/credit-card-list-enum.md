
# Credit Card List Enum

## Enumeration

`CreditCardListEnum`

## Fields

| Name |
|  --- |
| `MASTERCARD` |
| `VISA` |
| `AMERICANEXPRESS` |
| `DINERSCLUB` |
| `DISCOVER` |

## Example

```
MASTER_CARD
```

