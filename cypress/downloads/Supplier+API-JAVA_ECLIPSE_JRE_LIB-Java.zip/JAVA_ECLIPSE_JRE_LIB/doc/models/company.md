
# Company

Company model

## Structure

`Company`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `IsCompany` | `Boolean` | Optional | Is Property Manager Company or not (for example it can be a single host). TRUE=Company. Default is TRUE. | Boolean getIsCompany() | setIsCompany(Boolean isCompany) |
| `CompanyDetails` | [`CompanyDetails`](../../doc/models/company-details.md) | Required | - | CompanyDetails getCompanyDetails() | setCompanyDetails(CompanyDetails companyDetails) |
| `Policies` | [`Policies`](../../doc/models/policies.md) | Required | - | Policies getPolicies() | setPolicies(Policies policies) |
| `Payment` | [`Payment`](../../doc/models/payment.md) | Required | - | Payment getPayment() | setPayment(Payment payment) |
| `Id` | `Integer` | Optional | Supplier id. Not expected in any requests. Will be only in responses. | Integer getId() | setId(Integer id) |
| `OwnerInfo` | [`Text`](../../doc/models/text.md) | Optional | - | Text getOwnerInfo() | setOwnerInfo(Text ownerInfo) |
| `NeighborhoodOverview` | [`Text`](../../doc/models/text.md) | Optional | - | Text getNeighborhoodOverview() | setNeighborhoodOverview(Text neighborhoodOverview) |

## Example (as JSON)

```json
{
  "isCompany": false,
  "companyDetails": {
    "accountId": "132",
    "companyName": "Test PM",
    "language": "en",
    "fullName": "Test PM",
    "companyAddress": {
      "country": "US",
      "state": "Test State",
      "streetAddress": "Test Street",
      "city": "Test City",
      "zip": "13245"
    },
    "website": "www.testsite.com",
    "email": "apimaticPMemail@test.com",
    "phone": {
      "countryCode": "321",
      "number": "132456"
    },
    "password": "password",
    "currency": "USD"
  },
  "policies": {
    "paymentPolicy": {
      "type": "SPLIT",
      "splitPayment": {
        "depositType": "FLAT",
        "value": 4,
        "secondPaymentDays": 30
      }
    },
    "cancellationPolicy": {
      "type": "MANUAL",
      "manualPolicy": {
        "type": "FLAT",
        "manualPolicies": [
          {
            "chargeValue": 20,
            "beforeDays": 34,
            "cancellationFee": 1
          },
          {
            "chargeValue": 12,
            "beforeDays": 45,
            "cancellationFee": 2
          }
        ]
      }
    },
    "feeTaxMandatory": {
      "isFeeMandatory": true,
      "isTaxMandatory": true
    },
    "terms": "www.test.com",
    "checkInTime": "36000",
    "checkOutTime": "57600",
    "leadTime": 2
  },
  "payment": {
    "paymentType": "MAIL_CHECK",
    "creditCard": {
      "creditCardType": "POST",
      "paymentGateways": {
        "paymentGatewaysType": "AUTHORIZE_NET",
        "user": "test",
        "secret": "test",
        "additionalField1": "",
        "additionalField2": ""
      },
      "creditCardList": [
        "AMERICAN_EXPRESS",
        "DINERS_CLUB"
      ]
    }
  },
  "ownerInfo": {
    "language": "EN",
    "value": "ownerInfo on EN"
  },
  "neighborhoodOverview": {
    "language": "EN",
    "value": "neighborhoodOverview on EN"
  }
}
```

