
# Internet Policy

## Structure

`InternetPolicy`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `AccessInternet` | `boolean` | Required | Access internet into properties | boolean getAccessInternet() | setAccessInternet(boolean accessInternet) |
| `KindOfInternet` | [`KindOfInternetTypeEnum`](../../doc/models/kind-of-internet-type-enum.md) | Optional | - | KindOfInternetTypeEnum getKindOfInternet() | setKindOfInternet(KindOfInternetTypeEnum kindOfInternet) |
| `AvailableInternet` | [`AvailableInternetEnum`](../../doc/models/available-internet-enum.md) | Optional | - | AvailableInternetEnum getAvailableInternet() | setAvailableInternet(AvailableInternetEnum availableInternet) |
| `ChargeInternet` | `String` | Optional | Charge internet. Example: “Free”, “$ 100”. | String getChargeInternet() | setChargeInternet(String chargeInternet) |

## Example (as JSON)

```json
{
  "accessInternet": true,
  "kindOfInternet": "WiFi",
  "availableInternet": "AllAreas",
  "chargeInternet": "Free"
}
```

