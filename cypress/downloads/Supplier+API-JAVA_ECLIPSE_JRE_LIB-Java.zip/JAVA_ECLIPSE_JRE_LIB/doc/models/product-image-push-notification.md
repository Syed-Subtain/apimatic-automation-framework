
# Product Image Push Notification

## Structure

`ProductImagePushNotification`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Name` | `String` | Required | name of the object | String getName() | setName(String name) |
| `ProductId` | `String` | Required | product id | String getProductId() | setProductId(String productId) |
| `AltId` | `String` | Optional | product alternate id | String getAltId() | setAltId(String altId) |
| `Images` | [`List<ImagePushNotification>`](../../doc/models/image-push-notification.md) | Required | - | List<ImagePushNotification> getImages() | setImages(List<ImagePushNotification> images) |

## Example (as JSON)

```json
{
  "name": null,
  "productId": null,
  "images": {
    "success": null,
    "type": "IMPORT",
    "url": null,
    "version": null
  }
}
```

