
# Min Stay Model

MinStay model

## Structure

`MinStayModel`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `BeginDate` | `LocalDate` | Required | Beginning date of date range for which min stay is applied. Date should be in format "yyyy-MM-dd" | LocalDate getBeginDate() | setBeginDate(LocalDate beginDate) |
| `EndDate` | `LocalDate` | Required | End date of date range for which min stay is applied. Date should be in format "yyyy-MM-dd" | LocalDate getEndDate() | setEndDate(LocalDate endDate) |
| `MinStay` | `int` | Required | Number of days that will be applied for min stay | int getMinStay() | setMinStay(int minStay) |

## Example (as JSON)

```json
{
  "beginDate": "2016-03-13",
  "endDate": "2016-03-13",
  "minStay": 108
}
```

