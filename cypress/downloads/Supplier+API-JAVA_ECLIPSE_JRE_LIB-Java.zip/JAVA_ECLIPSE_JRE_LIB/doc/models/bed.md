
# Bed

## Structure

`Bed`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `BedType` | `String` | Required | Bed code BedTypes are given in Appendix. | String getBedType() | setBedType(String bedType) |
| `Count` | `int` | Required | Number of bed | int getCount() | setCount(int count) |

## Example (as JSON)

```json
{
  "bedType": "RMA113",
  "count": 1
}
```

