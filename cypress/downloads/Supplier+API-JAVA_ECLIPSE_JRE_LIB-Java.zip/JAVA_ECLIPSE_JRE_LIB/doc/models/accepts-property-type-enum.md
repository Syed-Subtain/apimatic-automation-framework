
# Accepts Property Type Enum

Channel accepts Property Type

## Enumeration

`AcceptsPropertyTypeEnum`

## Fields

| Name |
|  --- |
| `HomesAndApartments` |
| `Hotels` |
| `Both` |

## Example

```
HomesAndApartments
```

