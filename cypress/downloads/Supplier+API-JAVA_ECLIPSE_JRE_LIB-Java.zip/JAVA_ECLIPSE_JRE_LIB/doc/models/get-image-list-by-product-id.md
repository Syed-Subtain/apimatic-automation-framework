
# Get Image List by Product ID

## Structure

`GetImageListByProductID`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Message` | `String` | Required | text info message | String getMessage() | setMessage(String message) |
| `ErrorMessage` | `List<String>` | Required | List of error messages | List<String> getErrorMessage() | setErrorMessage(List<String> errorMessage) |
| `IsError` | `boolean` | Required | Is error (default = false) | boolean getIsError() | setIsError(boolean isError) |
| `Code` | `String` | Required | Code of message | String getCode() | setCode(String code) |
| `Data` | [`List<ImageURLList>`](../../doc/models/image-url-list.md) | Required | List of Models | List<ImageURLList> getData() | setData(List<ImageURLList> data) |

## Example (as JSON)

```json
{
  "message": "",
  "errorMessage": [],
  "is_error": false,
  "code": "",
  "data": [
    {
      "productId": 1235124634,
      "images": [
        {
          "url": "http://aff.bstatic.com/images/hotel/max500/110/11069098.jpg",
          "tags": [
            4,
            5,
            6
          ],
          "urlMbp": "https://s3.amazonaws.com/mybookingpal/pictures/n2ujn/n2ujn/1235124634/11069098.jpg",
          "sort": 1
        },
        {
          "url": "http://aff.bstatic.com/images/hotel/max500/110/11069099.jpg",
          "tags": [
            4,
            5,
            6
          ],
          "urlMbp": "https://s3.amazonaws.com/mybookingpal/pictures/n2ujn/n2ujn/1235124634/11069099.jpg",
          "sort": 2
        },
        {
          "url": "http://aff.bstatic.com/images/hotel/max500/110/11069100.jpg",
          "tags": [
            4,
            5,
            6
          ],
          "urlMbp": "https://s3.amazonaws.com/mybookingpal/pictures/n2ujn/n2ujn/1235124634/11069100.jpg",
          "sort": 3
        },
        {
          "url": "http://aff.bstatic.com/images/hotel/max500/110/11069101.jpg",
          "tags": [
            4,
            5,
            6
          ],
          "urlMbp": "https://s3.amazonaws.com/mybookingpal/pictures/n2ujn/n2ujn/1235124634/11069101.jpg",
          "sort": 4
        },
        {
          "url": "http://aff.bstatic.com/images/hotel/max500/110/11069102.jpg",
          "tags": [
            4,
            5,
            6
          ],
          "urlMbp": "https://s3.amazonaws.com/mybookingpal/pictures/n2ujn/n2ujn/1235124634/11069102.jpg",
          "sort": 5
        },
        {
          "url": "http://aff.bstatic.com/images/hotel/max500/110/11069103.jpg",
          "tags": [
            4,
            5,
            6
          ],
          "urlMbp": "https://s3.amazonaws.com/mybookingpal/pictures/n2ujn/n2ujn/1235124634/11069103.jpg",
          "sort": 6
        },
        {
          "url": "http://aff.bstatic.com/images/hotel/max500/110/11069104.jpg",
          "tags": [
            4,
            5,
            6
          ],
          "urlMbp": "https://s3.amazonaws.com/mybookingpal/pictures/n2ujn/n2ujn/1235124634/11069104.jpg",
          "sort": 7
        },
        {
          "url": "http://aff.bstatic.com/images/hotel/max500/110/11069105.jpg",
          "tags": [
            4,
            5,
            6
          ],
          "urlMbp": "https://s3.amazonaws.com/mybookingpal/pictures/n2ujn/n2ujn/1235124634/11069105.jpg",
          "sort": 8
        },
        {
          "url": "http://aff.bstatic.com/images/hotel/max500/110/11069106.jpg",
          "tags": [
            4,
            5,
            6
          ],
          "urlMbp": "https://s3.amazonaws.com/mybookingpal/pictures/n2ujn/n2ujn/1235124634/11069106.jpg",
          "sort": 9
        },
        {
          "url": "http://aff.bstatic.com/images/hotel/max500/110/11069107.jpg",
          "tags": [
            4,
            5,
            6
          ],
          "urlMbp": "https://s3.amazonaws.com/mybookingpal/pictures/n2ujn/n2ujn/1235124634/11069107.jpg",
          "sort": 10
        },
        {
          "url": "http://aff.bstatic.com/images/hotel/max500/110/11069108.jpg",
          "tags": [
            4,
            5,
            6
          ],
          "urlMbp": "https://s3.amazonaws.com/mybookingpal/pictures/n2ujn/n2ujn/1235124634/11069108.jpg",
          "sort": 11
        },
        {
          "url": "http://aff.bstatic.com/images/hotel/max500/110/11069109.jpg",
          "tags": [
            4,
            5,
            6
          ],
          "urlMbp": "https://s3.amazonaws.com/mybookingpal/pictures/n2ujn/n2ujn/1235124634/11069109.jpg",
          "sort": 12
        }
      ]
    }
  ]
}
```

