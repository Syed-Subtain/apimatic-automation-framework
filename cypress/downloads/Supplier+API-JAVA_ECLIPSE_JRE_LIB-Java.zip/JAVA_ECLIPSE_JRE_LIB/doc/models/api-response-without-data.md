
# API Response Without Data

Common response for most of functions - where 'data' element is not present.

## Structure

`APIResponseWithoutData`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Message` | `String` | Required | text info message | String getMessage() | setMessage(String message) |
| `ErrorMessage` | `List<String>` | Required | List of error messages | List<String> getErrorMessage() | setErrorMessage(List<String> errorMessage) |
| `IsError` | `boolean` | Required | Is error (default = false) | boolean getIsError() | setIsError(boolean isError) |
| `Code` | `String` | Required | Code of message | String getCode() | setCode(String code) |

## Example (as JSON)

```json
{
  "message": "",
  "errorMessage": [],
  "is_error": false,
  "code": ""
}
```

