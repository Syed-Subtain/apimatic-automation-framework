
# Request to Book Cancel Request Model

Model for request to book cancel API request

## Structure

`RequestToBookCancelRequestModel`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Action` | `String` | Required | RESERVATION_REQUEST_VOIDED | String getAction() | setAction(String action) |
| `ReservationId` | `int` | Required | ID of reservation in BookingPal | int getReservationId() | setReservationId(int reservationId) |

## Example (as JSON)

```json
{
  "action": "RESERVATION_REQUEST_VOIDED",
  "reservationId": 12345612345
}
```

