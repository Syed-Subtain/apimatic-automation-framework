
# Image UR Lfor Full Update

Model for full update of images (with list of URLs) for one property

## Structure

`ImageURLforFullUpdate`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `ProductId` | `int` | Required | Id of the product | int getProductId() | setProductId(int productId) |
| `Images` | [`List<AddImage>`](../../doc/models/add-image.md) | Required | Images for property | List<AddImage> getImages() | setImages(List<AddImage> images) |

## Example (as JSON)

```json
{
  "productId": 1234893572,
  "images": [
    {
      "url": "http://aff.bstatic.com/images/hotel/max500/110/11069097.jpg",
      "tags": [
        1,
        2,
        3
      ]
    },
    {
      "url": "http://aff.bstatic.com/images/hotel/max500/110/11069097.jpg",
      "tags": [
        1,
        2,
        3
      ]
    }
  ]
}
```

