
# License Get Response

## Structure

`LicenseGetResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Message` | `String` | Optional | text info message | String getMessage() | setMessage(String message) |
| `ErrorMessage` | `List<String>` | Optional | List of error messages | List<String> getErrorMessage() | setErrorMessage(List<String> errorMessage) |
| `IsError` | `Boolean` | Optional | Is error (default = false) | Boolean getIsError() | setIsError(Boolean isError) |
| `Code` | `String` | Optional | Code of message | String getCode() | setCode(String code) |
| `Data` | [`List<LicenseGetResponseData>`](../../doc/models/license-get-response-data.md) | Optional | License Information Data | List<LicenseGetResponseData> getData() | setData(List<LicenseGetResponseData> data) |

## Example (as JSON)

```json
{
  "message": null,
  "errorMessage": null,
  "is_error": null,
  "code": null,
  "data": null
}
```

