
# Rates Availability

Rates Availability model

## Structure

`RatesAvailability`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `ProductId` | `int` | Required | ID of the product | int getProductId() | setProductId(int productId) |
| `LeadTime` | `Integer` | Optional | Number of days before reservation in which reservation couldn’t be made. Allowed values are 0-7. If this value is set on property level - it will be used before than value on PM level. | Integer getLeadTime() | setLeadTime(Integer leadTime) |
| `Rates` | [`List<Rate>`](../../doc/models/rate.md) | Optional | List of models | List<Rate> getRates() | setRates(List<Rate> rates) |
| `MinStays` | [`List<MinStayModel>`](../../doc/models/min-stay-model.md) | Optional | List of models | List<MinStayModel> getMinStays() | setMinStays(List<MinStayModel> minStays) |
| `MaxStays` | [`List<MaxStayModel>`](../../doc/models/max-stay-model.md) | Optional | List of models | List<MaxStayModel> getMaxStays() | setMaxStays(List<MaxStayModel> maxStays) |
| `Restrictions` | [`List<Restriction>`](../../doc/models/restriction.md) | Optional | List of models | List<Restriction> getRestrictions() | setRestrictions(List<Restriction> restrictions) |
| `Availabilities` | [`List<AvailabilityModel>`](../../doc/models/availability-model.md) | Optional | List of models | List<AvailabilityModel> getAvailabilities() | setAvailabilities(List<AvailabilityModel> availabilities) |
| `AvailableCount` | [`List<AvailableCount>`](../../doc/models/available-count.md) | Optional | List of models (Only for MLT properties) | List<AvailableCount> getAvailableCount() | setAvailableCount(List<AvailableCount> availableCount) |

## Example (as JSON)

```json
{
  "productId": 98,
  "leadTime": null,
  "rates": null,
  "minStays": null,
  "maxStays": null,
  "restrictions": null,
  "availabilities": null,
  "availableCount": null
}
```

