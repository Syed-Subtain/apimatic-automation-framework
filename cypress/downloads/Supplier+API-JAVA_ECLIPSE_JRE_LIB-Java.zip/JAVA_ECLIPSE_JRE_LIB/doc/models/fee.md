
# Fee

## Structure

`Fee`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `BeginDate` | `LocalDate` | Optional | Fee applies from Date. Date should be in format "yyyy-MM-dd" | LocalDate getBeginDate() | setBeginDate(LocalDate beginDate) |
| `EndDate` | `LocalDate` | Optional | Fee applies to Date. Date should be in format "yyyy-MM-dd" | LocalDate getEndDate() | setEndDate(LocalDate endDate) |
| `EntityType` | [`FeeEntityTypeEnum`](../../doc/models/fee-entity-type-enum.md) | Required | - | FeeEntityTypeEnum getEntityType() | setEntityType(FeeEntityTypeEnum entityType) |
| `FeeType` | [`FeeTypeEnum`](../../doc/models/fee-type-enum.md) | Required | - | FeeTypeEnum getFeeType() | setFeeType(FeeTypeEnum feeType) |
| `Option` | `Integer` | Optional | Number of guests when set extra person fee. Only values >0 are allowed. | Integer getOption() | setOption(Integer option) |
| `Name` | `String` | Required | Fee name.  For example: Extra person, Cleaning fee, Parking etc. | String getName() | setName(String name) |
| `TaxType` | [`FeeTaxTypeEnum`](../../doc/models/fee-tax-type-enum.md) | Optional | - | FeeTaxTypeEnum getTaxType() | setTaxType(FeeTaxTypeEnum taxType) |
| `Unit` | [`FeeUnitEnum`](../../doc/models/fee-unit-enum.md) | Required | - | FeeUnitEnum getUnit() | setUnit(FeeUnitEnum unit) |
| `Value` | `double` | Required | Fee value | double getValue() | setValue(double value) |
| `ValueType` | [`FeeValueTypeEnum`](../../doc/models/fee-value-type-enum.md) | Required | Value Type {FLAT, PERCENT} | FeeValueTypeEnum getValueType() | setValueType(FeeValueTypeEnum valueType) |
| `AltId` | `String` | Optional | Alternative Id of the fee (fee id in your system) | String getAltId() | setAltId(String altId) |

## Example (as JSON)

```json
{
  "entityType": "MANDATORY",
  "feeType": "GENERAL",
  "name": null,
  "unit": "PER_STAY",
  "value": null,
  "valueType": "FLAT"
}
```

