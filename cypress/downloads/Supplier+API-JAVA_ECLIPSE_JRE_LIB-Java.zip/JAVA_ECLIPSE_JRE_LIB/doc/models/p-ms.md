
# P Ms

Property Manager model

## Structure

`PMs`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Id` | `int` | Required | ID of the property manager | int getId() | setId(int id) |
| `Name` | `String` | Required | Name of the property manager’s company | String getName() | setName(String name) |
| `ExtraName` | `String` | Required | Contact person | String getExtraName() | setExtraName(String extraName) |
| `EmailAddress` | `String` | Required | Email of the property manager | String getEmailAddress() | setEmailAddress(String emailAddress) |

## Example (as JSON)

```json
{
  "id": 61690133,
  "name": "Test name",
  "extraName": "Test fullname",
  "emailAddress": "test001@gmail.com"
}
```

