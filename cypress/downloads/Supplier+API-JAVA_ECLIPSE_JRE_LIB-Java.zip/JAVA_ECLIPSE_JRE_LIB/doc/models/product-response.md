
# Product Response

Response for Get, Create or Update product API call

## Structure

`ProductResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Message` | `String` | Required | text info message | String getMessage() | setMessage(String message) |
| `ErrorMessage` | `List<String>` | Required | List of error messages | List<String> getErrorMessage() | setErrorMessage(List<String> errorMessage) |
| `IsError` | `boolean` | Required | Is error (default = false) | boolean getIsError() | setIsError(boolean isError) |
| `Code` | `String` | Required | Code of message | String getCode() | setCode(String code) |
| `Data` | [`List<Property>`](../../doc/models/property.md) | Required | List of models | List<Property> getData() | setData(List<Property> data) |

## Example (as JSON)

```json
{
  "message": null,
  "errorMessage": null,
  "is_error": null,
  "code": null,
  "data": {
    "name": null,
    "rooms": null,
    "bathrooms": null,
    "persons": null,
    "propertyType": "PCT101",
    "currency": null,
    "supportedLosRates": null
  }
}
```

