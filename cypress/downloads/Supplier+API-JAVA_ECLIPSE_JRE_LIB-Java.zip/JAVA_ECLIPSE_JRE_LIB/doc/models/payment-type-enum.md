
# Payment Type Enum

## Enumeration

`PaymentTypeEnum`

## Fields

| Name |
|  --- |
| `CREDITCARD` |
| `MAILCHECK` |
| `BOOKINGPALMOR` |

## Example

```
CREDIT_CARD
```

