
# Available Internet Enum

## Enumeration

`AvailableInternetEnum`

## Fields

| Name |
|  --- |
| `AllAreas` |
| `BusinessCenter` |
| `SomeRooms` |

## Example

```
AllAreas
```

