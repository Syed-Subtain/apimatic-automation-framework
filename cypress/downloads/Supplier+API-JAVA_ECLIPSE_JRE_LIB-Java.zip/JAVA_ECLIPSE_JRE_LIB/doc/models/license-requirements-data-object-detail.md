
# License Requirements Data Object Detail

## Structure

`LicenseRequirementsDataObjectDetail`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Name` | `String` | Optional | name of the property | String getName() | setName(String name) |
| `Level` | `String` | Optional | Level of the property for the name above | String getLevel() | setLevel(String level) |
| `Variants` | [`List<LicenseVariants>`](../../doc/models/license-variants.md) | Optional | - | List<LicenseVariants> getVariants() | setVariants(List<LicenseVariants> variants) |
| `Active` | `String` | Optional | active/inactive indicator | String getActive() | setActive(String active) |
| `Id` | `String` | Optional | ID of the requirement. | String getId() | setId(String id) |

## Example (as JSON)

```json
{
  "name": null,
  "level": null,
  "variants": null,
  "active": null,
  "id": null
}
```

