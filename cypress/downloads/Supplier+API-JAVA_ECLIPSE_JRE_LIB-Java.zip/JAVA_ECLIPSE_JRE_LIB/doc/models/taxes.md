
# Taxes

## Structure

`Taxes`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Name` | `String` | Required | Tax name | String getName() | setName(String name) |
| `Type` | [`TaxisTypeEnum`](../../doc/models/taxis-type-enum.md) | Optional | - | TaxisTypeEnum getType() | setType(TaxisTypeEnum type) |
| `Value` | `double` | Required | Tax value | double getValue() | setValue(double value) |
| `AltId` | `String` | Optional | Alternative Id of the tax (tax id in your system) | String getAltId() | setAltId(String altId) |

## Example (as JSON)

```json
{
  "name": "Tax reTestAT",
  "type": "SalesTaxIncluded",
  "value": 55,
  "altId": "11"
}
```

