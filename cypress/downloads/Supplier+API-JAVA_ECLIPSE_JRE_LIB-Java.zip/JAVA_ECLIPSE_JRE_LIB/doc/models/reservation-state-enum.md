
# Reservation State Enum

Possible Reservation states

## Enumeration

`ReservationStateEnum`

## Fields

| Name | Description |
|  --- | --- |
| `Cancelled` | Reservation was cancelled |
| `Confirmed` | Reservation processed successfully to the PMS |
| `FullyPaid` | Reservation processed successfully to the PMS (Channel is MOR) |
| `Provisional` | Reservation currently in progress |
| `Exception` | Previously confirmed or fully paid reservation that the HMC no longer has matching closed dates for |
| `Failed` | Reservation was not successfully processed to the PMS or PMS did not provide confirmation |

## Example

```
Cancelled
```

