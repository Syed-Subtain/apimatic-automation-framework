
# Reservation Commissions Notification Model

## Structure

`ReservationCommissionsNotificationModel`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `ChannelCommission` | `Double` | Optional | Channel commission | Double getChannelCommission() | setChannelCommission(Double channelCommission) |
| `Commission` | `Double` | Optional | BookingPal commission | Double getCommission() | setCommission(Double commission) |

## Example (as JSON)

```json
{
  "channelCommission": 10,
  "commission": 12
}
```

