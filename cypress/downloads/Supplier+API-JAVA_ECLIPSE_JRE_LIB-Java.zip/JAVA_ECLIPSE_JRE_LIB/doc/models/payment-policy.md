
# Payment Policy

## Structure

`PaymentPolicy`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Type` | [`PaymentPolicyTypeEnum`](../../doc/models/payment-policy-type-enum.md) | Required | Full or Split payment. In case of Split payment - it will be 2 payments. [SPLIT,FULL] | PaymentPolicyTypeEnum getType() | setType(PaymentPolicyTypeEnum type) |
| `SplitPayment` | [`SplitPayment`](../../doc/models/split-payment.md) | Required | - | SplitPayment getSplitPayment() | setSplitPayment(SplitPayment splitPayment) |

## Example (as JSON)

```json
{
  "type": "SPLIT",
  "splitPayment": {
    "depositType": "FLAT",
    "value": 4,
    "secondPaymentDays": 30
  }
}
```

