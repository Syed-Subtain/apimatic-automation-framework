
# Yield

## Structure

`Yield`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `BeginDate` | `LocalDate` | Required | From date. Date should be in format "yyyy-MM-dd" | LocalDate getBeginDate() | setBeginDate(LocalDate beginDate) |
| `EndDate` | `LocalDate` | Required | To date. Date should be in format "yyyy-MM-dd" | LocalDate getEndDate() | setEndDate(LocalDate endDate) |
| `Amount` | `double` | Required | Yield amount | double getAmount() | setAmount(double amount) |
| `Modifier` | [`YieldModifierEnum`](../../doc/models/yield-modifier-enum.md) | Required | - | YieldModifierEnum getModifier() | setModifier(YieldModifierEnum modifier) |
| `WeekendParam` | [`WeekendParamEnum`](../../doc/models/weekend-param-enum.md) | Optional | - | WeekendParamEnum getWeekendParam() | setWeekendParam(WeekendParamEnum weekendParam) |
| `Param` | `Integer` | Optional | Parameter. It can verify depending on what YMR was set. More details about params you can see in the description above. | Integer getParam() | setParam(Integer param) |

## Example (as JSON)

```json
{
  "beginDate": null,
  "endDate": null,
  "amount": null,
  "modifier": "INCREASE_PERCENT"
}
```

