
# Request to Book Test Action Enum

Allowed values for request to book Test action

## Enumeration

`RequestToBookTestActionEnum`

## Fields

| Name | Description |
|  --- | --- |
| `RESERVATIONREQUESTVOIDED` | Send example request like you got request to book cancellation notification. |
| `RESERVATIONREQUEST` | Send example request like you got request to book notification. |

## Example

```
RESERVATION_REQUEST_VOIDED
```

