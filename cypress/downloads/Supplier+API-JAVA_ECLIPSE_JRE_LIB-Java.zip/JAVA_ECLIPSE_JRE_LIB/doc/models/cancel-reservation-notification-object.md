
# Cancel Reservation Notification Object

## Structure

`CancelReservationNotificationObject`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `ReservationId` | `String` | Required | Id of the reservation in BookingPal | String getReservationId() | setReservationId(String reservationId) |
| `ProductId` | `String` | Required | Id of the product in BookingPal | String getProductId() | setProductId(String productId) |
| `SupplierId` | `int` | Required | Id of the property manager | int getSupplierId() | setSupplierId(int supplierId) |
| `AgentName` | `String` | Optional | DEPRECATED. Use channelName instead. Agent name/Channel name | String getAgentName() | setAgentName(String agentName) |
| `ChannelName` | `String` | Required | Agent name/Channel name | String getChannelName() | setChannelName(String channelName) |
| `ConfirmationId` | `String` | Required | Channel confirmation code | String getConfirmationId() | setConfirmationId(String confirmationId) |
| `UniqueKey` | `String` | Required | Unique code to identify that the request is from BookingPal. This value is unique for every PMS (and it will be different in different environments). | String getUniqueKey() | setUniqueKey(String uniqueKey) |
| `NewState` | `String` | Required | It will always be "Cancelled" in this request | String getNewState() | setNewState(String newState) |
| `CustomerName` | `String` | Required | Guest full name (in format firstName lastName) | String getCustomerName() | setCustomerName(String customerName) |
| `FromDate` | `LocalDate` | Required | Reservation date from. Date is in format "yyyy-MM-dd" | LocalDate getFromDate() | setFromDate(LocalDate fromDate) |
| `ToDate` | `LocalDate` | Required | Reservation date to. Date is in format "yyyy-MM-dd" | LocalDate getToDate() | setToDate(LocalDate toDate) |
| `Adult` | `int` | Required | Number of adults | int getAdult() | setAdult(int adult) |
| `Child` | `int` | Required | Number of children | int getChild() | setChild(int child) |
| `Email` | `String` | Required | Guest email | String getEmail() | setEmail(String email) |
| `Phone` | `String` | Optional | Guest phone | String getPhone() | setPhone(String phone) |
| `Notes` | `String` | Optional | Guest notes | String getNotes() | setNotes(String notes) |
| `CreditCardType` | `String` | Optional | Credit card type | String getCreditCardType() | setCreditCardType(String creditCardType) |
| `Total` | `double` | Required | Best available rate (This is the total value that guests will pay, including rate, fees, taxes, and all commissions. ) | double getTotal() | setTotal(double total) |

## Example (as JSON)

```json
{
  "reservationId": "107",
  "productId": "1234816374",
  "supplierId": 3731837,
  "channelName": "TestAndrew",
  "confirmationId": "dasdasd",
  "uniqueKey": null,
  "newState": null,
  "customerName": "John Smith",
  "fromDate": null,
  "toDate": null,
  "adult": 2,
  "child": 0,
  "email": "andrewtesttest222@gmail.com",
  "total": null
}
```

