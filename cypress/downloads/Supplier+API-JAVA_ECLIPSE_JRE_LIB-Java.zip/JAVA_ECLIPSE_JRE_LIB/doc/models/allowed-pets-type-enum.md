
# Allowed Pets Type Enum

## Enumeration

`AllowedPetsTypeEnum`

## Fields

| Name |
|  --- |
| `Allowed` |
| `AllowedOnRequest` |
| `NotAllowed` |

## Example

```
Allowed
```

