
# License Req Data

## Structure

`LicenseReqData`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `ProductId` | `String` | Optional | Product ID | String getProductId() | setProductId(String productId) |
| `LicenseRequirementResponse` | [`List<LicenseRequirementResponseObject>`](../../doc/models/license-requirement-response-object.md) | Optional | License Requirement Response Object | List<LicenseRequirementResponseObject> getLicenseRequirementResponse() | setLicenseRequirementResponse(List<LicenseRequirementResponseObject> licenseRequirementResponse) |

## Example (as JSON)

```json
{
  "productId": null,
  "licenseRequirementResponse": null
}
```

