
# Native Property Type Enum

Channel native Property Type

## Enumeration

`NativePropertyTypeEnum`

## Fields

| Name |
|  --- |
| `HomesAndApartments` |
| `Hotels` |

## Example

```
HomesAndApartments
```

