
# License Response Content Data

## Structure

`LicenseResponseContentData`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Name` | `String` | Optional | name of the license | String getName() | setName(String name) |
| `Value` | `String` | Optional | value of the license | String getValue() | setValue(String value) |

## Example (as JSON)

```json
{
  "name": null,
  "value": null
}
```

