
# Type Enum

Cancellation policy type. [FULLY_REFUNDABLE,NON_REFUNDABLE,MANUAL]

## Enumeration

`TypeEnum`

## Fields

| Name |
|  --- |
| `FULLYREFUNDABLE` |
| `NONREFUNDABLE` |
| `MANUAL` |

## Example

```
FULLY_REFUNDABLE
```

