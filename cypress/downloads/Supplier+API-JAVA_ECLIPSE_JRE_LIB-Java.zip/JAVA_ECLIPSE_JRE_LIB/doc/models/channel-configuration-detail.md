
# Channel Configuration Detail

## Structure

`ChannelConfigurationDetail`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Name` | `String` | Optional | Channel name | String getName() | setName(String name) |
| `Abbreviation` | `String` | Optional | Channel abbreviation | String getAbbreviation() | setAbbreviation(String abbreviation) |
| `Logo` | `String` | Optional | Channel logo | String getLogo() | setLogo(String logo) |
| `State` | [`StateEnum`](../../doc/models/state-enum.md) | Optional | Channel State | StateEnum getState() | setState(StateEnum state) |
| `SupportValidation` | `Boolean` | Optional | Channel support validation | Boolean getSupportValidation() | setSupportValidation(Boolean supportValidation) |
| `SupportCreate` | `Boolean` | Optional | Channel support create | Boolean getSupportCreate() | setSupportCreate(Boolean supportCreate) |
| `SupportConnect` | `Boolean` | Optional | Channel support connect | Boolean getSupportConnect() | setSupportConnect(Boolean supportConnect) |
| `SupportOpenClose` | `Boolean` | Optional | Channel support open close | Boolean getSupportOpenClose() | setSupportOpenClose(Boolean supportOpenClose) |
| `SupportStaticUpdate` | `Boolean` | Optional | Channel support Static Update | Boolean getSupportStaticUpdate() | setSupportStaticUpdate(Boolean supportStaticUpdate) |
| `SupportDynamicUpdate` | `Boolean` | Optional | Channel support Dynamic Update | Boolean getSupportDynamicUpdate() | setSupportDynamicUpdate(Boolean supportDynamicUpdate) |
| `SupportSynchronization` | `Boolean` | Optional | Channel support Synchronization | Boolean getSupportSynchronization() | setSupportSynchronization(Boolean supportSynchronization) |
| `SupportCreateChannelAccount` | `Boolean` | Optional | Channel support Create Channel Account | Boolean getSupportCreateChannelAccount() | setSupportCreateChannelAccount(Boolean supportCreateChannelAccount) |
| `SupportAuthorization` | `Boolean` | Optional | Channel support Authorization | Boolean getSupportAuthorization() | setSupportAuthorization(Boolean supportAuthorization) |
| `SupportCancelFormPm` | `Boolean` | Optional | Support cancel Reservation form Property Manager | Boolean getSupportCancelFormPm() | setSupportCancelFormPm(Boolean supportCancelFormPm) |
| `SupportModificationFromPm` | `Boolean` | Optional | Support modification Reservation from Property Manager | Boolean getSupportModificationFromPm() | setSupportModificationFromPm(Boolean supportModificationFromPm) |
| `SupportGather` | `Boolean` | Optional | Channel support Gather | Boolean getSupportGather() | setSupportGather(Boolean supportGather) |
| `SupportChannelCancellationPolicy` | `Boolean` | Optional | Channel support Channel Cancellation Policy | Boolean getSupportChannelCancellationPolicy() | setSupportChannelCancellationPolicy(Boolean supportChannelCancellationPolicy) |
| `BookingType` | [`BookingTypeEnum`](../../doc/models/booking-type-enum.md) | Optional | Channel booking Type | BookingTypeEnum getBookingType() | setBookingType(BookingTypeEnum bookingType) |
| `RatesAndAvailabilityMapping` | [`RatesAndAvailabilityMappingEnum`](../../doc/models/rates-and-availability-mapping-enum.md) | Optional | Channel rates And Availability Mapping | RatesAndAvailabilityMappingEnum getRatesAndAvailabilityMapping() | setRatesAndAvailabilityMapping(RatesAndAvailabilityMappingEnum ratesAndAvailabilityMapping) |
| `AcceptsPropertyType` | [`AcceptsPropertyTypeEnum`](../../doc/models/accepts-property-type-enum.md) | Optional | Channel accepts Property Type | AcceptsPropertyTypeEnum getAcceptsPropertyType() | setAcceptsPropertyType(AcceptsPropertyTypeEnum acceptsPropertyType) |
| `NativePropertyType` | [`NativePropertyTypeEnum`](../../doc/models/native-property-type-enum.md) | Optional | Channel native Property Type | NativePropertyTypeEnum getNativePropertyType() | setNativePropertyType(NativePropertyTypeEnum nativePropertyType) |
| `MinimumProperties` | `Integer` | Optional | Channel minimum Properties | Integer getMinimumProperties() | setMinimumProperties(Integer minimumProperties) |

## Example (as JSON)

```json
{
  "name": null,
  "abbreviation": null,
  "logo": null,
  "state": null,
  "supportValidation": null,
  "supportCreate": null,
  "supportConnect": null,
  "supportOpenClose": null,
  "supportStaticUpdate": null,
  "supportDynamicUpdate": null,
  "supportSynchronization": null,
  "supportCreateChannelAccount": null,
  "supportAuthorization": null,
  "supportCancelFormPm": null,
  "supportModificationFromPm": null,
  "supportGather": null,
  "supportChannelCancellationPolicy": null,
  "bookingType": null,
  "ratesAndAvailabilityMapping": null,
  "acceptsPropertyType": null,
  "nativePropertyType": null,
  "minimumProperties": null
}
```

