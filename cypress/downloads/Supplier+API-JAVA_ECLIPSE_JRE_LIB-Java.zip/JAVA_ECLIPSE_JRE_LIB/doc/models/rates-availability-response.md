
# Rates Availability Response

Rates Availability response

## Structure

`RatesAvailabilityResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Message` | `String` | Required | text info message | String getMessage() | setMessage(String message) |
| `ErrorMessage` | `List<String>` | Required | List of error messages | List<String> getErrorMessage() | setErrorMessage(List<String> errorMessage) |
| `IsError` | `boolean` | Required | Is error (default = false) | boolean getIsError() | setIsError(boolean isError) |
| `Code` | `String` | Required | Code of message | String getCode() | setCode(String code) |
| `Data` | [`List<RatesAvailability>`](../../doc/models/rates-availability.md) | Required | List of models. This is a deprecated field. It will be removed in version 3.3. (This is only for Create and update requests, so you will not get this data in response). On GET request you will get data here. | List<RatesAvailability> getData() | setData(List<RatesAvailability> data) |

## Example (as JSON)

```json
{
  "message": "Your request was received and put in queue",
  "errorMessage": [],
  "is_error": false,
  "code": "",
  "data": []
}
```

