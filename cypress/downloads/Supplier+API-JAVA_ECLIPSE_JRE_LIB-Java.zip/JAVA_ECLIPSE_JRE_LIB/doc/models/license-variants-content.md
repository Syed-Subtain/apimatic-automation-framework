
# License Variants Content

## Structure

`LicenseVariantsContent`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Name` | `String` | Optional | name of the variant | String getName() | setName(String name) |
| `DataType` | `String` | Optional | data type of the variant | String getDataType() | setDataType(String dataType) |
| `Required` | `String` | Optional | indicator if content is required | String getRequired() | setRequired(String required) |

## Example (as JSON)

```json
{
  "name": null,
  "dataType": null,
  "required": null
}
```

