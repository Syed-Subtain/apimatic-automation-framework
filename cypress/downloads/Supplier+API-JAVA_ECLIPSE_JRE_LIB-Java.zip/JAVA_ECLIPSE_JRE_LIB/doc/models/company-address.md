
# Company Address

## Structure

`CompanyAddress`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Country` | `String` | Required | Country of PM. Require 2 letter ISO code | String getCountry() | setCountry(String country) |
| `State` | `String` | Required | State (Region) of PM. Required for US properties. | String getState() | setState(String state) |
| `StreetAddress` | `String` | Required | Street address of PM. | String getStreetAddress() | setStreetAddress(String streetAddress) |
| `City` | `String` | Required | City of PM | String getCity() | setCity(String city) |
| `Zip` | `String` | Required | Zip code (postal code) of PM. | String getZip() | setZip(String zip) |

## Example (as JSON)

```json
{
  "country": "US",
  "state": "Test State",
  "streetAddress": "Test Street",
  "city": "Test City",
  "zip": "13245"
}
```

