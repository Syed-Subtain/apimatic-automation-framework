
# Createand Update Ratesand Availability Request

## Structure

`CreateandUpdateRatesandAvailabilityRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Data` | [`RatesAvailability`](../../doc/models/rates-availability.md) | Required | Rates Availability model | RatesAvailability getData() | setData(RatesAvailability data) |

## Example (as JSON)

```json
{
  "data": {
    "productId": 184,
    "leadTime": null,
    "rates": null,
    "minStays": null,
    "maxStays": null,
    "restrictions": null,
    "availabilities": null,
    "availableCount": null
  }
}
```

