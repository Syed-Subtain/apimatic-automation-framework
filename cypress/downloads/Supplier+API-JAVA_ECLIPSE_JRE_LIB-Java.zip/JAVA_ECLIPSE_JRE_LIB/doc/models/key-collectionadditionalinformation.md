
# Key Collectionadditionalinformation

## Structure

`KeyCollectionadditionalinformation`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Instruction` | [`KeyCollectionadditionalinformationinstruction`](../../doc/models/key-collectionadditionalinformationinstruction.md) | Required | - | KeyCollectionadditionalinformationinstruction getInstruction() | setInstruction(KeyCollectionadditionalinformationinstruction instruction) |

## Example (as JSON)

```json
{
  "instruction": {
    "how": "how example",
    "when": "when example"
  }
}
```

