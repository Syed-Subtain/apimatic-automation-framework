
# Bedroom Configuration

## Structure

`BedroomConfiguration`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Bedrooms` | [`List<Bedroom>`](../../doc/models/bedroom.md) | Required | Bedroom configuration for property | List<Bedroom> getBedrooms() | setBedrooms(List<Bedroom> bedrooms) |

## Example (as JSON)

```json
{
  "bedrooms": [
    {
      "beds": {
        "bed": [
          {
            "bedType": "RMA113",
            "count": 1
          },
          {
            "bedType": "RMA58",
            "count": 1
          }
        ]
      },
      "type": "Bedroom",
      "privateBathroom": false
    },
    {
      "beds": {
        "bed": [
          {
            "bedType": "RMA113",
            "count": 1
          },
          {
            "bedType": "RMA58",
            "count": 1
          }
        ]
      },
      "type": "Bedroom",
      "privateBathroom": false
    },
    {
      "beds": {
        "bed": [
          {
            "bedType": "RMA113",
            "count": 1
          },
          {
            "bedType": "RMA86",
            "count": 1
          }
        ]
      },
      "type": "Bedroom",
      "privateBathroom": false
    },
    {
      "beds": {
        "bed": [
          {
            "bedType": "RMA113",
            "count": 1
          }
        ]
      },
      "type": "Bedroom",
      "privateBathroom": false
    },
    {
      "beds": {
        "bed": [
          {
            "bedType": "RMA113",
            "count": 1
          }
        ]
      },
      "type": "Bedroom",
      "privateBathroom": false
    },
    {
      "beds": {
        "bed": [
          {
            "bedType": "RMA58",
            "count": 1
          }
        ]
      },
      "type": "Bedroom",
      "privateBathroom": true
    },
    {
      "beds": {
        "bed": [
          {
            "bedType": "RMA58",
            "count": 1
          }
        ]
      },
      "type": "Living Room",
      "privateBathroom": false
    }
  ]
}
```

