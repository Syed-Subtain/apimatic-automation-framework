
# Validation Asynchronous Push Message Request

Request for validation messages which BookingPal push asynchronous (webhooks request)

## Structure

`ValidationAsynchronousPushMessageRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `SupplierId` | `int` | Required | Id of supplier in BookingPal | int getSupplierId() | setSupplierId(int supplierId) |
| `Type` | `String` | Required | - | String getType() | setType(String type) |
| `Validation` | [`List<AsynchronousValidationModel>`](../../doc/models/asynchronous-validation-model.md) | Required | Validation Model | List<AsynchronousValidationModel> getValidation() | setValidation(List<AsynchronousValidationModel> validation) |

## Example (as JSON)

```json
{
  "supplierId": 636753,
  "type": "BP_VALIDATION",
  "validation": [
    {
      "productId": 291358,
      "validationErrors": "null",
      "valid": true
    },
    {
      "productId": 291356,
      "validationErrors": "noPrice;",
      "valid": false
    }
  ]
}
```

