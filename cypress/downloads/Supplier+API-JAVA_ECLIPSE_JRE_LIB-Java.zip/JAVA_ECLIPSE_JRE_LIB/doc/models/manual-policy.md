
# Manual Policy

## Structure

`ManualPolicy`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Type` | [`ManualPolicyTypeEnum`](../../doc/models/manual-policy-type-enum.md) | Required | - | ManualPolicyTypeEnum getType() | setType(ManualPolicyTypeEnum type) |
| `ManualPolicies` | [`List<ManualPolicies>`](../../doc/models/manual-policies.md) | Required | Model | List<ManualPolicies> getManualPolicies() | setManualPolicies(List<ManualPolicies> manualPolicies) |

## Example (as JSON)

```json
{
  "type": "FLAT",
  "manualPolicies": [
    {
      "chargeValue": 20,
      "beforeDays": 34,
      "cancellationFee": 1
    },
    {
      "chargeValue": 12,
      "beforeDays": 45,
      "cancellationFee": 2
    }
  ]
}
```

