
# Fee Entity Type Enum

## Enumeration

`FeeEntityTypeEnum`

## Fields

| Name |
|  --- |
| `MANDATORY` |
| `OPTIONAL` |
| `MANDATORYPAL` |

## Example

```
MANDATORY
```

