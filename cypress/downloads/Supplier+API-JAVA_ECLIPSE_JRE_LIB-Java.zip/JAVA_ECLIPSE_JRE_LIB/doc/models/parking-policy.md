
# Parking Policy

## Structure

`ParkingPolicy`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `AccessParking` | `boolean` | Required | Access parking into properties {true,false} | boolean getAccessParking() | setAccessParking(boolean accessParking) |
| `LocatedParking` | [`LocatedParkingTypeEnum`](../../doc/models/located-parking-type-enum.md) | Optional | - | LocatedParkingTypeEnum getLocatedParking() | setLocatedParking(LocatedParkingTypeEnum locatedParking) |
| `PrivateParking` | `Boolean` | Optional | Parking is private or no. {true,false} | Boolean getPrivateParking() | setPrivateParking(Boolean privateParking) |
| `ChargeParking` | `String` | Optional | Charge parking. Example: “Free”, “$ 100”. | String getChargeParking() | setChargeParking(String chargeParking) |
| `TimeCostParking` | [`TimeCostParkingEnum`](../../doc/models/time-cost-parking-enum.md) | Optional | - | TimeCostParkingEnum getTimeCostParking() | setTimeCostParking(TimeCostParkingEnum timeCostParking) |
| `NecessaryReservationParking` | [`ReservationParkingTypeEnum`](../../doc/models/reservation-parking-type-enum.md) | Optional | - | ReservationParkingTypeEnum getNecessaryReservationParking() | setNecessaryReservationParking(ReservationParkingTypeEnum necessaryReservationParking) |

## Example (as JSON)

```json
{
  "accessParking": true,
  "locatedParking": "OnSite",
  "privateParking": true,
  "chargeParking": "$ 150",
  "timeCostParking": "PerStay",
  "necessaryReservationParking": "NotPossible"
}
```

