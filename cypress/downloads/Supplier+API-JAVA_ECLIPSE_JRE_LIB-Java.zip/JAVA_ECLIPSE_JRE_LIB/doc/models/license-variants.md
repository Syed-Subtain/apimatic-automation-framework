
# License Variants

## Structure

`LicenseVariants`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Id` | `String` | Optional | ID of the variant | String getId() | setId(String id) |
| `Name` | `String` | Optional | name of the variant | String getName() | setName(String name) |
| `Content` | [`List<LicenseVariantsContent>`](../../doc/models/license-variants-content.md) | Optional | - | List<LicenseVariantsContent> getContent() | setContent(List<LicenseVariantsContent> content) |

## Example (as JSON)

```json
{
  "id": null,
  "name": null,
  "content": null
}
```

