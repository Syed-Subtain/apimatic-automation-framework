
# Rate

## Structure

`Rate`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `BeginDate` | `LocalDate` | Required | Beginning date of date range for which rate is applied. Date should be in format "yyyy-MM-dd" | LocalDate getBeginDate() | setBeginDate(LocalDate beginDate) |
| `EndDate` | `LocalDate` | Required | End date of date range for which rate is applied. Date should be in format "yyyy-MM-dd" | LocalDate getEndDate() | setEndDate(LocalDate endDate) |
| `Amount` | `double` | Required | Value of rate, needs to be higher than 0, otherwise it will not be imported | double getAmount() | setAmount(double amount) |

## Example (as JSON)

```json
{
  "beginDate": "2016-03-13",
  "endDate": "2016-03-13",
  "amount": 56.78
}
```

