
# State Enum

Channel State

## Enumeration

`StateEnum`

## Fields

| Name |
|  --- |
| `NOTVISIBLE` |
| `VISIBLE` |
| `COMINGSOON` |

## Example

```
NOT_VISIBLE
```

