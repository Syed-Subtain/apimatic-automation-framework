
# Image Push Notification

## Structure

`ImagePushNotification`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Success` | `boolean` | Required | Processing Image success status | boolean getSuccess() | setSuccess(boolean success) |
| `Type` | [`TypeEnum`](../../doc/models/type-enum.md) | Required | image type | TypeEnum getType() | setType(TypeEnum type) |
| `Url` | `String` | Required | image URL | String getUrl() | setUrl(String url) |
| `Version` | `String` | Required | Versoin for processing image | String getVersion() | setVersion(String version) |

## Example (as JSON)

```json
{
  "success": null,
  "type": "IMPORT",
  "url": null,
  "version": null
}
```

