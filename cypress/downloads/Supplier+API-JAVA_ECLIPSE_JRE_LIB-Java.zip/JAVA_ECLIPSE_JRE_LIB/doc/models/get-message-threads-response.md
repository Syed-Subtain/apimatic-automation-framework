
# Get Message Threads Response

## Structure

`GetMessageThreadsResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Message` | `String` | Required | Text info message | String getMessage() | setMessage(String message) |
| `ErrorMessage` | `List<String>` | Required | Text info message | List<String> getErrorMessage() | setErrorMessage(List<String> errorMessage) |
| `IsError` | `boolean` | Required | Is error (default = false) | boolean getIsError() | setIsError(boolean isError) |
| `Code` | `String` | Required | Code of message | String getCode() | setCode(String code) |
| `Data` | [`List<ThreadsModel>`](../../doc/models/threads-model.md) | Required | List of Models | List<ThreadsModel> getData() | setData(List<ThreadsModel> data) |

## Example (as JSON)

```json
{
  "message": "",
  "errorMessage": [],
  "is_error": false,
  "code": "",
  "data": [
    {
      "threads": []
    }
  ]
}
```

