
# Multi Unit Enum

Enum for product multyunit type.

## Enumeration

`MultiUnitEnum`

## Fields

| Name | Description |
|  --- | --- |
| `MLT` | Enum type for MultiUnit property type |
| `OWN` | Enum type for Owner (hotel) property type |

## Example

```
MLT
```

