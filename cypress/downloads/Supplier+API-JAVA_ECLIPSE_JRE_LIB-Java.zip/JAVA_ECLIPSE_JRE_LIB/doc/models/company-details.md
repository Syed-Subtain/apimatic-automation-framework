
# Company Details

## Structure

`CompanyDetails`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `AccountId` | `String` | Required | Unique ID of PM in PMS | String getAccountId() | setAccountId(String accountId) |
| `CompanyName` | `String` | Required | Name of PM | String getCompanyName() | setCompanyName(String companyName) |
| `Language` | `String` | Required | Language 2 letter value  as ISO 639-1 code | String getLanguage() | setLanguage(String language) |
| `FullName` | `String` | Required | First and Last Name | String getFullName() | setFullName(String fullName) |
| `CompanyAddress` | [`CompanyAddress`](../../doc/models/company-address.md) | Required | - | CompanyAddress getCompanyAddress() | setCompanyAddress(CompanyAddress companyAddress) |
| `Website` | `String` | Required | Company (PM) website URL | String getWebsite() | setWebsite(String website) |
| `Email` | `String` | Required | Email of PM. Email need to be unique in BP system, so you might receive error if we already have this email in our system | String getEmail() | setEmail(String email) |
| `Phone` | [`Phone`](../../doc/models/phone.md) | Required | - | Phone getPhone() | setPhone(Phone phone) |
| `Password` | `String` | Optional | Password for accessing PM. If the password is not passed in the request random password will be generated and returned in response. Password will be in response only on create and if it is manually generated. Special characters are not allowed, instead use UTF-8 codes, for example instead of # use %23 | String getPassword() | setPassword(String password) |
| `Currency` | `String` | Required | PM default currency. ISO 4217 code is required | String getCurrency() | setCurrency(String currency) |

## Example (as JSON)

```json
{
  "accountId": "132",
  "companyName": "Test PM",
  "language": "en",
  "fullName": "Test PM",
  "companyAddress": {
    "country": "US",
    "state": "Test State",
    "streetAddress": "Test Street",
    "city": "Test City",
    "zip": "13245"
  },
  "website": "www.testsite.com",
  "email": "apimaticPMemail@test.com",
  "phone": {
    "countryCode": "321",
    "number": "132456"
  },
  "password": "password",
  "currency": "USD"
}
```

