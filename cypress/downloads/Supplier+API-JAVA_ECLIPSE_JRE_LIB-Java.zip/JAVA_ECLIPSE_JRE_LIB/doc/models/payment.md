
# Payment

## Structure

`Payment`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `PaymentType` | [`PaymentTypeEnum`](../../doc/models/payment-type-enum.md) | Required | - | PaymentTypeEnum getPaymentType() | setPaymentType(PaymentTypeEnum paymentType) |
| `CreditCard` | [`CreditCard`](../../doc/models/credit-card.md) | Optional | - | CreditCard getCreditCard() | setCreditCard(CreditCard creditCard) |

## Example (as JSON)

```json
{
  "paymentType": "MAIL_CHECK",
  "creditCard": {
    "creditCardType": "POST",
    "paymentGateways": {
      "paymentGatewaysType": "AUTHORIZE_NET",
      "user": "test",
      "secret": "test",
      "additionalField1": "",
      "additionalField2": ""
    },
    "creditCardList": [
      "AMERICAN_EXPRESS",
      "DINERS_CLUB"
    ]
  }
}
```

