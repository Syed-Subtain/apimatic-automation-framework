
# Threads Model

## Structure

`ThreadsModel`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Threads` | [`List<Thread>`](../../doc/models/thread.md) | Required | List of models | List<Thread> getThreads() | setThreads(List<Thread> threads) |

## Example (as JSON)

```json
{
  "threads": {
    "id": null,
    "lastMessageSentAt": null,
    "lastMessageText": null,
    "channelName": null,
    "channelABB": "BKG",
    "guestName": null,
    "productId": null,
    "dateFrom": null,
    "dateTo": null
  }
}
```

