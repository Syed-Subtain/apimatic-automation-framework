
# Location

## Structure

`Location`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `PostalCode` | `String` | Required | Postal code of property (Zip code) | String getPostalCode() | setPostalCode(String postalCode) |
| `Country` | `String` | Required | Country of property. Require 2 letter ISO code | String getCountry() | setCountry(String country) |
| `Region` | `String` | Required | State (Region) of PM. Required for US properties. | String getRegion() | setRegion(String region) |
| `City` | `String` | Required | City of property | String getCity() | setCity(String city) |
| `Street` | `String` | Required | Street of property | String getStreet() | setStreet(String street) |
| `ZipCode9` | `String` | Required | Set only for US properties (format should be zip5-xxxx) | String getZipCode9() | setZipCode9(String zipCode9) |

## Example (as JSON)

```json
{
  "postalCode": "60606",
  "country": "US",
  "region": "Illinois",
  "city": "Chicago",
  "street": "210 North Wells Street",
  "zipCode9": "60606-1330"
}
```

