
# Create and Update LOS Request

## Structure

`CreateAndUpdateLOSRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Data` | [`LOSRatesProduct`](../../doc/models/los-rates-product.md) | Required | Model for product LOS rates | LOSRatesProduct getData() | setData(LOSRatesProduct data) |

## Example (as JSON)

```json
{
  "data": {
    "productId": 184,
    "losRates": [
      {
        "checkInDate": "2016-03-13",
        "maxGuests": 51,
        "losValue": [
          57.37,
          57.38
        ],
        "currency": null
      },
      {
        "checkInDate": "2016-03-13",
        "maxGuests": 50,
        "losValue": [
          57.38,
          57.39,
          57.4
        ],
        "currency": null
      },
      {
        "checkInDate": "2016-03-13",
        "maxGuests": 49,
        "losValue": [
          57.39
        ],
        "currency": null
      }
    ]
  }
}
```

