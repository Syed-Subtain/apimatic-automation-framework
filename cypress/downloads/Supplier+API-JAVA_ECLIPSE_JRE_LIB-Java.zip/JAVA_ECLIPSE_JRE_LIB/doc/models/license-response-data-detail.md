
# License Response Data Detail

## Structure

`LicenseResponseDataDetail`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `VariantId` | `String` | Optional | Variant ID | String getVariantId() | setVariantId(String variantId) |
| `ContentData` | [`List<LicenseResponseContentData>`](../../doc/models/license-response-content-data.md) | Optional | - | List<LicenseResponseContentData> getContentData() | setContentData(List<LicenseResponseContentData> contentData) |

## Example (as JSON)

```json
{
  "variantId": null,
  "contentData": null
}
```

