
# Phone

## Structure

`Phone`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `CountryCode` | `String` | Required | Country code prefix in phone number. For example “+1”. | String getCountryCode() | setCountryCode(String countryCode) |
| `Number` | `String` | Required | Phone number | String getNumber() | setNumber(String number) |

## Example (as JSON)

```json
{
  "countryCode": "321",
  "number": "132456"
}
```

