
# License Get Response Data

## Structure

`LicenseGetResponseData`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `ProductId` | `String` | Optional | name of the property | String getProductId() | setProductId(String productId) |
| `Level` | `String` | Optional | Level of the property for the name above | String getLevel() | setLevel(String level) |
| `LicenseInformationResponse` | [`List<LicenseInfoResponse>`](../../doc/models/license-info-response.md) | Optional | - | List<LicenseInfoResponse> getLicenseInformationResponse() | setLicenseInformationResponse(List<LicenseInfoResponse> licenseInformationResponse) |

## Example (as JSON)

```json
{
  "productId": null,
  "level": null,
  "licenseInformationResponse": null
}
```

