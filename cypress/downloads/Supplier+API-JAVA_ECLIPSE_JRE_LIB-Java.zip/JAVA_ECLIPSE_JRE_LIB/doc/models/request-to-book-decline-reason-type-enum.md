
# Request to Book Decline Reason Type Enum

## Enumeration

`RequestToBookDeclineReasonTypeEnum`

## Fields

| Name |
|  --- |
| `DATESNOTAVAILABLE` |
| `NOTAGOODFIT` |
| `WAITINGFORBETTERRESERVATION` |
| `NOTCOMFORTABLE` |

## Example

```
DATES_NOT_AVAILABLE
```

