
# Cancellation Policy

## Structure

`CancellationPolicy`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Type` | [`CancellationPolicyTypeEnum`](../../doc/models/cancellation-policy-type-enum.md) | Required | - | CancellationPolicyTypeEnum getType() | setType(CancellationPolicyTypeEnum type) |
| `ManualPolicy` | [`ManualPolicy`](../../doc/models/manual-policy.md) | Required | - | ManualPolicy getManualPolicy() | setManualPolicy(ManualPolicy manualPolicy) |

## Example (as JSON)

```json
{
  "type": "MANUAL",
  "manualPolicy": {
    "type": "FLAT",
    "manualPolicies": [
      {
        "chargeValue": 20,
        "beforeDays": 34,
        "cancellationFee": 1
      },
      {
        "chargeValue": 12,
        "beforeDays": 45,
        "cancellationFee": 2
      }
    ]
  }
}
```

