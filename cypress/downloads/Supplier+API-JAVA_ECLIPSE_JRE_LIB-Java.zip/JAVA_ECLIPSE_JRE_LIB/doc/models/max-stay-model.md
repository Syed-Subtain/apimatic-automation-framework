
# Max Stay Model

## Structure

`MaxStayModel`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `BeginDate` | `LocalDate` | Required | Beginning date of date range for which max stay is applied. Date should be in format "yyyy-MM-dd" | LocalDate getBeginDate() | setBeginDate(LocalDate beginDate) |
| `EndDate` | `LocalDate` | Required | End date of date range for which max stay is applied. Date should be in format "yyyy-MM-dd" | LocalDate getEndDate() | setEndDate(LocalDate endDate) |
| `MaxStay` | `int` | Required | Number of days that will be applied for max stay | int getMaxStay() | setMaxStay(int maxStay) |

## Example (as JSON)

```json
{
  "beginDate": "2016-03-13",
  "endDate": "2016-03-13",
  "maxStay": 24
}
```

