
# Text

## Structure

`Text`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Language` | `String` | Required | Language 2 letter value  as ISO 639-1 code (https://en.wikipedia.org/wiki/List_of_ISO_639-1_codes) | String getLanguage() | setLanguage(String language) |
| `Value` | `String` | Required | Text value. Send here only plain text. Do not use HTML or any other characters. | String getValue() | setValue(String value) |

## Example (as JSON)

```json
{
  "language": "EN",
  "value": "Main description on EN!"
}
```

