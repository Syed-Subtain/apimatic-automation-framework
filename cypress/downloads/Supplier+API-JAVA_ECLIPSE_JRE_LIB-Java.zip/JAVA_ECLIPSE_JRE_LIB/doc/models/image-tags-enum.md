
# Image Tags Enum

## Enumeration

`ImageTagsEnum`

## Fields

| Name | Description |
|  --- | --- |
| `Enum1` | Shower |
| `Enum2` | Toilet |
| `Enum3` | Property building |
| `Enum4` | patio |
| `Enum5` | Nearby landmark |
| `Enum6` | Staff |
| `Enum7` | Restaurant/places to eat |
| `Enum8` | Communal lounge/ TV room |
| `Enum10` | Facade/entrance |
| `Enum43` | People |
| `Enum11` | Spring |
| `Enum13` | Bed |
| `Enum14` | Off site |
| `Enum37` | Food close-up |
| `Enum41` | Day |
| `Enum42` | Night |
| `Enum50` | Property logo or sign |
| `Enum55` | Neighbourhood |
| `Enum61` | Natural landscape |
| `Enum70` | Activities |
| `Enum74` | Bird's eye view |
| `Enum81` | Winter |
| `Enum82` | Summer |
| `Enum87` | BBQ facilities |
| `Enum89` | Billiard |
| `Enum90` | Bowling |
| `Enum94` | Casino |
| `Enum95` | Place of worship |
| `Enum96` | Children play ground |
| `Enum97` | Darts |
| `Enum100` | Fishing |
| `Enum102` | Game Room |
| `Enum103` | Garden |
| `Enum104` | Golf course |
| `Enum106` | Horse-riding |
| `Enum107` | Hot Spring Bath |
| `Enum141` | Table tennis |
| `Enum108` | Hot Tub |
| `Enum112` | Karaoke |
| `Enum113` | Library |
| `Enum114` | Massage |
| `Enum115` | Minigolf |
| `Enum116` | Nightclub / DJ |
| `Enum124` | Sauna |
| `Enum125` | On-site shops |
| `Enum128` | Ski School |
| `Enum131` | Skiing |
| `Enum137` | Squash |
| `Enum133` | Snorkeling |
| `Enum134` | Solarium |
| `Enum143` | Steam room |
| `Enum153` | Bathroom |
| `Enum154` | TV and multimedia |
| `Enum155` | Coffee/tea facilities |
| `Enum156` | View (from property/room) |
| `Enum157` | Balcony/Terrace |
| `Enum158` | Kitchen or kitchenette |
| `Enum159` | Living room |
| `Enum160` | Lobby or reception |
| `Enum161` | Lounge or bar |
| `Enum164` | Spa and wellness centre/facili |
| `Enum165` | Fitness centre/facilities |
| `Enum167` | Food and drinks |
| `Enum172` | Other |
| `Enum173` | Photo of the whole room |
| `Enum177` | Business facilities |
| `Enum178` | Banquet/Function facilities |
| `Enum179` | Decorative detail |
| `Enum182` | Seating area |
| `Enum183` | Floor plan |
| `Enum184` | Dining area |
| `Enum185` | Beach |
| `Enum186` | Aqua park |
| `Enum187` | Tennis court |
| `Enum188` | Windsurfing |
| `Enum189` | Canoeing |
| `Enum190` | Hiking |
| `Enum191` | Cycling |
| `Enum192` | Diving |
| `Enum193` | Kids's club |
| `Enum194` | Evening entertainment |
| `Enum197` | Logo/Certificate/Sign |
| `Enum198` | Animals |
| `Enum199` | Bedroom |
| `Enum204` | Communal kitchen |
| `Enum205` | Autumn |
| `Enum240` | On site |
| `Enum241` | Meeting/conference room |
| `Enum242` | Food |
| `Enum245` | Text overlay |
| `Enum246` | Pets |
| `Enum247` | Guests |
| `Enum248` | City view |
| `Enum249` | Garden view |
| `Enum250` | Lake view |
| `Enum251` | Landmark view |
| `Enum252` | Mountain view |
| `Enum253` | Pool view |
| `Enum254` | River view |
| `Enum255` | Sea view |
| `Enum256` | Street view |
| `Enum257` | Area and facilities |
| `Enum258` | Supermarket/grocery shop |
| `Enum259` | Shopping Area |
| `Enum260` | Swimming pool |
| `Enum261` | Sports |
| `Enum262` | Entertainment |
| `Enum263` | Meals |
| `Enum264` | Breakfast |
| `Enum265` | Continental breakfast |
| `Enum266` | Buffet breakfast |
| `Enum267` | Asian breakfast |
| `Enum268` | Italian breakfast |
| `Enum269` | English/Irish breakfast |
| `Enum270` | American breakfast |
| `Enum271` | Lunch |
| `Enum272` | Dinner |
| `Enum273` | Drinks |
| `Enum274` | Alcoholic drinks |
| `Enum275` | Non alcoholic drinks |
| `Enum276` | Seasons |
| `Enum277` | Time of day |
| `Enum278` | Location |
| `Enum279` | Sunrise |
| `Enum280` | Sunset |
| `Enum281` | children |
| `Enum282` | young children |
| `Enum283` | older children |
| `Enum284` | group of guests |
| `Enum285` | cot |
| `Enum286` | bunk bed |
| `Enum287` | Certificate/Award |
| `Enum288` | ADAM |
| `Enum289` | Open Air Bath |
| `Enum290` | Public Bath |
| `Enum291` | Family |

## Example

```
1
```

