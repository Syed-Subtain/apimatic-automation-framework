
# Policies

## Structure

`Policies`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `PaymentPolicy` | [`PaymentPolicy`](../../doc/models/payment-policy.md) | Required | - | PaymentPolicy getPaymentPolicy() | setPaymentPolicy(PaymentPolicy paymentPolicy) |
| `CancellationPolicy` | [`CancellationPolicy`](../../doc/models/cancellation-policy.md) | Required | - | CancellationPolicy getCancellationPolicy() | setCancellationPolicy(CancellationPolicy cancellationPolicy) |
| `FeeTaxMandatory` | [`FeeTaxMandatory`](../../doc/models/fee-tax-mandatory.md) | Required | - | FeeTaxMandatory getFeeTaxMandatory() | setFeeTaxMandatory(FeeTaxMandatory feeTaxMandatory) |
| `Terms` | `String` | Required | Full URL to PM terms and conditions | String getTerms() | setTerms(String terms) |
| `CheckInTime` | `String` | Required | Time of Check in (HH:MM:SS) | String getCheckInTime() | setCheckInTime(String checkInTime) |
| `CheckOutTime` | `String` | Required | Time of Check out (HH:MM:SS) | String getCheckOutTime() | setCheckOutTime(String checkOutTime) |
| `LeadTime` | `int` | Required | Minimum number of days before check-in for which reservation is allowed to be booked. Allowed values are 0-7. | int getLeadTime() | setLeadTime(int leadTime) |

## Example (as JSON)

```json
{
  "paymentPolicy": {
    "type": "SPLIT",
    "splitPayment": {
      "depositType": "FLAT",
      "value": 4,
      "secondPaymentDays": 30
    }
  },
  "cancellationPolicy": {
    "type": "MANUAL",
    "manualPolicy": {
      "type": "FLAT",
      "manualPolicies": [
        {
          "chargeValue": 20,
          "beforeDays": 34,
          "cancellationFee": 1
        },
        {
          "chargeValue": 12,
          "beforeDays": 45,
          "cancellationFee": 2
        }
      ]
    }
  },
  "feeTaxMandatory": {
    "isFeeMandatory": true,
    "isTaxMandatory": true
  },
  "terms": "www.test.com",
  "checkInTime": "36000",
  "checkOutTime": "57600",
  "leadTime": 2
}
```

