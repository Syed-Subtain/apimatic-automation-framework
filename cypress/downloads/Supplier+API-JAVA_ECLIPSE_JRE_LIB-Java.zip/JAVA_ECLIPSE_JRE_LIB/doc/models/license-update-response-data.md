
# License Update Response Data

## Structure

`LicenseUpdateResponseData`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `ProductId` | `String` | Optional | product ID | String getProductId() | setProductId(String productId) |
| `Response` | [`List<LicenseUpdateResponseDataDetail>`](../../doc/models/license-update-response-data-detail.md) | Optional | - | List<LicenseUpdateResponseDataDetail> getResponse() | setResponse(List<LicenseUpdateResponseDataDetail> response) |

## Example (as JSON)

```json
{
  "productId": null,
  "response": null
}
```

