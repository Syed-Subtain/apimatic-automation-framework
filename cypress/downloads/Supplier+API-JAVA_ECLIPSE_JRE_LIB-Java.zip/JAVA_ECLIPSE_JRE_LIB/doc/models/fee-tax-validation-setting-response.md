
# Fee Tax Validation Setting Response

## Structure

`FeeTaxValidationSettingResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Message` | `String` | Required | Text info message | String getMessage() | setMessage(String message) |
| `ErrorMessage` | `List<String>` | Required | List of error messages | List<String> getErrorMessage() | setErrorMessage(List<String> errorMessage) |
| `IsError` | `boolean` | Required | Is error (default = false) | boolean getIsError() | setIsError(boolean isError) |
| `Code` | `String` | Required | Code of message | String getCode() | setCode(String code) |
| `Data` | [`List<FeeTaxValidationSettings>`](../../doc/models/fee-tax-validation-settings.md) | Required | List of Models | List<FeeTaxValidationSettings> getData() | setData(List<FeeTaxValidationSettings> data) |

## Example (as JSON)

```json
{
  "message": "",
  "errorMessage": [],
  "is_error": false,
  "code": "",
  "data": [
    {
      "validationSettings": [
        {
          "productId": 1235124634,
          "isFeeMandatory": false,
          "isTaxMandatory": false
        },
        {
          "productId": 1235124636,
          "isFeeMandatory": true,
          "isTaxMandatory": true
        },
        {
          "productId": 1235124637,
          "isFeeMandatory": true,
          "isTaxMandatory": true
        }
      ]
    }
  ]
}
```

