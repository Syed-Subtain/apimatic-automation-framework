
# Attributes With Quantity

List of allowed attribute codes and mapping on different channels you can also find on this URL https://developerstesting.channelconnector.com/channel-attributes/

## Structure

`AttributesWithQuantity`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `AttributeId` | [`AmenityTypesEnum`](../../doc/models/amenity-types-enum.md) | Required | - | AmenityTypesEnum getAttributeId() | setAttributeId(AmenityTypesEnum attributeId) |
| `Quantity` | `int` | Required | Will be set to 1 by default | int getQuantity() | setQuantity(int quantity) |

## Example (as JSON)

```json
{
  "attributeId": "HAC312",
  "quantity": 1
}
```

