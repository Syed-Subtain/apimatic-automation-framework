
# Property

## Structure

`Property`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Name` | `String` | Required | Name of the property to display in the list | String getName() | setName(String name) |
| `Id` | `Integer` | Optional | Property ID in BookingPal | Integer getId() | setId(Integer id) |
| `AltId` | `Integer` | Optional | Alternative Id of the property (ID in your PMS system).   Note: this field can not be updated, so this field will not be used during update. | Integer getAltId() | setAltId(Integer altId) |
| `SupplierId` | `Integer` | Optional | Id of the Property Manager (not be used for creating new property. Property will have ID of current authorized user) | Integer getSupplierId() | setSupplierId(Integer supplierId) |
| `Rooms` | `int` | Required | Number of bedrooms. Number of bedrooms should be > 0. Value 0 is only allowed in case property type  is Studio (PCT46 or PCT110) | int getRooms() | setRooms(int rooms) |
| `Bathrooms` | `int` | Required | Number of bathrooms | int getBathrooms() | setBathrooms(int bathrooms) |
| `Toilets` | `Integer` | Optional | Number of toilets | Integer getToilets() | setToilets(Integer toilets) |
| `TotalBeds` | `Integer` | Optional | Property’s total number of beds | Integer getTotalBeds() | setTotalBeds(Integer totalBeds) |
| `Space` | `Double` | Optional | Property size | Double getSpace() | setSpace(Double space) |
| `SpaceUnit` | [`SpaceUnitEnum`](../../doc/models/space-unit-enum.md) | Optional | - | SpaceUnitEnum getSpaceUnit() | setSpaceUnit(SpaceUnitEnum spaceUnit) |
| `Persons` | `int` | Required | Maximum number of allowed adults | int getPersons() | setPersons(int persons) |
| `Childs` | `Integer` | Optional | Number of allowed children (from 7 to 12 years) | Integer getChilds() | setChilds(Integer childs) |
| `Latitude` | `Double` | Optional | Latitude of the property (Must set field latitude and longitude or location) | Double getLatitude() | setLatitude(Double latitude) |
| `Longitude` | `Double` | Optional | Longitude of the property (Must set field latitude and longitude or location) | Double getLongitude() | setLongitude(Double longitude) |
| `LivingRoom` | `Integer` | Optional | Number of Living rooms | Integer getLivingRoom() | setLivingRoom(Integer livingRoom) |
| `Notes` | [`Notes`](../../doc/models/notes.md) | Optional | Model where you can define different kinds of text values. If you need to delete some kind of texts, for example short description, you can do this on Update call (PUT), and you need to pass empty array for texts value, for example :  "shortDescription": {  "texts": [  ] } | Notes getNotes() | setNotes(Notes notes) |
| `AttributesWithQuantity` | [`List<AttributesWithQuantity>`](../../doc/models/attributes-with-quantity.md) | Optional | Use this param instead of previous if you need to set quantity more than 1 of attributes. If use both in POST request this will overwrite the previous list (under param attributes). | List<AttributesWithQuantity> getAttributesWithQuantity() | setAttributesWithQuantity(List<AttributesWithQuantity> attributesWithQuantity) |
| `NearbyAmenities` | [`List<NearbyAmenity>`](../../doc/models/nearby-amenity.md) | Optional | List of Nearby Attributes models. Check allowed values in Appendix. | List<NearbyAmenity> getNearbyAmenities() | setNearbyAmenities(List<NearbyAmenity> nearbyAmenities) |
| `PropertyType` | [`PropertyTypesEnum`](../../doc/models/property-types-enum.md) | Required | - | PropertyTypesEnum getPropertyType() | setPropertyType(PropertyTypesEnum propertyType) |
| `BedroomConfiguration` | [`BedroomConfiguration`](../../doc/models/bedroom-configuration.md) | Optional | - | BedroomConfiguration getBedroomConfiguration() | setBedroomConfiguration(BedroomConfiguration bedroomConfiguration) |
| `CheckInTime` | `String` | Optional | Time of Check in (HH:MM:SS) | String getCheckInTime() | setCheckInTime(String checkInTime) |
| `CheckInToTime` | `String` | Optional | Time Check in to (HH:MM:SS) | String getCheckInToTime() | setCheckInToTime(String checkInToTime) |
| `CheckOutTime` | `String` | Optional | Time of Check out (HH:MM:SS) | String getCheckOutTime() | setCheckOutTime(String checkOutTime) |
| `Currency` | `String` | Required | Property currency. ISO 4217 code is required. | String getCurrency() | setCurrency(String currency) |
| `Policy` | [`Policy`](../../doc/models/policy.md) | Optional | - | Policy getPolicy() | setPolicy(Policy policy) |
| `Location` | [`Location`](../../doc/models/location.md) | Optional | - | Location getLocation() | setLocation(Location location) |
| `SupportedLosRates` | `boolean` | Required | If true - means that the property supports only LOS rates. So daily rates can not be sent and updated. Default is false. | boolean getSupportedLosRates() | setSupportedLosRates(boolean supportedLosRates) |
| `TaxNumber` | `String` | Optional | Tax number for the property | String getTaxNumber() | setTaxNumber(String taxNumber) |
| `MultiUnit` | [`MultiUnitEnum`](../../doc/models/multi-unit-enum.md) | Optional | Enum for product multyunit type. | MultiUnitEnum getMultiUnit() | setMultiUnit(MultiUnitEnum multiUnit) |
| `ParentId` | `Integer` | Optional | This fields should not be used unless your property is not MLT (check field multiunit). In this case you must set owner (parent) id property to which this property will belong. Also you can not update this property. | Integer getParentId() | setParentId(Integer parentId) |
| `PropertyRating` | `Double` | Optional | Property rating. A floating point number representing the aggregate property rating (0-5). | Double getPropertyRating() | setPropertyRating(Double propertyRating) |
| `RatingNumber` | `Integer` | Optional | Rating Number. Number of ratings that the property has (Non-negative integer) | Integer getRatingNumber() | setRatingNumber(Integer ratingNumber) |
| `MinimumRentingAge` | `Integer` | Optional | Minimum renting age. If you want to remove previously added value - send value 0. | Integer getMinimumRentingAge() | setMinimumRentingAge(Integer minimumRentingAge) |
| `BasePrice` | `Double` | Optional | Display value that channels use when guests search without dates. Min value = 10 USD; Max value = 25,000 USD | Double getBasePrice() | setBasePrice(Double basePrice) |
| `BuiltDate` | `LocalDateTime` | Optional | Date when property were built. Format YYYY-MM-DD HH:MM:SS | LocalDateTime getBuiltDate() | setBuiltDate(LocalDateTime builtDate) |
| `RenovatingDate` | `LocalDateTime` | Optional | Date when property last time were renovated. Format YYYY-MM-DD HH:MM:SS | LocalDateTime getRenovatingDate() | setRenovatingDate(LocalDateTime renovatingDate) |
| `RentingDate` | `LocalDateTime` | Optional | Date from when property is rented. Format YYYY-MM-DD HH:MM:SS | LocalDateTime getRentingDate() | setRentingDate(LocalDateTime rentingDate) |
| `HostLocation` | `Boolean` | Optional | Indicator, whether the host is living in the property or not. Default is FALSE. | Boolean getHostLocation() | setHostLocation(Boolean hostLocation) |
| `KeyCollection` | [`KeyCollection`](../../doc/models/key-collection.md) | Optional | - | KeyCollection getKeyCollection() | setKeyCollection(KeyCollection keyCollection) |
| `NeighborhoodOverview` | [`Text`](../../doc/models/text.md) | Optional | - | Text getNeighborhoodOverview() | setNeighborhoodOverview(Text neighborhoodOverview) |
| `About` | [`Text`](../../doc/models/text.md) | Optional | - | Text getAbout() | setAbout(Text about) |

## Example (as JSON)

```json
{
  "name": null,
  "rooms": null,
  "bathrooms": null,
  "persons": null,
  "propertyType": "PCT101",
  "currency": null,
  "supportedLosRates": null
}
```

