
# Property List Request

Request Model for list of properties

## Structure

`PropertyListRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Data` | `List<Integer>` | Required | List of property IDs (ID from BookingPal system). At least one ID need to be present. | List<Integer> getData() | setData(List<Integer> data) |

## Example (as JSON)

```json
{
  "data": [
    1235124636,
    1235124637
  ]
}
```

