
# Fee Tax Mandatory

## Structure

`FeeTaxMandatory`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `IsFeeMandatory` | `boolean` | Required | Used in BookingPal validator. Info does property require any fee or not. Default value is TRUE. This setup can be overridden on property level with different API call, which is stronger. | boolean getIsFeeMandatory() | setIsFeeMandatory(boolean isFeeMandatory) |
| `IsTaxMandatory` | `boolean` | Required | Used in BookingPal validator. Info does property require any tax or not. Default value is TRUE. This setup can be overridden on property level with different API call, which is stronger. | boolean getIsTaxMandatory() | setIsTaxMandatory(boolean isTaxMandatory) |

## Example (as JSON)

```json
{
  "isFeeMandatory": true,
  "isTaxMandatory": true
}
```

