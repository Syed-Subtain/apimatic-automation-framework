
# Request to Book Test Request

## Structure

`RequestToBookTestRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Data` | [`FunctionsRequestToBookTest`](../../doc/models/functions-request-to-book-test.md) | Required | - | FunctionsRequestToBookTest getData() | setData(FunctionsRequestToBookTest data) |

## Example (as JSON)

```json
{
  "data": {
    "action": "RESERVATION_REQUEST_VOIDED",
    "productId": 1235124634
  }
}
```

