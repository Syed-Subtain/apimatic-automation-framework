
# Split Payment

## Structure

`SplitPayment`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `DepositType` | [`DepositTypeEnum`](../../doc/models/deposit-type-enum.md) | Required | First payment deposit type. | DepositTypeEnum getDepositType() | setDepositType(DepositTypeEnum depositType) |
| `Value` | `double` | Required | First payment value | double getValue() | setValue(double value) |
| `SecondPaymentDays` | `int` | Required | Number of days before check-in when second payment is required. | int getSecondPaymentDays() | setSecondPaymentDays(int secondPaymentDays) |

## Example (as JSON)

```json
{
  "depositType": "FLAT",
  "value": 4,
  "secondPaymentDays": 30
}
```

