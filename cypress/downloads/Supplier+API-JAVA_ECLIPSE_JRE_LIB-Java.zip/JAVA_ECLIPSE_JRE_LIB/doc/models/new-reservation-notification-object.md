
# New Reservation Notification Object

## Structure

`NewReservationNotificationObject`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `ReservationId` | `String` | Required | Id of the reservation in BookingPal | String getReservationId() | setReservationId(String reservationId) |
| `ProductId` | `String` | Required | Id of the product in BookingPal | String getProductId() | setProductId(String productId) |
| `SupplierId` | `String` | Required | Id of the property manager | String getSupplierId() | setSupplierId(String supplierId) |
| `ChannelName` | `String` | Required | Channel name | String getChannelName() | setChannelName(String channelName) |
| `ConfirmationId` | `String` | Required | Channel confirmation code | String getConfirmationId() | setConfirmationId(String confirmationId) |
| `UniqueKey` | `String` | Required | Unique code to identify that the request is from BookingPal. This value is unique for every PMS (and it will be different in different environments). | String getUniqueKey() | setUniqueKey(String uniqueKey) |
| `NewState` | [`ReservationStateEnum`](../../doc/models/reservation-state-enum.md) | Required | Possible Reservation states | ReservationStateEnum getNewState() | setNewState(ReservationStateEnum newState) |
| `CustomerName` | `String` | Required | Guest full name (in format firstName lastName) | String getCustomerName() | setCustomerName(String customerName) |
| `FromDate` | `LocalDate` | Required | Reservation date from. Date is in format "yyyy-MM-dd" | LocalDate getFromDate() | setFromDate(LocalDate fromDate) |
| `ToDate` | `LocalDate` | Required | Reservation date to. Date is in format "yyyy-MM-dd" | LocalDate getToDate() | setToDate(LocalDate toDate) |
| `Adult` | `int` | Required | number of adults | int getAdult() | setAdult(int adult) |
| `Child` | `int` | Required | number of children | int getChild() | setChild(int child) |
| `Address` | `String` | Optional | Guest address | String getAddress() | setAddress(String address) |
| `City` | `String` | Optional | Guest city | String getCity() | setCity(String city) |
| `Zip` | `String` | Optional | Guest zip code | String getZip() | setZip(String zip) |
| `Country` | `String` | Optional | Guest country | String getCountry() | setCountry(String country) |
| `State` | `String` | Optional | Guest state | String getState() | setState(String state) |
| `Email` | `String` | Required | Guest email | String getEmail() | setEmail(String email) |
| `Phone` | `String` | Optional | Guest phone | String getPhone() | setPhone(String phone) |
| `Notes` | `String` | Optional | Guest notes | String getNotes() | setNotes(String notes) |
| `CreditCardType` | [`CreditCardListEnum`](../../doc/models/credit-card-list-enum.md) | Optional | - | CreditCardListEnum getCreditCardType() | setCreditCardType(CreditCardListEnum creditCardType) |
| `CreditCardNumber` | `String` | Optional | Credit card number | String getCreditCardNumber() | setCreditCardNumber(String creditCardNumber) |
| `CreditCardExpirationMonth` | `String` | Optional | Credit card expiration month | String getCreditCardExpirationMonth() | setCreditCardExpirationMonth(String creditCardExpirationMonth) |
| `CreditCardExpirationYear` | `String` | Optional | Credit card expiration yea | String getCreditCardExpirationYear() | setCreditCardExpirationYear(String creditCardExpirationYear) |
| `CreditCardCid` | `String` | Optional | Credit card cid | String getCreditCardCid() | setCreditCardCid(String creditCardCid) |
| `Total` | `double` | Required | Best available rate (This is the total value that guests will pay, including rate, fees, taxes, and all commissions. ) | double getTotal() | setTotal(double total) |
| `Fees` | [`List<ReservationFeeNotificationModel>`](../../doc/models/reservation-fee-notification-model.md) | Optional | List of models | List<ReservationFeeNotificationModel> getFees() | setFees(List<ReservationFeeNotificationModel> fees) |
| `Taxes` | [`List<ReservationTaxNotificationModel>`](../../doc/models/reservation-tax-notification-model.md) | Optional | List of models | List<ReservationTaxNotificationModel> getTaxes() | setTaxes(List<ReservationTaxNotificationModel> taxes) |
| `Commission` | [`ReservationCommissionsNotificationModel`](../../doc/models/reservation-commissions-notification-model.md) | Optional | - | ReservationCommissionsNotificationModel getCommission() | setCommission(ReservationCommissionsNotificationModel commission) |
| `Rate` | [`ReservationRateNotifcationModel`](../../doc/models/reservation-rate-notifcation-model.md) | Optional | - | ReservationRateNotifcationModel getRate() | setRate(ReservationRateNotifcationModel rate) |

## Example (as JSON)

```json
{
  "reservationId": "107",
  "productId": "1234816374",
  "supplierId": "3731837",
  "channelName": "Airbnb",
  "confirmationId": "dasdasd",
  "uniqueKey": null,
  "newState": "Cancelled",
  "customerName": "John Smith",
  "fromDate": null,
  "toDate": null,
  "adult": 2,
  "child": 0,
  "email": "andrewtesttest222@gmail.com",
  "total": null
}
```

