
# Message Request From Supplier

## Structure

`MessageRequestFromSupplier`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `ThreadId` | `int` | Required | ID of thread | int getThreadId() | setThreadId(int threadId) |
| `Message` | `String` | Required | Message text | String getMessage() | setMessage(String message) |

## Example (as JSON)

```json
{
  "threadId": 5656,
  "message": "new message"
}
```

