
# Feesand Taxes

## Structure

`FeesandTaxes`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `ProductId` | `int` | Required | ID of the product | int getProductId() | setProductId(int productId) |
| `Fees` | [`List<Fee>`](../../doc/models/fee.md) | Optional | List of models | List<Fee> getFees() | setFees(List<Fee> fees) |
| `Taxes` | [`List<Taxes>`](../../doc/models/taxes.md) | Optional | List of models | List<Taxes> getTaxes() | setTaxes(List<Taxes> taxes) |

## Example (as JSON)

```json
{
  "productId": 98,
  "fees": null,
  "taxes": null
}
```

