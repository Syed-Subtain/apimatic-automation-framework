
# Thread

## Structure

`Thread`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Id` | `int` | Required | Thread ID | int getId() | setId(int id) |
| `LastMessageSentAt` | `String` | Required | Time when last message was sent | String getLastMessageSentAt() | setLastMessageSentAt(String lastMessageSentAt) |
| `LastMessageText` | `String` | Required | Last message text | String getLastMessageText() | setLastMessageText(String lastMessageText) |
| `ChannelThreadId` | `String` | Optional | Channel thread ID | String getChannelThreadId() | setChannelThreadId(String channelThreadId) |
| `ChannelName` | `String` | Required | Channel from where come reservation | String getChannelName() | setChannelName(String channelName) |
| `ChannelABB` | [`ChannelABBEnum`](../../doc/models/channel-abb-enum.md) | Required | - | ChannelABBEnum getChannelABB() | setChannelABB(ChannelABBEnum channelABB) |
| `GuestName` | `String` | Required | Name of guest | String getGuestName() | setGuestName(String guestName) |
| `GuestEmailAddress` | `String` | Optional | Email of guest | String getGuestEmailAddress() | setGuestEmailAddress(String guestEmailAddress) |
| `ProductId` | `int` | Required | ID of product in BookingPal database | int getProductId() | setProductId(int productId) |
| `ReservationId` | `Integer` | Optional | ID of reservation | Integer getReservationId() | setReservationId(Integer reservationId) |
| `DateFrom` | `LocalDate` | Required | Start date of reservation. Date is in format "yyyy-MM-dd" | LocalDate getDateFrom() | setDateFrom(LocalDate dateFrom) |
| `DateTo` | `LocalDate` | Required | End date of reservation. Date is in format "yyyy-MM-dd" | LocalDate getDateTo() | setDateTo(LocalDate dateTo) |

## Example (as JSON)

```json
{
  "id": null,
  "lastMessageSentAt": null,
  "lastMessageText": null,
  "channelName": null,
  "channelABB": "BKG",
  "guestName": null,
  "productId": null,
  "dateFrom": null,
  "dateTo": null
}
```

