
# Fee Type Enum

## Enumeration

`FeeTypeEnum`

## Fields

| Name |
|  --- |
| `GENERAL` |
| `PETFEE` |
| `DEPOSIT` |

## Example

```
GENERAL
```

