
# Reservation Push Response

This is response which the BookingPal expect to get on from PMS on push POST request for create/cancel reservation

## Structure

`ReservationPushResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `AltId` | `String` | Required | Id of reservation in your system | String getAltId() | setAltId(String altId) |
| `IsError` | `boolean` | Required | Did you have error during processing of request (true) or not (false) | boolean getIsError() | setIsError(boolean isError) |
| `Code` | `String` | Required | Code of message | String getCode() | setCode(String code) |
| `Message` | `String` | Required | Text info message. If you have any error please put here detail message. | String getMessage() | setMessage(String message) |

## Example (as JSON)

```json
{
  "altId": "45717",
  "is_error": false,
  "code": "",
  "message": "Reservation is processed."
}
```

