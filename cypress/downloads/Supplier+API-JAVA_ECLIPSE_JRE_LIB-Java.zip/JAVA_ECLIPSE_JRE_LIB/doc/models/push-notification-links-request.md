
# Push Notification Links Request

## Structure

`PushNotificationLinksRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Data` | [`PushNotificationLinksModel`](../../doc/models/push-notification-links-model.md) | Required | Model for push notification links | PushNotificationLinksModel getData() | setData(PushNotificationLinksModel data) |

## Example (as JSON)

```json
{
  "data": {
    "bookLink": "https://newreservationnotification.link",
    "cancelLink": "https://cancelreservation.link",
    "asyncPush": "https://asyncpush.link",
    "requestToBook": "https://requestToBook.link",
    "useJson": true
  }
}
```

