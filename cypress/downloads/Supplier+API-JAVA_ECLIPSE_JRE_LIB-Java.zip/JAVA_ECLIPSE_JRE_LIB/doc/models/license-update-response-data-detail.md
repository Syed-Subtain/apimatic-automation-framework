
# License Update Response Data Detail

## Structure

`LicenseUpdateResponseDataDetail`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Meta` | [`List<LicenseRequirementMeta>`](../../doc/models/license-requirement-meta.md) | Optional | - | List<LicenseRequirementMeta> getMeta() | setMeta(List<LicenseRequirementMeta> meta) |
| `Data` | [`List<LicenseResponseIndicatorData>`](../../doc/models/license-response-indicator-data.md) | Optional | - | List<LicenseResponseIndicatorData> getData() | setData(List<LicenseResponseIndicatorData> data) |
| `Warnings` | `List<String>` | Optional | List of warning messages | List<String> getWarnings() | setWarnings(List<String> warnings) |
| `Errors` | `List<String>` | Optional | List of error messages | List<String> getErrors() | setErrors(List<String> errors) |

## Example (as JSON)

```json
{
  "meta": null,
  "data": null,
  "warnings": null,
  "errors": null
}
```

