
# Key Collection

## Structure

`KeyCollection`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Type` | `String` | Required | required string where accepted strings = {"primary"} | String getType() | setType(String type) |
| `CheckInMethod` | [`KeyCollectionCheckinmethodEnum`](../../doc/models/key-collection-checkinmethod-enum.md) | Required | - | KeyCollectionCheckinmethodEnum getCheckInMethod() | setCheckInMethod(KeyCollectionCheckinmethodEnum checkInMethod) |
| `AdditionalInfo` | [`KeyCollectionadditionalinformation`](../../doc/models/key-collectionadditionalinformation.md) | Required | - | KeyCollectionadditionalinformation getAdditionalInfo() | setAdditionalInfo(KeyCollectionadditionalinformation additionalInfo) |

## Example (as JSON)

```json
{
  "type": "primary",
  "checkInMethod": "doorman",
  "additionalInfo": {
    "instruction": {
      "how": "how example",
      "when": "when example"
    }
  }
}
```

