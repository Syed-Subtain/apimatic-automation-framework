
# License Requirement Response

## Structure

`LicenseRequirementResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Message` | `String` | Required | text info message | String getMessage() | setMessage(String message) |
| `ErrorMessage` | `List<String>` | Required | List of error messages | List<String> getErrorMessage() | setErrorMessage(List<String> errorMessage) |
| `IsError` | `boolean` | Required | Is error (default = false) | boolean getIsError() | setIsError(boolean isError) |
| `Code` | `String` | Required | Code of message | String getCode() | setCode(String code) |
| `Data` | [`List<LicenseReqData>`](../../doc/models/license-req-data.md) | Required | License Requirements Data | List<LicenseReqData> getData() | setData(List<LicenseReqData> data) |

## Example (as JSON)

```json
{
  "message": "message0",
  "errorMessage": [
    "errorMessage2",
    "errorMessage3",
    "errorMessage4"
  ],
  "is_error": false,
  "code": "code8",
  "data": [
    {
      "productId": null,
      "licenseRequirementResponse": null
    },
    {
      "productId": null,
      "licenseRequirementResponse": null
    }
  ]
}
```

