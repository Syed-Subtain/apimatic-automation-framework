
# License Data

## Structure

`LicenseData`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `ContentData` | [`List<LicenseDataContent>`](../../doc/models/license-data-content.md) | Required | - | List<LicenseDataContent> getContentData() | setContentData(List<LicenseDataContent> contentData) |
| `VariantId` | `String` | Required | Variant ID | String getVariantId() | setVariantId(String variantId) |

## Example (as JSON)

```json
{
  "contentData": [
    {
      "name": null,
      "value": null
    },
    {
      "name": null,
      "value": null
    },
    {
      "name": null,
      "value": null
    }
  ],
  "variantId": "variantId0"
}
```

