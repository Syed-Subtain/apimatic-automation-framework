
# Located Parking Type Enum

## Enumeration

`LocatedParkingTypeEnum`

## Fields

| Name |
|  --- |
| `OnSite` |
| `Nearby` |

## Example

```
OnSite
```

