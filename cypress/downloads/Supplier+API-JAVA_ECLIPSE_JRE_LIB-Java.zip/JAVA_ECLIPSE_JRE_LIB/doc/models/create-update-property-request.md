
# Create Update Property Request

Request for Create or Update of Product

## Structure

`CreateUpdatePropertyRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Data` | [`Property`](../../doc/models/property.md) | Required | - | Property getData() | setData(Property data) |

## Example (as JSON)

```json
{
  "data": {
    "name": null,
    "rooms": null,
    "bathrooms": null,
    "persons": null,
    "propertyType": "PCT101",
    "currency": null,
    "supportedLosRates": null
  }
}
```

