
# Functions Request to Book Test

## Structure

`FunctionsRequestToBookTest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Action` | [`RequestToBookTestActionEnum`](../../doc/models/request-to-book-test-action-enum.md) | Required | Allowed values for request to book Test action | RequestToBookTestActionEnum getAction() | setAction(RequestToBookTestActionEnum action) |
| `ProductId` | `int` | Required | Product id for test request to book | int getProductId() | setProductId(int productId) |

## Example (as JSON)

```json
{
  "action": "RESERVATION_REQUEST_VOIDED",
  "productId": 1235124634
}
```

