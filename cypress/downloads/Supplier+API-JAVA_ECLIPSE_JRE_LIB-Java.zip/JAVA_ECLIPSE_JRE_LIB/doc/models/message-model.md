
# Message Model

Model for one message

## Structure

`MessageModel`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Id` | `Integer` | Optional | Id of message | Integer getId() | setId(Integer id) |
| `Message` | `String` | Required | Message text | String getMessage() | setMessage(String message) |
| `CreatedAt` | `String` | Required | Time when message created | String getCreatedAt() | setCreatedAt(String createdAt) |
| `User` | [`UserEnum`](../../doc/models/user-enum.md) | Required | - | UserEnum getUser() | setUser(UserEnum user) |
| `ChannelMessageId` | `String` | Optional | Channel Message ID | String getChannelMessageId() | setChannelMessageId(String channelMessageId) |

## Example (as JSON)

```json
{
  "id": 68233,
  "message": "Test message",
  "createdAt": "2019-11-25T12:32:39.000+0000",
  "user": "PROPERTY_MANAGER",
  "channelMessageId": "2221139318748986368"
}
```

