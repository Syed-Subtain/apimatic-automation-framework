
# LOS Rates Product

Model for product LOS rates

## Structure

`LOSRatesProduct`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `ProductId` | `int` | Required | ID of the product | int getProductId() | setProductId(int productId) |
| `LosRates` | [`List<LOSRate>`](../../doc/models/los-rate.md) | Required | List of models. Max size array for LosRates object 1000 | List<LOSRate> getLosRates() | setLosRates(List<LOSRate> losRates) |

## Example (as JSON)

```json
{
  "productId": 98,
  "losRates": [
    {
      "checkInDate": "2016-03-13",
      "maxGuests": 113,
      "losValue": [
        49.07,
        49.08
      ],
      "currency": null
    },
    {
      "checkInDate": "2016-03-13",
      "maxGuests": 112,
      "losValue": [
        49.08,
        49.09,
        49.1
      ],
      "currency": null
    },
    {
      "checkInDate": "2016-03-13",
      "maxGuests": 111,
      "losValue": [
        49.09
      ],
      "currency": null
    }
  ]
}
```

