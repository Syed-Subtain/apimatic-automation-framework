
# Post New Message for Specific Thread Request

## Structure

`PostNewMessageForSpecificThreadRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Data` | [`MessageRequestFromSupplier`](../../doc/models/message-request-from-supplier.md) | Required | - | MessageRequestFromSupplier getData() | setData(MessageRequestFromSupplier data) |

## Example (as JSON)

```json
{
  "data": {
    "threadId": 5656,
    "message": "New message"
  }
}
```

