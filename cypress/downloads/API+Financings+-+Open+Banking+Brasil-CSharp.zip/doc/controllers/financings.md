# Financings

```csharp
FinancingsController financingsController = client.FinancingsController;
```

## Class Name

`FinancingsController`

## Methods

* [Financings Get Contracts](../../doc/controllers/financings.md#financings-get-contracts)
* [Financings Get Contracts Contract Id](../../doc/controllers/financings.md#financings-get-contracts-contract-id)
* [Financings Get Contracts Contract Id Warranties](../../doc/controllers/financings.md#financings-get-contracts-contract-id-warranties)
* [Financings Get Contracts Contract Id Scheduled Instalments](../../doc/controllers/financings.md#financings-get-contracts-contract-id-scheduled-instalments)
* [Financings Get Contracts Contract Id Payments](../../doc/controllers/financings.md#financings-get-contracts-contract-id-payments)


# Financings Get Contracts

Método para obter a lista de contratos de empréstimo mantidos pelo cliente na instituição transmissora e para os quais ele tenha fornecido consentimento

```csharp
FinancingsGetContractsAsync(
    string authorization,
    string xFapiAuthDate,
    string xFapiCustomerIpAddress = null,
    string xFapiInteractionId = null,
    string xCustomerUserAgent = null,
    int? page = 1,
    int? pageSize = 25,
    string paginationKey = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `authorization` | `string` | Header, Required | Cabeçalho HTTP padrão. Permite que as credenciais sejam fornecidas dependendo do tipo de recurso solicitado<br>**Constraints**: *Maximum Length*: `2048`, *Pattern*: `[\w\W\s]*` |
| `xFapiAuthDate` | `string` | Header, Required | Data em que o usuário logou pela última vez com o receptor. Representada de acordo com a [RFC7231](https://tools.ietf.org/html/rfc7231).Exemplo: Sun, 10 Sep 2017 19:43:31 UTC<br>**Constraints**: *Minimum Length*: `29`, *Maximum Length*: `29`, *Pattern*: `^(Mon\|Tue\|Wed\|Thu\|Fri\|Sat\|Sun), \d{2} (Jan\|Feb\|Mar\|Apr\|May\|Jun\|Jul\|Aug\|Sep\|Oct\|Nov\|Dec) \d{4} \d{2}:\d{2}:\d{2} (GMT\|UTC)$` |
| `xFapiCustomerIpAddress` | `string` | Header, Optional | O endereço IP do usuário se estiver atualmente logado com o receptor.<br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `100`, *Pattern*: `[\w\W\s]*` |
| `xFapiInteractionId` | `string` | Header, Optional | Um UID [RFC4122](https://tools.ietf.org/html/rfc4122) usado como um ID de correlação. Se fornecido, o transmissor deve "reproduzir" esse valor no cabeçalho de resposta.<br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `100`, *Pattern*: `^[a-zA-Z0-9][a-zA-Z0-9\-]{0,99}$` |
| `xCustomerUserAgent` | `string` | Header, Optional | Indica o user-agent que o usuário utiliza.<br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `100`, *Pattern*: `[\w\W\s]*` |
| `page` | `int?` | Query, Optional | Número da página que está sendo requisitada (o valor da primeira página é 1).<br>**Default**: `1`<br>**Constraints**: `>= 1`, `<= 2147483647` |
| `pageSize` | `int?` | Query, Optional | Quantidade total de registros por páginas.<br>**Default**: `25`<br>**Constraints**: `>= 1`, `<= 1000` |
| `paginationKey` | `string` | Query, Optional | Identificador de rechamada, utilizado para evitar a contagem de chamadas ao endpoint durante a paginação.<br>**Constraints**: *Maximum Length*: `2048`, *Pattern*: `[\w\W\s]*` |

## Requires scope

`OPENID`

## Response Type

[`Task<Models.ResponseFinancingsContractList>`](../../doc/models/response-financings-contract-list.md)

## Example Usage

```csharp
string authorization = "Authorization8";
string xFapiAuthDate = "x-fapi-auth-date0";
int? page = 1;
int? pageSize = 25;

try
{
    ResponseFinancingsContractList result = await financingsController.FinancingsGetContractsAsync(authorization, xFapiAuthDate, null, null, null, page, pageSize, null);
}
catch (ApiException e){};
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | A requisição foi malformada, omitindo atributos obrigatórios, seja no payload ou através de atributos na URL. | [`ResponseErrorWithAbleAdditionalPropertiesException`](../../doc/models/response-error-with-able-additional-properties-exception.md) |
| 401 | Cabeçalho de autenticação ausente/inválido ou token inválido | [`ResponseErrorWithAbleAdditionalPropertiesException`](../../doc/models/response-error-with-able-additional-properties-exception.md) |
| 403 | O token tem escopo incorreto ou uma política de segurança foi violada | [`ResponseErrorWithAbleAdditionalPropertiesException`](../../doc/models/response-error-with-able-additional-properties-exception.md) |
| 404 | O recurso solicitado não existe ou não foi implementado | [`ResponseErrorWithAbleAdditionalPropertiesException`](../../doc/models/response-error-with-able-additional-properties-exception.md) |
| 405 | O consumidor tentou acessar o recurso com um método não suportado | [`ResponseErrorWithAbleAdditionalPropertiesException`](../../doc/models/response-error-with-able-additional-properties-exception.md) |
| 406 | A solicitação continha um cabeçalho Accept diferente dos tipos de mídia permitidos ou um conjunto de caracteres diferente de UTF-8 | [`ResponseErrorWithAbleAdditionalPropertiesException`](../../doc/models/response-error-with-able-additional-properties-exception.md) |
| 422 | A sintaxe da requisição esta correta, mas não foi possível processar as instruções presentes. | [`ResponseErrorWithAbleAdditionalPropertiesException`](../../doc/models/response-error-with-able-additional-properties-exception.md) |
| 423 | Locked | [`ResponseErrorWithAbleAdditionalPropertiesException`](../../doc/models/response-error-with-able-additional-properties-exception.md) |
| 429 | A operação foi recusada, pois muitas solicitações foram feitas dentro de um determinado período ou o limite global de requisições concorrentes foi atingido | [`ResponseErrorWithAbleAdditionalPropertiesException`](../../doc/models/response-error-with-able-additional-properties-exception.md) |
| 500 | Ocorreu um erro no gateway da API ou no microsserviço | [`ResponseErrorWithAbleAdditionalPropertiesException`](../../doc/models/response-error-with-able-additional-properties-exception.md) |
| 504 | GATEWAY TIMEOUT - A requisição não foi atendida dentro do tempo limite estabelecido | [`ResponseErrorWithAbleAdditionalPropertiesException`](../../doc/models/response-error-with-able-additional-properties-exception.md) |
| 529 | O site está sobrecarregado e a operação foi recusada, pois foi atingido o limite máximo de TPS global, neste momento. | [`ResponseErrorWithAbleAdditionalPropertiesException`](../../doc/models/response-error-with-able-additional-properties-exception.md) |
| Default | Erro inesperado. | [`ResponseErrorWithAbleAdditionalPropertiesException`](../../doc/models/response-error-with-able-additional-properties-exception.md) |


# Financings Get Contracts Contract Id

Método para obter os dados do contrato de financiamento identificado por contractId mantido pelo cliente na instituição transmissora

```csharp
FinancingsGetContractsContractIdAsync(
    string contractId,
    string authorization,
    string xFapiAuthDate = null,
    string xFapiCustomerIpAddress = null,
    string xFapiInteractionId = null,
    string xCustomerUserAgent = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `contractId` | `string` | Template, Required | Identificador do contrato para todos os tipos de operação de crédito.<br>**Constraints**: *Maximum Length*: `100`, *Pattern*: `^[a-zA-Z0-9][a-zA-Z0-9-]{0,99}$` |
| `authorization` | `string` | Header, Required | Cabeçalho HTTP padrão. Permite que as credenciais sejam fornecidas dependendo do tipo de recurso solicitado<br>**Constraints**: *Maximum Length*: `2048`, *Pattern*: `[\w\W\s]*` |
| `xFapiAuthDate` | `string` | Header, Optional | Data em que o usuário logou pela última vez com o receptor. Representada de acordo com a [RFC7231](https://tools.ietf.org/html/rfc7231).Exemplo: Sun, 10 Sep 2017 19:43:31 UTC<br>**Constraints**: *Minimum Length*: `29`, *Maximum Length*: `29`, *Pattern*: `^(Mon\|Tue\|Wed\|Thu\|Fri\|Sat\|Sun), \d{2} (Jan\|Feb\|Mar\|Apr\|May\|Jun\|Jul\|Aug\|Sep\|Oct\|Nov\|Dec) \d{4} \d{2}:\d{2}:\d{2} (GMT\|UTC)$` |
| `xFapiCustomerIpAddress` | `string` | Header, Optional | O endereço IP do usuário se estiver atualmente logado com o receptor.<br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `100`, *Pattern*: `[\w\W\s]*` |
| `xFapiInteractionId` | `string` | Header, Optional | Um UID [RFC4122](https://tools.ietf.org/html/rfc4122) usado como um ID de correlação. Se fornecido, o transmissor deve "reproduzir" esse valor no cabeçalho de resposta.<br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `100`, *Pattern*: `^[a-zA-Z0-9][a-zA-Z0-9\-]{0,99}$` |
| `xCustomerUserAgent` | `string` | Header, Optional | Indica o user-agent que o usuário utiliza.<br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `100`, *Pattern*: `[\w\W\s]*` |

## Requires scope

`OPENID`

## Response Type

[`Task<Models.ResponseFinancingsContract>`](../../doc/models/response-financings-contract.md)

## Example Usage

```csharp
string contractId = "contractId2";
string authorization = "Authorization8";

try
{
    ResponseFinancingsContract result = await financingsController.FinancingsGetContractsContractIdAsync(contractId, authorization, null, null, null, null);
}
catch (ApiException e){};
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | A requisição foi malformada, omitindo atributos obrigatórios, seja no payload ou através de atributos na URL. | [`ResponseErrorWithAbleAdditionalPropertiesException`](../../doc/models/response-error-with-able-additional-properties-exception.md) |
| 401 | Cabeçalho de autenticação ausente/inválido ou token inválido | [`ResponseErrorWithAbleAdditionalPropertiesException`](../../doc/models/response-error-with-able-additional-properties-exception.md) |
| 403 | O token tem escopo incorreto ou uma política de segurança foi violada | [`ResponseErrorWithAbleAdditionalPropertiesException`](../../doc/models/response-error-with-able-additional-properties-exception.md) |
| 404 | O recurso solicitado não existe ou não foi implementado | [`ResponseErrorWithAbleAdditionalPropertiesException`](../../doc/models/response-error-with-able-additional-properties-exception.md) |
| 405 | O consumidor tentou acessar o recurso com um método não suportado | [`ResponseErrorWithAbleAdditionalPropertiesException`](../../doc/models/response-error-with-able-additional-properties-exception.md) |
| 406 | A solicitação continha um cabeçalho Accept diferente dos tipos de mídia permitidos ou um conjunto de caracteres diferente de UTF-8 | [`ResponseErrorWithAbleAdditionalPropertiesException`](../../doc/models/response-error-with-able-additional-properties-exception.md) |
| 422 | A sintaxe da requisição esta correta, mas não foi possível processar as instruções presentes. | [`ResponseErrorWithAbleAdditionalPropertiesException`](../../doc/models/response-error-with-able-additional-properties-exception.md) |
| 423 | Locked | [`ResponseErrorWithAbleAdditionalPropertiesException`](../../doc/models/response-error-with-able-additional-properties-exception.md) |
| 429 | A operação foi recusada, pois muitas solicitações foram feitas dentro de um determinado período ou o limite global de requisições concorrentes foi atingido | [`ResponseErrorWithAbleAdditionalPropertiesException`](../../doc/models/response-error-with-able-additional-properties-exception.md) |
| 500 | Ocorreu um erro no gateway da API ou no microsserviço | [`ResponseErrorWithAbleAdditionalPropertiesException`](../../doc/models/response-error-with-able-additional-properties-exception.md) |
| 504 | GATEWAY TIMEOUT - A requisição não foi atendida dentro do tempo limite estabelecido | [`ResponseErrorWithAbleAdditionalPropertiesException`](../../doc/models/response-error-with-able-additional-properties-exception.md) |
| 529 | O site está sobrecarregado e a operação foi recusada, pois foi atingido o limite máximo de TPS global, neste momento. | [`ResponseErrorWithAbleAdditionalPropertiesException`](../../doc/models/response-error-with-able-additional-properties-exception.md) |
| Default | Erro inesperado. | [`ResponseErrorWithAbleAdditionalPropertiesException`](../../doc/models/response-error-with-able-additional-properties-exception.md) |


# Financings Get Contracts Contract Id Warranties

Método para obter a lista de garantias vinculadas ao contrato de financiamento identificado por contractId mantido pelo cliente na instituição transmissora

```csharp
FinancingsGetContractsContractIdWarrantiesAsync(
    string contractId,
    string authorization,
    int? page = 1,
    int? pageSize = 25,
    string xFapiAuthDate = null,
    string xFapiCustomerIpAddress = null,
    string xFapiInteractionId = null,
    string xCustomerUserAgent = null,
    string paginationKey = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `contractId` | `string` | Template, Required | Identificador do contrato para todos os tipos de operação de crédito.<br>**Constraints**: *Maximum Length*: `100`, *Pattern*: `^[a-zA-Z0-9][a-zA-Z0-9-]{0,99}$` |
| `authorization` | `string` | Header, Required | Cabeçalho HTTP padrão. Permite que as credenciais sejam fornecidas dependendo do tipo de recurso solicitado<br>**Constraints**: *Maximum Length*: `2048`, *Pattern*: `[\w\W\s]*` |
| `page` | `int?` | Query, Optional | Número da página que está sendo requisitada (o valor da primeira página é 1).<br>**Default**: `1`<br>**Constraints**: `>= 1`, `<= 2147483647` |
| `pageSize` | `int?` | Query, Optional | Quantidade total de registros por páginas.<br>**Default**: `25`<br>**Constraints**: `>= 1`, `<= 1000` |
| `xFapiAuthDate` | `string` | Header, Optional | Data em que o usuário logou pela última vez com o receptor. Representada de acordo com a [RFC7231](https://tools.ietf.org/html/rfc7231).Exemplo: Sun, 10 Sep 2017 19:43:31 UTC<br>**Constraints**: *Minimum Length*: `29`, *Maximum Length*: `29`, *Pattern*: `^(Mon\|Tue\|Wed\|Thu\|Fri\|Sat\|Sun), \d{2} (Jan\|Feb\|Mar\|Apr\|May\|Jun\|Jul\|Aug\|Sep\|Oct\|Nov\|Dec) \d{4} \d{2}:\d{2}:\d{2} (GMT\|UTC)$` |
| `xFapiCustomerIpAddress` | `string` | Header, Optional | O endereço IP do usuário se estiver atualmente logado com o receptor.<br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `100`, *Pattern*: `[\w\W\s]*` |
| `xFapiInteractionId` | `string` | Header, Optional | Um UID [RFC4122](https://tools.ietf.org/html/rfc4122) usado como um ID de correlação. Se fornecido, o transmissor deve "reproduzir" esse valor no cabeçalho de resposta.<br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `100`, *Pattern*: `^[a-zA-Z0-9][a-zA-Z0-9\-]{0,99}$` |
| `xCustomerUserAgent` | `string` | Header, Optional | Indica o user-agent que o usuário utiliza.<br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `100`, *Pattern*: `[\w\W\s]*` |
| `paginationKey` | `string` | Query, Optional | Identificador de rechamada, utilizado para evitar a contagem de chamadas ao endpoint durante a paginação.<br>**Constraints**: *Maximum Length*: `2048`, *Pattern*: `[\w\W\s]*` |

## Requires scope

`OPENID`

## Response Type

[`Task<Models.ResponseFinancingsWarranties>`](../../doc/models/response-financings-warranties.md)

## Example Usage

```csharp
string contractId = "contractId2";
string authorization = "Authorization8";
int? page = 1;
int? pageSize = 25;

try
{
    ResponseFinancingsWarranties result = await financingsController.FinancingsGetContractsContractIdWarrantiesAsync(contractId, authorization, page, pageSize, null, null, null, null, null);
}
catch (ApiException e){};
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | A requisição foi malformada, omitindo atributos obrigatórios, seja no payload ou através de atributos na URL. | [`ResponseErrorWithAbleAdditionalPropertiesException`](../../doc/models/response-error-with-able-additional-properties-exception.md) |
| 401 | Cabeçalho de autenticação ausente/inválido ou token inválido | [`ResponseErrorWithAbleAdditionalPropertiesException`](../../doc/models/response-error-with-able-additional-properties-exception.md) |
| 403 | O token tem escopo incorreto ou uma política de segurança foi violada | [`ResponseErrorWithAbleAdditionalPropertiesException`](../../doc/models/response-error-with-able-additional-properties-exception.md) |
| 404 | O recurso solicitado não existe ou não foi implementado | [`ResponseErrorWithAbleAdditionalPropertiesException`](../../doc/models/response-error-with-able-additional-properties-exception.md) |
| 405 | O consumidor tentou acessar o recurso com um método não suportado | [`ResponseErrorWithAbleAdditionalPropertiesException`](../../doc/models/response-error-with-able-additional-properties-exception.md) |
| 406 | A solicitação continha um cabeçalho Accept diferente dos tipos de mídia permitidos ou um conjunto de caracteres diferente de UTF-8 | [`ResponseErrorWithAbleAdditionalPropertiesException`](../../doc/models/response-error-with-able-additional-properties-exception.md) |
| 422 | A sintaxe da requisição esta correta, mas não foi possível processar as instruções presentes. | [`ResponseErrorWithAbleAdditionalPropertiesException`](../../doc/models/response-error-with-able-additional-properties-exception.md) |
| 423 | Locked | [`ResponseErrorWithAbleAdditionalPropertiesException`](../../doc/models/response-error-with-able-additional-properties-exception.md) |
| 429 | A operação foi recusada, pois muitas solicitações foram feitas dentro de um determinado período ou o limite global de requisições concorrentes foi atingido | [`ResponseErrorWithAbleAdditionalPropertiesException`](../../doc/models/response-error-with-able-additional-properties-exception.md) |
| 500 | Ocorreu um erro no gateway da API ou no microsserviço | [`ResponseErrorWithAbleAdditionalPropertiesException`](../../doc/models/response-error-with-able-additional-properties-exception.md) |
| 504 | GATEWAY TIMEOUT - A requisição não foi atendida dentro do tempo limite estabelecido | [`ResponseErrorWithAbleAdditionalPropertiesException`](../../doc/models/response-error-with-able-additional-properties-exception.md) |
| 529 | O site está sobrecarregado e a operação foi recusada, pois foi atingido o limite máximo de TPS global, neste momento. | [`ResponseErrorWithAbleAdditionalPropertiesException`](../../doc/models/response-error-with-able-additional-properties-exception.md) |
| Default | Erro inesperado. | [`ResponseErrorWithAbleAdditionalPropertiesException`](../../doc/models/response-error-with-able-additional-properties-exception.md) |


# Financings Get Contracts Contract Id Scheduled Instalments

Método para obter os dados do cronograma de parcelas do contrato de financiamento identificado por contractId mantido pelo cliente na instituição transmissora

```csharp
FinancingsGetContractsContractIdScheduledInstalmentsAsync(
    string contractId,
    string authorization,
    int? page = 1,
    int? pageSize = 25,
    string xFapiAuthDate = null,
    string xFapiCustomerIpAddress = null,
    string xFapiInteractionId = null,
    string xCustomerUserAgent = null,
    string paginationKey = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `contractId` | `string` | Template, Required | Identificador do contrato para todos os tipos de operação de crédito.<br>**Constraints**: *Maximum Length*: `100`, *Pattern*: `^[a-zA-Z0-9][a-zA-Z0-9-]{0,99}$` |
| `authorization` | `string` | Header, Required | Cabeçalho HTTP padrão. Permite que as credenciais sejam fornecidas dependendo do tipo de recurso solicitado<br>**Constraints**: *Maximum Length*: `2048`, *Pattern*: `[\w\W\s]*` |
| `page` | `int?` | Query, Optional | Número da página que está sendo requisitada (o valor da primeira página é 1).<br>**Default**: `1`<br>**Constraints**: `>= 1`, `<= 2147483647` |
| `pageSize` | `int?` | Query, Optional | Quantidade total de registros por páginas.<br>**Default**: `25`<br>**Constraints**: `>= 1`, `<= 1000` |
| `xFapiAuthDate` | `string` | Header, Optional | Data em que o usuário logou pela última vez com o receptor. Representada de acordo com a [RFC7231](https://tools.ietf.org/html/rfc7231).Exemplo: Sun, 10 Sep 2017 19:43:31 UTC<br>**Constraints**: *Minimum Length*: `29`, *Maximum Length*: `29`, *Pattern*: `^(Mon\|Tue\|Wed\|Thu\|Fri\|Sat\|Sun), \d{2} (Jan\|Feb\|Mar\|Apr\|May\|Jun\|Jul\|Aug\|Sep\|Oct\|Nov\|Dec) \d{4} \d{2}:\d{2}:\d{2} (GMT\|UTC)$` |
| `xFapiCustomerIpAddress` | `string` | Header, Optional | O endereço IP do usuário se estiver atualmente logado com o receptor.<br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `100`, *Pattern*: `[\w\W\s]*` |
| `xFapiInteractionId` | `string` | Header, Optional | Um UID [RFC4122](https://tools.ietf.org/html/rfc4122) usado como um ID de correlação. Se fornecido, o transmissor deve "reproduzir" esse valor no cabeçalho de resposta.<br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `100`, *Pattern*: `^[a-zA-Z0-9][a-zA-Z0-9\-]{0,99}$` |
| `xCustomerUserAgent` | `string` | Header, Optional | Indica o user-agent que o usuário utiliza.<br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `100`, *Pattern*: `[\w\W\s]*` |
| `paginationKey` | `string` | Query, Optional | Identificador de rechamada, utilizado para evitar a contagem de chamadas ao endpoint durante a paginação.<br>**Constraints**: *Maximum Length*: `2048`, *Pattern*: `[\w\W\s]*` |

## Requires scope

`OPENID`

## Response Type

[`Task<Models.ResponseFinancingsInstalments>`](../../doc/models/response-financings-instalments.md)

## Example Usage

```csharp
string contractId = "contractId2";
string authorization = "Authorization8";
int? page = 1;
int? pageSize = 25;

try
{
    ResponseFinancingsInstalments result = await financingsController.FinancingsGetContractsContractIdScheduledInstalmentsAsync(contractId, authorization, page, pageSize, null, null, null, null, null);
}
catch (ApiException e){};
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | A requisição foi malformada, omitindo atributos obrigatórios, seja no payload ou através de atributos na URL. | [`ResponseErrorWithAbleAdditionalPropertiesException`](../../doc/models/response-error-with-able-additional-properties-exception.md) |
| 401 | Cabeçalho de autenticação ausente/inválido ou token inválido | [`ResponseErrorWithAbleAdditionalPropertiesException`](../../doc/models/response-error-with-able-additional-properties-exception.md) |
| 403 | O token tem escopo incorreto ou uma política de segurança foi violada | [`ResponseErrorWithAbleAdditionalPropertiesException`](../../doc/models/response-error-with-able-additional-properties-exception.md) |
| 404 | O recurso solicitado não existe ou não foi implementado | [`ResponseErrorWithAbleAdditionalPropertiesException`](../../doc/models/response-error-with-able-additional-properties-exception.md) |
| 405 | O consumidor tentou acessar o recurso com um método não suportado | [`ResponseErrorWithAbleAdditionalPropertiesException`](../../doc/models/response-error-with-able-additional-properties-exception.md) |
| 406 | A solicitação continha um cabeçalho Accept diferente dos tipos de mídia permitidos ou um conjunto de caracteres diferente de UTF-8 | [`ResponseErrorWithAbleAdditionalPropertiesException`](../../doc/models/response-error-with-able-additional-properties-exception.md) |
| 422 | A sintaxe da requisição esta correta, mas não foi possível processar as instruções presentes. | [`ResponseErrorWithAbleAdditionalPropertiesException`](../../doc/models/response-error-with-able-additional-properties-exception.md) |
| 423 | Locked | [`ResponseErrorWithAbleAdditionalPropertiesException`](../../doc/models/response-error-with-able-additional-properties-exception.md) |
| 429 | A operação foi recusada, pois muitas solicitações foram feitas dentro de um determinado período ou o limite global de requisições concorrentes foi atingido | [`ResponseErrorWithAbleAdditionalPropertiesException`](../../doc/models/response-error-with-able-additional-properties-exception.md) |
| 500 | Ocorreu um erro no gateway da API ou no microsserviço | [`ResponseErrorWithAbleAdditionalPropertiesException`](../../doc/models/response-error-with-able-additional-properties-exception.md) |
| 504 | GATEWAY TIMEOUT - A requisição não foi atendida dentro do tempo limite estabelecido | [`ResponseErrorWithAbleAdditionalPropertiesException`](../../doc/models/response-error-with-able-additional-properties-exception.md) |
| 529 | O site está sobrecarregado e a operação foi recusada, pois foi atingido o limite máximo de TPS global, neste momento. | [`ResponseErrorWithAbleAdditionalPropertiesException`](../../doc/models/response-error-with-able-additional-properties-exception.md) |
| Default | Erro inesperado. | [`ResponseErrorWithAbleAdditionalPropertiesException`](../../doc/models/response-error-with-able-additional-properties-exception.md) |


# Financings Get Contracts Contract Id Payments

Método para obter os dados de pagamentos do contrato de financiamento identificado por contractId mantido pelo cliente na instituição transmissora

```csharp
FinancingsGetContractsContractIdPaymentsAsync(
    string contractId,
    string authorization,
    int? page = 1,
    int? pageSize = 25,
    string xFapiAuthDate = null,
    string xFapiCustomerIpAddress = null,
    string xFapiInteractionId = null,
    string xCustomerUserAgent = null,
    string paginationKey = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `contractId` | `string` | Template, Required | Identificador do contrato para todos os tipos de operação de crédito.<br>**Constraints**: *Maximum Length*: `100`, *Pattern*: `^[a-zA-Z0-9][a-zA-Z0-9-]{0,99}$` |
| `authorization` | `string` | Header, Required | Cabeçalho HTTP padrão. Permite que as credenciais sejam fornecidas dependendo do tipo de recurso solicitado<br>**Constraints**: *Maximum Length*: `2048`, *Pattern*: `[\w\W\s]*` |
| `page` | `int?` | Query, Optional | Número da página que está sendo requisitada (o valor da primeira página é 1).<br>**Default**: `1`<br>**Constraints**: `>= 1`, `<= 2147483647` |
| `pageSize` | `int?` | Query, Optional | Quantidade total de registros por páginas.<br>**Default**: `25`<br>**Constraints**: `>= 1`, `<= 1000` |
| `xFapiAuthDate` | `string` | Header, Optional | Data em que o usuário logou pela última vez com o receptor. Representada de acordo com a [RFC7231](https://tools.ietf.org/html/rfc7231).Exemplo: Sun, 10 Sep 2017 19:43:31 UTC<br>**Constraints**: *Minimum Length*: `29`, *Maximum Length*: `29`, *Pattern*: `^(Mon\|Tue\|Wed\|Thu\|Fri\|Sat\|Sun), \d{2} (Jan\|Feb\|Mar\|Apr\|May\|Jun\|Jul\|Aug\|Sep\|Oct\|Nov\|Dec) \d{4} \d{2}:\d{2}:\d{2} (GMT\|UTC)$` |
| `xFapiCustomerIpAddress` | `string` | Header, Optional | O endereço IP do usuário se estiver atualmente logado com o receptor.<br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `100`, *Pattern*: `[\w\W\s]*` |
| `xFapiInteractionId` | `string` | Header, Optional | Um UID [RFC4122](https://tools.ietf.org/html/rfc4122) usado como um ID de correlação. Se fornecido, o transmissor deve "reproduzir" esse valor no cabeçalho de resposta.<br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `100`, *Pattern*: `^[a-zA-Z0-9][a-zA-Z0-9\-]{0,99}$` |
| `xCustomerUserAgent` | `string` | Header, Optional | Indica o user-agent que o usuário utiliza.<br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `100`, *Pattern*: `[\w\W\s]*` |
| `paginationKey` | `string` | Query, Optional | Identificador de rechamada, utilizado para evitar a contagem de chamadas ao endpoint durante a paginação.<br>**Constraints**: *Maximum Length*: `2048`, *Pattern*: `[\w\W\s]*` |

## Requires scope

`OPENID`

## Response Type

[`Task<Models.ResponseFinancingsPayments>`](../../doc/models/response-financings-payments.md)

## Example Usage

```csharp
string contractId = "contractId2";
string authorization = "Authorization8";
int? page = 1;
int? pageSize = 25;

try
{
    ResponseFinancingsPayments result = await financingsController.FinancingsGetContractsContractIdPaymentsAsync(contractId, authorization, page, pageSize, null, null, null, null, null);
}
catch (ApiException e){};
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | A requisição foi malformada, omitindo atributos obrigatórios, seja no payload ou através de atributos na URL. | [`ResponseErrorWithAbleAdditionalPropertiesException`](../../doc/models/response-error-with-able-additional-properties-exception.md) |
| 401 | Cabeçalho de autenticação ausente/inválido ou token inválido | [`ResponseErrorWithAbleAdditionalPropertiesException`](../../doc/models/response-error-with-able-additional-properties-exception.md) |
| 403 | O token tem escopo incorreto ou uma política de segurança foi violada | [`ResponseErrorWithAbleAdditionalPropertiesException`](../../doc/models/response-error-with-able-additional-properties-exception.md) |
| 404 | O recurso solicitado não existe ou não foi implementado | [`ResponseErrorWithAbleAdditionalPropertiesException`](../../doc/models/response-error-with-able-additional-properties-exception.md) |
| 405 | O consumidor tentou acessar o recurso com um método não suportado | [`ResponseErrorWithAbleAdditionalPropertiesException`](../../doc/models/response-error-with-able-additional-properties-exception.md) |
| 406 | A solicitação continha um cabeçalho Accept diferente dos tipos de mídia permitidos ou um conjunto de caracteres diferente de UTF-8 | [`ResponseErrorWithAbleAdditionalPropertiesException`](../../doc/models/response-error-with-able-additional-properties-exception.md) |
| 422 | A sintaxe da requisição esta correta, mas não foi possível processar as instruções presentes. | [`ResponseErrorWithAbleAdditionalPropertiesException`](../../doc/models/response-error-with-able-additional-properties-exception.md) |
| 423 | Locked | [`ResponseErrorWithAbleAdditionalPropertiesException`](../../doc/models/response-error-with-able-additional-properties-exception.md) |
| 429 | A operação foi recusada, pois muitas solicitações foram feitas dentro de um determinado período ou o limite global de requisições concorrentes foi atingido | [`ResponseErrorWithAbleAdditionalPropertiesException`](../../doc/models/response-error-with-able-additional-properties-exception.md) |
| 500 | Ocorreu um erro no gateway da API ou no microsserviço | [`ResponseErrorWithAbleAdditionalPropertiesException`](../../doc/models/response-error-with-able-additional-properties-exception.md) |
| 504 | GATEWAY TIMEOUT - A requisição não foi atendida dentro do tempo limite estabelecido | [`ResponseErrorWithAbleAdditionalPropertiesException`](../../doc/models/response-error-with-able-additional-properties-exception.md) |
| 529 | O site está sobrecarregado e a operação foi recusada, pois foi atingido o limite máximo de TPS global, neste momento. | [`ResponseErrorWithAbleAdditionalPropertiesException`](../../doc/models/response-error-with-able-additional-properties-exception.md) |
| Default | Erro inesperado. | [`ResponseErrorWithAbleAdditionalPropertiesException`](../../doc/models/response-error-with-able-additional-properties-exception.md) |

