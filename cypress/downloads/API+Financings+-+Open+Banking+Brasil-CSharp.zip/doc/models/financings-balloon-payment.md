
# Financings Balloon Payment

Lista que traz as datas de vencimento e valor das parcelas não regulares  do contrato da modalidade de crédito consultada.

## Structure

`FinancingsBalloonPayment`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `DueDate` | `DateTime` | Required | Data de vencimento da parcela não regular  a vencer do contrato da modalidade de crédito consultada, conforme especificação RFC-3339. p.ex. 2014-03-19 |
| `Amount` | [`Models.FinancingsBalloonPaymentAmount`](../../doc/models/financings-balloon-payment-amount.md) | Required | Valor monetário da parcela não regular a vencer |

## Example (as JSON)

```json
{
  "dueDate": "2016-03-13",
  "amount": {
    "amount": "amount0",
    "currency": "currency2"
  }
}
```

