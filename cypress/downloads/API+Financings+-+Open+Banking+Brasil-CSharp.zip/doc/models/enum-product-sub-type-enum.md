
# Enum Product Sub Type Enum

"Sub tipo da modalidades de crédito contratadas, conforme  circular 4.015 e descrição do DOC3040 do SCR). (Vide Enum)
Aquisição de bens veículos automotores, Aquisição de bens de outros bens, Microcrédito, Custeio, Investimento, Industrialização, Comercialização, Financiamento habitacional SFH e Financiamento habitacional exceto SFH"

## Enumeration

`EnumProductSubTypeEnum`

## Fields

| Name |
|  --- |
| `AQUISICAOBENSVEICULOSAUTOMOTORES` |
| `AQUISICAOBENSOUTROSBENS` |
| `MICROCREDITO` |
| `CUSTEIO` |
| `INVESTIMENTO` |
| `INDUSTRIALIZACAO` |
| `COMERCIALIZACAO` |
| `FINANCIAMENTOHABITACIONALSFH` |
| `FINANCIAMENTOHABITACIONALEXCETOSFH` |

