
# Response Financings Instalments

## Structure

`ResponseFinancingsInstalments`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Data` | [`Models.FinancingsInstalments`](../../doc/models/financings-instalments.md) | Required | Conjunto de informações referentes às parcelas / prestações da operação de crédito de financiamentos contratada |
| `Links` | [`Models.Links`](../../doc/models/links.md) | Required | Referências para outros recusos da API requisitada. |
| `Meta` | [`Models.Meta`](../../doc/models/meta.md) | Required | Meta informações referente à API requisitada. |

## Example (as JSON)

```json
{
  "data": {
    "typeNumberOfInstalments": "MES",
    "totalNumberOfInstalments": null,
    "typeContractRemaining": "SEM_PRAZO_REMANESCENTE",
    "contractRemainingNumber": null,
    "paidInstalments": 112.16,
    "dueInstalments": null,
    "pastDueInstalments": null,
    "balloonPayments": null
  },
  "links": {
    "self": "self2",
    "first": null,
    "prev": null,
    "next": null,
    "last": null
  },
  "meta": {
    "totalRecords": 122,
    "totalPages": 52,
    "requestDateTime": "2016-03-13T12:52:32.123Z"
  }
}
```

