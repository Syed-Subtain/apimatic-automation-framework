
# Referential Rate Indexer Sub Type Enum

"Sub tipos de taxas referenciais ou indexadores, conforme Anexo 5: Taxa referencial ou Indexador (Indx), do Documento 3040"

## Enumeration

`ReferentialRateIndexerSubTypeEnum`

## Fields

| Name |
|  --- |
| `SEMSUBTIPOINDEXADOR` |
| `PREFIXADO` |
| `TRTBF` |
| `TJLP` |
| `LIBOR` |
| `TLP` |
| `OUTRASTAXASPOSFIXADAS` |
| `CDI` |
| `SELIC` |
| `OUTRASTAXASFLUTUANTES` |
| `IGPM` |
| `IPCA` |
| `IPCC` |
| `OUTROSINDICESPRECO` |
| `TCRPRE` |
| `TCRPOS` |
| `TRFCPRE` |
| `TRFCPOS` |
| `OUTROSINDEXADORES` |

