
# Financings Contract Fee

Objeto que traz o conjunto de informações necessárias para demonstrar a composição das taxas de juros remuneratórios da Modalidade de crédito

## Structure

`FinancingsContractFee`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `FeeName` | `string` | Required | Denominação da Tarifa pactuada<br>**Constraints**: *Maximum Length*: `140`, *Pattern*: `[\w\W\s]*` |
| `FeeCode` | `string` | Required | Sigla identificadora da tarifa pactuada<br>**Constraints**: *Maximum Length*: `140`, *Pattern*: `[\w\W\s]*` |
| `FeeChargeType` | [`Models.FeeChargeTypeEnum`](../../doc/models/fee-charge-type-enum.md) | Required | Tipo de cobrança para a tarifa pactuada no contrato. |
| `FeeCharge` | [`Models.FeeChargeEnum`](../../doc/models/fee-charge-enum.md) | Required | "Forma de cobrança relativa a tarifa pactuada no contrato. (Vide Enum)<br><br>- Mínimo<br>- Máximo<br>- Fixo<br>- Percentual" |
| `FeeAmount` | `string` | Optional | Valor monetário da tarifa pactuada no contrato.<br><br>[Restrição] Preenchimento obrigatório quando a forma de cobrança for diferente de Percentual.<br>**Constraints**: *Minimum Length*: `4`, *Maximum Length*: `20`, *Pattern*: `^\d{1,15}\.\d{2,4}$` |
| `FeeRate` | `string` | Optional | É o valor da tarifa em percentual pactuada no contrato.<br><br>[Restrição] Preenchimento obrigatório quando a forma de cobrança for Percentual.<br>**Constraints**: *Minimum Length*: `8`, *Maximum Length*: `8`, *Pattern*: `^[01]\.\d{6}$` |

## Example (as JSON)

```json
{
  "feeName": "feeName2",
  "feeCode": "feeCode8",
  "feeChargeType": "UNICA",
  "feeCharge": "FIXO",
  "feeAmount": null,
  "feeRate": null
}
```

