
# Enum Contract Finance Charge Type Enum

Tipo de encargo pactuado no contrato.

## Enumeration

`EnumContractFinanceChargeTypeEnum`

## Fields

| Name |
|  --- |
| `JUROSREMUNERATORIOSPORATRASO` |
| `MULTAATRASOPAGAMENTO` |
| `JUROSMORAATRASO` |
| `IOFCONTRATACAO` |
| `IOFPORATRASO` |
| `SEMENCARGO` |
| `OUTROS` |

