
# Response Error With Able Additional Properties Exception

## Structure

`ResponseErrorWithAbleAdditionalPropertiesException`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Errors` | [`List<Models.Error>`](../../doc/models/error.md) | Required | **Constraints**: *Minimum Items*: `1`, *Maximum Items*: `13` |
| `Meta` | [`Models.Meta`](../../doc/models/meta.md) | Optional | Meta informações referente à API requisitada. |

## Example (as JSON)

```json
{
  "errors": [
    {
      "code": "code3",
      "title": "title1",
      "detail": "detail1"
    },
    {
      "code": "code4",
      "title": "title2",
      "detail": "detail2"
    },
    {
      "code": "code5",
      "title": "title3",
      "detail": "detail3"
    }
  ],
  "meta": null
}
```

