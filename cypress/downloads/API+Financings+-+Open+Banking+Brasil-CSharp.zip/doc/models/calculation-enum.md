
# Calculation Enum

Base de cálculo

## Enumeration

`CalculationEnum`

## Fields

| Name |
|  --- |
| `Enum21252` |
| `Enum30360` |
| `Enum30365` |

