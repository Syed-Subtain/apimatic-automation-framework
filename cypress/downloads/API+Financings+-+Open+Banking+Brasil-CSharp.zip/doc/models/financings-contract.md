
# Financings Contract

Conjunto de informações referentes à identificação da operação de crédito de financiamentos

## Structure

`FinancingsContract`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ContractNumber` | `string` | Required | Número do contrato dado pela instituição contratante.<br>**Constraints**: *Maximum Length*: `100`, *Pattern*: `^\d{1,100}$` |
| `IpocCode` | `string` | Required | "Número padronizado do contrato - IPOC (Identificação Padronizada da Operação de Crédito). Segundo DOC 3040, composta por:<br><br>- **CNPJ da instituição:** 8 (oito) posições iniciais;<br>- **Modalidade da operação:** 4 (quatro) posições;<br>- **Tipo do cliente:** 1 (uma) posição( 1 = pessoa natural - CPF, 2= pessoa jurídica – CNPJ, 3 = pessoa física no exterior, 4 = pessoa jurídica no exterior, 5 = pessoa natural sem CPF e 6 = pessoa jurídica sem CNPJ);<br>- **Código do cliente:** O número de posições varia conforme o tipo do cliente:<br>  1. Para clientes pessoa física com CPF (tipo de cliente = 1), informar as 11 (onze) posições do CPF;<br>  2. Para clientes pessoa jurídica com CNPJ (tipo de cliente = 2), informar as 8 (oito) posições iniciais do CNPJ;<br>  3. Para os demais clientes (tipos de cliente 3, 4, 5 e 6), informar 14 (catorze) posições com complemento de zeros à esquerda se a identificação tiver tamanho inferior;<br>- **Código do contrato:** 1 (uma) até 40 (quarenta) posições, sem complemento de caracteres."<br>**Constraints**: *Minimum Length*: `22`, *Maximum Length*: `67`, *Pattern*: `^\d{22,67}$` |
| `ProductName` | `string` | Required | Denominação/Identificação do nome da Modalidade da Operação de Crédito divulgado ao cliente<br>**Constraints**: *Maximum Length*: `140`, *Pattern*: `[\w\W\s]*` |
| `ProductType` | [`Models.EnumProductTypeEnum`](../../doc/models/enum-product-type-enum.md) | Required | "Tipo da modalidade de crédito contratada, conforme  circular 4.015 e descrição do DOC3040 do SCR). (Vide Enum)<br>Financiamentos, Financiamentos rurais  e Financiamentos imobiliários" |
| `ProductSubType` | [`Models.EnumProductSubTypeEnum`](../../doc/models/enum-product-sub-type-enum.md) | Required | "Sub tipo da modalidades de crédito contratadas, conforme  circular 4.015 e descrição do DOC3040 do SCR). (Vide Enum)<br>Aquisição de bens veículos automotores, Aquisição de bens de outros bens, Microcrédito, Custeio, Investimento, Industrialização, Comercialização, Financiamento habitacional SFH e Financiamento habitacional exceto SFH" |
| `ContractDate` | `DateTime` | Required | Data de contratação da operação de crédito. Especificação RFC-3339 |
| `DisbursementDates` | `List<DateTime>` | Optional | Lista que traz as Datas de Desembolso do valor contratado.<br>**Constraints**: *Minimum Items*: `1` |
| `SettlementDate` | `DateTime?` | Optional | Data de liquidação da operação. |
| `ContractAmount` | `string` | Optional | Valor contratado da operação. Expresso em valor monetário com no mínimo 2 casas e no máximo 4 casas decimais.<br>**Constraints**: *Minimum Length*: `4`, *Maximum Length*: `20`, *Pattern*: `^\d{1,15}\.\d{2,4}$` |
| `Currency` | `string` | Optional | Moeda referente ao valor da garantia, segundo modelo ISO-4217. p.ex. 'BRL'<br>Todos os valores monetários informados estão representados com a moeda vigente do Brasil<br>**Constraints**: *Maximum Length*: `3`, *Pattern*: `^(\w{3}){1}$` |
| `DueDate` | `DateTime?` | Optional | Data de vencimento Final da operação. Especificação RFC-3339. |
| `InstalmentPeriodicity` | [`Models.InstalmentPeriodicityEnum`](../../doc/models/instalment-periodicity-enum.md) | Required | "Informação relativa à periodicidade regular das parcelas. (Vide Enum)<br>sem periodicidade regular, semanal, quinzenal, mensal, bimestral, trimestral, semestral, anual" |
| `InstalmentPeriodicityAdditionalInfo` | `string` | Optional | Campo para complementar a informação relativa à periodicidade de pagamento regular.<br><br>[Restrição] Obrigatório quando o campo instalmentPeriodicity for igual a OUTROS.<br>**Constraints**: *Maximum Length*: `50`, *Pattern*: `[\w\W\s]*` |
| `FirstInstalmentDueDate` | `DateTime?` | Optional | Data de vencimento primeira parcela do principal. |
| `CET` | `string` | Optional | CET – Custo Efetivo Total deve ser expresso na forma de taxa percentual anual e incorpora todos os encargos e despesas incidentes nas operações de crédito (taxa de juro, mas também tarifas, tributos, seguros e outras despesas cobradas).  <br>O preenchimento deve respeitar as 6 casas decimais, mesmo que venham preenchidas com zeros (representação de porcentagem p.ex: 0.150000. Este valor representa 15%. O valor 1 representa 100%).<br>**Constraints**: *Minimum Length*: `8`, *Maximum Length*: `9`, *Pattern*: `^\d{1,2}\.\d{6}$` |
| `AmortizationScheduled` | [`Models.AmortizationScheduledEnum`](../../doc/models/amortization-scheduled-enum.md) | Required | Sistema de amortização (Vide Enum):<br><br>- SAC (Sistema de Amortização Constante) - É aquele em que o valor da amortização permanece igual até o final. Os juros cobrados sobre o parcelamento não entram nesta conta.<br>- PRICE (Sistema Francês de Amortização) - As parcelas são fixas do início ao fim do contrato. Ou seja, todas as parcelas terão o mesmo valor, desde a primeira até a última. Nos primeiros pagamentos, a maior parte do valor da prestação corresponde aos juros. Ao longo do tempo, a taxa de juros vai decrescendo. Como o valor da prestação é fixo, com o passar das parcelas, o valor de amortização vai aumentando.<br>- SAM (Sistema de Amortização Misto) - Cada prestação (pagamento) é a média aritmética das prestações respectivas no Sistemas Price e no Sistema de Amortização Constante (SAC).<br>- SEM SISTEMA DE AMORTIZAÇÃO |
| `AmortizationScheduledAdditionalInfo` | `string` | Optional | Campo para complementar a informação relativa à amortização.<br><br>[Restrição] Obrigatório quando o campo amortizationScheduled for igual a OUTROS.<br>**Constraints**: *Maximum Length*: `200`, *Pattern*: `[\w\W\s]*` |
| `InterestRates` | [`List<Models.FinancingsContractInterestRate>`](../../doc/models/financings-contract-interest-rate.md) | Required | Objeto que traz o conjunto de informações necessárias para demonstrar a composição das taxas de juros remuneratórios da Modalidade de crédito.  <br>Caso o contrato não possua taxas de juros, deve ser compartilhada uma lista vazia. Caso o contrato possua uma taxa de juros com valor 0, deve ser compartilhado um objeto com o valor 0 de forma explícita.<br>**Constraints**: *Minimum Items*: `0` |
| `ContractedFees` | [`List<Models.FinancingsContractFee>`](../../doc/models/financings-contract-fee.md) | Required | Lista que traz as informações das tarifas pactuadas no contrato.<br>**Constraints**: *Minimum Items*: `0` |
| `ContractedFinanceCharges` | [`List<Models.FinancingsFinanceCharge>`](../../doc/models/financings-finance-charge.md) | Required | Lista que traz os encargos pactuados no contrato<br>**Constraints**: *Minimum Items*: `0` |

## Example (as JSON)

```json
{
  "contractNumber": "contractNumber0",
  "ipocCode": "ipocCode0",
  "productName": "productName0",
  "productType": "FINANCIAMENTOS",
  "productSubType": "AQUISICAO_BENS_VEICULOS_AUTOMOTORES",
  "contractDate": "2016-03-13",
  "disbursementDates": null,
  "settlementDate": null,
  "contractAmount": null,
  "currency": null,
  "dueDate": null,
  "instalmentPeriodicity": "OUTROS",
  "instalmentPeriodicityAdditionalInfo": null,
  "firstInstalmentDueDate": null,
  "CET": null,
  "amortizationScheduled": "SAM",
  "amortizationScheduledAdditionalInfo": null,
  "interestRates": [
    {
      "taxType": "EFETIVA",
      "interestRateType": "COMPOSTO",
      "taxPeriodicity": "AA",
      "calculation": "30/365",
      "referentialRateIndexerType": "PRE_FIXADO",
      "referentialRateIndexerSubType": null,
      "referentialRateIndexerAdditionalInfo": null,
      "preFixedRate": null,
      "postFixedRate": null,
      "additionalInfo": null
    },
    {
      "taxType": "NOMINAL",
      "interestRateType": "SIMPLES",
      "taxPeriodicity": "AM",
      "calculation": "21/252",
      "referentialRateIndexerType": "POS_FIXADO",
      "referentialRateIndexerSubType": null,
      "referentialRateIndexerAdditionalInfo": null,
      "preFixedRate": null,
      "postFixedRate": null,
      "additionalInfo": null
    }
  ],
  "contractedFees": [
    {
      "feeName": "feeName4",
      "feeCode": "feeCode0",
      "feeChargeType": "UNICA",
      "feeCharge": "MINIMO",
      "feeAmount": null,
      "feeRate": null
    },
    {
      "feeName": "feeName3",
      "feeCode": "feeCode9",
      "feeChargeType": "POR_PARCELA",
      "feeCharge": "MAXIMO",
      "feeAmount": null,
      "feeRate": null
    },
    {
      "feeName": "feeName2",
      "feeCode": "feeCode8",
      "feeChargeType": "UNICA",
      "feeCharge": "FIXO",
      "feeAmount": null,
      "feeRate": null
    }
  ],
  "contractedFinanceCharges": [
    {
      "chargeType": "JUROS_REMUNERATORIOS_POR_ATRASO",
      "chargeAdditionalInfo": null,
      "chargeRate": null
    }
  ]
}
```

