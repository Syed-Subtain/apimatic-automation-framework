
# Financings Balloon Payment Amount

Valor monetário da parcela não regular a vencer

## Structure

`FinancingsBalloonPaymentAmount`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Amount` | `string` | Required | Valor monetário da parcela não regular a vencer. Expresso em valor monetário com no mínimo 2 casas e no máximo 4 casas decimais.<br>**Constraints**: *Minimum Length*: `4`, *Maximum Length*: `20`, *Pattern*: `^\d{1,15}\.\d{2,4}$` |
| `Currency` | `string` | Required | Moeda referente ao valor monetário, seguindo o modelo ISO-4217.<br>**Constraints**: *Maximum Length*: `3`, *Pattern*: `^[A-Z]{3}$` |

## Example (as JSON)

```json
{
  "amount": "amount8",
  "currency": "currency0"
}
```

