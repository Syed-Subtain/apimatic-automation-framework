
# Fee Charge Enum

"Forma de cobrança relativa a tarifa pactuada no contrato. (Vide Enum)

- Mínimo
- Máximo
- Fixo
- Percentual"

## Enumeration

`FeeChargeEnum`

## Fields

| Name |
|  --- |
| `MINIMO` |
| `MAXIMO` |
| `FIXO` |
| `PERCENTUAL` |

