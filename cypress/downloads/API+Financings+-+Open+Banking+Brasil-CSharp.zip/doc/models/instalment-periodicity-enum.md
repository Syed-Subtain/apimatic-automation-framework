
# Instalment Periodicity Enum

"Informação relativa à periodicidade regular das parcelas. (Vide Enum)
sem periodicidade regular, semanal, quinzenal, mensal, bimestral, trimestral, semestral, anual"

## Enumeration

`InstalmentPeriodicityEnum`

## Fields

| Name |
|  --- |
| `SEMPERIODICIDADEREGULAR` |
| `SEMANAL` |
| `QUINZENAL` |
| `MENSAL` |
| `BIMESTRAL` |
| `TRIMESTRAL` |
| `SEMESTRAL` |
| `ANUAL` |
| `OUTROS` |

