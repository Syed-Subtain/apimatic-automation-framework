
# Financings Contract Interest Rate

Objeto que traz o conjunto de informações necessárias para demonstrar a composição das taxas de juros remuneratórios da Modalidade de crédito

## Structure

`FinancingsContractInterestRate`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `TaxType` | [`Models.TaxTypeEnum`](../../doc/models/tax-type-enum.md) | Required | "Tipo de Taxa (vide  Enum)<br><br>- NOMINAL (taxa nominal é uma taxa de juros em que a unidade referencial não coincide com a unidade de tempo da capitalização. Ela é sempre fornecida em termos anuais, e seus períodos de capitalização podem ser diários, mensais, trimestrais ou semestrais. p.ex. Uma taxa de 12% ao ano com capitalização mensal)<br>- EFETIVA (É a taxa de juros em que a unidade referencial coincide com a unidade de tempo da capitalização. Como as unidades de medida de tempo da taxa de juros e dos períodos de capitalização são iguais, usa-se exemplos simples como 1% ao mês, 60% ao ano)" |
| `InterestRateType` | [`Models.InterestRateTypeEnum`](../../doc/models/interest-rate-type-enum.md) | Required | "Tipo de Juros  (vide  Enum)<br><br>- SIMPLES (aplicada/cobrada sempre sobre o capital inicial, que é o valor emprestado/investido. Não há cobrança de juros sobre juros acumulados no(s) período(s) anterior(es). Exemplo: em um empréstimo de R$1.000, com taxa de juros simples de 8% a.a., com duração de 2 anos, o total de juros será R$80 no primeiro ano e R$ 80 no segundo ano. Ao final do contrato, o tomador irá devolver o principal e os juros simples de cada ano: R$1.000+R$80+R$80=R$1.160)<br>- COMPOSTO (para cada período do contrato (diário, mensal, anual etc.), há um “novo capital” para a cobrança da taxa de juros contratada. Esse “novo capital” é a soma do capital e do juro cobrado no período anterior. Exemplo: em um empréstimo de R$1.000, com taxa de juros composta de 8% a.a., com duração de 2 anos, o total de juros será R$80 no primeiro ano. No segundo ano, os juros vão ser somados ao capital (R$1.000 + R$ 80 = R$ 1.080), resultando em juros de R$ 86 (8%de R$ 1.080))" |
| `TaxPeriodicity` | [`Models.TaxPeriodicityEnum`](../../doc/models/tax-periodicity-enum.md) | Required | "Periodicidade da taxa . (Vide  Enum)<br>a.m - ao mês<br>a.a. - ao ano" |
| `Calculation` | [`Models.CalculationEnum`](../../doc/models/calculation-enum.md) | Required | Base de cálculo |
| `ReferentialRateIndexerType` | [`Models.ReferentialRateIndexerTypeEnum`](../../doc/models/referential-rate-indexer-type-enum.md) | Required | "Tipos de taxas referenciais ou indexadores, conforme Anexo 5: Taxa referencial ou Indexador (Indx), do Documento 3040" |
| `ReferentialRateIndexerSubType` | [`Models.ReferentialRateIndexerSubTypeEnum?`](../../doc/models/referential-rate-indexer-sub-type-enum.md) | Optional | "Sub tipos de taxas referenciais ou indexadores, conforme Anexo 5: Taxa referencial ou Indexador (Indx), do Documento 3040" |
| `ReferentialRateIndexerAdditionalInfo` | `string` | Optional | Campo livre para complementar a informação relativa ao Tipo de taxa referencial ou indexador.<br><br>[Restrição] Obrigatório para complementar a informação relativa ao Tipo de taxa referencial ou indexador, quando selecionada o tipo ou subtipo OUTRO.<br>**Constraints**: *Maximum Length*: `140`, *Pattern*: `[\w\W\s]*` |
| `PreFixedRate` | `string` | Optional | Taxa pré fixada aplicada sob o contrato da modalidade crédito. p.ex. 0.014500.  <br>O preenchimento deve respeitar as 6 casas decimais, mesmo que venham preenchidas com zeros(representação de porcentagem p.ex: 0.150000. Este valor representa 15%. O valor 1 representa 100%).<br>**Constraints**: *Minimum Length*: `8`, *Maximum Length*: `9`, *Pattern*: `^\d{1,2}\.\d{6}$` |
| `PostFixedRate` | `string` | Optional | Taxa pós fixada aplicada sob o contrato da modalidade crédito. p.ex. 0.014500.  <br>O preenchimento deve respeitar as 6 casas decimais, mesmo que venham preenchidas com zeros (representação de porcentagem p.ex: 0.150000. Este valor representa 15%. O valor 1 representa 100%).<br>**Constraints**: *Minimum Length*: `8`, *Maximum Length*: `9`, *Pattern*: `^\d{1,2}\.\d{6}$` |
| `AdditionalInfo` | `string` | Optional | Texto com informações adicionais sobre a composição das taxas de juros pactuadas.<br><br>[Restrição] Caso a instituição possua a informação para compartilhamento, esta deverá ser informada.<br>**Constraints**: *Maximum Length*: `1200`, *Pattern*: `[\w\W\s]*` |

## Example (as JSON)

```json
{
  "taxType": "NOMINAL",
  "interestRateType": "SIMPLES",
  "taxPeriodicity": "AM",
  "calculation": "30/365",
  "referentialRateIndexerType": "POS_FIXADO",
  "referentialRateIndexerSubType": null,
  "referentialRateIndexerAdditionalInfo": null,
  "preFixedRate": null,
  "postFixedRate": null,
  "additionalInfo": null
}
```

