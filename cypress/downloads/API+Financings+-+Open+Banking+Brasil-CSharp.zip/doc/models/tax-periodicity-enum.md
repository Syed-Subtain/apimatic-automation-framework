
# Tax Periodicity Enum

"Periodicidade da taxa . (Vide  Enum)
a.m - ao mês
a.a. - ao ano"

## Enumeration

`TaxPeriodicityEnum`

## Fields

| Name |
|  --- |
| `AM` |
| `AA` |

