
# Warranty Type Enum

Denominação/Identificação do tipo da garantia que avaliza a Modalidade da Operação de Crédito contratada  (Doc 3040, Anexo 12)

## Enumeration

`WarrantyTypeEnum`

## Fields

| Name |
|  --- |
| `CESSAODIREITOSCREDITORIOS` |
| `CAUCAO` |
| `PENHOR` |
| `ALIENACAOFIDUCIARIA` |
| `HIPOTECA` |
| `OPERACOESGARANTIDASPELOGOVERNO` |
| `OUTRASGARANTIASNAOFIDEJUSSORIAS` |
| `SEGUROSASSEMELHADOS` |
| `GARANTIAFIDEJUSSORIA` |
| `BENSARRENDADOS` |
| `GARANTIASINTERNACIONAIS` |
| `OPERACOESGARANTIDASOUTRASENTIDADES` |
| `ACORDOSCOMPENSACAO` |

