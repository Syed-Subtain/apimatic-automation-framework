
# Response Financings Payments

## Structure

`ResponseFinancingsPayments`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Data` | [`Models.FinancingsPayments`](../../doc/models/financings-payments.md) | Required | Conjunto de informações referentes aos pagamentos realizados de uma operação de crédito de adiantamento a depositantes |
| `Links` | [`Models.Links`](../../doc/models/links.md) | Required | Referências para outros recusos da API requisitada. |
| `Meta` | [`Models.Meta`](../../doc/models/meta.md) | Required | Meta informações referente à API requisitada. |

## Example (as JSON)

```json
{
  "data": {
    "paidInstalments": null,
    "contractOutstandingBalance": "contractOutstandingBalance2",
    "releases": [
      {
        "paymentId": null,
        "isOverParcelPayment": false,
        "instalmentId": null,
        "paidDate": "2016-03-13",
        "currency": "currency6",
        "paidAmount": "paidAmount2",
        "overParcel": null
      },
      {
        "paymentId": null,
        "isOverParcelPayment": true,
        "instalmentId": null,
        "paidDate": "2016-03-13",
        "currency": "currency5",
        "paidAmount": "paidAmount1",
        "overParcel": null
      }
    ]
  },
  "links": {
    "self": "self2",
    "first": null,
    "prev": null,
    "next": null,
    "last": null
  },
  "meta": {
    "totalRecords": 122,
    "totalPages": 52,
    "requestDateTime": "2016-03-13T12:52:32.123Z"
  }
}
```

