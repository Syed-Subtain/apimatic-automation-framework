// <copyright file="FinancingsController.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace APIFinancingsOpenBankingBrasil.Standard.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Dynamic;
    using System.Globalization;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading;
    using System.Threading.Tasks;
    using APIFinancingsOpenBankingBrasil.Standard;
    using APIFinancingsOpenBankingBrasil.Standard.Authentication;
    using APIFinancingsOpenBankingBrasil.Standard.Exceptions;
    using APIFinancingsOpenBankingBrasil.Standard.Http.Client;
    using APIFinancingsOpenBankingBrasil.Standard.Http.Request;
    using APIFinancingsOpenBankingBrasil.Standard.Http.Request.Configuration;
    using APIFinancingsOpenBankingBrasil.Standard.Http.Response;
    using APIFinancingsOpenBankingBrasil.Standard.Utilities;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// FinancingsController.
    /// </summary>
    public class FinancingsController : BaseController
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="FinancingsController"/> class.
        /// </summary>
        /// <param name="config"> config instance. </param>
        /// <param name="httpClient"> httpClient. </param>
        /// <param name="authManagers"> authManager. </param>
        internal FinancingsController(IConfiguration config, IHttpClient httpClient, IDictionary<string, IAuthManager> authManagers)
            : base(config, httpClient, authManagers)
        {
        }

        /// <summary>
        /// Método para obter a lista de contratos de empréstimo mantidos pelo cliente na instituição transmissora e para os quais ele tenha fornecido consentimento.
        /// </summary>
        /// <param name="authorization">Required parameter: Cabeçalho HTTP padrão. Permite que as credenciais sejam fornecidas dependendo do tipo de recurso solicitado.</param>
        /// <param name="xFapiAuthDate">Required parameter: Data em que o usuário logou pela última vez com o receptor. Representada de acordo com a [RFC7231](https://tools.ietf.org/html/rfc7231).Exemplo: Sun, 10 Sep 2017 19:43:31 UTC.</param>
        /// <param name="xFapiCustomerIpAddress">Optional parameter: O endereço IP do usuário se estiver atualmente logado com o receptor..</param>
        /// <param name="xFapiInteractionId">Optional parameter: Um UID [RFC4122](https://tools.ietf.org/html/rfc4122) usado como um ID de correlação. Se fornecido, o transmissor deve "reproduzir" esse valor no cabeçalho de resposta..</param>
        /// <param name="xCustomerUserAgent">Optional parameter: Indica o user-agent que o usuário utiliza..</param>
        /// <param name="page">Optional parameter: Número da página que está sendo requisitada (o valor da primeira página é 1)..</param>
        /// <param name="pageSize">Optional parameter: Quantidade total de registros por páginas..</param>
        /// <param name="paginationKey">Optional parameter: Identificador de rechamada, utilizado para evitar a contagem de chamadas ao endpoint durante a paginação..</param>
        /// <returns>Returns the Models.ResponseFinancingsContractList response from the API call.</returns>
        public Models.ResponseFinancingsContractList FinancingsGetContracts(
                string authorization,
                string xFapiAuthDate,
                string xFapiCustomerIpAddress = null,
                string xFapiInteractionId = null,
                string xCustomerUserAgent = null,
                int? page = 1,
                int? pageSize = 25,
                string paginationKey = null)
        {
            Task<Models.ResponseFinancingsContractList> t = this.FinancingsGetContractsAsync(authorization, xFapiAuthDate, xFapiCustomerIpAddress, xFapiInteractionId, xCustomerUserAgent, page, pageSize, paginationKey);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// Método para obter a lista de contratos de empréstimo mantidos pelo cliente na instituição transmissora e para os quais ele tenha fornecido consentimento.
        /// </summary>
        /// <param name="authorization">Required parameter: Cabeçalho HTTP padrão. Permite que as credenciais sejam fornecidas dependendo do tipo de recurso solicitado.</param>
        /// <param name="xFapiAuthDate">Required parameter: Data em que o usuário logou pela última vez com o receptor. Representada de acordo com a [RFC7231](https://tools.ietf.org/html/rfc7231).Exemplo: Sun, 10 Sep 2017 19:43:31 UTC.</param>
        /// <param name="xFapiCustomerIpAddress">Optional parameter: O endereço IP do usuário se estiver atualmente logado com o receptor..</param>
        /// <param name="xFapiInteractionId">Optional parameter: Um UID [RFC4122](https://tools.ietf.org/html/rfc4122) usado como um ID de correlação. Se fornecido, o transmissor deve "reproduzir" esse valor no cabeçalho de resposta..</param>
        /// <param name="xCustomerUserAgent">Optional parameter: Indica o user-agent que o usuário utiliza..</param>
        /// <param name="page">Optional parameter: Número da página que está sendo requisitada (o valor da primeira página é 1)..</param>
        /// <param name="pageSize">Optional parameter: Quantidade total de registros por páginas..</param>
        /// <param name="paginationKey">Optional parameter: Identificador de rechamada, utilizado para evitar a contagem de chamadas ao endpoint durante a paginação..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.ResponseFinancingsContractList response from the API call.</returns>
        public async Task<Models.ResponseFinancingsContractList> FinancingsGetContractsAsync(
                string authorization,
                string xFapiAuthDate,
                string xFapiCustomerIpAddress = null,
                string xFapiInteractionId = null,
                string xCustomerUserAgent = null,
                int? page = 1,
                int? pageSize = 25,
                string paginationKey = null,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/contracts");

            // prepare specfied query parameters.
            var queryParams = new Dictionary<string, object>()
            {
                { "page", (page != null) ? page : 1 },
                { "page-size", (pageSize != null) ? pageSize : 25 },
                { "pagination-key", paginationKey },
            };

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "Authorization", authorization },
                { "x-fapi-auth-date", xFapiAuthDate },
                { "x-fapi-customer-ip-address", xFapiCustomerIpAddress },
                { "x-fapi-interaction-id", xFapiInteractionId },
                { "x-customer-user-agent", xCustomerUserAgent },
            };

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().Get(queryBuilder.ToString(), headers, queryParameters: queryParams);

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);

            if (response.StatusCode == 400)
            {
                throw new ResponseErrorWithAbleAdditionalPropertiesException("A requisição foi malformada, omitindo atributos obrigatórios, seja no payload ou através de atributos na URL.", context);
            }

            if (response.StatusCode == 401)
            {
                throw new ResponseErrorWithAbleAdditionalPropertiesException("Cabeçalho de autenticação ausente/inválido ou token inválido", context);
            }

            if (response.StatusCode == 403)
            {
                throw new ResponseErrorWithAbleAdditionalPropertiesException("O token tem escopo incorreto ou uma política de segurança foi violada", context);
            }

            if (response.StatusCode == 404)
            {
                throw new ResponseErrorWithAbleAdditionalPropertiesException("O recurso solicitado não existe ou não foi implementado", context);
            }

            if (response.StatusCode == 405)
            {
                throw new ResponseErrorWithAbleAdditionalPropertiesException("O consumidor tentou acessar o recurso com um método não suportado", context);
            }

            if (response.StatusCode == 406)
            {
                throw new ResponseErrorWithAbleAdditionalPropertiesException("A solicitação continha um cabeçalho Accept diferente dos tipos de mídia permitidos ou um conjunto de caracteres diferente de UTF-8", context);
            }

            if (response.StatusCode == 422)
            {
                throw new ResponseErrorWithAbleAdditionalPropertiesException("A sintaxe da requisição esta correta, mas não foi possível processar as instruções presentes.", context);
            }

            if (response.StatusCode == 423)
            {
                throw new ResponseErrorWithAbleAdditionalPropertiesException("Locked", context);
            }

            if (response.StatusCode == 429)
            {
                throw new ResponseErrorWithAbleAdditionalPropertiesException("A operação foi recusada, pois muitas solicitações foram feitas dentro de um determinado período ou o limite global de requisições concorrentes foi atingido", context);
            }

            if (response.StatusCode == 500)
            {
                throw new ResponseErrorWithAbleAdditionalPropertiesException("Ocorreu um erro no gateway da API ou no microsserviço", context);
            }

            if (response.StatusCode == 504)
            {
                throw new ResponseErrorWithAbleAdditionalPropertiesException("GATEWAY TIMEOUT - A requisição não foi atendida dentro do tempo limite estabelecido", context);
            }

            if (response.StatusCode == 529)
            {
                throw new ResponseErrorWithAbleAdditionalPropertiesException("O site está sobrecarregado e a operação foi recusada, pois foi atingido o limite máximo de TPS global, neste momento.", context);
            }

            // [200,208] = HTTP OK
            if ((response.StatusCode < 200) || (response.StatusCode > 208))
            {
                throw new ResponseErrorWithAbleAdditionalPropertiesException("Erro inesperado.", context);
            }

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.ResponseFinancingsContractList>(response.Body);
        }

        /// <summary>
        /// Método para obter os dados do contrato de financiamento identificado por contractId mantido pelo cliente na instituição transmissora.
        /// </summary>
        /// <param name="contractId">Required parameter: Identificador do contrato para todos os tipos de operação de crédito..</param>
        /// <param name="authorization">Required parameter: Cabeçalho HTTP padrão. Permite que as credenciais sejam fornecidas dependendo do tipo de recurso solicitado.</param>
        /// <param name="xFapiAuthDate">Optional parameter: Data em que o usuário logou pela última vez com o receptor. Representada de acordo com a [RFC7231](https://tools.ietf.org/html/rfc7231).Exemplo: Sun, 10 Sep 2017 19:43:31 UTC.</param>
        /// <param name="xFapiCustomerIpAddress">Optional parameter: O endereço IP do usuário se estiver atualmente logado com o receptor..</param>
        /// <param name="xFapiInteractionId">Optional parameter: Um UID [RFC4122](https://tools.ietf.org/html/rfc4122) usado como um ID de correlação. Se fornecido, o transmissor deve "reproduzir" esse valor no cabeçalho de resposta..</param>
        /// <param name="xCustomerUserAgent">Optional parameter: Indica o user-agent que o usuário utiliza..</param>
        /// <returns>Returns the Models.ResponseFinancingsContract response from the API call.</returns>
        public Models.ResponseFinancingsContract FinancingsGetContractsContractId(
                string contractId,
                string authorization,
                string xFapiAuthDate = null,
                string xFapiCustomerIpAddress = null,
                string xFapiInteractionId = null,
                string xCustomerUserAgent = null)
        {
            Task<Models.ResponseFinancingsContract> t = this.FinancingsGetContractsContractIdAsync(contractId, authorization, xFapiAuthDate, xFapiCustomerIpAddress, xFapiInteractionId, xCustomerUserAgent);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// Método para obter os dados do contrato de financiamento identificado por contractId mantido pelo cliente na instituição transmissora.
        /// </summary>
        /// <param name="contractId">Required parameter: Identificador do contrato para todos os tipos de operação de crédito..</param>
        /// <param name="authorization">Required parameter: Cabeçalho HTTP padrão. Permite que as credenciais sejam fornecidas dependendo do tipo de recurso solicitado.</param>
        /// <param name="xFapiAuthDate">Optional parameter: Data em que o usuário logou pela última vez com o receptor. Representada de acordo com a [RFC7231](https://tools.ietf.org/html/rfc7231).Exemplo: Sun, 10 Sep 2017 19:43:31 UTC.</param>
        /// <param name="xFapiCustomerIpAddress">Optional parameter: O endereço IP do usuário se estiver atualmente logado com o receptor..</param>
        /// <param name="xFapiInteractionId">Optional parameter: Um UID [RFC4122](https://tools.ietf.org/html/rfc4122) usado como um ID de correlação. Se fornecido, o transmissor deve "reproduzir" esse valor no cabeçalho de resposta..</param>
        /// <param name="xCustomerUserAgent">Optional parameter: Indica o user-agent que o usuário utiliza..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.ResponseFinancingsContract response from the API call.</returns>
        public async Task<Models.ResponseFinancingsContract> FinancingsGetContractsContractIdAsync(
                string contractId,
                string authorization,
                string xFapiAuthDate = null,
                string xFapiCustomerIpAddress = null,
                string xFapiInteractionId = null,
                string xCustomerUserAgent = null,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/contracts/{contractId}");

            // process optional template parameters.
            ApiHelper.AppendUrlWithTemplateParameters(queryBuilder, new Dictionary<string, object>()
            {
                { "contractId", contractId },
            });

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "Authorization", authorization },
                { "x-fapi-auth-date", xFapiAuthDate },
                { "x-fapi-customer-ip-address", xFapiCustomerIpAddress },
                { "x-fapi-interaction-id", xFapiInteractionId },
                { "x-customer-user-agent", xCustomerUserAgent },
            };

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().Get(queryBuilder.ToString(), headers);

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);

            if (response.StatusCode == 400)
            {
                throw new ResponseErrorWithAbleAdditionalPropertiesException("A requisição foi malformada, omitindo atributos obrigatórios, seja no payload ou através de atributos na URL.", context);
            }

            if (response.StatusCode == 401)
            {
                throw new ResponseErrorWithAbleAdditionalPropertiesException("Cabeçalho de autenticação ausente/inválido ou token inválido", context);
            }

            if (response.StatusCode == 403)
            {
                throw new ResponseErrorWithAbleAdditionalPropertiesException("O token tem escopo incorreto ou uma política de segurança foi violada", context);
            }

            if (response.StatusCode == 404)
            {
                throw new ResponseErrorWithAbleAdditionalPropertiesException("O recurso solicitado não existe ou não foi implementado", context);
            }

            if (response.StatusCode == 405)
            {
                throw new ResponseErrorWithAbleAdditionalPropertiesException("O consumidor tentou acessar o recurso com um método não suportado", context);
            }

            if (response.StatusCode == 406)
            {
                throw new ResponseErrorWithAbleAdditionalPropertiesException("A solicitação continha um cabeçalho Accept diferente dos tipos de mídia permitidos ou um conjunto de caracteres diferente de UTF-8", context);
            }

            if (response.StatusCode == 422)
            {
                throw new ResponseErrorWithAbleAdditionalPropertiesException("A sintaxe da requisição esta correta, mas não foi possível processar as instruções presentes.", context);
            }

            if (response.StatusCode == 423)
            {
                throw new ResponseErrorWithAbleAdditionalPropertiesException("Locked", context);
            }

            if (response.StatusCode == 429)
            {
                throw new ResponseErrorWithAbleAdditionalPropertiesException("A operação foi recusada, pois muitas solicitações foram feitas dentro de um determinado período ou o limite global de requisições concorrentes foi atingido", context);
            }

            if (response.StatusCode == 500)
            {
                throw new ResponseErrorWithAbleAdditionalPropertiesException("Ocorreu um erro no gateway da API ou no microsserviço", context);
            }

            if (response.StatusCode == 504)
            {
                throw new ResponseErrorWithAbleAdditionalPropertiesException("GATEWAY TIMEOUT - A requisição não foi atendida dentro do tempo limite estabelecido", context);
            }

            if (response.StatusCode == 529)
            {
                throw new ResponseErrorWithAbleAdditionalPropertiesException("O site está sobrecarregado e a operação foi recusada, pois foi atingido o limite máximo de TPS global, neste momento.", context);
            }

            // [200,208] = HTTP OK
            if ((response.StatusCode < 200) || (response.StatusCode > 208))
            {
                throw new ResponseErrorWithAbleAdditionalPropertiesException("Erro inesperado.", context);
            }

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.ResponseFinancingsContract>(response.Body);
        }

        /// <summary>
        /// Método para obter a lista de garantias vinculadas ao contrato de financiamento identificado por contractId mantido pelo cliente na instituição transmissora.
        /// </summary>
        /// <param name="contractId">Required parameter: Identificador do contrato para todos os tipos de operação de crédito..</param>
        /// <param name="authorization">Required parameter: Cabeçalho HTTP padrão. Permite que as credenciais sejam fornecidas dependendo do tipo de recurso solicitado.</param>
        /// <param name="page">Optional parameter: Número da página que está sendo requisitada (o valor da primeira página é 1)..</param>
        /// <param name="pageSize">Optional parameter: Quantidade total de registros por páginas..</param>
        /// <param name="xFapiAuthDate">Optional parameter: Data em que o usuário logou pela última vez com o receptor. Representada de acordo com a [RFC7231](https://tools.ietf.org/html/rfc7231).Exemplo: Sun, 10 Sep 2017 19:43:31 UTC.</param>
        /// <param name="xFapiCustomerIpAddress">Optional parameter: O endereço IP do usuário se estiver atualmente logado com o receptor..</param>
        /// <param name="xFapiInteractionId">Optional parameter: Um UID [RFC4122](https://tools.ietf.org/html/rfc4122) usado como um ID de correlação. Se fornecido, o transmissor deve "reproduzir" esse valor no cabeçalho de resposta..</param>
        /// <param name="xCustomerUserAgent">Optional parameter: Indica o user-agent que o usuário utiliza..</param>
        /// <param name="paginationKey">Optional parameter: Identificador de rechamada, utilizado para evitar a contagem de chamadas ao endpoint durante a paginação..</param>
        /// <returns>Returns the Models.ResponseFinancingsWarranties response from the API call.</returns>
        public Models.ResponseFinancingsWarranties FinancingsGetContractsContractIdWarranties(
                string contractId,
                string authorization,
                int? page = 1,
                int? pageSize = 25,
                string xFapiAuthDate = null,
                string xFapiCustomerIpAddress = null,
                string xFapiInteractionId = null,
                string xCustomerUserAgent = null,
                string paginationKey = null)
        {
            Task<Models.ResponseFinancingsWarranties> t = this.FinancingsGetContractsContractIdWarrantiesAsync(contractId, authorization, page, pageSize, xFapiAuthDate, xFapiCustomerIpAddress, xFapiInteractionId, xCustomerUserAgent, paginationKey);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// Método para obter a lista de garantias vinculadas ao contrato de financiamento identificado por contractId mantido pelo cliente na instituição transmissora.
        /// </summary>
        /// <param name="contractId">Required parameter: Identificador do contrato para todos os tipos de operação de crédito..</param>
        /// <param name="authorization">Required parameter: Cabeçalho HTTP padrão. Permite que as credenciais sejam fornecidas dependendo do tipo de recurso solicitado.</param>
        /// <param name="page">Optional parameter: Número da página que está sendo requisitada (o valor da primeira página é 1)..</param>
        /// <param name="pageSize">Optional parameter: Quantidade total de registros por páginas..</param>
        /// <param name="xFapiAuthDate">Optional parameter: Data em que o usuário logou pela última vez com o receptor. Representada de acordo com a [RFC7231](https://tools.ietf.org/html/rfc7231).Exemplo: Sun, 10 Sep 2017 19:43:31 UTC.</param>
        /// <param name="xFapiCustomerIpAddress">Optional parameter: O endereço IP do usuário se estiver atualmente logado com o receptor..</param>
        /// <param name="xFapiInteractionId">Optional parameter: Um UID [RFC4122](https://tools.ietf.org/html/rfc4122) usado como um ID de correlação. Se fornecido, o transmissor deve "reproduzir" esse valor no cabeçalho de resposta..</param>
        /// <param name="xCustomerUserAgent">Optional parameter: Indica o user-agent que o usuário utiliza..</param>
        /// <param name="paginationKey">Optional parameter: Identificador de rechamada, utilizado para evitar a contagem de chamadas ao endpoint durante a paginação..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.ResponseFinancingsWarranties response from the API call.</returns>
        public async Task<Models.ResponseFinancingsWarranties> FinancingsGetContractsContractIdWarrantiesAsync(
                string contractId,
                string authorization,
                int? page = 1,
                int? pageSize = 25,
                string xFapiAuthDate = null,
                string xFapiCustomerIpAddress = null,
                string xFapiInteractionId = null,
                string xCustomerUserAgent = null,
                string paginationKey = null,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/contracts/{contractId}/warranties");

            // process optional template parameters.
            ApiHelper.AppendUrlWithTemplateParameters(queryBuilder, new Dictionary<string, object>()
            {
                { "contractId", contractId },
            });

            // prepare specfied query parameters.
            var queryParams = new Dictionary<string, object>()
            {
                { "page", (page != null) ? page : 1 },
                { "page-size", (pageSize != null) ? pageSize : 25 },
                { "pagination-key", paginationKey },
            };

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "Authorization", authorization },
                { "x-fapi-auth-date", xFapiAuthDate },
                { "x-fapi-customer-ip-address", xFapiCustomerIpAddress },
                { "x-fapi-interaction-id", xFapiInteractionId },
                { "x-customer-user-agent", xCustomerUserAgent },
            };

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().Get(queryBuilder.ToString(), headers, queryParameters: queryParams);

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);

            if (response.StatusCode == 400)
            {
                throw new ResponseErrorWithAbleAdditionalPropertiesException("A requisição foi malformada, omitindo atributos obrigatórios, seja no payload ou através de atributos na URL.", context);
            }

            if (response.StatusCode == 401)
            {
                throw new ResponseErrorWithAbleAdditionalPropertiesException("Cabeçalho de autenticação ausente/inválido ou token inválido", context);
            }

            if (response.StatusCode == 403)
            {
                throw new ResponseErrorWithAbleAdditionalPropertiesException("O token tem escopo incorreto ou uma política de segurança foi violada", context);
            }

            if (response.StatusCode == 404)
            {
                throw new ResponseErrorWithAbleAdditionalPropertiesException("O recurso solicitado não existe ou não foi implementado", context);
            }

            if (response.StatusCode == 405)
            {
                throw new ResponseErrorWithAbleAdditionalPropertiesException("O consumidor tentou acessar o recurso com um método não suportado", context);
            }

            if (response.StatusCode == 406)
            {
                throw new ResponseErrorWithAbleAdditionalPropertiesException("A solicitação continha um cabeçalho Accept diferente dos tipos de mídia permitidos ou um conjunto de caracteres diferente de UTF-8", context);
            }

            if (response.StatusCode == 422)
            {
                throw new ResponseErrorWithAbleAdditionalPropertiesException("A sintaxe da requisição esta correta, mas não foi possível processar as instruções presentes.", context);
            }

            if (response.StatusCode == 423)
            {
                throw new ResponseErrorWithAbleAdditionalPropertiesException("Locked", context);
            }

            if (response.StatusCode == 429)
            {
                throw new ResponseErrorWithAbleAdditionalPropertiesException("A operação foi recusada, pois muitas solicitações foram feitas dentro de um determinado período ou o limite global de requisições concorrentes foi atingido", context);
            }

            if (response.StatusCode == 500)
            {
                throw new ResponseErrorWithAbleAdditionalPropertiesException("Ocorreu um erro no gateway da API ou no microsserviço", context);
            }

            if (response.StatusCode == 504)
            {
                throw new ResponseErrorWithAbleAdditionalPropertiesException("GATEWAY TIMEOUT - A requisição não foi atendida dentro do tempo limite estabelecido", context);
            }

            if (response.StatusCode == 529)
            {
                throw new ResponseErrorWithAbleAdditionalPropertiesException("O site está sobrecarregado e a operação foi recusada, pois foi atingido o limite máximo de TPS global, neste momento.", context);
            }

            // [200,208] = HTTP OK
            if ((response.StatusCode < 200) || (response.StatusCode > 208))
            {
                throw new ResponseErrorWithAbleAdditionalPropertiesException("Erro inesperado.", context);
            }

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.ResponseFinancingsWarranties>(response.Body);
        }

        /// <summary>
        /// Método para obter os dados do cronograma de parcelas do contrato de financiamento identificado por contractId mantido pelo cliente na instituição transmissora.
        /// </summary>
        /// <param name="contractId">Required parameter: Identificador do contrato para todos os tipos de operação de crédito..</param>
        /// <param name="authorization">Required parameter: Cabeçalho HTTP padrão. Permite que as credenciais sejam fornecidas dependendo do tipo de recurso solicitado.</param>
        /// <param name="page">Optional parameter: Número da página que está sendo requisitada (o valor da primeira página é 1)..</param>
        /// <param name="pageSize">Optional parameter: Quantidade total de registros por páginas..</param>
        /// <param name="xFapiAuthDate">Optional parameter: Data em que o usuário logou pela última vez com o receptor. Representada de acordo com a [RFC7231](https://tools.ietf.org/html/rfc7231).Exemplo: Sun, 10 Sep 2017 19:43:31 UTC.</param>
        /// <param name="xFapiCustomerIpAddress">Optional parameter: O endereço IP do usuário se estiver atualmente logado com o receptor..</param>
        /// <param name="xFapiInteractionId">Optional parameter: Um UID [RFC4122](https://tools.ietf.org/html/rfc4122) usado como um ID de correlação. Se fornecido, o transmissor deve "reproduzir" esse valor no cabeçalho de resposta..</param>
        /// <param name="xCustomerUserAgent">Optional parameter: Indica o user-agent que o usuário utiliza..</param>
        /// <param name="paginationKey">Optional parameter: Identificador de rechamada, utilizado para evitar a contagem de chamadas ao endpoint durante a paginação..</param>
        /// <returns>Returns the Models.ResponseFinancingsInstalments response from the API call.</returns>
        public Models.ResponseFinancingsInstalments FinancingsGetContractsContractIdScheduledInstalments(
                string contractId,
                string authorization,
                int? page = 1,
                int? pageSize = 25,
                string xFapiAuthDate = null,
                string xFapiCustomerIpAddress = null,
                string xFapiInteractionId = null,
                string xCustomerUserAgent = null,
                string paginationKey = null)
        {
            Task<Models.ResponseFinancingsInstalments> t = this.FinancingsGetContractsContractIdScheduledInstalmentsAsync(contractId, authorization, page, pageSize, xFapiAuthDate, xFapiCustomerIpAddress, xFapiInteractionId, xCustomerUserAgent, paginationKey);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// Método para obter os dados do cronograma de parcelas do contrato de financiamento identificado por contractId mantido pelo cliente na instituição transmissora.
        /// </summary>
        /// <param name="contractId">Required parameter: Identificador do contrato para todos os tipos de operação de crédito..</param>
        /// <param name="authorization">Required parameter: Cabeçalho HTTP padrão. Permite que as credenciais sejam fornecidas dependendo do tipo de recurso solicitado.</param>
        /// <param name="page">Optional parameter: Número da página que está sendo requisitada (o valor da primeira página é 1)..</param>
        /// <param name="pageSize">Optional parameter: Quantidade total de registros por páginas..</param>
        /// <param name="xFapiAuthDate">Optional parameter: Data em que o usuário logou pela última vez com o receptor. Representada de acordo com a [RFC7231](https://tools.ietf.org/html/rfc7231).Exemplo: Sun, 10 Sep 2017 19:43:31 UTC.</param>
        /// <param name="xFapiCustomerIpAddress">Optional parameter: O endereço IP do usuário se estiver atualmente logado com o receptor..</param>
        /// <param name="xFapiInteractionId">Optional parameter: Um UID [RFC4122](https://tools.ietf.org/html/rfc4122) usado como um ID de correlação. Se fornecido, o transmissor deve "reproduzir" esse valor no cabeçalho de resposta..</param>
        /// <param name="xCustomerUserAgent">Optional parameter: Indica o user-agent que o usuário utiliza..</param>
        /// <param name="paginationKey">Optional parameter: Identificador de rechamada, utilizado para evitar a contagem de chamadas ao endpoint durante a paginação..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.ResponseFinancingsInstalments response from the API call.</returns>
        public async Task<Models.ResponseFinancingsInstalments> FinancingsGetContractsContractIdScheduledInstalmentsAsync(
                string contractId,
                string authorization,
                int? page = 1,
                int? pageSize = 25,
                string xFapiAuthDate = null,
                string xFapiCustomerIpAddress = null,
                string xFapiInteractionId = null,
                string xCustomerUserAgent = null,
                string paginationKey = null,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/contracts/{contractId}/scheduled-instalments");

            // process optional template parameters.
            ApiHelper.AppendUrlWithTemplateParameters(queryBuilder, new Dictionary<string, object>()
            {
                { "contractId", contractId },
            });

            // prepare specfied query parameters.
            var queryParams = new Dictionary<string, object>()
            {
                { "page", (page != null) ? page : 1 },
                { "page-size", (pageSize != null) ? pageSize : 25 },
                { "pagination-key", paginationKey },
            };

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "Authorization", authorization },
                { "x-fapi-auth-date", xFapiAuthDate },
                { "x-fapi-customer-ip-address", xFapiCustomerIpAddress },
                { "x-fapi-interaction-id", xFapiInteractionId },
                { "x-customer-user-agent", xCustomerUserAgent },
            };

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().Get(queryBuilder.ToString(), headers, queryParameters: queryParams);

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);

            if (response.StatusCode == 400)
            {
                throw new ResponseErrorWithAbleAdditionalPropertiesException("A requisição foi malformada, omitindo atributos obrigatórios, seja no payload ou através de atributos na URL.", context);
            }

            if (response.StatusCode == 401)
            {
                throw new ResponseErrorWithAbleAdditionalPropertiesException("Cabeçalho de autenticação ausente/inválido ou token inválido", context);
            }

            if (response.StatusCode == 403)
            {
                throw new ResponseErrorWithAbleAdditionalPropertiesException("O token tem escopo incorreto ou uma política de segurança foi violada", context);
            }

            if (response.StatusCode == 404)
            {
                throw new ResponseErrorWithAbleAdditionalPropertiesException("O recurso solicitado não existe ou não foi implementado", context);
            }

            if (response.StatusCode == 405)
            {
                throw new ResponseErrorWithAbleAdditionalPropertiesException("O consumidor tentou acessar o recurso com um método não suportado", context);
            }

            if (response.StatusCode == 406)
            {
                throw new ResponseErrorWithAbleAdditionalPropertiesException("A solicitação continha um cabeçalho Accept diferente dos tipos de mídia permitidos ou um conjunto de caracteres diferente de UTF-8", context);
            }

            if (response.StatusCode == 422)
            {
                throw new ResponseErrorWithAbleAdditionalPropertiesException("A sintaxe da requisição esta correta, mas não foi possível processar as instruções presentes.", context);
            }

            if (response.StatusCode == 423)
            {
                throw new ResponseErrorWithAbleAdditionalPropertiesException("Locked", context);
            }

            if (response.StatusCode == 429)
            {
                throw new ResponseErrorWithAbleAdditionalPropertiesException("A operação foi recusada, pois muitas solicitações foram feitas dentro de um determinado período ou o limite global de requisições concorrentes foi atingido", context);
            }

            if (response.StatusCode == 500)
            {
                throw new ResponseErrorWithAbleAdditionalPropertiesException("Ocorreu um erro no gateway da API ou no microsserviço", context);
            }

            if (response.StatusCode == 504)
            {
                throw new ResponseErrorWithAbleAdditionalPropertiesException("GATEWAY TIMEOUT - A requisição não foi atendida dentro do tempo limite estabelecido", context);
            }

            if (response.StatusCode == 529)
            {
                throw new ResponseErrorWithAbleAdditionalPropertiesException("O site está sobrecarregado e a operação foi recusada, pois foi atingido o limite máximo de TPS global, neste momento.", context);
            }

            // [200,208] = HTTP OK
            if ((response.StatusCode < 200) || (response.StatusCode > 208))
            {
                throw new ResponseErrorWithAbleAdditionalPropertiesException("Erro inesperado.", context);
            }

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.ResponseFinancingsInstalments>(response.Body);
        }

        /// <summary>
        /// Método para obter os dados de pagamentos do contrato de financiamento identificado por contractId mantido pelo cliente na instituição transmissora.
        /// </summary>
        /// <param name="contractId">Required parameter: Identificador do contrato para todos os tipos de operação de crédito..</param>
        /// <param name="authorization">Required parameter: Cabeçalho HTTP padrão. Permite que as credenciais sejam fornecidas dependendo do tipo de recurso solicitado.</param>
        /// <param name="page">Optional parameter: Número da página que está sendo requisitada (o valor da primeira página é 1)..</param>
        /// <param name="pageSize">Optional parameter: Quantidade total de registros por páginas..</param>
        /// <param name="xFapiAuthDate">Optional parameter: Data em que o usuário logou pela última vez com o receptor. Representada de acordo com a [RFC7231](https://tools.ietf.org/html/rfc7231).Exemplo: Sun, 10 Sep 2017 19:43:31 UTC.</param>
        /// <param name="xFapiCustomerIpAddress">Optional parameter: O endereço IP do usuário se estiver atualmente logado com o receptor..</param>
        /// <param name="xFapiInteractionId">Optional parameter: Um UID [RFC4122](https://tools.ietf.org/html/rfc4122) usado como um ID de correlação. Se fornecido, o transmissor deve "reproduzir" esse valor no cabeçalho de resposta..</param>
        /// <param name="xCustomerUserAgent">Optional parameter: Indica o user-agent que o usuário utiliza..</param>
        /// <param name="paginationKey">Optional parameter: Identificador de rechamada, utilizado para evitar a contagem de chamadas ao endpoint durante a paginação..</param>
        /// <returns>Returns the Models.ResponseFinancingsPayments response from the API call.</returns>
        public Models.ResponseFinancingsPayments FinancingsGetContractsContractIdPayments(
                string contractId,
                string authorization,
                int? page = 1,
                int? pageSize = 25,
                string xFapiAuthDate = null,
                string xFapiCustomerIpAddress = null,
                string xFapiInteractionId = null,
                string xCustomerUserAgent = null,
                string paginationKey = null)
        {
            Task<Models.ResponseFinancingsPayments> t = this.FinancingsGetContractsContractIdPaymentsAsync(contractId, authorization, page, pageSize, xFapiAuthDate, xFapiCustomerIpAddress, xFapiInteractionId, xCustomerUserAgent, paginationKey);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// Método para obter os dados de pagamentos do contrato de financiamento identificado por contractId mantido pelo cliente na instituição transmissora.
        /// </summary>
        /// <param name="contractId">Required parameter: Identificador do contrato para todos os tipos de operação de crédito..</param>
        /// <param name="authorization">Required parameter: Cabeçalho HTTP padrão. Permite que as credenciais sejam fornecidas dependendo do tipo de recurso solicitado.</param>
        /// <param name="page">Optional parameter: Número da página que está sendo requisitada (o valor da primeira página é 1)..</param>
        /// <param name="pageSize">Optional parameter: Quantidade total de registros por páginas..</param>
        /// <param name="xFapiAuthDate">Optional parameter: Data em que o usuário logou pela última vez com o receptor. Representada de acordo com a [RFC7231](https://tools.ietf.org/html/rfc7231).Exemplo: Sun, 10 Sep 2017 19:43:31 UTC.</param>
        /// <param name="xFapiCustomerIpAddress">Optional parameter: O endereço IP do usuário se estiver atualmente logado com o receptor..</param>
        /// <param name="xFapiInteractionId">Optional parameter: Um UID [RFC4122](https://tools.ietf.org/html/rfc4122) usado como um ID de correlação. Se fornecido, o transmissor deve "reproduzir" esse valor no cabeçalho de resposta..</param>
        /// <param name="xCustomerUserAgent">Optional parameter: Indica o user-agent que o usuário utiliza..</param>
        /// <param name="paginationKey">Optional parameter: Identificador de rechamada, utilizado para evitar a contagem de chamadas ao endpoint durante a paginação..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.ResponseFinancingsPayments response from the API call.</returns>
        public async Task<Models.ResponseFinancingsPayments> FinancingsGetContractsContractIdPaymentsAsync(
                string contractId,
                string authorization,
                int? page = 1,
                int? pageSize = 25,
                string xFapiAuthDate = null,
                string xFapiCustomerIpAddress = null,
                string xFapiInteractionId = null,
                string xCustomerUserAgent = null,
                string paginationKey = null,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/contracts/{contractId}/payments");

            // process optional template parameters.
            ApiHelper.AppendUrlWithTemplateParameters(queryBuilder, new Dictionary<string, object>()
            {
                { "contractId", contractId },
            });

            // prepare specfied query parameters.
            var queryParams = new Dictionary<string, object>()
            {
                { "page", (page != null) ? page : 1 },
                { "page-size", (pageSize != null) ? pageSize : 25 },
                { "pagination-key", paginationKey },
            };

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "Authorization", authorization },
                { "x-fapi-auth-date", xFapiAuthDate },
                { "x-fapi-customer-ip-address", xFapiCustomerIpAddress },
                { "x-fapi-interaction-id", xFapiInteractionId },
                { "x-customer-user-agent", xCustomerUserAgent },
            };

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().Get(queryBuilder.ToString(), headers, queryParameters: queryParams);

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);

            if (response.StatusCode == 400)
            {
                throw new ResponseErrorWithAbleAdditionalPropertiesException("A requisição foi malformada, omitindo atributos obrigatórios, seja no payload ou através de atributos na URL.", context);
            }

            if (response.StatusCode == 401)
            {
                throw new ResponseErrorWithAbleAdditionalPropertiesException("Cabeçalho de autenticação ausente/inválido ou token inválido", context);
            }

            if (response.StatusCode == 403)
            {
                throw new ResponseErrorWithAbleAdditionalPropertiesException("O token tem escopo incorreto ou uma política de segurança foi violada", context);
            }

            if (response.StatusCode == 404)
            {
                throw new ResponseErrorWithAbleAdditionalPropertiesException("O recurso solicitado não existe ou não foi implementado", context);
            }

            if (response.StatusCode == 405)
            {
                throw new ResponseErrorWithAbleAdditionalPropertiesException("O consumidor tentou acessar o recurso com um método não suportado", context);
            }

            if (response.StatusCode == 406)
            {
                throw new ResponseErrorWithAbleAdditionalPropertiesException("A solicitação continha um cabeçalho Accept diferente dos tipos de mídia permitidos ou um conjunto de caracteres diferente de UTF-8", context);
            }

            if (response.StatusCode == 422)
            {
                throw new ResponseErrorWithAbleAdditionalPropertiesException("A sintaxe da requisição esta correta, mas não foi possível processar as instruções presentes.", context);
            }

            if (response.StatusCode == 423)
            {
                throw new ResponseErrorWithAbleAdditionalPropertiesException("Locked", context);
            }

            if (response.StatusCode == 429)
            {
                throw new ResponseErrorWithAbleAdditionalPropertiesException("A operação foi recusada, pois muitas solicitações foram feitas dentro de um determinado período ou o limite global de requisições concorrentes foi atingido", context);
            }

            if (response.StatusCode == 500)
            {
                throw new ResponseErrorWithAbleAdditionalPropertiesException("Ocorreu um erro no gateway da API ou no microsserviço", context);
            }

            if (response.StatusCode == 504)
            {
                throw new ResponseErrorWithAbleAdditionalPropertiesException("GATEWAY TIMEOUT - A requisição não foi atendida dentro do tempo limite estabelecido", context);
            }

            if (response.StatusCode == 529)
            {
                throw new ResponseErrorWithAbleAdditionalPropertiesException("O site está sobrecarregado e a operação foi recusada, pois foi atingido o limite máximo de TPS global, neste momento.", context);
            }

            // [200,208] = HTTP OK
            if ((response.StatusCode < 200) || (response.StatusCode > 208))
            {
                throw new ResponseErrorWithAbleAdditionalPropertiesException("Erro inesperado.", context);
            }

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.ResponseFinancingsPayments>(response.Body);
        }
    }
}