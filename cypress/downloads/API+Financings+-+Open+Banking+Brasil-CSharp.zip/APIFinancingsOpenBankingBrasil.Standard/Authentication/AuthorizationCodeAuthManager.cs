// <copyright file="AuthorizationCodeAuthManager.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace APIFinancingsOpenBankingBrasil.Standard.Authentication
{
    using System;
    using System.Collections.Generic;
    using System.Text;
    using System.Threading.Tasks;
    using APIFinancingsOpenBankingBrasil.Standard.Controllers;
    using APIFinancingsOpenBankingBrasil.Standard.Http.Request;
    using APIFinancingsOpenBankingBrasil.Standard.Utilities;
    using APIFinancingsOpenBankingBrasil.Standard.Exceptions;
    using APIFinancingsOpenBankingBrasil.Standard.Models;

    /// <summary>
    /// AuthorizationCodeAuthManager Class.
    /// </summary>
    public class AuthorizationCodeAuthManager : IAuthorizationCodeAuth, IAuthManager
    {
        private readonly OAuthAuthorizationController oAuthApi;
        private readonly APIFinancingsOpenBankingBrasilClient client;

        /// <summary>
        /// Initializes a new instance of the <see cref="AuthorizationCodeAuthManager"/> class.
        /// </summary>
        /// <param name="oAuthClientId"> OAuth 2 Client ID.</param>
        /// <param name="oAuthClientSecret"> OAuth 2 Client Secret.</param>
        /// <param name="oAuthRedirectUri"> OAuth 2 Redirection URI.</param>
        /// <param name="oAuthToken"> OAuth 2 token.</param>
        /// <param name="oAuthScopes"> List of OAuth 2 scopes.</param>
        /// <param name="client"> Instance of APIFinancingsOpenBankingBrasilClient.</param>
        public AuthorizationCodeAuthManager(
            string oAuthClientId,
            string oAuthClientSecret,
            string oAuthRedirectUri,
            Models.OAuthToken oAuthToken,
            List<Models.AuthorizationCodeScopeEnum> oAuthScopes,
            APIFinancingsOpenBankingBrasilClient client)
        {
            this.OAuthClientId = oAuthClientId;
            this.OAuthClientSecret = oAuthClientSecret;
            this.OAuthRedirectUri = oAuthRedirectUri;
            this.OAuthToken = oAuthToken;
            this.OAuthScopes = oAuthScopes;
            this.client = client;
            this.oAuthApi = new OAuthAuthorizationController(this.client, this.client.HttpClient, this.client.AuthManagers);
        }

        /// <summary>
        /// Gets string value for oAuthClientId.
        /// </summary>
        public string OAuthClientId { get; }

        /// <summary>
        /// Gets string value for oAuthClientSecret.
        /// </summary>
        public string OAuthClientSecret { get; }

        /// <summary>
        /// Gets string value for oAuthRedirectUri.
        /// </summary>
        public string OAuthRedirectUri { get; }

        /// <summary>
        /// Gets Models.OAuthToken value for oAuthToken.
        /// </summary>
        public Models.OAuthToken OAuthToken { get; }

        /// <summary>
        /// Gets List of Models.AuthorizationCodeScopeEnum value for oAuthScopes.
        /// </summary>
        public List<Models.AuthorizationCodeScopeEnum> OAuthScopes { get; }

        /// <summary>
        /// Check if credentials match.
        /// </summary>
        /// <param name="oAuthClientId"> The string value for credentials.</param>
        /// <param name="oAuthClientSecret"> The string value for credentials.</param>
        /// <param name="oAuthRedirectUri"> The string value for credentials.</param>
        /// <param name="oAuthToken"> The Models.OAuthToken value for credentials.</param>
        /// <param name="oAuthScopes"> The List of Models.AuthorizationCodeScopeEnum value for credentials.</param>
        /// <returns> True if credentials matched.</returns>
        public bool Equals(string oAuthClientId, string oAuthClientSecret, string oAuthRedirectUri, Models.OAuthToken oAuthToken, List<Models.AuthorizationCodeScopeEnum> oAuthScopes)
        {
            return oAuthClientId.Equals(this.OAuthClientId)
                    && oAuthClientSecret.Equals(this.OAuthClientSecret)
                    && oAuthRedirectUri.Equals(this.OAuthRedirectUri)
                    && ((oAuthToken == null && this.OAuthToken == null) || (oAuthToken != null && this.OAuthToken != null && oAuthToken.Equals(this.OAuthToken)))
                    && ((oAuthScopes == null && this.OAuthScopes == null) || (oAuthScopes != null && this.OAuthScopes != null && oAuthScopes.Equals(this.OAuthScopes)));
        }

        /// <summary>
        /// Checks if token is expired.
        /// </summary>
        /// <returns> Returns true if token is expired.</returns>
        public bool IsTokenExpired()
        {
           if (this.OAuthToken == null)
           {
               throw new InvalidOperationException("OAuth token is missing.");
           }
        
           return this.OAuthToken.Expiry != null
               && this.OAuthToken.Expiry < (long)DateTime.UtcNow.Subtract(new DateTime(1970, 1, 1)).TotalSeconds;
        }

        /// <summary>
        /// Add authentication information to the HTTP Request.
        /// </summary>
        /// <param name="httpRequest">The http request object on which authentication will be applied.</param>
        /// <exception cref="ApiException">Thrown when OAuthToken is null or expired.</exception>
        /// <returns>HttpRequest.</returns>
        public HttpRequest Apply(HttpRequest httpRequest)
        {
            Task<HttpRequest> t = this.ApplyAsync(httpRequest);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// Asynchronously add authentication information to the HTTP Request.
        /// </summary>
        /// <param name="httpRequest">The http request object on which authentication will be applied.</param>
        /// <exception cref="ApiException">Thrown when OAuthToken is null or expired.</exception>
        /// <returns>A <see cref="Task"/> representing the asynchronous operation.</returns>
        public Task<HttpRequest> ApplyAsync(HttpRequest httpRequest)
        {
            return Task<HttpRequest>.Factory.StartNew(() =>
            {
                CheckAuthorization();
                httpRequest.Headers["Authorization"] = $"Bearer {this.OAuthToken.AccessToken}";
                return httpRequest;
            });
        }

        /// <summary>
        /// Fetch the OAuth token.
        /// </summary>
        /// <param name="authorizationCode">Authorization code returned by the OAuth provider.</param>
        /// <param name="additionalParameters">Dictionary of additional parameters.</param>
        /// <returns>Models.OAuthToken.</returns>
        public Models.OAuthToken FetchToken(string authorizationCode, Dictionary<string, object> additionalParameters = null)
        {
            Task<Models.OAuthToken> t = this.FetchTokenAsync(authorizationCode, additionalParameters);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// Fetch the OAuth token asynchronously.
        /// </summary>
        /// <param name="authorizationCode">Authorization code returned by the OAuth provider.</param>
        /// <param name="additionalParameters">Dictionary of additional parameters.</param>
        /// <returns>Models.OAuthToken.</returns>
        public async Task<Models.OAuthToken> FetchTokenAsync(string authorizationCode, Dictionary<string, object> additionalParameters = null)
        {
            Models.OAuthToken token = await oAuthApi.AuthorizationCodeAuthRequestTokenAsync(BuildBasicAuthheader(), authorizationCode, OAuthRedirectUri, additionalParameters);

            if (token.ExpiresIn != null && token.ExpiresIn != 0)
            {
                token.Expiry = (long)DateTime.UtcNow.Subtract(new DateTime(1970, 1, 1)).TotalSeconds + token.ExpiresIn;
            }

            return token;
        }

        /// <summary>
        /// Refresh the OAuth token asynchronously.
        /// </summary>
        /// <param name="additionalParameters">Dictionary of additional parameters.</param>
        /// <returns>Models.OAuthToken.</returns>
        public async Task<Models.OAuthToken> RefreshTokenAsync(Dictionary<string, object> additionalParameters = null)
        {
            return await oAuthApi.AuthorizationCodeAuthRefreshTokenAsync(BuildBasicAuthheader(),
                OAuthToken.RefreshToken,
                scope: this.OAuthScopes.GetValues(),
                fieldParameters: additionalParameters);
        }

        /// <summary>
        /// Refresh the OAuth token.
        /// </summary>
        /// <param name="additionalParameters">Dictionary of additional parameters.</param>
        /// <returns>Models.OAuthToken.</returns>
        public Models.OAuthToken RefreshToken(Dictionary<string, object> additionalParameters = null)
        {
            Task<Models.OAuthToken> t = this.RefreshTokenAsync(additionalParameters);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// Builds the authorization url for making authorized calls.
        /// </summary>
        /// <param name="state">State</param>        
        /// <param name="additionalParameters">Additional parameters to be appended</param>        
        public string BuildAuthorizationUrl(string state = null, Dictionary<string, object> additionalParameters = null)
        {
            // the base uri for api requests
            string baseUri = this.client.GetBaseUri();

            // prepare query string for API call
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/authorization");

            ApiHelper.AppendUrlWithQueryParameters(queryBuilder, new Dictionary<string, object>
            {
                { "response_type", "code" },
                { "client_id", this.OAuthClientId},
                { "redirect_uri", this.OAuthRedirectUri},
                { "scope", this.OAuthScopes.GetValues() },
                { "state", state}
            });

            if (additionalParameters != null)
                ApiHelper.AppendUrlWithQueryParameters(queryBuilder, additionalParameters);

            // validate and preprocess url
            string queryUrl = ApiHelper.CleanUrl(queryBuilder);

            return queryUrl;
        }

        /// <summary>
        /// Build basic auth header.
        /// </summary>
        /// <returns> string. </returns>
        private string BuildBasicAuthheader()
        {
            var plainTextBytes = Encoding.UTF8.GetBytes(this.OAuthClientId + ':' + this.OAuthClientSecret);
            return "Basic " + Convert.ToBase64String(plainTextBytes);
        }

        /// <summary>
        /// Checks if client is authorized.
        /// </summary>
        private void CheckAuthorization()
        {
            if (this.OAuthToken == null)
            {
                throw new ApiException(
                        "Client is not authorized. An OAuth token is needed to make API calls.");
            }

            if (IsTokenExpired())
            {
                throw new ApiException(
                        "OAuth token is expired. A valid token is needed to make API calls.");
            }
        }
    }
}