// <copyright file="FinancingsContractInterestRate.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace APIFinancingsOpenBankingBrasil.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using APIFinancingsOpenBankingBrasil.Standard;
    using APIFinancingsOpenBankingBrasil.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// FinancingsContractInterestRate.
    /// </summary>
    public class FinancingsContractInterestRate
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="FinancingsContractInterestRate"/> class.
        /// </summary>
        public FinancingsContractInterestRate()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="FinancingsContractInterestRate"/> class.
        /// </summary>
        /// <param name="taxType">taxType.</param>
        /// <param name="interestRateType">interestRateType.</param>
        /// <param name="taxPeriodicity">taxPeriodicity.</param>
        /// <param name="calculation">calculation.</param>
        /// <param name="referentialRateIndexerType">referentialRateIndexerType.</param>
        /// <param name="referentialRateIndexerSubType">referentialRateIndexerSubType.</param>
        /// <param name="referentialRateIndexerAdditionalInfo">referentialRateIndexerAdditionalInfo.</param>
        /// <param name="preFixedRate">preFixedRate.</param>
        /// <param name="postFixedRate">postFixedRate.</param>
        /// <param name="additionalInfo">additionalInfo.</param>
        public FinancingsContractInterestRate(
            Models.TaxTypeEnum taxType,
            Models.InterestRateTypeEnum interestRateType,
            Models.TaxPeriodicityEnum taxPeriodicity,
            Models.CalculationEnum calculation,
            Models.ReferentialRateIndexerTypeEnum referentialRateIndexerType,
            Models.ReferentialRateIndexerSubTypeEnum? referentialRateIndexerSubType = null,
            string referentialRateIndexerAdditionalInfo = null,
            string preFixedRate = null,
            string postFixedRate = null,
            string additionalInfo = null)
        {
            this.TaxType = taxType;
            this.InterestRateType = interestRateType;
            this.TaxPeriodicity = taxPeriodicity;
            this.Calculation = calculation;
            this.ReferentialRateIndexerType = referentialRateIndexerType;
            this.ReferentialRateIndexerSubType = referentialRateIndexerSubType;
            this.ReferentialRateIndexerAdditionalInfo = referentialRateIndexerAdditionalInfo;
            this.PreFixedRate = preFixedRate;
            this.PostFixedRate = postFixedRate;
            this.AdditionalInfo = additionalInfo;
        }

        /// <summary>
        /// "Tipo de Taxa (vide  Enum)
        /// - NOMINAL (taxa nominal é uma taxa de juros em que a unidade referencial não coincide com a unidade de tempo da capitalização. Ela é sempre fornecida em termos anuais, e seus períodos de capitalização podem ser diários, mensais, trimestrais ou semestrais. p.ex. Uma taxa de 12% ao ano com capitalização mensal)
        /// - EFETIVA (É a taxa de juros em que a unidade referencial coincide com a unidade de tempo da capitalização. Como as unidades de medida de tempo da taxa de juros e dos períodos de capitalização são iguais, usa-se exemplos simples como 1% ao mês, 60% ao ano)"
        /// </summary>
        [JsonProperty("taxType", ItemConverterType = typeof(StringEnumConverter))]
        public Models.TaxTypeEnum TaxType { get; set; }

        /// <summary>
        /// "Tipo de Juros  (vide  Enum)
        /// - SIMPLES (aplicada/cobrada sempre sobre o capital inicial, que é o valor emprestado/investido. Não há cobrança de juros sobre juros acumulados no(s) período(s) anterior(es). Exemplo: em um empréstimo de R$1.000, com taxa de juros simples de 8% a.a., com duração de 2 anos, o total de juros será R$80 no primeiro ano e R$ 80 no segundo ano. Ao final do contrato, o tomador irá devolver o principal e os juros simples de cada ano: R$1.000+R$80+R$80=R$1.160)
        /// - COMPOSTO (para cada período do contrato (diário, mensal, anual etc.), há um “novo capital” para a cobrança da taxa de juros contratada. Esse “novo capital” é a soma do capital e do juro cobrado no período anterior. Exemplo: em um empréstimo de R$1.000, com taxa de juros composta de 8% a.a., com duração de 2 anos, o total de juros será R$80 no primeiro ano. No segundo ano, os juros vão ser somados ao capital (R$1.000 + R$ 80 = R$ 1.080), resultando em juros de R$ 86 (8%de R$ 1.080))"
        /// </summary>
        [JsonProperty("interestRateType", ItemConverterType = typeof(StringEnumConverter))]
        public Models.InterestRateTypeEnum InterestRateType { get; set; }

        /// <summary>
        /// "Periodicidade da taxa . (Vide  Enum)
        /// a.m - ao mês
        /// a.a. - ao ano"
        /// </summary>
        [JsonProperty("taxPeriodicity", ItemConverterType = typeof(StringEnumConverter))]
        public Models.TaxPeriodicityEnum TaxPeriodicity { get; set; }

        /// <summary>
        /// Base de cálculo
        /// </summary>
        [JsonProperty("calculation", ItemConverterType = typeof(StringEnumConverter))]
        public Models.CalculationEnum Calculation { get; set; }

        /// <summary>
        /// "Tipos de taxas referenciais ou indexadores, conforme Anexo 5: Taxa referencial ou Indexador (Indx), do Documento 3040"
        /// </summary>
        [JsonProperty("referentialRateIndexerType", ItemConverterType = typeof(StringEnumConverter))]
        public Models.ReferentialRateIndexerTypeEnum ReferentialRateIndexerType { get; set; }

        /// <summary>
        /// "Sub tipos de taxas referenciais ou indexadores, conforme Anexo 5: Taxa referencial ou Indexador (Indx), do Documento 3040"
        /// </summary>
        [JsonProperty("referentialRateIndexerSubType", ItemConverterType = typeof(StringEnumConverter), NullValueHandling = NullValueHandling.Ignore)]
        public Models.ReferentialRateIndexerSubTypeEnum? ReferentialRateIndexerSubType { get; set; }

        /// <summary>
        /// Campo livre para complementar a informação relativa ao Tipo de taxa referencial ou indexador.
        /// [Restrição] Obrigatório para complementar a informação relativa ao Tipo de taxa referencial ou indexador, quando selecionada o tipo ou subtipo OUTRO.
        /// </summary>
        [JsonProperty("referentialRateIndexerAdditionalInfo", NullValueHandling = NullValueHandling.Ignore)]
        public string ReferentialRateIndexerAdditionalInfo { get; set; }

        /// <summary>
        /// Taxa pré fixada aplicada sob o contrato da modalidade crédito. p.ex. 0.014500.
        /// O preenchimento deve respeitar as 6 casas decimais, mesmo que venham preenchidas com zeros(representação de porcentagem p.ex: 0.150000. Este valor representa 15%. O valor 1 representa 100%).
        /// </summary>
        [JsonProperty("preFixedRate", NullValueHandling = NullValueHandling.Ignore)]
        public string PreFixedRate { get; set; }

        /// <summary>
        /// Taxa pós fixada aplicada sob o contrato da modalidade crédito. p.ex. 0.014500.
        /// O preenchimento deve respeitar as 6 casas decimais, mesmo que venham preenchidas com zeros (representação de porcentagem p.ex: 0.150000. Este valor representa 15%. O valor 1 representa 100%).
        /// </summary>
        [JsonProperty("postFixedRate", NullValueHandling = NullValueHandling.Ignore)]
        public string PostFixedRate { get; set; }

        /// <summary>
        /// Texto com informações adicionais sobre a composição das taxas de juros pactuadas.
        /// [Restrição] Caso a instituição possua a informação para compartilhamento, esta deverá ser informada.
        /// </summary>
        [JsonProperty("additionalInfo", NullValueHandling = NullValueHandling.Ignore)]
        public string AdditionalInfo { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"FinancingsContractInterestRate : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is FinancingsContractInterestRate other &&
                this.TaxType.Equals(other.TaxType) &&
                this.InterestRateType.Equals(other.InterestRateType) &&
                this.TaxPeriodicity.Equals(other.TaxPeriodicity) &&
                this.Calculation.Equals(other.Calculation) &&
                this.ReferentialRateIndexerType.Equals(other.ReferentialRateIndexerType) &&
                ((this.ReferentialRateIndexerSubType == null && other.ReferentialRateIndexerSubType == null) || (this.ReferentialRateIndexerSubType?.Equals(other.ReferentialRateIndexerSubType) == true)) &&
                ((this.ReferentialRateIndexerAdditionalInfo == null && other.ReferentialRateIndexerAdditionalInfo == null) || (this.ReferentialRateIndexerAdditionalInfo?.Equals(other.ReferentialRateIndexerAdditionalInfo) == true)) &&
                ((this.PreFixedRate == null && other.PreFixedRate == null) || (this.PreFixedRate?.Equals(other.PreFixedRate) == true)) &&
                ((this.PostFixedRate == null && other.PostFixedRate == null) || (this.PostFixedRate?.Equals(other.PostFixedRate) == true)) &&
                ((this.AdditionalInfo == null && other.AdditionalInfo == null) || (this.AdditionalInfo?.Equals(other.AdditionalInfo) == true));
        }
        

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.TaxType = {this.TaxType}");
            toStringOutput.Add($"this.InterestRateType = {this.InterestRateType}");
            toStringOutput.Add($"this.TaxPeriodicity = {this.TaxPeriodicity}");
            toStringOutput.Add($"this.Calculation = {this.Calculation}");
            toStringOutput.Add($"this.ReferentialRateIndexerType = {this.ReferentialRateIndexerType}");
            toStringOutput.Add($"this.ReferentialRateIndexerSubType = {(this.ReferentialRateIndexerSubType == null ? "null" : this.ReferentialRateIndexerSubType.ToString())}");
            toStringOutput.Add($"this.ReferentialRateIndexerAdditionalInfo = {(this.ReferentialRateIndexerAdditionalInfo == null ? "null" : this.ReferentialRateIndexerAdditionalInfo == string.Empty ? "" : this.ReferentialRateIndexerAdditionalInfo)}");
            toStringOutput.Add($"this.PreFixedRate = {(this.PreFixedRate == null ? "null" : this.PreFixedRate == string.Empty ? "" : this.PreFixedRate)}");
            toStringOutput.Add($"this.PostFixedRate = {(this.PostFixedRate == null ? "null" : this.PostFixedRate == string.Empty ? "" : this.PostFixedRate)}");
            toStringOutput.Add($"this.AdditionalInfo = {(this.AdditionalInfo == null ? "null" : this.AdditionalInfo == string.Empty ? "" : this.AdditionalInfo)}");
        }
    }
}