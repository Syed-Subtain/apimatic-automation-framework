// <copyright file="Meta.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace APIFinancingsOpenBankingBrasil.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using APIFinancingsOpenBankingBrasil.Standard;
    using APIFinancingsOpenBankingBrasil.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// Meta.
    /// </summary>
    public class Meta
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="Meta"/> class.
        /// </summary>
        public Meta()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="Meta"/> class.
        /// </summary>
        /// <param name="totalRecords">totalRecords.</param>
        /// <param name="totalPages">totalPages.</param>
        /// <param name="requestDateTime">requestDateTime.</param>
        public Meta(
            int totalRecords,
            int totalPages,
            DateTime requestDateTime)
        {
            this.TotalRecords = totalRecords;
            this.TotalPages = totalPages;
            this.RequestDateTime = requestDateTime;
        }

        /// <summary>
        /// Número total de registros no resultado
        /// </summary>
        [JsonProperty("totalRecords")]
        public int TotalRecords { get; set; }

        /// <summary>
        /// Número total de páginas no resultado
        /// </summary>
        [JsonProperty("totalPages")]
        public int TotalPages { get; set; }

        /// <summary>
        /// Data e hora da consulta, conforme especificação RFC-3339, formato UTC.
        /// </summary>
        [JsonConverter(typeof(IsoDateTimeConverter))]
        [JsonProperty("requestDateTime")]
        public DateTime RequestDateTime { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"Meta : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is Meta other &&
                this.TotalRecords.Equals(other.TotalRecords) &&
                this.TotalPages.Equals(other.TotalPages) &&
                this.RequestDateTime.Equals(other.RequestDateTime);
        }
        

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.TotalRecords = {this.TotalRecords}");
            toStringOutput.Add($"this.TotalPages = {this.TotalPages}");
            toStringOutput.Add($"this.RequestDateTime = {this.RequestDateTime}");
        }
    }
}