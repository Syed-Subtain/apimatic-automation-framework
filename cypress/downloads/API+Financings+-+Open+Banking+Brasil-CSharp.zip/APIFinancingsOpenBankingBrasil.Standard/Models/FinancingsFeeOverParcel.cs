// <copyright file="FinancingsFeeOverParcel.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace APIFinancingsOpenBankingBrasil.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using APIFinancingsOpenBankingBrasil.Standard;
    using APIFinancingsOpenBankingBrasil.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// FinancingsFeeOverParcel.
    /// </summary>
    public class FinancingsFeeOverParcel
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="FinancingsFeeOverParcel"/> class.
        /// </summary>
        public FinancingsFeeOverParcel()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="FinancingsFeeOverParcel"/> class.
        /// </summary>
        /// <param name="feeName">feeName.</param>
        /// <param name="feeCode">feeCode.</param>
        /// <param name="feeAmount">feeAmount.</param>
        public FinancingsFeeOverParcel(
            string feeName,
            string feeCode,
            string feeAmount)
        {
            this.FeeName = feeName;
            this.FeeCode = feeCode;
            this.FeeAmount = feeAmount;
        }

        /// <summary>
        /// Denominação da Tarifa pactuada.
        /// </summary>
        [JsonProperty("feeName")]
        public string FeeName { get; set; }

        /// <summary>
        /// Sigla identificadora da tarifa pactuada.
        /// </summary>
        [JsonProperty("feeCode")]
        public string FeeCode { get; set; }

        /// <summary>
        /// Valor monetário da tarifa pactuada no contrato.
        /// Expresso em valor monetário com no mínimo 2 casas e no máximo 4 casas decimais.
        /// </summary>
        [JsonProperty("feeAmount")]
        public string FeeAmount { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"FinancingsFeeOverParcel : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is FinancingsFeeOverParcel other &&
                ((this.FeeName == null && other.FeeName == null) || (this.FeeName?.Equals(other.FeeName) == true)) &&
                ((this.FeeCode == null && other.FeeCode == null) || (this.FeeCode?.Equals(other.FeeCode) == true)) &&
                ((this.FeeAmount == null && other.FeeAmount == null) || (this.FeeAmount?.Equals(other.FeeAmount) == true));
        }
        

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.FeeName = {(this.FeeName == null ? "null" : this.FeeName == string.Empty ? "" : this.FeeName)}");
            toStringOutput.Add($"this.FeeCode = {(this.FeeCode == null ? "null" : this.FeeCode == string.Empty ? "" : this.FeeCode)}");
            toStringOutput.Add($"this.FeeAmount = {(this.FeeAmount == null ? "null" : this.FeeAmount == string.Empty ? "" : this.FeeAmount)}");
        }
    }
}