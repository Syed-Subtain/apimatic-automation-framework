// <copyright file="FinancingsContractFee.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace APIFinancingsOpenBankingBrasil.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using APIFinancingsOpenBankingBrasil.Standard;
    using APIFinancingsOpenBankingBrasil.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// FinancingsContractFee.
    /// </summary>
    public class FinancingsContractFee
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="FinancingsContractFee"/> class.
        /// </summary>
        public FinancingsContractFee()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="FinancingsContractFee"/> class.
        /// </summary>
        /// <param name="feeName">feeName.</param>
        /// <param name="feeCode">feeCode.</param>
        /// <param name="feeChargeType">feeChargeType.</param>
        /// <param name="feeCharge">feeCharge.</param>
        /// <param name="feeAmount">feeAmount.</param>
        /// <param name="feeRate">feeRate.</param>
        public FinancingsContractFee(
            string feeName,
            string feeCode,
            Models.FeeChargeTypeEnum feeChargeType,
            Models.FeeChargeEnum feeCharge,
            string feeAmount = null,
            string feeRate = null)
        {
            this.FeeName = feeName;
            this.FeeCode = feeCode;
            this.FeeChargeType = feeChargeType;
            this.FeeCharge = feeCharge;
            this.FeeAmount = feeAmount;
            this.FeeRate = feeRate;
        }

        /// <summary>
        /// Denominação da Tarifa pactuada
        /// </summary>
        [JsonProperty("feeName")]
        public string FeeName { get; set; }

        /// <summary>
        /// Sigla identificadora da tarifa pactuada
        /// </summary>
        [JsonProperty("feeCode")]
        public string FeeCode { get; set; }

        /// <summary>
        /// Tipo de cobrança para a tarifa pactuada no contrato.
        /// </summary>
        [JsonProperty("feeChargeType", ItemConverterType = typeof(StringEnumConverter))]
        public Models.FeeChargeTypeEnum FeeChargeType { get; set; }

        /// <summary>
        /// "Forma de cobrança relativa a tarifa pactuada no contrato. (Vide Enum)
        /// - Mínimo
        /// - Máximo
        /// - Fixo
        /// - Percentual"
        /// </summary>
        [JsonProperty("feeCharge", ItemConverterType = typeof(StringEnumConverter))]
        public Models.FeeChargeEnum FeeCharge { get; set; }

        /// <summary>
        /// Valor monetário da tarifa pactuada no contrato.
        /// [Restrição] Preenchimento obrigatório quando a forma de cobrança for diferente de Percentual.
        /// </summary>
        [JsonProperty("feeAmount", NullValueHandling = NullValueHandling.Ignore)]
        public string FeeAmount { get; set; }

        /// <summary>
        /// É o valor da tarifa em percentual pactuada no contrato.
        /// [Restrição] Preenchimento obrigatório quando a forma de cobrança for Percentual.
        /// </summary>
        [JsonProperty("feeRate", NullValueHandling = NullValueHandling.Ignore)]
        public string FeeRate { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"FinancingsContractFee : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is FinancingsContractFee other &&
                ((this.FeeName == null && other.FeeName == null) || (this.FeeName?.Equals(other.FeeName) == true)) &&
                ((this.FeeCode == null && other.FeeCode == null) || (this.FeeCode?.Equals(other.FeeCode) == true)) &&
                this.FeeChargeType.Equals(other.FeeChargeType) &&
                this.FeeCharge.Equals(other.FeeCharge) &&
                ((this.FeeAmount == null && other.FeeAmount == null) || (this.FeeAmount?.Equals(other.FeeAmount) == true)) &&
                ((this.FeeRate == null && other.FeeRate == null) || (this.FeeRate?.Equals(other.FeeRate) == true));
        }
        

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.FeeName = {(this.FeeName == null ? "null" : this.FeeName == string.Empty ? "" : this.FeeName)}");
            toStringOutput.Add($"this.FeeCode = {(this.FeeCode == null ? "null" : this.FeeCode == string.Empty ? "" : this.FeeCode)}");
            toStringOutput.Add($"this.FeeChargeType = {this.FeeChargeType}");
            toStringOutput.Add($"this.FeeCharge = {this.FeeCharge}");
            toStringOutput.Add($"this.FeeAmount = {(this.FeeAmount == null ? "null" : this.FeeAmount == string.Empty ? "" : this.FeeAmount)}");
            toStringOutput.Add($"this.FeeRate = {(this.FeeRate == null ? "null" : this.FeeRate == string.Empty ? "" : this.FeeRate)}");
        }
    }
}