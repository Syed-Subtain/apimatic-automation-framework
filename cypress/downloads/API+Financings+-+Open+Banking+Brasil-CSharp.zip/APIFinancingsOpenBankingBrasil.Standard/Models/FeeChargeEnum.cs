// <copyright file="FeeChargeEnum.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace APIFinancingsOpenBankingBrasil.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Runtime.Serialization;
    using APIFinancingsOpenBankingBrasil.Standard;
    using APIFinancingsOpenBankingBrasil.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// FeeChargeEnum.
    /// </summary>
    [JsonConverter(typeof(StringEnumConverter))]
    public enum FeeChargeEnum
    {
        /// <summary>
        /// MINIMO.
        /// </summary>
        [EnumMember(Value = "MINIMO")]
        MINIMO,

        /// <summary>
        /// MAXIMO.
        /// </summary>
        [EnumMember(Value = "MAXIMO")]
        MAXIMO,

        /// <summary>
        /// FIXO.
        /// </summary>
        [EnumMember(Value = "FIXO")]
        FIXO,

        /// <summary>
        /// PERCENTUAL.
        /// </summary>
        [EnumMember(Value = "PERCENTUAL")]
        PERCENTUAL
    }
}