// <copyright file="InterestRateTypeEnum.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace APIFinancingsOpenBankingBrasil.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Runtime.Serialization;
    using APIFinancingsOpenBankingBrasil.Standard;
    using APIFinancingsOpenBankingBrasil.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// InterestRateTypeEnum.
    /// </summary>
    [JsonConverter(typeof(StringEnumConverter))]
    public enum InterestRateTypeEnum
    {
        /// <summary>
        /// SIMPLES.
        /// </summary>
        [EnumMember(Value = "SIMPLES")]
        SIMPLES,

        /// <summary>
        /// COMPOSTO.
        /// </summary>
        [EnumMember(Value = "COMPOSTO")]
        COMPOSTO
    }
}