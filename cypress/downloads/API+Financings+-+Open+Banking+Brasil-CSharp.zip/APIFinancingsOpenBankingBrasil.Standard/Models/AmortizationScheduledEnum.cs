// <copyright file="AmortizationScheduledEnum.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace APIFinancingsOpenBankingBrasil.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Runtime.Serialization;
    using APIFinancingsOpenBankingBrasil.Standard;
    using APIFinancingsOpenBankingBrasil.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// AmortizationScheduledEnum.
    /// </summary>
    [JsonConverter(typeof(StringEnumConverter))]
    public enum AmortizationScheduledEnum
    {
        /// <summary>
        /// SAC.
        /// </summary>
        [EnumMember(Value = "SAC")]
        SAC,

        /// <summary>
        /// PRICE.
        /// </summary>
        [EnumMember(Value = "PRICE")]
        PRICE,

        /// <summary>
        /// SAM.
        /// </summary>
        [EnumMember(Value = "SAM")]
        SAM,

        /// <summary>
        /// SEMSISTEMAAMORTIZACAO.
        /// </summary>
        [EnumMember(Value = "SEM_SISTEMA_AMORTIZACAO")]
        SEMSISTEMAAMORTIZACAO,

        /// <summary>
        /// OUTROS.
        /// </summary>
        [EnumMember(Value = "OUTROS")]
        OUTROS
    }
}