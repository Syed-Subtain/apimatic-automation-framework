// <copyright file="ReferentialRateIndexerSubTypeEnum.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace APIFinancingsOpenBankingBrasil.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Runtime.Serialization;
    using APIFinancingsOpenBankingBrasil.Standard;
    using APIFinancingsOpenBankingBrasil.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// ReferentialRateIndexerSubTypeEnum.
    /// </summary>
    [JsonConverter(typeof(StringEnumConverter))]
    public enum ReferentialRateIndexerSubTypeEnum
    {
        /// <summary>
        /// SEMSUBTIPOINDEXADOR.
        /// </summary>
        [EnumMember(Value = "SEM_SUB_TIPO_INDEXADOR")]
        SEMSUBTIPOINDEXADOR,

        /// <summary>
        /// PREFIXADO.
        /// </summary>
        [EnumMember(Value = "PRE_FIXADO")]
        PREFIXADO,

        /// <summary>
        /// TRTBF.
        /// </summary>
        [EnumMember(Value = "TR_TBF")]
        TRTBF,

        /// <summary>
        /// TJLP.
        /// </summary>
        [EnumMember(Value = "TJLP")]
        TJLP,

        /// <summary>
        /// LIBOR.
        /// </summary>
        [EnumMember(Value = "LIBOR")]
        LIBOR,

        /// <summary>
        /// TLP.
        /// </summary>
        [EnumMember(Value = "TLP")]
        TLP,

        /// <summary>
        /// OUTRASTAXASPOSFIXADAS.
        /// </summary>
        [EnumMember(Value = "OUTRAS_TAXAS_POS_FIXADAS")]
        OUTRASTAXASPOSFIXADAS,

        /// <summary>
        /// CDI.
        /// </summary>
        [EnumMember(Value = "CDI")]
        CDI,

        /// <summary>
        /// SELIC.
        /// </summary>
        [EnumMember(Value = "SELIC")]
        SELIC,

        /// <summary>
        /// OUTRASTAXASFLUTUANTES.
        /// </summary>
        [EnumMember(Value = "OUTRAS_TAXAS_FLUTUANTES")]
        OUTRASTAXASFLUTUANTES,

        /// <summary>
        /// IGPM.
        /// </summary>
        [EnumMember(Value = "IGPM")]
        IGPM,

        /// <summary>
        /// IPCA.
        /// </summary>
        [EnumMember(Value = "IPCA")]
        IPCA,

        /// <summary>
        /// IPCC.
        /// </summary>
        [EnumMember(Value = "IPCC")]
        IPCC,

        /// <summary>
        /// OUTROSINDICESPRECO.
        /// </summary>
        [EnumMember(Value = "OUTROS_INDICES_PRECO")]
        OUTROSINDICESPRECO,

        /// <summary>
        /// TCRPRE.
        /// </summary>
        [EnumMember(Value = "TCR_PRE")]
        TCRPRE,

        /// <summary>
        /// TCRPOS.
        /// </summary>
        [EnumMember(Value = "TCR_POS")]
        TCRPOS,

        /// <summary>
        /// TRFCPRE.
        /// </summary>
        [EnumMember(Value = "TRFC_PRE")]
        TRFCPRE,

        /// <summary>
        /// TRFCPOS.
        /// </summary>
        [EnumMember(Value = "TRFC_POS")]
        TRFCPOS,

        /// <summary>
        /// OUTROSINDEXADORES.
        /// </summary>
        [EnumMember(Value = "OUTROS_INDEXADORES")]
        OUTROSINDEXADORES
    }
}