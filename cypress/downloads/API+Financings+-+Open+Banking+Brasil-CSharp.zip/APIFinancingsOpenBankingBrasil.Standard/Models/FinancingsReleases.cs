// <copyright file="FinancingsReleases.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace APIFinancingsOpenBankingBrasil.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using APIFinancingsOpenBankingBrasil.Standard;
    using APIFinancingsOpenBankingBrasil.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// FinancingsReleases.
    /// </summary>
    public class FinancingsReleases
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="FinancingsReleases"/> class.
        /// </summary>
        public FinancingsReleases()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="FinancingsReleases"/> class.
        /// </summary>
        /// <param name="isOverParcelPayment">isOverParcelPayment.</param>
        /// <param name="paidDate">paidDate.</param>
        /// <param name="currency">currency.</param>
        /// <param name="paidAmount">paidAmount.</param>
        /// <param name="paymentId">paymentId.</param>
        /// <param name="instalmentId">instalmentId.</param>
        /// <param name="overParcel">overParcel.</param>
        public FinancingsReleases(
            bool isOverParcelPayment,
            DateTime paidDate,
            string currency,
            string paidAmount,
            string paymentId = null,
            string instalmentId = null,
            Models.FinancingsOverParcel overParcel = null)
        {
            this.PaymentId = paymentId;
            this.IsOverParcelPayment = isOverParcelPayment;
            this.InstalmentId = instalmentId;
            this.PaidDate = paidDate;
            this.Currency = currency;
            this.PaidAmount = paidAmount;
            this.OverParcel = overParcel;
        }

        /// <summary>
        /// Identificador de pagamento de responsabilidade de cada Instituição transmissora.
        /// </summary>
        [JsonProperty("paymentId", NullValueHandling = NullValueHandling.Ignore)]
        public string PaymentId { get; set; }

        /// <summary>
        /// Identifica se é um pagamento pactuado (false) ou avulso (true).
        /// </summary>
        [JsonProperty("isOverParcelPayment")]
        public bool IsOverParcelPayment { get; set; }

        /// <summary>
        /// Identificador de parcela, de responsabilidade de cada Instituição transmissora.
        /// [Restrição] Informação de envio obrigatório quando isOverParcelPayment tiver o valor FALSE.
        /// </summary>
        [JsonProperty("instalmentId", NullValueHandling = NullValueHandling.Ignore)]
        public string InstalmentId { get; set; }

        /// <summary>
        /// Data efetiva do pagamento referente ao contrato da modalidade de crédito consultada, conforme especificação RFC-3339. p.ex. 2014-03-19
        /// </summary>
        [JsonConverter(typeof(CustomDateTimeConverter), "yyyy'-'MM'-'dd")]
        [JsonProperty("paidDate")]
        public DateTime PaidDate { get; set; }

        /// <summary>
        /// Moeda referente ao valor monetário informado, segundo modelo ISO-4217. p.ex. 'BRL'.
        /// Todos os valores monetários informados estão representados com a moeda vigente do Brasil.
        /// </summary>
        [JsonProperty("currency")]
        public string Currency { get; set; }

        /// <summary>
        /// Valor do pagamento referente ao  contrato da modalidade de crédito consultada.
        /// Expresso em valor monetário com no mínimo 2 casas e no máximo 4 casas decimais.
        /// </summary>
        [JsonProperty("paidAmount")]
        public string PaidAmount { get; set; }

        /// <summary>
        /// Objeto das tarifas e encargos que foram pagos fora da parcela.
        /// [Restrição] Informação deve ser enviada caso ela exista.
        /// </summary>
        [JsonProperty("overParcel", NullValueHandling = NullValueHandling.Ignore)]
        public Models.FinancingsOverParcel OverParcel { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"FinancingsReleases : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is FinancingsReleases other &&
                ((this.PaymentId == null && other.PaymentId == null) || (this.PaymentId?.Equals(other.PaymentId) == true)) &&
                this.IsOverParcelPayment.Equals(other.IsOverParcelPayment) &&
                ((this.InstalmentId == null && other.InstalmentId == null) || (this.InstalmentId?.Equals(other.InstalmentId) == true)) &&
                this.PaidDate.Equals(other.PaidDate) &&
                ((this.Currency == null && other.Currency == null) || (this.Currency?.Equals(other.Currency) == true)) &&
                ((this.PaidAmount == null && other.PaidAmount == null) || (this.PaidAmount?.Equals(other.PaidAmount) == true)) &&
                ((this.OverParcel == null && other.OverParcel == null) || (this.OverParcel?.Equals(other.OverParcel) == true));
        }
        

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.PaymentId = {(this.PaymentId == null ? "null" : this.PaymentId == string.Empty ? "" : this.PaymentId)}");
            toStringOutput.Add($"this.IsOverParcelPayment = {this.IsOverParcelPayment}");
            toStringOutput.Add($"this.InstalmentId = {(this.InstalmentId == null ? "null" : this.InstalmentId == string.Empty ? "" : this.InstalmentId)}");
            toStringOutput.Add($"this.PaidDate = {this.PaidDate}");
            toStringOutput.Add($"this.Currency = {(this.Currency == null ? "null" : this.Currency == string.Empty ? "" : this.Currency)}");
            toStringOutput.Add($"this.PaidAmount = {(this.PaidAmount == null ? "null" : this.PaidAmount == string.Empty ? "" : this.PaidAmount)}");
            toStringOutput.Add($"this.OverParcel = {(this.OverParcel == null ? "null" : this.OverParcel.ToString())}");
        }
    }
}