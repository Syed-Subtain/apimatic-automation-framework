// <copyright file="FinancingsChargeOverParcel.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace APIFinancingsOpenBankingBrasil.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using APIFinancingsOpenBankingBrasil.Standard;
    using APIFinancingsOpenBankingBrasil.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// FinancingsChargeOverParcel.
    /// </summary>
    public class FinancingsChargeOverParcel
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="FinancingsChargeOverParcel"/> class.
        /// </summary>
        public FinancingsChargeOverParcel()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="FinancingsChargeOverParcel"/> class.
        /// </summary>
        /// <param name="chargeType">chargeType.</param>
        /// <param name="chargeAmount">chargeAmount.</param>
        /// <param name="chargeAdditionalInfo">chargeAdditionalInfo.</param>
        public FinancingsChargeOverParcel(
            Models.EnumContractFinanceChargeTypeEnum chargeType,
            string chargeAmount,
            string chargeAdditionalInfo = null)
        {
            this.ChargeType = chargeType;
            this.ChargeAmount = chargeAmount;
            this.ChargeAdditionalInfo = chargeAdditionalInfo;
        }

        /// <summary>
        /// Tipo de encargo pactuado no contrato.
        /// </summary>
        [JsonProperty("chargeType", ItemConverterType = typeof(StringEnumConverter))]
        public Models.EnumContractFinanceChargeTypeEnum ChargeType { get; set; }

        /// <summary>
        /// Valor do pagamento do encargo pago fora da parcela. Expresso em valor monetário com no mínimo 2 casas e no máximo 4 casas decimais.
        /// </summary>
        [JsonProperty("chargeAmount")]
        public string ChargeAmount { get; set; }

        /// <summary>
        /// Campo livre para preenchimento das informações adicionais referente ao encargo.
        /// [Restrição] Obrigatório quando chargeType for igual 'OUTROS'.
        /// </summary>
        [JsonProperty("chargeAdditionalInfo", NullValueHandling = NullValueHandling.Ignore)]
        public string ChargeAdditionalInfo { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"FinancingsChargeOverParcel : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is FinancingsChargeOverParcel other &&
                this.ChargeType.Equals(other.ChargeType) &&
                ((this.ChargeAmount == null && other.ChargeAmount == null) || (this.ChargeAmount?.Equals(other.ChargeAmount) == true)) &&
                ((this.ChargeAdditionalInfo == null && other.ChargeAdditionalInfo == null) || (this.ChargeAdditionalInfo?.Equals(other.ChargeAdditionalInfo) == true));
        }
        

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.ChargeType = {this.ChargeType}");
            toStringOutput.Add($"this.ChargeAmount = {(this.ChargeAmount == null ? "null" : this.ChargeAmount == string.Empty ? "" : this.ChargeAmount)}");
            toStringOutput.Add($"this.ChargeAdditionalInfo = {(this.ChargeAdditionalInfo == null ? "null" : this.ChargeAdditionalInfo == string.Empty ? "" : this.ChargeAdditionalInfo)}");
        }
    }
}