// <copyright file="AuthorizationCodeScopeEnum.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace APIFinancingsOpenBankingBrasil.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Runtime.Serialization;
    using APIFinancingsOpenBankingBrasil.Standard;
    using APIFinancingsOpenBankingBrasil.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// AuthorizationCodeScopeEnum.
    /// </summary>
    [JsonConverter(typeof(StringEnumConverter))]
    public enum AuthorizationCodeScopeEnum
    {
        /// <summary>
        /// Openid.
        /// </summary>
        [EnumMember(Value = "openid")]
        Openid,

        /// <summary>
        ///Escopo necessário para acesso à API Financings. O controle dos endpoints específicos é feito via permissions.
        /// Financings.
        /// </summary>
        [EnumMember(Value = "financings")]
        Financings,

        /// <summary>
        /// ConsentconsentId.
        /// </summary>
        [EnumMember(Value = "consent:consentId")]
        ConsentconsentId
    }
}