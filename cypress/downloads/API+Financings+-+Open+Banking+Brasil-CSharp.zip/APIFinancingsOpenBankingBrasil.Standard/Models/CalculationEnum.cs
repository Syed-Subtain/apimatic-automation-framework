// <copyright file="CalculationEnum.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace APIFinancingsOpenBankingBrasil.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Runtime.Serialization;
    using APIFinancingsOpenBankingBrasil.Standard;
    using APIFinancingsOpenBankingBrasil.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// CalculationEnum.
    /// </summary>
    [JsonConverter(typeof(StringEnumConverter))]
    public enum CalculationEnum
    {
        /// <summary>
        /// Enum21252.
        /// </summary>
        [EnumMember(Value = "21/252")]
        Enum21252,

        /// <summary>
        /// Enum30360.
        /// </summary>
        [EnumMember(Value = "30/360")]
        Enum30360,

        /// <summary>
        /// Enum30365.
        /// </summary>
        [EnumMember(Value = "30/365")]
        Enum30365
    }
}