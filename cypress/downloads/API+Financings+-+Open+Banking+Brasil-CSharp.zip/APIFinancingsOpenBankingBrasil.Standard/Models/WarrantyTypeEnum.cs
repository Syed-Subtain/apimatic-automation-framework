// <copyright file="WarrantyTypeEnum.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace APIFinancingsOpenBankingBrasil.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Runtime.Serialization;
    using APIFinancingsOpenBankingBrasil.Standard;
    using APIFinancingsOpenBankingBrasil.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// WarrantyTypeEnum.
    /// </summary>
    [JsonConverter(typeof(StringEnumConverter))]
    public enum WarrantyTypeEnum
    {
        /// <summary>
        /// CESSAODIREITOSCREDITORIOS.
        /// </summary>
        [EnumMember(Value = "CESSAO_DIREITOS_CREDITORIOS")]
        CESSAODIREITOSCREDITORIOS,

        /// <summary>
        /// CAUCAO.
        /// </summary>
        [EnumMember(Value = "CAUCAO")]
        CAUCAO,

        /// <summary>
        /// PENHOR.
        /// </summary>
        [EnumMember(Value = "PENHOR")]
        PENHOR,

        /// <summary>
        /// ALIENACAOFIDUCIARIA.
        /// </summary>
        [EnumMember(Value = "ALIENACAO_FIDUCIARIA")]
        ALIENACAOFIDUCIARIA,

        /// <summary>
        /// HIPOTECA.
        /// </summary>
        [EnumMember(Value = "HIPOTECA")]
        HIPOTECA,

        /// <summary>
        /// OPERACOESGARANTIDASPELOGOVERNO.
        /// </summary>
        [EnumMember(Value = "OPERACOES_GARANTIDAS_PELO_GOVERNO")]
        OPERACOESGARANTIDASPELOGOVERNO,

        /// <summary>
        /// OUTRASGARANTIASNAOFIDEJUSSORIAS.
        /// </summary>
        [EnumMember(Value = "OUTRAS_GARANTIAS_NAO_FIDEJUSSORIAS")]
        OUTRASGARANTIASNAOFIDEJUSSORIAS,

        /// <summary>
        /// SEGUROSASSEMELHADOS.
        /// </summary>
        [EnumMember(Value = "SEGUROS_ASSEMELHADOS")]
        SEGUROSASSEMELHADOS,

        /// <summary>
        /// GARANTIAFIDEJUSSORIA.
        /// </summary>
        [EnumMember(Value = "GARANTIA_FIDEJUSSORIA")]
        GARANTIAFIDEJUSSORIA,

        /// <summary>
        /// BENSARRENDADOS.
        /// </summary>
        [EnumMember(Value = "BENS_ARRENDADOS")]
        BENSARRENDADOS,

        /// <summary>
        /// GARANTIASINTERNACIONAIS.
        /// </summary>
        [EnumMember(Value = "GARANTIAS_INTERNACIONAIS")]
        GARANTIASINTERNACIONAIS,

        /// <summary>
        /// OPERACOESGARANTIDASOUTRASENTIDADES.
        /// </summary>
        [EnumMember(Value = "OPERACOES_GARANTIDAS_OUTRAS_ENTIDADES")]
        OPERACOESGARANTIDASOUTRASENTIDADES,

        /// <summary>
        /// ACORDOSCOMPENSACAO.
        /// </summary>
        [EnumMember(Value = "ACORDOS_COMPENSACAO")]
        ACORDOSCOMPENSACAO
    }
}