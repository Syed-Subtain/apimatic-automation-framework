// <copyright file="FinancingsBalloonPayment.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace APIFinancingsOpenBankingBrasil.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using APIFinancingsOpenBankingBrasil.Standard;
    using APIFinancingsOpenBankingBrasil.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// FinancingsBalloonPayment.
    /// </summary>
    public class FinancingsBalloonPayment
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="FinancingsBalloonPayment"/> class.
        /// </summary>
        public FinancingsBalloonPayment()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="FinancingsBalloonPayment"/> class.
        /// </summary>
        /// <param name="dueDate">dueDate.</param>
        /// <param name="amount">amount.</param>
        public FinancingsBalloonPayment(
            DateTime dueDate,
            Models.FinancingsBalloonPaymentAmount amount)
        {
            this.DueDate = dueDate;
            this.Amount = amount;
        }

        /// <summary>
        /// Data de vencimento da parcela não regular  a vencer do contrato da modalidade de crédito consultada, conforme especificação RFC-3339. p.ex. 2014-03-19
        /// </summary>
        [JsonConverter(typeof(CustomDateTimeConverter), "yyyy'-'MM'-'dd")]
        [JsonProperty("dueDate")]
        public DateTime DueDate { get; set; }

        /// <summary>
        /// Valor monetário da parcela não regular a vencer
        /// </summary>
        [JsonProperty("amount")]
        public Models.FinancingsBalloonPaymentAmount Amount { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"FinancingsBalloonPayment : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is FinancingsBalloonPayment other &&
                this.DueDate.Equals(other.DueDate) &&
                ((this.Amount == null && other.Amount == null) || (this.Amount?.Equals(other.Amount) == true));
        }
        

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.DueDate = {this.DueDate}");
            toStringOutput.Add($"this.Amount = {(this.Amount == null ? "null" : this.Amount.ToString())}");
        }
    }
}