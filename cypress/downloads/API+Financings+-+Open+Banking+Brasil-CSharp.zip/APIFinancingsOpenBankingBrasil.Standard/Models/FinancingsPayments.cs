// <copyright file="FinancingsPayments.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace APIFinancingsOpenBankingBrasil.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using APIFinancingsOpenBankingBrasil.Standard;
    using APIFinancingsOpenBankingBrasil.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// FinancingsPayments.
    /// </summary>
    public class FinancingsPayments
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="FinancingsPayments"/> class.
        /// </summary>
        public FinancingsPayments()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="FinancingsPayments"/> class.
        /// </summary>
        /// <param name="contractOutstandingBalance">contractOutstandingBalance.</param>
        /// <param name="releases">releases.</param>
        /// <param name="paidInstalments">paidInstalments.</param>
        public FinancingsPayments(
            string contractOutstandingBalance,
            List<Models.FinancingsReleases> releases,
            double? paidInstalments = null)
        {
            this.PaidInstalments = paidInstalments;
            this.ContractOutstandingBalance = contractOutstandingBalance;
            this.Releases = releases;
        }

        /// <summary>
        /// Quantidade total de parcelas pagas do contrato referente à Modalidade de Crédito informada.
        /// [Restrição] Obrigatório para modalidades que possuam parcelas.
        /// </summary>
        [JsonProperty("paidInstalments", NullValueHandling = NullValueHandling.Ignore)]
        public double? PaidInstalments { get; set; }

        /// <summary>
        /// Valor necessario para o cliente liquidar a dívida.
        /// </summary>
        [JsonProperty("contractOutstandingBalance")]
        public string ContractOutstandingBalance { get; set; }

        /// <summary>
        /// Lista dos pagamentos realizados no período
        /// </summary>
        [JsonProperty("releases")]
        public List<Models.FinancingsReleases> Releases { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"FinancingsPayments : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is FinancingsPayments other &&
                ((this.PaidInstalments == null && other.PaidInstalments == null) || (this.PaidInstalments?.Equals(other.PaidInstalments) == true)) &&
                ((this.ContractOutstandingBalance == null && other.ContractOutstandingBalance == null) || (this.ContractOutstandingBalance?.Equals(other.ContractOutstandingBalance) == true)) &&
                ((this.Releases == null && other.Releases == null) || (this.Releases?.Equals(other.Releases) == true));
        }
        

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.PaidInstalments = {(this.PaidInstalments == null ? "null" : this.PaidInstalments.ToString())}");
            toStringOutput.Add($"this.ContractOutstandingBalance = {(this.ContractOutstandingBalance == null ? "null" : this.ContractOutstandingBalance == string.Empty ? "" : this.ContractOutstandingBalance)}");
            toStringOutput.Add($"this.Releases = {(this.Releases == null ? "null" : $"[{string.Join(", ", this.Releases)} ]")}");
        }
    }
}