// <copyright file="FinancingsInstalments.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace APIFinancingsOpenBankingBrasil.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using APIFinancingsOpenBankingBrasil.Standard;
    using APIFinancingsOpenBankingBrasil.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// FinancingsInstalments.
    /// </summary>
    public class FinancingsInstalments
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="FinancingsInstalments"/> class.
        /// </summary>
        public FinancingsInstalments()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="FinancingsInstalments"/> class.
        /// </summary>
        /// <param name="typeNumberOfInstalments">typeNumberOfInstalments.</param>
        /// <param name="typeContractRemaining">typeContractRemaining.</param>
        /// <param name="paidInstalments">paidInstalments.</param>
        /// <param name="totalNumberOfInstalments">totalNumberOfInstalments.</param>
        /// <param name="contractRemainingNumber">contractRemainingNumber.</param>
        /// <param name="dueInstalments">dueInstalments.</param>
        /// <param name="pastDueInstalments">pastDueInstalments.</param>
        /// <param name="balloonPayments">balloonPayments.</param>
        public FinancingsInstalments(
            Models.TypeNumberOfInstalmentsEnum typeNumberOfInstalments,
            Models.TypeContractRemainingEnum typeContractRemaining,
            double paidInstalments,
            double? totalNumberOfInstalments = null,
            double? contractRemainingNumber = null,
            double? dueInstalments = null,
            double? pastDueInstalments = null,
            List<Models.FinancingsBalloonPayment> balloonPayments = null)
        {
            this.TypeNumberOfInstalments = typeNumberOfInstalments;
            this.TotalNumberOfInstalments = totalNumberOfInstalments;
            this.TypeContractRemaining = typeContractRemaining;
            this.ContractRemainingNumber = contractRemainingNumber;
            this.PaidInstalments = paidInstalments;
            this.DueInstalments = dueInstalments;
            this.PastDueInstalments = pastDueInstalments;
            this.BalloonPayments = balloonPayments;
        }

        /// <summary>
        /// Tipo de prazo total do contrato referente à modalidade de crédito informada.
        /// </summary>
        [JsonProperty("typeNumberOfInstalments", ItemConverterType = typeof(StringEnumConverter))]
        public Models.TypeNumberOfInstalmentsEnum TypeNumberOfInstalments { get; set; }

        /// <summary>
        /// Prazo Total segundo o tipo (dia, semana, mês, ano) referente à Modalidade de Crédito informada.
        /// [Restrição] Obrigatoriamente deve ser preenchido caso o typeNumberOfInstalments seja diferente de SEM_PRAZO_TOTAL.
        /// </summary>
        [JsonProperty("totalNumberOfInstalments", NullValueHandling = NullValueHandling.Ignore)]
        public double? TotalNumberOfInstalments { get; set; }

        /// <summary>
        /// Tipo de prazo remanescente do contrato referente à modalidade de crédito informada.
        /// </summary>
        [JsonProperty("typeContractRemaining", ItemConverterType = typeof(StringEnumConverter))]
        public Models.TypeContractRemainingEnum TypeContractRemaining { get; set; }

        /// <summary>
        /// Prazo Remanescente segundo o tipo (dia, semana, mês, ano) referente à Modalidade de Crédito informada.
        /// [Restrição] Obrigatoriamente deve ser preenchido caso o typeContractRemaining seja diferente de SEM_PRAZO_REMANESCENTE.
        /// </summary>
        [JsonProperty("contractRemainingNumber", NullValueHandling = NullValueHandling.Ignore)]
        public double? ContractRemainingNumber { get; set; }

        /// <summary>
        /// Quantidade de prestações pagas. (No caso de modalidades que não possuam parcelas, o número de prestações é igual a zero)
        /// </summary>
        [JsonProperty("paidInstalments")]
        public double PaidInstalments { get; set; }

        /// <summary>
        /// Quantidade de prestações a vencer.
        /// [Restrição] Obrigatório para modalidades que possuam parcelas.
        /// </summary>
        [JsonProperty("dueInstalments", NullValueHandling = NullValueHandling.Ignore)]
        public double? DueInstalments { get; set; }

        /// <summary>
        /// Quantidade de prestações vencidas.
        /// [Restrição] Obrigatório para modalidades que possuam parcelas.
        /// </summary>
        [JsonProperty("pastDueInstalments", NullValueHandling = NullValueHandling.Ignore)]
        public double? PastDueInstalments { get; set; }

        /// <summary>
        /// Lista que traz as datas de vencimento e valor das parcelas não regulares do contrato da modalidade de crédito consultada
        /// </summary>
        [JsonProperty("balloonPayments", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.FinancingsBalloonPayment> BalloonPayments { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"FinancingsInstalments : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is FinancingsInstalments other &&
                this.TypeNumberOfInstalments.Equals(other.TypeNumberOfInstalments) &&
                ((this.TotalNumberOfInstalments == null && other.TotalNumberOfInstalments == null) || (this.TotalNumberOfInstalments?.Equals(other.TotalNumberOfInstalments) == true)) &&
                this.TypeContractRemaining.Equals(other.TypeContractRemaining) &&
                ((this.ContractRemainingNumber == null && other.ContractRemainingNumber == null) || (this.ContractRemainingNumber?.Equals(other.ContractRemainingNumber) == true)) &&
                this.PaidInstalments.Equals(other.PaidInstalments) &&
                ((this.DueInstalments == null && other.DueInstalments == null) || (this.DueInstalments?.Equals(other.DueInstalments) == true)) &&
                ((this.PastDueInstalments == null && other.PastDueInstalments == null) || (this.PastDueInstalments?.Equals(other.PastDueInstalments) == true)) &&
                ((this.BalloonPayments == null && other.BalloonPayments == null) || (this.BalloonPayments?.Equals(other.BalloonPayments) == true));
        }
        

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.TypeNumberOfInstalments = {this.TypeNumberOfInstalments}");
            toStringOutput.Add($"this.TotalNumberOfInstalments = {(this.TotalNumberOfInstalments == null ? "null" : this.TotalNumberOfInstalments.ToString())}");
            toStringOutput.Add($"this.TypeContractRemaining = {this.TypeContractRemaining}");
            toStringOutput.Add($"this.ContractRemainingNumber = {(this.ContractRemainingNumber == null ? "null" : this.ContractRemainingNumber.ToString())}");
            toStringOutput.Add($"this.PaidInstalments = {this.PaidInstalments}");
            toStringOutput.Add($"this.DueInstalments = {(this.DueInstalments == null ? "null" : this.DueInstalments.ToString())}");
            toStringOutput.Add($"this.PastDueInstalments = {(this.PastDueInstalments == null ? "null" : this.PastDueInstalments.ToString())}");
            toStringOutput.Add($"this.BalloonPayments = {(this.BalloonPayments == null ? "null" : $"[{string.Join(", ", this.BalloonPayments)} ]")}");
        }
    }
}