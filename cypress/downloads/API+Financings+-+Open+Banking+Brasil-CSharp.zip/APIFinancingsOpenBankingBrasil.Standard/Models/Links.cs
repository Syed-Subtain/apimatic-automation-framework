// <copyright file="Links.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace APIFinancingsOpenBankingBrasil.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using APIFinancingsOpenBankingBrasil.Standard;
    using APIFinancingsOpenBankingBrasil.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// Links.
    /// </summary>
    public class Links
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="Links"/> class.
        /// </summary>
        public Links()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="Links"/> class.
        /// </summary>
        /// <param name="self">self.</param>
        /// <param name="first">first.</param>
        /// <param name="prev">prev.</param>
        /// <param name="next">next.</param>
        /// <param name="last">last.</param>
        public Links(
            string self,
            string first = null,
            string prev = null,
            string next = null,
            string last = null)
        {
            this.Self = self;
            this.First = first;
            this.Prev = prev;
            this.Next = next;
            this.Last = last;
        }

        /// <summary>
        /// URI completo que gerou a resposta atual.
        /// </summary>
        [JsonProperty("self")]
        public string Self { get; set; }

        /// <summary>
        /// URI da primeira página que originou essa lista de resultados. Restrição - Obrigatório quando não for a primeira página da resposta
        /// </summary>
        [JsonProperty("first", NullValueHandling = NullValueHandling.Ignore)]
        public string First { get; set; }

        /// <summary>
        /// URI da página anterior dessa lista de resultados. Restrição - 	Obrigatório quando não for a primeira página da resposta
        /// </summary>
        [JsonProperty("prev", NullValueHandling = NullValueHandling.Ignore)]
        public string Prev { get; set; }

        /// <summary>
        /// URI da próxima página dessa lista de resultados. Restrição - Obrigatório quando não for a última página da resposta
        /// </summary>
        [JsonProperty("next", NullValueHandling = NullValueHandling.Ignore)]
        public string Next { get; set; }

        /// <summary>
        /// URI da última página dessa lista de resultados. Restrição - Obrigatório quando não for a última página da resposta
        /// </summary>
        [JsonProperty("last", NullValueHandling = NullValueHandling.Ignore)]
        public string Last { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"Links : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is Links other &&
                ((this.Self == null && other.Self == null) || (this.Self?.Equals(other.Self) == true)) &&
                ((this.First == null && other.First == null) || (this.First?.Equals(other.First) == true)) &&
                ((this.Prev == null && other.Prev == null) || (this.Prev?.Equals(other.Prev) == true)) &&
                ((this.Next == null && other.Next == null) || (this.Next?.Equals(other.Next) == true)) &&
                ((this.Last == null && other.Last == null) || (this.Last?.Equals(other.Last) == true));
        }
        

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.Self = {(this.Self == null ? "null" : this.Self == string.Empty ? "" : this.Self)}");
            toStringOutput.Add($"this.First = {(this.First == null ? "null" : this.First == string.Empty ? "" : this.First)}");
            toStringOutput.Add($"this.Prev = {(this.Prev == null ? "null" : this.Prev == string.Empty ? "" : this.Prev)}");
            toStringOutput.Add($"this.Next = {(this.Next == null ? "null" : this.Next == string.Empty ? "" : this.Next)}");
            toStringOutput.Add($"this.Last = {(this.Last == null ? "null" : this.Last == string.Empty ? "" : this.Last)}");
        }
    }
}