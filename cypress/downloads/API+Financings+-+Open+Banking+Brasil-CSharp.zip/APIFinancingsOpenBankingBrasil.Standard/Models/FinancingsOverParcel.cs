// <copyright file="FinancingsOverParcel.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace APIFinancingsOpenBankingBrasil.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using APIFinancingsOpenBankingBrasil.Standard;
    using APIFinancingsOpenBankingBrasil.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// FinancingsOverParcel.
    /// </summary>
    public class FinancingsOverParcel
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="FinancingsOverParcel"/> class.
        /// </summary>
        public FinancingsOverParcel()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="FinancingsOverParcel"/> class.
        /// </summary>
        /// <param name="fees">fees.</param>
        /// <param name="charges">charges.</param>
        public FinancingsOverParcel(
            List<Models.FinancingsFeeOverParcel> fees,
            List<Models.FinancingsChargeOverParcel> charges)
        {
            this.Fees = fees;
            this.Charges = charges;
        }

        /// <summary>
        /// Lista das tarifas que foram pagas fora da parcela, só para pagamento avulso.
        /// </summary>
        [JsonProperty("fees")]
        public List<Models.FinancingsFeeOverParcel> Fees { get; set; }

        /// <summary>
        /// Lista dos encargos que foram pagos fora da parcela.
        /// </summary>
        [JsonProperty("charges")]
        public List<Models.FinancingsChargeOverParcel> Charges { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"FinancingsOverParcel : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is FinancingsOverParcel other &&
                ((this.Fees == null && other.Fees == null) || (this.Fees?.Equals(other.Fees) == true)) &&
                ((this.Charges == null && other.Charges == null) || (this.Charges?.Equals(other.Charges) == true));
        }
        

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.Fees = {(this.Fees == null ? "null" : $"[{string.Join(", ", this.Fees)} ]")}");
            toStringOutput.Add($"this.Charges = {(this.Charges == null ? "null" : $"[{string.Join(", ", this.Charges)} ]")}");
        }
    }
}