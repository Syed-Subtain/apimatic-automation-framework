// <copyright file="InstalmentPeriodicityEnum.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace APIFinancingsOpenBankingBrasil.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Runtime.Serialization;
    using APIFinancingsOpenBankingBrasil.Standard;
    using APIFinancingsOpenBankingBrasil.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// InstalmentPeriodicityEnum.
    /// </summary>
    [JsonConverter(typeof(StringEnumConverter))]
    public enum InstalmentPeriodicityEnum
    {
        /// <summary>
        /// SEMPERIODICIDADEREGULAR.
        /// </summary>
        [EnumMember(Value = "SEM_PERIODICIDADE_REGULAR")]
        SEMPERIODICIDADEREGULAR,

        /// <summary>
        /// SEMANAL.
        /// </summary>
        [EnumMember(Value = "SEMANAL")]
        SEMANAL,

        /// <summary>
        /// QUINZENAL.
        /// </summary>
        [EnumMember(Value = "QUINZENAL")]
        QUINZENAL,

        /// <summary>
        /// MENSAL.
        /// </summary>
        [EnumMember(Value = "MENSAL")]
        MENSAL,

        /// <summary>
        /// BIMESTRAL.
        /// </summary>
        [EnumMember(Value = "BIMESTRAL")]
        BIMESTRAL,

        /// <summary>
        /// TRIMESTRAL.
        /// </summary>
        [EnumMember(Value = "TRIMESTRAL")]
        TRIMESTRAL,

        /// <summary>
        /// SEMESTRAL.
        /// </summary>
        [EnumMember(Value = "SEMESTRAL")]
        SEMESTRAL,

        /// <summary>
        /// ANUAL.
        /// </summary>
        [EnumMember(Value = "ANUAL")]
        ANUAL,

        /// <summary>
        /// OUTROS.
        /// </summary>
        [EnumMember(Value = "OUTROS")]
        OUTROS
    }
}