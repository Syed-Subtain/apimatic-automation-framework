// <copyright file="EnumProductSubTypeEnum.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace APIFinancingsOpenBankingBrasil.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Runtime.Serialization;
    using APIFinancingsOpenBankingBrasil.Standard;
    using APIFinancingsOpenBankingBrasil.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// EnumProductSubTypeEnum.
    /// </summary>
    [JsonConverter(typeof(StringEnumConverter))]
    public enum EnumProductSubTypeEnum
    {
        /// <summary>
        /// AQUISICAOBENSVEICULOSAUTOMOTORES.
        /// </summary>
        [EnumMember(Value = "AQUISICAO_BENS_VEICULOS_AUTOMOTORES")]
        AQUISICAOBENSVEICULOSAUTOMOTORES,

        /// <summary>
        /// AQUISICAOBENSOUTROSBENS.
        /// </summary>
        [EnumMember(Value = "AQUISICAO_BENS_OUTROS_BENS")]
        AQUISICAOBENSOUTROSBENS,

        /// <summary>
        /// MICROCREDITO.
        /// </summary>
        [EnumMember(Value = "MICROCREDITO")]
        MICROCREDITO,

        /// <summary>
        /// CUSTEIO.
        /// </summary>
        [EnumMember(Value = "CUSTEIO")]
        CUSTEIO,

        /// <summary>
        /// INVESTIMENTO.
        /// </summary>
        [EnumMember(Value = "INVESTIMENTO")]
        INVESTIMENTO,

        /// <summary>
        /// INDUSTRIALIZACAO.
        /// </summary>
        [EnumMember(Value = "INDUSTRIALIZACAO")]
        INDUSTRIALIZACAO,

        /// <summary>
        /// COMERCIALIZACAO.
        /// </summary>
        [EnumMember(Value = "COMERCIALIZACAO")]
        COMERCIALIZACAO,

        /// <summary>
        /// FINANCIAMENTOHABITACIONALSFH.
        /// </summary>
        [EnumMember(Value = "FINANCIAMENTO_HABITACIONAL_SFH")]
        FINANCIAMENTOHABITACIONALSFH,

        /// <summary>
        /// FINANCIAMENTOHABITACIONALEXCETOSFH.
        /// </summary>
        [EnumMember(Value = "FINANCIAMENTO_HABITACIONAL_EXCETO_SFH")]
        FINANCIAMENTOHABITACIONALEXCETOSFH
    }
}