// <copyright file="WarrantySubTypeEnum.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace APIFinancingsOpenBankingBrasil.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Runtime.Serialization;
    using APIFinancingsOpenBankingBrasil.Standard;
    using APIFinancingsOpenBankingBrasil.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// WarrantySubTypeEnum.
    /// </summary>
    [JsonConverter(typeof(StringEnumConverter))]
    public enum WarrantySubTypeEnum
    {
        /// <summary>
        /// ACOESDEBENTURES.
        /// </summary>
        [EnumMember(Value = "ACOES_DEBENTURES")]
        ACOESDEBENTURES,

        /// <summary>
        /// ACORDOSCOMPENSACAOLIQUIDACAOOBRIGACOES.
        /// </summary>
        [EnumMember(Value = "ACORDOS_COMPENSACAO_LIQUIDACAO_OBRIGACOES")]
        ACORDOSCOMPENSACAOLIQUIDACAOOBRIGACOES,

        /// <summary>
        /// APLICACOESFINANCEIRASRENDAFIXA.
        /// </summary>
        [EnumMember(Value = "APLICACOES_FINANCEIRAS_RENDA_FIXA")]
        APLICACOESFINANCEIRASRENDAFIXA,

        /// <summary>
        /// APLICACOESFINANCEIRASRENDAVARIAVEL.
        /// </summary>
        [EnumMember(Value = "APLICACOES_FINANCEIRAS_RENDA_VARIAVEL")]
        APLICACOESFINANCEIRASRENDAVARIAVEL,

        /// <summary>
        /// APOLICESCREDITOEXPORTACAO.
        /// </summary>
        [EnumMember(Value = "APOLICES_CREDITO_EXPORTACAO")]
        APOLICESCREDITOEXPORTACAO,

        /// <summary>
        /// CCRCONVENIOCREDITOSRECIPROCOS.
        /// </summary>
        [EnumMember(Value = "CCR_CONVENIO_CREDITOS_RECIPROCOS")]
        CCRCONVENIOCREDITOSRECIPROCOS,

        /// <summary>
        /// CHEQUES.
        /// </summary>
        [EnumMember(Value = "CHEQUES")]
        CHEQUES,

        /// <summary>
        /// CIVIL.
        /// </summary>
        [EnumMember(Value = "CIVIL")]
        CIVIL,

        /// <summary>
        /// DIREITOSSOBREALUGUEIS.
        /// </summary>
        [EnumMember(Value = "DIREITOS_SOBRE_ALUGUEIS")]
        DIREITOSSOBREALUGUEIS,

        /// <summary>
        /// DEPOSITOSAVISTAAPRAZOPOUPANCAOUROTITULOSPUBLICOSFEDERAISART36.
        /// </summary>
        [EnumMember(Value = "DEPOSITOS_A_VISTA_A_PRAZO_POUPANCA_OURO_TITULOS_PUBLICOS_FEDERAIS_ART_36")]
        DEPOSITOSAVISTAAPRAZOPOUPANCAOUROTITULOSPUBLICOSFEDERAISART36,

        /// <summary>
        /// DEPOSITOTITULOSEMITIDOSENTIDADESART23.
        /// </summary>
        [EnumMember(Value = "DEPOSITO_TITULOS_EMITIDOS_ENTIDADES_ART_23")]
        DEPOSITOTITULOSEMITIDOSENTIDADESART23,

        /// <summary>
        /// DUPLICATAS.
        /// </summary>
        [EnumMember(Value = "DUPLICATAS")]
        DUPLICATAS,

        /// <summary>
        /// EMDENTIDADESMULTILATERAISDESENVOLVIMENTOART37.
        /// </summary>
        [EnumMember(Value = "EMD_ENTIDADES_MULTILATERAIS_DESENVOLVIMENTO_ART_37")]
        EMDENTIDADESMULTILATERAISDESENVOLVIMENTOART37,

        /// <summary>
        /// EQUIPAMENTOS.
        /// </summary>
        [EnumMember(Value = "EQUIPAMENTOS")]
        EQUIPAMENTOS,

        /// <summary>
        /// ESTADUALOUDISTRITAL.
        /// </summary>
        [EnumMember(Value = "ESTADUAL_OU_DISTRITAL")]
        ESTADUALOUDISTRITAL,

        /// <summary>
        /// FATURACARTAOCREDITO.
        /// </summary>
        [EnumMember(Value = "FATURA_CARTAO_CREDITO")]
        FATURACARTAOCREDITO,

        /// <summary>
        /// FEDERAL.
        /// </summary>
        [EnumMember(Value = "FEDERAL")]
        FEDERAL,

        /// <summary>
        /// FCVSFUNDOCOMPENSACAOVARIACOESSALARIAIS.
        /// </summary>
        [EnumMember(Value = "FCVS_FUNDO_COMPENSACAO_VARIACOES_SALARIAIS")]
        FCVSFUNDOCOMPENSACAOVARIACOESSALARIAIS,

        /// <summary>
        /// FGIFUNDOGARANTIDORINVESTIMENTOS.
        /// </summary>
        [EnumMember(Value = "FGI_FUNDO_GARANTIDOR_INVESTIMENTOS")]
        FGIFUNDOGARANTIDORINVESTIMENTOS,

        /// <summary>
        /// FGPCFUNDOGARANTIAPROMOCAOCOMPETIT.
        /// </summary>
        [EnumMember(Value = "FGPC_FUNDO_GARANTIA_PROMOCAO_COMPETIT")]
        FGPCFUNDOGARANTIAPROMOCAOCOMPETIT,

        /// <summary>
        /// FGTSFUNDOGARANTIATEMPOSERVICO.
        /// </summary>
        [EnumMember(Value = "FGTS_FUNDO_GARANTIA_TEMPO_SERVICO")]
        FGTSFUNDOGARANTIATEMPOSERVICO,

        /// <summary>
        /// FUNDOGARANTIDORAVAL.
        /// </summary>
        [EnumMember(Value = "FUNDO_GARANTIDOR_AVAL")]
        FUNDOGARANTIDORAVAL,

        /// <summary>
        /// GARANTIAPRESTADAFGPCLEI9531ART37.
        /// </summary>
        [EnumMember(Value = "GARANTIA_PRESTADA_FGPC_LEI_9531_ART_37")]
        GARANTIAPRESTADAFGPCLEI9531ART37,

        /// <summary>
        /// GARANTIAPRESTADAFUNDOSQUAISQUEROUTROSMECANISMOSCOBERTURARISCOCREDITOART37.
        /// </summary>
        [EnumMember(Value = "GARANTIA_PRESTADA_FUNDOS_QUAISQUER_OUTROS_MECANISMOS_COBERTURA_RISCO_CREDITO_ART_37")]
        GARANTIAPRESTADAFUNDOSQUAISQUEROUTROSMECANISMOSCOBERTURARISCOCREDITOART37,

        /// <summary>
        /// GARANTIAPRESTADATESOURONACIONALOUBACENART37BENSDIREITOSINTEGRANTESPATRIMONIOAFETACAO.
        /// </summary>
        [EnumMember(Value = "GARANTIA_PRESTADA_TESOURO_NACIONAL_OU_BACEN_ART_37_BENS_DIREITOS_INTEGRANTES_PATRIMONIO_AFETACAO")]
        GARANTIAPRESTADATESOURONACIONALOUBACENART37BENSDIREITOSINTEGRANTESPATRIMONIOAFETACAO,

        /// <summary>
        /// IMOVEIS.
        /// </summary>
        [EnumMember(Value = "IMOVEIS")]
        IMOVEIS,

        /// <summary>
        /// IMOVEISRESIDENCIAIS.
        /// </summary>
        [EnumMember(Value = "IMOVEIS_RESIDENCIAIS")]
        IMOVEISRESIDENCIAIS,

        /// <summary>
        /// MITIGADORAS.
        /// </summary>
        [EnumMember(Value = "MITIGADORAS")]
        MITIGADORAS,

        /// <summary>
        /// MUNICIPAL.
        /// </summary>
        [EnumMember(Value = "MUNICIPAL")]
        MUNICIPAL,

        /// <summary>
        /// NAOMITIGADORAS.
        /// </summary>
        [EnumMember(Value = "NAO_MITIGADORAS")]
        NAOMITIGADORAS,

        /// <summary>
        /// NOTASPROMISSORIASOUTROSDIREITOSCREDITO.
        /// </summary>
        [EnumMember(Value = "NOTAS_PROMISSORIAS_OUTROS_DIREITOS_CREDITO")]
        NOTASPROMISSORIASOUTROSDIREITOSCREDITO,

        /// <summary>
        /// OUTRAS.
        /// </summary>
        [EnumMember(Value = "OUTRAS")]
        OUTRAS,

        /// <summary>
        /// OUTROS.
        /// </summary>
        [EnumMember(Value = "OUTROS")]
        OUTROS,

        /// <summary>
        /// OUTROSBENS.
        /// </summary>
        [EnumMember(Value = "OUTROS_BENS")]
        OUTROSBENS,

        /// <summary>
        /// OUTROSGRAUS.
        /// </summary>
        [EnumMember(Value = "OUTROS_GRAUS")]
        OUTROSGRAUS,

        /// <summary>
        /// OUTROSIMOVEIS.
        /// </summary>
        [EnumMember(Value = "OUTROS_IMOVEIS")]
        OUTROSIMOVEIS,

        /// <summary>
        /// OUTROSSEGUROSASSEMELHADOS.
        /// </summary>
        [EnumMember(Value = "OUTROS_SEGUROS_ASSEMELHADOS")]
        OUTROSSEGUROSASSEMELHADOS,

        /// <summary>
        /// PESSOAFISICA.
        /// </summary>
        [EnumMember(Value = "PESSOA_FISICA")]
        PESSOAFISICA,

        /// <summary>
        /// PESSOAFISICAEXTERIOR.
        /// </summary>
        [EnumMember(Value = "PESSOA_FISICA_EXTERIOR")]
        PESSOAFISICAEXTERIOR,

        /// <summary>
        /// PESSOAJURIDICA.
        /// </summary>
        [EnumMember(Value = "PESSOA_JURIDICA")]
        PESSOAJURIDICA,

        /// <summary>
        /// PESSOAJURIDICAEXTERIOR.
        /// </summary>
        [EnumMember(Value = "PESSOA_JURIDICA_EXTERIOR")]
        PESSOAJURIDICAEXTERIOR,

        /// <summary>
        /// PRIMEIROGRAUBENSDIREITOSINTEGRANTESPATRIMONIOAFETACAO.
        /// </summary>
        [EnumMember(Value = "PRIMEIRO_GRAU_BENS_DIREITOS_INTEGRANTES_PATRIMONIO_AFETACAO")]
        PRIMEIROGRAUBENSDIREITOSINTEGRANTESPATRIMONIOAFETACAO,

        /// <summary>
        /// PRIMEIROGRAUIMOVEISRESIDENCIAIS.
        /// </summary>
        [EnumMember(Value = "PRIMEIRO_GRAU_IMOVEIS_RESIDENCIAIS")]
        PRIMEIROGRAUIMOVEISRESIDENCIAIS,

        /// <summary>
        /// PRIMEIROGRAUOUTROS.
        /// </summary>
        [EnumMember(Value = "PRIMEIRO_GRAU_OUTROS")]
        PRIMEIROGRAUOUTROS,

        /// <summary>
        /// PROAGRO.
        /// </summary>
        [EnumMember(Value = "PROAGRO")]
        PROAGRO,

        /// <summary>
        /// PRODUTOSAGROPECUARIOSCOMWARRANT.
        /// </summary>
        [EnumMember(Value = "PRODUTOS_AGROPECUARIOS_COM_WARRANT")]
        PRODUTOSAGROPECUARIOSCOMWARRANT,

        /// <summary>
        /// PRODUTOSAGROPECUARIOSSEMWARRANT.
        /// </summary>
        [EnumMember(Value = "PRODUTOS_AGROPECUARIOS_SEM_WARRANT")]
        PRODUTOSAGROPECUARIOSSEMWARRANT,

        /// <summary>
        /// SBCESOCIEDADEBRASILEIRACREDITOEXPORTAO.
        /// </summary>
        [EnumMember(Value = "SBCE_SOCIEDADE_BRASILEIRA_CREDITO_EXPORTAÇÃO")]
        SBCESOCIEDADEBRASILEIRACREDITOEXPORTAO,

        /// <summary>
        /// SEGURORURAL.
        /// </summary>
        [EnumMember(Value = "SEGURO_RURAL")]
        SEGURORURAL,

        /// <summary>
        /// SEMSUBTIPOGARANTIA.
        /// </summary>
        [EnumMember(Value = "SEM_SUB_TIPO_GARANTIA")]
        SEMSUBTIPOGARANTIA,

        /// <summary>
        /// TRIBUTOSRECEITASORCAMENTARIAS.
        /// </summary>
        [EnumMember(Value = "TRIBUTOS_RECEITAS_ORCAMENTARIAS")]
        TRIBUTOSRECEITASORCAMENTARIAS,

        /// <summary>
        /// VEICULOS.
        /// </summary>
        [EnumMember(Value = "VEICULOS")]
        VEICULOS,

        /// <summary>
        /// VEICULOSAUTOMOTORES.
        /// </summary>
        [EnumMember(Value = "VEICULOS_AUTOMOTORES")]
        VEICULOSAUTOMOTORES
    }
}