// <copyright file="FeeChargeTypeEnum.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace APIFinancingsOpenBankingBrasil.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Runtime.Serialization;
    using APIFinancingsOpenBankingBrasil.Standard;
    using APIFinancingsOpenBankingBrasil.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// FeeChargeTypeEnum.
    /// </summary>
    [JsonConverter(typeof(StringEnumConverter))]
    public enum FeeChargeTypeEnum
    {
        /// <summary>
        /// UNICA.
        /// </summary>
        [EnumMember(Value = "UNICA")]
        UNICA,

        /// <summary>
        /// PORPARCELA.
        /// </summary>
        [EnumMember(Value = "POR_PARCELA")]
        PORPARCELA
    }
}