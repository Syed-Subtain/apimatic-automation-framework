// <copyright file="TaxPeriodicityEnum.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace APIFinancingsOpenBankingBrasil.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Runtime.Serialization;
    using APIFinancingsOpenBankingBrasil.Standard;
    using APIFinancingsOpenBankingBrasil.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// TaxPeriodicityEnum.
    /// </summary>
    [JsonConverter(typeof(StringEnumConverter))]
    public enum TaxPeriodicityEnum
    {
        /// <summary>
        /// AM.
        /// </summary>
        [EnumMember(Value = "AM")]
        AM,

        /// <summary>
        /// AA.
        /// </summary>
        [EnumMember(Value = "AA")]
        AA
    }
}