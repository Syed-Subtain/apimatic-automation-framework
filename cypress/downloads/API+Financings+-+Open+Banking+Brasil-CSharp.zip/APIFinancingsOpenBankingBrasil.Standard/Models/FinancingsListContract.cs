// <copyright file="FinancingsListContract.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace APIFinancingsOpenBankingBrasil.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using APIFinancingsOpenBankingBrasil.Standard;
    using APIFinancingsOpenBankingBrasil.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// FinancingsListContract.
    /// </summary>
    public class FinancingsListContract
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="FinancingsListContract"/> class.
        /// </summary>
        public FinancingsListContract()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="FinancingsListContract"/> class.
        /// </summary>
        /// <param name="contractId">contractId.</param>
        /// <param name="brandName">brandName.</param>
        /// <param name="companyCnpj">companyCnpj.</param>
        /// <param name="productType">productType.</param>
        /// <param name="productSubType">productSubType.</param>
        /// <param name="ipocCode">ipocCode.</param>
        public FinancingsListContract(
            string contractId,
            string brandName,
            string companyCnpj,
            Models.EnumProductTypeEnum productType,
            Models.EnumProductSubTypeEnum productSubType,
            string ipocCode)
        {
            this.ContractId = contractId;
            this.BrandName = brandName;
            this.CompanyCnpj = companyCnpj;
            this.ProductType = productType;
            this.ProductSubType = productSubType;
            this.IpocCode = ipocCode;
        }

        /// <summary>
        /// Identifica de forma única o contrato da operação de crédito do cliente, mantendo as regras de imutabilidade dentro da instituição transmissora.
        /// </summary>
        [JsonProperty("contractId")]
        public string ContractId { get; set; }

        /// <summary>
        /// Nome da Marca reportada pelo participante no Open Finance. Recomenda-se utilizar, sempre que possível, o mesmo nome de marca atribuído no campo do diretório Customer Friendly Server Name (Authorisation Server).
        /// </summary>
        [JsonProperty("brandName")]
        public string BrandName { get; set; }

        /// <summary>
        /// Número completo do CNPJ da instituição responsável pelo Cadastro - o CNPJ corresponde ao número de inscrição no Cadastro de Pessoa Jurídica. Deve-se ter apenas os números do CNPJ, sem máscara.
        /// </summary>
        [JsonProperty("companyCnpj")]
        public string CompanyCnpj { get; set; }

        /// <summary>
        /// "Tipo da modalidade de crédito contratada, conforme  circular 4.015 e descrição do DOC3040 do SCR). (Vide Enum)
        /// Financiamentos, Financiamentos rurais  e Financiamentos imobiliários"
        /// </summary>
        [JsonProperty("productType", ItemConverterType = typeof(StringEnumConverter))]
        public Models.EnumProductTypeEnum ProductType { get; set; }

        /// <summary>
        /// "Sub tipo da modalidades de crédito contratadas, conforme  circular 4.015 e descrição do DOC3040 do SCR). (Vide Enum)
        /// Aquisição de bens veículos automotores, Aquisição de bens de outros bens, Microcrédito, Custeio, Investimento, Industrialização, Comercialização, Financiamento habitacional SFH e Financiamento habitacional exceto SFH"
        /// </summary>
        [JsonProperty("productSubType", ItemConverterType = typeof(StringEnumConverter))]
        public Models.EnumProductSubTypeEnum ProductSubType { get; set; }

        /// <summary>
        /// Número padronizado do contrato - IPOC (Identificação Padronizada da Operação de Crédito). Segundo DOC 3040, composta por:
        /// - **CNPJ da instituição:** 8 (oito) posições iniciais;
        /// - **Modalidade da operação:** 4 (quatro) posições;
        /// - **Tipo do cliente:** 1 (uma) posição( 1 = pessoa natural - CPF, 2= pessoa jurídica – CNPJ, 3 = pessoa física no exterior, 4 = pessoa jurídica no exterior, 5 = pessoa natural sem CPF e 6 = pessoa jurídica sem CNPJ);
        /// - **Código do cliente:** O número de posições varia conforme o tipo do cliente:
        ///   1. Para clientes pessoa física com CPF (tipo de cliente = 1), informar as 11 (onze) posições do CPF;
        ///   2. Para clientes pessoa jurídica com CNPJ (tipo de cliente = 2), informar as 8 (oito) posições iniciais do CNPJ;
        ///   3. Para os demais clientes (tipos de cliente 3, 4, 5 e 6), informar 14 (catorze) posições com complemento de zeros à esquerda se a identificação tiver tamanho inferior;
        /// - **Código do contrato:** 1 (uma) até 40 (quarenta) posições, sem complemento de caracteres.
        /// </summary>
        [JsonProperty("ipocCode")]
        public string IpocCode { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"FinancingsListContract : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is FinancingsListContract other &&
                ((this.ContractId == null && other.ContractId == null) || (this.ContractId?.Equals(other.ContractId) == true)) &&
                ((this.BrandName == null && other.BrandName == null) || (this.BrandName?.Equals(other.BrandName) == true)) &&
                ((this.CompanyCnpj == null && other.CompanyCnpj == null) || (this.CompanyCnpj?.Equals(other.CompanyCnpj) == true)) &&
                this.ProductType.Equals(other.ProductType) &&
                this.ProductSubType.Equals(other.ProductSubType) &&
                ((this.IpocCode == null && other.IpocCode == null) || (this.IpocCode?.Equals(other.IpocCode) == true));
        }
        

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.ContractId = {(this.ContractId == null ? "null" : this.ContractId == string.Empty ? "" : this.ContractId)}");
            toStringOutput.Add($"this.BrandName = {(this.BrandName == null ? "null" : this.BrandName == string.Empty ? "" : this.BrandName)}");
            toStringOutput.Add($"this.CompanyCnpj = {(this.CompanyCnpj == null ? "null" : this.CompanyCnpj == string.Empty ? "" : this.CompanyCnpj)}");
            toStringOutput.Add($"this.ProductType = {this.ProductType}");
            toStringOutput.Add($"this.ProductSubType = {this.ProductSubType}");
            toStringOutput.Add($"this.IpocCode = {(this.IpocCode == null ? "null" : this.IpocCode == string.Empty ? "" : this.IpocCode)}");
        }
    }
}