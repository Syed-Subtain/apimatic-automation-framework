// <copyright file="EnumProductTypeEnum.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace APIFinancingsOpenBankingBrasil.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Runtime.Serialization;
    using APIFinancingsOpenBankingBrasil.Standard;
    using APIFinancingsOpenBankingBrasil.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// EnumProductTypeEnum.
    /// </summary>
    [JsonConverter(typeof(StringEnumConverter))]
    public enum EnumProductTypeEnum
    {
        /// <summary>
        /// FINANCIAMENTOS.
        /// </summary>
        [EnumMember(Value = "FINANCIAMENTOS")]
        FINANCIAMENTOS,

        /// <summary>
        /// FINANCIAMENTOSRURAIS.
        /// </summary>
        [EnumMember(Value = "FINANCIAMENTOS_RURAIS")]
        FINANCIAMENTOSRURAIS,

        /// <summary>
        /// FINANCIAMENTOSIMOBILIARIOS.
        /// </summary>
        [EnumMember(Value = "FINANCIAMENTOS_IMOBILIARIOS")]
        FINANCIAMENTOSIMOBILIARIOS
    }
}