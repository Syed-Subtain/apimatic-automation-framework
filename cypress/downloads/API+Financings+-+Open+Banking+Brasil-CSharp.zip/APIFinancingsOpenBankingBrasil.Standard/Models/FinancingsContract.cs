// <copyright file="FinancingsContract.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace APIFinancingsOpenBankingBrasil.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using APIFinancingsOpenBankingBrasil.Standard;
    using APIFinancingsOpenBankingBrasil.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// FinancingsContract.
    /// </summary>
    public class FinancingsContract
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="FinancingsContract"/> class.
        /// </summary>
        public FinancingsContract()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="FinancingsContract"/> class.
        /// </summary>
        /// <param name="contractNumber">contractNumber.</param>
        /// <param name="ipocCode">ipocCode.</param>
        /// <param name="productName">productName.</param>
        /// <param name="productType">productType.</param>
        /// <param name="productSubType">productSubType.</param>
        /// <param name="contractDate">contractDate.</param>
        /// <param name="instalmentPeriodicity">instalmentPeriodicity.</param>
        /// <param name="amortizationScheduled">amortizationScheduled.</param>
        /// <param name="interestRates">interestRates.</param>
        /// <param name="contractedFees">contractedFees.</param>
        /// <param name="contractedFinanceCharges">contractedFinanceCharges.</param>
        /// <param name="disbursementDates">disbursementDates.</param>
        /// <param name="settlementDate">settlementDate.</param>
        /// <param name="contractAmount">contractAmount.</param>
        /// <param name="currency">currency.</param>
        /// <param name="dueDate">dueDate.</param>
        /// <param name="instalmentPeriodicityAdditionalInfo">instalmentPeriodicityAdditionalInfo.</param>
        /// <param name="firstInstalmentDueDate">firstInstalmentDueDate.</param>
        /// <param name="cET">CET.</param>
        /// <param name="amortizationScheduledAdditionalInfo">amortizationScheduledAdditionalInfo.</param>
        public FinancingsContract(
            string contractNumber,
            string ipocCode,
            string productName,
            Models.EnumProductTypeEnum productType,
            Models.EnumProductSubTypeEnum productSubType,
            DateTime contractDate,
            Models.InstalmentPeriodicityEnum instalmentPeriodicity,
            Models.AmortizationScheduledEnum amortizationScheduled,
            List<Models.FinancingsContractInterestRate> interestRates,
            List<Models.FinancingsContractFee> contractedFees,
            List<Models.FinancingsFinanceCharge> contractedFinanceCharges,
            List<DateTime> disbursementDates = null,
            DateTime? settlementDate = null,
            string contractAmount = null,
            string currency = null,
            DateTime? dueDate = null,
            string instalmentPeriodicityAdditionalInfo = null,
            DateTime? firstInstalmentDueDate = null,
            string cET = null,
            string amortizationScheduledAdditionalInfo = null)
        {
            this.ContractNumber = contractNumber;
            this.IpocCode = ipocCode;
            this.ProductName = productName;
            this.ProductType = productType;
            this.ProductSubType = productSubType;
            this.ContractDate = contractDate;
            this.DisbursementDates = disbursementDates;
            this.SettlementDate = settlementDate;
            this.ContractAmount = contractAmount;
            this.Currency = currency;
            this.DueDate = dueDate;
            this.InstalmentPeriodicity = instalmentPeriodicity;
            this.InstalmentPeriodicityAdditionalInfo = instalmentPeriodicityAdditionalInfo;
            this.FirstInstalmentDueDate = firstInstalmentDueDate;
            this.CET = cET;
            this.AmortizationScheduled = amortizationScheduled;
            this.AmortizationScheduledAdditionalInfo = amortizationScheduledAdditionalInfo;
            this.InterestRates = interestRates;
            this.ContractedFees = contractedFees;
            this.ContractedFinanceCharges = contractedFinanceCharges;
        }

        /// <summary>
        /// Número do contrato dado pela instituição contratante.
        /// </summary>
        [JsonProperty("contractNumber")]
        public string ContractNumber { get; set; }

        /// <summary>
        /// "Número padronizado do contrato - IPOC (Identificação Padronizada da Operação de Crédito). Segundo DOC 3040, composta por:
        /// - **CNPJ da instituição:** 8 (oito) posições iniciais;
        /// - **Modalidade da operação:** 4 (quatro) posições;
        /// - **Tipo do cliente:** 1 (uma) posição( 1 = pessoa natural - CPF, 2= pessoa jurídica – CNPJ, 3 = pessoa física no exterior, 4 = pessoa jurídica no exterior, 5 = pessoa natural sem CPF e 6 = pessoa jurídica sem CNPJ);
        /// - **Código do cliente:** O número de posições varia conforme o tipo do cliente:
        ///   1. Para clientes pessoa física com CPF (tipo de cliente = 1), informar as 11 (onze) posições do CPF;
        ///   2. Para clientes pessoa jurídica com CNPJ (tipo de cliente = 2), informar as 8 (oito) posições iniciais do CNPJ;
        ///   3. Para os demais clientes (tipos de cliente 3, 4, 5 e 6), informar 14 (catorze) posições com complemento de zeros à esquerda se a identificação tiver tamanho inferior;
        /// - **Código do contrato:** 1 (uma) até 40 (quarenta) posições, sem complemento de caracteres."
        /// </summary>
        [JsonProperty("ipocCode")]
        public string IpocCode { get; set; }

        /// <summary>
        /// Denominação/Identificação do nome da Modalidade da Operação de Crédito divulgado ao cliente
        /// </summary>
        [JsonProperty("productName")]
        public string ProductName { get; set; }

        /// <summary>
        /// "Tipo da modalidade de crédito contratada, conforme  circular 4.015 e descrição do DOC3040 do SCR). (Vide Enum)
        /// Financiamentos, Financiamentos rurais  e Financiamentos imobiliários"
        /// </summary>
        [JsonProperty("productType", ItemConverterType = typeof(StringEnumConverter))]
        public Models.EnumProductTypeEnum ProductType { get; set; }

        /// <summary>
        /// "Sub tipo da modalidades de crédito contratadas, conforme  circular 4.015 e descrição do DOC3040 do SCR). (Vide Enum)
        /// Aquisição de bens veículos automotores, Aquisição de bens de outros bens, Microcrédito, Custeio, Investimento, Industrialização, Comercialização, Financiamento habitacional SFH e Financiamento habitacional exceto SFH"
        /// </summary>
        [JsonProperty("productSubType", ItemConverterType = typeof(StringEnumConverter))]
        public Models.EnumProductSubTypeEnum ProductSubType { get; set; }

        /// <summary>
        /// Data de contratação da operação de crédito. Especificação RFC-3339
        /// </summary>
        [JsonConverter(typeof(CustomDateTimeConverter), "yyyy'-'MM'-'dd")]
        [JsonProperty("contractDate")]
        public DateTime ContractDate { get; set; }

        /// <summary>
        /// Lista que traz as Datas de Desembolso do valor contratado.
        /// </summary>
        [JsonConverter(typeof(ListDateTimeConverter), typeof(CustomDateTimeConverter), "yyyy'-'MM'-'dd")]
        [JsonProperty("disbursementDates", NullValueHandling = NullValueHandling.Ignore)]
        public List<DateTime> DisbursementDates { get; set; }

        /// <summary>
        /// Data de liquidação da operação.
        /// </summary>
        [JsonConverter(typeof(CustomDateTimeConverter), "yyyy'-'MM'-'dd")]
        [JsonProperty("settlementDate", NullValueHandling = NullValueHandling.Ignore)]
        public DateTime? SettlementDate { get; set; }

        /// <summary>
        /// Valor contratado da operação. Expresso em valor monetário com no mínimo 2 casas e no máximo 4 casas decimais.
        /// </summary>
        [JsonProperty("contractAmount", NullValueHandling = NullValueHandling.Ignore)]
        public string ContractAmount { get; set; }

        /// <summary>
        /// Moeda referente ao valor da garantia, segundo modelo ISO-4217. p.ex. 'BRL'
        /// Todos os valores monetários informados estão representados com a moeda vigente do Brasil
        /// </summary>
        [JsonProperty("currency", NullValueHandling = NullValueHandling.Ignore)]
        public string Currency { get; set; }

        /// <summary>
        /// Data de vencimento Final da operação. Especificação RFC-3339.
        /// </summary>
        [JsonConverter(typeof(CustomDateTimeConverter), "yyyy'-'MM'-'dd")]
        [JsonProperty("dueDate", NullValueHandling = NullValueHandling.Ignore)]
        public DateTime? DueDate { get; set; }

        /// <summary>
        /// "Informação relativa à periodicidade regular das parcelas. (Vide Enum)
        /// sem periodicidade regular, semanal, quinzenal, mensal, bimestral, trimestral, semestral, anual"
        /// </summary>
        [JsonProperty("instalmentPeriodicity", ItemConverterType = typeof(StringEnumConverter))]
        public Models.InstalmentPeriodicityEnum InstalmentPeriodicity { get; set; }

        /// <summary>
        /// Campo para complementar a informação relativa à periodicidade de pagamento regular.
        /// [Restrição] Obrigatório quando o campo instalmentPeriodicity for igual a OUTROS.
        /// </summary>
        [JsonProperty("instalmentPeriodicityAdditionalInfo", NullValueHandling = NullValueHandling.Ignore)]
        public string InstalmentPeriodicityAdditionalInfo { get; set; }

        /// <summary>
        /// Data de vencimento primeira parcela do principal.
        /// </summary>
        [JsonConverter(typeof(CustomDateTimeConverter), "yyyy'-'MM'-'dd")]
        [JsonProperty("firstInstalmentDueDate", NullValueHandling = NullValueHandling.Ignore)]
        public DateTime? FirstInstalmentDueDate { get; set; }

        /// <summary>
        /// CET – Custo Efetivo Total deve ser expresso na forma de taxa percentual anual e incorpora todos os encargos e despesas incidentes nas operações de crédito (taxa de juro, mas também tarifas, tributos, seguros e outras despesas cobradas).
        /// O preenchimento deve respeitar as 6 casas decimais, mesmo que venham preenchidas com zeros (representação de porcentagem p.ex: 0.150000. Este valor representa 15%. O valor 1 representa 100%).
        /// </summary>
        [JsonProperty("CET", NullValueHandling = NullValueHandling.Ignore)]
        public string CET { get; set; }

        /// <summary>
        /// Sistema de amortização (Vide Enum):
        /// - SAC (Sistema de Amortização Constante) - É aquele em que o valor da amortização permanece igual até o final. Os juros cobrados sobre o parcelamento não entram nesta conta.
        /// - PRICE (Sistema Francês de Amortização) - As parcelas são fixas do início ao fim do contrato. Ou seja, todas as parcelas terão o mesmo valor, desde a primeira até a última. Nos primeiros pagamentos, a maior parte do valor da prestação corresponde aos juros. Ao longo do tempo, a taxa de juros vai decrescendo. Como o valor da prestação é fixo, com o passar das parcelas, o valor de amortização vai aumentando.
        /// - SAM (Sistema de Amortização Misto) - Cada prestação (pagamento) é a média aritmética das prestações respectivas no Sistemas Price e no Sistema de Amortização Constante (SAC).
        /// - SEM SISTEMA DE AMORTIZAÇÃO
        /// </summary>
        [JsonProperty("amortizationScheduled", ItemConverterType = typeof(StringEnumConverter))]
        public Models.AmortizationScheduledEnum AmortizationScheduled { get; set; }

        /// <summary>
        /// Campo para complementar a informação relativa à amortização.
        /// [Restrição] Obrigatório quando o campo amortizationScheduled for igual a OUTROS.
        /// </summary>
        [JsonProperty("amortizationScheduledAdditionalInfo", NullValueHandling = NullValueHandling.Ignore)]
        public string AmortizationScheduledAdditionalInfo { get; set; }

        /// <summary>
        /// Objeto que traz o conjunto de informações necessárias para demonstrar a composição das taxas de juros remuneratórios da Modalidade de crédito.
        /// Caso o contrato não possua taxas de juros, deve ser compartilhada uma lista vazia. Caso o contrato possua uma taxa de juros com valor 0, deve ser compartilhado um objeto com o valor 0 de forma explícita.
        /// </summary>
        [JsonProperty("interestRates")]
        public List<Models.FinancingsContractInterestRate> InterestRates { get; set; }

        /// <summary>
        /// Lista que traz as informações das tarifas pactuadas no contrato.
        /// </summary>
        [JsonProperty("contractedFees")]
        public List<Models.FinancingsContractFee> ContractedFees { get; set; }

        /// <summary>
        /// Lista que traz os encargos pactuados no contrato
        /// </summary>
        [JsonProperty("contractedFinanceCharges")]
        public List<Models.FinancingsFinanceCharge> ContractedFinanceCharges { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"FinancingsContract : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is FinancingsContract other &&
                ((this.ContractNumber == null && other.ContractNumber == null) || (this.ContractNumber?.Equals(other.ContractNumber) == true)) &&
                ((this.IpocCode == null && other.IpocCode == null) || (this.IpocCode?.Equals(other.IpocCode) == true)) &&
                ((this.ProductName == null && other.ProductName == null) || (this.ProductName?.Equals(other.ProductName) == true)) &&
                this.ProductType.Equals(other.ProductType) &&
                this.ProductSubType.Equals(other.ProductSubType) &&
                this.ContractDate.Equals(other.ContractDate) &&
                ((this.DisbursementDates == null && other.DisbursementDates == null) || (this.DisbursementDates?.Equals(other.DisbursementDates) == true)) &&
                ((this.SettlementDate == null && other.SettlementDate == null) || (this.SettlementDate?.Equals(other.SettlementDate) == true)) &&
                ((this.ContractAmount == null && other.ContractAmount == null) || (this.ContractAmount?.Equals(other.ContractAmount) == true)) &&
                ((this.Currency == null && other.Currency == null) || (this.Currency?.Equals(other.Currency) == true)) &&
                ((this.DueDate == null && other.DueDate == null) || (this.DueDate?.Equals(other.DueDate) == true)) &&
                this.InstalmentPeriodicity.Equals(other.InstalmentPeriodicity) &&
                ((this.InstalmentPeriodicityAdditionalInfo == null && other.InstalmentPeriodicityAdditionalInfo == null) || (this.InstalmentPeriodicityAdditionalInfo?.Equals(other.InstalmentPeriodicityAdditionalInfo) == true)) &&
                ((this.FirstInstalmentDueDate == null && other.FirstInstalmentDueDate == null) || (this.FirstInstalmentDueDate?.Equals(other.FirstInstalmentDueDate) == true)) &&
                ((this.CET == null && other.CET == null) || (this.CET?.Equals(other.CET) == true)) &&
                this.AmortizationScheduled.Equals(other.AmortizationScheduled) &&
                ((this.AmortizationScheduledAdditionalInfo == null && other.AmortizationScheduledAdditionalInfo == null) || (this.AmortizationScheduledAdditionalInfo?.Equals(other.AmortizationScheduledAdditionalInfo) == true)) &&
                ((this.InterestRates == null && other.InterestRates == null) || (this.InterestRates?.Equals(other.InterestRates) == true)) &&
                ((this.ContractedFees == null && other.ContractedFees == null) || (this.ContractedFees?.Equals(other.ContractedFees) == true)) &&
                ((this.ContractedFinanceCharges == null && other.ContractedFinanceCharges == null) || (this.ContractedFinanceCharges?.Equals(other.ContractedFinanceCharges) == true));
        }
        

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.ContractNumber = {(this.ContractNumber == null ? "null" : this.ContractNumber == string.Empty ? "" : this.ContractNumber)}");
            toStringOutput.Add($"this.IpocCode = {(this.IpocCode == null ? "null" : this.IpocCode == string.Empty ? "" : this.IpocCode)}");
            toStringOutput.Add($"this.ProductName = {(this.ProductName == null ? "null" : this.ProductName == string.Empty ? "" : this.ProductName)}");
            toStringOutput.Add($"this.ProductType = {this.ProductType}");
            toStringOutput.Add($"this.ProductSubType = {this.ProductSubType}");
            toStringOutput.Add($"this.ContractDate = {this.ContractDate}");
            toStringOutput.Add($"this.DisbursementDates = {(this.DisbursementDates == null ? "null" : $"[{string.Join(", ", this.DisbursementDates)} ]")}");
            toStringOutput.Add($"this.SettlementDate = {(this.SettlementDate == null ? "null" : this.SettlementDate.ToString())}");
            toStringOutput.Add($"this.ContractAmount = {(this.ContractAmount == null ? "null" : this.ContractAmount == string.Empty ? "" : this.ContractAmount)}");
            toStringOutput.Add($"this.Currency = {(this.Currency == null ? "null" : this.Currency == string.Empty ? "" : this.Currency)}");
            toStringOutput.Add($"this.DueDate = {(this.DueDate == null ? "null" : this.DueDate.ToString())}");
            toStringOutput.Add($"this.InstalmentPeriodicity = {this.InstalmentPeriodicity}");
            toStringOutput.Add($"this.InstalmentPeriodicityAdditionalInfo = {(this.InstalmentPeriodicityAdditionalInfo == null ? "null" : this.InstalmentPeriodicityAdditionalInfo == string.Empty ? "" : this.InstalmentPeriodicityAdditionalInfo)}");
            toStringOutput.Add($"this.FirstInstalmentDueDate = {(this.FirstInstalmentDueDate == null ? "null" : this.FirstInstalmentDueDate.ToString())}");
            toStringOutput.Add($"this.CET = {(this.CET == null ? "null" : this.CET == string.Empty ? "" : this.CET)}");
            toStringOutput.Add($"this.AmortizationScheduled = {this.AmortizationScheduled}");
            toStringOutput.Add($"this.AmortizationScheduledAdditionalInfo = {(this.AmortizationScheduledAdditionalInfo == null ? "null" : this.AmortizationScheduledAdditionalInfo == string.Empty ? "" : this.AmortizationScheduledAdditionalInfo)}");
            toStringOutput.Add($"this.InterestRates = {(this.InterestRates == null ? "null" : $"[{string.Join(", ", this.InterestRates)} ]")}");
            toStringOutput.Add($"this.ContractedFees = {(this.ContractedFees == null ? "null" : $"[{string.Join(", ", this.ContractedFees)} ]")}");
            toStringOutput.Add($"this.ContractedFinanceCharges = {(this.ContractedFinanceCharges == null ? "null" : $"[{string.Join(", ", this.ContractedFinanceCharges)} ]")}");
        }
    }
}