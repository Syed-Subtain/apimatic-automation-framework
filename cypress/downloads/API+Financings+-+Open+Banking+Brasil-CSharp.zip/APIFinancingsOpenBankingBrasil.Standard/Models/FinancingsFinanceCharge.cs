// <copyright file="FinancingsFinanceCharge.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace APIFinancingsOpenBankingBrasil.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using APIFinancingsOpenBankingBrasil.Standard;
    using APIFinancingsOpenBankingBrasil.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// FinancingsFinanceCharge.
    /// </summary>
    public class FinancingsFinanceCharge
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="FinancingsFinanceCharge"/> class.
        /// </summary>
        public FinancingsFinanceCharge()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="FinancingsFinanceCharge"/> class.
        /// </summary>
        /// <param name="chargeType">chargeType.</param>
        /// <param name="chargeAdditionalInfo">chargeAdditionalInfo.</param>
        /// <param name="chargeRate">chargeRate.</param>
        public FinancingsFinanceCharge(
            Models.EnumContractFinanceChargeTypeEnum chargeType,
            string chargeAdditionalInfo = null,
            string chargeRate = null)
        {
            this.ChargeType = chargeType;
            this.ChargeAdditionalInfo = chargeAdditionalInfo;
            this.ChargeRate = chargeRate;
        }

        /// <summary>
        /// Tipo de encargo pactuado no contrato.
        /// </summary>
        [JsonProperty("chargeType", ItemConverterType = typeof(StringEnumConverter))]
        public Models.EnumContractFinanceChargeTypeEnum ChargeType { get; set; }

        /// <summary>
        /// Campo para informações adicionais.
        /// [Restrição] Obrigatório se selecionada a opção 'OUTROS' em Tipo de encargo pactuado no contrato.
        /// </summary>
        [JsonProperty("chargeAdditionalInfo", NullValueHandling = NullValueHandling.Ignore)]
        public string ChargeAdditionalInfo { get; set; }

        /// <summary>
        /// Representa o valor do encargo em percentual pactuado no contrato.
        /// O preenchimento deve respeitar as 6 casas decimais, mesmo que venham preenchidas com zeros(representação de porcentagem p.ex: 0.150000.
        /// Este valor representa 15%. O valor 1 representa 100%).
        /// </summary>
        [JsonProperty("chargeRate", NullValueHandling = NullValueHandling.Ignore)]
        public string ChargeRate { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"FinancingsFinanceCharge : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is FinancingsFinanceCharge other &&
                this.ChargeType.Equals(other.ChargeType) &&
                ((this.ChargeAdditionalInfo == null && other.ChargeAdditionalInfo == null) || (this.ChargeAdditionalInfo?.Equals(other.ChargeAdditionalInfo) == true)) &&
                ((this.ChargeRate == null && other.ChargeRate == null) || (this.ChargeRate?.Equals(other.ChargeRate) == true));
        }
        

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.ChargeType = {this.ChargeType}");
            toStringOutput.Add($"this.ChargeAdditionalInfo = {(this.ChargeAdditionalInfo == null ? "null" : this.ChargeAdditionalInfo == string.Empty ? "" : this.ChargeAdditionalInfo)}");
            toStringOutput.Add($"this.ChargeRate = {(this.ChargeRate == null ? "null" : this.ChargeRate == string.Empty ? "" : this.ChargeRate)}");
        }
    }
}