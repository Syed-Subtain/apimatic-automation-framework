// <copyright file="TypeNumberOfInstalmentsEnum.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace APIFinancingsOpenBankingBrasil.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Runtime.Serialization;
    using APIFinancingsOpenBankingBrasil.Standard;
    using APIFinancingsOpenBankingBrasil.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// TypeNumberOfInstalmentsEnum.
    /// </summary>
    [JsonConverter(typeof(StringEnumConverter))]
    public enum TypeNumberOfInstalmentsEnum
    {
        /// <summary>
        /// DIA.
        /// </summary>
        [EnumMember(Value = "DIA")]
        DIA,

        /// <summary>
        /// SEMANA.
        /// </summary>
        [EnumMember(Value = "SEMANA")]
        SEMANA,

        /// <summary>
        /// MES.
        /// </summary>
        [EnumMember(Value = "MES")]
        MES,

        /// <summary>
        /// ANO.
        /// </summary>
        [EnumMember(Value = "ANO")]
        ANO,

        /// <summary>
        /// SEMPRAZOTOTAL.
        /// </summary>
        [EnumMember(Value = "SEM_PRAZO_TOTAL")]
        SEMPRAZOTOTAL
    }
}