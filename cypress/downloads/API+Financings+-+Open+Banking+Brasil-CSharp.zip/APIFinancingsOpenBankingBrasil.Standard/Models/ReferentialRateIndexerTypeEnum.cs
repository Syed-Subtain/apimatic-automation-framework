// <copyright file="ReferentialRateIndexerTypeEnum.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace APIFinancingsOpenBankingBrasil.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Runtime.Serialization;
    using APIFinancingsOpenBankingBrasil.Standard;
    using APIFinancingsOpenBankingBrasil.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// ReferentialRateIndexerTypeEnum.
    /// </summary>
    [JsonConverter(typeof(StringEnumConverter))]
    public enum ReferentialRateIndexerTypeEnum
    {
        /// <summary>
        /// SEMTIPOINDEXADOR.
        /// </summary>
        [EnumMember(Value = "SEM_TIPO_INDEXADOR")]
        SEMTIPOINDEXADOR,

        /// <summary>
        /// PREFIXADO.
        /// </summary>
        [EnumMember(Value = "PRE_FIXADO")]
        PREFIXADO,

        /// <summary>
        /// POSFIXADO.
        /// </summary>
        [EnumMember(Value = "POS_FIXADO")]
        POSFIXADO,

        /// <summary>
        /// FLUTUANTES.
        /// </summary>
        [EnumMember(Value = "FLUTUANTES")]
        FLUTUANTES,

        /// <summary>
        /// INDICESPRECOS.
        /// </summary>
        [EnumMember(Value = "INDICES_PRECOS")]
        INDICESPRECOS,

        /// <summary>
        /// CREDITORURAL.
        /// </summary>
        [EnumMember(Value = "CREDITO_RURAL")]
        CREDITORURAL,

        /// <summary>
        /// OUTROSINDEXADORES.
        /// </summary>
        [EnumMember(Value = "OUTROS_INDEXADORES")]
        OUTROSINDEXADORES
    }
}