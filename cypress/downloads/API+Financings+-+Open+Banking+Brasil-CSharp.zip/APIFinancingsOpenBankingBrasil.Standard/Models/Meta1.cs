// <copyright file="Meta1.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace APIFinancingsOpenBankingBrasil.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using APIFinancingsOpenBankingBrasil.Standard;
    using APIFinancingsOpenBankingBrasil.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// Meta1.
    /// </summary>
    public class Meta1
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="Meta1"/> class.
        /// </summary>
        public Meta1()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="Meta1"/> class.
        /// </summary>
        /// <param name="requestDateTime">requestDateTime.</param>
        public Meta1(
            DateTime requestDateTime)
        {
            this.RequestDateTime = requestDateTime;
        }

        /// <summary>
        /// Data e hora da consulta, conforme especificação RFC-3339, formato UTC.
        /// </summary>
        [JsonConverter(typeof(IsoDateTimeConverter))]
        [JsonProperty("requestDateTime")]
        public DateTime RequestDateTime { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"Meta1 : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is Meta1 other &&
                this.RequestDateTime.Equals(other.RequestDateTime);
        }
        

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.RequestDateTime = {this.RequestDateTime}");
        }
    }
}