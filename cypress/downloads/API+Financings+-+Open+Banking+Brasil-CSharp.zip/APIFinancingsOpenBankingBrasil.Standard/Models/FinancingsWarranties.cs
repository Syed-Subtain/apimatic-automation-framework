// <copyright file="FinancingsWarranties.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace APIFinancingsOpenBankingBrasil.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using APIFinancingsOpenBankingBrasil.Standard;
    using APIFinancingsOpenBankingBrasil.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// FinancingsWarranties.
    /// </summary>
    public class FinancingsWarranties
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="FinancingsWarranties"/> class.
        /// </summary>
        public FinancingsWarranties()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="FinancingsWarranties"/> class.
        /// </summary>
        /// <param name="warrantyType">warrantyType.</param>
        /// <param name="warrantySubType">warrantySubType.</param>
        /// <param name="currency">currency.</param>
        /// <param name="warrantyAmount">warrantyAmount.</param>
        public FinancingsWarranties(
            Models.WarrantyTypeEnum warrantyType,
            Models.WarrantySubTypeEnum warrantySubType,
            string currency = null,
            string warrantyAmount = null)
        {
            this.Currency = currency;
            this.WarrantyType = warrantyType;
            this.WarrantySubType = warrantySubType;
            this.WarrantyAmount = warrantyAmount;
        }

        /// <summary>
        /// Moeda referente ao valor da garantia, segundo modelo ISO-4217. p.ex. 'BRL'. Todos os valores monetários informados estão representados com a moeda vigente do Brasil
        /// </summary>
        [JsonProperty("currency", NullValueHandling = NullValueHandling.Ignore)]
        public string Currency { get; set; }

        /// <summary>
        /// Denominação/Identificação do tipo da garantia que avaliza a Modalidade da Operação de Crédito contratada  (Doc 3040, Anexo 12)
        /// </summary>
        [JsonProperty("warrantyType", ItemConverterType = typeof(StringEnumConverter))]
        public Models.WarrantyTypeEnum WarrantyType { get; set; }

        /// <summary>
        /// Denominação/Identificação do sub tipo da garantia que avaliza a Modalidade da Operação de Crédito contratada (Doc 3040, Anexo 12).
        /// </summary>
        [JsonProperty("warrantySubType", ItemConverterType = typeof(StringEnumConverter))]
        public Models.WarrantySubTypeEnum WarrantySubType { get; set; }

        /// <summary>
        /// Valor original da garantia. Expresso em valor monetário com no mínimo 2 casas e no máximo 4 casas decimais.
        /// </summary>
        [JsonProperty("warrantyAmount", NullValueHandling = NullValueHandling.Ignore)]
        public string WarrantyAmount { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"FinancingsWarranties : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is FinancingsWarranties other &&
                ((this.Currency == null && other.Currency == null) || (this.Currency?.Equals(other.Currency) == true)) &&
                this.WarrantyType.Equals(other.WarrantyType) &&
                this.WarrantySubType.Equals(other.WarrantySubType) &&
                ((this.WarrantyAmount == null && other.WarrantyAmount == null) || (this.WarrantyAmount?.Equals(other.WarrantyAmount) == true));
        }
        

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.Currency = {(this.Currency == null ? "null" : this.Currency == string.Empty ? "" : this.Currency)}");
            toStringOutput.Add($"this.WarrantyType = {this.WarrantyType}");
            toStringOutput.Add($"this.WarrantySubType = {this.WarrantySubType}");
            toStringOutput.Add($"this.WarrantyAmount = {(this.WarrantyAmount == null ? "null" : this.WarrantyAmount == string.Empty ? "" : this.WarrantyAmount)}");
        }
    }
}