// <copyright file="EnumContractFinanceChargeTypeEnum.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace APIFinancingsOpenBankingBrasil.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Runtime.Serialization;
    using APIFinancingsOpenBankingBrasil.Standard;
    using APIFinancingsOpenBankingBrasil.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// EnumContractFinanceChargeTypeEnum.
    /// </summary>
    [JsonConverter(typeof(StringEnumConverter))]
    public enum EnumContractFinanceChargeTypeEnum
    {
        /// <summary>
        /// JUROSREMUNERATORIOSPORATRASO.
        /// </summary>
        [EnumMember(Value = "JUROS_REMUNERATORIOS_POR_ATRASO")]
        JUROSREMUNERATORIOSPORATRASO,

        /// <summary>
        /// MULTAATRASOPAGAMENTO.
        /// </summary>
        [EnumMember(Value = "MULTA_ATRASO_PAGAMENTO")]
        MULTAATRASOPAGAMENTO,

        /// <summary>
        /// JUROSMORAATRASO.
        /// </summary>
        [EnumMember(Value = "JUROS_MORA_ATRASO")]
        JUROSMORAATRASO,

        /// <summary>
        /// IOFCONTRATACAO.
        /// </summary>
        [EnumMember(Value = "IOF_CONTRATACAO")]
        IOFCONTRATACAO,

        /// <summary>
        /// IOFPORATRASO.
        /// </summary>
        [EnumMember(Value = "IOF_POR_ATRASO")]
        IOFPORATRASO,

        /// <summary>
        /// SEMENCARGO.
        /// </summary>
        [EnumMember(Value = "SEM_ENCARGO")]
        SEMENCARGO,

        /// <summary>
        /// OUTROS.
        /// </summary>
        [EnumMember(Value = "OUTROS")]
        OUTROS
    }
}