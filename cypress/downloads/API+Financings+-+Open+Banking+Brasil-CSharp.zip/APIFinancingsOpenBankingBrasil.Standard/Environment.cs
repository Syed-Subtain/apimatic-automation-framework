// <copyright file="Environment.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace APIFinancingsOpenBankingBrasil.Standard
{
    using System.Runtime.Serialization;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    /// <summary>
    /// Available environments.
    /// </summary>
    [JsonConverter(typeof(StringEnumConverter))]
    public enum Environment
    {
        /// <summary>
        /// Servidor de Produção.
        /// </summary>
        [EnumMember(Value = "production")]
        Production,

        /// <summary>
        /// Servidor de Produção.
        /// </summary>
        [EnumMember(Value = "environment2")]
        Environment2,

        /// <summary>
        /// Servidor de Produção.
        /// </summary>
        [EnumMember(Value = "environment3")]
        Environment3,

        /// <summary>
        /// Servidor de Homologação.
        /// </summary>
        [EnumMember(Value = "environment4")]
        Environment4,

        /// <summary>
        /// Servidor de Homologação.
        /// </summary>
        [EnumMember(Value = "environment5")]
        Environment5,

        /// <summary>
        /// Servidor de Homologação.
        /// </summary>
        [EnumMember(Value = "environment6")]
        Environment6,
    }
}
