// <copyright file="APIFinancingsOpenBankingBrasilClient.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace APIFinancingsOpenBankingBrasil.Standard
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Net;
    using System.Text;
    using APIFinancingsOpenBankingBrasil.Standard.Authentication;
    using APIFinancingsOpenBankingBrasil.Standard.Controllers;
    using APIFinancingsOpenBankingBrasil.Standard.Http.Client;
    using APIFinancingsOpenBankingBrasil.Standard.Utilities;

    /// <summary>
    /// The gateway for the SDK. This class acts as a factory for Controller and
    /// holds the configuration of the SDK.
    /// </summary>
    public sealed class APIFinancingsOpenBankingBrasilClient : IConfiguration
    {
        // A map of environments and their corresponding servers/baseurls
        private static readonly Dictionary<Environment, Dictionary<Server, string>> EnvironmentsMap =
            new Dictionary<Environment, Dictionary<Server, string>>
        {
            {
                Environment.Production, new Dictionary<Server, string>
                {
                    { Server.Default, "https://api.banco.com.br/open-banking/financings/v2" },
                }
            },
            {
                Environment.Environment2, new Dictionary<Server, string>
                {
                    { Server.Default, "https://auth.mockbank.poc.raidiam.io/.well-known" },
                }
            },
            {
                Environment.Environment3, new Dictionary<Server, string>
                {
                    { Server.Default, "https://authserver.example" },
                }
            },
            {
                Environment.Environment4, new Dictionary<Server, string>
                {
                    { Server.Default, "https://apih.banco.com.br/open-banking/financings/v2" },
                }
            },
            {
                Environment.Environment5, new Dictionary<Server, string>
                {
                    { Server.Default, "https://auth.mockbank.poc.raidiam.io/.well-known" },
                }
            },
            {
                Environment.Environment6, new Dictionary<Server, string>
                {
                    { Server.Default, "https://authserver.example" },
                }
            },
        };

        private readonly IDictionary<string, IAuthManager> authManagers;
        private readonly IHttpClient httpClient;
        private readonly AuthorizationCodeAuthManager authorizationCodeAuthManager;

        private readonly Lazy<FinancingsController> financings;
        private readonly Lazy<OAuthAuthorizationController> oAuthAuthorization;

        private APIFinancingsOpenBankingBrasilClient(
            Environment environment,
            string authorizationCodeClientId,
            string authorizationCodeClientSecret,
            string authorizationCodeRedirectUri,
            Models.OAuthToken authorizationCodeToken,
            List<Models.AuthorizationCodeScopeEnum> authorizationCodeScopes,
            IDictionary<string, IAuthManager> authManagers,
            IHttpClient httpClient,
            IHttpClientConfiguration httpClientConfiguration)
        {
            this.Environment = environment;
            this.httpClient = httpClient;
            this.authManagers = (authManagers == null) ? new Dictionary<string, IAuthManager>() : new Dictionary<string, IAuthManager>(authManagers);
            this.HttpClientConfiguration = httpClientConfiguration;

            this.financings = new Lazy<FinancingsController>(
                () => new FinancingsController(this, this.httpClient, this.authManagers));
            this.oAuthAuthorization = new Lazy<OAuthAuthorizationController>(
                () => new OAuthAuthorizationController(this, this.httpClient, this.authManagers));

            if (this.authManagers.ContainsKey("global"))
            {
                this.authorizationCodeAuthManager = (AuthorizationCodeAuthManager)this.authManagers["global"];
            }

            if (!this.authManagers.ContainsKey("global")
                || !this.AuthorizationCodeAuth.Equals(authorizationCodeClientId, authorizationCodeClientSecret, authorizationCodeRedirectUri, authorizationCodeToken, authorizationCodeScopes))
            {
                this.authorizationCodeAuthManager = new AuthorizationCodeAuthManager(authorizationCodeClientId, authorizationCodeClientSecret, authorizationCodeRedirectUri, authorizationCodeToken, authorizationCodeScopes, this);
                this.authManagers["global"] = this.authorizationCodeAuthManager;
            }
        }

        /// <summary>
        /// Gets FinancingsController controller.
        /// </summary>
        public FinancingsController FinancingsController => this.financings.Value;

        /// <summary>
        /// Gets OAuthAuthorizationController controller.
        /// </summary>
        public OAuthAuthorizationController OAuthAuthorizationController => this.oAuthAuthorization.Value;

        /// <summary>
        /// Gets the configuration of the Http Client associated with this client.
        /// </summary>
        public IHttpClientConfiguration HttpClientConfiguration { get; }

        /// <summary>
        /// Gets Environment.
        /// Current API environment.
        /// </summary>
        public Environment Environment { get; }

        /// <summary>
        /// Gets auth managers.
        /// </summary>
        internal IDictionary<string, IAuthManager> AuthManagers => this.authManagers;

        /// <summary>
        /// Gets http client.
        /// </summary>
        internal IHttpClient HttpClient => this.httpClient;

        /// <summary>
        /// Gets the credentials to use with AuthorizationCodeAuth.
        /// </summary>
        public IAuthorizationCodeAuth AuthorizationCodeAuth => this.authorizationCodeAuthManager;

        /// <summary>
        /// Gets the URL for a particular alias in the current environment and appends
        /// it with template parameters.
        /// </summary>
        /// <param name="alias">Default value:DEFAULT.</param>
        /// <returns>Returns the baseurl.</returns>
        public string GetBaseUri(Server alias = Server.Default)
        {
            StringBuilder url = new StringBuilder(EnvironmentsMap[this.Environment][alias]);
            ApiHelper.AppendUrlWithTemplateParameters(url, this.GetBaseUriParameters());

            return url.ToString();
        }

        /// <summary>
        /// Creates an object of the APIFinancingsOpenBankingBrasilClient using the values provided for the builder.
        /// </summary>
        /// <returns>Builder.</returns>
        public Builder ToBuilder()
        {
            Builder builder = new Builder()
                .Environment(this.Environment)
                .OAuthToken(this.authorizationCodeAuthManager.OAuthToken)
                .OAuthScopes(this.authorizationCodeAuthManager.OAuthScopes)
                .AuthorizationCodeAuth(this.authorizationCodeAuthManager.OAuthClientId, this.authorizationCodeAuthManager.OAuthClientSecret, this.authorizationCodeAuthManager.OAuthRedirectUri)
                .HttpClient(this.httpClient)
                .AuthManagers(this.authManagers)
                .HttpClientConfig(config => config.Build());

            return builder;
        }

        /// <inheritdoc/>
        public override string ToString()
        {
            return
                $"Environment = {this.Environment}, " +
                $"HttpClientConfiguration = {this.HttpClientConfiguration}, ";
        }

        /// <summary>
        /// Creates the client using builder.
        /// </summary>
        /// <returns> APIFinancingsOpenBankingBrasilClient.</returns>
        internal static APIFinancingsOpenBankingBrasilClient CreateFromEnvironment()
        {
            var builder = new Builder();

            string environment = System.Environment.GetEnvironmentVariable("API_FINANCINGS_OPEN_BANKING_BRASIL_STANDARD_ENVIRONMENT");
            string authorizationCodeClientId = System.Environment.GetEnvironmentVariable("API_FINANCINGS_OPEN_BANKING_BRASIL_STANDARD_AUTHORIZATION_CODE_CLIENT_ID");
            string authorizationCodeClientSecret = System.Environment.GetEnvironmentVariable("API_FINANCINGS_OPEN_BANKING_BRASIL_STANDARD_AUTHORIZATION_CODE_CLIENT_SECRET");
            string authorizationCodeRedirectUri = System.Environment.GetEnvironmentVariable("API_FINANCINGS_OPEN_BANKING_BRASIL_STANDARD_AUTHORIZATION_CODE_REDIRECT_URI");

            if (environment != null)
            {
                builder.Environment(ApiHelper.JsonDeserialize<Environment>($"\"{environment}\""));
            }

            if (authorizationCodeClientId != null && authorizationCodeClientSecret != null && authorizationCodeRedirectUri != null)
            {
                builder.AuthorizationCodeAuth(authorizationCodeClientId, authorizationCodeClientSecret, authorizationCodeRedirectUri);
            }

            return builder.Build();
        }

        /// <summary>
        /// Makes a list of the BaseURL parameters.
        /// </summary>
        /// <returns>Returns the parameters list.</returns>
        private List<KeyValuePair<string, object>> GetBaseUriParameters()
        {
            List<KeyValuePair<string, object>> kvpList = new List<KeyValuePair<string, object>>()
            {
            };
            return kvpList;
        }

        /// <summary>
        /// Builder class.
        /// </summary>
        public class Builder
        {
            private Environment environment = APIFinancingsOpenBankingBrasil.Standard.Environment.Production;
            private string authorizationCodeClientId = "";
            private string authorizationCodeClientSecret = "";
            private string authorizationCodeRedirectUri = "";
            private Models.OAuthToken authorizationCodeToken = null;
            private List<Models.AuthorizationCodeScopeEnum> authorizationCodeScopes = null;
            private IDictionary<string, IAuthManager> authManagers = new Dictionary<string, IAuthManager>();
            private HttpClientConfiguration.Builder httpClientConfig = new HttpClientConfiguration.Builder();
            private IHttpClient httpClient;

            /// <summary>
            /// Sets credentials for AuthorizationCodeAuth.
            /// </summary>
            /// <param name="authorizationCodeClientId">AuthorizationCodeClientId.</param>
            /// <param name="authorizationCodeClientSecret">AuthorizationCodeClientSecret.</param>
            /// <param name="authorizationCodeRedirectUri">AuthorizationCodeRedirectUri.</param>
            /// <returns>Builder.</returns>
            public Builder AuthorizationCodeAuth(string authorizationCodeClientId, string authorizationCodeClientSecret, string authorizationCodeRedirectUri)
            {
                this.authorizationCodeClientId = authorizationCodeClientId ?? throw new ArgumentNullException(nameof(authorizationCodeClientId));
                this.authorizationCodeClientSecret = authorizationCodeClientSecret ?? throw new ArgumentNullException(nameof(authorizationCodeClientSecret));
                this.authorizationCodeRedirectUri = authorizationCodeRedirectUri ?? throw new ArgumentNullException(nameof(authorizationCodeRedirectUri));
                return this;
            }

            /// <summary>
            /// Sets OAuthToken.
            /// </summary>
            /// <param name="authorizationCodeToken">AuthorizationCodeToken.</param>
            /// <returns>Builder.</returns>
            public Builder AuthorizationCodeToken(Models.OAuthToken authorizationCodeToken)
            {
                this.authorizationCodeToken = authorizationCodeToken;
                return this;
            }

            /// <summary>
            /// Sets OAuthScopes.
            /// </summary>
            /// <param name="authorizationCodeScopes">AuthorizationCodeScopes.</param>
            /// <returns>Builder.</returns>
            public Builder AuthorizationCodeScopes(List<Models.AuthorizationCodeScopeEnum> authorizationCodeScopes)
            {
                this.authorizationCodeScopes = authorizationCodeScopes;
                return this;
            }

            /// <summary>
            /// Sets Environment.
            /// </summary>
            /// <param name="environment"> Environment. </param>
            /// <returns> Builder. </returns>
            public Builder Environment(Environment environment)
            {
                this.environment = environment;
                return this;
            }

            /// <summary>
            /// Sets HttpClientConfig.
            /// </summary>
            /// <param name="action"> Action. </param>
            /// <returns>Builder.</returns>
            public Builder HttpClientConfig(Action<HttpClientConfiguration.Builder> action)
            {
                if (action is null)
                {
                    throw new ArgumentNullException(nameof(action));
                }

                action(this.httpClientConfig);
                return this;
            }

            /// <summary>
            /// Sets the IHttpClient for the Builder.
            /// </summary>
            /// <param name="httpClient"> http client. </param>
            /// <returns>Builder.</returns>
            internal Builder HttpClient(IHttpClient httpClient)
            {
                this.httpClient = httpClient ?? throw new ArgumentNullException(nameof(httpClient));
                return this;
            }

            /// <summary>
            /// Sets the authentication managers for the Builder.
            /// </summary>
            /// <param name="authManagers"> auth managers. </param>
            /// <returns>Builder.</returns>
            internal Builder AuthManagers(IDictionary<string, IAuthManager> authManagers)
            {
                this.authManagers = authManagers ?? throw new ArgumentNullException(nameof(authManagers));
                return this;
            }

            /// <summary>
            /// Creates an object of the APIFinancingsOpenBankingBrasilClient using the values provided for the builder.
            /// </summary>
            /// <returns>APIFinancingsOpenBankingBrasilClient.</returns>
            public APIFinancingsOpenBankingBrasilClient Build()
            {
                this.httpClient = new HttpClientWrapper(this.httpClientConfig.Build());

                return new APIFinancingsOpenBankingBrasilClient(
                    this.environment,
                    this.authorizationCodeClientId,
                    this.authorizationCodeClientSecret,
                    this.authorizationCodeRedirectUri,
                    this.authorizationCodeToken,
                    this.authorizationCodeScopes,
                    this.authManagers,
                    this.httpClient,
                    this.httpClientConfig.Build());
            }
        }
    }
}
