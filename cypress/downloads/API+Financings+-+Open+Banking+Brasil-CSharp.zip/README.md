
# Getting Started with API Financings - Open Banking Brasil

## Introduction

API de informações de operações de financiamentos do Open Banking Brasil – Fase 2.
API que retorna informações de operações de crédito do tipo financiamento, mantidas nas instituições transmissoras por seus clientes, incluindo dados como denominação, modalidade, número do contrato, tarifas, prazo, prestações, pagamentos, amortizações, garantias, encargos e taxas de juros remuneratórios.\
Não possui segregação entre pessoa natural e pessoa jurídica.\
Requer consentimento do cliente para todos os `endpoints`.

### Orientações

A `Role`  do diretório de participantes relacionada à presente API é a `DADOS`.\
Para todos os `endpoints` desta API é previsto o envio de um `token` através do header `Authorization`.\
Este token deverá estar relacionado ao consentimento (`consentId`) mantido na instituição transmissora dos dados, o qual permitirá a pesquisa e retorno, na API em questão, dos
dados relacionados ao `consentId` específico relacionado.\
Os dados serão devolvidos na consulta desde que o `consentId` relacionado corresponda a um consentimento válido e com o status `AUTHORISED`.\
É também necessário que o recurso em questão (conta, contrato, etc) esteja disponível na instituição transmissora (ou seja, sem boqueios de qualquer natureza e com todas as autorizações/consentimentos já autorizados).\
Além disso as `permissions` necessárias deverão ter sido solicitadas quando da criação do consentimento relacionado (`consentId`).\
Relacionamos a seguir as `permissions` necessárias para a consulta de dados em cada `endpoint` da presente API.

#### Observação

- No endpoint `/contracts/{contratId}/payments` a paginação ocorrerá sob os dados contidos no campo `releases` do tipo lista.

#### Permissions necessárias para a API Financings

Para cada um dos paths desta API, além dos escopos (`scopes`) indicados existem `permissions` que deverão ser observadas:

##### `/contracts`

- permissions:
  - GET: **FINANCINGS_READ**

##### `/contracts/{contractId}`

- permissions:
  - GET **FINANCINGS_READ**

##### `/contracts/{contractId}/warranties`

- permissions:
  - GET: **FINANCINGS_WARRANTIES_READ**

##### `/contracts/{contractId}/scheduled-instalments`

- permissions:
  - GET: **FINANCINGS_SCHEDULED_INSTALMENTS_READ**

##### `/contracts/{contractId}/payments`

- permissions:
  - GET: **FINANCINGS_PAYMENTS_READ**

## Building

The generated code uses the Newtonsoft Json.NET NuGet Package. If the automatic NuGet package restore is enabled, these dependencies will be installed automatically. Therefore, you will need internet access for build.

* Open the solution (APIFinancingsOpenBankingBrasil.sln) file.

Invoke the build process using Ctrl + Shift + B shortcut key or using the Build menu as shown below.

The build process generates a portable class library, which can be used like a normal class library. The generated library is compatible with Windows Forms, Windows RT, Windows Phone 8, Silverlight 5, Xamarin iOS, Xamarin Android and Mono. More information on how to use can be found at the MSDN Portable Class Libraries documentation.

## Installation

The following section explains how to use the APIFinancingsOpenBankingBrasil.Standard library in a new project.

### 1. Starting a new project

For starting a new project, right click on the current solution from the solution explorer and choose `Add -> New Project`.

![Add a new project in Visual Studio](https://apidocs.io/illustration/cs?workspaceFolder=API%20Financings%20-%20Open%20Banking%20Brasil-CSharp&workspaceName=APIFinancingsOpenBankingBrasil&projectName=APIFinancingsOpenBankingBrasil.Standard&rootNamespace=APIFinancingsOpenBankingBrasil.Standard&step=addProject)

Next, choose `Console Application`, provide `TestConsoleProject` as the project name and click OK.

![Create a new Console Application in Visual Studio](https://apidocs.io/illustration/cs?workspaceFolder=API%20Financings%20-%20Open%20Banking%20Brasil-CSharp&workspaceName=APIFinancingsOpenBankingBrasil&projectName=APIFinancingsOpenBankingBrasil.Standard&rootNamespace=APIFinancingsOpenBankingBrasil.Standard&step=createProject)

### 2. Set as startup project

The new console project is the entry point for the eventual execution. This requires us to set the `TestConsoleProject` as the start-up project. To do this, right-click on the `TestConsoleProject` and choose `Set as StartUp Project` form the context menu.

![Adding a project reference](https://apidocs.io/illustration/cs?workspaceFolder=API%20Financings%20-%20Open%20Banking%20Brasil-CSharp&workspaceName=APIFinancingsOpenBankingBrasil&projectName=APIFinancingsOpenBankingBrasil.Standard&rootNamespace=APIFinancingsOpenBankingBrasil.Standard&step=setStartup)

### 3. Add reference of the library project

In order to use the Tester library in the new project, first we must add a project reference to the `TestConsoleProject`. First, right click on the `References` node in the solution explorer and click `Add Reference...`

![Adding a project reference](https://apidocs.io/illustration/cs?workspaceFolder=API%20Financings%20-%20Open%20Banking%20Brasil-CSharp&workspaceName=APIFinancingsOpenBankingBrasil&projectName=APIFinancingsOpenBankingBrasil.Standard&rootNamespace=APIFinancingsOpenBankingBrasil.Standard&step=addReference)

Next, a window will be displayed where we must set the `checkbox` on `Tester.Tests` and click `OK`. By doing this, we have added a reference of the `Tester.Tests` project into the new `TestConsoleProject`.

![Creating a project reference](https://apidocs.io/illustration/cs?workspaceFolder=API%20Financings%20-%20Open%20Banking%20Brasil-CSharp&workspaceName=APIFinancingsOpenBankingBrasil&projectName=APIFinancingsOpenBankingBrasil.Standard&rootNamespace=APIFinancingsOpenBankingBrasil.Standard&step=createReference)

### 4. Write sample code

Once the `TestConsoleProject` is created, a file named `Program.cs` will be visible in the solution explorer with an empty `Main` method. This is the entry point for the execution of the entire solution. Here, you can add code to initialize the client library and acquire the instance of a Controller class. Sample code to initialize the client library and using Controller methods is given in the subsequent sections.

![Adding a project reference](https://apidocs.io/illustration/cs?workspaceFolder=API%20Financings%20-%20Open%20Banking%20Brasil-CSharp&workspaceName=APIFinancingsOpenBankingBrasil&projectName=APIFinancingsOpenBankingBrasil.Standard&rootNamespace=APIFinancingsOpenBankingBrasil.Standard&step=addCode)

## Initialize the API Client

**_Note:_** Documentation for the client can be found [here.](doc/client.md)

The following parameters are configurable for the API Client:

| Parameter | Type | Description |
|  --- | --- | --- |
| `Environment` | Environment | The API environment. <br> **Default: `Environment.Production`** |
| `Timeout` | `TimeSpan` | Http client timeout.<br>*Default*: `TimeSpan.FromSeconds(100)` |
| `AuthorizationCodeClientId` | `string` | OAuth 2 Client ID |
| `AuthorizationCodeClientSecret` | `string` | OAuth 2 Client Secret |
| `AuthorizationCodeRedirectUri` | `string` | OAuth 2 Redirection endpoint or Callback Uri |
| `AuthorizationCodeToken` | `Models.OAuthToken` | Object for storing information about the OAuth token |
| `AuthorizationCodeScopes` | `List<Models.AuthorizationCodeScopeEnum>` |  |

The API client can be initialized as follows:

```csharp
APIFinancingsOpenBankingBrasil.Standard.APIFinancingsOpenBankingBrasilClient client = new APIFinancingsOpenBankingBrasil.Standard.APIFinancingsOpenBankingBrasilClient.Builder()
    .OAuthScopes(new List<OAuthScopeEnum>(){OAuthScopeEnum.Openid, OAuthScopeEnum.Financings})
    .AuthorizationCodeAuth("AuthorizationCodeClientId", "AuthorizationCodeClientSecret", "AuthorizationCodeRedirectUri")
    .Environment(APIFinancingsOpenBankingBrasil.Standard.Environment.Production)
    .HttpClientConfig(config => config.NumberOfRetries(0))
    .Build();
```

## Environments

The SDK can be configured to use a different environment for making API calls. Available environments are:

### Fields

| Name | Description |
|  --- | --- |
| production | **Default** Servidor de Produção |
| environment2 | Servidor de Produção |
| environment3 | Servidor de Produção |
| environment4 | Servidor de Homologação |
| environment5 | Servidor de Homologação |
| environment6 | Servidor de Homologação |

## Authorization

This API uses `OAuth 2 Authorization Code Grant`.

## Authorization Code Grant

Your application must obtain user authorization before it can execute an endpoint call incase this SDK chooses to use *OAuth 2.0 Authorization Code Grant*. This authorization includes the following steps

### 1\. Obtain user consent

To obtain user's consent, you must redirect the user to the authorization page.The `BuildAuthorizationUrl()` method creates the URL to the authorization page. You must pass the scopes for which you need permission to access.

```csharp
string authUrl = client.AuthorizationCodeAuth.BuildAuthorizationUrl();
```

### 2\. Handle the OAuth server response

Once the user responds to the consent request, the OAuth 2.0 server responds to your application's access request by redirecting the user to the redirect URI specified set in `Configuration`.

If the user approves the request, the authorization code will be sent as the `code` query string:

```
https://example.com/oauth/callback?code=XXXXXXXXXXXXXXXXXXXXXXXXX
```

If the user does not approve the request, the response contains an `error` query string:

```
https://example.com/oauth/callback?error=access_denied
```

### 3\. Authorize the client using the code

After the server receives the code, it can exchange this for an *access token*. The access token is an object containing information for authorizing client requests and refreshing the token itself.

```csharp
var authManager = client.AuthorizationCodeAuth;

try
{
    OAuthToken token = authManager.FetchToken(authorizationCode);
    // re-instantiate the client with OAuth token
    client = client.ToBuilder().OAuthToken(token).Build();
}
catch (ApiException e)
{
    // TODO Handle exception
}
```

### Scopes

Scopes enable your application to only request access to the resources it needs while enabling users to control the amount of access they grant to your application. Available scopes are defined in the `AuthorizationCodeScopeEnum` enumeration.

| Scope Name | Description |
|  --- | --- |
| `OPENID` |  |
| `FINANCINGS` | Escopo necessário para acesso à API Financings. O controle dos endpoints específicos é feito via permissions. |
| `CONSENTCONSENTID` |  |

### Refreshing the token

An access token may expire after sometime. To extend its lifetime, you must refresh the token.

```csharp
if (authManager.IsTokenExpired())
{
    try
    {
        OAuthToken token = authManager.RefreshToken();
        // re-instantiate the client with OAuth token
        client = client.ToBuilder().OAuthToken(token).Build();
    }
    catch (ApiException e)
    {
        // TODO Handle exception
    }
}
```

If a token expires, an exception will be thrown before the next endpoint call requiring authentication.

### Storing an access token for reuse

It is recommended that you store the access token for reuse.

```csharp
// store token
SaveTokenToDatabase(client.AuthorizationCodeAuth.OAuthToken);
```

### Creating a client from a stored token

To authorize a client from a stored access token, just set the access token in Configuration along with the other configuration parameters before creating the client:

```csharp
// load token later
OAuthToken token = LoadTokenFromDatabase();

// Provide token along with other configuration properties while instantiating the client
APIFinancingsOpenBankingBrasilClient client = client.ToBuilder().OAuthToken(token).Build();
```

## List of APIs

* [O Auth Authorization](doc/controllers/o-auth-authorization.md)
* [Financings](doc/controllers/financings.md)

## Classes Documentation

* [Utility Classes](doc/utility-classes.md)
* [HttpRequest](doc/http-request.md)
* [HttpResponse](doc/http-response.md)
* [HttpStringResponse](doc/http-string-response.md)
* [HttpContext](doc/http-context.md)
* [HttpClientConfiguration](doc/http-client-configuration.md)
* [HttpClientConfiguration Builder](doc/http-client-configuration-builder.md)
* [IAuthManager](doc/i-auth-manager.md)
* [ApiException](doc/api-exception.md)

