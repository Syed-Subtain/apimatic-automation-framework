
# Update a Phone Book Request

## Structure

`UpdateAPhoneBookRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `name` | `string` | Required | - | getName(): string | setName(string name): void |
| `attribute3` | `string` | Required | - | getAttribute3(): string | setAttribute3(string attribute3): void |

## Example (as JSON)

```json
{
  "name": "Soccer Moms and Dads",
  "attribute_3": "ID"
}
```

