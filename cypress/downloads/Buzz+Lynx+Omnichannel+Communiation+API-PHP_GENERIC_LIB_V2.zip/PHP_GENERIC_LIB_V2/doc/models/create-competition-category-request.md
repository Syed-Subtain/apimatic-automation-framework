
# Create Competition Category Request

## Structure

`CreateCompetitionCategoryRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `name` | `string` | Required | - | getName(): string | setName(string name): void |
| `text` | `string` | Required | - | getText(): string | setText(string text): void |
| `createDate` | `string` | Required | - | getCreateDate(): string | setCreateDate(string createDate): void |

## Example (as JSON)

```json
{
  "name": "Soccer Practice Reminder",
  "text": "Reminder: There is soccer practice on Wednesday at 16:00.",
  "create_date": "2015-12-08 16:47:45"
}
```

