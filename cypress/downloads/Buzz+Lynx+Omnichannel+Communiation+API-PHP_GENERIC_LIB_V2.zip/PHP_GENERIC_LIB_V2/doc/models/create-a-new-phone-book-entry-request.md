
# Create a New Phone Book Entry Request

## Structure

`CreateANewPhoneBookEntryRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `mobileNumber` | `string` | Required | - | getMobileNumber(): string | setMobileNumber(string mobileNumber): void |
| `title` | `string` | Required | - | getTitle(): string | setTitle(string title): void |
| `firstName` | `string` | Required | - | getFirstName(): string | setFirstName(string firstName): void |
| `lastName` | `string` | Required | - | getLastName(): string | setLastName(string lastName): void |
| `attribute1` | `string` | Required | Custom Attribute 1 for phone book entry | getAttribute1(): string | setAttribute1(string attribute1): void |
| `attribute2` | `string` | Required | Custom Attribute 2 for phone book entry | getAttribute2(): string | setAttribute2(string attribute2): void |
| `attribute3` | `string` | Required | Custom Attribute 3 for phone book entry | getAttribute3(): string | setAttribute3(string attribute3): void |
| `attribute4` | `string` | Required | Custom Attribute 4 for phone book entry | getAttribute4(): string | setAttribute4(string attribute4): void |
| `attribute5` | `string` | Required | Custom Attribute 5 for phone book entry | getAttribute5(): string | setAttribute5(string attribute5): void |

## Example (as JSON)

```json
{
  "mobile_number": "mobile_number0",
  "title": "title4",
  "first_name": "first_name0",
  "last_name": "last_name8",
  "attribute_1": "attribute_12",
  "attribute_2": "attribute_22",
  "attribute_3": "attribute_34",
  "attribute_4": "attribute_40",
  "attribute_5": "attribute_54"
}
```

