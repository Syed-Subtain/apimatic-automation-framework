
# Create a New Template Request

## Structure

`CreateANewTemplateRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `name` | `string` | Required | - | getName(): string | setName(string name): void |
| `text` | `string` | Required | - | getText(): string | setText(string text): void |
| `phoneBookId` | `string` | Required | - | getPhoneBookId(): string | setPhoneBookId(string phoneBookId): void |

## Example (as JSON)

```json
{
  "name": "Soccer Practice Reminder",
  "text": "Reminder: There is soccer practice on Wednesday at 16:00.",
  "phone_book_id": "123"
}
```

