
# Create a New Schedule Request

## Structure

`CreateANewScheduleRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `name` | `string` | Required | - | getName(): string | setName(string name): void |
| `type` | `string` | Required | - | getType(): string | setType(string type): void |
| `startDate` | `string` | Required | - | getStartDate(): string | setStartDate(string startDate): void |
| `endDate` | `string` | Required | - | getEndDate(): string | setEndDate(string endDate): void |
| `phoneBookId` | `string` | Required | - | getPhoneBookId(): string | setPhoneBookId(string phoneBookId): void |
| `templateId` | `string` | Required | - | getTemplateId(): string | setTemplateId(string templateId): void |
| `intervalType` | `string` | Required | - | getIntervalType(): string | setIntervalType(string intervalType): void |
| `interval` | `int` | Required | - | getInterval(): int | setInterval(int interval): void |

## Example (as JSON)

```json
{
  "name": "Soccer Practice Reminder",
  "type": "recurring",
  "start_date": "2015-11-08 14:00",
  "end_date": "2015-11-20 14:00",
  "phone_book_id": "59196",
  "template_id": "8465",
  "interval_type": "days",
  "interval": 30
}
```

