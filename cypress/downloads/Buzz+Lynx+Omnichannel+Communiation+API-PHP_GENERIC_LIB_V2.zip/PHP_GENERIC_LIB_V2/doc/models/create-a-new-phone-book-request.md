
# Create a New Phone Book Request

## Structure

`CreateANewPhoneBookRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `name` | `string` | Required | The name of the phone book (segment) | getName(): string | setName(string name): void |
| `attribute1` | `?string` | Optional | This specification allows you to specify a name for a first extensible attribute for the segment | getAttribute1(): ?string | setAttribute1(?string attribute1): void |
| `attribute2` | `?string` | Optional | This specification allows you to specify a name for a second extensible attribute for the segment | getAttribute2(): ?string | setAttribute2(?string attribute2): void |
| `attribute3` | `?string` | Optional | This specification allows you to specify a name for a third extensible attribute for the segment | getAttribute3(): ?string | setAttribute3(?string attribute3): void |
| `attribute4` | `?string` | Optional | This specification allows you to specify a name for a fourth extensible attribute for the segment | getAttribute4(): ?string | setAttribute4(?string attribute4): void |
| `attribute5` | `?string` | Optional | This specification allows you to specify a name for a fifth extensible attribute for the segment | getAttribute5(): ?string | setAttribute5(?string attribute5): void |

## Example (as JSON)

```json
{
  "name": "Soccer Moms",
  "attribute_1": "ChildName",
  "attribute_2": "Team"
}
```

