
# Send Messages Request

## Structure

`SendMessagesRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `mobileNumbers` | `string` | Required | - | getMobileNumbers(): string | setMobileNumbers(string mobileNumbers): void |
| `message` | `string` | Required | - | getMessage(): string | setMessage(string message): void |

## Example (as JSON)

```json
{
  "mobile_numbers": "5558328328,55553942432",
  "message": "Soccer practice will be on the 7th at 6."
}
```

