
# Update Phone Book Entry Request

## Structure

`UpdatePhoneBookEntryRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `mobileNumber` | `string` | Required | - | getMobileNumber(): string | setMobileNumber(string mobileNumber): void |
| `title` | `string` | Required | - | getTitle(): string | setTitle(string title): void |
| `firstName` | `string` | Required | - | getFirstName(): string | setFirstName(string firstName): void |
| `lastName` | `string` | Required | - | getLastName(): string | setLastName(string lastName): void |
| `attribute1` | `string` | Required | - | getAttribute1(): string | setAttribute1(string attribute1): void |
| `attribute2` | `string` | Required | - | getAttribute2(): string | setAttribute2(string attribute2): void |

## Example (as JSON)

```json
{
  "mobile_number": "821838384234",
  "title": "Mrs",
  "first_name": "Holly",
  "last_name": "Hunter",
  "attribute_1": "Myron",
  "attribute_2": "Team B"
}
```

