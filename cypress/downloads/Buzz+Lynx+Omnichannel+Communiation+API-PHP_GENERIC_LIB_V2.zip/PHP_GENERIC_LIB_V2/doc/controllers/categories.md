# Categories

```php
$categoriesController = $client->getCategoriesController();
```

## Class Name

`CategoriesController`

## Methods

* [Create Competition Category](../../doc/controllers/categories.md#create-competition-category)
* [Delete Competition Category](../../doc/controllers/categories.md#delete-competition-category)
* [Get Competition Categories](../../doc/controllers/categories.md#get-competition-categories)


# Create Competition Category

`POST /iwin-competition/api/v1/competitions/{id}/categories`

Create a new compeition category. Note that you can add the same category to multiple competitions at the same time by comma separating the competition IDs, e.g.
`/iwin-competition/api/v1/competitions/2334,2322/categories`, where `2334` and `2322` are the respective competition IDs.
This is useful for situations where you have more than one short code, e.g. a R2 short code and R30 short code for the same competition, but would like entrants to use either.

Important: Categories refresh every evening at 00:00. If you add a category at 15:00, the category will only be recognised at 00:00.

```php
function createCompetitionCategory(
    string $contentType,
    string $accept,
    CreateCompetitionCategoryRequest $body,
    string $id
): void
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `contentType` | `string` | Header, Required | - |
| `accept` | `string` | Header, Required | - |
| `body` | [`CreateCompetitionCategoryRequest`](../../doc/models/create-competition-category-request.md) | Body, Required | - |
| `id` | `string` | Template, Required | - |

## Response Type

`void`

## Example Usage

```php
$contentType = 'application/json';
$accept = 'application/json';
$body_name = 'Soccer Practice Reminder';
$body_text = 'Reminder: There is soccer practice on Wednesday at 16:00.';
$body_createDate = '2015-12-08 16:47:45';
$body = new Models\CreateCompetitionCategoryRequest(
    $body_name,
    $body_text,
    $body_createDate
);
$id = 'id0';

$categoriesController->createCompetitionCategory($contentType, $accept, $body, $id);
```


# Delete Competition Category

`DELETE /iwin-competition/api/v1/competitions/{id}/categories/{code}`

Delete a category. You can also delete the same category from different competitions in the same call by comma separating the competition IDs.

Important: Categories refresh every evening at 00:00. If you delete a category at 15:00, the category will only be recognised as deleted at 00:00.

```php
function deleteCompetitionCategory(string $accept, string $id): void
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `accept` | `string` | Header, Required | - |
| `id` | `string` | Template, Required | - |

## Response Type

`void`

## Example Usage

```php
$accept = 'application/json';
$id = 'id0';

$categoriesController->deleteCompetitionCategory($accept, $id);
```


# Get Competition Categories

`GET /iwin-competition/api/v1/competitions/{id}/categories`

Get all the categories (e.g. entrants) for a competition.

```php
function getCompetitionCategories(string $accept, string $id): void
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `accept` | `string` | Header, Required | - |
| `id` | `string` | Template, Required | - |

## Response Type

`void`

## Example Usage

```php
$accept = 'application/json';
$id = 'id0';

$categoriesController->getCompetitionCategories($accept, $id);
```

