# Sent Messages

View messages that have been sent. Sent messages can be used to monitor delivery status.

```php
$sentMessagesController = $client->getSentMessagesController();
```

## Class Name

`SentMessagesController`


# Get View Sent Messages

`GET /iwin/api/v1/sentmessages`

View all the sent messages.

```php
function getViewSentMessages(string $accept): void
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `accept` | `string` | Header, Required | - |

## Response Type

`void`

## Example Usage

```php
$accept = 'application/json';

$sentMessagesController->getViewSentMessages($accept);
```

