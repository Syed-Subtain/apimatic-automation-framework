# Account

The account resource provides an interface to update your Iwin account.

```php
$accountController = $client->getAccountController();
```

## Class Name

`AccountController`

## Methods

* [Get Account](../../doc/controllers/account.md#get-account)
* [Update Account](../../doc/controllers/account.md#update-account)


# Get Account

`GET /iwin/api/v1/account`

See your account details.

```php
function getAccount(string $accept): void
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `accept` | `string` | Header, Required | - |

## Response Type

`void`

## Example Usage

```php
$accept = 'application/json';

$accountController->getAccount($accept);
```


# Update Account

`PUT /iwin/api/v1/account`

Update your account details.

```php
function updateAccount(string $contentType, string $accept, UpdateAccountRequest $body): void
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `contentType` | `string` | Header, Required | - |
| `accept` | `string` | Header, Required | - |
| `body` | [`UpdateAccountRequest`](../../doc/models/update-account-request.md) | Body, Required | - |

## Response Type

`void`

## Example Usage

```php
$contentType = 'application/json';
$accept = 'application/json';
$body_firstName = 'Holly';
$body_lastName = 'Soccer practice will be on the 7th at 6.';
$body_email = 'holly.hunter@company.com';
$body_mobileNumber = '5557756235';
$body_password = 'hunter';
$body = new Models\UpdateAccountRequest(
    $body_firstName,
    $body_lastName,
    $body_email,
    $body_mobileNumber,
    $body_password
);

$accountController->updateAccount($contentType, $accept, $body);
```

