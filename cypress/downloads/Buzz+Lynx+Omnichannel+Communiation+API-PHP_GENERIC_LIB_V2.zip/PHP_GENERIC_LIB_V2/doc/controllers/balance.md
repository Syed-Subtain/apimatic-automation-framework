# Balance

```php
$balanceController = $client->getBalanceController();
```

## Class Name

`BalanceController`


# Get Balance

`GET /iwin/api/v1/balance`

Get your Iwin balance. Your balance is the number of messages that can be sent until your account balance is depleted.

```php
function getBalance(string $accept): void
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `accept` | `string` | Header, Required | - |

## Response Type

`void`

## Example Usage

```php
$accept = 'application/json';

$balanceController->getBalance($accept);
```

