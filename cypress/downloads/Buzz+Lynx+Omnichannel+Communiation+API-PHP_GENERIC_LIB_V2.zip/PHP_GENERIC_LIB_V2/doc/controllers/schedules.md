# Schedules

While messages are great for sending out some messages on an ad-hoc basis, schedules are more suited for
sending out messages to regular groups. Schedules are also very useful for personalised messages.
There are two types of schedules:

- `once off` - Once off schedules will be sent only once.

- `recurring` - Recurring schedules will be sent between the start and end date, on the interval specified.

```php
$schedulesController = $client->getSchedulesController();
```

## Class Name

`SchedulesController`

## Methods

* [Create a New Schedule](../../doc/controllers/schedules.md#create-a-new-schedule)
* [Get a Schedule](../../doc/controllers/schedules.md#get-a-schedule)
* [Update Activate a Schedule](../../doc/controllers/schedules.md#update-activate-a-schedule)
* [Delete a Schedule](../../doc/controllers/schedules.md#delete-a-schedule)
* [Update Suspend a Schedule](../../doc/controllers/schedules.md#update-suspend-a-schedule)
* [Get All Schedules](../../doc/controllers/schedules.md#get-all-schedules)


# Create a New Schedule

`POST /iwin/api/v1/schedules`

Create a new schedule.

```php
function createANewSchedule(string $contentType, string $accept, CreateANewScheduleRequest $body): void
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `contentType` | `string` | Header, Required | - |
| `accept` | `string` | Header, Required | - |
| `body` | [`CreateANewScheduleRequest`](../../doc/models/create-a-new-schedule-request.md) | Body, Required | - |

## Response Type

`void`

## Example Usage

```php
$contentType = 'application/json';
$accept = 'application/json';
$body_name = 'Soccer Practice Reminder';
$body_type = 'recurring';
$body_startDate = '2015-11-08 14:00';
$body_endDate = '2015-11-20 14:00';
$body_phoneBookId = '59196';
$body_templateId = '8465';
$body_intervalType = 'days';
$body_interval = 30;
$body = new Models\CreateANewScheduleRequest(
    $body_name,
    $body_type,
    $body_startDate,
    $body_endDate,
    $body_phoneBookId,
    $body_templateId,
    $body_intervalType,
    $body_interval
);

$schedulesController->createANewSchedule($contentType, $accept, $body);
```


# Get a Schedule

`GET /iwin/api/v1/schedules/{id}`

Get a single schedule.

```php
function getASchedule(string $accept, string $scheduleId): void
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `accept` | `string` | Header, Required | - |
| `scheduleId` | `string` | Template, Required | - |

## Response Type

`void`

## Example Usage

```php
$accept = 'application/json';
$scheduleId = 'scheduleId2';

$schedulesController->getASchedule($accept, $scheduleId);
```


# Update Activate a Schedule

`PUT /iwin/api/v1/schedules/{id}/activate`

It is only necessary to activate a schedule if it was suspended explicitly. After activation, the schedule status will be "active".

```php
function updateActivateASchedule(string $accept, string $scheduleId): void
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `accept` | `string` | Header, Required | - |
| `scheduleId` | `string` | Template, Required | - |

## Response Type

`void`

## Example Usage

```php
$accept = 'application/json';
$scheduleId = 'scheduleId2';

$schedulesController->updateActivateASchedule($accept, $scheduleId);
```


# Delete a Schedule

`DELETE /iwin/api/v1/schedules/{id}`

Only schedules in status "suspended" can be deleted. Call `PUT /iwin/api/v1/schedules/{id}/suspend` to suspend a schedule.

```php
function deleteASchedule(string $accept, string $scheduleId): void
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `accept` | `string` | Header, Required | - |
| `scheduleId` | `string` | Template, Required | - |

## Response Type

`void`

## Example Usage

```php
$accept = 'application/json';
$scheduleId = 'scheduleId2';

$schedulesController->deleteASchedule($accept, $scheduleId);
```


# Update Suspend a Schedule

`PUT /iwin/api/v1/schedules/{id}/suspend`

Suspending a schedule will temporary stop a scedule from running, until it is activated again. After suspending a schedule, the schedule status will be "suspended".

```php
function updateSuspendASchedule(string $accept, string $scheduleId): void
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `accept` | `string` | Header, Required | - |
| `scheduleId` | `string` | Template, Required | - |

## Response Type

`void`

## Example Usage

```php
$accept = 'application/json';
$scheduleId = 'scheduleId2';

$schedulesController->updateSuspendASchedule($accept, $scheduleId);
```


# Get All Schedules

`GET /iwin/api/v1/schedules`

Get all schedules, both active and suspended.

```php
function getAllSchedules(string $accept): void
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `accept` | `string` | Header, Required | - |

## Response Type

`void`

## Example Usage

```php
$accept = 'application/json';

$schedulesController->getAllSchedules($accept);
```

