# Report Filters

```php
$reportFiltersController = $client->getReportFiltersController();
```

## Class Name

`ReportFiltersController`


# Get a Report S Filters

`GET /iwin/api/v1/reports/{id}/filters`

Get a report's filters.

```php
function getAReportSFilters(string $accept, string $id): void
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `accept` | `string` | Header, Required | - |
| `id` | `string` | Template, Required | - |

## Response Type

`void`

## Example Usage

```php
$accept = 'application/json';
$id = 'id0';

$reportFiltersController->getAReportSFilters($accept, $id);
```

