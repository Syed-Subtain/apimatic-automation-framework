# Sent Schedule Messages

View messages sent as part of a scheduled campaign. This would be all the messages that has been sent out as a sent schedule run.

```php
$sentScheduleMessagesController = $client->getSentScheduleMessagesController();
```

## Class Name

`SentScheduleMessagesController`


# Get All Sent Schedule Messages

`GET /iwin/api/v1/sentschedules/{id}/messages`

View all the messages sent out as part of a scheduled message run.

```php
function getAllSentScheduleMessages(string $accept, string $id): void
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `accept` | `string` | Header, Required | - |
| `id` | `string` | Template, Required | - |

## Response Type

`void`

## Example Usage

```php
$accept = 'application/json';
$id = 'id0';

$sentScheduleMessagesController->getAllSentScheduleMessages($accept, $id);
```

