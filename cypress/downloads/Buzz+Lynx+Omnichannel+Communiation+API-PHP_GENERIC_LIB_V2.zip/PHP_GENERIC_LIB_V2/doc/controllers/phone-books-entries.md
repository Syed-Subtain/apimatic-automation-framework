# Phone Books Entries

A phone book has multiple phone book entries containing recipient's details. If you plan on using tokens in your
messages, it is advisable to store the additonal attribute details for each phone book entry.

```php
$phoneBooksEntriesController = $client->getPhoneBooksEntriesController();
```

## Class Name

`PhoneBooksEntriesController`

## Methods

* [Delete Phone Book Entry](../../doc/controllers/phone-books-entries.md#delete-phone-book-entry)
* [Get a Phone Book Entry](../../doc/controllers/phone-books-entries.md#get-a-phone-book-entry)
* [Create a New Phone Book Entry](../../doc/controllers/phone-books-entries.md#create-a-new-phone-book-entry)
* [Update Phone Book Entry](../../doc/controllers/phone-books-entries.md#update-phone-book-entry)
* [Get Phone Book Entries](../../doc/controllers/phone-books-entries.md#get-phone-book-entries)


# Delete Phone Book Entry

`DELETE /iwin/api/v1/phonebooks/{id}/entries/{entry_id}`

Delete a phone book entry.

```php
function deletePhoneBookEntry(string $accept, string $id, string $entryId): void
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `accept` | `string` | Header, Required | - |
| `id` | `string` | Template, Required | - |
| `entryId` | `string` | Template, Required | - |

## Response Type

`void`

## Example Usage

```php
$accept = 'application/json';
$id = 'id0';
$entryId = 'entryId2';

$phoneBooksEntriesController->deletePhoneBookEntry($accept, $id, $entryId);
```


# Get a Phone Book Entry

`GET /iwin/api/v1/phonebooks/{id}/entries/{entry_id}`

Get a single phone book entry.

```php
function getAPhoneBookEntry(string $accept, string $id): void
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `accept` | `string` | Header, Required | - |
| `id` | `string` | Template, Required | - |

## Response Type

`void`

## Example Usage

```php
$accept = 'application/json';
$id = 'id0';

$phoneBooksEntriesController->getAPhoneBookEntry($accept, $id);
```


# Create a New Phone Book Entry

`POST /iwin/api/v1/phonebooks/{id}/entries`

Add a new phone book entry.

```php
function createANewPhoneBookEntry(
    string $contentType,
    string $accept,
    CreateANewPhoneBookEntryRequest $body,
    string $id
): void
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `contentType` | `string` | Header, Required | - |
| `accept` | `string` | Header, Required | - |
| `body` | [`CreateANewPhoneBookEntryRequest`](../../doc/models/create-a-new-phone-book-entry-request.md) | Body, Required | - |
| `id` | `string` | Template, Required | - |

## Response Type

`void`

## Example Usage

```php
$contentType = 'application/json';
$accept = 'application/json';
$body_mobileNumber = 'mobile_number4';
$body_title = 'title8';
$body_firstName = 'first_name6';
$body_lastName = 'last_name4';
$body_attribute1 = 'attribute_18';
$body_attribute2 = 'attribute_28';
$body_attribute3 = 'attribute_38';
$body_attribute4 = 'attribute_46';
$body_attribute5 = 'attribute_50';
$body = new Models\CreateANewPhoneBookEntryRequest(
    $body_mobileNumber,
    $body_title,
    $body_firstName,
    $body_lastName,
    $body_attribute1,
    $body_attribute2,
    $body_attribute3,
    $body_attribute4,
    $body_attribute5
);
$id = 'id0';

$phoneBooksEntriesController->createANewPhoneBookEntry($contentType, $accept, $body, $id);
```


# Update Phone Book Entry

`PUT /iwin/api/v1/phonebooks/{id}/entries/{entry_id}`

Update a phone book entry. Only the values present in the request will be updated - the rest will be left unchanged.

```php
function updatePhoneBookEntry(
    string $contentType,
    string $accept,
    UpdatePhoneBookEntryRequest $body,
    string $id,
    string $entryId
): void
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `contentType` | `string` | Header, Required | - |
| `accept` | `string` | Header, Required | - |
| `body` | [`UpdatePhoneBookEntryRequest`](../../doc/models/update-phone-book-entry-request.md) | Body, Required | - |
| `id` | `string` | Template, Required | - |
| `entryId` | `string` | Template, Required | - |

## Response Type

`void`

## Example Usage

```php
$contentType = 'application/json';
$accept = 'application/json';
$body_mobileNumber = '821838384234';
$body_title = 'Mrs';
$body_firstName = 'Holly';
$body_lastName = 'Hunter';
$body_attribute1 = 'Myron';
$body_attribute2 = 'Team B';
$body = new Models\UpdatePhoneBookEntryRequest(
    $body_mobileNumber,
    $body_title,
    $body_firstName,
    $body_lastName,
    $body_attribute1,
    $body_attribute2
);
$id = 'id0';
$entryId = 'entryId2';

$phoneBooksEntriesController->updatePhoneBookEntry($contentType, $accept, $body, $id, $entryId);
```


# Get Phone Book Entries

`GET /iwin/api/v1/phonebooks/{id}/entries`

Get all the entries in a phone book.

```php
function getPhoneBookEntries(string $accept, string $id): void
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `accept` | `string` | Header, Required | - |
| `id` | `string` | Template, Required | - |

## Response Type

`void`

## Example Usage

```php
$accept = 'application/json';
$id = 'id0';

$phoneBooksEntriesController->getPhoneBookEntries($accept, $id);
```

