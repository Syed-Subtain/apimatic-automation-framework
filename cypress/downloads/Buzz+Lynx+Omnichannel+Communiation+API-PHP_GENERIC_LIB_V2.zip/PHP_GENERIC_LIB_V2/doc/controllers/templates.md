# Templates

Message templates are stored messages that can be resent and reused. Tokens can be used to personalize messages. To use a token,
wrap the token name in <>, all uppercase. Tokens must be defined in the associated phone book's attributes 1 to 5.

```php
$templatesController = $client->getTemplatesController();
```

## Class Name

`TemplatesController`

## Methods

* [Create a New Template](../../doc/controllers/templates.md#create-a-new-template)
* [Delete a Template](../../doc/controllers/templates.md#delete-a-template)
* [Get All Templates](../../doc/controllers/templates.md#get-all-templates)
* [Get a Template](../../doc/controllers/templates.md#get-a-template)
* [Update a Template](../../doc/controllers/templates.md#update-a-template)


# Create a New Template

`POST /iwin/api/v1/templates`

Create a new template. A phone book ID can optionally be passed in, if you would like to use tokens in your messages.

```php
function createANewTemplate(string $contentType, string $accept, CreateANewTemplateRequest $body): void
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `contentType` | `string` | Header, Required | - |
| `accept` | `string` | Header, Required | - |
| `body` | [`CreateANewTemplateRequest`](../../doc/models/create-a-new-template-request.md) | Body, Required | - |

## Response Type

`void`

## Example Usage

```php
$contentType = 'application/json';
$accept = 'application/json';
$body_name = 'Soccer Practice Reminder';
$body_text = 'Reminder: There is soccer practice on Wednesday at 16:00.';
$body_phoneBookId = '123';
$body = new Models\CreateANewTemplateRequest(
    $body_name,
    $body_text,
    $body_phoneBookId
);

$templatesController->createANewTemplate($contentType, $accept, $body);
```


# Delete a Template

`DELETE /iwin/api/v1/templates/{id}`

Delete a template. A template can only be deleted if it does not belong to a schedule.

```php
function deleteATemplate(string $accept, string $templateId): void
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `accept` | `string` | Header, Required | - |
| `templateId` | `string` | Template, Required | - |

## Response Type

`void`

## Example Usage

```php
$accept = 'application/json';
$templateId = 'templateId0';

$templatesController->deleteATemplate($accept, $templateId);
```


# Get All Templates

`GET /iwin/api/v1/templates`

Get all your message templates.

```php
function getAllTemplates(string $accept): void
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `accept` | `string` | Header, Required | - |

## Response Type

`void`

## Example Usage

```php
$accept = 'application/json';

$templatesController->getAllTemplates($accept);
```


# Get a Template

`GET /iwin/api/v1/templates/{id}`

Get a template.

```php
function getATemplate(string $accept, string $templateId): void
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `accept` | `string` | Header, Required | - |
| `templateId` | `string` | Template, Required | - |

## Response Type

`void`

## Example Usage

```php
$accept = 'application/json';
$templateId = 'templateId0';

$templatesController->getATemplate($accept, $templateId);
```


# Update a Template

`PUT /iwin/api/v1/templates/{id}`

Update a template.

```php
function updateATemplate(
    string $contentType,
    string $accept,
    UpdateATemplateRequest $body,
    string $templateId
): void
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `contentType` | `string` | Header, Required | - |
| `accept` | `string` | Header, Required | - |
| `body` | [`UpdateATemplateRequest`](../../doc/models/update-a-template-request.md) | Body, Required | - |
| `templateId` | `string` | Template, Required | - |

## Response Type

`void`

## Example Usage

```php
$contentType = 'application/json';
$accept = 'application/json';
$body_name = 'Soccer Practice Reminder';
$body_text = 'Reminder: There is soccer practice on Tuesday at 16:00.';
$body_phoneBookId = '123';
$body = new Models\UpdateATemplateRequest(
    $body_name,
    $body_text,
    $body_phoneBookId
);
$templateId = 'templateId0';

$templatesController->updateATemplate($contentType, $accept, $body, $templateId);
```

