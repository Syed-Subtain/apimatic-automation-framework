# Competitions

```php
$competitionsController = $client->getCompetitionsController();
```

## Class Name

`CompetitionsController`


# Get Competitions

`GET /iwin-competition/api/v1/competitions`

Get all your competitions (registered premium rated SMSes). To learn more about our Short Codes, go to http://www.iwin.co.za/shortcodes/.

```php
function getCompetitions(string $accept): void
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `accept` | `string` | Header, Required | - |

## Response Type

`void`

## Example Usage

```php
$accept = 'application/json';

$competitionsController->getCompetitions($accept);
```

