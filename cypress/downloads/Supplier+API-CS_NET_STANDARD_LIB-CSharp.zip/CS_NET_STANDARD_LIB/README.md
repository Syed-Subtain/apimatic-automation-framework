
# Getting Started with Supplier API

## Introduction

![example image](https://i.ibb.co/7bqPkGJ/PMS-integration-workflow.png "An exemplary image")

**Before beginning your work it is necessary that:**

* Your organization is registered and activated
* You have participated in a kick-off meeting
* The opening questionnaire has been filled out
* You have your login and password. (Using it you get a unique session `token` that must be used in every request to API as param `jwt`)

[Contact us](https://bookingpal.com/en/contact-us/) to be registered and get your credentials.

All responses are returned as JSON.

This document covers all the API calls and other methods that can be used to complete Razor-Cloud integration. It is important to note that all parameters are **case sensitive** in this document and should be used as documented.

**Payload Limit:**  for each request, max payload limit is 200Kb

**Responses:**
When a request is successful, a response body will typically be sent back in the form of a JSON object. An exception to this is when a DELETE request is processed, which will result in a successful `200` status and an empty response body.

## Building

The generated code uses the Newtonsoft Json.NET NuGet Package. If the automatic NuGet package restore is enabled, these dependencies will be installed automatically. Therefore, you will need internet access for build.

* Open the solution (SupplierAPI.sln) file.

Invoke the build process using Ctrl + Shift + B shortcut key or using the Build menu as shown below.

The build process generates a portable class library, which can be used like a normal class library. The generated library is compatible with Windows Forms, Windows RT, Windows Phone 8, Silverlight 5, Xamarin iOS, Xamarin Android and Mono. More information on how to use can be found at the MSDN Portable Class Libraries documentation.

## Installation

The following section explains how to use the SupplierAPI.Standard library in a new project.

### 1. Starting a new project

For starting a new project, right click on the current solution from the solution explorer and choose `Add -> New Project`.

![Add a new project in Visual Studio](https://apidocs.io/illustration/cs?workspaceFolder=Supplier%20API-CSharp&workspaceName=SupplierAPI&projectName=SupplierAPI.Standard&rootNamespace=SupplierAPI.Standard&step=addProject)

Next, choose `Console Application`, provide `TestConsoleProject` as the project name and click OK.

![Create a new Console Application in Visual Studio](https://apidocs.io/illustration/cs?workspaceFolder=Supplier%20API-CSharp&workspaceName=SupplierAPI&projectName=SupplierAPI.Standard&rootNamespace=SupplierAPI.Standard&step=createProject)

### 2. Set as startup project

The new console project is the entry point for the eventual execution. This requires us to set the `TestConsoleProject` as the start-up project. To do this, right-click on the `TestConsoleProject` and choose `Set as StartUp Project` form the context menu.

![Adding a project reference](https://apidocs.io/illustration/cs?workspaceFolder=Supplier%20API-CSharp&workspaceName=SupplierAPI&projectName=SupplierAPI.Standard&rootNamespace=SupplierAPI.Standard&step=setStartup)

### 3. Add reference of the library project

In order to use the Tester library in the new project, first we must add a project reference to the `TestConsoleProject`. First, right click on the `References` node in the solution explorer and click `Add Reference...`

![Adding a project reference](https://apidocs.io/illustration/cs?workspaceFolder=Supplier%20API-CSharp&workspaceName=SupplierAPI&projectName=SupplierAPI.Standard&rootNamespace=SupplierAPI.Standard&step=addReference)

Next, a window will be displayed where we must set the `checkbox` on `Tester.Tests` and click `OK`. By doing this, we have added a reference of the `Tester.Tests` project into the new `TestConsoleProject`.

![Creating a project reference](https://apidocs.io/illustration/cs?workspaceFolder=Supplier%20API-CSharp&workspaceName=SupplierAPI&projectName=SupplierAPI.Standard&rootNamespace=SupplierAPI.Standard&step=createReference)

### 4. Write sample code

Once the `TestConsoleProject` is created, a file named `Program.cs` will be visible in the solution explorer with an empty `Main` method. This is the entry point for the execution of the entire solution. Here, you can add code to initialize the client library and acquire the instance of a Controller class. Sample code to initialize the client library and using Controller methods is given in the subsequent sections.

![Adding a project reference](https://apidocs.io/illustration/cs?workspaceFolder=Supplier%20API-CSharp&workspaceName=SupplierAPI&projectName=SupplierAPI.Standard&rootNamespace=SupplierAPI.Standard&step=addCode)

## Test the SDK

The generated SDK also contain one or more Tests, which are contained in the Tests project. In order to invoke these test cases, you will need `NUnit 3.0 Test Adapter Extension` for Visual Studio. Once the SDK is complied, the test cases should appear in the Test Explorer window. Here, you can click `Run All` to execute these test cases.

## Initialize the API Client

**_Note:_** Documentation for the client can be found [here.](doc/client.md)

The following parameters are configurable for the API Client:

| Parameter | Type | Description |
|  --- | --- | --- |
| `PushServerUrl` | `string` | In some API call BookingPal will send POST request (push message) to the PMS for URL which you provide in API 'Push Notification'. You can test these calls to in this documentation, just you will need to set your URL here on specific API call, on Configure button in the right section of specific API function<br>*Default*: `"https://www.yourEndpoint.url"` |
| `Environment` | Environment | The API environment. <br> **Default: `Environment.Production`** |
| `Timeout` | `TimeSpan` | Http client timeout.<br>*Default*: `TimeSpan.FromSeconds(100)` |
| `Jwt` | `string` | Token which need to be passed in every request as GET parameter. You will get this token in authorization response. Token is valid 1 hour. |

The API client can be initialized as follows:

```csharp
SupplierAPI.Standard.SupplierAPIClient client = new SupplierAPI.Standard.SupplierAPIClient.Builder()
    .CustomQueryAuthenticationCredentials("jwt")
    .Environment(SupplierAPI.Standard.Environment.Production)
    .PushServerUrl("https://www.yourEndpoint.url")
    .HttpClientConfig(config => config.NumberOfRetries(0))
    .Build();
```

## Environments

The SDK can be configured to use a different environment for making API calls. Available environments are:

### Fields

| Name | Description |
|  --- | --- |
| production | **Default** BookingPal Supplier API test server |
| environment2 | BookingPal Supplier API test server |

## Authorization

This API uses `Custom Query Parameter`.

## List of APIs

* [Property Managers](doc/controllers/property-managers.md)
* [Ratesand Availability](doc/controllers/ratesand-availability.md)
* [Feeand Tax](doc/controllers/feeand-tax.md)
* [Feeand Tax Mandatoryatthepropertylevel](doc/controllers/feeand-tax-mandatoryatthepropertylevel.md)
* [Testingofmessage AP Icalls](doc/controllers/testingofmessage-ap-icalls.md)
* [Push Notification](doc/controllers/push-notification.md)
* [Reservation Notifications](doc/controllers/reservation-notifications.md)
* [Asynchronous Push Messages](doc/controllers/asynchronous-push-messages.md)
* [Request to Book](doc/controllers/request-to-book.md)
* [LOS Pricing](doc/controllers/los-pricing.md)
* [Configuration in Supplier API](doc/controllers/configuration-in-supplier-api.md)
* [Authorization](doc/controllers/authorization.md)
* [Product](doc/controllers/product.md)
* [Images](doc/controllers/images.md)
* [Yields](doc/controllers/yields.md)
* [Validation](doc/controllers/validation.md)
* [Messaging](doc/controllers/messaging.md)
* [Licenses](doc/controllers/licenses.md)

## Classes Documentation

* [Utility Classes](doc/utility-classes.md)
* [HttpRequest](doc/http-request.md)
* [HttpResponse](doc/http-response.md)
* [HttpStringResponse](doc/http-string-response.md)
* [HttpContext](doc/http-context.md)
* [HttpClientConfiguration](doc/http-client-configuration.md)
* [HttpClientConfiguration Builder](doc/http-client-configuration-builder.md)
* [IAuthManager](doc/i-auth-manager.md)
* [ApiException](doc/api-exception.md)

