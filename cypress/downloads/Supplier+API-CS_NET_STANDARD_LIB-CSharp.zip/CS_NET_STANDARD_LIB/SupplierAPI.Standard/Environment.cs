// <copyright file="Environment.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace SupplierAPI.Standard
{
    using System.Runtime.Serialization;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    /// <summary>
    /// Available environments.
    /// </summary>
    [JsonConverter(typeof(StringEnumConverter))]
    public enum Environment
    {
        /// <summary>
        /// BookingPal Supplier API test server.
        /// </summary>
        [EnumMember(Value = "production")]
        Production,

        /// <summary>
        /// BookingPal Supplier API test server.
        /// </summary>
        [EnumMember(Value = "environment2")]
        Environment2,
    }
}
