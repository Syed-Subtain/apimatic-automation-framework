// <copyright file="DescriptionTextModel.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace SupplierAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using SupplierAPI.Standard;
    using SupplierAPI.Standard.Utilities;

    /// <summary>
    /// DescriptionTextModel.
    /// </summary>
    public class DescriptionTextModel
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="DescriptionTextModel"/> class.
        /// </summary>
        public DescriptionTextModel()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="DescriptionTextModel"/> class.
        /// </summary>
        /// <param name="texts">texts.</param>
        public DescriptionTextModel(
            List<Models.Text> texts)
        {
            this.Texts = texts;
        }

        /// <summary>
        /// Text value per languages
        /// </summary>
        [JsonProperty("texts")]
        public List<Models.Text> Texts { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"DescriptionTextModel : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is DescriptionTextModel other &&
                ((this.Texts == null && other.Texts == null) || (this.Texts?.Equals(other.Texts) == true));
        }
        

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.Texts = {(this.Texts == null ? "null" : $"[{string.Join(", ", this.Texts)} ]")}");
        }
    }
}