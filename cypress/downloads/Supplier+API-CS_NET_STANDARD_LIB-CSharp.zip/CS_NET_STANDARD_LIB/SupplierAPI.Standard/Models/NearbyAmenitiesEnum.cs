// <copyright file="NearbyAmenitiesEnum.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace SupplierAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Runtime.Serialization;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using SupplierAPI.Standard;
    using SupplierAPI.Standard.Utilities;

    /// <summary>
    /// NearbyAmenitiesEnum.
    /// </summary>
    [JsonConverter(typeof(StringEnumConverter))]
    public enum NearbyAmenitiesEnum
    {
        /// <summary>
        ///Airport
        /// ACC1.
        /// </summary>
        [EnumMember(Value = "ACC1")]
        ACC1,

        /// <summary>
        ///Ferry
        /// ACC203.
        /// </summary>
        [EnumMember(Value = "ACC203")]
        ACC203,

        /// <summary>
        ///Shopping
        /// ACC65.
        /// </summary>
        [EnumMember(Value = "ACC65")]
        ACC65,

        /// <summary>
        ///Railway
        /// HAC199.
        /// </summary>
        [EnumMember(Value = "HAC199")]
        HAC199,

        /// <summary>
        ///Beach
        /// RST5.
        /// </summary>
        [EnumMember(Value = "RST5")]
        RST5
    }
}