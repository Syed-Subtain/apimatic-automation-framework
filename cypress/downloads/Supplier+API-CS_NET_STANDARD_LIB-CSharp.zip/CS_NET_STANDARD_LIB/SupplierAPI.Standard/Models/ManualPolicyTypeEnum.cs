// <copyright file="ManualPolicyTypeEnum.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace SupplierAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Runtime.Serialization;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using SupplierAPI.Standard;
    using SupplierAPI.Standard.Utilities;

    /// <summary>
    /// ManualPolicyTypeEnum.
    /// </summary>
    [JsonConverter(typeof(StringEnumConverter))]
    public enum ManualPolicyTypeEnum
    {
        /// <summary>
        /// PERCENTAGE.
        /// </summary>
        [EnumMember(Value = "PERCENTAGE")]
        PERCENTAGE,

        /// <summary>
        /// FLAT.
        /// </summary>
        [EnumMember(Value = "FLAT")]
        FLAT
    }
}