// <copyright file="MessageModel.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace SupplierAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using SupplierAPI.Standard;
    using SupplierAPI.Standard.Utilities;

    /// <summary>
    /// MessageModel.
    /// </summary>
    public class MessageModel
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="MessageModel"/> class.
        /// </summary>
        public MessageModel()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="MessageModel"/> class.
        /// </summary>
        /// <param name="message">message.</param>
        /// <param name="createdAt">createdAt.</param>
        /// <param name="user">user.</param>
        /// <param name="id">id.</param>
        /// <param name="channelMessageId">channelMessageId.</param>
        public MessageModel(
            string message,
            string createdAt,
            Models.UserEnum user,
            int? id = null,
            string channelMessageId = null)
        {
            this.Id = id;
            this.Message = message;
            this.CreatedAt = createdAt;
            this.User = user;
            this.ChannelMessageId = channelMessageId;
        }

        /// <summary>
        /// Id of message
        /// </summary>
        [JsonProperty("id", NullValueHandling = NullValueHandling.Ignore)]
        public int? Id { get; set; }

        /// <summary>
        /// Message text
        /// </summary>
        [JsonProperty("message")]
        public string Message { get; set; }

        /// <summary>
        /// Time when message created
        /// </summary>
        [JsonProperty("createdAt")]
        public string CreatedAt { get; set; }

        /// <summary>
        /// Gets or sets User.
        /// </summary>
        [JsonProperty("user", ItemConverterType = typeof(StringEnumConverter))]
        public Models.UserEnum User { get; set; }

        /// <summary>
        /// Channel Message ID
        /// </summary>
        [JsonProperty("channelMessageId", NullValueHandling = NullValueHandling.Ignore)]
        public string ChannelMessageId { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"MessageModel : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is MessageModel other &&
                ((this.Id == null && other.Id == null) || (this.Id?.Equals(other.Id) == true)) &&
                ((this.Message == null && other.Message == null) || (this.Message?.Equals(other.Message) == true)) &&
                ((this.CreatedAt == null && other.CreatedAt == null) || (this.CreatedAt?.Equals(other.CreatedAt) == true)) &&
                this.User.Equals(other.User) &&
                ((this.ChannelMessageId == null && other.ChannelMessageId == null) || (this.ChannelMessageId?.Equals(other.ChannelMessageId) == true));
        }
        

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.Id = {(this.Id == null ? "null" : this.Id.ToString())}");
            toStringOutput.Add($"this.Message = {(this.Message == null ? "null" : this.Message == string.Empty ? "" : this.Message)}");
            toStringOutput.Add($"this.CreatedAt = {(this.CreatedAt == null ? "null" : this.CreatedAt == string.Empty ? "" : this.CreatedAt)}");
            toStringOutput.Add($"this.User = {this.User}");
            toStringOutput.Add($"this.ChannelMessageId = {(this.ChannelMessageId == null ? "null" : this.ChannelMessageId == string.Empty ? "" : this.ChannelMessageId)}");
        }
    }
}