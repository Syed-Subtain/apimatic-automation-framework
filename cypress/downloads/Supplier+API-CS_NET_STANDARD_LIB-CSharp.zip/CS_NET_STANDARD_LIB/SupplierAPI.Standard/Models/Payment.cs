// <copyright file="Payment.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace SupplierAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using SupplierAPI.Standard;
    using SupplierAPI.Standard.Utilities;

    /// <summary>
    /// Payment.
    /// </summary>
    public class Payment
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="Payment"/> class.
        /// </summary>
        public Payment()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="Payment"/> class.
        /// </summary>
        /// <param name="paymentType">paymentType.</param>
        /// <param name="creditCard">creditCard.</param>
        public Payment(
            Models.PaymentTypeEnum paymentType,
            Models.CreditCard creditCard = null)
        {
            this.PaymentType = paymentType;
            this.CreditCard = creditCard;
        }

        /// <summary>
        /// Gets or sets PaymentType.
        /// </summary>
        [JsonProperty("paymentType", ItemConverterType = typeof(StringEnumConverter))]
        public Models.PaymentTypeEnum PaymentType { get; set; }

        /// <summary>
        /// Gets or sets CreditCard.
        /// </summary>
        [JsonProperty("creditCard", NullValueHandling = NullValueHandling.Ignore)]
        public Models.CreditCard CreditCard { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"Payment : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is Payment other &&
                this.PaymentType.Equals(other.PaymentType) &&
                ((this.CreditCard == null && other.CreditCard == null) || (this.CreditCard?.Equals(other.CreditCard) == true));
        }
        

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.PaymentType = {this.PaymentType}");
            toStringOutput.Add($"this.CreditCard = {(this.CreditCard == null ? "null" : this.CreditCard.ToString())}");
        }
    }
}