// <copyright file="BedroomTypeEnum.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace SupplierAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Runtime.Serialization;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using SupplierAPI.Standard;
    using SupplierAPI.Standard.Utilities;

    /// <summary>
    /// BedroomTypeEnum.
    /// </summary>
    [JsonConverter(typeof(StringEnumConverter))]
    public enum BedroomTypeEnum
    {
        /// <summary>
        /// Bedroom.
        /// </summary>
        [EnumMember(Value = "Bedroom")]
        Bedroom,

        /// <summary>
        /// EnumLivingRoom.
        /// </summary>
        [EnumMember(Value = "Living Room")]
        EnumLivingRoom
    }
}