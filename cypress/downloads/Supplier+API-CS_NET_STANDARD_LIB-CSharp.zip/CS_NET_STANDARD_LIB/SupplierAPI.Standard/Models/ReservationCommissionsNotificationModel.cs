// <copyright file="ReservationCommissionsNotificationModel.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace SupplierAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using SupplierAPI.Standard;
    using SupplierAPI.Standard.Utilities;

    /// <summary>
    /// ReservationCommissionsNotificationModel.
    /// </summary>
    public class ReservationCommissionsNotificationModel
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ReservationCommissionsNotificationModel"/> class.
        /// </summary>
        public ReservationCommissionsNotificationModel()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ReservationCommissionsNotificationModel"/> class.
        /// </summary>
        /// <param name="channelCommission">channelCommission.</param>
        /// <param name="commission">commission.</param>
        public ReservationCommissionsNotificationModel(
            double? channelCommission = null,
            double? commission = null)
        {
            this.ChannelCommission = channelCommission;
            this.Commission = commission;
        }

        /// <summary>
        /// Channel commission
        /// </summary>
        [JsonProperty("channelCommission", NullValueHandling = NullValueHandling.Ignore)]
        public double? ChannelCommission { get; set; }

        /// <summary>
        /// BookingPal commission
        /// </summary>
        [JsonProperty("commission", NullValueHandling = NullValueHandling.Ignore)]
        public double? Commission { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"ReservationCommissionsNotificationModel : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is ReservationCommissionsNotificationModel other &&
                ((this.ChannelCommission == null && other.ChannelCommission == null) || (this.ChannelCommission?.Equals(other.ChannelCommission) == true)) &&
                ((this.Commission == null && other.Commission == null) || (this.Commission?.Equals(other.Commission) == true));
        }
        

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.ChannelCommission = {(this.ChannelCommission == null ? "null" : this.ChannelCommission.ToString())}");
            toStringOutput.Add($"this.Commission = {(this.Commission == null ? "null" : this.Commission.ToString())}");
        }
    }
}