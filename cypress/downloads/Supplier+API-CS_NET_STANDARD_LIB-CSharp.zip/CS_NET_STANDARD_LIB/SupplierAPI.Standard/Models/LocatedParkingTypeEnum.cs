// <copyright file="LocatedParkingTypeEnum.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace SupplierAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Runtime.Serialization;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using SupplierAPI.Standard;
    using SupplierAPI.Standard.Utilities;

    /// <summary>
    /// LocatedParkingTypeEnum.
    /// </summary>
    [JsonConverter(typeof(StringEnumConverter))]
    public enum LocatedParkingTypeEnum
    {
        /// <summary>
        /// OnSite.
        /// </summary>
        [EnumMember(Value = "OnSite")]
        OnSite,

        /// <summary>
        /// Nearby.
        /// </summary>
        [EnumMember(Value = "Nearby")]
        Nearby
    }
}