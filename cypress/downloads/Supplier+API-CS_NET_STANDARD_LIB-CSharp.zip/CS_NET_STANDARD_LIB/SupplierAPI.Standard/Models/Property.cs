// <copyright file="Property.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace SupplierAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using SupplierAPI.Standard;
    using SupplierAPI.Standard.Utilities;

    /// <summary>
    /// Property.
    /// </summary>
    public class Property
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="Property"/> class.
        /// </summary>
        public Property()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="Property"/> class.
        /// </summary>
        /// <param name="name">name.</param>
        /// <param name="rooms">rooms.</param>
        /// <param name="bathrooms">bathrooms.</param>
        /// <param name="persons">persons.</param>
        /// <param name="propertyType">propertyType.</param>
        /// <param name="currency">currency.</param>
        /// <param name="supportedLosRates">supportedLosRates.</param>
        /// <param name="id">id.</param>
        /// <param name="altId">altId.</param>
        /// <param name="supplierId">supplierId.</param>
        /// <param name="toilets">toilets.</param>
        /// <param name="totalBeds">totalBeds.</param>
        /// <param name="space">space.</param>
        /// <param name="spaceUnit">spaceUnit.</param>
        /// <param name="childs">childs.</param>
        /// <param name="latitude">latitude.</param>
        /// <param name="longitude">longitude.</param>
        /// <param name="livingRoom">livingRoom.</param>
        /// <param name="notes">notes.</param>
        /// <param name="attributesWithQuantity">attributesWithQuantity.</param>
        /// <param name="nearbyAmenities">nearbyAmenities.</param>
        /// <param name="bedroomConfiguration">bedroomConfiguration.</param>
        /// <param name="checkInTime">checkInTime.</param>
        /// <param name="checkInToTime">checkInToTime.</param>
        /// <param name="checkOutTime">checkOutTime.</param>
        /// <param name="policy">policy.</param>
        /// <param name="location">location.</param>
        /// <param name="taxNumber">taxNumber.</param>
        /// <param name="multiUnit">multiUnit.</param>
        /// <param name="parentId">parentId.</param>
        /// <param name="propertyRating">propertyRating.</param>
        /// <param name="ratingNumber">ratingNumber.</param>
        /// <param name="minimumRentingAge">minimumRentingAge.</param>
        /// <param name="basePrice">basePrice.</param>
        /// <param name="builtDate">builtDate.</param>
        /// <param name="renovatingDate">renovatingDate.</param>
        /// <param name="rentingDate">rentingDate.</param>
        /// <param name="hostLocation">hostLocation.</param>
        /// <param name="keyCollection">keyCollection.</param>
        /// <param name="neighborhoodOverview">neighborhoodOverview.</param>
        /// <param name="about">about.</param>
        public Property(
            string name,
            int rooms,
            int bathrooms,
            int persons,
            Models.PropertyTypesEnum propertyType,
            string currency,
            bool supportedLosRates,
            int? id = null,
            int? altId = null,
            int? supplierId = null,
            int? toilets = null,
            int? totalBeds = null,
            double? space = null,
            Models.SpaceUnitEnum? spaceUnit = null,
            int? childs = null,
            double? latitude = null,
            double? longitude = null,
            int? livingRoom = null,
            Models.Notes notes = null,
            List<Models.AttributesWithQuantity> attributesWithQuantity = null,
            List<Models.NearbyAmenity> nearbyAmenities = null,
            Models.BedroomConfiguration bedroomConfiguration = null,
            string checkInTime = null,
            string checkInToTime = null,
            string checkOutTime = null,
            Models.Policy policy = null,
            Models.Location location = null,
            string taxNumber = null,
            Models.MultiUnitEnum? multiUnit = null,
            int? parentId = null,
            double? propertyRating = null,
            int? ratingNumber = null,
            int? minimumRentingAge = null,
            double? basePrice = null,
            DateTime? builtDate = null,
            DateTime? renovatingDate = null,
            DateTime? rentingDate = null,
            bool? hostLocation = null,
            Models.KeyCollection keyCollection = null,
            Models.Text neighborhoodOverview = null,
            Models.Text about = null)
        {
            this.Name = name;
            this.Id = id;
            this.AltId = altId;
            this.SupplierId = supplierId;
            this.Rooms = rooms;
            this.Bathrooms = bathrooms;
            this.Toilets = toilets;
            this.TotalBeds = totalBeds;
            this.Space = space;
            this.SpaceUnit = spaceUnit;
            this.Persons = persons;
            this.Childs = childs;
            this.Latitude = latitude;
            this.Longitude = longitude;
            this.LivingRoom = livingRoom;
            this.Notes = notes;
            this.AttributesWithQuantity = attributesWithQuantity;
            this.NearbyAmenities = nearbyAmenities;
            this.PropertyType = propertyType;
            this.BedroomConfiguration = bedroomConfiguration;
            this.CheckInTime = checkInTime;
            this.CheckInToTime = checkInToTime;
            this.CheckOutTime = checkOutTime;
            this.Currency = currency;
            this.Policy = policy;
            this.Location = location;
            this.SupportedLosRates = supportedLosRates;
            this.TaxNumber = taxNumber;
            this.MultiUnit = multiUnit;
            this.ParentId = parentId;
            this.PropertyRating = propertyRating;
            this.RatingNumber = ratingNumber;
            this.MinimumRentingAge = minimumRentingAge;
            this.BasePrice = basePrice;
            this.BuiltDate = builtDate;
            this.RenovatingDate = renovatingDate;
            this.RentingDate = rentingDate;
            this.HostLocation = hostLocation;
            this.KeyCollection = keyCollection;
            this.NeighborhoodOverview = neighborhoodOverview;
            this.About = about;
        }

        /// <summary>
        /// Name of the property to display in the list
        /// </summary>
        [JsonProperty("name")]
        public string Name { get; set; }

        /// <summary>
        /// Property ID in BookingPal
        /// </summary>
        [JsonProperty("id", NullValueHandling = NullValueHandling.Ignore)]
        public int? Id { get; set; }

        /// <summary>
        /// Alternative Id of the property (ID in your PMS system).   Note: this field can not be updated, so this field will not be used during update.
        /// </summary>
        [JsonProperty("altId", NullValueHandling = NullValueHandling.Ignore)]
        public int? AltId { get; set; }

        /// <summary>
        /// Id of the Property Manager (not be used for creating new property. Property will have ID of current authorized user)
        /// </summary>
        [JsonProperty("supplierId", NullValueHandling = NullValueHandling.Ignore)]
        public int? SupplierId { get; set; }

        /// <summary>
        /// Number of bedrooms. Number of bedrooms should be > 0. Value 0 is only allowed in case property type  is Studio (PCT46 or PCT110)
        /// </summary>
        [JsonProperty("rooms")]
        public int Rooms { get; set; }

        /// <summary>
        /// Number of bathrooms
        /// </summary>
        [JsonProperty("bathrooms")]
        public int Bathrooms { get; set; }

        /// <summary>
        /// Number of toilets
        /// </summary>
        [JsonProperty("toilets", NullValueHandling = NullValueHandling.Ignore)]
        public int? Toilets { get; set; }

        /// <summary>
        /// Property’s total number of beds
        /// </summary>
        [JsonProperty("totalBeds", NullValueHandling = NullValueHandling.Ignore)]
        public int? TotalBeds { get; set; }

        /// <summary>
        /// Property size
        /// </summary>
        [JsonProperty("space", NullValueHandling = NullValueHandling.Ignore)]
        public double? Space { get; set; }

        /// <summary>
        /// Gets or sets SpaceUnit.
        /// </summary>
        [JsonProperty("spaceUnit", ItemConverterType = typeof(StringEnumConverter), NullValueHandling = NullValueHandling.Ignore)]
        public Models.SpaceUnitEnum? SpaceUnit { get; set; }

        /// <summary>
        /// Maximum number of allowed adults
        /// </summary>
        [JsonProperty("persons")]
        public int Persons { get; set; }

        /// <summary>
        /// Number of allowed children (from 7 to 12 years)
        /// </summary>
        [JsonProperty("childs", NullValueHandling = NullValueHandling.Ignore)]
        public int? Childs { get; set; }

        /// <summary>
        /// Latitude of the property (Must set field latitude and longitude or location)
        /// </summary>
        [JsonProperty("latitude", NullValueHandling = NullValueHandling.Ignore)]
        public double? Latitude { get; set; }

        /// <summary>
        /// Longitude of the property (Must set field latitude and longitude or location)
        /// </summary>
        [JsonProperty("longitude", NullValueHandling = NullValueHandling.Ignore)]
        public double? Longitude { get; set; }

        /// <summary>
        /// Number of Living rooms
        /// </summary>
        [JsonProperty("livingRoom", NullValueHandling = NullValueHandling.Ignore)]
        public int? LivingRoom { get; set; }

        /// <summary>
        /// Model where you can define different kinds of text values. If you need to delete some kind of texts, for example short description, you can do this on Update call (PUT), and you need to pass empty array for texts value, for example :  "shortDescription": {  "texts": [  ] }
        /// </summary>
        [JsonProperty("notes", NullValueHandling = NullValueHandling.Ignore)]
        public Models.Notes Notes { get; set; }

        /// <summary>
        /// Use this param instead of previous if you need to set quantity more than 1 of attributes. If use both in POST request this will overwrite the previous list (under param attributes).
        /// </summary>
        [JsonProperty("attributesWithQuantity", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.AttributesWithQuantity> AttributesWithQuantity { get; set; }

        /// <summary>
        /// List of Nearby Attributes models. Check allowed values in Appendix.
        /// </summary>
        [JsonProperty("nearbyAmenities", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.NearbyAmenity> NearbyAmenities { get; set; }

        /// <summary>
        /// Gets or sets PropertyType.
        /// </summary>
        [JsonProperty("propertyType", ItemConverterType = typeof(StringEnumConverter))]
        public Models.PropertyTypesEnum PropertyType { get; set; }

        /// <summary>
        /// Gets or sets BedroomConfiguration.
        /// </summary>
        [JsonProperty("bedroomConfiguration", NullValueHandling = NullValueHandling.Ignore)]
        public Models.BedroomConfiguration BedroomConfiguration { get; set; }

        /// <summary>
        /// Time of Check in (HH:MM:SS)
        /// </summary>
        [JsonProperty("checkInTime", NullValueHandling = NullValueHandling.Ignore)]
        public string CheckInTime { get; set; }

        /// <summary>
        /// Time Check in to (HH:MM:SS)
        /// </summary>
        [JsonProperty("checkInToTime", NullValueHandling = NullValueHandling.Ignore)]
        public string CheckInToTime { get; set; }

        /// <summary>
        /// Time of Check out (HH:MM:SS)
        /// </summary>
        [JsonProperty("checkOutTime", NullValueHandling = NullValueHandling.Ignore)]
        public string CheckOutTime { get; set; }

        /// <summary>
        /// Property currency. ISO 4217 code is required.
        /// </summary>
        [JsonProperty("currency")]
        public string Currency { get; set; }

        /// <summary>
        /// Gets or sets Policy.
        /// </summary>
        [JsonProperty("policy", NullValueHandling = NullValueHandling.Ignore)]
        public Models.Policy Policy { get; set; }

        /// <summary>
        /// Gets or sets Location.
        /// </summary>
        [JsonProperty("location", NullValueHandling = NullValueHandling.Ignore)]
        public Models.Location Location { get; set; }

        /// <summary>
        /// If true - means that the property supports only LOS rates. So daily rates can not be sent and updated. Default is false.
        /// </summary>
        [JsonProperty("supportedLosRates")]
        public bool SupportedLosRates { get; set; }

        /// <summary>
        /// Tax number for the property
        /// </summary>
        [JsonProperty("taxNumber", NullValueHandling = NullValueHandling.Ignore)]
        public string TaxNumber { get; set; }

        /// <summary>
        /// Enum for product multyunit type.
        /// </summary>
        [JsonProperty("multiUnit", ItemConverterType = typeof(StringEnumConverter), NullValueHandling = NullValueHandling.Ignore)]
        public Models.MultiUnitEnum? MultiUnit { get; set; }

        /// <summary>
        /// This fields should not be used unless your property is not MLT (check field multiunit). In this case you must set owner (parent) id property to which this property will belong. Also you can not update this property.
        /// </summary>
        [JsonProperty("parentId", NullValueHandling = NullValueHandling.Ignore)]
        public int? ParentId { get; set; }

        /// <summary>
        /// Property rating. A floating point number representing the aggregate property rating (0-5).
        /// </summary>
        [JsonProperty("propertyRating", NullValueHandling = NullValueHandling.Ignore)]
        public double? PropertyRating { get; set; }

        /// <summary>
        /// Rating Number. Number of ratings that the property has (Non-negative integer)
        /// </summary>
        [JsonProperty("ratingNumber", NullValueHandling = NullValueHandling.Ignore)]
        public int? RatingNumber { get; set; }

        /// <summary>
        /// Minimum renting age. If you want to remove previously added value - send value 0.
        /// </summary>
        [JsonProperty("minimumRentingAge", NullValueHandling = NullValueHandling.Ignore)]
        public int? MinimumRentingAge { get; set; }

        /// <summary>
        /// Display value that channels use when guests search without dates. Min value = 10 USD; Max value = 25,000 USD
        /// </summary>
        [JsonProperty("basePrice", NullValueHandling = NullValueHandling.Ignore)]
        public double? BasePrice { get; set; }

        /// <summary>
        /// Date when property were built. Format YYYY-MM-DD HH:MM:SS
        /// </summary>
        [JsonConverter(typeof(IsoDateTimeConverter))]
        [JsonProperty("builtDate", NullValueHandling = NullValueHandling.Ignore)]
        public DateTime? BuiltDate { get; set; }

        /// <summary>
        /// Date when property last time were renovated. Format YYYY-MM-DD HH:MM:SS
        /// </summary>
        [JsonConverter(typeof(IsoDateTimeConverter))]
        [JsonProperty("renovatingDate", NullValueHandling = NullValueHandling.Ignore)]
        public DateTime? RenovatingDate { get; set; }

        /// <summary>
        /// Date from when property is rented. Format YYYY-MM-DD HH:MM:SS
        /// </summary>
        [JsonConverter(typeof(IsoDateTimeConverter))]
        [JsonProperty("rentingDate", NullValueHandling = NullValueHandling.Ignore)]
        public DateTime? RentingDate { get; set; }

        /// <summary>
        /// Indicator, whether the host is living in the property or not. Default is FALSE.
        /// </summary>
        [JsonProperty("hostLocation", NullValueHandling = NullValueHandling.Ignore)]
        public bool? HostLocation { get; set; }

        /// <summary>
        /// Gets or sets KeyCollection.
        /// </summary>
        [JsonProperty("keyCollection", NullValueHandling = NullValueHandling.Ignore)]
        public Models.KeyCollection KeyCollection { get; set; }

        /// <summary>
        /// Gets or sets NeighborhoodOverview.
        /// </summary>
        [JsonProperty("neighborhoodOverview", NullValueHandling = NullValueHandling.Ignore)]
        public Models.Text NeighborhoodOverview { get; set; }

        /// <summary>
        /// Gets or sets About.
        /// </summary>
        [JsonProperty("about", NullValueHandling = NullValueHandling.Ignore)]
        public Models.Text About { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"Property : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is Property other &&
                ((this.Name == null && other.Name == null) || (this.Name?.Equals(other.Name) == true)) &&
                ((this.Id == null && other.Id == null) || (this.Id?.Equals(other.Id) == true)) &&
                ((this.AltId == null && other.AltId == null) || (this.AltId?.Equals(other.AltId) == true)) &&
                ((this.SupplierId == null && other.SupplierId == null) || (this.SupplierId?.Equals(other.SupplierId) == true)) &&
                this.Rooms.Equals(other.Rooms) &&
                this.Bathrooms.Equals(other.Bathrooms) &&
                ((this.Toilets == null && other.Toilets == null) || (this.Toilets?.Equals(other.Toilets) == true)) &&
                ((this.TotalBeds == null && other.TotalBeds == null) || (this.TotalBeds?.Equals(other.TotalBeds) == true)) &&
                ((this.Space == null && other.Space == null) || (this.Space?.Equals(other.Space) == true)) &&
                ((this.SpaceUnit == null && other.SpaceUnit == null) || (this.SpaceUnit?.Equals(other.SpaceUnit) == true)) &&
                this.Persons.Equals(other.Persons) &&
                ((this.Childs == null && other.Childs == null) || (this.Childs?.Equals(other.Childs) == true)) &&
                ((this.Latitude == null && other.Latitude == null) || (this.Latitude?.Equals(other.Latitude) == true)) &&
                ((this.Longitude == null && other.Longitude == null) || (this.Longitude?.Equals(other.Longitude) == true)) &&
                ((this.LivingRoom == null && other.LivingRoom == null) || (this.LivingRoom?.Equals(other.LivingRoom) == true)) &&
                ((this.Notes == null && other.Notes == null) || (this.Notes?.Equals(other.Notes) == true)) &&
                ((this.AttributesWithQuantity == null && other.AttributesWithQuantity == null) || (this.AttributesWithQuantity?.Equals(other.AttributesWithQuantity) == true)) &&
                ((this.NearbyAmenities == null && other.NearbyAmenities == null) || (this.NearbyAmenities?.Equals(other.NearbyAmenities) == true)) &&
                this.PropertyType.Equals(other.PropertyType) &&
                ((this.BedroomConfiguration == null && other.BedroomConfiguration == null) || (this.BedroomConfiguration?.Equals(other.BedroomConfiguration) == true)) &&
                ((this.CheckInTime == null && other.CheckInTime == null) || (this.CheckInTime?.Equals(other.CheckInTime) == true)) &&
                ((this.CheckInToTime == null && other.CheckInToTime == null) || (this.CheckInToTime?.Equals(other.CheckInToTime) == true)) &&
                ((this.CheckOutTime == null && other.CheckOutTime == null) || (this.CheckOutTime?.Equals(other.CheckOutTime) == true)) &&
                ((this.Currency == null && other.Currency == null) || (this.Currency?.Equals(other.Currency) == true)) &&
                ((this.Policy == null && other.Policy == null) || (this.Policy?.Equals(other.Policy) == true)) &&
                ((this.Location == null && other.Location == null) || (this.Location?.Equals(other.Location) == true)) &&
                this.SupportedLosRates.Equals(other.SupportedLosRates) &&
                ((this.TaxNumber == null && other.TaxNumber == null) || (this.TaxNumber?.Equals(other.TaxNumber) == true)) &&
                ((this.MultiUnit == null && other.MultiUnit == null) || (this.MultiUnit?.Equals(other.MultiUnit) == true)) &&
                ((this.ParentId == null && other.ParentId == null) || (this.ParentId?.Equals(other.ParentId) == true)) &&
                ((this.PropertyRating == null && other.PropertyRating == null) || (this.PropertyRating?.Equals(other.PropertyRating) == true)) &&
                ((this.RatingNumber == null && other.RatingNumber == null) || (this.RatingNumber?.Equals(other.RatingNumber) == true)) &&
                ((this.MinimumRentingAge == null && other.MinimumRentingAge == null) || (this.MinimumRentingAge?.Equals(other.MinimumRentingAge) == true)) &&
                ((this.BasePrice == null && other.BasePrice == null) || (this.BasePrice?.Equals(other.BasePrice) == true)) &&
                ((this.BuiltDate == null && other.BuiltDate == null) || (this.BuiltDate?.Equals(other.BuiltDate) == true)) &&
                ((this.RenovatingDate == null && other.RenovatingDate == null) || (this.RenovatingDate?.Equals(other.RenovatingDate) == true)) &&
                ((this.RentingDate == null && other.RentingDate == null) || (this.RentingDate?.Equals(other.RentingDate) == true)) &&
                ((this.HostLocation == null && other.HostLocation == null) || (this.HostLocation?.Equals(other.HostLocation) == true)) &&
                ((this.KeyCollection == null && other.KeyCollection == null) || (this.KeyCollection?.Equals(other.KeyCollection) == true)) &&
                ((this.NeighborhoodOverview == null && other.NeighborhoodOverview == null) || (this.NeighborhoodOverview?.Equals(other.NeighborhoodOverview) == true)) &&
                ((this.About == null && other.About == null) || (this.About?.Equals(other.About) == true));
        }
        

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.Name = {(this.Name == null ? "null" : this.Name == string.Empty ? "" : this.Name)}");
            toStringOutput.Add($"this.Id = {(this.Id == null ? "null" : this.Id.ToString())}");
            toStringOutput.Add($"this.AltId = {(this.AltId == null ? "null" : this.AltId.ToString())}");
            toStringOutput.Add($"this.SupplierId = {(this.SupplierId == null ? "null" : this.SupplierId.ToString())}");
            toStringOutput.Add($"this.Rooms = {this.Rooms}");
            toStringOutput.Add($"this.Bathrooms = {this.Bathrooms}");
            toStringOutput.Add($"this.Toilets = {(this.Toilets == null ? "null" : this.Toilets.ToString())}");
            toStringOutput.Add($"this.TotalBeds = {(this.TotalBeds == null ? "null" : this.TotalBeds.ToString())}");
            toStringOutput.Add($"this.Space = {(this.Space == null ? "null" : this.Space.ToString())}");
            toStringOutput.Add($"this.SpaceUnit = {(this.SpaceUnit == null ? "null" : this.SpaceUnit.ToString())}");
            toStringOutput.Add($"this.Persons = {this.Persons}");
            toStringOutput.Add($"this.Childs = {(this.Childs == null ? "null" : this.Childs.ToString())}");
            toStringOutput.Add($"this.Latitude = {(this.Latitude == null ? "null" : this.Latitude.ToString())}");
            toStringOutput.Add($"this.Longitude = {(this.Longitude == null ? "null" : this.Longitude.ToString())}");
            toStringOutput.Add($"this.LivingRoom = {(this.LivingRoom == null ? "null" : this.LivingRoom.ToString())}");
            toStringOutput.Add($"this.Notes = {(this.Notes == null ? "null" : this.Notes.ToString())}");
            toStringOutput.Add($"this.AttributesWithQuantity = {(this.AttributesWithQuantity == null ? "null" : $"[{string.Join(", ", this.AttributesWithQuantity)} ]")}");
            toStringOutput.Add($"this.NearbyAmenities = {(this.NearbyAmenities == null ? "null" : $"[{string.Join(", ", this.NearbyAmenities)} ]")}");
            toStringOutput.Add($"this.PropertyType = {this.PropertyType}");
            toStringOutput.Add($"this.BedroomConfiguration = {(this.BedroomConfiguration == null ? "null" : this.BedroomConfiguration.ToString())}");
            toStringOutput.Add($"this.CheckInTime = {(this.CheckInTime == null ? "null" : this.CheckInTime == string.Empty ? "" : this.CheckInTime)}");
            toStringOutput.Add($"this.CheckInToTime = {(this.CheckInToTime == null ? "null" : this.CheckInToTime == string.Empty ? "" : this.CheckInToTime)}");
            toStringOutput.Add($"this.CheckOutTime = {(this.CheckOutTime == null ? "null" : this.CheckOutTime == string.Empty ? "" : this.CheckOutTime)}");
            toStringOutput.Add($"this.Currency = {(this.Currency == null ? "null" : this.Currency == string.Empty ? "" : this.Currency)}");
            toStringOutput.Add($"this.Policy = {(this.Policy == null ? "null" : this.Policy.ToString())}");
            toStringOutput.Add($"this.Location = {(this.Location == null ? "null" : this.Location.ToString())}");
            toStringOutput.Add($"this.SupportedLosRates = {this.SupportedLosRates}");
            toStringOutput.Add($"this.TaxNumber = {(this.TaxNumber == null ? "null" : this.TaxNumber == string.Empty ? "" : this.TaxNumber)}");
            toStringOutput.Add($"this.MultiUnit = {(this.MultiUnit == null ? "null" : this.MultiUnit.ToString())}");
            toStringOutput.Add($"this.ParentId = {(this.ParentId == null ? "null" : this.ParentId.ToString())}");
            toStringOutput.Add($"this.PropertyRating = {(this.PropertyRating == null ? "null" : this.PropertyRating.ToString())}");
            toStringOutput.Add($"this.RatingNumber = {(this.RatingNumber == null ? "null" : this.RatingNumber.ToString())}");
            toStringOutput.Add($"this.MinimumRentingAge = {(this.MinimumRentingAge == null ? "null" : this.MinimumRentingAge.ToString())}");
            toStringOutput.Add($"this.BasePrice = {(this.BasePrice == null ? "null" : this.BasePrice.ToString())}");
            toStringOutput.Add($"this.BuiltDate = {(this.BuiltDate == null ? "null" : this.BuiltDate.ToString())}");
            toStringOutput.Add($"this.RenovatingDate = {(this.RenovatingDate == null ? "null" : this.RenovatingDate.ToString())}");
            toStringOutput.Add($"this.RentingDate = {(this.RentingDate == null ? "null" : this.RentingDate.ToString())}");
            toStringOutput.Add($"this.HostLocation = {(this.HostLocation == null ? "null" : this.HostLocation.ToString())}");
            toStringOutput.Add($"this.KeyCollection = {(this.KeyCollection == null ? "null" : this.KeyCollection.ToString())}");
            toStringOutput.Add($"this.NeighborhoodOverview = {(this.NeighborhoodOverview == null ? "null" : this.NeighborhoodOverview.ToString())}");
            toStringOutput.Add($"this.About = {(this.About == null ? "null" : this.About.ToString())}");
        }
    }
}