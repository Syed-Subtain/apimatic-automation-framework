// <copyright file="FullupdateImagesRequest.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace SupplierAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using SupplierAPI.Standard;
    using SupplierAPI.Standard.Utilities;

    /// <summary>
    /// FullupdateImagesRequest.
    /// </summary>
    public class FullupdateImagesRequest
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="FullupdateImagesRequest"/> class.
        /// </summary>
        public FullupdateImagesRequest()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="FullupdateImagesRequest"/> class.
        /// </summary>
        /// <param name="data">data.</param>
        public FullupdateImagesRequest(
            Models.ImagesURLForFullUpdate data)
        {
            this.Data = data;
        }

        /// <summary>
        /// Model with one image URL for one property used for inserting new image
        /// </summary>
        [JsonProperty("data")]
        public Models.ImagesURLForFullUpdate Data { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"FullupdateImagesRequest : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is FullupdateImagesRequest other &&
                ((this.Data == null && other.Data == null) || (this.Data?.Equals(other.Data) == true));
        }
        

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.Data = {(this.Data == null ? "null" : this.Data.ToString())}");
        }
    }
}