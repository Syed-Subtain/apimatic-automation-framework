// <copyright file="CreditCard.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace SupplierAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using SupplierAPI.Standard;
    using SupplierAPI.Standard.Utilities;

    /// <summary>
    /// CreditCard.
    /// </summary>
    public class CreditCard
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="CreditCard"/> class.
        /// </summary>
        public CreditCard()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="CreditCard"/> class.
        /// </summary>
        /// <param name="creditCardType">creditCardType.</param>
        /// <param name="paymentGateways">paymentGateways.</param>
        /// <param name="creditCardList">creditCardList.</param>
        public CreditCard(
            Models.CreditCardTypeEnum creditCardType,
            Models.PaymentGateways paymentGateways = null,
            List<Models.CreditCardListEnum> creditCardList = null)
        {
            this.CreditCardType = creditCardType;
            this.PaymentGateways = paymentGateways;
            this.CreditCardList = creditCardList;
        }

        /// <summary>
        /// Gets or sets CreditCardType.
        /// </summary>
        [JsonProperty("creditCardType", ItemConverterType = typeof(StringEnumConverter))]
        public Models.CreditCardTypeEnum CreditCardType { get; set; }

        /// <summary>
        /// Gets or sets PaymentGateways.
        /// </summary>
        [JsonProperty("paymentGateways", NullValueHandling = NullValueHandling.Ignore)]
        public Models.PaymentGateways PaymentGateways { get; set; }

        /// <summary>
        /// List of acceptable credit cards. Allowed only if type is TRANSMIT. {MASTER_CARD,VISA,AMERICAN_EXPRESS,DINERS_CLUB,DISCOVER}. If POST method selected it will select all creditCardList.
        /// </summary>
        [JsonProperty("creditCardList", ItemConverterType = typeof(StringEnumConverter), NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.CreditCardListEnum> CreditCardList { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"CreditCard : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is CreditCard other &&
                this.CreditCardType.Equals(other.CreditCardType) &&
                ((this.PaymentGateways == null && other.PaymentGateways == null) || (this.PaymentGateways?.Equals(other.PaymentGateways) == true)) &&
                ((this.CreditCardList == null && other.CreditCardList == null) || (this.CreditCardList?.Equals(other.CreditCardList) == true));
        }
        

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.CreditCardType = {this.CreditCardType}");
            toStringOutput.Add($"this.PaymentGateways = {(this.PaymentGateways == null ? "null" : this.PaymentGateways.ToString())}");
            toStringOutput.Add($"this.CreditCardList = {(this.CreditCardList == null ? "null" : $"[{string.Join(", ", this.CreditCardList)} ]")}");
        }
    }
}