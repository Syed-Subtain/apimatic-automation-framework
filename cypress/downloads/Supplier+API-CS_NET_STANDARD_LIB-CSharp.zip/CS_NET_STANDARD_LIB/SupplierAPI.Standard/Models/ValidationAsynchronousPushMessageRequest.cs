// <copyright file="ValidationAsynchronousPushMessageRequest.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace SupplierAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using SupplierAPI.Standard;
    using SupplierAPI.Standard.Utilities;

    /// <summary>
    /// ValidationAsynchronousPushMessageRequest.
    /// </summary>
    public class ValidationAsynchronousPushMessageRequest
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ValidationAsynchronousPushMessageRequest"/> class.
        /// </summary>
        public ValidationAsynchronousPushMessageRequest()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ValidationAsynchronousPushMessageRequest"/> class.
        /// </summary>
        /// <param name="supplierId">supplierId.</param>
        /// <param name="type">type.</param>
        /// <param name="validation">validation.</param>
        public ValidationAsynchronousPushMessageRequest(
            int supplierId,
            string type,
            List<Models.AsynchronousValidationModel> validation)
        {
            this.SupplierId = supplierId;
            this.Type = type;
            this.Validation = validation;
        }

        /// <summary>
        /// Id of supplier in BookingPal
        /// </summary>
        [JsonProperty("supplierId")]
        public int SupplierId { get; set; }

        /// <summary>
        /// Gets or sets Type.
        /// </summary>
        [JsonProperty("type")]
        public string Type { get; set; }

        /// <summary>
        /// Validation Model
        /// </summary>
        [JsonProperty("validation")]
        public List<Models.AsynchronousValidationModel> Validation { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"ValidationAsynchronousPushMessageRequest : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is ValidationAsynchronousPushMessageRequest other &&
                this.SupplierId.Equals(other.SupplierId) &&
                ((this.Type == null && other.Type == null) || (this.Type?.Equals(other.Type) == true)) &&
                ((this.Validation == null && other.Validation == null) || (this.Validation?.Equals(other.Validation) == true));
        }
        

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.SupplierId = {this.SupplierId}");
            toStringOutput.Add($"this.Type = {(this.Type == null ? "null" : this.Type == string.Empty ? "" : this.Type)}");
            toStringOutput.Add($"this.Validation = {(this.Validation == null ? "null" : $"[{string.Join(", ", this.Validation)} ]")}");
        }
    }
}