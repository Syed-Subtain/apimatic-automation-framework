// <copyright file="FeeEntityTypeEnum.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace SupplierAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Runtime.Serialization;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using SupplierAPI.Standard;
    using SupplierAPI.Standard.Utilities;

    /// <summary>
    /// FeeEntityTypeEnum.
    /// </summary>
    [JsonConverter(typeof(StringEnumConverter))]
    public enum FeeEntityTypeEnum
    {
        /// <summary>
        /// MANDATORY.
        /// </summary>
        [EnumMember(Value = "MANDATORY")]
        MANDATORY,

        /// <summary>
        /// OPTIONAL.
        /// </summary>
        [EnumMember(Value = "OPTIONAL")]
        OPTIONAL,

        /// <summary>
        /// MANDATORYPAL.
        /// </summary>
        [EnumMember(Value = "MANDATORY_PAL")]
        MANDATORYPAL
    }
}