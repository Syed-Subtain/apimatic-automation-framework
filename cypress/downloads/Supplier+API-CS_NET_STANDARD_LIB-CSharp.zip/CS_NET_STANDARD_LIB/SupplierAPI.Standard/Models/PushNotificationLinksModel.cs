// <copyright file="PushNotificationLinksModel.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace SupplierAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using SupplierAPI.Standard;
    using SupplierAPI.Standard.Utilities;

    /// <summary>
    /// PushNotificationLinksModel.
    /// </summary>
    public class PushNotificationLinksModel
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="PushNotificationLinksModel"/> class.
        /// </summary>
        public PushNotificationLinksModel()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="PushNotificationLinksModel"/> class.
        /// </summary>
        /// <param name="bookLink">bookLink.</param>
        /// <param name="cancelLink">cancelLink.</param>
        /// <param name="asyncPush">asyncPush.</param>
        /// <param name="requestToBook">requestToBook.</param>
        /// <param name="reservationLink">reservationLink.</param>
        /// <param name="useJson">useJson.</param>
        public PushNotificationLinksModel(
            string bookLink = null,
            string cancelLink = null,
            string asyncPush = null,
            string requestToBook = null,
            string reservationLink = null,
            bool? useJson = null)
        {
            this.BookLink = bookLink;
            this.CancelLink = cancelLink;
            this.AsyncPush = asyncPush;
            this.RequestToBook = requestToBook;
            this.ReservationLink = reservationLink;
            this.UseJson = useJson;
        }

        /// <summary>
        /// DEPRECATED. Check "reservationLink" field instead.  -  Link for getting notifications about new reservations
        /// </summary>
        [JsonProperty("bookLink", NullValueHandling = NullValueHandling.Ignore)]
        public string BookLink { get; set; }

        /// <summary>
        /// DEPRECATED. Check "reservationLink" field instead. - Link for getting notification about cancel reservation
        /// </summary>
        [JsonProperty("cancelLink", NullValueHandling = NullValueHandling.Ignore)]
        public string CancelLink { get; set; }

        /// <summary>
        /// Link for push data for async messages
        /// </summary>
        [JsonProperty("asyncPush", NullValueHandling = NullValueHandling.Ignore)]
        public string AsyncPush { get; set; }

        /// <summary>
        /// DEPRECATED. Check "reservationLink" field instead. Link for request to book for AirBnb
        /// </summary>
        [JsonProperty("requestToBook", NullValueHandling = NullValueHandling.Ignore)]
        public string RequestToBook { get; set; }

        /// <summary>
        /// Link for notifications for reservations. It is added instead of deprecated fields bookLink, cancelLink and requestToBook. On this link it will be pushed all reservation notification (new, cancel and update, and request to book requests) when you set this link. It is very important that you first implement slightly changed reservation notification and to accept new modified object of this push message. When you add this link - we will assume that you finish new implementation and you will get all reservation request on this endpoint with slight changed reservation object.
        /// </summary>
        [JsonProperty("reservationLink", NullValueHandling = NullValueHandling.Ignore)]
        public string ReservationLink { get; set; }

        /// <summary>
        /// optional boolean field to get the response in JSON or XML format.
        /// </summary>
        [JsonProperty("useJson", NullValueHandling = NullValueHandling.Ignore)]
        public bool? UseJson { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"PushNotificationLinksModel : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is PushNotificationLinksModel other &&
                ((this.BookLink == null && other.BookLink == null) || (this.BookLink?.Equals(other.BookLink) == true)) &&
                ((this.CancelLink == null && other.CancelLink == null) || (this.CancelLink?.Equals(other.CancelLink) == true)) &&
                ((this.AsyncPush == null && other.AsyncPush == null) || (this.AsyncPush?.Equals(other.AsyncPush) == true)) &&
                ((this.RequestToBook == null && other.RequestToBook == null) || (this.RequestToBook?.Equals(other.RequestToBook) == true)) &&
                ((this.ReservationLink == null && other.ReservationLink == null) || (this.ReservationLink?.Equals(other.ReservationLink) == true)) &&
                ((this.UseJson == null && other.UseJson == null) || (this.UseJson?.Equals(other.UseJson) == true));
        }
        

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.BookLink = {(this.BookLink == null ? "null" : this.BookLink == string.Empty ? "" : this.BookLink)}");
            toStringOutput.Add($"this.CancelLink = {(this.CancelLink == null ? "null" : this.CancelLink == string.Empty ? "" : this.CancelLink)}");
            toStringOutput.Add($"this.AsyncPush = {(this.AsyncPush == null ? "null" : this.AsyncPush == string.Empty ? "" : this.AsyncPush)}");
            toStringOutput.Add($"this.RequestToBook = {(this.RequestToBook == null ? "null" : this.RequestToBook == string.Empty ? "" : this.RequestToBook)}");
            toStringOutput.Add($"this.ReservationLink = {(this.ReservationLink == null ? "null" : this.ReservationLink == string.Empty ? "" : this.ReservationLink)}");
            toStringOutput.Add($"this.UseJson = {(this.UseJson == null ? "null" : this.UseJson.ToString())}");
        }
    }
}