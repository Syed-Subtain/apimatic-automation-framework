// <copyright file="Thread.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace SupplierAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using SupplierAPI.Standard;
    using SupplierAPI.Standard.Utilities;

    /// <summary>
    /// Thread.
    /// </summary>
    public class Thread
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="Thread"/> class.
        /// </summary>
        public Thread()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="Thread"/> class.
        /// </summary>
        /// <param name="id">id.</param>
        /// <param name="lastMessageSentAt">lastMessageSentAt.</param>
        /// <param name="lastMessageText">lastMessageText.</param>
        /// <param name="channelName">channelName.</param>
        /// <param name="channelABB">channelABB.</param>
        /// <param name="guestName">guestName.</param>
        /// <param name="productId">productId.</param>
        /// <param name="dateFrom">dateFrom.</param>
        /// <param name="dateTo">dateTo.</param>
        /// <param name="channelThreadId">channelThreadId.</param>
        /// <param name="guestEmailAddress">guestEmailAddress.</param>
        /// <param name="reservationId">reservationId.</param>
        public Thread(
            int id,
            string lastMessageSentAt,
            string lastMessageText,
            string channelName,
            Models.ChannelABBEnum channelABB,
            string guestName,
            int productId,
            DateTime dateFrom,
            DateTime dateTo,
            string channelThreadId = null,
            string guestEmailAddress = null,
            int? reservationId = null)
        {
            this.Id = id;
            this.LastMessageSentAt = lastMessageSentAt;
            this.LastMessageText = lastMessageText;
            this.ChannelThreadId = channelThreadId;
            this.ChannelName = channelName;
            this.ChannelABB = channelABB;
            this.GuestName = guestName;
            this.GuestEmailAddress = guestEmailAddress;
            this.ProductId = productId;
            this.ReservationId = reservationId;
            this.DateFrom = dateFrom;
            this.DateTo = dateTo;
        }

        /// <summary>
        /// Thread ID
        /// </summary>
        [JsonProperty("id")]
        public int Id { get; set; }

        /// <summary>
        /// Time when last message was sent
        /// </summary>
        [JsonProperty("lastMessageSentAt")]
        public string LastMessageSentAt { get; set; }

        /// <summary>
        /// Last message text
        /// </summary>
        [JsonProperty("lastMessageText")]
        public string LastMessageText { get; set; }

        /// <summary>
        /// Channel thread ID
        /// </summary>
        [JsonProperty("channelThreadId", NullValueHandling = NullValueHandling.Ignore)]
        public string ChannelThreadId { get; set; }

        /// <summary>
        /// Channel from where come reservation
        /// </summary>
        [JsonProperty("channelName")]
        public string ChannelName { get; set; }

        /// <summary>
        /// Gets or sets ChannelABB.
        /// </summary>
        [JsonProperty("channelABB", ItemConverterType = typeof(StringEnumConverter))]
        public Models.ChannelABBEnum ChannelABB { get; set; }

        /// <summary>
        /// Name of guest
        /// </summary>
        [JsonProperty("guestName")]
        public string GuestName { get; set; }

        /// <summary>
        /// Email of guest
        /// </summary>
        [JsonProperty("guestEmailAddress", NullValueHandling = NullValueHandling.Ignore)]
        public string GuestEmailAddress { get; set; }

        /// <summary>
        /// ID of product in BookingPal database
        /// </summary>
        [JsonProperty("productId")]
        public int ProductId { get; set; }

        /// <summary>
        /// ID of reservation
        /// </summary>
        [JsonProperty("reservationId", NullValueHandling = NullValueHandling.Ignore)]
        public int? ReservationId { get; set; }

        /// <summary>
        /// Start date of reservation. Date is in format "yyyy-MM-dd"
        /// </summary>
        [JsonConverter(typeof(CustomDateTimeConverter), "yyyy'-'MM'-'dd")]
        [JsonProperty("dateFrom")]
        public DateTime DateFrom { get; set; }

        /// <summary>
        /// End date of reservation. Date is in format "yyyy-MM-dd"
        /// </summary>
        [JsonConverter(typeof(CustomDateTimeConverter), "yyyy'-'MM'-'dd")]
        [JsonProperty("dateTo")]
        public DateTime DateTo { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"Thread : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is Thread other &&
                this.Id.Equals(other.Id) &&
                ((this.LastMessageSentAt == null && other.LastMessageSentAt == null) || (this.LastMessageSentAt?.Equals(other.LastMessageSentAt) == true)) &&
                ((this.LastMessageText == null && other.LastMessageText == null) || (this.LastMessageText?.Equals(other.LastMessageText) == true)) &&
                ((this.ChannelThreadId == null && other.ChannelThreadId == null) || (this.ChannelThreadId?.Equals(other.ChannelThreadId) == true)) &&
                ((this.ChannelName == null && other.ChannelName == null) || (this.ChannelName?.Equals(other.ChannelName) == true)) &&
                this.ChannelABB.Equals(other.ChannelABB) &&
                ((this.GuestName == null && other.GuestName == null) || (this.GuestName?.Equals(other.GuestName) == true)) &&
                ((this.GuestEmailAddress == null && other.GuestEmailAddress == null) || (this.GuestEmailAddress?.Equals(other.GuestEmailAddress) == true)) &&
                this.ProductId.Equals(other.ProductId) &&
                ((this.ReservationId == null && other.ReservationId == null) || (this.ReservationId?.Equals(other.ReservationId) == true)) &&
                this.DateFrom.Equals(other.DateFrom) &&
                this.DateTo.Equals(other.DateTo);
        }
        

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.Id = {this.Id}");
            toStringOutput.Add($"this.LastMessageSentAt = {(this.LastMessageSentAt == null ? "null" : this.LastMessageSentAt == string.Empty ? "" : this.LastMessageSentAt)}");
            toStringOutput.Add($"this.LastMessageText = {(this.LastMessageText == null ? "null" : this.LastMessageText == string.Empty ? "" : this.LastMessageText)}");
            toStringOutput.Add($"this.ChannelThreadId = {(this.ChannelThreadId == null ? "null" : this.ChannelThreadId == string.Empty ? "" : this.ChannelThreadId)}");
            toStringOutput.Add($"this.ChannelName = {(this.ChannelName == null ? "null" : this.ChannelName == string.Empty ? "" : this.ChannelName)}");
            toStringOutput.Add($"this.ChannelABB = {this.ChannelABB}");
            toStringOutput.Add($"this.GuestName = {(this.GuestName == null ? "null" : this.GuestName == string.Empty ? "" : this.GuestName)}");
            toStringOutput.Add($"this.GuestEmailAddress = {(this.GuestEmailAddress == null ? "null" : this.GuestEmailAddress == string.Empty ? "" : this.GuestEmailAddress)}");
            toStringOutput.Add($"this.ProductId = {this.ProductId}");
            toStringOutput.Add($"this.ReservationId = {(this.ReservationId == null ? "null" : this.ReservationId.ToString())}");
            toStringOutput.Add($"this.DateFrom = {this.DateFrom}");
            toStringOutput.Add($"this.DateTo = {this.DateTo}");
        }
    }
}