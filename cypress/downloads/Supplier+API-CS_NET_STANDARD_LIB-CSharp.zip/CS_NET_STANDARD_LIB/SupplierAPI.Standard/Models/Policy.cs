// <copyright file="Policy.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace SupplierAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using SupplierAPI.Standard;
    using SupplierAPI.Standard.Utilities;

    /// <summary>
    /// Policy.
    /// </summary>
    public class Policy
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="Policy"/> class.
        /// </summary>
        public Policy()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="Policy"/> class.
        /// </summary>
        /// <param name="childrenAllowed">childrenAllowed.</param>
        /// <param name="smokingAllowed">smokingAllowed.</param>
        /// <param name="internetPolicy">internetPolicy.</param>
        /// <param name="parkingPolicy">parkingPolicy.</param>
        /// <param name="petPolicy">petPolicy.</param>
        public Policy(
            bool childrenAllowed,
            bool smokingAllowed,
            Models.InternetPolicy internetPolicy = null,
            Models.ParkingPolicy parkingPolicy = null,
            Models.PetPolicy petPolicy = null)
        {
            this.InternetPolicy = internetPolicy;
            this.ParkingPolicy = parkingPolicy;
            this.PetPolicy = petPolicy;
            this.ChildrenAllowed = childrenAllowed;
            this.SmokingAllowed = smokingAllowed;
        }

        /// <summary>
        /// Gets or sets InternetPolicy.
        /// </summary>
        [JsonProperty("internetPolicy", NullValueHandling = NullValueHandling.Ignore)]
        public Models.InternetPolicy InternetPolicy { get; set; }

        /// <summary>
        /// Gets or sets ParkingPolicy.
        /// </summary>
        [JsonProperty("parkingPolicy", NullValueHandling = NullValueHandling.Ignore)]
        public Models.ParkingPolicy ParkingPolicy { get; set; }

        /// <summary>
        /// Gets or sets PetPolicy.
        /// </summary>
        [JsonProperty("petPolicy", NullValueHandling = NullValueHandling.Ignore)]
        public Models.PetPolicy PetPolicy { get; set; }

        /// <summary>
        /// Children policy
        /// </summary>
        [JsonProperty("childrenAllowed")]
        public bool ChildrenAllowed { get; set; }

        /// <summary>
        /// Smoking policy
        /// </summary>
        [JsonProperty("smokingAllowed")]
        public bool SmokingAllowed { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"Policy : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is Policy other &&
                ((this.InternetPolicy == null && other.InternetPolicy == null) || (this.InternetPolicy?.Equals(other.InternetPolicy) == true)) &&
                ((this.ParkingPolicy == null && other.ParkingPolicy == null) || (this.ParkingPolicy?.Equals(other.ParkingPolicy) == true)) &&
                ((this.PetPolicy == null && other.PetPolicy == null) || (this.PetPolicy?.Equals(other.PetPolicy) == true)) &&
                this.ChildrenAllowed.Equals(other.ChildrenAllowed) &&
                this.SmokingAllowed.Equals(other.SmokingAllowed);
        }
        

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.InternetPolicy = {(this.InternetPolicy == null ? "null" : this.InternetPolicy.ToString())}");
            toStringOutput.Add($"this.ParkingPolicy = {(this.ParkingPolicy == null ? "null" : this.ParkingPolicy.ToString())}");
            toStringOutput.Add($"this.PetPolicy = {(this.PetPolicy == null ? "null" : this.PetPolicy.ToString())}");
            toStringOutput.Add($"this.ChildrenAllowed = {this.ChildrenAllowed}");
            toStringOutput.Add($"this.SmokingAllowed = {this.SmokingAllowed}");
        }
    }
}