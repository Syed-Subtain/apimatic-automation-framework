// <copyright file="ProductImageAsynchronousPushMessageRequest.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace SupplierAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using SupplierAPI.Standard;
    using SupplierAPI.Standard.Utilities;

    /// <summary>
    /// ProductImageAsynchronousPushMessageRequest.
    /// </summary>
    public class ProductImageAsynchronousPushMessageRequest
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ProductImageAsynchronousPushMessageRequest"/> class.
        /// </summary>
        public ProductImageAsynchronousPushMessageRequest()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ProductImageAsynchronousPushMessageRequest"/> class.
        /// </summary>
        /// <param name="supplierId">supplierId.</param>
        /// <param name="type">type.</param>
        /// <param name="processingImage">processingImage.</param>
        public ProductImageAsynchronousPushMessageRequest(
            int supplierId,
            string type,
            List<Models.ProductImagePushNotification> processingImage)
        {
            this.SupplierId = supplierId;
            this.Type = type;
            this.ProcessingImage = processingImage;
        }

        /// <summary>
        /// Id of supplier in BookingPal
        /// </summary>
        [JsonProperty("supplierId")]
        public int SupplierId { get; set; }

        /// <summary>
        /// Gets or sets Type.
        /// </summary>
        [JsonProperty("type")]
        public string Type { get; set; }

        /// <summary>
        /// Product Image Validation Model
        /// </summary>
        [JsonProperty("processingImage")]
        public List<Models.ProductImagePushNotification> ProcessingImage { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"ProductImageAsynchronousPushMessageRequest : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is ProductImageAsynchronousPushMessageRequest other &&
                this.SupplierId.Equals(other.SupplierId) &&
                ((this.Type == null && other.Type == null) || (this.Type?.Equals(other.Type) == true)) &&
                ((this.ProcessingImage == null && other.ProcessingImage == null) || (this.ProcessingImage?.Equals(other.ProcessingImage) == true));
        }
        

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.SupplierId = {this.SupplierId}");
            toStringOutput.Add($"this.Type = {(this.Type == null ? "null" : this.Type == string.Empty ? "" : this.Type)}");
            toStringOutput.Add($"this.ProcessingImage = {(this.ProcessingImage == null ? "null" : $"[{string.Join(", ", this.ProcessingImage)} ]")}");
        }
    }
}