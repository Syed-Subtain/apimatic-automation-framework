// <copyright file="KeyCollectionCheckinmethodEnum.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace SupplierAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Runtime.Serialization;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using SupplierAPI.Standard;
    using SupplierAPI.Standard.Utilities;

    /// <summary>
    /// KeyCollectionCheckinmethodEnum.
    /// </summary>
    [JsonConverter(typeof(StringEnumConverter))]
    public enum KeyCollectionCheckinmethodEnum
    {
        /// <summary>
        /// Doorman.
        /// </summary>
        [EnumMember(Value = "doorman")]
        Doorman,

        /// <summary>
        /// LockBox.
        /// </summary>
        [EnumMember(Value = "lock_box")]
        LockBox,

        /// <summary>
        /// SmartLock.
        /// </summary>
        [EnumMember(Value = "smart_lock")]
        SmartLock,

        /// <summary>
        /// Keypad.
        /// </summary>
        [EnumMember(Value = "keypad")]
        Keypad,

        /// <summary>
        /// InPersonMeet.
        /// </summary>
        [EnumMember(Value = "in_person_meet")]
        InPersonMeet,

        /// <summary>
        /// Other.
        /// </summary>
        [EnumMember(Value = "other")]
        Other,

        /// <summary>
        /// FrontDesk.
        /// </summary>
        [EnumMember(Value = "front_desk")]
        FrontDesk,

        /// <summary>
        /// SecretSpot.
        /// </summary>
        [EnumMember(Value = "secret_spot")]
        SecretSpot,

        /// <summary>
        /// InstructionContactUs.
        /// </summary>
        [EnumMember(Value = "instruction_contact_us")]
        InstructionContactUs
    }
}