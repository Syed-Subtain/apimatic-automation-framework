// <copyright file="PropertyTypesEnum.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace SupplierAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Runtime.Serialization;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using SupplierAPI.Standard;
    using SupplierAPI.Standard.Utilities;

    /// <summary>
    /// PropertyTypesEnum.
    /// </summary>
    [JsonConverter(typeof(StringEnumConverter))]
    public enum PropertyTypesEnum
    {
        /// <summary>
        ///Townhome
        /// PCT101.
        /// </summary>
        [EnumMember(Value = "PCT101")]
        PCT101,

        /// <summary>
        ///Single Room
        /// PCT102.
        /// </summary>
        [EnumMember(Value = "PCT102")]
        PCT102,

        /// <summary>
        ///Double Room
        /// PCT103.
        /// </summary>
        [EnumMember(Value = "PCT103")]
        PCT103,

        /// <summary>
        ///Twin
        /// PCT104.
        /// </summary>
        [EnumMember(Value = "PCT104")]
        PCT104,

        /// <summary>
        ///Twin/Double
        /// PCT105.
        /// </summary>
        [EnumMember(Value = "PCT105")]
        PCT105,

        /// <summary>
        ///Triple Room
        /// PCT106.
        /// </summary>
        [EnumMember(Value = "PCT106")]
        PCT106,

        /// <summary>
        ///Quadruple
        /// PCT107.
        /// </summary>
        [EnumMember(Value = "PCT107")]
        PCT107,

        /// <summary>
        ///Family
        /// PCT108.
        /// </summary>
        [EnumMember(Value = "PCT108")]
        PCT108,

        /// <summary>
        ///Suite
        /// PCT109.
        /// </summary>
        [EnumMember(Value = "PCT109")]
        PCT109,

        /// <summary>
        ///Studio
        /// PCT110.
        /// </summary>
        [EnumMember(Value = "PCT110")]
        PCT110,

        /// <summary>
        ///Bungalow
        /// PCT111.
        /// </summary>
        [EnumMember(Value = "PCT111")]
        PCT111,

        /// <summary>
        ///Private room
        /// PCT112.
        /// </summary>
        [EnumMember(Value = "PCT112")]
        PCT112,

        /// <summary>
        ///Shared room
        /// PCT113.
        /// </summary>
        [EnumMember(Value = "PCT113")]
        PCT113,

        /// <summary>
        ///Cottage
        /// PCT114.
        /// </summary>
        [EnumMember(Value = "PCT114")]
        PCT114,

        /// <summary>
        ///Apart Hotel
        /// PCT115.
        /// </summary>
        [EnumMember(Value = "PCT115")]
        PCT115,

        /// <summary>
        ///Narrow boat
        /// PCT116.
        /// </summary>
        [EnumMember(Value = "PCT116")]
        PCT116,

        /// <summary>
        ///Riad
        /// PCT117.
        /// </summary>
        [EnumMember(Value = "PCT117")]
        PCT117,

        /// <summary>
        ///Shepherd Hut
        /// PCT118.
        /// </summary>
        [EnumMember(Value = "PCT118")]
        PCT118,

        /// <summary>
        ///Tipi
        /// PCT119.
        /// </summary>
        [EnumMember(Value = "PCT119")]
        PCT119,

        /// <summary>
        ///Cruise
        /// PCT12.
        /// </summary>
        [EnumMember(Value = "PCT12")]
        PCT12,

        /// <summary>
        ///Tower
        /// PCT120.
        /// </summary>
        [EnumMember(Value = "PCT120")]
        PCT120,

        /// <summary>
        ///Tree house
        /// PCT121.
        /// </summary>
        [EnumMember(Value = "PCT121")]
        PCT121,

        /// <summary>
        ///Trullo
        /// PCT122.
        /// </summary>
        [EnumMember(Value = "PCT122")]
        PCT122,

        /// <summary>
        ///Watermill
        /// PCT123.
        /// </summary>
        [EnumMember(Value = "PCT123")]
        PCT123,

        /// <summary>
        ///Windmill
        /// PCT124.
        /// </summary>
        [EnumMember(Value = "PCT124")]
        PCT124,

        /// <summary>
        ///Yacht
        /// PCT125.
        /// </summary>
        [EnumMember(Value = "PCT125")]
        PCT125,

        /// <summary>
        ///Yurt
        /// PCT126.
        /// </summary>
        [EnumMember(Value = "PCT126")]
        PCT126,

        /// <summary>
        ///Log Cabin
        /// PCT127.
        /// </summary>
        [EnumMember(Value = "PCT127")]
        PCT127,

        /// <summary>
        ///Penthouse
        /// PCT128.
        /// </summary>
        [EnumMember(Value = "PCT128")]
        PCT128,

        /// <summary>
        ///Ferry
        /// PCT14.
        /// </summary>
        [EnumMember(Value = "PCT14")]
        PCT14,

        /// <summary>
        ///Guest farm
        /// PCT15.
        /// </summary>
        [EnumMember(Value = "PCT15")]
        PCT15,

        /// <summary>
        ///Guest house limited service
        /// PCT16.
        /// </summary>
        [EnumMember(Value = "PCT16")]
        PCT16,

        /// <summary>
        ///Holiday resort
        /// PCT18.
        /// </summary>
        [EnumMember(Value = "PCT18")]
        PCT18,

        /// <summary>
        ///Hostel
        /// PCT19.
        /// </summary>
        [EnumMember(Value = "PCT19")]
        PCT19,

        /// <summary>
        ///Hotel
        /// PCT20.
        /// </summary>
        [EnumMember(Value = "PCT20")]
        PCT20,

        /// <summary>
        ///Inn
        /// PCT21.
        /// </summary>
        [EnumMember(Value = "PCT21")]
        PCT21,

        /// <summary>
        ///Lodge
        /// PCT22.
        /// </summary>
        [EnumMember(Value = "PCT22")]
        PCT22,

        /// <summary>
        ///Meeting resort
        /// PCT23.
        /// </summary>
        [EnumMember(Value = "PCT23")]
        PCT23,

        /// <summary>
        ///Mobile-home
        /// PCT25.
        /// </summary>
        [EnumMember(Value = "PCT25")]
        PCT25,

        /// <summary>
        ///Monastery
        /// PCT26.
        /// </summary>
        [EnumMember(Value = "PCT26")]
        PCT26,

        /// <summary>
        ///Motel
        /// PCT27.
        /// </summary>
        [EnumMember(Value = "PCT27")]
        PCT27,

        /// <summary>
        ///Ranch
        /// PCT28.
        /// </summary>
        [EnumMember(Value = "PCT28")]
        PCT28,

        /// <summary>
        ///Residential apartment
        /// PCT29.
        /// </summary>
        [EnumMember(Value = "PCT29")]
        PCT29,

        /// <summary>
        ///Apartment
        /// PCT3.
        /// </summary>
        [EnumMember(Value = "PCT3")]
        PCT3,

        /// <summary>
        ///Resort
        /// PCT30.
        /// </summary>
        [EnumMember(Value = "PCT30")]
        PCT30,

        /// <summary>
        ///Sailing ship
        /// PCT31.
        /// </summary>
        [EnumMember(Value = "PCT31")]
        PCT31,

        /// <summary>
        ///Self catering accommodation
        /// PCT32.
        /// </summary>
        [EnumMember(Value = "PCT32")]
        PCT32,

        /// <summary>
        ///Tent
        /// PCT33.
        /// </summary>
        [EnumMember(Value = "PCT33")]
        PCT33,

        /// <summary>
        ///Vacation home
        /// PCT34.
        /// </summary>
        [EnumMember(Value = "PCT34")]
        PCT34,

        /// <summary>
        ///Villa
        /// PCT35.
        /// </summary>
        [EnumMember(Value = "PCT35")]
        PCT35,

        /// <summary>
        ///Wildlife reserve
        /// PCT36.
        /// </summary>
        [EnumMember(Value = "PCT36")]
        PCT36,

        /// <summary>
        ///Castle
        /// PCT37.
        /// </summary>
        [EnumMember(Value = "PCT37")]
        PCT37,

        /// <summary>
        ///Bed and breakfast
        /// PCT4.
        /// </summary>
        [EnumMember(Value = "PCT4")]
        PCT4,

        /// <summary>
        ///Pension
        /// PCT40.
        /// </summary>
        [EnumMember(Value = "PCT40")]
        PCT40,

        /// <summary>
        ///Ski Chalet
        /// PCT41.
        /// </summary>
        [EnumMember(Value = "PCT41")]
        PCT41,

        /// <summary>
        ///Boatel
        /// PCT44.
        /// </summary>
        [EnumMember(Value = "PCT44")]
        PCT44,

        /// <summary>
        ///Boutique
        /// PCT45.
        /// </summary>
        [EnumMember(Value = "PCT45")]
        PCT45,

        /// <summary>
        ///Efficiency/studio
        /// PCT46.
        /// </summary>
        [EnumMember(Value = "PCT46")]
        PCT46,

        /// <summary>
        ///Cabin or bungalow
        /// PCT5.
        /// </summary>
        [EnumMember(Value = "PCT5")]
        PCT5,

        /// <summary>
        ///Recreational vehicle park
        /// PCT50.
        /// </summary>
        [EnumMember(Value = "PCT50")]
        PCT50,

        /// <summary>
        ///Charm hotel
        /// PCT51.
        /// </summary>
        [EnumMember(Value = "PCT51")]
        PCT51,

        /// <summary>
        ///Manor
        /// PCT52.
        /// </summary>
        [EnumMember(Value = "PCT52")]
        PCT52,

        /// <summary>
        ///Campground
        /// PCT6.
        /// </summary>
        [EnumMember(Value = "PCT6")]
        PCT6,

        /// <summary>
        ///Chalet
        /// PCT7.
        /// </summary>
        [EnumMember(Value = "PCT7")]
        PCT7,

        /// <summary>
        ///Condominium
        /// PCT8.
        /// </summary>
        [EnumMember(Value = "PCT8")]
        PCT8
    }
}