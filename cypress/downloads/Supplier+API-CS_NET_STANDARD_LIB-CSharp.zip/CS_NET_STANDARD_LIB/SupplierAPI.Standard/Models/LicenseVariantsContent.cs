// <copyright file="LicenseVariantsContent.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace SupplierAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using SupplierAPI.Standard;
    using SupplierAPI.Standard.Utilities;

    /// <summary>
    /// LicenseVariantsContent.
    /// </summary>
    public class LicenseVariantsContent
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="LicenseVariantsContent"/> class.
        /// </summary>
        public LicenseVariantsContent()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="LicenseVariantsContent"/> class.
        /// </summary>
        /// <param name="name">name.</param>
        /// <param name="dataType">dataType.</param>
        /// <param name="required">required.</param>
        public LicenseVariantsContent(
            string name = null,
            string dataType = null,
            string required = null)
        {
            this.Name = name;
            this.DataType = dataType;
            this.Required = required;
        }

        /// <summary>
        /// name of the variant
        /// </summary>
        [JsonProperty("name", NullValueHandling = NullValueHandling.Ignore)]
        public string Name { get; set; }

        /// <summary>
        /// data type of the variant
        /// </summary>
        [JsonProperty("dataType", NullValueHandling = NullValueHandling.Ignore)]
        public string DataType { get; set; }

        /// <summary>
        /// indicator if content is required
        /// </summary>
        [JsonProperty("required", NullValueHandling = NullValueHandling.Ignore)]
        public string Required { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"LicenseVariantsContent : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is LicenseVariantsContent other &&
                ((this.Name == null && other.Name == null) || (this.Name?.Equals(other.Name) == true)) &&
                ((this.DataType == null && other.DataType == null) || (this.DataType?.Equals(other.DataType) == true)) &&
                ((this.Required == null && other.Required == null) || (this.Required?.Equals(other.Required) == true));
        }
        

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.Name = {(this.Name == null ? "null" : this.Name == string.Empty ? "" : this.Name)}");
            toStringOutput.Add($"this.DataType = {(this.DataType == null ? "null" : this.DataType == string.Empty ? "" : this.DataType)}");
            toStringOutput.Add($"this.Required = {(this.Required == null ? "null" : this.Required == string.Empty ? "" : this.Required)}");
        }
    }
}