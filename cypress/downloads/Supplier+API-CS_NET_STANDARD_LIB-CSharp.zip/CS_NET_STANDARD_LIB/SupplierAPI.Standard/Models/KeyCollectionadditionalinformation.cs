// <copyright file="KeyCollectionadditionalinformation.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace SupplierAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using SupplierAPI.Standard;
    using SupplierAPI.Standard.Utilities;

    /// <summary>
    /// KeyCollectionadditionalinformation.
    /// </summary>
    public class KeyCollectionadditionalinformation
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="KeyCollectionadditionalinformation"/> class.
        /// </summary>
        public KeyCollectionadditionalinformation()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="KeyCollectionadditionalinformation"/> class.
        /// </summary>
        /// <param name="instruction">instruction.</param>
        public KeyCollectionadditionalinformation(
            Models.KeyCollectionadditionalinformationinstruction instruction)
        {
            this.Instruction = instruction;
        }

        /// <summary>
        /// Gets or sets Instruction.
        /// </summary>
        [JsonProperty("instruction")]
        public Models.KeyCollectionadditionalinformationinstruction Instruction { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"KeyCollectionadditionalinformation : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is KeyCollectionadditionalinformation other &&
                ((this.Instruction == null && other.Instruction == null) || (this.Instruction?.Equals(other.Instruction) == true));
        }
        

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.Instruction = {(this.Instruction == null ? "null" : this.Instruction.ToString())}");
        }
    }
}