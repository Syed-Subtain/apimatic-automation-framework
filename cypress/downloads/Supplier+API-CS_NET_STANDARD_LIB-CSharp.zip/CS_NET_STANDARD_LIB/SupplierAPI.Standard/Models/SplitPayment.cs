// <copyright file="SplitPayment.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace SupplierAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using SupplierAPI.Standard;
    using SupplierAPI.Standard.Utilities;

    /// <summary>
    /// SplitPayment.
    /// </summary>
    public class SplitPayment
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="SplitPayment"/> class.
        /// </summary>
        public SplitPayment()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="SplitPayment"/> class.
        /// </summary>
        /// <param name="depositType">depositType.</param>
        /// <param name="mValue">value.</param>
        /// <param name="secondPaymentDays">secondPaymentDays.</param>
        public SplitPayment(
            Models.DepositTypeEnum depositType,
            double mValue,
            int secondPaymentDays)
        {
            this.DepositType = depositType;
            this.MValue = mValue;
            this.SecondPaymentDays = secondPaymentDays;
        }

        /// <summary>
        /// First payment deposit type.
        /// </summary>
        [JsonProperty("depositType", ItemConverterType = typeof(StringEnumConverter))]
        public Models.DepositTypeEnum DepositType { get; set; }

        /// <summary>
        /// First payment value
        /// </summary>
        [JsonProperty("value")]
        public double MValue { get; set; }

        /// <summary>
        /// Number of days before check-in when second payment is required.
        /// </summary>
        [JsonProperty("secondPaymentDays")]
        public int SecondPaymentDays { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"SplitPayment : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is SplitPayment other &&
                this.DepositType.Equals(other.DepositType) &&
                this.MValue.Equals(other.MValue) &&
                this.SecondPaymentDays.Equals(other.SecondPaymentDays);
        }
        

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.DepositType = {this.DepositType}");
            toStringOutput.Add($"this.MValue = {this.MValue}");
            toStringOutput.Add($"this.SecondPaymentDays = {this.SecondPaymentDays}");
        }
    }
}