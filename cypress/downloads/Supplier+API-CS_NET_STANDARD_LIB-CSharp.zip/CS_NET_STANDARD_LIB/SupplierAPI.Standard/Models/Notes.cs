// <copyright file="Notes.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace SupplierAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using SupplierAPI.Standard;
    using SupplierAPI.Standard.Utilities;

    /// <summary>
    /// Notes.
    /// </summary>
    public class Notes
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="Notes"/> class.
        /// </summary>
        public Notes()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="Notes"/> class.
        /// </summary>
        /// <param name="description">description.</param>
        /// <param name="houseRules">houseRules.</param>
        /// <param name="finePrint">finePrint.</param>
        /// <param name="shortDescription">shortDescription.</param>
        /// <param name="name">name.</param>
        public Notes(
            Models.DescriptionTextModel description,
            Models.DescriptionTextModel houseRules = null,
            Models.DescriptionTextModel finePrint = null,
            Models.DescriptionTextModel shortDescription = null,
            Models.DescriptionTextModel name = null)
        {
            this.Description = description;
            this.HouseRules = houseRules;
            this.FinePrint = finePrint;
            this.ShortDescription = shortDescription;
            this.Name = name;
        }

        /// <summary>
        /// Model for any kind of description text in Property object
        /// </summary>
        [JsonProperty("description")]
        public Models.DescriptionTextModel Description { get; set; }

        /// <summary>
        /// Model for any kind of description text in Property object
        /// </summary>
        [JsonProperty("houseRules", NullValueHandling = NullValueHandling.Ignore)]
        public Models.DescriptionTextModel HouseRules { get; set; }

        /// <summary>
        /// Model for any kind of description text in Property object
        /// </summary>
        [JsonProperty("finePrint", NullValueHandling = NullValueHandling.Ignore)]
        public Models.DescriptionTextModel FinePrint { get; set; }

        /// <summary>
        /// Model for any kind of description text in Property object
        /// </summary>
        [JsonProperty("shortDescription", NullValueHandling = NullValueHandling.Ignore)]
        public Models.DescriptionTextModel ShortDescription { get; set; }

        /// <summary>
        /// Model for any kind of description text in Property object
        /// </summary>
        [JsonProperty("name", NullValueHandling = NullValueHandling.Ignore)]
        public Models.DescriptionTextModel Name { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"Notes : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is Notes other &&
                ((this.Description == null && other.Description == null) || (this.Description?.Equals(other.Description) == true)) &&
                ((this.HouseRules == null && other.HouseRules == null) || (this.HouseRules?.Equals(other.HouseRules) == true)) &&
                ((this.FinePrint == null && other.FinePrint == null) || (this.FinePrint?.Equals(other.FinePrint) == true)) &&
                ((this.ShortDescription == null && other.ShortDescription == null) || (this.ShortDescription?.Equals(other.ShortDescription) == true)) &&
                ((this.Name == null && other.Name == null) || (this.Name?.Equals(other.Name) == true));
        }
        

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.Description = {(this.Description == null ? "null" : this.Description.ToString())}");
            toStringOutput.Add($"this.HouseRules = {(this.HouseRules == null ? "null" : this.HouseRules.ToString())}");
            toStringOutput.Add($"this.FinePrint = {(this.FinePrint == null ? "null" : this.FinePrint.ToString())}");
            toStringOutput.Add($"this.ShortDescription = {(this.ShortDescription == null ? "null" : this.ShortDescription.ToString())}");
            toStringOutput.Add($"this.Name = {(this.Name == null ? "null" : this.Name.ToString())}");
        }
    }
}