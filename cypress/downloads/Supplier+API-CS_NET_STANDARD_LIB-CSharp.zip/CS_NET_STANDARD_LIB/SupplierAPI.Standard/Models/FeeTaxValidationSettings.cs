// <copyright file="FeeTaxValidationSettings.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace SupplierAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using SupplierAPI.Standard;
    using SupplierAPI.Standard.Utilities;

    /// <summary>
    /// FeeTaxValidationSettings.
    /// </summary>
    public class FeeTaxValidationSettings
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="FeeTaxValidationSettings"/> class.
        /// </summary>
        public FeeTaxValidationSettings()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="FeeTaxValidationSettings"/> class.
        /// </summary>
        /// <param name="validationSettings">validationSettings.</param>
        public FeeTaxValidationSettings(
            List<Models.FeeTaxMandatorySetting> validationSettings)
        {
            this.ValidationSettings = validationSettings;
        }

        /// <summary>
        /// Model
        /// </summary>
        [JsonProperty("validationSettings")]
        public List<Models.FeeTaxMandatorySetting> ValidationSettings { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"FeeTaxValidationSettings : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is FeeTaxValidationSettings other &&
                ((this.ValidationSettings == null && other.ValidationSettings == null) || (this.ValidationSettings?.Equals(other.ValidationSettings) == true));
        }
        

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.ValidationSettings = {(this.ValidationSettings == null ? "null" : $"[{string.Join(", ", this.ValidationSettings)} ]")}");
        }
    }
}