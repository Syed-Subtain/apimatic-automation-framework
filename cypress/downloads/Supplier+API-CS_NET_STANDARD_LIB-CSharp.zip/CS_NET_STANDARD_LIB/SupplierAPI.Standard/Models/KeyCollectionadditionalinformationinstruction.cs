// <copyright file="KeyCollectionadditionalinformationinstruction.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace SupplierAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using SupplierAPI.Standard;
    using SupplierAPI.Standard.Utilities;

    /// <summary>
    /// KeyCollectionadditionalinformationinstruction.
    /// </summary>
    public class KeyCollectionadditionalinformationinstruction
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="KeyCollectionadditionalinformationinstruction"/> class.
        /// </summary>
        public KeyCollectionadditionalinformationinstruction()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="KeyCollectionadditionalinformationinstruction"/> class.
        /// </summary>
        /// <param name="how">how.</param>
        /// <param name="when">when.</param>
        public KeyCollectionadditionalinformationinstruction(
            string how,
            string when)
        {
            this.How = how;
            this.When = when;
        }

        /// <summary>
        /// how key should be collected
        /// </summary>
        [JsonProperty("how")]
        public string How { get; set; }

        /// <summary>
        /// when key should be collected
        /// </summary>
        [JsonProperty("when")]
        public string When { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"KeyCollectionadditionalinformationinstruction : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is KeyCollectionadditionalinformationinstruction other &&
                ((this.How == null && other.How == null) || (this.How?.Equals(other.How) == true)) &&
                ((this.When == null && other.When == null) || (this.When?.Equals(other.When) == true));
        }
        

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.How = {(this.How == null ? "null" : this.How == string.Empty ? "" : this.How)}");
            toStringOutput.Add($"this.When = {(this.When == null ? "null" : this.When == string.Empty ? "" : this.When)}");
        }
    }
}