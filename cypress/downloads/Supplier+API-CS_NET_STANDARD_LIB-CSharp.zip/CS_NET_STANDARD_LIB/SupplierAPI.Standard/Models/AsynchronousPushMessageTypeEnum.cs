// <copyright file="AsynchronousPushMessageTypeEnum.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace SupplierAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Runtime.Serialization;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using SupplierAPI.Standard;
    using SupplierAPI.Standard.Utilities;

    /// <summary>
    /// AsynchronousPushMessageTypeEnum.
    /// </summary>
    [JsonConverter(typeof(StringEnumConverter))]
    public enum AsynchronousPushMessageTypeEnum
    {
        /// <summary>
        ///Validation type - will be sent after validation is done.
        /// BPVALIDATION.
        /// </summary>
        [EnumMember(Value = "BP_VALIDATION")]
        BPVALIDATION
    }
}