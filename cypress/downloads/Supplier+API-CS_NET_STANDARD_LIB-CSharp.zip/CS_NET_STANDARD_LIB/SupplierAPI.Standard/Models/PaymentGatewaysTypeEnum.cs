// <copyright file="PaymentGatewaysTypeEnum.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace SupplierAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Runtime.Serialization;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using SupplierAPI.Standard;
    using SupplierAPI.Standard.Utilities;

    /// <summary>
    /// PaymentGatewaysTypeEnum.
    /// </summary>
    [JsonConverter(typeof(StringEnumConverter))]
    public enum PaymentGatewaysTypeEnum
    {
        /// <summary>
        /// PAYPAL.
        /// </summary>
        [EnumMember(Value = "PAYPAL")]
        PAYPAL,

        /// <summary>
        /// AUTHORIZENET.
        /// </summary>
        [EnumMember(Value = "AUTHORIZE_NET")]
        AUTHORIZENET,

        /// <summary>
        /// BRIDGEPAY.
        /// </summary>
        [EnumMember(Value = "BRIDGE_PAY")]
        BRIDGEPAY,

        /// <summary>
        /// PAYBOX.
        /// </summary>
        [EnumMember(Value = "PAY_BOX")]
        PAYBOX,

        /// <summary>
        /// DIBS.
        /// </summary>
        [EnumMember(Value = "DIBS")]
        DIBS,

        /// <summary>
        /// OGONE.
        /// </summary>
        [EnumMember(Value = "O_GONE")]
        OGONE,

        /// <summary>
        /// DOCDATA.
        /// </summary>
        [EnumMember(Value = "DOC_DATA")]
        DOCDATA,

        /// <summary>
        /// PAYGATE.
        /// </summary>
        [EnumMember(Value = "PAY_GATE")]
        PAYGATE
    }
}