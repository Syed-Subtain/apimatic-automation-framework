// <copyright file="InternetPolicy.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace SupplierAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using SupplierAPI.Standard;
    using SupplierAPI.Standard.Utilities;

    /// <summary>
    /// InternetPolicy.
    /// </summary>
    public class InternetPolicy
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="InternetPolicy"/> class.
        /// </summary>
        public InternetPolicy()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="InternetPolicy"/> class.
        /// </summary>
        /// <param name="accessInternet">accessInternet.</param>
        /// <param name="kindOfInternet">kindOfInternet.</param>
        /// <param name="availableInternet">availableInternet.</param>
        /// <param name="chargeInternet">chargeInternet.</param>
        public InternetPolicy(
            bool accessInternet,
            Models.KindOfInternetTypeEnum? kindOfInternet = null,
            Models.AvailableInternetEnum? availableInternet = null,
            string chargeInternet = null)
        {
            this.AccessInternet = accessInternet;
            this.KindOfInternet = kindOfInternet;
            this.AvailableInternet = availableInternet;
            this.ChargeInternet = chargeInternet;
        }

        /// <summary>
        /// Access internet into properties
        /// </summary>
        [JsonProperty("accessInternet")]
        public bool AccessInternet { get; set; }

        /// <summary>
        /// Gets or sets KindOfInternet.
        /// </summary>
        [JsonProperty("kindOfInternet", ItemConverterType = typeof(StringEnumConverter), NullValueHandling = NullValueHandling.Ignore)]
        public Models.KindOfInternetTypeEnum? KindOfInternet { get; set; }

        /// <summary>
        /// Gets or sets AvailableInternet.
        /// </summary>
        [JsonProperty("availableInternet", ItemConverterType = typeof(StringEnumConverter), NullValueHandling = NullValueHandling.Ignore)]
        public Models.AvailableInternetEnum? AvailableInternet { get; set; }

        /// <summary>
        /// Charge internet. Example: “Free”, “$ 100”.
        /// </summary>
        [JsonProperty("chargeInternet", NullValueHandling = NullValueHandling.Ignore)]
        public string ChargeInternet { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"InternetPolicy : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is InternetPolicy other &&
                this.AccessInternet.Equals(other.AccessInternet) &&
                ((this.KindOfInternet == null && other.KindOfInternet == null) || (this.KindOfInternet?.Equals(other.KindOfInternet) == true)) &&
                ((this.AvailableInternet == null && other.AvailableInternet == null) || (this.AvailableInternet?.Equals(other.AvailableInternet) == true)) &&
                ((this.ChargeInternet == null && other.ChargeInternet == null) || (this.ChargeInternet?.Equals(other.ChargeInternet) == true));
        }
        

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.AccessInternet = {this.AccessInternet}");
            toStringOutput.Add($"this.KindOfInternet = {(this.KindOfInternet == null ? "null" : this.KindOfInternet.ToString())}");
            toStringOutput.Add($"this.AvailableInternet = {(this.AvailableInternet == null ? "null" : this.AvailableInternet.ToString())}");
            toStringOutput.Add($"this.ChargeInternet = {(this.ChargeInternet == null ? "null" : this.ChargeInternet == string.Empty ? "" : this.ChargeInternet)}");
        }
    }
}