// <copyright file="ChannelABBEnum.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace SupplierAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Runtime.Serialization;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using SupplierAPI.Standard;
    using SupplierAPI.Standard.Utilities;

    /// <summary>
    /// ChannelABBEnum.
    /// </summary>
    [JsonConverter(typeof(StringEnumConverter))]
    public enum ChannelABBEnum
    {
        /// <summary>
        /// BKG.
        /// </summary>
        [EnumMember(Value = "BKG")]
        BKG,

        /// <summary>
        /// ABB.
        /// </summary>
        [EnumMember(Value = "ABB")]
        ABB,

        /// <summary>
        /// EXP.
        /// </summary>
        [EnumMember(Value = "EXP")]
        EXP,

        /// <summary>
        /// EXPHC.
        /// </summary>
        [EnumMember(Value = "EXP_HC")]
        EXPHC,

        /// <summary>
        /// HAC.
        /// </summary>
        [EnumMember(Value = "HAC")]
        HAC
    }
}