// <copyright file="AllowedPetsTypeEnum.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace SupplierAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Runtime.Serialization;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using SupplierAPI.Standard;
    using SupplierAPI.Standard.Utilities;

    /// <summary>
    /// AllowedPetsTypeEnum.
    /// </summary>
    [JsonConverter(typeof(StringEnumConverter))]
    public enum AllowedPetsTypeEnum
    {
        /// <summary>
        /// Allowed.
        /// </summary>
        [EnumMember(Value = "Allowed")]
        Allowed,

        /// <summary>
        /// AllowedOnRequest.
        /// </summary>
        [EnumMember(Value = "AllowedOnRequest")]
        AllowedOnRequest,

        /// <summary>
        /// NotAllowed.
        /// </summary>
        [EnumMember(Value = "NotAllowed")]
        NotAllowed
    }
}