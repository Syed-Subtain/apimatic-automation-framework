// <copyright file="ThreadsModel.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace SupplierAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using SupplierAPI.Standard;
    using SupplierAPI.Standard.Utilities;

    /// <summary>
    /// ThreadsModel.
    /// </summary>
    public class ThreadsModel
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ThreadsModel"/> class.
        /// </summary>
        public ThreadsModel()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ThreadsModel"/> class.
        /// </summary>
        /// <param name="threads">threads.</param>
        public ThreadsModel(
            List<Models.Thread> threads)
        {
            this.Threads = threads;
        }

        /// <summary>
        /// List of models
        /// </summary>
        [JsonProperty("threads")]
        public List<Models.Thread> Threads { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"ThreadsModel : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is ThreadsModel other &&
                ((this.Threads == null && other.Threads == null) || (this.Threads?.Equals(other.Threads) == true));
        }
        

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.Threads = {(this.Threads == null ? "null" : $"[{string.Join(", ", this.Threads)} ]")}");
        }
    }
}