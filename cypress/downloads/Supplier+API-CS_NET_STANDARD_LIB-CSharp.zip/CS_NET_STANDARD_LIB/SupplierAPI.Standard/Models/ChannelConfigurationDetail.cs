// <copyright file="ChannelConfigurationDetail.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace SupplierAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using SupplierAPI.Standard;
    using SupplierAPI.Standard.Utilities;

    /// <summary>
    /// ChannelConfigurationDetail.
    /// </summary>
    public class ChannelConfigurationDetail
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ChannelConfigurationDetail"/> class.
        /// </summary>
        public ChannelConfigurationDetail()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ChannelConfigurationDetail"/> class.
        /// </summary>
        /// <param name="name">name.</param>
        /// <param name="abbreviation">abbreviation.</param>
        /// <param name="logo">logo.</param>
        /// <param name="state">state.</param>
        /// <param name="supportValidation">supportValidation.</param>
        /// <param name="supportCreate">supportCreate.</param>
        /// <param name="supportConnect">supportConnect.</param>
        /// <param name="supportOpenClose">supportOpenClose.</param>
        /// <param name="supportStaticUpdate">supportStaticUpdate.</param>
        /// <param name="supportDynamicUpdate">supportDynamicUpdate.</param>
        /// <param name="supportSynchronization">supportSynchronization.</param>
        /// <param name="supportCreateChannelAccount">supportCreateChannelAccount.</param>
        /// <param name="supportAuthorization">supportAuthorization.</param>
        /// <param name="supportCancelFormPm">supportCancelFormPm.</param>
        /// <param name="supportModificationFromPm">supportModificationFromPm.</param>
        /// <param name="supportGather">supportGather.</param>
        /// <param name="supportChannelCancellationPolicy">supportChannelCancellationPolicy.</param>
        /// <param name="bookingType">bookingType.</param>
        /// <param name="ratesAndAvailabilityMapping">ratesAndAvailabilityMapping.</param>
        /// <param name="acceptsPropertyType">acceptsPropertyType.</param>
        /// <param name="nativePropertyType">nativePropertyType.</param>
        /// <param name="minimumProperties">minimumProperties.</param>
        public ChannelConfigurationDetail(
            string name = null,
            string abbreviation = null,
            string logo = null,
            Models.StateEnum? state = null,
            bool? supportValidation = null,
            bool? supportCreate = null,
            bool? supportConnect = null,
            bool? supportOpenClose = null,
            bool? supportStaticUpdate = null,
            bool? supportDynamicUpdate = null,
            bool? supportSynchronization = null,
            bool? supportCreateChannelAccount = null,
            bool? supportAuthorization = null,
            bool? supportCancelFormPm = null,
            bool? supportModificationFromPm = null,
            bool? supportGather = null,
            bool? supportChannelCancellationPolicy = null,
            Models.BookingTypeEnum? bookingType = null,
            Models.RatesAndAvailabilityMappingEnum? ratesAndAvailabilityMapping = null,
            Models.AcceptsPropertyTypeEnum? acceptsPropertyType = null,
            Models.NativePropertyTypeEnum? nativePropertyType = null,
            int? minimumProperties = null)
        {
            this.Name = name;
            this.Abbreviation = abbreviation;
            this.Logo = logo;
            this.State = state;
            this.SupportValidation = supportValidation;
            this.SupportCreate = supportCreate;
            this.SupportConnect = supportConnect;
            this.SupportOpenClose = supportOpenClose;
            this.SupportStaticUpdate = supportStaticUpdate;
            this.SupportDynamicUpdate = supportDynamicUpdate;
            this.SupportSynchronization = supportSynchronization;
            this.SupportCreateChannelAccount = supportCreateChannelAccount;
            this.SupportAuthorization = supportAuthorization;
            this.SupportCancelFormPm = supportCancelFormPm;
            this.SupportModificationFromPm = supportModificationFromPm;
            this.SupportGather = supportGather;
            this.SupportChannelCancellationPolicy = supportChannelCancellationPolicy;
            this.BookingType = bookingType;
            this.RatesAndAvailabilityMapping = ratesAndAvailabilityMapping;
            this.AcceptsPropertyType = acceptsPropertyType;
            this.NativePropertyType = nativePropertyType;
            this.MinimumProperties = minimumProperties;
        }

        /// <summary>
        /// Channel name
        /// </summary>
        [JsonProperty("name", NullValueHandling = NullValueHandling.Ignore)]
        public string Name { get; set; }

        /// <summary>
        /// Channel abbreviation
        /// </summary>
        [JsonProperty("abbreviation", NullValueHandling = NullValueHandling.Ignore)]
        public string Abbreviation { get; set; }

        /// <summary>
        /// Channel logo
        /// </summary>
        [JsonProperty("logo", NullValueHandling = NullValueHandling.Ignore)]
        public string Logo { get; set; }

        /// <summary>
        /// Channel State
        /// </summary>
        [JsonProperty("state", ItemConverterType = typeof(StringEnumConverter), NullValueHandling = NullValueHandling.Ignore)]
        public Models.StateEnum? State { get; set; }

        /// <summary>
        /// Channel support validation
        /// </summary>
        [JsonProperty("supportValidation", NullValueHandling = NullValueHandling.Ignore)]
        public bool? SupportValidation { get; set; }

        /// <summary>
        /// Channel support create
        /// </summary>
        [JsonProperty("supportCreate", NullValueHandling = NullValueHandling.Ignore)]
        public bool? SupportCreate { get; set; }

        /// <summary>
        /// Channel support connect
        /// </summary>
        [JsonProperty("supportConnect", NullValueHandling = NullValueHandling.Ignore)]
        public bool? SupportConnect { get; set; }

        /// <summary>
        /// Channel support open close
        /// </summary>
        [JsonProperty("supportOpenClose", NullValueHandling = NullValueHandling.Ignore)]
        public bool? SupportOpenClose { get; set; }

        /// <summary>
        /// Channel support Static Update
        /// </summary>
        [JsonProperty("supportStaticUpdate", NullValueHandling = NullValueHandling.Ignore)]
        public bool? SupportStaticUpdate { get; set; }

        /// <summary>
        /// Channel support Dynamic Update
        /// </summary>
        [JsonProperty("supportDynamicUpdate", NullValueHandling = NullValueHandling.Ignore)]
        public bool? SupportDynamicUpdate { get; set; }

        /// <summary>
        /// Channel support Synchronization
        /// </summary>
        [JsonProperty("supportSynchronization", NullValueHandling = NullValueHandling.Ignore)]
        public bool? SupportSynchronization { get; set; }

        /// <summary>
        /// Channel support Create Channel Account
        /// </summary>
        [JsonProperty("supportCreateChannelAccount", NullValueHandling = NullValueHandling.Ignore)]
        public bool? SupportCreateChannelAccount { get; set; }

        /// <summary>
        /// Channel support Authorization
        /// </summary>
        [JsonProperty("supportAuthorization", NullValueHandling = NullValueHandling.Ignore)]
        public bool? SupportAuthorization { get; set; }

        /// <summary>
        /// Support cancel Reservation form Property Manager
        /// </summary>
        [JsonProperty("supportCancelFormPm", NullValueHandling = NullValueHandling.Ignore)]
        public bool? SupportCancelFormPm { get; set; }

        /// <summary>
        /// Support modification Reservation from Property Manager
        /// </summary>
        [JsonProperty("supportModificationFromPm", NullValueHandling = NullValueHandling.Ignore)]
        public bool? SupportModificationFromPm { get; set; }

        /// <summary>
        /// Channel support Gather
        /// </summary>
        [JsonProperty("supportGather", NullValueHandling = NullValueHandling.Ignore)]
        public bool? SupportGather { get; set; }

        /// <summary>
        /// Channel support Channel Cancellation Policy
        /// </summary>
        [JsonProperty("supportChannelCancellationPolicy", NullValueHandling = NullValueHandling.Ignore)]
        public bool? SupportChannelCancellationPolicy { get; set; }

        /// <summary>
        /// Channel booking Type
        /// </summary>
        [JsonProperty("bookingType", ItemConverterType = typeof(StringEnumConverter), NullValueHandling = NullValueHandling.Ignore)]
        public Models.BookingTypeEnum? BookingType { get; set; }

        /// <summary>
        /// Channel rates And Availability Mapping
        /// </summary>
        [JsonProperty("ratesAndAvailabilityMapping", ItemConverterType = typeof(StringEnumConverter), NullValueHandling = NullValueHandling.Ignore)]
        public Models.RatesAndAvailabilityMappingEnum? RatesAndAvailabilityMapping { get; set; }

        /// <summary>
        /// Channel accepts Property Type
        /// </summary>
        [JsonProperty("acceptsPropertyType", ItemConverterType = typeof(StringEnumConverter), NullValueHandling = NullValueHandling.Ignore)]
        public Models.AcceptsPropertyTypeEnum? AcceptsPropertyType { get; set; }

        /// <summary>
        /// Channel native Property Type
        /// </summary>
        [JsonProperty("nativePropertyType", ItemConverterType = typeof(StringEnumConverter), NullValueHandling = NullValueHandling.Ignore)]
        public Models.NativePropertyTypeEnum? NativePropertyType { get; set; }

        /// <summary>
        /// Channel minimum Properties
        /// </summary>
        [JsonProperty("minimumProperties", NullValueHandling = NullValueHandling.Ignore)]
        public int? MinimumProperties { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"ChannelConfigurationDetail : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is ChannelConfigurationDetail other &&
                ((this.Name == null && other.Name == null) || (this.Name?.Equals(other.Name) == true)) &&
                ((this.Abbreviation == null && other.Abbreviation == null) || (this.Abbreviation?.Equals(other.Abbreviation) == true)) &&
                ((this.Logo == null && other.Logo == null) || (this.Logo?.Equals(other.Logo) == true)) &&
                ((this.State == null && other.State == null) || (this.State?.Equals(other.State) == true)) &&
                ((this.SupportValidation == null && other.SupportValidation == null) || (this.SupportValidation?.Equals(other.SupportValidation) == true)) &&
                ((this.SupportCreate == null && other.SupportCreate == null) || (this.SupportCreate?.Equals(other.SupportCreate) == true)) &&
                ((this.SupportConnect == null && other.SupportConnect == null) || (this.SupportConnect?.Equals(other.SupportConnect) == true)) &&
                ((this.SupportOpenClose == null && other.SupportOpenClose == null) || (this.SupportOpenClose?.Equals(other.SupportOpenClose) == true)) &&
                ((this.SupportStaticUpdate == null && other.SupportStaticUpdate == null) || (this.SupportStaticUpdate?.Equals(other.SupportStaticUpdate) == true)) &&
                ((this.SupportDynamicUpdate == null && other.SupportDynamicUpdate == null) || (this.SupportDynamicUpdate?.Equals(other.SupportDynamicUpdate) == true)) &&
                ((this.SupportSynchronization == null && other.SupportSynchronization == null) || (this.SupportSynchronization?.Equals(other.SupportSynchronization) == true)) &&
                ((this.SupportCreateChannelAccount == null && other.SupportCreateChannelAccount == null) || (this.SupportCreateChannelAccount?.Equals(other.SupportCreateChannelAccount) == true)) &&
                ((this.SupportAuthorization == null && other.SupportAuthorization == null) || (this.SupportAuthorization?.Equals(other.SupportAuthorization) == true)) &&
                ((this.SupportCancelFormPm == null && other.SupportCancelFormPm == null) || (this.SupportCancelFormPm?.Equals(other.SupportCancelFormPm) == true)) &&
                ((this.SupportModificationFromPm == null && other.SupportModificationFromPm == null) || (this.SupportModificationFromPm?.Equals(other.SupportModificationFromPm) == true)) &&
                ((this.SupportGather == null && other.SupportGather == null) || (this.SupportGather?.Equals(other.SupportGather) == true)) &&
                ((this.SupportChannelCancellationPolicy == null && other.SupportChannelCancellationPolicy == null) || (this.SupportChannelCancellationPolicy?.Equals(other.SupportChannelCancellationPolicy) == true)) &&
                ((this.BookingType == null && other.BookingType == null) || (this.BookingType?.Equals(other.BookingType) == true)) &&
                ((this.RatesAndAvailabilityMapping == null && other.RatesAndAvailabilityMapping == null) || (this.RatesAndAvailabilityMapping?.Equals(other.RatesAndAvailabilityMapping) == true)) &&
                ((this.AcceptsPropertyType == null && other.AcceptsPropertyType == null) || (this.AcceptsPropertyType?.Equals(other.AcceptsPropertyType) == true)) &&
                ((this.NativePropertyType == null && other.NativePropertyType == null) || (this.NativePropertyType?.Equals(other.NativePropertyType) == true)) &&
                ((this.MinimumProperties == null && other.MinimumProperties == null) || (this.MinimumProperties?.Equals(other.MinimumProperties) == true));
        }
        

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.Name = {(this.Name == null ? "null" : this.Name == string.Empty ? "" : this.Name)}");
            toStringOutput.Add($"this.Abbreviation = {(this.Abbreviation == null ? "null" : this.Abbreviation == string.Empty ? "" : this.Abbreviation)}");
            toStringOutput.Add($"this.Logo = {(this.Logo == null ? "null" : this.Logo == string.Empty ? "" : this.Logo)}");
            toStringOutput.Add($"this.State = {(this.State == null ? "null" : this.State.ToString())}");
            toStringOutput.Add($"this.SupportValidation = {(this.SupportValidation == null ? "null" : this.SupportValidation.ToString())}");
            toStringOutput.Add($"this.SupportCreate = {(this.SupportCreate == null ? "null" : this.SupportCreate.ToString())}");
            toStringOutput.Add($"this.SupportConnect = {(this.SupportConnect == null ? "null" : this.SupportConnect.ToString())}");
            toStringOutput.Add($"this.SupportOpenClose = {(this.SupportOpenClose == null ? "null" : this.SupportOpenClose.ToString())}");
            toStringOutput.Add($"this.SupportStaticUpdate = {(this.SupportStaticUpdate == null ? "null" : this.SupportStaticUpdate.ToString())}");
            toStringOutput.Add($"this.SupportDynamicUpdate = {(this.SupportDynamicUpdate == null ? "null" : this.SupportDynamicUpdate.ToString())}");
            toStringOutput.Add($"this.SupportSynchronization = {(this.SupportSynchronization == null ? "null" : this.SupportSynchronization.ToString())}");
            toStringOutput.Add($"this.SupportCreateChannelAccount = {(this.SupportCreateChannelAccount == null ? "null" : this.SupportCreateChannelAccount.ToString())}");
            toStringOutput.Add($"this.SupportAuthorization = {(this.SupportAuthorization == null ? "null" : this.SupportAuthorization.ToString())}");
            toStringOutput.Add($"this.SupportCancelFormPm = {(this.SupportCancelFormPm == null ? "null" : this.SupportCancelFormPm.ToString())}");
            toStringOutput.Add($"this.SupportModificationFromPm = {(this.SupportModificationFromPm == null ? "null" : this.SupportModificationFromPm.ToString())}");
            toStringOutput.Add($"this.SupportGather = {(this.SupportGather == null ? "null" : this.SupportGather.ToString())}");
            toStringOutput.Add($"this.SupportChannelCancellationPolicy = {(this.SupportChannelCancellationPolicy == null ? "null" : this.SupportChannelCancellationPolicy.ToString())}");
            toStringOutput.Add($"this.BookingType = {(this.BookingType == null ? "null" : this.BookingType.ToString())}");
            toStringOutput.Add($"this.RatesAndAvailabilityMapping = {(this.RatesAndAvailabilityMapping == null ? "null" : this.RatesAndAvailabilityMapping.ToString())}");
            toStringOutput.Add($"this.AcceptsPropertyType = {(this.AcceptsPropertyType == null ? "null" : this.AcceptsPropertyType.ToString())}");
            toStringOutput.Add($"this.NativePropertyType = {(this.NativePropertyType == null ? "null" : this.NativePropertyType.ToString())}");
            toStringOutput.Add($"this.MinimumProperties = {(this.MinimumProperties == null ? "null" : this.MinimumProperties.ToString())}");
        }
    }
}