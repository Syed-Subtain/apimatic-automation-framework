// <copyright file="AmenityTypesEnum.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace SupplierAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Runtime.Serialization;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using SupplierAPI.Standard;
    using SupplierAPI.Standard.Utilities;

    /// <summary>
    /// AmenityTypesEnum.
    /// </summary>
    [JsonConverter(typeof(StringEnumConverter))]
    public enum AmenityTypesEnum
    {
        /// <summary>
        ///Arboretum
        /// ACC111.
        /// </summary>
        [EnumMember(Value = "ACC111")]
        ACC111,

        /// <summary>
        ///Autumn foliage
        /// ACC112.
        /// </summary>
        [EnumMember(Value = "ACC112")]
        ACC112,

        /// <summary>
        ///Cave
        /// ACC113.
        /// </summary>
        [EnumMember(Value = "ACC113")]
        ACC113,

        /// <summary>
        ///Duty Free
        /// ACC114.
        /// </summary>
        [EnumMember(Value = "ACC114")]
        ACC114,

        /// <summary>
        ///Nude beach
        /// ACC115.
        /// </summary>
        [EnumMember(Value = "ACC115")]
        ACC115,

        /// <summary>
        ///Rain forest
        /// ACC116.
        /// </summary>
        [EnumMember(Value = "ACC116")]
        ACC116,

        /// <summary>
        ///Reef
        /// ACC117.
        /// </summary>
        [EnumMember(Value = "ACC117")]
        ACC117,

        /// <summary>
        ///Ruins
        /// ACC118.
        /// </summary>
        [EnumMember(Value = "ACC118")]
        ACC118,

        /// <summary>
        ///Outdoor lanai gazebo covered
        /// ACC119.
        /// </summary>
        [EnumMember(Value = "ACC119")]
        ACC119,

        /// <summary>
        ///Volcano
        /// ACC120.
        /// </summary>
        [EnumMember(Value = "ACC120")]
        ACC120,

        /// <summary>
        ///Rural
        /// ACC123.
        /// </summary>
        [EnumMember(Value = "ACC123")]
        ACC123,

        /// <summary>
        ///Church
        /// ACC14.
        /// </summary>
        [EnumMember(Value = "ACC14")]
        ACC14,

        /// <summary>
        ///Hospital
        /// ACC24.
        /// </summary>
        [EnumMember(Value = "ACC24")]
        ACC24,

        /// <summary>
        ///Lake
        /// ACC25.
        /// </summary>
        [EnumMember(Value = "ACC25")]
        ACC25,

        /// <summary>
        ///Library
        /// ACC27.
        /// </summary>
        [EnumMember(Value = "ACC27")]
        ACC27,

        /// <summary>
        ///Marina
        /// ACC28.
        /// </summary>
        [EnumMember(Value = "ACC28")]
        ACC28,

        /// <summary>
        ///Market
        /// ACC29.
        /// </summary>
        [EnumMember(Value = "ACC29")]
        ACC29,

        /// <summary>
        ///Mountain
        /// ACC31.
        /// </summary>
        [EnumMember(Value = "ACC31")]
        ACC31,

        /// <summary>
        ///Museum
        /// ACC32.
        /// </summary>
        [EnumMember(Value = "ACC32")]
        ACC32,

        /// <summary>
        ///Ocean
        /// ACC33.
        /// </summary>
        [EnumMember(Value = "ACC33")]
        ACC33,

        /// <summary>
        ///Recreation center
        /// ACC39.
        /// </summary>
        [EnumMember(Value = "ACC39")]
        ACC39,

        /// <summary>
        ///Resort
        /// ACC40.
        /// </summary>
        [EnumMember(Value = "ACC40")]
        ACC40,

        /// <summary>
        ///Restaurant
        /// ACC41.
        /// </summary>
        [EnumMember(Value = "ACC41")]
        ACC41,

        /// <summary>
        ///River
        /// ACC42.
        /// </summary>
        [EnumMember(Value = "ACC42")]
        ACC42,

        /// <summary>
        ///Ski area
        /// ACC45.
        /// </summary>
        [EnumMember(Value = "ACC45")]
        ACC45,

        /// <summary>
        ///Store
        /// ACC47.
        /// </summary>
        [EnumMember(Value = "ACC47")]
        ACC47,

        /// <summary>
        ///Beach
        /// ACC5.
        /// </summary>
        [EnumMember(Value = "ACC5")]
        ACC5,

        /// <summary>
        ///Movie Theater
        /// ACC50.
        /// </summary>
        [EnumMember(Value = "ACC50")]
        ACC50,

        /// <summary>
        ///Water park
        /// ACC54.
        /// </summary>
        [EnumMember(Value = "ACC54")]
        ACC54,

        /// <summary>
        ///Waterfront
        /// ACC55.
        /// </summary>
        [EnumMember(Value = "ACC55")]
        ACC55,

        /// <summary>
        ///Winery
        /// ACC56.
        /// </summary>
        [EnumMember(Value = "ACC56")]
        ACC56,

        /// <summary>
        ///Zoo
        /// ACC57.
        /// </summary>
        [EnumMember(Value = "ACC57")]
        ACC57,

        /// <summary>
        ///Festival
        /// ACC59.
        /// </summary>
        [EnumMember(Value = "ACC59")]
        ACC59,

        /// <summary>
        ///Bar
        /// ACC73.
        /// </summary>
        [EnumMember(Value = "ACC73")]
        ACC73,

        /// <summary>
        ///Bay
        /// ACC74.
        /// </summary>
        [EnumMember(Value = "ACC74")]
        ACC74,

        /// <summary>
        ///Synagogue
        /// ACC82.
        /// </summary>
        [EnumMember(Value = "ACC82")]
        ACC82,

        /// <summary>
        ///Botanical garden
        /// ACC90.
        /// </summary>
        [EnumMember(Value = "ACC90")]
        ACC90,

        /// <summary>
        ///Natural attraction
        /// ACC95.
        /// </summary>
        [EnumMember(Value = "ACC95")]
        ACC95,

        /// <summary>
        ///24 Hour Reception Desk
        /// HAC1.
        /// </summary>
        [EnumMember(Value = "HAC1")]
        HAC1,

        /// <summary>
        ///Wheelchair access
        /// HAC101.
        /// </summary>
        [EnumMember(Value = "HAC101")]
        HAC101,

        /// <summary>
        ///Accessible parking
        /// HAC116.
        /// </summary>
        [EnumMember(Value = "HAC116")]
        HAC116,

        /// <summary>
        ///Shops and commercial services
        /// HAC122.
        /// </summary>
        [EnumMember(Value = "HAC122")]
        HAC122,

        /// <summary>
        ///Business library
        /// HAC14.
        /// </summary>
        [EnumMember(Value = "HAC14")]
        HAC14,

        /// <summary>
        ///Grocery shopping service available
        /// HAC149.
        /// </summary>
        [EnumMember(Value = "HAC149")]
        HAC149,

        /// <summary>
        ///Car rental desk
        /// HAC15.
        /// </summary>
        [EnumMember(Value = "HAC15")]
        HAC15,

        /// <summary>
        ///Medical Facilities Service
        /// HAC154.
        /// </summary>
        [EnumMember(Value = "HAC154")]
        HAC154,

        /// <summary>
        ///All-inclusive meal plan
        /// HAC156.
        /// </summary>
        [EnumMember(Value = "HAC156")]
        HAC156,

        /// <summary>
        ///Buffet breakfast
        /// HAC157.
        /// </summary>
        [EnumMember(Value = "HAC157")]
        HAC157,

        /// <summary>
        ///Continental breakfast
        /// HAC159.
        /// </summary>
        [EnumMember(Value = "HAC159")]
        HAC159,

        /// <summary>
        ///Casino
        /// HAC16.
        /// </summary>
        [EnumMember(Value = "HAC16")]
        HAC16,

        /// <summary>
        ///Full meal plan
        /// HAC160.
        /// </summary>
        [EnumMember(Value = "HAC160")]
        HAC160,

        /// <summary>
        ///Lounges/bars
        /// HAC165.
        /// </summary>
        [EnumMember(Value = "HAC165")]
        HAC165,

        /// <summary>
        ///Onsite laundry
        /// HAC168.
        /// </summary>
        [EnumMember(Value = "HAC168")]
        HAC168,

        /// <summary>
        ///Breakfast served in restaurant
        /// HAC173.
        /// </summary>
        [EnumMember(Value = "HAC173")]
        HAC173,

        /// <summary>
        ///Full service housekeeping
        /// HAC176.
        /// </summary>
        [EnumMember(Value = "HAC176")]
        HAC176,

        /// <summary>
        ///Street side parking
        /// HAC186.
        /// </summary>
        [EnumMember(Value = "HAC186")]
        HAC186,

        /// <summary>
        ///Children's play area
        /// HAC193.
        /// </summary>
        [EnumMember(Value = "HAC193")]
        HAC193,

        /// <summary>
        ///Disco
        /// HAC195.
        /// </summary>
        [EnumMember(Value = "HAC195")]
        HAC195,

        /// <summary>
        ///Early check-in
        /// HAC196.
        /// </summary>
        [EnumMember(Value = "HAC196")]
        HAC196,

        /// <summary>
        ///Locker room
        /// HAC197.
        /// </summary>
        [EnumMember(Value = "HAC197")]
        HAC197,

        /// <summary>
        ///Non-smoking rooms (generic)
        /// HAC198.
        /// </summary>
        [EnumMember(Value = "HAC198")]
        HAC198,

        /// <summary>
        ///Bicycle rentals
        /// HAC202.
        /// </summary>
        [EnumMember(Value = "HAC202")]
        HAC202,

        /// <summary>
        ///Late check-out available
        /// HAC204.
        /// </summary>
        [EnumMember(Value = "HAC204")]
        HAC204,

        /// <summary>
        ///Coin operated laundry
        /// HAC21.
        /// </summary>
        [EnumMember(Value = "HAC21")]
        HAC21,

        /// <summary>
        ///Concierge desk
        /// HAC22.
        /// </summary>
        [EnumMember(Value = "HAC22")]
        HAC22,

        /// <summary>
        ///Catering services
        /// HAC226.
        /// </summary>
        [EnumMember(Value = "HAC226")]
        HAC226,

        /// <summary>
        ///Business center
        /// HAC228.
        /// </summary>
        [EnumMember(Value = "HAC228")]
        HAC228,

        /// <summary>
        ///Secured parking
        /// HAC230.
        /// </summary>
        [EnumMember(Value = "HAC230")]
        HAC230,

        /// <summary>
        ///Racquetball
        /// HAC231.
        /// </summary>
        [EnumMember(Value = "HAC231")]
        HAC231,

        /// <summary>
        ///Snow sports
        /// HAC232.
        /// </summary>
        [EnumMember(Value = "HAC232")]
        HAC232,

        /// <summary>
        ///Tennis court
        /// HAC233.
        /// </summary>
        [EnumMember(Value = "HAC233")]
        HAC233,

        /// <summary>
        ///Water sports
        /// HAC234.
        /// </summary>
        [EnumMember(Value = "HAC234")]
        HAC234,

        /// <summary>
        ///Golf
        /// HAC236.
        /// </summary>
        [EnumMember(Value = "HAC236")]
        HAC236,

        /// <summary>
        ///Horseback riding
        /// HAC237.
        /// </summary>
        [EnumMember(Value = "HAC237")]
        HAC237,

        /// <summary>
        ///Oceanfront
        /// HAC238.
        /// </summary>
        [EnumMember(Value = "HAC238")]
        HAC238,

        /// <summary>
        ///Beachfront
        /// HAC239.
        /// </summary>
        [EnumMember(Value = "HAC239")]
        HAC239,

        /// <summary>
        ///Ironing board
        /// HAC241.
        /// </summary>
        [EnumMember(Value = "HAC241")]
        HAC241,

        /// <summary>
        ///Heated guest rooms
        /// HAC242.
        /// </summary>
        [EnumMember(Value = "HAC242")]
        HAC242,

        /// <summary>
        ///Thalassotherapy
        /// HAC246.
        /// </summary>
        [EnumMember(Value = "HAC246")]
        HAC246,

        /// <summary>
        ///Courtyard
        /// HAC25.
        /// </summary>
        [EnumMember(Value = "HAC25")]
        HAC25,

        /// <summary>
        ///Connecting rooms
        /// HAC254.
        /// </summary>
        [EnumMember(Value = "HAC254")]
        HAC254,

        /// <summary>
        ///Currency exchange
        /// HAC26.
        /// </summary>
        [EnumMember(Value = "HAC26")]
        HAC26,

        /// <summary>
        ///Kitchenette
        /// HAC262.
        /// </summary>
        [EnumMember(Value = "HAC262")]
        HAC262,

        /// <summary>
        ///Welcome drink
        /// HAC265.
        /// </summary>
        [EnumMember(Value = "HAC265")]
        HAC265,

        /// <summary>
        ///Meeting rooms
        /// HAC269.
        /// </summary>
        [EnumMember(Value = "HAC269")]
        HAC269,

        /// <summary>
        ///Snow skiing
        /// HAC272.
        /// </summary>
        [EnumMember(Value = "HAC272")]
        HAC272,

        /// <summary>
        ///Water skiing
        /// HAC273.
        /// </summary>
        [EnumMember(Value = "HAC273")]
        HAC273,

        /// <summary>
        ///Grocery store
        /// HAC280.
        /// </summary>
        [EnumMember(Value = "HAC280")]
        HAC280,

        /// <summary>
        ///Airport shuttle service
        /// HAC282.
        /// </summary>
        [EnumMember(Value = "HAC282")]
        HAC282,

        /// <summary>
        ///Luggage service
        /// HAC283.
        /// </summary>
        [EnumMember(Value = "HAC283")]
        HAC283,

        /// <summary>
        ///Door man
        /// HAC29.
        /// </summary>
        [EnumMember(Value = "HAC29")]
        HAC29,

        /// <summary>
        ///Newspaper
        /// HAC292.
        /// </summary>
        [EnumMember(Value = "HAC292")]
        HAC292,

        /// <summary>
        ///Food and beverage discount
        /// HAC301.
        /// </summary>
        [EnumMember(Value = "HAC301")]
        HAC301,

        /// <summary>
        ///Welcome gift
        /// HAC309.
        /// </summary>
        [EnumMember(Value = "HAC309")]
        HAC309,

        /// <summary>
        ///Hypoallergenic rooms
        /// HAC310.
        /// </summary>
        [EnumMember(Value = "HAC310")]
        HAC310,

        /// <summary>
        ///Smoke-free property
        /// HAC312.
        /// </summary>
        [EnumMember(Value = "HAC312")]
        HAC312,

        /// <summary>
        ///Electric car charging stations
        /// HAC316.
        /// </summary>
        [EnumMember(Value = "HAC316")]
        HAC316,

        /// <summary>
        ///Duty free shop
        /// HAC32.
        /// </summary>
        [EnumMember(Value = "HAC32")]
        HAC32,

        /// <summary>
        ///Events ticket service
        /// HAC327.
        /// </summary>
        [EnumMember(Value = "HAC327")]
        HAC327,

        /// <summary>
        ///Elevators
        /// HAC33.
        /// </summary>
        [EnumMember(Value = "HAC33")]
        HAC33,

        /// <summary>
        ///Summer terrace
        /// HAC334.
        /// </summary>
        [EnumMember(Value = "HAC334")]
        HAC334,

        /// <summary>
        ///Executive floor
        /// HAC34.
        /// </summary>
        [EnumMember(Value = "HAC34")]
        HAC34,

        /// <summary>
        ///Snack bar
        /// HAC342.
        /// </summary>
        [EnumMember(Value = "HAC342")]
        HAC342,

        /// <summary>
        ///Fitness center
        /// HAC345.
        /// </summary>
        [EnumMember(Value = "HAC345")]
        HAC345,

        /// <summary>
        ///Health and beauty services
        /// HAC348.
        /// </summary>
        [EnumMember(Value = "HAC348")]
        HAC348,

        /// <summary>
        ///Express check-in
        /// HAC36.
        /// </summary>
        [EnumMember(Value = "HAC36")]
        HAC36,

        /// <summary>
        ///Express check-out
        /// HAC37.
        /// </summary>
        [EnumMember(Value = "HAC37")]
        HAC37,

        /// <summary>
        ///Free airport shuttle
        /// HAC41.
        /// </summary>
        [EnumMember(Value = "HAC41")]
        HAC41,

        /// <summary>
        ///Free parking
        /// HAC42.
        /// </summary>
        [EnumMember(Value = "HAC42")]
        HAC42,

        /// <summary>
        ///Game room
        /// HAC44.
        /// </summary>
        [EnumMember(Value = "HAC44")]
        HAC44,

        /// <summary>
        ///Gift/News stand
        /// HAC45.
        /// </summary>
        [EnumMember(Value = "HAC45")]
        HAC45,

        /// <summary>
        ///Heated pool
        /// HAC49.
        /// </summary>
        [EnumMember(Value = "HAC49")]
        HAC49,

        /// <summary>
        ///Air conditioning
        /// HAC5.
        /// </summary>
        [EnumMember(Value = "HAC5")]
        HAC5,

        /// <summary>
        ///Housekeeping - daily
        /// HAC50.
        /// </summary>
        [EnumMember(Value = "HAC50")]
        HAC50,

        /// <summary>
        ///Ski Storage
        /// HAC5033.
        /// </summary>
        [EnumMember(Value = "HAC5033")]
        HAC5033,

        /// <summary>
        ///Housekeeping - weekly
        /// HAC51.
        /// </summary>
        [EnumMember(Value = "HAC51")]
        HAC51,

        /// <summary>
        ///Indoor parking
        /// HAC53.
        /// </summary>
        [EnumMember(Value = "HAC53")]
        HAC53,

        /// <summary>
        ///Indoor pool
        /// HAC54.
        /// </summary>
        [EnumMember(Value = "HAC54")]
        HAC54,

        /// <summary>
        ///Jacuzzi
        /// HAC55.
        /// </summary>
        [EnumMember(Value = "HAC55")]
        HAC55,

        /// <summary>
        ///Live entertainment
        /// HAC60.
        /// </summary>
        [EnumMember(Value = "HAC60")]
        HAC60,

        /// <summary>
        ///Chef Services
        /// HAC6002.
        /// </summary>
        [EnumMember(Value = "HAC6002")]
        HAC6002,

        /// <summary>
        ///Ski rental
        /// HAC6008.
        /// </summary>
        [EnumMember(Value = "HAC6008")]
        HAC6008,

        /// <summary>
        ///Child toddler seat
        /// HAC6010.
        /// </summary>
        [EnumMember(Value = "HAC6010")]
        HAC6010,

        /// <summary>
        ///Photographer
        /// HAC6013.
        /// </summary>
        [EnumMember(Value = "HAC6013")]
        HAC6013,

        /// <summary>
        ///Chauffeur/cars
        /// HAC6014.
        /// </summary>
        [EnumMember(Value = "HAC6014")]
        HAC6014,

        /// <summary>
        ///Soap/Shampoo
        /// HAC6019.
        /// </summary>
        [EnumMember(Value = "HAC6019")]
        HAC6019,

        /// <summary>
        ///Boat
        /// HAC6020.
        /// </summary>
        [EnumMember(Value = "HAC6020")]
        HAC6020,

        /// <summary>
        ///Self checkin
        /// HAC6024.
        /// </summary>
        [EnumMember(Value = "HAC6024")]
        HAC6024,

        /// <summary>
        ///pack-n-play
        /// HAC6025.
        /// </summary>
        [EnumMember(Value = "HAC6025")]
        HAC6025,

        /// <summary>
        ///Other services staff
        /// HAC6026.
        /// </summary>
        [EnumMember(Value = "HAC6026")]
        HAC6026,

        /// <summary>
        ///Games
        /// HAC6027.
        /// </summary>
        [EnumMember(Value = "HAC6027")]
        HAC6027,

        /// <summary>
        ///Petanque
        /// HAC6028.
        /// </summary>
        [EnumMember(Value = "HAC6028")]
        HAC6028,

        /// <summary>
        ///Car necessary
        /// HAC6029.
        /// </summary>
        [EnumMember(Value = "HAC6029")]
        HAC6029,

        /// <summary>
        ///Car not necessary
        /// HAC6030.
        /// </summary>
        [EnumMember(Value = "HAC6030")]
        HAC6030,

        /// <summary>
        ///Car recommended
        /// HAC6031.
        /// </summary>
        [EnumMember(Value = "HAC6031")]
        HAC6031,

        /// <summary>
        ///Synagogues
        /// HAC6032.
        /// </summary>
        [EnumMember(Value = "HAC6032")]
        HAC6032,

        /// <summary>
        ///EV charger
        /// HAC6033.
        /// </summary>
        [EnumMember(Value = "HAC6033")]
        HAC6033,

        /// <summary>
        ///Long term stays allowed
        /// HAC6034.
        /// </summary>
        [EnumMember(Value = "HAC6034")]
        HAC6034,

        /// <summary>
        ///Cleaning before checkout
        /// HAC6035.
        /// </summary>
        [EnumMember(Value = "HAC6035")]
        HAC6035,

        /// <summary>
        ///Beach essentials
        /// HAC6036.
        /// </summary>
        [EnumMember(Value = "HAC6036")]
        HAC6036,

        /// <summary>
        ///Wide hallway clearance
        /// HAC6037.
        /// </summary>
        [EnumMember(Value = "HAC6037")]
        HAC6037,

        /// <summary>
        ///Home step free access
        /// HAC6038.
        /// </summary>
        [EnumMember(Value = "HAC6038")]
        HAC6038,

        /// <summary>
        ///Path to entrance lit at night
        /// HAC6039.
        /// </summary>
        [EnumMember(Value = "HAC6039")]
        HAC6039,

        /// <summary>
        ///Home wide doorway
        /// HAC6040.
        /// </summary>
        [EnumMember(Value = "HAC6040")]
        HAC6040,

        /// <summary>
        ///Flat smooth pathway to front door
        /// HAC6041.
        /// </summary>
        [EnumMember(Value = "HAC6041")]
        HAC6041,

        /// <summary>
        ///Disabled parking spot
        /// HAC6042.
        /// </summary>
        [EnumMember(Value = "HAC6042")]
        HAC6042,

        /// <summary>
        ///HAC6043
        /// HAC6043.
        /// </summary>
        [EnumMember(Value = "HAC6043")]
        HAC6043,

        /// <summary>
        ///Cycling Trips
        /// HAC6044.
        /// </summary>
        [EnumMember(Value = "HAC6044")]
        HAC6044,

        /// <summary>
        ///Included housekeeping
        /// HAC6045.
        /// </summary>
        [EnumMember(Value = "HAC6045")]
        HAC6045,

        /// <summary>
        ///Staffed Property
        /// HAC6046.
        /// </summary>
        [EnumMember(Value = "HAC6046")]
        HAC6046,

        /// <summary>
        ///Near a train/subway station
        /// HAC6047.
        /// </summary>
        [EnumMember(Value = "HAC6047")]
        HAC6047,

        /// <summary>
        ///Nearby local nightlife
        /// HAC6048.
        /// </summary>
        [EnumMember(Value = "HAC6048")]
        HAC6048,

        /// <summary>
        ///Shared residential building
        /// HAC6049.
        /// </summary>
        [EnumMember(Value = "HAC6049")]
        HAC6049,

        /// <summary>
        ///24/7 Support
        /// HAC6050.
        /// </summary>
        [EnumMember(Value = "HAC6050")]
        HAC6050,

        /// <summary>
        ///Butler
        /// HAC6051.
        /// </summary>
        [EnumMember(Value = "HAC6051")]
        HAC6051,

        /// <summary>
        ///Concierge Services
        /// HAC6052.
        /// </summary>
        [EnumMember(Value = "HAC6052")]
        HAC6052,

        /// <summary>
        ///In-person Check-in
        /// HAC6053.
        /// </summary>
        [EnumMember(Value = "HAC6053")]
        HAC6053,

        /// <summary>
        ///Carbon Monoxide Detector + Smoke Detector
        /// HAC6054.
        /// </summary>
        [EnumMember(Value = "HAC6054")]
        HAC6054,

        /// <summary>
        ///Professionally Cleaned
        /// HAC6055.
        /// </summary>
        [EnumMember(Value = "HAC6055")]
        HAC6055,

        /// <summary>
        ///Accessible Parking: Indoor
        /// HAC6056.
        /// </summary>
        [EnumMember(Value = "HAC6056")]
        HAC6056,

        /// <summary>
        ///Accessible Parking: Indoor, 1 spot
        /// HAC6057.
        /// </summary>
        [EnumMember(Value = "HAC6057")]
        HAC6057,

        /// <summary>
        ///Accessible Parking: Indoor, 2 spots
        /// HAC6058.
        /// </summary>
        [EnumMember(Value = "HAC6058")]
        HAC6058,

        /// <summary>
        ///Accessible Parking: Outdoor
        /// HAC6059.
        /// </summary>
        [EnumMember(Value = "HAC6059")]
        HAC6059,

        /// <summary>
        ///Accessible Parking: Outdoor, 1 spot
        /// HAC6060.
        /// </summary>
        [EnumMember(Value = "HAC6060")]
        HAC6060,

        /// <summary>
        ///Accessible Parking: Outdoor, 2 spots
        /// HAC6061.
        /// </summary>
        [EnumMember(Value = "HAC6061")]
        HAC6061,

        /// <summary>
        ///Beach Access
        /// HAC6062.
        /// </summary>
        [EnumMember(Value = "HAC6062")]
        HAC6062,

        /// <summary>
        ///Business Facilities
        /// HAC6063.
        /// </summary>
        [EnumMember(Value = "HAC6063")]
        HAC6063,

        /// <summary>
        ///Courtyard: Shared
        /// HAC6064.
        /// </summary>
        [EnumMember(Value = "HAC6064")]
        HAC6064,

        /// <summary>
        ///Courtyard: Private Use
        /// HAC6065.
        /// </summary>
        [EnumMember(Value = "HAC6065")]
        HAC6065,

        /// <summary>
        ///Fire Pit
        /// HAC6066.
        /// </summary>
        [EnumMember(Value = "HAC6066")]
        HAC6066,

        /// <summary>
        ///Fitness Center: Access to community facilities
        /// HAC6067.
        /// </summary>
        [EnumMember(Value = "HAC6067")]
        HAC6067,

        /// <summary>
        ///Fitness Center: Private
        /// HAC6068.
        /// </summary>
        [EnumMember(Value = "HAC6068")]
        HAC6068,

        /// <summary>
        ///Heli-pad
        /// HAC6069.
        /// </summary>
        [EnumMember(Value = "HAC6069")]
        HAC6069,

        /// <summary>
        ///Home Theatre System
        /// HAC6070.
        /// </summary>
        [EnumMember(Value = "HAC6070")]
        HAC6070,

        /// <summary>
        ///Lakefront
        /// HAC6072.
        /// </summary>
        [EnumMember(Value = "HAC6072")]
        HAC6072,

        /// <summary>
        ///Laundry Facilities
        /// HAC6073.
        /// </summary>
        [EnumMember(Value = "HAC6073")]
        HAC6073,

        /// <summary>
        ///Outdoor Dining Area: Private
        /// HAC6074.
        /// </summary>
        [EnumMember(Value = "HAC6074")]
        HAC6074,

        /// <summary>
        ///Outdoor Dining Area: Shared
        /// HAC6075.
        /// </summary>
        [EnumMember(Value = "HAC6075")]
        HAC6075,

        /// <summary>
        ///Outdoor Dining Area: Screened-in
        /// HAC6076.
        /// </summary>
        [EnumMember(Value = "HAC6076")]
        HAC6076,

        /// <summary>
        ///Outdoor Dining Area: Seats 10
        /// HAC6077.
        /// </summary>
        [EnumMember(Value = "HAC6077")]
        HAC6077,

        /// <summary>
        ///Outdoor Dining Area: Seats 12
        /// HAC6078.
        /// </summary>
        [EnumMember(Value = "HAC6078")]
        HAC6078,

        /// <summary>
        ///Outdoor Dining Area: Seats 20+
        /// HAC6079.
        /// </summary>
        [EnumMember(Value = "HAC6079")]
        HAC6079,

        /// <summary>
        ///Outdoor Furniture Area
        /// HAC6080.
        /// </summary>
        [EnumMember(Value = "HAC6080")]
        HAC6080,

        /// <summary>
        ///Outdoor Furniture Area: Sun Loungers
        /// HAC6081.
        /// </summary>
        [EnumMember(Value = "HAC6081")]
        HAC6081,

        /// <summary>
        ///Outdoor Furniture Area: Dining Area
        /// HAC6082.
        /// </summary>
        [EnumMember(Value = "HAC6082")]
        HAC6082,

        /// <summary>
        ///Pool: Infinity Edge
        /// HAC6084.
        /// </summary>
        [EnumMember(Value = "HAC6084")]
        HAC6084,

        /// <summary>
        ///Pool: Saltwater
        /// HAC6085.
        /// </summary>
        [EnumMember(Value = "HAC6085")]
        HAC6085,

        /// <summary>
        ///Pool: Community Access
        /// HAC6086.
        /// </summary>
        [EnumMember(Value = "HAC6086")]
        HAC6086,

        /// <summary>
        ///Riverfront
        /// HAC6087.
        /// </summary>
        [EnumMember(Value = "HAC6087")]
        HAC6087,

        /// <summary>
        ///Sauna: Private
        /// HAC6088.
        /// </summary>
        [EnumMember(Value = "HAC6088")]
        HAC6088,

        /// <summary>
        ///Sauna: Shared
        /// HAC6089.
        /// </summary>
        [EnumMember(Value = "HAC6089")]
        HAC6089,

        /// <summary>
        ///Sauna: En-suite
        /// HAC6090.
        /// </summary>
        [EnumMember(Value = "HAC6090")]
        HAC6090,

        /// <summary>
        ///Seafront
        /// HAC6091.
        /// </summary>
        [EnumMember(Value = "HAC6091")]
        HAC6091,

        /// <summary>
        ///Ski rental: Available for additional fee
        /// HAC6092.
        /// </summary>
        [EnumMember(Value = "HAC6092")]
        HAC6092,

        /// <summary>
        ///Ski rental: Rental cost included with stay
        /// HAC6093.
        /// </summary>
        [EnumMember(Value = "HAC6093")]
        HAC6093,

        /// <summary>
        ///Steam room
        /// HAC6095.
        /// </summary>
        [EnumMember(Value = "HAC6095")]
        HAC6095,

        /// <summary>
        ///Bathroom Amenities: Robe included
        /// HAC6096.
        /// </summary>
        [EnumMember(Value = "HAC6096")]
        HAC6096,

        /// <summary>
        ///Children’s play area: Indoor
        /// HAC6097.
        /// </summary>
        [EnumMember(Value = "HAC6097")]
        HAC6097,

        /// <summary>
        ///Children’s play area: Outdoor
        /// HAC6098.
        /// </summary>
        [EnumMember(Value = "HAC6098")]
        HAC6098,

        /// <summary>
        ///High Chair
        /// HAC6099.
        /// </summary>
        [EnumMember(Value = "HAC6099")]
        HAC6099,

        /// <summary>
        ///Massage services
        /// HAC61.
        /// </summary>
        [EnumMember(Value = "HAC61")]
        HAC61,

        /// <summary>
        ///Table Tennis: Indoor
        /// HAC6100.
        /// </summary>
        [EnumMember(Value = "HAC6100")]
        HAC6100,

        /// <summary>
        ///Table Tennis: Outdoor
        /// HAC6101.
        /// </summary>
        [EnumMember(Value = "HAC6101")]
        HAC6101,

        /// <summary>
        ///Television: Plasma
        /// HAC6102.
        /// </summary>
        [EnumMember(Value = "HAC6102")]
        HAC6102,

        /// <summary>
        ///Television: Flat screen
        /// HAC6103.
        /// </summary>
        [EnumMember(Value = "HAC6103")]
        HAC6103,

        /// <summary>
        ///Television: Smart
        /// HAC6104.
        /// </summary>
        [EnumMember(Value = "HAC6104")]
        HAC6104,

        /// <summary>
        ///Water Sports: Available for rent
        /// HAC6105.
        /// </summary>
        [EnumMember(Value = "HAC6105")]
        HAC6105,

        /// <summary>
        ///Water Sports: Available for additional fee
        /// HAC6106.
        /// </summary>
        [EnumMember(Value = "HAC6106")]
        HAC6106,

        /// <summary>
        ///Baby Sitting: On request
        /// HAC6107.
        /// </summary>
        [EnumMember(Value = "HAC6107")]
        HAC6107,

        /// <summary>
        ///Baby Sitting: Available for additional fee
        /// HAC6108.
        /// </summary>
        [EnumMember(Value = "HAC6108")]
        HAC6108,

        /// <summary>
        ///Bartender
        /// HAC6109.
        /// </summary>
        [EnumMember(Value = "HAC6109")]
        HAC6109,

        /// <summary>
        ///Bartender: On request
        /// HAC6110.
        /// </summary>
        [EnumMember(Value = "HAC6110")]
        HAC6110,

        /// <summary>
        ///Bartender: Available for additional fee
        /// HAC6111.
        /// </summary>
        [EnumMember(Value = "HAC6111")]
        HAC6111,

        /// <summary>
        ///Butler: On request
        /// HAC6113.
        /// </summary>
        [EnumMember(Value = "HAC6113")]
        HAC6113,

        /// <summary>
        ///Butler: Available for additional fee
        /// HAC6114.
        /// </summary>
        [EnumMember(Value = "HAC6114")]
        HAC6114,

        /// <summary>
        ///Chef Services: Included
        /// HAC6115.
        /// </summary>
        [EnumMember(Value = "HAC6115")]
        HAC6115,

        /// <summary>
        ///Chef Services: Available for additional fee
        /// HAC6116.
        /// </summary>
        [EnumMember(Value = "HAC6116")]
        HAC6116,

        /// <summary>
        ///Chef Services: Working schedule
        /// HAC6117.
        /// </summary>
        [EnumMember(Value = "HAC6117")]
        HAC6117,

        /// <summary>
        ///Concierge Services: AM only
        /// HAC6118.
        /// </summary>
        [EnumMember(Value = "HAC6118")]
        HAC6118,

        /// <summary>
        ///Concierge Services: PM only
        /// HAC6119.
        /// </summary>
        [EnumMember(Value = "HAC6119")]
        HAC6119,

        /// <summary>
        ///Concierge Services: Weekends only
        /// HAC6120.
        /// </summary>
        [EnumMember(Value = "HAC6120")]
        HAC6120,

        /// <summary>
        ///Dry Cleaning: On request
        /// HAC6121.
        /// </summary>
        [EnumMember(Value = "HAC6121")]
        HAC6121,

        /// <summary>
        ///Dry Cleaning: Available for additional fee
        /// HAC6122.
        /// </summary>
        [EnumMember(Value = "HAC6122")]
        HAC6122,

        /// <summary>
        ///Gardener
        /// HAC6123.
        /// </summary>
        [EnumMember(Value = "HAC6123")]
        HAC6123,

        /// <summary>
        ///Grocery shopping service available: On request
        /// HAC6124.
        /// </summary>
        [EnumMember(Value = "HAC6124")]
        HAC6124,

        /// <summary>
        ///Grocery shopping service available: Available for additional fee
        /// HAC6125.
        /// </summary>
        [EnumMember(Value = "HAC6125")]
        HAC6125,

        /// <summary>
        ///Housekeeping: 2x Daily
        /// HAC6126.
        /// </summary>
        [EnumMember(Value = "HAC6126")]
        HAC6126,

        /// <summary>
        ///Housekeeping: Additional Services
        /// HAC6127.
        /// </summary>
        [EnumMember(Value = "HAC6127")]
        HAC6127,

        /// <summary>
        ///Housekeeping: Additional services available on request
        /// HAC6128.
        /// </summary>
        [EnumMember(Value = "HAC6128")]
        HAC6128,

        /// <summary>
        ///Housekeeping: Additional services available for extra fee
        /// HAC6129.
        /// </summary>
        [EnumMember(Value = "HAC6129")]
        HAC6129,

        /// <summary>
        ///House Manager
        /// HAC6130.
        /// </summary>
        [EnumMember(Value = "HAC6130")]
        HAC6130,

        /// <summary>
        ///In-person Welcome
        /// HAC6131.
        /// </summary>
        [EnumMember(Value = "HAC6131")]
        HAC6131,

        /// <summary>
        ///Laundry Services
        /// HAC6132.
        /// </summary>
        [EnumMember(Value = "HAC6132")]
        HAC6132,

        /// <summary>
        ///Laundry Services: Availabe for additional fee
        /// HAC6133.
        /// </summary>
        [EnumMember(Value = "HAC6133")]
        HAC6133,

        /// <summary>
        ///Meal Included: Breakfast
        /// HAC6134.
        /// </summary>
        [EnumMember(Value = "HAC6134")]
        HAC6134,

        /// <summary>
        ///Meal Included: 3 meals/ day
        /// HAC6135.
        /// </summary>
        [EnumMember(Value = "HAC6135")]
        HAC6135,

        /// <summary>
        ///Meal Included: Available for additional fee
        /// HAC6136.
        /// </summary>
        [EnumMember(Value = "HAC6136")]
        HAC6136,

        /// <summary>
        ///Valet Parking: On request
        /// HAC6137.
        /// </summary>
        [EnumMember(Value = "HAC6137")]
        HAC6137,

        /// <summary>
        ///Valet Parking: Available for additional fee
        /// HAC6138.
        /// </summary>
        [EnumMember(Value = "HAC6138")]
        HAC6138,

        /// <summary>
        ///Nightclub
        /// HAC62.
        /// </summary>
        [EnumMember(Value = "HAC62")]
        HAC62,

        /// <summary>
        ///Outdoor pool
        /// HAC66.
        /// </summary>
        [EnumMember(Value = "HAC66")]
        HAC66,

        /// <summary>
        ///ATM/Cash machine
        /// HAC7.
        /// </summary>
        [EnumMember(Value = "HAC7")]
        HAC7,

        /// <summary>
        ///Pool
        /// HAC71.
        /// </summary>
        [EnumMember(Value = "HAC71")]
        HAC71,

        /// <summary>
        ///Restaurant
        /// HAC76.
        /// </summary>
        [EnumMember(Value = "HAC76")]
        HAC76,

        /// <summary>
        ///Room service
        /// HAC77.
        /// </summary>
        [EnumMember(Value = "HAC77")]
        HAC77,

        /// <summary>
        ///Safe deposit box
        /// HAC78.
        /// </summary>
        [EnumMember(Value = "HAC78")]
        HAC78,

        /// <summary>
        ///Sauna
        /// HAC79.
        /// </summary>
        [EnumMember(Value = "HAC79")]
        HAC79,

        /// <summary>
        ///Baby sitting
        /// HAC8.
        /// </summary>
        [EnumMember(Value = "HAC8")]
        HAC8,

        /// <summary>
        ///Shoe shine stand
        /// HAC81.
        /// </summary>
        [EnumMember(Value = "HAC81")]
        HAC81,

        /// <summary>
        ///Solarium
        /// HAC83.
        /// </summary>
        [EnumMember(Value = "HAC83")]
        HAC83,

        /// <summary>
        ///Steam bath
        /// HAC86.
        /// </summary>
        [EnumMember(Value = "HAC86")]
        HAC86,

        /// <summary>
        ///BBQ/Picnic area
        /// HAC9.
        /// </summary>
        [EnumMember(Value = "HAC9")]
        HAC9,

        /// <summary>
        ///Tour/sightseeing desk
        /// HAC91.
        /// </summary>
        [EnumMember(Value = "HAC91")]
        HAC91,

        /// <summary>
        ///Truck parking
        /// HAC94.
        /// </summary>
        [EnumMember(Value = "HAC94")]
        HAC94,

        /// <summary>
        ///Dry cleaning
        /// HAC96.
        /// </summary>
        [EnumMember(Value = "HAC96")]
        HAC96,

        /// <summary>
        ///Valet parking
        /// HAC97.
        /// </summary>
        [EnumMember(Value = "HAC97")]
        HAC97,

        /// <summary>
        ///Vending machines
        /// HAC98.
        /// </summary>
        [EnumMember(Value = "HAC98")]
        HAC98,

        /// <summary>
        ///Adjoining rooms
        /// RMA1.
        /// </summary>
        [EnumMember(Value = "RMA1")]
        RMA1,

        /// <summary>
        ///Bathrobe
        /// RMA10.
        /// </summary>
        [EnumMember(Value = "RMA10")]
        RMA10,

        /// <summary>
        ///Smoke detectors
        /// RMA100.
        /// </summary>
        [EnumMember(Value = "RMA100")]
        RMA100,

        /// <summary>
        ///Sofa bed
        /// RMA102.
        /// </summary>
        [EnumMember(Value = "RMA102")]
        RMA102,

        /// <summary>
        ///Speaker phone
        /// RMA103.
        /// </summary>
        [EnumMember(Value = "RMA103")]
        RMA103,

        /// <summary>
        ///Stereo
        /// RMA104.
        /// </summary>
        [EnumMember(Value = "RMA104")]
        RMA104,

        /// <summary>
        ///Stove
        /// RMA105.
        /// </summary>
        [EnumMember(Value = "RMA105")]
        RMA105,

        /// <summary>
        ///Telephone
        /// RMA107.
        /// </summary>
        [EnumMember(Value = "RMA107")]
        RMA107,

        /// <summary>
        ///Telephone for hearing impaired
        /// RMA108.
        /// </summary>
        [EnumMember(Value = "RMA108")]
        RMA108,

        /// <summary>
        ///Bathroom amenities
        /// RMA11.
        /// </summary>
        [EnumMember(Value = "RMA11")]
        RMA11,

        /// <summary>
        ///Trouser/Pant press
        /// RMA111.
        /// </summary>
        [EnumMember(Value = "RMA111")]
        RMA111,

        /// <summary>
        ///Twin bed
        /// RMA113.
        /// </summary>
        [EnumMember(Value = "RMA113")]
        RMA113,

        /// <summary>
        ///VCR movies
        /// RMA115.
        /// </summary>
        [EnumMember(Value = "RMA115")]
        RMA115,

        /// <summary>
        ///Video games
        /// RMA117.
        /// </summary>
        [EnumMember(Value = "RMA117")]
        RMA117,

        /// <summary>
        ///Wake-up calls
        /// RMA119.
        /// </summary>
        [EnumMember(Value = "RMA119")]
        RMA119,

        /// <summary>
        ///Air conditioning individually controlled in room
        /// RMA126.
        /// </summary>
        [EnumMember(Value = "RMA126")]
        RMA126,

        /// <summary>
        ///Bathtub &whirlpool separate
        /// RMA127.
        /// </summary>
        [EnumMember(Value = "RMA127")]
        RMA127,

        /// <summary>
        ///CD  player
        /// RMA129.
        /// </summary>
        [EnumMember(Value = "RMA129")]
        RMA129,

        /// <summary>
        ///Bathtub
        /// RMA13.
        /// </summary>
        [EnumMember(Value = "RMA13")]
        RMA13,

        /// <summary>
        ///Desk with electrical outlet
        /// RMA133.
        /// </summary>
        [EnumMember(Value = "RMA133")]
        RMA133,

        /// <summary>
        ///Foam pillows
        /// RMA135.
        /// </summary>
        [EnumMember(Value = "RMA135")]
        RMA135,

        /// <summary>
        ///Marble bathroom
        /// RMA138.
        /// </summary>
        [EnumMember(Value = "RMA138")]
        RMA138,

        /// <summary>
        ///List of movie channels available
        /// RMA139.
        /// </summary>
        [EnumMember(Value = "RMA139")]
        RMA139,

        /// <summary>
        ///Bathtub only
        /// RMA14.
        /// </summary>
        [EnumMember(Value = "RMA14")]
        RMA14,

        /// <summary>
        ///Oversized bathtub
        /// RMA141.
        /// </summary>
        [EnumMember(Value = "RMA141")]
        RMA141,

        /// <summary>
        ///Shower
        /// RMA142.
        /// </summary>
        [EnumMember(Value = "RMA142")]
        RMA142,

        /// <summary>
        ///Sink in-room
        /// RMA143.
        /// </summary>
        [EnumMember(Value = "RMA143")]
        RMA143,

        /// <summary>
        ///Soundproofed room
        /// RMA144.
        /// </summary>
        [EnumMember(Value = "RMA144")]
        RMA144,

        /// <summary>
        ///Tables and chairs
        /// RMA146.
        /// </summary>
        [EnumMember(Value = "RMA146")]
        RMA146,

        /// <summary>
        ///Two-line phone
        /// RMA147.
        /// </summary>
        [EnumMember(Value = "RMA147")]
        RMA147,

        /// <summary>
        ///Washer/dryer
        /// RMA149.
        /// </summary>
        [EnumMember(Value = "RMA149")]
        RMA149,

        /// <summary>
        ///Bathtub or Shower
        /// RMA15.
        /// </summary>
        [EnumMember(Value = "RMA15")]
        RMA15,

        /// <summary>
        ///Welcome gift
        /// RMA151.
        /// </summary>
        [EnumMember(Value = "RMA151")]
        RMA151,

        /// <summary>
        ///Separate tub and shower
        /// RMA155.
        /// </summary>
        [EnumMember(Value = "RMA155")]
        RMA155,

        /// <summary>
        ///Ceiling fan
        /// RMA157.
        /// </summary>
        [EnumMember(Value = "RMA157")]
        RMA157,

        /// <summary>
        ///CNN available
        /// RMA158.
        /// </summary>
        [EnumMember(Value = "RMA158")]
        RMA158,

        /// <summary>
        ///Bidet
        /// RMA16.
        /// </summary>
        [EnumMember(Value = "RMA16")]
        RMA16,

        /// <summary>
        ///Accessible room
        /// RMA161.
        /// </summary>
        [EnumMember(Value = "RMA161")]
        RMA161,

        /// <summary>
        ///Closets in room
        /// RMA162.
        /// </summary>
        [EnumMember(Value = "RMA162")]
        RMA162,

        /// <summary>
        ///DVD player
        /// RMA163.
        /// </summary>
        [EnumMember(Value = "RMA163")]
        RMA163,

        /// <summary>
        ///Mini-refrigerator
        /// RMA164.
        /// </summary>
        [EnumMember(Value = "RMA164")]
        RMA164,

        /// <summary>
        ///Heating
        /// RMA166.
        /// </summary>
        [EnumMember(Value = "RMA166")]
        RMA166,

        /// <summary>
        ///Toaster
        /// RMA167.
        /// </summary>
        [EnumMember(Value = "RMA167")]
        RMA167,

        /// <summary>
        ///International calls
        /// RMA170.
        /// </summary>
        [EnumMember(Value = "RMA170")]
        RMA170,

        /// <summary>
        ///Long distance calls
        /// RMA175.
        /// </summary>
        [EnumMember(Value = "RMA175")]
        RMA175,

        /// <summary>
        ///Cable television
        /// RMA18.
        /// </summary>
        [EnumMember(Value = "RMA18")]
        RMA18,

        /// <summary>
        ///Hypoallergenic bed
        /// RMA186.
        /// </summary>
        [EnumMember(Value = "RMA186")]
        RMA186,

        /// <summary>
        ///Coffee/Tea maker
        /// RMA19.
        /// </summary>
        [EnumMember(Value = "RMA19")]
        RMA19,

        /// <summary>
        ///Meal included - continental breakfast
        /// RMA190.
        /// </summary>
        [EnumMember(Value = "RMA190")]
        RMA190,

        /// <summary>
        ///Meal included - dinner
        /// RMA191.
        /// </summary>
        [EnumMember(Value = "RMA191")]
        RMA191,

        /// <summary>
        ///Meal included - lunch
        /// RMA192.
        /// </summary>
        [EnumMember(Value = "RMA192")]
        RMA192,

        /// <summary>
        ///Shared bathroom
        /// RMA193.
        /// </summary>
        [EnumMember(Value = "RMA193")]
        RMA193,

        /// <summary>
        ///Telephone TDD/Textphone
        /// RMA194.
        /// </summary>
        [EnumMember(Value = "RMA194")]
        RMA194,

        /// <summary>
        ///Water bed
        /// RMA195.
        /// </summary>
        [EnumMember(Value = "RMA195")]
        RMA195,

        /// <summary>
        ///Air conditioning
        /// RMA2.
        /// </summary>
        [EnumMember(Value = "RMA2")]
        RMA2,

        /// <summary>
        ///Color television
        /// RMA20.
        /// </summary>
        [EnumMember(Value = "RMA20")]
        RMA20,

        /// <summary>
        ///Futon
        /// RMA200.
        /// </summary>
        [EnumMember(Value = "RMA200")]
        RMA200,

        /// <summary>
        ///Murphy bed
        /// RMA201.
        /// </summary>
        [EnumMember(Value = "RMA201")]
        RMA201,

        /// <summary>
        ///Single bed
        /// RMA203.
        /// </summary>
        [EnumMember(Value = "RMA203")]
        RMA203,

        /// <summary>
        ///Annex room
        /// RMA204.
        /// </summary>
        [EnumMember(Value = "RMA204")]
        RMA204,

        /// <summary>
        ///Free newspaper
        /// RMA205.
        /// </summary>
        [EnumMember(Value = "RMA205")]
        RMA205,

        /// <summary>
        ///Complimentary high speed internet in room
        /// RMA207.
        /// </summary>
        [EnumMember(Value = "RMA207")]
        RMA207,

        /// <summary>
        ///Computer
        /// RMA21.
        /// </summary>
        [EnumMember(Value = "RMA21")]
        RMA21,

        /// <summary>
        ///Satellite television
        /// RMA210.
        /// </summary>
        [EnumMember(Value = "RMA210")]
        RMA210,

        /// <summary>
        ///iPod docking station
        /// RMA214.
        /// </summary>
        [EnumMember(Value = "RMA214")]
        RMA214,

        /// <summary>
        ///Satellite radio
        /// RMA217.
        /// </summary>
        [EnumMember(Value = "RMA217")]
        RMA217,

        /// <summary>
        ///Video on demand
        /// RMA218.
        /// </summary>
        [EnumMember(Value = "RMA218")]
        RMA218,

        /// <summary>
        ///Connecting rooms
        /// RMA22.
        /// </summary>
        [EnumMember(Value = "RMA22")]
        RMA22,

        /// <summary>
        ///Gulf view
        /// RMA220.
        /// </summary>
        [EnumMember(Value = "RMA220")]
        RMA220,

        /// <summary>
        ///Mountain view
        /// RMA223.
        /// </summary>
        [EnumMember(Value = "RMA223")]
        RMA223,

        /// <summary>
        ///Ocean view
        /// RMA224.
        /// </summary>
        [EnumMember(Value = "RMA224")]
        RMA224,

        /// <summary>
        ///Premium movie channels
        /// RMA227.
        /// </summary>
        [EnumMember(Value = "RMA227")]
        RMA227,

        /// <summary>
        ///Slippers
        /// RMA228.
        /// </summary>
        [EnumMember(Value = "RMA228")]
        RMA228,

        /// <summary>
        ///Chair provided with desk
        /// RMA230.
        /// </summary>
        [EnumMember(Value = "RMA230")]
        RMA230,

        /// <summary>
        ///Pillow top mattress
        /// RMA231.
        /// </summary>
        [EnumMember(Value = "RMA231")]
        RMA231,

        /// <summary>
        ///Luxury linen type
        /// RMA234.
        /// </summary>
        [EnumMember(Value = "RMA234")]
        RMA234,

        /// <summary>
        ///Instant hot water
        /// RMA242.
        /// </summary>
        [EnumMember(Value = "RMA242")]
        RMA242,

        /// <summary>
        ///RMA245
        /// RMA245.
        /// </summary>
        [EnumMember(Value = "RMA245")]
        RMA245,

        /// <summary>
        ///High Definition (HD) Flat Panel Television - 32 inches or greater
        /// RMA246.
        /// </summary>
        [EnumMember(Value = "RMA246")]
        RMA246,

        /// <summary>
        ///Cordless phone
        /// RMA25.
        /// </summary>
        [EnumMember(Value = "RMA25")]
        RMA25,

        /// <summary>
        ///TV
        /// RMA251.
        /// </summary>
        [EnumMember(Value = "RMA251")]
        RMA251,

        /// <summary>
        ///Video game player:
        /// RMA254.
        /// </summary>
        [EnumMember(Value = "RMA254")]
        RMA254,

        /// <summary>
        ///Dining room seats
        /// RMA256.
        /// </summary>
        [EnumMember(Value = "RMA256")]
        RMA256,

        /// <summary>
        ///Mobile/cellular phones
        /// RMA258.
        /// </summary>
        [EnumMember(Value = "RMA258")]
        RMA258,

        /// <summary>
        ///Movies
        /// RMA259.
        /// </summary>
        [EnumMember(Value = "RMA259")]
        RMA259,

        /// <summary>
        ///Cribs
        /// RMA26.
        /// </summary>
        [EnumMember(Value = "RMA26")]
        RMA26,

        /// <summary>
        ///Multiple closets
        /// RMA260.
        /// </summary>
        [EnumMember(Value = "RMA260")]
        RMA260,

        /// <summary>
        ///Safe large enough to accommodate a laptop
        /// RMA262.
        /// </summary>
        [EnumMember(Value = "RMA262")]
        RMA262,

        /// <summary>
        ///Bluray player
        /// RMA265.
        /// </summary>
        [EnumMember(Value = "RMA265")]
        RMA265,

        /// <summary>
        ///Non-allergenic room
        /// RMA268.
        /// </summary>
        [EnumMember(Value = "RMA268")]
        RMA268,

        /// <summary>
        ///Pillow type
        /// RMA269.
        /// </summary>
        [EnumMember(Value = "RMA269")]
        RMA269,

        /// <summary>
        ///Seating area with sofa/chair
        /// RMA270.
        /// </summary>
        [EnumMember(Value = "RMA270")]
        RMA270,

        /// <summary>
        ///Separate toilet area
        /// RMA271.
        /// </summary>
        [EnumMember(Value = "RMA271")]
        RMA271,

        /// <summary>
        ///Widescreen TV
        /// RMA273.
        /// </summary>
        [EnumMember(Value = "RMA273")]
        RMA273,

        /// <summary>
        ///Separate tub or shower
        /// RMA276.
        /// </summary>
        [EnumMember(Value = "RMA276")]
        RMA276,

        /// <summary>
        ///Children's playpen
        /// RMA279.
        /// </summary>
        [EnumMember(Value = "RMA279")]
        RMA279,

        /// <summary>
        ///Desk
        /// RMA28.
        /// </summary>
        [EnumMember(Value = "RMA28")]
        RMA28,

        /// <summary>
        ///Plunge pool
        /// RMA280.
        /// </summary>
        [EnumMember(Value = "RMA280")]
        RMA280,

        /// <summary>
        ///Desk with lamp
        /// RMA29.
        /// </summary>
        [EnumMember(Value = "RMA29")]
        RMA29,

        /// <summary>
        ///Alarm clock
        /// RMA3.
        /// </summary>
        [EnumMember(Value = "RMA3")]
        RMA3,

        /// <summary>
        ///Dishwasher
        /// RMA32.
        /// </summary>
        [EnumMember(Value = "RMA32")]
        RMA32,

        /// <summary>
        ///Double bed
        /// RMA33.
        /// </summary>
        [EnumMember(Value = "RMA33")]
        RMA33,

        /// <summary>
        ///Fax machine
        /// RMA38.
        /// </summary>
        [EnumMember(Value = "RMA38")]
        RMA38,

        /// <summary>
        ///Fireplace
        /// RMA41.
        /// </summary>
        [EnumMember(Value = "RMA41")]
        RMA41,

        /// <summary>
        ///Free local calls
        /// RMA45.
        /// </summary>
        [EnumMember(Value = "RMA45")]
        RMA45,

        /// <summary>
        ///Free movies/video
        /// RMA46.
        /// </summary>
        [EnumMember(Value = "RMA46")]
        RMA46,

        /// <summary>
        ///Full kitchen
        /// RMA47.
        /// </summary>
        [EnumMember(Value = "RMA47")]
        RMA47,

        /// <summary>
        ///Grecian tub
        /// RMA49.
        /// </summary>
        [EnumMember(Value = "RMA49")]
        RMA49,

        /// <summary>
        ///AM/FM radio
        /// RMA5.
        /// </summary>
        [EnumMember(Value = "RMA5")]
        RMA5,

        /// <summary>
        ///Hairdryer
        /// RMA50.
        /// </summary>
        [EnumMember(Value = "RMA50")]
        RMA50,

        /// <summary>
        ///Bath
        /// RMA5005.
        /// </summary>
        [EnumMember(Value = "RMA5005")]
        RMA5005,

        /// <summary>
        ///Spa Bath
        /// RMA5020.
        /// </summary>
        [EnumMember(Value = "RMA5020")]
        RMA5020,

        /// <summary>
        ///Dining Area
        /// RMA5085.
        /// </summary>
        [EnumMember(Value = "RMA5085")]
        RMA5085,

        /// <summary>
        ///Electric Kettle
        /// RMA5086.
        /// </summary>
        [EnumMember(Value = "RMA5086")]
        RMA5086,

        /// <summary>
        ///Towels/Linens At Surcharge
        /// RMA5091.
        /// </summary>
        [EnumMember(Value = "RMA5091")]
        RMA5091,

        /// <summary>
        ///Dining Table
        /// RMA5126.
        /// </summary>
        [EnumMember(Value = "RMA5126")]
        RMA5126,

        /// <summary>
        ///Baby safety gates
        /// RMA5145.
        /// </summary>
        [EnumMember(Value = "RMA5145")]
        RMA5145,

        /// <summary>
        ///Iron
        /// RMA55.
        /// </summary>
        [EnumMember(Value = "RMA55")]
        RMA55,

        /// <summary>
        ///Ironing board
        /// RMA56.
        /// </summary>
        [EnumMember(Value = "RMA56")]
        RMA56,

        /// <summary>
        ///Whirpool
        /// RMA57.
        /// </summary>
        [EnumMember(Value = "RMA57")]
        RMA57,

        /// <summary>
        ///King bed
        /// RMA58.
        /// </summary>
        [EnumMember(Value = "RMA58")]
        RMA58,

        /// <summary>
        ///Kitchen
        /// RMA59.
        /// </summary>
        [EnumMember(Value = "RMA59")]
        RMA59,

        /// <summary>
        ///Baby listening device
        /// RMA6.
        /// </summary>
        [EnumMember(Value = "RMA6")]
        RMA6,

        /// <summary>
        ///Kitchen supplies
        /// RMA60.
        /// </summary>
        [EnumMember(Value = "RMA60")]
        RMA60,

        /// <summary>
        ///Towels available
        /// RMA6001.
        /// </summary>
        [EnumMember(Value = "RMA6001")]
        RMA6001,

        /// <summary>
        ///Cats allowed
        /// RMA6003.
        /// </summary>
        [EnumMember(Value = "RMA6003")]
        RMA6003,

        /// <summary>
        ///Dogs allowed
        /// RMA6004.
        /// </summary>
        [EnumMember(Value = "RMA6004")]
        RMA6004,

        /// <summary>
        ///CD library
        /// RMA6005.
        /// </summary>
        [EnumMember(Value = "RMA6005")]
        RMA6005,

        /// <summary>
        ///Separate entrance
        /// RMA6010.
        /// </summary>
        [EnumMember(Value = "RMA6010")]
        RMA6010,

        /// <summary>
        ///Beach view
        /// RMA6012.
        /// </summary>
        [EnumMember(Value = "RMA6012")]
        RMA6012,

        /// <summary>
        ///Pool view
        /// RMA6013.
        /// </summary>
        [EnumMember(Value = "RMA6013")]
        RMA6013,

        /// <summary>
        ///Water view
        /// RMA6017.
        /// </summary>
        [EnumMember(Value = "RMA6017")]
        RMA6017,

        /// <summary>
        ///Electronic room key
        /// RMA6018.
        /// </summary>
        [EnumMember(Value = "RMA6018")]
        RMA6018,

        /// <summary>
        ///Fire extinguishers
        /// RMA6021.
        /// </summary>
        [EnumMember(Value = "RMA6021")]
        RMA6021,

        /// <summary>
        ///Golf view
        /// RMA6027.
        /// </summary>
        [EnumMember(Value = "RMA6027")]
        RMA6027,

        /// <summary>
        ///Ground floor
        /// RMA6028.
        /// </summary>
        [EnumMember(Value = "RMA6028")]
        RMA6028,

        /// <summary>
        ///Lake view
        /// RMA6029.
        /// </summary>
        [EnumMember(Value = "RMA6029")]
        RMA6029,

        /// <summary>
        ///City view
        /// RMA6030.
        /// </summary>
        [EnumMember(Value = "RMA6030")]
        RMA6030,

        /// <summary>
        ///Harbor view
        /// RMA6031.
        /// </summary>
        [EnumMember(Value = "RMA6031")]
        RMA6031,

        /// <summary>
        ///Bunk bed
        /// RMA6032.
        /// </summary>
        [EnumMember(Value = "RMA6032")]
        RMA6032,

        /// <summary>
        ///Washer
        /// RMA6033.
        /// </summary>
        [EnumMember(Value = "RMA6033")]
        RMA6033,

        /// <summary>
        ///Dryer
        /// RMA6034.
        /// </summary>
        [EnumMember(Value = "RMA6034")]
        RMA6034,

        /// <summary>
        ///Hangers
        /// RMA6035.
        /// </summary>
        [EnumMember(Value = "RMA6035")]
        RMA6035,

        /// <summary>
        ///Laptop Friendly Workspace
        /// RMA6036.
        /// </summary>
        [EnumMember(Value = "RMA6036")]
        RMA6036,

        /// <summary>
        ///Essentials
        /// RMA6037.
        /// </summary>
        [EnumMember(Value = "RMA6037")]
        RMA6037,

        /// <summary>
        ///Extra bed
        /// RMA6038.
        /// </summary>
        [EnumMember(Value = "RMA6038")]
        RMA6038,

        /// <summary>
        ///Patio
        /// RMA6039.
        /// </summary>
        [EnumMember(Value = "RMA6039")]
        RMA6039,

        /// <summary>
        ///iPad
        /// RMA6040.
        /// </summary>
        [EnumMember(Value = "RMA6040")]
        RMA6040,

        /// <summary>
        ///Living room
        /// RMA6042.
        /// </summary>
        [EnumMember(Value = "RMA6042")]
        RMA6042,

        /// <summary>
        ///Outdoor furniture
        /// RMA6045.
        /// </summary>
        [EnumMember(Value = "RMA6045")]
        RMA6045,

        /// <summary>
        ///Outdoor dinning area
        /// RMA6046.
        /// </summary>
        [EnumMember(Value = "RMA6046")]
        RMA6046,

        /// <summary>
        ///Garden view
        /// RMA6051.
        /// </summary>
        [EnumMember(Value = "RMA6051")]
        RMA6051,

        /// <summary>
        ///River view
        /// RMA6052.
        /// </summary>
        [EnumMember(Value = "RMA6052")]
        RMA6052,

        /// <summary>
        ///Park view
        /// RMA6053.
        /// </summary>
        [EnumMember(Value = "RMA6053")]
        RMA6053,

        /// <summary>
        ///Game Console - Xbox 360
        /// RMA6054.
        /// </summary>
        [EnumMember(Value = "RMA6054")]
        RMA6054,

        /// <summary>
        ///Game Console - PS2
        /// RMA6055.
        /// </summary>
        [EnumMember(Value = "RMA6055")]
        RMA6055,

        /// <summary>
        ///Game Console - PS3
        /// RMA6056.
        /// </summary>
        [EnumMember(Value = "RMA6056")]
        RMA6056,

        /// <summary>
        ///Game Console - Nintendo Wii
        /// RMA6057.
        /// </summary>
        [EnumMember(Value = "RMA6057")]
        RMA6057,

        /// <summary>
        ///Linen
        /// RMA6058.
        /// </summary>
        [EnumMember(Value = "RMA6058")]
        RMA6058,

        /// <summary>
        ///Carpeted floor
        /// RMA6059.
        /// </summary>
        [EnumMember(Value = "RMA6059")]
        RMA6059,

        /// <summary>
        ///Tiled floor
        /// RMA6060.
        /// </summary>
        [EnumMember(Value = "RMA6060")]
        RMA6060,

        /// <summary>
        ///Parquet Floor
        /// RMA6061.
        /// </summary>
        [EnumMember(Value = "RMA6061")]
        RMA6061,

        /// <summary>
        ///Upper Floor Reachable By Stairs Only
        /// RMA6062.
        /// </summary>
        [EnumMember(Value = "RMA6062")]
        RMA6062,

        /// <summary>
        ///Semi-Detached
        /// RMA6063.
        /// </summary>
        [EnumMember(Value = "RMA6063")]
        RMA6063,

        /// <summary>
        ///Detached
        /// RMA6064.
        /// </summary>
        [EnumMember(Value = "RMA6064")]
        RMA6064,

        /// <summary>
        ///Mosquito Net
        /// RMA6065.
        /// </summary>
        [EnumMember(Value = "RMA6065")]
        RMA6065,

        /// <summary>
        ///Cleaning Included
        /// RMA6066.
        /// </summary>
        [EnumMember(Value = "RMA6066")]
        RMA6066,

        /// <summary>
        ///Carbon monoxide detector
        /// RMA6067.
        /// </summary>
        [EnumMember(Value = "RMA6067")]
        RMA6067,

        /// <summary>
        ///First aid kit
        /// RMA6068.
        /// </summary>
        [EnumMember(Value = "RMA6068")]
        RMA6068,

        /// <summary>
        ///Buzzer/wireless intercom
        /// RMA6071.
        /// </summary>
        [EnumMember(Value = "RMA6071")]
        RMA6071,

        /// <summary>
        ///Safety card
        /// RMA6072.
        /// </summary>
        [EnumMember(Value = "RMA6072")]
        RMA6072,

        /// <summary>
        ///Lock on bedroom door
        /// RMA6073.
        /// </summary>
        [EnumMember(Value = "RMA6073")]
        RMA6073,

        /// <summary>
        ///Smart lock
        /// RMA6074.
        /// </summary>
        [EnumMember(Value = "RMA6074")]
        RMA6074,

        /// <summary>
        ///Private entrance
        /// RMA6075.
        /// </summary>
        [EnumMember(Value = "RMA6075")]
        RMA6075,

        /// <summary>
        ///Outlet covers
        /// RMA6076.
        /// </summary>
        [EnumMember(Value = "RMA6076")]
        RMA6076,

        /// <summary>
        ///Baby bath
        /// RMA6077.
        /// </summary>
        [EnumMember(Value = "RMA6077")]
        RMA6077,

        /// <summary>
        ///Stair gates
        /// RMA6078.
        /// </summary>
        [EnumMember(Value = "RMA6078")]
        RMA6078,

        /// <summary>
        ///Window guards
        /// RMA6079.
        /// </summary>
        [EnumMember(Value = "RMA6079")]
        RMA6079,

        /// <summary>
        ///Table corner guards
        /// RMA6080.
        /// </summary>
        [EnumMember(Value = "RMA6080")]
        RMA6080,

        /// <summary>
        ///Fireplace guards
        /// RMA6081.
        /// </summary>
        [EnumMember(Value = "RMA6081")]
        RMA6081,

        /// <summary>
        ///Room darkening shades
        /// RMA6082.
        /// </summary>
        [EnumMember(Value = "RMA6082")]
        RMA6082,

        /// <summary>
        ///Childrens dinnerware
        /// RMA6083.
        /// </summary>
        [EnumMember(Value = "RMA6083")]
        RMA6083,

        /// <summary>
        ///Children’s books and toys
        /// RMA6084.
        /// </summary>
        [EnumMember(Value = "RMA6084")]
        RMA6084,

        /// <summary>
        ///Breakfast not available
        /// RMA6085.
        /// </summary>
        [EnumMember(Value = "RMA6085")]
        RMA6085,

        /// <summary>
        ///Dinner booking possible
        /// RMA6086.
        /// </summary>
        [EnumMember(Value = "RMA6086")]
        RMA6086,

        /// <summary>
        ///Dinner not available
        /// RMA6087.
        /// </summary>
        [EnumMember(Value = "RMA6087")]
        RMA6087,

        /// <summary>
        ///House cleaning optional
        /// RMA6088.
        /// </summary>
        [EnumMember(Value = "RMA6088")]
        RMA6088,

        /// <summary>
        ///Lunch booking possible
        /// RMA6089.
        /// </summary>
        [EnumMember(Value = "RMA6089")]
        RMA6089,

        /// <summary>
        ///Lunch not available
        /// RMA6090.
        /// </summary>
        [EnumMember(Value = "RMA6090")]
        RMA6090,

        /// <summary>
        ///Wood stove
        /// RMA6091.
        /// </summary>
        [EnumMember(Value = "RMA6091")]
        RMA6091,

        /// <summary>
        ///Dining Highchair
        /// RMA6092.
        /// </summary>
        [EnumMember(Value = "RMA6092")]
        RMA6092,

        /// <summary>
        ///Dining Raclette
        /// RMA6093.
        /// </summary>
        [EnumMember(Value = "RMA6093")]
        RMA6093,

        /// <summary>
        ///Dining room
        /// RMA6094.
        /// </summary>
        [EnumMember(Value = "RMA6094")]
        RMA6094,

        /// <summary>
        ///Dining spices
        /// RMA6095.
        /// </summary>
        [EnumMember(Value = "RMA6095")]
        RMA6095,

        /// <summary>
        ///Meals guests furnish own
        /// RMA6096.
        /// </summary>
        [EnumMember(Value = "RMA6096")]
        RMA6096,

        /// <summary>
        ///Limited accessibility
        /// RMA6097.
        /// </summary>
        [EnumMember(Value = "RMA6097")]
        RMA6097,

        /// <summary>
        ///Wheelchair inaccessible
        /// RMA6098.
        /// </summary>
        [EnumMember(Value = "RMA6098")]
        RMA6098,

        /// <summary>
        ///Breakfast booking possible
        /// RMA6099.
        /// </summary>
        [EnumMember(Value = "RMA6099")]
        RMA6099,

        /// <summary>
        ///Kitchenette
        /// RMA61.
        /// </summary>
        [EnumMember(Value = "RMA61")]
        RMA61,

        /// <summary>
        ///Extra pillows and blankets
        /// RMA6100.
        /// </summary>
        [EnumMember(Value = "RMA6100")]
        RMA6100,

        /// <summary>
        ///Ethernet connection
        /// RMA6101.
        /// </summary>
        [EnumMember(Value = "RMA6101")]
        RMA6101,

        /// <summary>
        ///Pocket wifi
        /// RMA6102.
        /// </summary>
        [EnumMember(Value = "RMA6102")]
        RMA6102,

        /// <summary>
        ///Cooking basics
        /// RMA6103.
        /// </summary>
        [EnumMember(Value = "RMA6103")]
        RMA6103,

        /// <summary>
        ///Changing table
        /// RMA6104.
        /// </summary>
        [EnumMember(Value = "RMA6104")]
        RMA6104,

        /// <summary>
        ///Bedroom step free access
        /// RMA6105.
        /// </summary>
        [EnumMember(Value = "RMA6105")]
        RMA6105,

        /// <summary>
        ///Wide clearance to bed
        /// RMA6106.
        /// </summary>
        [EnumMember(Value = "RMA6106")]
        RMA6106,

        /// <summary>
        ///Bedroom wide doorway
        /// RMA6107.
        /// </summary>
        [EnumMember(Value = "RMA6107")]
        RMA6107,

        /// <summary>
        ///Accessible height bed
        /// RMA6108.
        /// </summary>
        [EnumMember(Value = "RMA6108")]
        RMA6108,

        /// <summary>
        ///Bathroom step free access
        /// RMA6109.
        /// </summary>
        [EnumMember(Value = "RMA6109")]
        RMA6109,

        /// <summary>
        ///Grab rails in shower and toilet
        /// RMA6110.
        /// </summary>
        [EnumMember(Value = "RMA6110")]
        RMA6110,

        /// <summary>
        ///Accessible height toilet
        /// RMA6111.
        /// </summary>
        [EnumMember(Value = "RMA6111")]
        RMA6111,

        /// <summary>
        ///Rollin shower with bench
        /// RMA6112.
        /// </summary>
        [EnumMember(Value = "RMA6112")]
        RMA6112,

        /// <summary>
        ///Bathroom wide doorway
        /// RMA6113.
        /// </summary>
        [EnumMember(Value = "RMA6113")]
        RMA6113,

        /// <summary>
        ///Tub with shower bench
        /// RMA6114.
        /// </summary>
        [EnumMember(Value = "RMA6114")]
        RMA6114,

        /// <summary>
        ///Wide clearance to shower and toilet
        /// RMA6115.
        /// </summary>
        [EnumMember(Value = "RMA6115")]
        RMA6115,

        /// <summary>
        ///Handheld shower hear
        /// RMA6116.
        /// </summary>
        [EnumMember(Value = "RMA6116")]
        RMA6116,

        /// <summary>
        ///Single level home
        /// RMA6117.
        /// </summary>
        [EnumMember(Value = "RMA6117")]
        RMA6117,

        /// <summary>
        ///Couch
        /// RMA6118.
        /// </summary>
        [EnumMember(Value = "RMA6118")]
        RMA6118,

        /// <summary>
        ///Air mattress
        /// RMA6119.
        /// </summary>
        [EnumMember(Value = "RMA6119")]
        RMA6119,

        /// <summary>
        ///Floor mattress
        /// RMA6120.
        /// </summary>
        [EnumMember(Value = "RMA6120")]
        RMA6120,

        /// <summary>
        ///Toddler bed
        /// RMA6121.
        /// </summary>
        [EnumMember(Value = "RMA6121")]
        RMA6121,

        /// <summary>
        ///Hammock
        /// RMA6122.
        /// </summary>
        [EnumMember(Value = "RMA6122")]
        RMA6122,

        /// <summary>
        ///Freezer
        /// RMA6123.
        /// </summary>
        [EnumMember(Value = "RMA6123")]
        RMA6123,

        /// <summary>
        ///Private yard
        /// RMA6124.
        /// </summary>
        [EnumMember(Value = "RMA6124")]
        RMA6124,

        /// <summary>
        ///Ensuite
        /// RMA6125.
        /// </summary>
        [EnumMember(Value = "RMA6125")]
        RMA6125,

        /// <summary>
        ///High-Speed Wifi
        /// RMA6126.
        /// </summary>
        [EnumMember(Value = "RMA6126")]
        RMA6126,

        /// <summary>
        ///Patio/Balcony
        /// RMA6127.
        /// </summary>
        [EnumMember(Value = "RMA6127")]
        RMA6127,

        /// <summary>
        ///Balcony: Garden View
        /// RMA6128.
        /// </summary>
        [EnumMember(Value = "RMA6128")]
        RMA6128,

        /// <summary>
        ///Balcony: City View
        /// RMA6129.
        /// </summary>
        [EnumMember(Value = "RMA6129")]
        RMA6129,

        /// <summary>
        ///Balcony: Ocean View
        /// RMA6130.
        /// </summary>
        [EnumMember(Value = "RMA6130")]
        RMA6130,

        /// <summary>
        ///Balcony: Mountain View
        /// RMA6131.
        /// </summary>
        [EnumMember(Value = "RMA6131")]
        RMA6131,

        /// <summary>
        ///Fireplace: Wood burning
        /// RMA6132.
        /// </summary>
        [EnumMember(Value = "RMA6132")]
        RMA6132,

        /// <summary>
        ///Fireplace: Gas
        /// RMA6133.
        /// </summary>
        [EnumMember(Value = "RMA6133")]
        RMA6133,

        /// <summary>
        ///Fireplace: Electric
        /// RMA6134.
        /// </summary>
        [EnumMember(Value = "RMA6134")]
        RMA6134,

        /// <summary>
        ///Pizza Oven
        /// RMA6135.
        /// </summary>
        [EnumMember(Value = "RMA6135")]
        RMA6135,

        /// <summary>
        ///Air Conditioning: Central
        /// RMA6136.
        /// </summary>
        [EnumMember(Value = "RMA6136")]
        RMA6136,

        /// <summary>
        ///Air Conditioning: Partial
        /// RMA6137.
        /// </summary>
        [EnumMember(Value = "RMA6137")]
        RMA6137,

        /// <summary>
        ///RMA6138 Air Conditioning: In rooms
        /// RMA6138.
        /// </summary>
        [EnumMember(Value = "RMA6138")]
        RMA6138,

        /// <summary>
        ///Baby Crib
        /// RMA6139.
        /// </summary>
        [EnumMember(Value = "RMA6139")]
        RMA6139,

        /// <summary>
        ///Barbeque Grill: Gas
        /// RMA6140.
        /// </summary>
        [EnumMember(Value = "RMA6140")]
        RMA6140,

        /// <summary>
        ///Barbeque Grill: Propane
        /// RMA6141.
        /// </summary>
        [EnumMember(Value = "RMA6141")]
        RMA6141,

        /// <summary>
        ///Barbeque Grill: Charcoal
        /// RMA6142.
        /// </summary>
        [EnumMember(Value = "RMA6142")]
        RMA6142,

        /// <summary>
        ///Premium Linens & Towels
        /// RMA6144.
        /// </summary>
        [EnumMember(Value = "RMA6144")]
        RMA6144,

        /// <summary>
        ///Kitchen Essentials
        /// RMA6145.
        /// </summary>
        [EnumMember(Value = "RMA6145")]
        RMA6145,

        /// <summary>
        ///In-unit Washer
        /// RMA6146.
        /// </summary>
        [EnumMember(Value = "RMA6146")]
        RMA6146,

        /// <summary>
        ///Self-controlled heating/cooling system
        /// RMA6147.
        /// </summary>
        [EnumMember(Value = "RMA6147")]
        RMA6147,

        /// <summary>
        ///Private living room
        /// RMA6148.
        /// </summary>
        [EnumMember(Value = "RMA6148")]
        RMA6148,

        /// <summary>
        ///Amenity toilet
        /// RMA6149.
        /// </summary>
        [EnumMember(Value = "RMA6149")]
        RMA6149,

        /// <summary>
        ///Amenity combo tub shower
        /// RMA6150.
        /// </summary>
        [EnumMember(Value = "RMA6150")]
        RMA6150,

        /// <summary>
        ///Amenity outdoor shower
        /// RMA6151.
        /// </summary>
        [EnumMember(Value = "RMA6151")]
        RMA6151,

        /// <summary>
        ///Entertainment Books
        /// RMA6154.
        /// </summary>
        [EnumMember(Value = "RMA6154")]
        RMA6154,

        /// <summary>
        ///Entertainment Toys
        /// RMA6155.
        /// </summary>
        [EnumMember(Value = "RMA6155")]
        RMA6155,

        /// <summary>
        ///Security System
        /// RMA6156.
        /// </summary>
        [EnumMember(Value = "RMA6156")]
        RMA6156,

        /// <summary>
        ///Private Dock
        /// RMA6157.
        /// </summary>
        [EnumMember(Value = "RMA6157")]
        RMA6157,

        /// <summary>
        ///Indoor Fireplace
        /// RMA6158.
        /// </summary>
        [EnumMember(Value = "RMA6158")]
        RMA6158,

        /// <summary>
        ///Laptop
        /// RMA63.
        /// </summary>
        [EnumMember(Value = "RMA63")]
        RMA63,

        /// <summary>
        ///Large desk
        /// RMA64.
        /// </summary>
        [EnumMember(Value = "RMA64")]
        RMA64,

        /// <summary>
        ///Loft
        /// RMA67.
        /// </summary>
        [EnumMember(Value = "RMA67")]
        RMA67,

        /// <summary>
        ///Microwave
        /// RMA68.
        /// </summary>
        [EnumMember(Value = "RMA68")]
        RMA68,

        /// <summary>
        ///Minibar
        /// RMA69.
        /// </summary>
        [EnumMember(Value = "RMA69")]
        RMA69,

        /// <summary>
        ///Balcony/Lanai/Terrace
        /// RMA7.
        /// </summary>
        [EnumMember(Value = "RMA7")]
        RMA7,

        /// <summary>
        ///Multi-line phone
        /// RMA72.
        /// </summary>
        [EnumMember(Value = "RMA72")]
        RMA72,

        /// <summary>
        ///Oven
        /// RMA77.
        /// </summary>
        [EnumMember(Value = "RMA77")]
        RMA77,

        /// <summary>
        ///Pay per view movies on TV
        /// RMA78.
        /// </summary>
        [EnumMember(Value = "RMA78")]
        RMA78,

        /// <summary>
        ///Barbeque grills
        /// RMA8.
        /// </summary>
        [EnumMember(Value = "RMA8")]
        RMA8,

        /// <summary>
        ///Phone in bathroom
        /// RMA80.
        /// </summary>
        [EnumMember(Value = "RMA80")]
        RMA80,

        /// <summary>
        ///Plates and bowls
        /// RMA81.
        /// </summary>
        [EnumMember(Value = "RMA81")]
        RMA81,

        /// <summary>
        ///Private bathroom
        /// RMA85.
        /// </summary>
        [EnumMember(Value = "RMA85")]
        RMA85,

        /// <summary>
        ///Queen bed
        /// RMA86.
        /// </summary>
        [EnumMember(Value = "RMA86")]
        RMA86,

        /// <summary>
        ///Refrigerator
        /// RMA88.
        /// </summary>
        [EnumMember(Value = "RMA88")]
        RMA88,

        /// <summary>
        ///Refrigerator with ice maker
        /// RMA89.
        /// </summary>
        [EnumMember(Value = "RMA89")]
        RMA89,

        /// <summary>
        ///Bath tub with spray jets
        /// RMA9.
        /// </summary>
        [EnumMember(Value = "RMA9")]
        RMA9,

        /// <summary>
        ///Rollaway bed
        /// RMA91.
        /// </summary>
        [EnumMember(Value = "RMA91")]
        RMA91,

        /// <summary>
        ///Safe
        /// RMA92.
        /// </summary>
        [EnumMember(Value = "RMA92")]
        RMA92,

        /// <summary>
        ///Separate closet
        /// RMA94.
        /// </summary>
        [EnumMember(Value = "RMA94")]
        RMA94,

        /// <summary>
        ///Shower only
        /// RMA97.
        /// </summary>
        [EnumMember(Value = "RMA97")]
        RMA97,

        /// <summary>
        ///Silverware/utensils
        /// RMA98.
        /// </summary>
        [EnumMember(Value = "RMA98")]
        RMA98,

        /// <summary>
        ///Sitting area
        /// RMA99.
        /// </summary>
        [EnumMember(Value = "RMA99")]
        RMA99,

        /// <summary>
        ///Windsurfing
        /// RST101.
        /// </summary>
        [EnumMember(Value = "RST101")]
        RST101,

        /// <summary>
        ///Hot tub
        /// RST104.
        /// </summary>
        [EnumMember(Value = "RST104")]
        RST104,

        /// <summary>
        ///Hunting
        /// RST105.
        /// </summary>
        [EnumMember(Value = "RST105")]
        RST105,

        /// <summary>
        ///Mountain climbing
        /// RST108.
        /// </summary>
        [EnumMember(Value = "RST108")]
        RST108,

        /// <summary>
        ///Billiards
        /// RST111.
        /// </summary>
        [EnumMember(Value = "RST111")]
        RST111,

        /// <summary>
        ///Rock climbing
        /// RST112.
        /// </summary>
        [EnumMember(Value = "RST112")]
        RST112,

        /// <summary>
        ///Surfing
        /// RST116.
        /// </summary>
        [EnumMember(Value = "RST116")]
        RST116,

        /// <summary>
        ///Table tennis
        /// RST117.
        /// </summary>
        [EnumMember(Value = "RST117")]
        RST117,

        /// <summary>
        ///Snow mobiling
        /// RST120.
        /// </summary>
        [EnumMember(Value = "RST120")]
        RST120,

        /// <summary>
        ///Outdoor pool
        /// RST123.
        /// </summary>
        [EnumMember(Value = "RST123")]
        RST123,

        /// <summary>
        ///Bird watching
        /// RST127.
        /// </summary>
        [EnumMember(Value = "RST127")]
        RST127,

        /// <summary>
        ///Children's pool
        /// RST129.
        /// </summary>
        [EnumMember(Value = "RST129")]
        RST129,

        /// <summary>
        ///Cross country skiing
        /// RST13.
        /// </summary>
        [EnumMember(Value = "RST13")]
        RST13,

        /// <summary>
        ///Gambling
        /// RST133.
        /// </summary>
        [EnumMember(Value = "RST133")]
        RST133,

        /// <summary>
        ///Garden
        /// RST134.
        /// </summary>
        [EnumMember(Value = "RST134")]
        RST134,

        /// <summary>
        ///Ice skating
        /// RST137.
        /// </summary>
        [EnumMember(Value = "RST137")]
        RST137,

        /// <summary>
        ///Dart board
        /// RST14.
        /// </summary>
        [EnumMember(Value = "RST14")]
        RST14,

        /// <summary>
        ///Canoeing
        /// RST149.
        /// </summary>
        [EnumMember(Value = "RST149")]
        RST149,

        /// <summary>
        ///Outlet shopping
        /// RST151.
        /// </summary>
        [EnumMember(Value = "RST151")]
        RST151,

        /// <summary>
        ///Ski in/out facilities
        /// RST156.
        /// </summary>
        [EnumMember(Value = "RST156")]
        RST156,

        /// <summary>
        ///Tennis professional
        /// RST157.
        /// </summary>
        [EnumMember(Value = "RST157")]
        RST157,

        /// <summary>
        ///Diving
        /// RST160.
        /// </summary>
        [EnumMember(Value = "RST160")]
        RST160,

        /// <summary>
        ///Walking track
        /// RST161.
        /// </summary>
        [EnumMember(Value = "RST161")]
        RST161,

        /// <summary>
        ///Bikes Available (Free)
        /// RST169.
        /// </summary>
        [EnumMember(Value = "RST169")]
        RST169,

        /// <summary>
        ///Away from it all
        /// RST170.
        /// </summary>
        [EnumMember(Value = "RST170")]
        RST170,

        /// <summary>
        ///Budget
        /// RST171.
        /// </summary>
        [EnumMember(Value = "RST171")]
        RST171,

        /// <summary>
        ///Farm holidays
        /// RST172.
        /// </summary>
        [EnumMember(Value = "RST172")]
        RST172,

        /// <summary>
        ///Historic
        /// RST173.
        /// </summary>
        [EnumMember(Value = "RST173")]
        RST173,

        /// <summary>
        ///Holiday complex
        /// RST174.
        /// </summary>
        [EnumMember(Value = "RST174")]
        RST174,

        /// <summary>
        ///Romantic
        /// RST175.
        /// </summary>
        [EnumMember(Value = "RST175")]
        RST175,

        /// <summary>
        ///Tourist attractions
        /// RST176.
        /// </summary>
        [EnumMember(Value = "RST176")]
        RST176,

        /// <summary>
        ///Eco tourism
        /// RST177.
        /// </summary>
        [EnumMember(Value = "RST177")]
        RST177,

        /// <summary>
        ///Luaus
        /// RST178.
        /// </summary>
        [EnumMember(Value = "RST178")]
        RST178,

        /// <summary>
        ///Paddle boating
        /// RST179.
        /// </summary>
        [EnumMember(Value = "RST179")]
        RST179,

        /// <summary>
        ///Sledding
        /// RST180.
        /// </summary>
        [EnumMember(Value = "RST180")]
        RST180,

        /// <summary>
        ///Thermalisme
        /// RST181.
        /// </summary>
        [EnumMember(Value = "RST181")]
        RST181,

        /// <summary>
        ///Whale watching
        /// RST182.
        /// </summary>
        [EnumMember(Value = "RST182")]
        RST182,

        /// <summary>
        ///Hot air ballooning
        /// RST183.
        /// </summary>
        [EnumMember(Value = "RST183")]
        RST183,

        /// <summary>
        ///Shelling
        /// RST184.
        /// </summary>
        [EnumMember(Value = "RST184")]
        RST184,

        /// <summary>
        ///Adventure
        /// RST185.
        /// </summary>
        [EnumMember(Value = "RST185")]
        RST185,

        /// <summary>
        ///Rural countryside retreats
        /// RST186.
        /// </summary>
        [EnumMember(Value = "RST186")]
        RST186,

        /// <summary>
        ///Trampoline
        /// RST187.
        /// </summary>
        [EnumMember(Value = "RST187")]
        RST187,

        /// <summary>
        ///Fishing
        /// RST20.
        /// </summary>
        [EnumMember(Value = "RST20")]
        RST20,

        /// <summary>
        ///Fly fishing
        /// RST25.
        /// </summary>
        [EnumMember(Value = "RST25")]
        RST25,

        /// <summary>
        ///Golf
        /// RST34.
        /// </summary>
        [EnumMember(Value = "RST34")]
        RST34,

        /// <summary>
        ///Gym
        /// RST35.
        /// </summary>
        [EnumMember(Value = "RST35")]
        RST35,

        /// <summary>
        ///Basketball court
        /// RST4.
        /// </summary>
        [EnumMember(Value = "RST4")]
        RST4,

        /// <summary>
        ///Ski-to-door access
        /// RST5028.
        /// </summary>
        [EnumMember(Value = "RST5028")]
        RST5028,

        /// <summary>
        ///Hiking trail
        /// RST60.
        /// </summary>
        [EnumMember(Value = "RST60")]
        RST60,

        /// <summary>
        ///Jet-ski
        /// RST63.
        /// </summary>
        [EnumMember(Value = "RST63")]
        RST63,

        /// <summary>
        ///Kayaking
        /// RST65.
        /// </summary>
        [EnumMember(Value = "RST65")]
        RST65,

        /// <summary>
        ///Miniature golf
        /// RST67.
        /// </summary>
        [EnumMember(Value = "RST67")]
        RST67,

        /// <summary>
        ///Mountain biking trail
        /// RST68.
        /// </summary>
        [EnumMember(Value = "RST68")]
        RST68,

        /// <summary>
        ///Boating
        /// RST7.
        /// </summary>
        [EnumMember(Value = "RST7")]
        RST7,

        /// <summary>
        ///Outdoor tennis courts
        /// RST71.
        /// </summary>
        [EnumMember(Value = "RST71")]
        RST71,

        /// <summary>
        ///Parasailing
        /// RST73.
        /// </summary>
        [EnumMember(Value = "RST73")]
        RST73,

        /// <summary>
        ///Playground
        /// RST74.
        /// </summary>
        [EnumMember(Value = "RST74")]
        RST74,

        /// <summary>
        ///River rafting
        /// RST79.
        /// </summary>
        [EnumMember(Value = "RST79")]
        RST79,

        /// <summary>
        ///Sailing
        /// RST80.
        /// </summary>
        [EnumMember(Value = "RST80")]
        RST80,

        /// <summary>
        ///Scuba diving
        /// RST82.
        /// </summary>
        [EnumMember(Value = "RST82")]
        RST82,

        /// <summary>
        ///Snorkeling
        /// RST86.
        /// </summary>
        [EnumMember(Value = "RST86")]
        RST86,

        /// <summary>
        ///Snow boarding
        /// RST87.
        /// </summary>
        [EnumMember(Value = "RST87")]
        RST87,

        /// <summary>
        ///Bowling alley
        /// RST9.
        /// </summary>
        [EnumMember(Value = "RST9")]
        RST9,

        /// <summary>
        ///Squash court
        /// RST92.
        /// </summary>
        [EnumMember(Value = "RST92")]
        RST92,

        /// <summary>
        ///Tubing
        /// RST96.
        /// </summary>
        [EnumMember(Value = "RST96")]
        RST96
    }
}