// <copyright file="FeeTaxMandatory.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace SupplierAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using SupplierAPI.Standard;
    using SupplierAPI.Standard.Utilities;

    /// <summary>
    /// FeeTaxMandatory.
    /// </summary>
    public class FeeTaxMandatory
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="FeeTaxMandatory"/> class.
        /// </summary>
        public FeeTaxMandatory()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="FeeTaxMandatory"/> class.
        /// </summary>
        /// <param name="isFeeMandatory">isFeeMandatory.</param>
        /// <param name="isTaxMandatory">isTaxMandatory.</param>
        public FeeTaxMandatory(
            bool isFeeMandatory,
            bool isTaxMandatory)
        {
            this.IsFeeMandatory = isFeeMandatory;
            this.IsTaxMandatory = isTaxMandatory;
        }

        /// <summary>
        /// Used in BookingPal validator. Info does property require any fee or not. Default value is TRUE. This setup can be overridden on property level with different API call, which is stronger.
        /// </summary>
        [JsonProperty("isFeeMandatory")]
        public bool IsFeeMandatory { get; set; }

        /// <summary>
        /// Used in BookingPal validator. Info does property require any tax or not. Default value is TRUE. This setup can be overridden on property level with different API call, which is stronger.
        /// </summary>
        [JsonProperty("isTaxMandatory")]
        public bool IsTaxMandatory { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"FeeTaxMandatory : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is FeeTaxMandatory other &&
                this.IsFeeMandatory.Equals(other.IsFeeMandatory) &&
                this.IsTaxMandatory.Equals(other.IsTaxMandatory);
        }
        

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.IsFeeMandatory = {this.IsFeeMandatory}");
            toStringOutput.Add($"this.IsTaxMandatory = {this.IsTaxMandatory}");
        }
    }
}