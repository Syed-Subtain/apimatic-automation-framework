// <copyright file="AcceptsPropertyTypeEnum.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace SupplierAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Runtime.Serialization;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using SupplierAPI.Standard;
    using SupplierAPI.Standard.Utilities;

    /// <summary>
    /// AcceptsPropertyTypeEnum.
    /// </summary>
    [JsonConverter(typeof(StringEnumConverter))]
    public enum AcceptsPropertyTypeEnum
    {
        /// <summary>
        /// HomesAndApartments.
        /// </summary>
        [EnumMember(Value = "HomesAndApartments")]
        HomesAndApartments,

        /// <summary>
        /// Hotels.
        /// </summary>
        [EnumMember(Value = "Hotels")]
        Hotels,

        /// <summary>
        /// Both.
        /// </summary>
        [EnumMember(Value = "Both")]
        Both
    }
}