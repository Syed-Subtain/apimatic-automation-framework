// <copyright file="MessageRequestFromSupplier.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace SupplierAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using SupplierAPI.Standard;
    using SupplierAPI.Standard.Utilities;

    /// <summary>
    /// MessageRequestFromSupplier.
    /// </summary>
    public class MessageRequestFromSupplier
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="MessageRequestFromSupplier"/> class.
        /// </summary>
        public MessageRequestFromSupplier()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="MessageRequestFromSupplier"/> class.
        /// </summary>
        /// <param name="threadId">threadId.</param>
        /// <param name="message">message.</param>
        public MessageRequestFromSupplier(
            int threadId,
            string message)
        {
            this.ThreadId = threadId;
            this.Message = message;
        }

        /// <summary>
        /// ID of thread
        /// </summary>
        [JsonProperty("threadId")]
        public int ThreadId { get; set; }

        /// <summary>
        /// Message text
        /// </summary>
        [JsonProperty("message")]
        public string Message { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"MessageRequestFromSupplier : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is MessageRequestFromSupplier other &&
                this.ThreadId.Equals(other.ThreadId) &&
                ((this.Message == null && other.Message == null) || (this.Message?.Equals(other.Message) == true));
        }
        

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.ThreadId = {this.ThreadId}");
            toStringOutput.Add($"this.Message = {(this.Message == null ? "null" : this.Message == string.Empty ? "" : this.Message)}");
        }
    }
}