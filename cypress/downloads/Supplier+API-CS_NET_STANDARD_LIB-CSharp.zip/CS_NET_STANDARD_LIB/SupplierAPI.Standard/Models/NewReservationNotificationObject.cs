// <copyright file="NewReservationNotificationObject.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace SupplierAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using SupplierAPI.Standard;
    using SupplierAPI.Standard.Utilities;

    /// <summary>
    /// NewReservationNotificationObject.
    /// </summary>
    public class NewReservationNotificationObject
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="NewReservationNotificationObject"/> class.
        /// </summary>
        public NewReservationNotificationObject()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="NewReservationNotificationObject"/> class.
        /// </summary>
        /// <param name="reservationId">reservationId.</param>
        /// <param name="productId">productId.</param>
        /// <param name="supplierId">supplierId.</param>
        /// <param name="channelName">channelName.</param>
        /// <param name="confirmationId">confirmationId.</param>
        /// <param name="uniqueKey">uniqueKey.</param>
        /// <param name="newState">newState.</param>
        /// <param name="customerName">customerName.</param>
        /// <param name="fromDate">fromDate.</param>
        /// <param name="toDate">toDate.</param>
        /// <param name="adult">adult.</param>
        /// <param name="child">child.</param>
        /// <param name="email">email.</param>
        /// <param name="total">total.</param>
        /// <param name="address">address.</param>
        /// <param name="city">city.</param>
        /// <param name="zip">zip.</param>
        /// <param name="country">country.</param>
        /// <param name="state">state.</param>
        /// <param name="phone">phone.</param>
        /// <param name="notes">notes.</param>
        /// <param name="creditCardType">creditCardType.</param>
        /// <param name="creditCardNumber">creditCardNumber.</param>
        /// <param name="creditCardExpirationMonth">creditCardExpirationMonth.</param>
        /// <param name="creditCardExpirationYear">creditCardExpirationYear.</param>
        /// <param name="creditCardCid">creditCardCid.</param>
        /// <param name="fees">fees.</param>
        /// <param name="taxes">taxes.</param>
        /// <param name="commission">commission.</param>
        /// <param name="rate">rate.</param>
        public NewReservationNotificationObject(
            string reservationId,
            string productId,
            string supplierId,
            string channelName,
            string confirmationId,
            string uniqueKey,
            Models.ReservationStateEnum newState,
            string customerName,
            DateTime fromDate,
            DateTime toDate,
            int adult,
            int child,
            string email,
            double total,
            string address = null,
            string city = null,
            string zip = null,
            string country = null,
            string state = null,
            string phone = null,
            string notes = null,
            Models.CreditCardListEnum? creditCardType = null,
            string creditCardNumber = null,
            string creditCardExpirationMonth = null,
            string creditCardExpirationYear = null,
            string creditCardCid = null,
            List<Models.ReservationFeeNotificationModel> fees = null,
            List<Models.ReservationTaxNotificationModel> taxes = null,
            Models.ReservationCommissionsNotificationModel commission = null,
            Models.ReservationRateNotifcationModel rate = null)
        {
            this.ReservationId = reservationId;
            this.ProductId = productId;
            this.SupplierId = supplierId;
            this.ChannelName = channelName;
            this.ConfirmationId = confirmationId;
            this.UniqueKey = uniqueKey;
            this.NewState = newState;
            this.CustomerName = customerName;
            this.FromDate = fromDate;
            this.ToDate = toDate;
            this.Adult = adult;
            this.Child = child;
            this.Address = address;
            this.City = city;
            this.Zip = zip;
            this.Country = country;
            this.State = state;
            this.Email = email;
            this.Phone = phone;
            this.Notes = notes;
            this.CreditCardType = creditCardType;
            this.CreditCardNumber = creditCardNumber;
            this.CreditCardExpirationMonth = creditCardExpirationMonth;
            this.CreditCardExpirationYear = creditCardExpirationYear;
            this.CreditCardCid = creditCardCid;
            this.Total = total;
            this.Fees = fees;
            this.Taxes = taxes;
            this.Commission = commission;
            this.Rate = rate;
        }

        /// <summary>
        /// Id of the reservation in BookingPal
        /// </summary>
        [JsonProperty("reservationId")]
        public string ReservationId { get; set; }

        /// <summary>
        /// Id of the product in BookingPal
        /// </summary>
        [JsonProperty("productId")]
        public string ProductId { get; set; }

        /// <summary>
        /// Id of the property manager
        /// </summary>
        [JsonProperty("supplierId")]
        public string SupplierId { get; set; }

        /// <summary>
        /// Channel name
        /// </summary>
        [JsonProperty("channelName")]
        public string ChannelName { get; set; }

        /// <summary>
        /// Channel confirmation code
        /// </summary>
        [JsonProperty("confirmationId")]
        public string ConfirmationId { get; set; }

        /// <summary>
        /// Unique code to identify that the request is from BookingPal. This value is unique for every PMS (and it will be different in different environments).
        /// </summary>
        [JsonProperty("uniqueKey")]
        public string UniqueKey { get; set; }

        /// <summary>
        /// Possible Reservation states
        /// </summary>
        [JsonProperty("newState", ItemConverterType = typeof(StringEnumConverter))]
        public Models.ReservationStateEnum NewState { get; set; }

        /// <summary>
        /// Guest full name (in format firstName lastName)
        /// </summary>
        [JsonProperty("customerName")]
        public string CustomerName { get; set; }

        /// <summary>
        /// Reservation date from. Date is in format "yyyy-MM-dd"
        /// </summary>
        [JsonConverter(typeof(CustomDateTimeConverter), "yyyy'-'MM'-'dd")]
        [JsonProperty("fromDate")]
        public DateTime FromDate { get; set; }

        /// <summary>
        /// Reservation date to. Date is in format "yyyy-MM-dd"
        /// </summary>
        [JsonConverter(typeof(CustomDateTimeConverter), "yyyy'-'MM'-'dd")]
        [JsonProperty("toDate")]
        public DateTime ToDate { get; set; }

        /// <summary>
        /// number of adults
        /// </summary>
        [JsonProperty("adult")]
        public int Adult { get; set; }

        /// <summary>
        /// number of children
        /// </summary>
        [JsonProperty("child")]
        public int Child { get; set; }

        /// <summary>
        /// Guest address
        /// </summary>
        [JsonProperty("address", NullValueHandling = NullValueHandling.Ignore)]
        public string Address { get; set; }

        /// <summary>
        /// Guest city
        /// </summary>
        [JsonProperty("city", NullValueHandling = NullValueHandling.Ignore)]
        public string City { get; set; }

        /// <summary>
        /// Guest zip code
        /// </summary>
        [JsonProperty("zip", NullValueHandling = NullValueHandling.Ignore)]
        public string Zip { get; set; }

        /// <summary>
        /// Guest country
        /// </summary>
        [JsonProperty("country", NullValueHandling = NullValueHandling.Ignore)]
        public string Country { get; set; }

        /// <summary>
        /// Guest state
        /// </summary>
        [JsonProperty("state", NullValueHandling = NullValueHandling.Ignore)]
        public string State { get; set; }

        /// <summary>
        /// Guest email
        /// </summary>
        [JsonProperty("email")]
        public string Email { get; set; }

        /// <summary>
        /// Guest phone
        /// </summary>
        [JsonProperty("phone", NullValueHandling = NullValueHandling.Ignore)]
        public string Phone { get; set; }

        /// <summary>
        /// Guest notes
        /// </summary>
        [JsonProperty("notes", NullValueHandling = NullValueHandling.Ignore)]
        public string Notes { get; set; }

        /// <summary>
        /// Gets or sets CreditCardType.
        /// </summary>
        [JsonProperty("creditCardType", ItemConverterType = typeof(StringEnumConverter), NullValueHandling = NullValueHandling.Ignore)]
        public Models.CreditCardListEnum? CreditCardType { get; set; }

        /// <summary>
        /// Credit card number
        /// </summary>
        [JsonProperty("creditCardNumber", NullValueHandling = NullValueHandling.Ignore)]
        public string CreditCardNumber { get; set; }

        /// <summary>
        /// Credit card expiration month
        /// </summary>
        [JsonProperty("creditCardExpirationMonth", NullValueHandling = NullValueHandling.Ignore)]
        public string CreditCardExpirationMonth { get; set; }

        /// <summary>
        /// Credit card expiration yea
        /// </summary>
        [JsonProperty("creditCardExpirationYear", NullValueHandling = NullValueHandling.Ignore)]
        public string CreditCardExpirationYear { get; set; }

        /// <summary>
        /// Credit card cid
        /// </summary>
        [JsonProperty("creditCardCid", NullValueHandling = NullValueHandling.Ignore)]
        public string CreditCardCid { get; set; }

        /// <summary>
        /// Best available rate (This is the total value that guests will pay, including rate, fees, taxes, and all commissions. )
        /// </summary>
        [JsonProperty("total")]
        public double Total { get; set; }

        /// <summary>
        /// List of models
        /// </summary>
        [JsonProperty("fees", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.ReservationFeeNotificationModel> Fees { get; set; }

        /// <summary>
        /// List of models
        /// </summary>
        [JsonProperty("taxes", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.ReservationTaxNotificationModel> Taxes { get; set; }

        /// <summary>
        /// Gets or sets Commission.
        /// </summary>
        [JsonProperty("commission", NullValueHandling = NullValueHandling.Ignore)]
        public Models.ReservationCommissionsNotificationModel Commission { get; set; }

        /// <summary>
        /// Gets or sets Rate.
        /// </summary>
        [JsonProperty("rate", NullValueHandling = NullValueHandling.Ignore)]
        public Models.ReservationRateNotifcationModel Rate { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"NewReservationNotificationObject : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is NewReservationNotificationObject other &&
                ((this.ReservationId == null && other.ReservationId == null) || (this.ReservationId?.Equals(other.ReservationId) == true)) &&
                ((this.ProductId == null && other.ProductId == null) || (this.ProductId?.Equals(other.ProductId) == true)) &&
                ((this.SupplierId == null && other.SupplierId == null) || (this.SupplierId?.Equals(other.SupplierId) == true)) &&
                ((this.ChannelName == null && other.ChannelName == null) || (this.ChannelName?.Equals(other.ChannelName) == true)) &&
                ((this.ConfirmationId == null && other.ConfirmationId == null) || (this.ConfirmationId?.Equals(other.ConfirmationId) == true)) &&
                ((this.UniqueKey == null && other.UniqueKey == null) || (this.UniqueKey?.Equals(other.UniqueKey) == true)) &&
                this.NewState.Equals(other.NewState) &&
                ((this.CustomerName == null && other.CustomerName == null) || (this.CustomerName?.Equals(other.CustomerName) == true)) &&
                this.FromDate.Equals(other.FromDate) &&
                this.ToDate.Equals(other.ToDate) &&
                this.Adult.Equals(other.Adult) &&
                this.Child.Equals(other.Child) &&
                ((this.Address == null && other.Address == null) || (this.Address?.Equals(other.Address) == true)) &&
                ((this.City == null && other.City == null) || (this.City?.Equals(other.City) == true)) &&
                ((this.Zip == null && other.Zip == null) || (this.Zip?.Equals(other.Zip) == true)) &&
                ((this.Country == null && other.Country == null) || (this.Country?.Equals(other.Country) == true)) &&
                ((this.State == null && other.State == null) || (this.State?.Equals(other.State) == true)) &&
                ((this.Email == null && other.Email == null) || (this.Email?.Equals(other.Email) == true)) &&
                ((this.Phone == null && other.Phone == null) || (this.Phone?.Equals(other.Phone) == true)) &&
                ((this.Notes == null && other.Notes == null) || (this.Notes?.Equals(other.Notes) == true)) &&
                ((this.CreditCardType == null && other.CreditCardType == null) || (this.CreditCardType?.Equals(other.CreditCardType) == true)) &&
                ((this.CreditCardNumber == null && other.CreditCardNumber == null) || (this.CreditCardNumber?.Equals(other.CreditCardNumber) == true)) &&
                ((this.CreditCardExpirationMonth == null && other.CreditCardExpirationMonth == null) || (this.CreditCardExpirationMonth?.Equals(other.CreditCardExpirationMonth) == true)) &&
                ((this.CreditCardExpirationYear == null && other.CreditCardExpirationYear == null) || (this.CreditCardExpirationYear?.Equals(other.CreditCardExpirationYear) == true)) &&
                ((this.CreditCardCid == null && other.CreditCardCid == null) || (this.CreditCardCid?.Equals(other.CreditCardCid) == true)) &&
                this.Total.Equals(other.Total) &&
                ((this.Fees == null && other.Fees == null) || (this.Fees?.Equals(other.Fees) == true)) &&
                ((this.Taxes == null && other.Taxes == null) || (this.Taxes?.Equals(other.Taxes) == true)) &&
                ((this.Commission == null && other.Commission == null) || (this.Commission?.Equals(other.Commission) == true)) &&
                ((this.Rate == null && other.Rate == null) || (this.Rate?.Equals(other.Rate) == true));
        }
        

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.ReservationId = {(this.ReservationId == null ? "null" : this.ReservationId == string.Empty ? "" : this.ReservationId)}");
            toStringOutput.Add($"this.ProductId = {(this.ProductId == null ? "null" : this.ProductId == string.Empty ? "" : this.ProductId)}");
            toStringOutput.Add($"this.SupplierId = {(this.SupplierId == null ? "null" : this.SupplierId == string.Empty ? "" : this.SupplierId)}");
            toStringOutput.Add($"this.ChannelName = {(this.ChannelName == null ? "null" : this.ChannelName == string.Empty ? "" : this.ChannelName)}");
            toStringOutput.Add($"this.ConfirmationId = {(this.ConfirmationId == null ? "null" : this.ConfirmationId == string.Empty ? "" : this.ConfirmationId)}");
            toStringOutput.Add($"this.UniqueKey = {(this.UniqueKey == null ? "null" : this.UniqueKey == string.Empty ? "" : this.UniqueKey)}");
            toStringOutput.Add($"this.NewState = {this.NewState}");
            toStringOutput.Add($"this.CustomerName = {(this.CustomerName == null ? "null" : this.CustomerName == string.Empty ? "" : this.CustomerName)}");
            toStringOutput.Add($"this.FromDate = {this.FromDate}");
            toStringOutput.Add($"this.ToDate = {this.ToDate}");
            toStringOutput.Add($"this.Adult = {this.Adult}");
            toStringOutput.Add($"this.Child = {this.Child}");
            toStringOutput.Add($"this.Address = {(this.Address == null ? "null" : this.Address == string.Empty ? "" : this.Address)}");
            toStringOutput.Add($"this.City = {(this.City == null ? "null" : this.City == string.Empty ? "" : this.City)}");
            toStringOutput.Add($"this.Zip = {(this.Zip == null ? "null" : this.Zip == string.Empty ? "" : this.Zip)}");
            toStringOutput.Add($"this.Country = {(this.Country == null ? "null" : this.Country == string.Empty ? "" : this.Country)}");
            toStringOutput.Add($"this.State = {(this.State == null ? "null" : this.State == string.Empty ? "" : this.State)}");
            toStringOutput.Add($"this.Email = {(this.Email == null ? "null" : this.Email == string.Empty ? "" : this.Email)}");
            toStringOutput.Add($"this.Phone = {(this.Phone == null ? "null" : this.Phone == string.Empty ? "" : this.Phone)}");
            toStringOutput.Add($"this.Notes = {(this.Notes == null ? "null" : this.Notes == string.Empty ? "" : this.Notes)}");
            toStringOutput.Add($"this.CreditCardType = {(this.CreditCardType == null ? "null" : this.CreditCardType.ToString())}");
            toStringOutput.Add($"this.CreditCardNumber = {(this.CreditCardNumber == null ? "null" : this.CreditCardNumber == string.Empty ? "" : this.CreditCardNumber)}");
            toStringOutput.Add($"this.CreditCardExpirationMonth = {(this.CreditCardExpirationMonth == null ? "null" : this.CreditCardExpirationMonth == string.Empty ? "" : this.CreditCardExpirationMonth)}");
            toStringOutput.Add($"this.CreditCardExpirationYear = {(this.CreditCardExpirationYear == null ? "null" : this.CreditCardExpirationYear == string.Empty ? "" : this.CreditCardExpirationYear)}");
            toStringOutput.Add($"this.CreditCardCid = {(this.CreditCardCid == null ? "null" : this.CreditCardCid == string.Empty ? "" : this.CreditCardCid)}");
            toStringOutput.Add($"this.Total = {this.Total}");
            toStringOutput.Add($"this.Fees = {(this.Fees == null ? "null" : $"[{string.Join(", ", this.Fees)} ]")}");
            toStringOutput.Add($"this.Taxes = {(this.Taxes == null ? "null" : $"[{string.Join(", ", this.Taxes)} ]")}");
            toStringOutput.Add($"this.Commission = {(this.Commission == null ? "null" : this.Commission.ToString())}");
            toStringOutput.Add($"this.Rate = {(this.Rate == null ? "null" : this.Rate.ToString())}");
        }
    }
}