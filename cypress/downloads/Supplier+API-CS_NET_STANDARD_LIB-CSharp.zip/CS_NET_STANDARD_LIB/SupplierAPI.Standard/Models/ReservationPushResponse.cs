// <copyright file="ReservationPushResponse.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace SupplierAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using SupplierAPI.Standard;
    using SupplierAPI.Standard.Utilities;

    /// <summary>
    /// ReservationPushResponse.
    /// </summary>
    public class ReservationPushResponse
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ReservationPushResponse"/> class.
        /// </summary>
        public ReservationPushResponse()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ReservationPushResponse"/> class.
        /// </summary>
        /// <param name="altId">altId.</param>
        /// <param name="isError">is_error.</param>
        /// <param name="code">code.</param>
        /// <param name="message">message.</param>
        public ReservationPushResponse(
            string altId,
            bool isError,
            string code,
            string message)
        {
            this.AltId = altId;
            this.IsError = isError;
            this.Code = code;
            this.Message = message;
        }

        /// <summary>
        /// Id of reservation in your system
        /// </summary>
        [JsonProperty("altId")]
        public string AltId { get; set; }

        /// <summary>
        /// Did you have error during processing of request (true) or not (false)
        /// </summary>
        [JsonProperty("is_error")]
        public bool IsError { get; set; }

        /// <summary>
        /// Code of message
        /// </summary>
        [JsonProperty("code")]
        public string Code { get; set; }

        /// <summary>
        /// Text info message. If you have any error please put here detail message.
        /// </summary>
        [JsonProperty("message")]
        public string Message { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"ReservationPushResponse : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is ReservationPushResponse other &&
                ((this.AltId == null && other.AltId == null) || (this.AltId?.Equals(other.AltId) == true)) &&
                this.IsError.Equals(other.IsError) &&
                ((this.Code == null && other.Code == null) || (this.Code?.Equals(other.Code) == true)) &&
                ((this.Message == null && other.Message == null) || (this.Message?.Equals(other.Message) == true));
        }
        

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.AltId = {(this.AltId == null ? "null" : this.AltId == string.Empty ? "" : this.AltId)}");
            toStringOutput.Add($"this.IsError = {this.IsError}");
            toStringOutput.Add($"this.Code = {(this.Code == null ? "null" : this.Code == string.Empty ? "" : this.Code)}");
            toStringOutput.Add($"this.Message = {(this.Message == null ? "null" : this.Message == string.Empty ? "" : this.Message)}");
        }
    }
}