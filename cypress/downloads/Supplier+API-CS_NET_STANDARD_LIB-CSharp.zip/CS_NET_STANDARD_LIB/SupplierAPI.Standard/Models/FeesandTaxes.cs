// <copyright file="FeesandTaxes.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace SupplierAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using SupplierAPI.Standard;
    using SupplierAPI.Standard.Utilities;

    /// <summary>
    /// FeesandTaxes.
    /// </summary>
    public class FeesandTaxes
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="FeesandTaxes"/> class.
        /// </summary>
        public FeesandTaxes()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="FeesandTaxes"/> class.
        /// </summary>
        /// <param name="productId">productId.</param>
        /// <param name="fees">fees.</param>
        /// <param name="taxes">taxes.</param>
        public FeesandTaxes(
            int productId,
            List<Models.Fee> fees = null,
            List<Models.Taxes> taxes = null)
        {
            this.ProductId = productId;
            this.Fees = fees;
            this.Taxes = taxes;
        }

        /// <summary>
        /// ID of the product
        /// </summary>
        [JsonProperty("productId")]
        public int ProductId { get; set; }

        /// <summary>
        /// List of models
        /// </summary>
        [JsonProperty("fees", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.Fee> Fees { get; set; }

        /// <summary>
        /// List of models
        /// </summary>
        [JsonProperty("taxes", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.Taxes> Taxes { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"FeesandTaxes : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is FeesandTaxes other &&
                this.ProductId.Equals(other.ProductId) &&
                ((this.Fees == null && other.Fees == null) || (this.Fees?.Equals(other.Fees) == true)) &&
                ((this.Taxes == null && other.Taxes == null) || (this.Taxes?.Equals(other.Taxes) == true));
        }
        

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.ProductId = {this.ProductId}");
            toStringOutput.Add($"this.Fees = {(this.Fees == null ? "null" : $"[{string.Join(", ", this.Fees)} ]")}");
            toStringOutput.Add($"this.Taxes = {(this.Taxes == null ? "null" : $"[{string.Join(", ", this.Taxes)} ]")}");
        }
    }
}