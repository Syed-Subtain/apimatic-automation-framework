// <copyright file="ValidationOfPropertyIDsList.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace SupplierAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using SupplierAPI.Standard;
    using SupplierAPI.Standard.Utilities;

    /// <summary>
    /// ValidationOfPropertyIDsList.
    /// </summary>
    public class ValidationOfPropertyIDsList
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ValidationOfPropertyIDsList"/> class.
        /// </summary>
        public ValidationOfPropertyIDsList()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ValidationOfPropertyIDsList"/> class.
        /// </summary>
        /// <param name="productIds">productIds.</param>
        public ValidationOfPropertyIDsList(
            List<int> productIds)
        {
            this.ProductIds = productIds;
        }

        /// <summary>
        /// List of properties for validation
        /// </summary>
        [JsonProperty("productIds")]
        public List<int> ProductIds { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"ValidationOfPropertyIDsList : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is ValidationOfPropertyIDsList other &&
                ((this.ProductIds == null && other.ProductIds == null) || (this.ProductIds?.Equals(other.ProductIds) == true));
        }
        

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.ProductIds = {(this.ProductIds == null ? "null" : $"[{string.Join(", ", this.ProductIds)} ]")}");
        }
    }
}