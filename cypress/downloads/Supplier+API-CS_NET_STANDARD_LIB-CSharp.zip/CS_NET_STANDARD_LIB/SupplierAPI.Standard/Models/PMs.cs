// <copyright file="PMs.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace SupplierAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using SupplierAPI.Standard;
    using SupplierAPI.Standard.Utilities;

    /// <summary>
    /// PMs.
    /// </summary>
    public class PMs
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="PMs"/> class.
        /// </summary>
        public PMs()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="PMs"/> class.
        /// </summary>
        /// <param name="id">id.</param>
        /// <param name="name">name.</param>
        /// <param name="extraName">extraName.</param>
        /// <param name="emailAddress">emailAddress.</param>
        public PMs(
            int id,
            string name,
            string extraName,
            string emailAddress)
        {
            this.Id = id;
            this.Name = name;
            this.ExtraName = extraName;
            this.EmailAddress = emailAddress;
        }

        /// <summary>
        /// ID of the property manager
        /// </summary>
        [JsonProperty("id")]
        public int Id { get; set; }

        /// <summary>
        /// Name of the property manager’s company
        /// </summary>
        [JsonProperty("name")]
        public string Name { get; set; }

        /// <summary>
        /// Contact person
        /// </summary>
        [JsonProperty("extraName")]
        public string ExtraName { get; set; }

        /// <summary>
        /// Email of the property manager
        /// </summary>
        [JsonProperty("emailAddress")]
        public string EmailAddress { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"PMs : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is PMs other &&
                this.Id.Equals(other.Id) &&
                ((this.Name == null && other.Name == null) || (this.Name?.Equals(other.Name) == true)) &&
                ((this.ExtraName == null && other.ExtraName == null) || (this.ExtraName?.Equals(other.ExtraName) == true)) &&
                ((this.EmailAddress == null && other.EmailAddress == null) || (this.EmailAddress?.Equals(other.EmailAddress) == true));
        }
        

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.Id = {this.Id}");
            toStringOutput.Add($"this.Name = {(this.Name == null ? "null" : this.Name == string.Empty ? "" : this.Name)}");
            toStringOutput.Add($"this.ExtraName = {(this.ExtraName == null ? "null" : this.ExtraName == string.Empty ? "" : this.ExtraName)}");
            toStringOutput.Add($"this.EmailAddress = {(this.EmailAddress == null ? "null" : this.EmailAddress == string.Empty ? "" : this.EmailAddress)}");
        }
    }
}