// <copyright file="ReservationRateNotifcationModel.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace SupplierAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using SupplierAPI.Standard;
    using SupplierAPI.Standard.Utilities;

    /// <summary>
    /// ReservationRateNotifcationModel.
    /// </summary>
    public class ReservationRateNotifcationModel
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ReservationRateNotifcationModel"/> class.
        /// </summary>
        public ReservationRateNotifcationModel()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ReservationRateNotifcationModel"/> class.
        /// </summary>
        /// <param name="originalRackRate">originalRackRate.</param>
        /// <param name="netRate">netRate.</param>
        /// <param name="newPublishedRackRate">newPublishedRackRate.</param>
        public ReservationRateNotifcationModel(
            double? originalRackRate = null,
            double? netRate = null,
            double? newPublishedRackRate = null)
        {
            this.OriginalRackRate = originalRackRate;
            this.NetRate = netRate;
            this.NewPublishedRackRate = newPublishedRackRate;
        }

        /// <summary>
        /// Original rack rate. Rate received from PMS (rate without additional channel commission or any additional markup)
        /// </summary>
        [JsonProperty("originalRackRate", NullValueHandling = NullValueHandling.Ignore)]
        public double? OriginalRackRate { get; set; }

        /// <summary>
        /// Net rate (rate which PM will get - so without any additional commissions).
        /// </summary>
        [JsonProperty("netRate", NullValueHandling = NullValueHandling.Ignore)]
        public double? NetRate { get; set; }

        /// <summary>
        /// New published rack rate (rate which guest paid - rate with all commissions).
        /// </summary>
        [JsonProperty("newPublishedRackRate", NullValueHandling = NullValueHandling.Ignore)]
        public double? NewPublishedRackRate { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"ReservationRateNotifcationModel : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is ReservationRateNotifcationModel other &&
                ((this.OriginalRackRate == null && other.OriginalRackRate == null) || (this.OriginalRackRate?.Equals(other.OriginalRackRate) == true)) &&
                ((this.NetRate == null && other.NetRate == null) || (this.NetRate?.Equals(other.NetRate) == true)) &&
                ((this.NewPublishedRackRate == null && other.NewPublishedRackRate == null) || (this.NewPublishedRackRate?.Equals(other.NewPublishedRackRate) == true));
        }
        

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.OriginalRackRate = {(this.OriginalRackRate == null ? "null" : this.OriginalRackRate.ToString())}");
            toStringOutput.Add($"this.NetRate = {(this.NetRate == null ? "null" : this.NetRate.ToString())}");
            toStringOutput.Add($"this.NewPublishedRackRate = {(this.NewPublishedRackRate == null ? "null" : this.NewPublishedRackRate.ToString())}");
        }
    }
}