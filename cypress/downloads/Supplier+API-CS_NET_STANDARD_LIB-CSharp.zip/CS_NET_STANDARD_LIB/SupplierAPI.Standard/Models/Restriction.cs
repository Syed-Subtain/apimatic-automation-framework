// <copyright file="Restriction.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace SupplierAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using SupplierAPI.Standard;
    using SupplierAPI.Standard.Utilities;

    /// <summary>
    /// Restriction.
    /// </summary>
    public class Restriction
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="Restriction"/> class.
        /// </summary>
        public Restriction()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="Restriction"/> class.
        /// </summary>
        /// <param name="beginDate">beginDate.</param>
        /// <param name="endDate">endDate.</param>
        /// <param name="checkIn">checkIn.</param>
        /// <param name="checkOut">checkOut.</param>
        public Restriction(
            DateTime beginDate,
            DateTime endDate,
            Models.CheckIn checkIn,
            Models.CheckOut checkOut)
        {
            this.BeginDate = beginDate;
            this.EndDate = endDate;
            this.CheckIn = checkIn;
            this.CheckOut = checkOut;
        }

        /// <summary>
        /// Beginning date of date range for which restriction is applied. Date should be in format "yyyy-MM-dd"
        /// </summary>
        [JsonConverter(typeof(CustomDateTimeConverter), "yyyy'-'MM'-'dd")]
        [JsonProperty("beginDate")]
        public DateTime BeginDate { get; set; }

        /// <summary>
        /// End date of date range for which restriction is applied. Date should be in format "yyyy-MM-dd"
        /// </summary>
        [JsonConverter(typeof(CustomDateTimeConverter), "yyyy'-'MM'-'dd")]
        [JsonProperty("endDate")]
        public DateTime EndDate { get; set; }

        /// <summary>
        /// Gets or sets CheckIn.
        /// </summary>
        [JsonProperty("checkIn")]
        public Models.CheckIn CheckIn { get; set; }

        /// <summary>
        /// Gets or sets CheckOut.
        /// </summary>
        [JsonProperty("checkOut")]
        public Models.CheckOut CheckOut { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"Restriction : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is Restriction other &&
                this.BeginDate.Equals(other.BeginDate) &&
                this.EndDate.Equals(other.EndDate) &&
                ((this.CheckIn == null && other.CheckIn == null) || (this.CheckIn?.Equals(other.CheckIn) == true)) &&
                ((this.CheckOut == null && other.CheckOut == null) || (this.CheckOut?.Equals(other.CheckOut) == true));
        }
        

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.BeginDate = {this.BeginDate}");
            toStringOutput.Add($"this.EndDate = {this.EndDate}");
            toStringOutput.Add($"this.CheckIn = {(this.CheckIn == null ? "null" : this.CheckIn.ToString())}");
            toStringOutput.Add($"this.CheckOut = {(this.CheckOut == null ? "null" : this.CheckOut.ToString())}");
        }
    }
}