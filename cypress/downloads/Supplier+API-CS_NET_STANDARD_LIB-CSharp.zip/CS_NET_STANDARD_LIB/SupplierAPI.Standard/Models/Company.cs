// <copyright file="Company.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace SupplierAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using SupplierAPI.Standard;
    using SupplierAPI.Standard.Utilities;

    /// <summary>
    /// Company.
    /// </summary>
    public class Company
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="Company"/> class.
        /// </summary>
        public Company()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="Company"/> class.
        /// </summary>
        /// <param name="companyDetails">companyDetails.</param>
        /// <param name="policies">policies.</param>
        /// <param name="payment">payment.</param>
        /// <param name="isCompany">isCompany.</param>
        /// <param name="id">id.</param>
        /// <param name="ownerInfo">ownerInfo.</param>
        /// <param name="neighborhoodOverview">neighborhoodOverview.</param>
        public Company(
            Models.CompanyDetails companyDetails,
            Models.Policies policies,
            Models.Payment payment,
            bool? isCompany = null,
            int? id = null,
            Models.Text ownerInfo = null,
            Models.Text neighborhoodOverview = null)
        {
            this.IsCompany = isCompany;
            this.CompanyDetails = companyDetails;
            this.Policies = policies;
            this.Payment = payment;
            this.Id = id;
            this.OwnerInfo = ownerInfo;
            this.NeighborhoodOverview = neighborhoodOverview;
        }

        /// <summary>
        /// Is Property Manager Company or not (for example it can be a single host). TRUE=Company. Default is TRUE.
        /// </summary>
        [JsonProperty("isCompany", NullValueHandling = NullValueHandling.Ignore)]
        public bool? IsCompany { get; set; }

        /// <summary>
        /// Gets or sets CompanyDetails.
        /// </summary>
        [JsonProperty("companyDetails")]
        public Models.CompanyDetails CompanyDetails { get; set; }

        /// <summary>
        /// Gets or sets Policies.
        /// </summary>
        [JsonProperty("policies")]
        public Models.Policies Policies { get; set; }

        /// <summary>
        /// Gets or sets Payment.
        /// </summary>
        [JsonProperty("payment")]
        public Models.Payment Payment { get; set; }

        /// <summary>
        /// Supplier id. Not expected in any requests. Will be only in responses.
        /// </summary>
        [JsonProperty("id", NullValueHandling = NullValueHandling.Ignore)]
        public int? Id { get; set; }

        /// <summary>
        /// Gets or sets OwnerInfo.
        /// </summary>
        [JsonProperty("ownerInfo", NullValueHandling = NullValueHandling.Ignore)]
        public Models.Text OwnerInfo { get; set; }

        /// <summary>
        /// Gets or sets NeighborhoodOverview.
        /// </summary>
        [JsonProperty("neighborhoodOverview", NullValueHandling = NullValueHandling.Ignore)]
        public Models.Text NeighborhoodOverview { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"Company : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is Company other &&
                ((this.IsCompany == null && other.IsCompany == null) || (this.IsCompany?.Equals(other.IsCompany) == true)) &&
                ((this.CompanyDetails == null && other.CompanyDetails == null) || (this.CompanyDetails?.Equals(other.CompanyDetails) == true)) &&
                ((this.Policies == null && other.Policies == null) || (this.Policies?.Equals(other.Policies) == true)) &&
                ((this.Payment == null && other.Payment == null) || (this.Payment?.Equals(other.Payment) == true)) &&
                ((this.Id == null && other.Id == null) || (this.Id?.Equals(other.Id) == true)) &&
                ((this.OwnerInfo == null && other.OwnerInfo == null) || (this.OwnerInfo?.Equals(other.OwnerInfo) == true)) &&
                ((this.NeighborhoodOverview == null && other.NeighborhoodOverview == null) || (this.NeighborhoodOverview?.Equals(other.NeighborhoodOverview) == true));
        }
        

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.IsCompany = {(this.IsCompany == null ? "null" : this.IsCompany.ToString())}");
            toStringOutput.Add($"this.CompanyDetails = {(this.CompanyDetails == null ? "null" : this.CompanyDetails.ToString())}");
            toStringOutput.Add($"this.Policies = {(this.Policies == null ? "null" : this.Policies.ToString())}");
            toStringOutput.Add($"this.Payment = {(this.Payment == null ? "null" : this.Payment.ToString())}");
            toStringOutput.Add($"this.Id = {(this.Id == null ? "null" : this.Id.ToString())}");
            toStringOutput.Add($"this.OwnerInfo = {(this.OwnerInfo == null ? "null" : this.OwnerInfo.ToString())}");
            toStringOutput.Add($"this.NeighborhoodOverview = {(this.NeighborhoodOverview == null ? "null" : this.NeighborhoodOverview.ToString())}");
        }
    }
}