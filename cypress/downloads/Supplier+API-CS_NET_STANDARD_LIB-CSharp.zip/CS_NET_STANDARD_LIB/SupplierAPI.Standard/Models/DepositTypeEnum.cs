// <copyright file="DepositTypeEnum.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace SupplierAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Runtime.Serialization;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using SupplierAPI.Standard;
    using SupplierAPI.Standard.Utilities;

    /// <summary>
    /// DepositTypeEnum.
    /// </summary>
    [JsonConverter(typeof(StringEnumConverter))]
    public enum DepositTypeEnum
    {
        /// <summary>
        /// PERCENTAGE.
        /// </summary>
        [EnumMember(Value = "PERCENTAGE")]
        PERCENTAGE,

        /// <summary>
        /// FLAT.
        /// </summary>
        [EnumMember(Value = "FLAT")]
        FLAT,

        /// <summary>
        /// NON.
        /// </summary>
        [EnumMember(Value = "NON")]
        NON
    }
}