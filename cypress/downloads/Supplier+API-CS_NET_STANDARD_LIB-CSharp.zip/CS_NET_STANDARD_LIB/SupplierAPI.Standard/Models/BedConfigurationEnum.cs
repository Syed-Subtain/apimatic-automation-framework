// <copyright file="BedConfigurationEnum.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace SupplierAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Runtime.Serialization;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using SupplierAPI.Standard;
    using SupplierAPI.Standard.Utilities;

    /// <summary>
    /// BedConfigurationEnum.
    /// </summary>
    [JsonConverter(typeof(StringEnumConverter))]
    public enum BedConfigurationEnum
    {
        /// <summary>
        ///King bed
        /// RMA58.
        /// </summary>
        [EnumMember(Value = "RMA58")]
        RMA58,

        /// <summary>
        ///Queen bed
        /// RMA86.
        /// </summary>
        [EnumMember(Value = "RMA86")]
        RMA86,

        /// <summary>
        ///Sofa bed
        /// RMA102.
        /// </summary>
        [EnumMember(Value = "RMA102")]
        RMA102,

        /// <summary>
        ///Twin bed
        /// RMA113.
        /// </summary>
        [EnumMember(Value = "RMA113")]
        RMA113,

        /// <summary>
        ///Futon
        /// RMA200.
        /// </summary>
        [EnumMember(Value = "RMA200")]
        RMA200,

        /// <summary>
        ///Murphy bed
        /// RMA201.
        /// </summary>
        [EnumMember(Value = "RMA201")]
        RMA201,

        /// <summary>
        ///Single bed
        /// RMA203.
        /// </summary>
        [EnumMember(Value = "RMA203")]
        RMA203,

        /// <summary>
        ///Bunk bed
        /// RMA6032.
        /// </summary>
        [EnumMember(Value = "RMA6032")]
        RMA6032,

        /// <summary>
        ///Double bed
        /// RMA33.
        /// </summary>
        [EnumMember(Value = "RMA33")]
        RMA33,

        /// <summary>
        ///Cribs
        /// RMA26.
        /// </summary>
        [EnumMember(Value = "RMA26")]
        RMA26,

        /// <summary>
        ///Extra bed
        /// RMA6038.
        /// </summary>
        [EnumMember(Value = "RMA6038")]
        RMA6038,

        /// <summary>
        ///Couch
        /// RMA6118.
        /// </summary>
        [EnumMember(Value = "RMA6118")]
        RMA6118,

        /// <summary>
        ///Air mattress
        /// RMA6119.
        /// </summary>
        [EnumMember(Value = "RMA6119")]
        RMA6119,

        /// <summary>
        ///Floor mattress
        /// RMA6120.
        /// </summary>
        [EnumMember(Value = "RMA6120")]
        RMA6120,

        /// <summary>
        ///Toddler bed
        /// RMA6121.
        /// </summary>
        [EnumMember(Value = "RMA6121")]
        RMA6121,

        /// <summary>
        ///Hammock
        /// RMA6122.
        /// </summary>
        [EnumMember(Value = "RMA6122")]
        RMA6122
    }
}