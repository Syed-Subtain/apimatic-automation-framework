// <copyright file="PaymentPolicy.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace SupplierAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using SupplierAPI.Standard;
    using SupplierAPI.Standard.Utilities;

    /// <summary>
    /// PaymentPolicy.
    /// </summary>
    public class PaymentPolicy
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="PaymentPolicy"/> class.
        /// </summary>
        public PaymentPolicy()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="PaymentPolicy"/> class.
        /// </summary>
        /// <param name="type">type.</param>
        /// <param name="splitPayment">splitPayment.</param>
        public PaymentPolicy(
            Models.PaymentPolicyTypeEnum type,
            Models.SplitPayment splitPayment)
        {
            this.Type = type;
            this.SplitPayment = splitPayment;
        }

        /// <summary>
        /// Full or Split payment. In case of Split payment - it will be 2 payments. [SPLIT,FULL]
        /// </summary>
        [JsonProperty("type", ItemConverterType = typeof(StringEnumConverter))]
        public Models.PaymentPolicyTypeEnum Type { get; set; }

        /// <summary>
        /// Gets or sets SplitPayment.
        /// </summary>
        [JsonProperty("splitPayment")]
        public Models.SplitPayment SplitPayment { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"PaymentPolicy : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is PaymentPolicy other &&
                this.Type.Equals(other.Type) &&
                ((this.SplitPayment == null && other.SplitPayment == null) || (this.SplitPayment?.Equals(other.SplitPayment) == true));
        }
        

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.Type = {this.Type}");
            toStringOutput.Add($"this.SplitPayment = {(this.SplitPayment == null ? "null" : this.SplitPayment.ToString())}");
        }
    }
}