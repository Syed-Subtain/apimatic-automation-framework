// <copyright file="CancellationPolicy.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace SupplierAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using SupplierAPI.Standard;
    using SupplierAPI.Standard.Utilities;

    /// <summary>
    /// CancellationPolicy.
    /// </summary>
    public class CancellationPolicy
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="CancellationPolicy"/> class.
        /// </summary>
        public CancellationPolicy()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="CancellationPolicy"/> class.
        /// </summary>
        /// <param name="type">type.</param>
        /// <param name="manualPolicy">manualPolicy.</param>
        public CancellationPolicy(
            Models.CancellationPolicyTypeEnum type,
            Models.ManualPolicy manualPolicy)
        {
            this.Type = type;
            this.ManualPolicy = manualPolicy;
        }

        /// <summary>
        /// Gets or sets Type.
        /// </summary>
        [JsonProperty("type", ItemConverterType = typeof(StringEnumConverter))]
        public Models.CancellationPolicyTypeEnum Type { get; set; }

        /// <summary>
        /// Gets or sets ManualPolicy.
        /// </summary>
        [JsonProperty("manualPolicy")]
        public Models.ManualPolicy ManualPolicy { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"CancellationPolicy : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is CancellationPolicy other &&
                this.Type.Equals(other.Type) &&
                ((this.ManualPolicy == null && other.ManualPolicy == null) || (this.ManualPolicy?.Equals(other.ManualPolicy) == true));
        }
        

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.Type = {this.Type}");
            toStringOutput.Add($"this.ManualPolicy = {(this.ManualPolicy == null ? "null" : this.ManualPolicy.ToString())}");
        }
    }
}