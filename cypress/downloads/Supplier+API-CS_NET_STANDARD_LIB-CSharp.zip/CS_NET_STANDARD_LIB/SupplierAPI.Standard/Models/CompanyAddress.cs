// <copyright file="CompanyAddress.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace SupplierAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using SupplierAPI.Standard;
    using SupplierAPI.Standard.Utilities;

    /// <summary>
    /// CompanyAddress.
    /// </summary>
    public class CompanyAddress
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="CompanyAddress"/> class.
        /// </summary>
        public CompanyAddress()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="CompanyAddress"/> class.
        /// </summary>
        /// <param name="country">country.</param>
        /// <param name="state">state.</param>
        /// <param name="streetAddress">streetAddress.</param>
        /// <param name="city">city.</param>
        /// <param name="zip">zip.</param>
        public CompanyAddress(
            string country,
            string state,
            string streetAddress,
            string city,
            string zip)
        {
            this.Country = country;
            this.State = state;
            this.StreetAddress = streetAddress;
            this.City = city;
            this.Zip = zip;
        }

        /// <summary>
        /// Country of PM. Require 2 letter ISO code
        /// </summary>
        [JsonProperty("country")]
        public string Country { get; set; }

        /// <summary>
        /// State (Region) of PM. Required for US properties.
        /// </summary>
        [JsonProperty("state")]
        public string State { get; set; }

        /// <summary>
        /// Street address of PM.
        /// </summary>
        [JsonProperty("streetAddress")]
        public string StreetAddress { get; set; }

        /// <summary>
        /// City of PM
        /// </summary>
        [JsonProperty("city")]
        public string City { get; set; }

        /// <summary>
        /// Zip code (postal code) of PM.
        /// </summary>
        [JsonProperty("zip")]
        public string Zip { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"CompanyAddress : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is CompanyAddress other &&
                ((this.Country == null && other.Country == null) || (this.Country?.Equals(other.Country) == true)) &&
                ((this.State == null && other.State == null) || (this.State?.Equals(other.State) == true)) &&
                ((this.StreetAddress == null && other.StreetAddress == null) || (this.StreetAddress?.Equals(other.StreetAddress) == true)) &&
                ((this.City == null && other.City == null) || (this.City?.Equals(other.City) == true)) &&
                ((this.Zip == null && other.Zip == null) || (this.Zip?.Equals(other.Zip) == true));
        }
        

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.Country = {(this.Country == null ? "null" : this.Country == string.Empty ? "" : this.Country)}");
            toStringOutput.Add($"this.State = {(this.State == null ? "null" : this.State == string.Empty ? "" : this.State)}");
            toStringOutput.Add($"this.StreetAddress = {(this.StreetAddress == null ? "null" : this.StreetAddress == string.Empty ? "" : this.StreetAddress)}");
            toStringOutput.Add($"this.City = {(this.City == null ? "null" : this.City == string.Empty ? "" : this.City)}");
            toStringOutput.Add($"this.Zip = {(this.Zip == null ? "null" : this.Zip == string.Empty ? "" : this.Zip)}");
        }
    }
}