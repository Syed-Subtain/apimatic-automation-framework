// <copyright file="LicenseReqData.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace SupplierAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using SupplierAPI.Standard;
    using SupplierAPI.Standard.Utilities;

    /// <summary>
    /// LicenseReqData.
    /// </summary>
    public class LicenseReqData
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="LicenseReqData"/> class.
        /// </summary>
        public LicenseReqData()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="LicenseReqData"/> class.
        /// </summary>
        /// <param name="productId">productId.</param>
        /// <param name="licenseRequirementResponse">licenseRequirementResponse.</param>
        public LicenseReqData(
            string productId = null,
            List<Models.LicenseRequirementResponseObject> licenseRequirementResponse = null)
        {
            this.ProductId = productId;
            this.LicenseRequirementResponse = licenseRequirementResponse;
        }

        /// <summary>
        /// Product ID
        /// </summary>
        [JsonProperty("productId", NullValueHandling = NullValueHandling.Ignore)]
        public string ProductId { get; set; }

        /// <summary>
        /// License Requirement Response Object
        /// </summary>
        [JsonProperty("licenseRequirementResponse", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.LicenseRequirementResponseObject> LicenseRequirementResponse { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"LicenseReqData : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is LicenseReqData other &&
                ((this.ProductId == null && other.ProductId == null) || (this.ProductId?.Equals(other.ProductId) == true)) &&
                ((this.LicenseRequirementResponse == null && other.LicenseRequirementResponse == null) || (this.LicenseRequirementResponse?.Equals(other.LicenseRequirementResponse) == true));
        }
        

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.ProductId = {(this.ProductId == null ? "null" : this.ProductId == string.Empty ? "" : this.ProductId)}");
            toStringOutput.Add($"this.LicenseRequirementResponse = {(this.LicenseRequirementResponse == null ? "null" : $"[{string.Join(", ", this.LicenseRequirementResponse)} ]")}");
        }
    }
}