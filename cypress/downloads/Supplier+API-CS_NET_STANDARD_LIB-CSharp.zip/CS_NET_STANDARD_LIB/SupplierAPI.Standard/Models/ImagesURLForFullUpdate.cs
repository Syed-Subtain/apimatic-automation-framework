// <copyright file="ImagesURLForFullUpdate.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace SupplierAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using SupplierAPI.Standard;
    using SupplierAPI.Standard.Utilities;

    /// <summary>
    /// ImagesURLForFullUpdate.
    /// </summary>
    public class ImagesURLForFullUpdate
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ImagesURLForFullUpdate"/> class.
        /// </summary>
        public ImagesURLForFullUpdate()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ImagesURLForFullUpdate"/> class.
        /// </summary>
        /// <param name="productId">productId.</param>
        /// <param name="images">images.</param>
        public ImagesURLForFullUpdate(
            int productId,
            List<Models.AddImage> images)
        {
            this.ProductId = productId;
            this.Images = images;
        }

        /// <summary>
        /// Id of the product
        /// </summary>
        [JsonProperty("productId")]
        public int ProductId { get; set; }

        /// <summary>
        /// Gets or sets Images.
        /// </summary>
        [JsonProperty("images")]
        public List<Models.AddImage> Images { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"ImagesURLForFullUpdate : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is ImagesURLForFullUpdate other &&
                this.ProductId.Equals(other.ProductId) &&
                ((this.Images == null && other.Images == null) || (this.Images?.Equals(other.Images) == true));
        }
        

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.ProductId = {this.ProductId}");
            toStringOutput.Add($"this.Images = {(this.Images == null ? "null" : $"[{string.Join(", ", this.Images)} ]")}");
        }
    }
}