// <copyright file="LicenseData.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace SupplierAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using SupplierAPI.Standard;
    using SupplierAPI.Standard.Utilities;

    /// <summary>
    /// LicenseData.
    /// </summary>
    public class LicenseData
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="LicenseData"/> class.
        /// </summary>
        public LicenseData()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="LicenseData"/> class.
        /// </summary>
        /// <param name="contentData">contentData.</param>
        /// <param name="variantId">variantId.</param>
        public LicenseData(
            List<Models.LicenseDataContent> contentData,
            string variantId)
        {
            this.ContentData = contentData;
            this.VariantId = variantId;
        }

        /// <summary>
        /// Gets or sets ContentData.
        /// </summary>
        [JsonProperty("contentData")]
        public List<Models.LicenseDataContent> ContentData { get; set; }

        /// <summary>
        /// Variant ID
        /// </summary>
        [JsonProperty("variantId")]
        public string VariantId { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"LicenseData : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is LicenseData other &&
                ((this.ContentData == null && other.ContentData == null) || (this.ContentData?.Equals(other.ContentData) == true)) &&
                ((this.VariantId == null && other.VariantId == null) || (this.VariantId?.Equals(other.VariantId) == true));
        }
        

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.ContentData = {(this.ContentData == null ? "null" : $"[{string.Join(", ", this.ContentData)} ]")}");
            toStringOutput.Add($"this.VariantId = {(this.VariantId == null ? "null" : this.VariantId == string.Empty ? "" : this.VariantId)}");
        }
    }
}