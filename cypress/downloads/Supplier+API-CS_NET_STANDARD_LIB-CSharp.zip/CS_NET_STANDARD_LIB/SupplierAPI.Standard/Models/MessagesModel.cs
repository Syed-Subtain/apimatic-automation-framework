// <copyright file="MessagesModel.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace SupplierAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using SupplierAPI.Standard;
    using SupplierAPI.Standard.Utilities;

    /// <summary>
    /// MessagesModel.
    /// </summary>
    public class MessagesModel
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="MessagesModel"/> class.
        /// </summary>
        public MessagesModel()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="MessagesModel"/> class.
        /// </summary>
        /// <param name="messages">messages.</param>
        public MessagesModel(
            List<Models.MessageModel> messages)
        {
            this.Messages = messages;
        }

        /// <summary>
        /// List of models
        /// </summary>
        [JsonProperty("messages")]
        public List<Models.MessageModel> Messages { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"MessagesModel : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is MessagesModel other &&
                ((this.Messages == null && other.Messages == null) || (this.Messages?.Equals(other.Messages) == true));
        }
        

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.Messages = {(this.Messages == null ? "null" : $"[{string.Join(", ", this.Messages)} ]")}");
        }
    }
}