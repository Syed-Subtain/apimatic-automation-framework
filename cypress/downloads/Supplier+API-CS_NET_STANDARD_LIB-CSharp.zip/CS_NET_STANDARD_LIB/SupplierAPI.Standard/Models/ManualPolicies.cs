// <copyright file="ManualPolicies.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace SupplierAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using SupplierAPI.Standard;
    using SupplierAPI.Standard.Utilities;

    /// <summary>
    /// ManualPolicies.
    /// </summary>
    public class ManualPolicies
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ManualPolicies"/> class.
        /// </summary>
        public ManualPolicies()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ManualPolicies"/> class.
        /// </summary>
        /// <param name="chargeValue">chargeValue.</param>
        /// <param name="beforeDays">beforeDays.</param>
        /// <param name="cancellationFee">cancellationFee.</param>
        public ManualPolicies(
            int chargeValue,
            int beforeDays,
            double cancellationFee)
        {
            this.ChargeValue = chargeValue;
            this.BeforeDays = beforeDays;
            this.CancellationFee = cancellationFee;
        }

        /// <summary>
        /// Percentage or flat value which will be charged in case of cancellation
        /// </summary>
        [JsonProperty("chargeValue")]
        public int ChargeValue { get; set; }

        /// <summary>
        /// Days before check-in when cancellation policy will be charged
        /// </summary>
        [JsonProperty("beforeDays")]
        public int BeforeDays { get; set; }

        /// <summary>
        /// Cancellation transaction fee - additional fee on cancellation
        /// </summary>
        [JsonProperty("cancellationFee")]
        public double CancellationFee { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"ManualPolicies : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is ManualPolicies other &&
                this.ChargeValue.Equals(other.ChargeValue) &&
                this.BeforeDays.Equals(other.BeforeDays) &&
                this.CancellationFee.Equals(other.CancellationFee);
        }
        

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.ChargeValue = {this.ChargeValue}");
            toStringOutput.Add($"this.BeforeDays = {this.BeforeDays}");
            toStringOutput.Add($"this.CancellationFee = {this.CancellationFee}");
        }
    }
}