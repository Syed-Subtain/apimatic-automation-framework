// <copyright file="LicenseUpdateResponseData.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace SupplierAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using SupplierAPI.Standard;
    using SupplierAPI.Standard.Utilities;

    /// <summary>
    /// LicenseUpdateResponseData.
    /// </summary>
    public class LicenseUpdateResponseData
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="LicenseUpdateResponseData"/> class.
        /// </summary>
        public LicenseUpdateResponseData()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="LicenseUpdateResponseData"/> class.
        /// </summary>
        /// <param name="productId">productId.</param>
        /// <param name="response">response.</param>
        public LicenseUpdateResponseData(
            string productId = null,
            List<Models.LicenseUpdateResponseDataDetail> response = null)
        {
            this.ProductId = productId;
            this.Response = response;
        }

        /// <summary>
        /// product ID
        /// </summary>
        [JsonProperty("productId", NullValueHandling = NullValueHandling.Ignore)]
        public string ProductId { get; set; }

        /// <summary>
        /// Gets or sets Response.
        /// </summary>
        [JsonProperty("response", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.LicenseUpdateResponseDataDetail> Response { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"LicenseUpdateResponseData : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is LicenseUpdateResponseData other &&
                ((this.ProductId == null && other.ProductId == null) || (this.ProductId?.Equals(other.ProductId) == true)) &&
                ((this.Response == null && other.Response == null) || (this.Response?.Equals(other.Response) == true));
        }
        

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.ProductId = {(this.ProductId == null ? "null" : this.ProductId == string.Empty ? "" : this.ProductId)}");
            toStringOutput.Add($"this.Response = {(this.Response == null ? "null" : $"[{string.Join(", ", this.Response)} ]")}");
        }
    }
}