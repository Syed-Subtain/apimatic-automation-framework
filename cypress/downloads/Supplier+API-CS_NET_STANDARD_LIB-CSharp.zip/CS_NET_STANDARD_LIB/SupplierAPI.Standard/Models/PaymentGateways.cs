// <copyright file="PaymentGateways.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace SupplierAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using SupplierAPI.Standard;
    using SupplierAPI.Standard.Utilities;

    /// <summary>
    /// PaymentGateways.
    /// </summary>
    public class PaymentGateways
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="PaymentGateways"/> class.
        /// </summary>
        public PaymentGateways()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="PaymentGateways"/> class.
        /// </summary>
        /// <param name="paymentGatewaysType">paymentGatewaysType.</param>
        /// <param name="user">user.</param>
        /// <param name="secret">secret.</param>
        /// <param name="additionalField1">additionalField1.</param>
        /// <param name="additionalField2">additionalField2.</param>
        public PaymentGateways(
            Models.PaymentGatewaysTypeEnum paymentGatewaysType,
            string user = null,
            string secret = null,
            string additionalField1 = null,
            string additionalField2 = null)
        {
            this.PaymentGatewaysType = paymentGatewaysType;
            this.User = user;
            this.Secret = secret;
            this.AdditionalField1 = additionalField1;
            this.AdditionalField2 = additionalField2;
        }

        /// <summary>
        /// Gets or sets PaymentGatewaysType.
        /// </summary>
        [JsonProperty("paymentGatewaysType", ItemConverterType = typeof(StringEnumConverter))]
        public Models.PaymentGatewaysTypeEnum PaymentGatewaysType { get; set; }

        /// <summary>
        /// Value necessary for accessing payment gateway, values are different per payment gateway: PAYPAL - Client ID AUTHORIZE_NET - User ID BRIDGE_PAY - Username PAY_BOX - Site number DIBS - Login O_GONE - User ID DOC_DATA - ID PAY_GATE - ID  Note: This value will not be returned in response.
        /// </summary>
        [JsonProperty("user", NullValueHandling = NullValueHandling.Ignore)]
        public string User { get; set; }

        /// <summary>
        /// Value necessary for accessing payment gateway, values are different per payment gateway: PAYPAL - Secret AUTHORIZE_NET - Transaction Key BRIDGE_PAY - Password  PAY_BOX - Rank number DIBS - Password O_GONE - Password  DOC_DATA - Password PAY_GATE - Password  Note: This value will not be returned in response.
        /// </summary>
        [JsonProperty("secret", NullValueHandling = NullValueHandling.Ignore)]
        public string Secret { get; set; }

        /// <summary>
        /// Additional value necessary for accessing some payment gateways, values are different per payment gateway: BRIDGE_PAY - Merchant Number PAY_BOX - An identifier DIBS - Merchant ID O_GONE - PSP ID  Note: This value will not be returned in response.
        /// </summary>
        [JsonProperty("additionalField1", NullValueHandling = NullValueHandling.Ignore)]
        public string AdditionalField1 { get; set; }

        /// <summary>
        /// Additional value necessary for accessing some payment gateways, values are different per payment gateway: BRIDGE_PAY - Merchant Number PAY_BOX - An identifier DIBS - Merchant ID O_GONE - PSP ID  Note: This value will not be returned in response.
        /// </summary>
        [JsonProperty("additionalField2", NullValueHandling = NullValueHandling.Ignore)]
        public string AdditionalField2 { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"PaymentGateways : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is PaymentGateways other &&
                this.PaymentGatewaysType.Equals(other.PaymentGatewaysType) &&
                ((this.User == null && other.User == null) || (this.User?.Equals(other.User) == true)) &&
                ((this.Secret == null && other.Secret == null) || (this.Secret?.Equals(other.Secret) == true)) &&
                ((this.AdditionalField1 == null && other.AdditionalField1 == null) || (this.AdditionalField1?.Equals(other.AdditionalField1) == true)) &&
                ((this.AdditionalField2 == null && other.AdditionalField2 == null) || (this.AdditionalField2?.Equals(other.AdditionalField2) == true));
        }
        

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.PaymentGatewaysType = {this.PaymentGatewaysType}");
            toStringOutput.Add($"this.User = {(this.User == null ? "null" : this.User == string.Empty ? "" : this.User)}");
            toStringOutput.Add($"this.Secret = {(this.Secret == null ? "null" : this.Secret == string.Empty ? "" : this.Secret)}");
            toStringOutput.Add($"this.AdditionalField1 = {(this.AdditionalField1 == null ? "null" : this.AdditionalField1 == string.Empty ? "" : this.AdditionalField1)}");
            toStringOutput.Add($"this.AdditionalField2 = {(this.AdditionalField2 == null ? "null" : this.AdditionalField2 == string.Empty ? "" : this.AdditionalField2)}");
        }
    }
}