// <copyright file="AsynchronousValidationModel.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace SupplierAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using SupplierAPI.Standard;
    using SupplierAPI.Standard.Utilities;

    /// <summary>
    /// AsynchronousValidationModel.
    /// </summary>
    public class AsynchronousValidationModel
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="AsynchronousValidationModel"/> class.
        /// </summary>
        public AsynchronousValidationModel()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="AsynchronousValidationModel"/> class.
        /// </summary>
        /// <param name="productId">productId.</param>
        /// <param name="valid">valid.</param>
        /// <param name="validationErrors">validationErrors.</param>
        public AsynchronousValidationModel(
            int productId,
            bool valid,
            string validationErrors = null)
        {
            this.ProductId = productId;
            this.ValidationErrors = validationErrors;
            this.Valid = valid;
        }

        /// <summary>
        /// Id of product in BookingPal
        /// </summary>
        [JsonProperty("productId")]
        public int ProductId { get; set; }

        /// <summary>
        /// Error message - explanation what are problems if validation failed.
        /// </summary>
        [JsonProperty("validationErrors", NullValueHandling = NullValueHandling.Ignore)]
        public string ValidationErrors { get; set; }

        /// <summary>
        /// Is product valid
        /// </summary>
        [JsonProperty("valid")]
        public bool Valid { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"AsynchronousValidationModel : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is AsynchronousValidationModel other &&
                this.ProductId.Equals(other.ProductId) &&
                ((this.ValidationErrors == null && other.ValidationErrors == null) || (this.ValidationErrors?.Equals(other.ValidationErrors) == true)) &&
                this.Valid.Equals(other.Valid);
        }
        

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.ProductId = {this.ProductId}");
            toStringOutput.Add($"this.ValidationErrors = {(this.ValidationErrors == null ? "null" : this.ValidationErrors == string.Empty ? "" : this.ValidationErrors)}");
            toStringOutput.Add($"this.Valid = {this.Valid}");
        }
    }
}