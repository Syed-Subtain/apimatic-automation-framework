// <copyright file="Taxes.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace SupplierAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using SupplierAPI.Standard;
    using SupplierAPI.Standard.Utilities;

    /// <summary>
    /// Taxes.
    /// </summary>
    public class Taxes
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="Taxes"/> class.
        /// </summary>
        public Taxes()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="Taxes"/> class.
        /// </summary>
        /// <param name="name">name.</param>
        /// <param name="mValue">value.</param>
        /// <param name="type">type.</param>
        /// <param name="altId">altId.</param>
        public Taxes(
            string name,
            double mValue,
            Models.TaxisTypeEnum? type = null,
            string altId = null)
        {
            this.Name = name;
            this.Type = type;
            this.MValue = mValue;
            this.AltId = altId;
        }

        /// <summary>
        /// Tax name
        /// </summary>
        [JsonProperty("name")]
        public string Name { get; set; }

        /// <summary>
        /// Gets or sets Type.
        /// </summary>
        [JsonProperty("type", ItemConverterType = typeof(StringEnumConverter), NullValueHandling = NullValueHandling.Ignore)]
        public Models.TaxisTypeEnum? Type { get; set; }

        /// <summary>
        /// Tax value
        /// </summary>
        [JsonProperty("value")]
        public double MValue { get; set; }

        /// <summary>
        /// Alternative Id of the tax (tax id in your system)
        /// </summary>
        [JsonProperty("altId", NullValueHandling = NullValueHandling.Ignore)]
        public string AltId { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"Taxes : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is Taxes other &&
                ((this.Name == null && other.Name == null) || (this.Name?.Equals(other.Name) == true)) &&
                ((this.Type == null && other.Type == null) || (this.Type?.Equals(other.Type) == true)) &&
                this.MValue.Equals(other.MValue) &&
                ((this.AltId == null && other.AltId == null) || (this.AltId?.Equals(other.AltId) == true));
        }
        

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.Name = {(this.Name == null ? "null" : this.Name == string.Empty ? "" : this.Name)}");
            toStringOutput.Add($"this.Type = {(this.Type == null ? "null" : this.Type.ToString())}");
            toStringOutput.Add($"this.MValue = {this.MValue}");
            toStringOutput.Add($"this.AltId = {(this.AltId == null ? "null" : this.AltId == string.Empty ? "" : this.AltId)}");
        }
    }
}