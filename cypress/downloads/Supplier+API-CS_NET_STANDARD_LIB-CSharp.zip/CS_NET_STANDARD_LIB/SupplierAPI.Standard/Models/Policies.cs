// <copyright file="Policies.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace SupplierAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using SupplierAPI.Standard;
    using SupplierAPI.Standard.Utilities;

    /// <summary>
    /// Policies.
    /// </summary>
    public class Policies
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="Policies"/> class.
        /// </summary>
        public Policies()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="Policies"/> class.
        /// </summary>
        /// <param name="paymentPolicy">paymentPolicy.</param>
        /// <param name="cancellationPolicy">cancellationPolicy.</param>
        /// <param name="feeTaxMandatory">feeTaxMandatory.</param>
        /// <param name="terms">terms.</param>
        /// <param name="checkInTime">checkInTime.</param>
        /// <param name="checkOutTime">checkOutTime.</param>
        /// <param name="leadTime">leadTime.</param>
        public Policies(
            Models.PaymentPolicy paymentPolicy,
            Models.CancellationPolicy cancellationPolicy,
            Models.FeeTaxMandatory feeTaxMandatory,
            string terms,
            string checkInTime,
            string checkOutTime,
            int leadTime)
        {
            this.PaymentPolicy = paymentPolicy;
            this.CancellationPolicy = cancellationPolicy;
            this.FeeTaxMandatory = feeTaxMandatory;
            this.Terms = terms;
            this.CheckInTime = checkInTime;
            this.CheckOutTime = checkOutTime;
            this.LeadTime = leadTime;
        }

        /// <summary>
        /// Gets or sets PaymentPolicy.
        /// </summary>
        [JsonProperty("paymentPolicy")]
        public Models.PaymentPolicy PaymentPolicy { get; set; }

        /// <summary>
        /// Gets or sets CancellationPolicy.
        /// </summary>
        [JsonProperty("cancellationPolicy")]
        public Models.CancellationPolicy CancellationPolicy { get; set; }

        /// <summary>
        /// Gets or sets FeeTaxMandatory.
        /// </summary>
        [JsonProperty("feeTaxMandatory")]
        public Models.FeeTaxMandatory FeeTaxMandatory { get; set; }

        /// <summary>
        /// Full URL to PM terms and conditions
        /// </summary>
        [JsonProperty("terms")]
        public string Terms { get; set; }

        /// <summary>
        /// Time of Check in (HH:MM:SS)
        /// </summary>
        [JsonProperty("checkInTime")]
        public string CheckInTime { get; set; }

        /// <summary>
        /// Time of Check out (HH:MM:SS)
        /// </summary>
        [JsonProperty("checkOutTime")]
        public string CheckOutTime { get; set; }

        /// <summary>
        /// Minimum number of days before check-in for which reservation is allowed to be booked. Allowed values are 0-7.
        /// </summary>
        [JsonProperty("leadTime")]
        public int LeadTime { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"Policies : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is Policies other &&
                ((this.PaymentPolicy == null && other.PaymentPolicy == null) || (this.PaymentPolicy?.Equals(other.PaymentPolicy) == true)) &&
                ((this.CancellationPolicy == null && other.CancellationPolicy == null) || (this.CancellationPolicy?.Equals(other.CancellationPolicy) == true)) &&
                ((this.FeeTaxMandatory == null && other.FeeTaxMandatory == null) || (this.FeeTaxMandatory?.Equals(other.FeeTaxMandatory) == true)) &&
                ((this.Terms == null && other.Terms == null) || (this.Terms?.Equals(other.Terms) == true)) &&
                ((this.CheckInTime == null && other.CheckInTime == null) || (this.CheckInTime?.Equals(other.CheckInTime) == true)) &&
                ((this.CheckOutTime == null && other.CheckOutTime == null) || (this.CheckOutTime?.Equals(other.CheckOutTime) == true)) &&
                this.LeadTime.Equals(other.LeadTime);
        }
        

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.PaymentPolicy = {(this.PaymentPolicy == null ? "null" : this.PaymentPolicy.ToString())}");
            toStringOutput.Add($"this.CancellationPolicy = {(this.CancellationPolicy == null ? "null" : this.CancellationPolicy.ToString())}");
            toStringOutput.Add($"this.FeeTaxMandatory = {(this.FeeTaxMandatory == null ? "null" : this.FeeTaxMandatory.ToString())}");
            toStringOutput.Add($"this.Terms = {(this.Terms == null ? "null" : this.Terms == string.Empty ? "" : this.Terms)}");
            toStringOutput.Add($"this.CheckInTime = {(this.CheckInTime == null ? "null" : this.CheckInTime == string.Empty ? "" : this.CheckInTime)}");
            toStringOutput.Add($"this.CheckOutTime = {(this.CheckOutTime == null ? "null" : this.CheckOutTime == string.Empty ? "" : this.CheckOutTime)}");
            toStringOutput.Add($"this.LeadTime = {this.LeadTime}");
        }
    }
}