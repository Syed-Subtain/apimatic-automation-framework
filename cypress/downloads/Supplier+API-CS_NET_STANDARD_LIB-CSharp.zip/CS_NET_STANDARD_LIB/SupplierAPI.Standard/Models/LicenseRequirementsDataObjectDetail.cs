// <copyright file="LicenseRequirementsDataObjectDetail.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace SupplierAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using SupplierAPI.Standard;
    using SupplierAPI.Standard.Utilities;

    /// <summary>
    /// LicenseRequirementsDataObjectDetail.
    /// </summary>
    public class LicenseRequirementsDataObjectDetail
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="LicenseRequirementsDataObjectDetail"/> class.
        /// </summary>
        public LicenseRequirementsDataObjectDetail()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="LicenseRequirementsDataObjectDetail"/> class.
        /// </summary>
        /// <param name="name">name.</param>
        /// <param name="level">level.</param>
        /// <param name="variants">variants.</param>
        /// <param name="active">active.</param>
        /// <param name="id">id.</param>
        public LicenseRequirementsDataObjectDetail(
            string name = null,
            string level = null,
            List<Models.LicenseVariants> variants = null,
            string active = null,
            string id = null)
        {
            this.Name = name;
            this.Level = level;
            this.Variants = variants;
            this.Active = active;
            this.Id = id;
        }

        /// <summary>
        /// name of the property
        /// </summary>
        [JsonProperty("name", NullValueHandling = NullValueHandling.Ignore)]
        public string Name { get; set; }

        /// <summary>
        /// Level of the property for the name above
        /// </summary>
        [JsonProperty("level", NullValueHandling = NullValueHandling.Ignore)]
        public string Level { get; set; }

        /// <summary>
        /// Gets or sets Variants.
        /// </summary>
        [JsonProperty("variants", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.LicenseVariants> Variants { get; set; }

        /// <summary>
        /// active/inactive indicator
        /// </summary>
        [JsonProperty("active", NullValueHandling = NullValueHandling.Ignore)]
        public string Active { get; set; }

        /// <summary>
        /// ID of the requirement.
        /// </summary>
        [JsonProperty("id", NullValueHandling = NullValueHandling.Ignore)]
        public string Id { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"LicenseRequirementsDataObjectDetail : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is LicenseRequirementsDataObjectDetail other &&
                ((this.Name == null && other.Name == null) || (this.Name?.Equals(other.Name) == true)) &&
                ((this.Level == null && other.Level == null) || (this.Level?.Equals(other.Level) == true)) &&
                ((this.Variants == null && other.Variants == null) || (this.Variants?.Equals(other.Variants) == true)) &&
                ((this.Active == null && other.Active == null) || (this.Active?.Equals(other.Active) == true)) &&
                ((this.Id == null && other.Id == null) || (this.Id?.Equals(other.Id) == true));
        }
        

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.Name = {(this.Name == null ? "null" : this.Name == string.Empty ? "" : this.Name)}");
            toStringOutput.Add($"this.Level = {(this.Level == null ? "null" : this.Level == string.Empty ? "" : this.Level)}");
            toStringOutput.Add($"this.Variants = {(this.Variants == null ? "null" : $"[{string.Join(", ", this.Variants)} ]")}");
            toStringOutput.Add($"this.Active = {(this.Active == null ? "null" : this.Active == string.Empty ? "" : this.Active)}");
            toStringOutput.Add($"this.Id = {(this.Id == null ? "null" : this.Id == string.Empty ? "" : this.Id)}");
        }
    }
}