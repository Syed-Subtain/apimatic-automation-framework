// <copyright file="LicenseGetResponseData.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace SupplierAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using SupplierAPI.Standard;
    using SupplierAPI.Standard.Utilities;

    /// <summary>
    /// LicenseGetResponseData.
    /// </summary>
    public class LicenseGetResponseData
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="LicenseGetResponseData"/> class.
        /// </summary>
        public LicenseGetResponseData()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="LicenseGetResponseData"/> class.
        /// </summary>
        /// <param name="productId">productId.</param>
        /// <param name="level">level.</param>
        /// <param name="licenseInformationResponse">licenseInformationResponse.</param>
        public LicenseGetResponseData(
            string productId = null,
            string level = null,
            List<Models.LicenseInfoResponse> licenseInformationResponse = null)
        {
            this.ProductId = productId;
            this.Level = level;
            this.LicenseInformationResponse = licenseInformationResponse;
        }

        /// <summary>
        /// name of the property
        /// </summary>
        [JsonProperty("productId", NullValueHandling = NullValueHandling.Ignore)]
        public string ProductId { get; set; }

        /// <summary>
        /// Level of the property for the name above
        /// </summary>
        [JsonProperty("level", NullValueHandling = NullValueHandling.Ignore)]
        public string Level { get; set; }

        /// <summary>
        /// Gets or sets LicenseInformationResponse.
        /// </summary>
        [JsonProperty("licenseInformationResponse", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.LicenseInfoResponse> LicenseInformationResponse { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"LicenseGetResponseData : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is LicenseGetResponseData other &&
                ((this.ProductId == null && other.ProductId == null) || (this.ProductId?.Equals(other.ProductId) == true)) &&
                ((this.Level == null && other.Level == null) || (this.Level?.Equals(other.Level) == true)) &&
                ((this.LicenseInformationResponse == null && other.LicenseInformationResponse == null) || (this.LicenseInformationResponse?.Equals(other.LicenseInformationResponse) == true));
        }
        

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.ProductId = {(this.ProductId == null ? "null" : this.ProductId == string.Empty ? "" : this.ProductId)}");
            toStringOutput.Add($"this.Level = {(this.Level == null ? "null" : this.Level == string.Empty ? "" : this.Level)}");
            toStringOutput.Add($"this.LicenseInformationResponse = {(this.LicenseInformationResponse == null ? "null" : $"[{string.Join(", ", this.LicenseInformationResponse)} ]")}");
        }
    }
}