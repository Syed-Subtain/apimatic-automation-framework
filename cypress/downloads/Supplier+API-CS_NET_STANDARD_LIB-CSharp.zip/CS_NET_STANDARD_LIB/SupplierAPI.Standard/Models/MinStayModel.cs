// <copyright file="MinStayModel.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace SupplierAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using SupplierAPI.Standard;
    using SupplierAPI.Standard.Utilities;

    /// <summary>
    /// MinStayModel.
    /// </summary>
    public class MinStayModel
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="MinStayModel"/> class.
        /// </summary>
        public MinStayModel()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="MinStayModel"/> class.
        /// </summary>
        /// <param name="beginDate">beginDate.</param>
        /// <param name="endDate">endDate.</param>
        /// <param name="minStay">minStay.</param>
        public MinStayModel(
            DateTime beginDate,
            DateTime endDate,
            int minStay)
        {
            this.BeginDate = beginDate;
            this.EndDate = endDate;
            this.MinStay = minStay;
        }

        /// <summary>
        /// Beginning date of date range for which min stay is applied. Date should be in format "yyyy-MM-dd"
        /// </summary>
        [JsonConverter(typeof(CustomDateTimeConverter), "yyyy'-'MM'-'dd")]
        [JsonProperty("beginDate")]
        public DateTime BeginDate { get; set; }

        /// <summary>
        /// End date of date range for which min stay is applied. Date should be in format "yyyy-MM-dd"
        /// </summary>
        [JsonConverter(typeof(CustomDateTimeConverter), "yyyy'-'MM'-'dd")]
        [JsonProperty("endDate")]
        public DateTime EndDate { get; set; }

        /// <summary>
        /// Number of days that will be applied for min stay
        /// </summary>
        [JsonProperty("minStay")]
        public int MinStay { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"MinStayModel : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is MinStayModel other &&
                this.BeginDate.Equals(other.BeginDate) &&
                this.EndDate.Equals(other.EndDate) &&
                this.MinStay.Equals(other.MinStay);
        }
        

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.BeginDate = {this.BeginDate}");
            toStringOutput.Add($"this.EndDate = {this.EndDate}");
            toStringOutput.Add($"this.MinStay = {this.MinStay}");
        }
    }
}