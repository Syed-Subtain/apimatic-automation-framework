// <copyright file="ImagePushNotification.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace SupplierAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using SupplierAPI.Standard;
    using SupplierAPI.Standard.Utilities;

    /// <summary>
    /// ImagePushNotification.
    /// </summary>
    public class ImagePushNotification
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ImagePushNotification"/> class.
        /// </summary>
        public ImagePushNotification()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ImagePushNotification"/> class.
        /// </summary>
        /// <param name="success">success.</param>
        /// <param name="type">type.</param>
        /// <param name="url">url.</param>
        /// <param name="version">version.</param>
        public ImagePushNotification(
            bool success,
            Models.TypeEnum type,
            string url,
            string version)
        {
            this.Success = success;
            this.Type = type;
            this.Url = url;
            this.Version = version;
        }

        /// <summary>
        /// Processing Image success status
        /// </summary>
        [JsonProperty("success")]
        public bool Success { get; set; }

        /// <summary>
        /// image type
        /// </summary>
        [JsonProperty("type", ItemConverterType = typeof(StringEnumConverter))]
        public Models.TypeEnum Type { get; set; }

        /// <summary>
        /// image URL
        /// </summary>
        [JsonProperty("url")]
        public string Url { get; set; }

        /// <summary>
        /// Versoin for processing image
        /// </summary>
        [JsonProperty("version")]
        public string Version { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"ImagePushNotification : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is ImagePushNotification other &&
                this.Success.Equals(other.Success) &&
                this.Type.Equals(other.Type) &&
                ((this.Url == null && other.Url == null) || (this.Url?.Equals(other.Url) == true)) &&
                ((this.Version == null && other.Version == null) || (this.Version?.Equals(other.Version) == true));
        }
        

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.Success = {this.Success}");
            toStringOutput.Add($"this.Type = {this.Type}");
            toStringOutput.Add($"this.Url = {(this.Url == null ? "null" : this.Url == string.Empty ? "" : this.Url)}");
            toStringOutput.Add($"this.Version = {(this.Version == null ? "null" : this.Version == string.Empty ? "" : this.Version)}");
        }
    }
}