// <copyright file="CreditCardListEnum.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace SupplierAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Runtime.Serialization;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using SupplierAPI.Standard;
    using SupplierAPI.Standard.Utilities;

    /// <summary>
    /// CreditCardListEnum.
    /// </summary>
    [JsonConverter(typeof(StringEnumConverter))]
    public enum CreditCardListEnum
    {
        /// <summary>
        /// MASTERCARD.
        /// </summary>
        [EnumMember(Value = "MASTER_CARD")]
        MASTERCARD,

        /// <summary>
        /// VISA.
        /// </summary>
        [EnumMember(Value = "VISA")]
        VISA,

        /// <summary>
        /// AMERICANEXPRESS.
        /// </summary>
        [EnumMember(Value = "AMERICAN_EXPRESS")]
        AMERICANEXPRESS,

        /// <summary>
        /// DINERSCLUB.
        /// </summary>
        [EnumMember(Value = "DINERS_CLUB")]
        DINERSCLUB,

        /// <summary>
        /// DISCOVER.
        /// </summary>
        [EnumMember(Value = "DISCOVER")]
        DISCOVER
    }
}