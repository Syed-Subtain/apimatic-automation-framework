// <copyright file="GetImageListByProductID.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace SupplierAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using SupplierAPI.Standard;
    using SupplierAPI.Standard.Utilities;

    /// <summary>
    /// GetImageListByProductID.
    /// </summary>
    public class GetImageListByProductID
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="GetImageListByProductID"/> class.
        /// </summary>
        public GetImageListByProductID()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="GetImageListByProductID"/> class.
        /// </summary>
        /// <param name="message">message.</param>
        /// <param name="errorMessage">errorMessage.</param>
        /// <param name="isError">is_error.</param>
        /// <param name="code">code.</param>
        /// <param name="data">data.</param>
        public GetImageListByProductID(
            string message,
            List<string> errorMessage,
            bool isError,
            string code,
            List<Models.ImageURLList> data)
        {
            this.Message = message;
            this.ErrorMessage = errorMessage;
            this.IsError = isError;
            this.Code = code;
            this.Data = data;
        }

        /// <summary>
        /// text info message
        /// </summary>
        [JsonProperty("message")]
        public string Message { get; set; }

        /// <summary>
        /// List of error messages
        /// </summary>
        [JsonProperty("errorMessage")]
        public List<string> ErrorMessage { get; set; }

        /// <summary>
        /// Is error (default = false)
        /// </summary>
        [JsonProperty("is_error")]
        public bool IsError { get; set; }

        /// <summary>
        /// Code of message
        /// </summary>
        [JsonProperty("code")]
        public string Code { get; set; }

        /// <summary>
        /// List of Models
        /// </summary>
        [JsonProperty("data")]
        public List<Models.ImageURLList> Data { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"GetImageListByProductID : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is GetImageListByProductID other &&
                ((this.Message == null && other.Message == null) || (this.Message?.Equals(other.Message) == true)) &&
                ((this.ErrorMessage == null && other.ErrorMessage == null) || (this.ErrorMessage?.Equals(other.ErrorMessage) == true)) &&
                this.IsError.Equals(other.IsError) &&
                ((this.Code == null && other.Code == null) || (this.Code?.Equals(other.Code) == true)) &&
                ((this.Data == null && other.Data == null) || (this.Data?.Equals(other.Data) == true));
        }
        

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.Message = {(this.Message == null ? "null" : this.Message == string.Empty ? "" : this.Message)}");
            toStringOutput.Add($"this.ErrorMessage = {(this.ErrorMessage == null ? "null" : $"[{string.Join(", ", this.ErrorMessage)} ]")}");
            toStringOutput.Add($"this.IsError = {this.IsError}");
            toStringOutput.Add($"this.Code = {(this.Code == null ? "null" : this.Code == string.Empty ? "" : this.Code)}");
            toStringOutput.Add($"this.Data = {(this.Data == null ? "null" : $"[{string.Join(", ", this.Data)} ]")}");
        }
    }
}