// <copyright file="FunctionsRequestToBookTest.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace SupplierAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using SupplierAPI.Standard;
    using SupplierAPI.Standard.Utilities;

    /// <summary>
    /// FunctionsRequestToBookTest.
    /// </summary>
    public class FunctionsRequestToBookTest
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="FunctionsRequestToBookTest"/> class.
        /// </summary>
        public FunctionsRequestToBookTest()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="FunctionsRequestToBookTest"/> class.
        /// </summary>
        /// <param name="action">action.</param>
        /// <param name="productId">productId.</param>
        public FunctionsRequestToBookTest(
            Models.RequestToBookTestActionEnum action,
            int productId)
        {
            this.Action = action;
            this.ProductId = productId;
        }

        /// <summary>
        /// Allowed values for request to book Test action
        /// </summary>
        [JsonProperty("action", ItemConverterType = typeof(StringEnumConverter))]
        public Models.RequestToBookTestActionEnum Action { get; set; }

        /// <summary>
        /// Product id for test request to book
        /// </summary>
        [JsonProperty("productId")]
        public int ProductId { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"FunctionsRequestToBookTest : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is FunctionsRequestToBookTest other &&
                this.Action.Equals(other.Action) &&
                this.ProductId.Equals(other.ProductId);
        }
        

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.Action = {this.Action}");
            toStringOutput.Add($"this.ProductId = {this.ProductId}");
        }
    }
}