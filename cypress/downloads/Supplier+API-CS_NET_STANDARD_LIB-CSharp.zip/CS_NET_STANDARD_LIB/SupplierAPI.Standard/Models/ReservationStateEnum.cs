// <copyright file="ReservationStateEnum.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace SupplierAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Runtime.Serialization;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using SupplierAPI.Standard;
    using SupplierAPI.Standard.Utilities;

    /// <summary>
    /// ReservationStateEnum.
    /// </summary>
    [JsonConverter(typeof(StringEnumConverter))]
    public enum ReservationStateEnum
    {
        /// <summary>
        ///Reservation was cancelled
        /// Cancelled.
        /// </summary>
        [EnumMember(Value = "Cancelled")]
        Cancelled,

        /// <summary>
        ///Reservation processed successfully to the PMS
        /// Confirmed.
        /// </summary>
        [EnumMember(Value = "Confirmed")]
        Confirmed,

        /// <summary>
        ///Reservation processed successfully to the PMS (Channel is MOR)
        /// FullyPaid.
        /// </summary>
        [EnumMember(Value = "FullyPaid")]
        FullyPaid,

        /// <summary>
        ///Reservation currently in progress
        /// Provisional.
        /// </summary>
        [EnumMember(Value = "Provisional")]
        Provisional,

        /// <summary>
        ///Previously confirmed or fully paid reservation that the HMC no longer has matching closed dates for
        /// Exception.
        /// </summary>
        [EnumMember(Value = "Exception")]
        Exception,

        /// <summary>
        ///Reservation was not successfully processed to the PMS or PMS did not provide confirmation
        /// Failed.
        /// </summary>
        [EnumMember(Value = "Failed")]
        Failed
    }
}