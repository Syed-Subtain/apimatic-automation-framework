// <copyright file="AttributesWithQuantity.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace SupplierAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using SupplierAPI.Standard;
    using SupplierAPI.Standard.Utilities;

    /// <summary>
    /// AttributesWithQuantity.
    /// </summary>
    public class AttributesWithQuantity
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="AttributesWithQuantity"/> class.
        /// </summary>
        public AttributesWithQuantity()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="AttributesWithQuantity"/> class.
        /// </summary>
        /// <param name="attributeId">attributeId.</param>
        /// <param name="quantity">quantity.</param>
        public AttributesWithQuantity(
            Models.AmenityTypesEnum attributeId,
            int quantity)
        {
            this.AttributeId = attributeId;
            this.Quantity = quantity;
        }

        /// <summary>
        /// Gets or sets AttributeId.
        /// </summary>
        [JsonProperty("attributeId", ItemConverterType = typeof(StringEnumConverter))]
        public Models.AmenityTypesEnum AttributeId { get; set; }

        /// <summary>
        /// Will be set to 1 by default
        /// </summary>
        [JsonProperty("quantity")]
        public int Quantity { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"AttributesWithQuantity : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is AttributesWithQuantity other &&
                this.AttributeId.Equals(other.AttributeId) &&
                this.Quantity.Equals(other.Quantity);
        }
        

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.AttributeId = {this.AttributeId}");
            toStringOutput.Add($"this.Quantity = {this.Quantity}");
        }
    }
}