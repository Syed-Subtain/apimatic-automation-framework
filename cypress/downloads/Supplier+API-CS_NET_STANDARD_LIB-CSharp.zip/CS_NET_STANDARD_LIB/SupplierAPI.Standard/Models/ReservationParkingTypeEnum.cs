// <copyright file="ReservationParkingTypeEnum.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace SupplierAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Runtime.Serialization;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using SupplierAPI.Standard;
    using SupplierAPI.Standard.Utilities;

    /// <summary>
    /// ReservationParkingTypeEnum.
    /// </summary>
    [JsonConverter(typeof(StringEnumConverter))]
    public enum ReservationParkingTypeEnum
    {
        /// <summary>
        /// NoReservationNeeded.
        /// </summary>
        [EnumMember(Value = "NoReservationNeeded")]
        NoReservationNeeded,

        /// <summary>
        /// NotPossible.
        /// </summary>
        [EnumMember(Value = "NotPossible")]
        NotPossible,

        /// <summary>
        /// ReservationNeeded.
        /// </summary>
        [EnumMember(Value = "ReservationNeeded")]
        ReservationNeeded
    }
}