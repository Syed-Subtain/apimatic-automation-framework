// <copyright file="NearbyAmenity.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace SupplierAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using SupplierAPI.Standard;
    using SupplierAPI.Standard.Utilities;

    /// <summary>
    /// NearbyAmenity.
    /// </summary>
    public class NearbyAmenity
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="NearbyAmenity"/> class.
        /// </summary>
        public NearbyAmenity()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="NearbyAmenity"/> class.
        /// </summary>
        /// <param name="attributeId">attributeId.</param>
        /// <param name="distance">distance.</param>
        public NearbyAmenity(
            Models.NearbyAmenitiesEnum attributeId,
            int? distance = null)
        {
            this.AttributeId = attributeId;
            this.Distance = distance;
        }

        /// <summary>
        /// List of allowed Nearby Amenities codes
        /// </summary>
        [JsonProperty("attributeId", ItemConverterType = typeof(StringEnumConverter))]
        public Models.NearbyAmenitiesEnum AttributeId { get; set; }

        /// <summary>
        /// Will be set to 0 by default
        /// </summary>
        [JsonProperty("distance", NullValueHandling = NullValueHandling.Ignore)]
        public int? Distance { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"NearbyAmenity : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is NearbyAmenity other &&
                this.AttributeId.Equals(other.AttributeId) &&
                ((this.Distance == null && other.Distance == null) || (this.Distance?.Equals(other.Distance) == true));
        }
        

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.AttributeId = {this.AttributeId}");
            toStringOutput.Add($"this.Distance = {(this.Distance == null ? "null" : this.Distance.ToString())}");
        }
    }
}