// <copyright file="PaymentPolicyTypeEnum.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace SupplierAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Runtime.Serialization;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using SupplierAPI.Standard;
    using SupplierAPI.Standard.Utilities;

    /// <summary>
    /// PaymentPolicyTypeEnum.
    /// </summary>
    [JsonConverter(typeof(StringEnumConverter))]
    public enum PaymentPolicyTypeEnum
    {
        /// <summary>
        ///Split payment policy
        /// SPLIT.
        /// </summary>
        [EnumMember(Value = "SPLIT")]
        SPLIT,

        /// <summary>
        ///Full payment policy
        /// FULL.
        /// </summary>
        [EnumMember(Value = "FULL")]
        FULL
    }
}