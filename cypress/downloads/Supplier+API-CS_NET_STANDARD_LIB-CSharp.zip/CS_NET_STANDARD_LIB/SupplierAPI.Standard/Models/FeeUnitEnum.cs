// <copyright file="FeeUnitEnum.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace SupplierAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Runtime.Serialization;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using SupplierAPI.Standard;
    using SupplierAPI.Standard.Utilities;

    /// <summary>
    /// FeeUnitEnum.
    /// </summary>
    [JsonConverter(typeof(StringEnumConverter))]
    public enum FeeUnitEnum
    {
        /// <summary>
        /// PERSTAY.
        /// </summary>
        [EnumMember(Value = "PER_STAY")]
        PERSTAY,

        /// <summary>
        /// PERDAY.
        /// </summary>
        [EnumMember(Value = "PER_DAY")]
        PERDAY,

        /// <summary>
        /// PERPERSON.
        /// </summary>
        [EnumMember(Value = "PER_PERSON")]
        PERPERSON,

        /// <summary>
        /// PERDAYPERPERSON.
        /// </summary>
        [EnumMember(Value = "PER_DAY_PER_PERSON")]
        PERDAYPERPERSON,

        /// <summary>
        /// PERDAYPERPERSONEXTRA.
        /// </summary>
        [EnumMember(Value = "PER_DAY_PER_PERSON_EXTRA")]
        PERDAYPERPERSONEXTRA
    }
}