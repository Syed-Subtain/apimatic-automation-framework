// <copyright file="LicenseResponseDataDetail.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace SupplierAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using SupplierAPI.Standard;
    using SupplierAPI.Standard.Utilities;

    /// <summary>
    /// LicenseResponseDataDetail.
    /// </summary>
    public class LicenseResponseDataDetail
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="LicenseResponseDataDetail"/> class.
        /// </summary>
        public LicenseResponseDataDetail()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="LicenseResponseDataDetail"/> class.
        /// </summary>
        /// <param name="variantId">variantId.</param>
        /// <param name="contentData">contentData.</param>
        public LicenseResponseDataDetail(
            string variantId = null,
            List<Models.LicenseResponseContentData> contentData = null)
        {
            this.VariantId = variantId;
            this.ContentData = contentData;
        }

        /// <summary>
        /// Variant ID
        /// </summary>
        [JsonProperty("variantId", NullValueHandling = NullValueHandling.Ignore)]
        public string VariantId { get; set; }

        /// <summary>
        /// Gets or sets ContentData.
        /// </summary>
        [JsonProperty("contentData", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.LicenseResponseContentData> ContentData { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"LicenseResponseDataDetail : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is LicenseResponseDataDetail other &&
                ((this.VariantId == null && other.VariantId == null) || (this.VariantId?.Equals(other.VariantId) == true)) &&
                ((this.ContentData == null && other.ContentData == null) || (this.ContentData?.Equals(other.ContentData) == true));
        }
        

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.VariantId = {(this.VariantId == null ? "null" : this.VariantId == string.Empty ? "" : this.VariantId)}");
            toStringOutput.Add($"this.ContentData = {(this.ContentData == null ? "null" : $"[{string.Join(", ", this.ContentData)} ]")}");
        }
    }
}