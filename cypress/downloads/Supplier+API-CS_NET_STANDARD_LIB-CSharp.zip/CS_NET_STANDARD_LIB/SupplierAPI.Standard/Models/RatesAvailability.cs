// <copyright file="RatesAvailability.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace SupplierAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using SupplierAPI.Standard;
    using SupplierAPI.Standard.Utilities;

    /// <summary>
    /// RatesAvailability.
    /// </summary>
    public class RatesAvailability
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="RatesAvailability"/> class.
        /// </summary>
        public RatesAvailability()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="RatesAvailability"/> class.
        /// </summary>
        /// <param name="productId">productId.</param>
        /// <param name="leadTime">leadTime.</param>
        /// <param name="rates">rates.</param>
        /// <param name="minStays">minStays.</param>
        /// <param name="maxStays">maxStays.</param>
        /// <param name="restrictions">restrictions.</param>
        /// <param name="availabilities">availabilities.</param>
        /// <param name="availableCount">availableCount.</param>
        public RatesAvailability(
            int productId,
            int? leadTime = null,
            List<Models.Rate> rates = null,
            List<Models.MinStayModel> minStays = null,
            List<Models.MaxStayModel> maxStays = null,
            List<Models.Restriction> restrictions = null,
            List<Models.AvailabilityModel> availabilities = null,
            List<Models.AvailableCount> availableCount = null)
        {
            this.ProductId = productId;
            this.LeadTime = leadTime;
            this.Rates = rates;
            this.MinStays = minStays;
            this.MaxStays = maxStays;
            this.Restrictions = restrictions;
            this.Availabilities = availabilities;
            this.AvailableCount = availableCount;
        }

        /// <summary>
        /// ID of the product
        /// </summary>
        [JsonProperty("productId")]
        public int ProductId { get; set; }

        /// <summary>
        /// Number of days before reservation in which reservation couldn’t be made. Allowed values are 0-7. If this value is set on property level - it will be used before than value on PM level.
        /// </summary>
        [JsonProperty("leadTime", NullValueHandling = NullValueHandling.Ignore)]
        public int? LeadTime { get; set; }

        /// <summary>
        /// List of models
        /// </summary>
        [JsonProperty("rates", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.Rate> Rates { get; set; }

        /// <summary>
        /// List of models
        /// </summary>
        [JsonProperty("minStays", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.MinStayModel> MinStays { get; set; }

        /// <summary>
        /// List of models
        /// </summary>
        [JsonProperty("maxStays", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.MaxStayModel> MaxStays { get; set; }

        /// <summary>
        /// List of models
        /// </summary>
        [JsonProperty("restrictions", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.Restriction> Restrictions { get; set; }

        /// <summary>
        /// List of models
        /// </summary>
        [JsonProperty("availabilities", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.AvailabilityModel> Availabilities { get; set; }

        /// <summary>
        /// List of models (Only for MLT properties)
        /// </summary>
        [JsonProperty("availableCount", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.AvailableCount> AvailableCount { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"RatesAvailability : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is RatesAvailability other &&
                this.ProductId.Equals(other.ProductId) &&
                ((this.LeadTime == null && other.LeadTime == null) || (this.LeadTime?.Equals(other.LeadTime) == true)) &&
                ((this.Rates == null && other.Rates == null) || (this.Rates?.Equals(other.Rates) == true)) &&
                ((this.MinStays == null && other.MinStays == null) || (this.MinStays?.Equals(other.MinStays) == true)) &&
                ((this.MaxStays == null && other.MaxStays == null) || (this.MaxStays?.Equals(other.MaxStays) == true)) &&
                ((this.Restrictions == null && other.Restrictions == null) || (this.Restrictions?.Equals(other.Restrictions) == true)) &&
                ((this.Availabilities == null && other.Availabilities == null) || (this.Availabilities?.Equals(other.Availabilities) == true)) &&
                ((this.AvailableCount == null && other.AvailableCount == null) || (this.AvailableCount?.Equals(other.AvailableCount) == true));
        }
        

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.ProductId = {this.ProductId}");
            toStringOutput.Add($"this.LeadTime = {(this.LeadTime == null ? "null" : this.LeadTime.ToString())}");
            toStringOutput.Add($"this.Rates = {(this.Rates == null ? "null" : $"[{string.Join(", ", this.Rates)} ]")}");
            toStringOutput.Add($"this.MinStays = {(this.MinStays == null ? "null" : $"[{string.Join(", ", this.MinStays)} ]")}");
            toStringOutput.Add($"this.MaxStays = {(this.MaxStays == null ? "null" : $"[{string.Join(", ", this.MaxStays)} ]")}");
            toStringOutput.Add($"this.Restrictions = {(this.Restrictions == null ? "null" : $"[{string.Join(", ", this.Restrictions)} ]")}");
            toStringOutput.Add($"this.Availabilities = {(this.Availabilities == null ? "null" : $"[{string.Join(", ", this.Availabilities)} ]")}");
            toStringOutput.Add($"this.AvailableCount = {(this.AvailableCount == null ? "null" : $"[{string.Join(", ", this.AvailableCount)} ]")}");
        }
    }
}