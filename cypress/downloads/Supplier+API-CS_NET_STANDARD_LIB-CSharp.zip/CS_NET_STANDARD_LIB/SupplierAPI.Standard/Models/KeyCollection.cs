// <copyright file="KeyCollection.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace SupplierAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using SupplierAPI.Standard;
    using SupplierAPI.Standard.Utilities;

    /// <summary>
    /// KeyCollection.
    /// </summary>
    public class KeyCollection
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="KeyCollection"/> class.
        /// </summary>
        public KeyCollection()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="KeyCollection"/> class.
        /// </summary>
        /// <param name="type">type.</param>
        /// <param name="checkInMethod">checkInMethod.</param>
        /// <param name="additionalInfo">additionalInfo.</param>
        public KeyCollection(
            string type,
            Models.KeyCollectionCheckinmethodEnum checkInMethod,
            Models.KeyCollectionadditionalinformation additionalInfo)
        {
            this.Type = type;
            this.CheckInMethod = checkInMethod;
            this.AdditionalInfo = additionalInfo;
        }

        /// <summary>
        /// required string where accepted strings = {"primary"}
        /// </summary>
        [JsonProperty("type")]
        public string Type { get; set; }

        /// <summary>
        /// Gets or sets CheckInMethod.
        /// </summary>
        [JsonProperty("checkInMethod", ItemConverterType = typeof(StringEnumConverter))]
        public Models.KeyCollectionCheckinmethodEnum CheckInMethod { get; set; }

        /// <summary>
        /// Gets or sets AdditionalInfo.
        /// </summary>
        [JsonProperty("additionalInfo")]
        public Models.KeyCollectionadditionalinformation AdditionalInfo { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"KeyCollection : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is KeyCollection other &&
                ((this.Type == null && other.Type == null) || (this.Type?.Equals(other.Type) == true)) &&
                this.CheckInMethod.Equals(other.CheckInMethod) &&
                ((this.AdditionalInfo == null && other.AdditionalInfo == null) || (this.AdditionalInfo?.Equals(other.AdditionalInfo) == true));
        }
        

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.Type = {(this.Type == null ? "null" : this.Type == string.Empty ? "" : this.Type)}");
            toStringOutput.Add($"this.CheckInMethod = {this.CheckInMethod}");
            toStringOutput.Add($"this.AdditionalInfo = {(this.AdditionalInfo == null ? "null" : this.AdditionalInfo.ToString())}");
        }
    }
}