// <copyright file="UserEnum.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace SupplierAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Runtime.Serialization;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using SupplierAPI.Standard;
    using SupplierAPI.Standard.Utilities;

    /// <summary>
    /// UserEnum.
    /// </summary>
    [JsonConverter(typeof(StringEnumConverter))]
    public enum UserEnum
    {
        /// <summary>
        /// PROPERTYMANAGER.
        /// </summary>
        [EnumMember(Value = "PROPERTY_MANAGER")]
        PROPERTYMANAGER,

        /// <summary>
        /// GUEST.
        /// </summary>
        [EnumMember(Value = "GUEST")]
        GUEST
    }
}