// <copyright file="TransportYield.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace SupplierAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using SupplierAPI.Standard;
    using SupplierAPI.Standard.Utilities;

    /// <summary>
    /// TransportYield.
    /// </summary>
    public class TransportYield
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="TransportYield"/> class.
        /// </summary>
        public TransportYield()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="TransportYield"/> class.
        /// </summary>
        /// <param name="productId">productId.</param>
        /// <param name="weekend">weekend.</param>
        /// <param name="lengthOfStay">lengthOfStay.</param>
        /// <param name="dateRange">dateRange.</param>
        /// <param name="channelMarkup">channelMarkup.</param>
        public TransportYield(
            int productId,
            List<Models.Yield> weekend = null,
            List<Models.Yield> lengthOfStay = null,
            List<Models.Yield> dateRange = null,
            List<Models.ChannelMarkUpYieldInfo> channelMarkup = null)
        {
            this.ProductId = productId;
            this.Weekend = weekend;
            this.LengthOfStay = lengthOfStay;
            this.DateRange = dateRange;
            this.ChannelMarkup = channelMarkup;
        }

        /// <summary>
        /// ID of the product
        /// </summary>
        [JsonProperty("productId")]
        public int ProductId { get; set; }

        /// <summary>
        /// Set a specific date range in which you would like to manipulate the basic price per night on weekends.  For example you will set the YMR date range from 01.07.2016-31.07.2016 param - (Friday, Saturday=0; Saturday, Sunday=1) yield amount = 20 modifier - Increase Percent Price per night in the period from 01.07.2016 to 31.07.2016 will be 100 USD in working days and 100 + 20% = 120 USD in weekends (Friday, Saturday or Saturday, Sunday, depending on what was selected).
        /// </summary>
        [JsonProperty("weekend", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.Yield> Weekend { get; set; }

        /// <summary>
        /// Automatically applies price modifications to inquiries based on the number of nights the inquiries are for.  For example you will set the YMR date range from 01.07.2016-31.07.2017 param - {Length of Stay}. Let’s say you set 15 days. yield amount = 5 modifier - Decrease Percent Price per night if you made a reservation for 15 or more days will be 100 - 5% = 95 USD
        /// </summary>
        [JsonProperty("lengthOfStay", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.Yield> LengthOfStay { get; set; }

        /// <summary>
        /// Set a specific date range in which you would like to manipulate the basic price per night.  For example you will set the YMR date range from 01.07.2016-31.07.2016 yield amount = 20 modifier - Increase Percent Price per night in the period from 01.07.2016 to 31.07.2016 will be 100 + 20% = 120 USD
        /// </summary>
        [JsonProperty("dateRange", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.Yield> DateRange { get; set; }

        /// <summary>
        /// Gets or sets ChannelMarkup.
        /// </summary>
        [JsonProperty("channelMarkup", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.ChannelMarkUpYieldInfo> ChannelMarkup { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"TransportYield : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is TransportYield other &&
                this.ProductId.Equals(other.ProductId) &&
                ((this.Weekend == null && other.Weekend == null) || (this.Weekend?.Equals(other.Weekend) == true)) &&
                ((this.LengthOfStay == null && other.LengthOfStay == null) || (this.LengthOfStay?.Equals(other.LengthOfStay) == true)) &&
                ((this.DateRange == null && other.DateRange == null) || (this.DateRange?.Equals(other.DateRange) == true)) &&
                ((this.ChannelMarkup == null && other.ChannelMarkup == null) || (this.ChannelMarkup?.Equals(other.ChannelMarkup) == true));
        }
        

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.ProductId = {this.ProductId}");
            toStringOutput.Add($"this.Weekend = {(this.Weekend == null ? "null" : $"[{string.Join(", ", this.Weekend)} ]")}");
            toStringOutput.Add($"this.LengthOfStay = {(this.LengthOfStay == null ? "null" : $"[{string.Join(", ", this.LengthOfStay)} ]")}");
            toStringOutput.Add($"this.DateRange = {(this.DateRange == null ? "null" : $"[{string.Join(", ", this.DateRange)} ]")}");
            toStringOutput.Add($"this.ChannelMarkup = {(this.ChannelMarkup == null ? "null" : $"[{string.Join(", ", this.ChannelMarkup)} ]")}");
        }
    }
}