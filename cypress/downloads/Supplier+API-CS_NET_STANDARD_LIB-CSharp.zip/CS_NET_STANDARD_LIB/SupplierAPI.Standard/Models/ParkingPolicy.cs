// <copyright file="ParkingPolicy.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace SupplierAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using SupplierAPI.Standard;
    using SupplierAPI.Standard.Utilities;

    /// <summary>
    /// ParkingPolicy.
    /// </summary>
    public class ParkingPolicy
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ParkingPolicy"/> class.
        /// </summary>
        public ParkingPolicy()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ParkingPolicy"/> class.
        /// </summary>
        /// <param name="accessParking">accessParking.</param>
        /// <param name="locatedParking">locatedParking.</param>
        /// <param name="privateParking">privateParking.</param>
        /// <param name="chargeParking">chargeParking.</param>
        /// <param name="timeCostParking">timeCostParking.</param>
        /// <param name="necessaryReservationParking">necessaryReservationParking.</param>
        public ParkingPolicy(
            bool accessParking,
            Models.LocatedParkingTypeEnum? locatedParking = null,
            bool? privateParking = null,
            string chargeParking = null,
            Models.TimeCostParkingEnum? timeCostParking = null,
            Models.ReservationParkingTypeEnum? necessaryReservationParking = null)
        {
            this.AccessParking = accessParking;
            this.LocatedParking = locatedParking;
            this.PrivateParking = privateParking;
            this.ChargeParking = chargeParking;
            this.TimeCostParking = timeCostParking;
            this.NecessaryReservationParking = necessaryReservationParking;
        }

        /// <summary>
        /// Access parking into properties {true,false}
        /// </summary>
        [JsonProperty("accessParking")]
        public bool AccessParking { get; set; }

        /// <summary>
        /// Gets or sets LocatedParking.
        /// </summary>
        [JsonProperty("locatedParking", ItemConverterType = typeof(StringEnumConverter), NullValueHandling = NullValueHandling.Ignore)]
        public Models.LocatedParkingTypeEnum? LocatedParking { get; set; }

        /// <summary>
        /// Parking is private or no. {true,false}
        /// </summary>
        [JsonProperty("privateParking", NullValueHandling = NullValueHandling.Ignore)]
        public bool? PrivateParking { get; set; }

        /// <summary>
        /// Charge parking. Example: “Free”, “$ 100”.
        /// </summary>
        [JsonProperty("chargeParking", NullValueHandling = NullValueHandling.Ignore)]
        public string ChargeParking { get; set; }

        /// <summary>
        /// Gets or sets TimeCostParking.
        /// </summary>
        [JsonProperty("timeCostParking", ItemConverterType = typeof(StringEnumConverter), NullValueHandling = NullValueHandling.Ignore)]
        public Models.TimeCostParkingEnum? TimeCostParking { get; set; }

        /// <summary>
        /// Gets or sets NecessaryReservationParking.
        /// </summary>
        [JsonProperty("necessaryReservationParking", ItemConverterType = typeof(StringEnumConverter), NullValueHandling = NullValueHandling.Ignore)]
        public Models.ReservationParkingTypeEnum? NecessaryReservationParking { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"ParkingPolicy : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is ParkingPolicy other &&
                this.AccessParking.Equals(other.AccessParking) &&
                ((this.LocatedParking == null && other.LocatedParking == null) || (this.LocatedParking?.Equals(other.LocatedParking) == true)) &&
                ((this.PrivateParking == null && other.PrivateParking == null) || (this.PrivateParking?.Equals(other.PrivateParking) == true)) &&
                ((this.ChargeParking == null && other.ChargeParking == null) || (this.ChargeParking?.Equals(other.ChargeParking) == true)) &&
                ((this.TimeCostParking == null && other.TimeCostParking == null) || (this.TimeCostParking?.Equals(other.TimeCostParking) == true)) &&
                ((this.NecessaryReservationParking == null && other.NecessaryReservationParking == null) || (this.NecessaryReservationParking?.Equals(other.NecessaryReservationParking) == true));
        }
        

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.AccessParking = {this.AccessParking}");
            toStringOutput.Add($"this.LocatedParking = {(this.LocatedParking == null ? "null" : this.LocatedParking.ToString())}");
            toStringOutput.Add($"this.PrivateParking = {(this.PrivateParking == null ? "null" : this.PrivateParking.ToString())}");
            toStringOutput.Add($"this.ChargeParking = {(this.ChargeParking == null ? "null" : this.ChargeParking == string.Empty ? "" : this.ChargeParking)}");
            toStringOutput.Add($"this.TimeCostParking = {(this.TimeCostParking == null ? "null" : this.TimeCostParking.ToString())}");
            toStringOutput.Add($"this.NecessaryReservationParking = {(this.NecessaryReservationParking == null ? "null" : this.NecessaryReservationParking.ToString())}");
        }
    }
}