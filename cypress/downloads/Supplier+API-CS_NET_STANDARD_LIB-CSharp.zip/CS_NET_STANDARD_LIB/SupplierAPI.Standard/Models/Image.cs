// <copyright file="Image.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace SupplierAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using SupplierAPI.Standard;
    using SupplierAPI.Standard.Utilities;

    /// <summary>
    /// Image.
    /// </summary>
    public class Image
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="Image"/> class.
        /// </summary>
        public Image()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="Image"/> class.
        /// </summary>
        /// <param name="url">url.</param>
        /// <param name="tags">tags.</param>
        /// <param name="urlMbp">urlMbp.</param>
        /// <param name="sort">sort.</param>
        public Image(
            string url,
            List<Models.ImageTagsEnum> tags = null,
            string urlMbp = null,
            int? sort = null)
        {
            this.Url = url;
            this.Tags = tags;
            this.UrlMbp = urlMbp;
            this.Sort = sort;
        }

        /// <summary>
        /// URL of the image. Please send normal URL, like https://example.com/image01.jpg, and do not use some GET parameters in URL, otherwise image might not be imported.
        /// </summary>
        [JsonProperty("url")]
        public string Url { get; set; }

        /// <summary>
        /// Image tags. Tags codes are given in Appendix.
        /// </summary>
        [JsonProperty("tags", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.ImageTagsEnum> Tags { get; set; }

        /// <summary>
        /// URL of the image on MyBookingPal. This field will be only in response. You can not send this in request.
        /// </summary>
        [JsonProperty("urlMbp", NullValueHandling = NullValueHandling.Ignore)]
        public string UrlMbp { get; set; }

        /// <summary>
        /// Sort of the image. Image with the lowest sort number will be set as main. This field will be only in response. You can not send this in request.
        /// </summary>
        [JsonProperty("sort", NullValueHandling = NullValueHandling.Ignore)]
        public int? Sort { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"Image : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is Image other &&
                ((this.Url == null && other.Url == null) || (this.Url?.Equals(other.Url) == true)) &&
                ((this.Tags == null && other.Tags == null) || (this.Tags?.Equals(other.Tags) == true)) &&
                ((this.UrlMbp == null && other.UrlMbp == null) || (this.UrlMbp?.Equals(other.UrlMbp) == true)) &&
                ((this.Sort == null && other.Sort == null) || (this.Sort?.Equals(other.Sort) == true));
        }
        

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.Url = {(this.Url == null ? "null" : this.Url == string.Empty ? "" : this.Url)}");
            toStringOutput.Add($"this.Tags = {(this.Tags == null ? "null" : $"[{string.Join(", ", this.Tags)} ]")}");
            toStringOutput.Add($"this.UrlMbp = {(this.UrlMbp == null ? "null" : this.UrlMbp == string.Empty ? "" : this.UrlMbp)}");
            toStringOutput.Add($"this.Sort = {(this.Sort == null ? "null" : this.Sort.ToString())}");
        }
    }
}