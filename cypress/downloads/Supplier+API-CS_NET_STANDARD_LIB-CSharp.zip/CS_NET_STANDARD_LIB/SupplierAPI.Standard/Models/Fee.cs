// <copyright file="Fee.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace SupplierAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using SupplierAPI.Standard;
    using SupplierAPI.Standard.Utilities;

    /// <summary>
    /// Fee.
    /// </summary>
    public class Fee
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="Fee"/> class.
        /// </summary>
        public Fee()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="Fee"/> class.
        /// </summary>
        /// <param name="entityType">entityType.</param>
        /// <param name="feeType">feeType.</param>
        /// <param name="name">name.</param>
        /// <param name="unit">unit.</param>
        /// <param name="mValue">value.</param>
        /// <param name="valueType">valueType.</param>
        /// <param name="beginDate">beginDate.</param>
        /// <param name="endDate">endDate.</param>
        /// <param name="option">option.</param>
        /// <param name="taxType">taxType.</param>
        /// <param name="altId">altId.</param>
        public Fee(
            Models.FeeEntityTypeEnum entityType,
            Models.FeeTypeEnum feeType,
            string name,
            Models.FeeUnitEnum unit,
            double mValue,
            Models.FeeValueTypeEnum valueType,
            DateTime? beginDate = null,
            DateTime? endDate = null,
            int? option = null,
            Models.FeeTaxTypeEnum? taxType = null,
            string altId = null)
        {
            this.BeginDate = beginDate;
            this.EndDate = endDate;
            this.EntityType = entityType;
            this.FeeType = feeType;
            this.Option = option;
            this.Name = name;
            this.TaxType = taxType;
            this.Unit = unit;
            this.MValue = mValue;
            this.ValueType = valueType;
            this.AltId = altId;
        }

        /// <summary>
        /// Fee applies from Date. Date should be in format "yyyy-MM-dd"
        /// </summary>
        [JsonConverter(typeof(CustomDateTimeConverter), "yyyy'-'MM'-'dd")]
        [JsonProperty("beginDate", NullValueHandling = NullValueHandling.Ignore)]
        public DateTime? BeginDate { get; set; }

        /// <summary>
        /// Fee applies to Date. Date should be in format "yyyy-MM-dd"
        /// </summary>
        [JsonConverter(typeof(CustomDateTimeConverter), "yyyy'-'MM'-'dd")]
        [JsonProperty("endDate", NullValueHandling = NullValueHandling.Ignore)]
        public DateTime? EndDate { get; set; }

        /// <summary>
        /// Gets or sets EntityType.
        /// </summary>
        [JsonProperty("entityType", ItemConverterType = typeof(StringEnumConverter))]
        public Models.FeeEntityTypeEnum EntityType { get; set; }

        /// <summary>
        /// Gets or sets FeeType.
        /// </summary>
        [JsonProperty("feeType", ItemConverterType = typeof(StringEnumConverter))]
        public Models.FeeTypeEnum FeeType { get; set; }

        /// <summary>
        /// Number of guests when set extra person fee. Only values >0 are allowed.
        /// </summary>
        [JsonProperty("option", NullValueHandling = NullValueHandling.Ignore)]
        public int? Option { get; set; }

        /// <summary>
        /// Fee name.  For example: Extra person, Cleaning fee, Parking etc.
        /// </summary>
        [JsonProperty("name")]
        public string Name { get; set; }

        /// <summary>
        /// Gets or sets TaxType.
        /// </summary>
        [JsonProperty("taxType", ItemConverterType = typeof(StringEnumConverter), NullValueHandling = NullValueHandling.Ignore)]
        public Models.FeeTaxTypeEnum? TaxType { get; set; }

        /// <summary>
        /// Gets or sets Unit.
        /// </summary>
        [JsonProperty("unit", ItemConverterType = typeof(StringEnumConverter))]
        public Models.FeeUnitEnum Unit { get; set; }

        /// <summary>
        /// Fee value
        /// </summary>
        [JsonProperty("value")]
        public double MValue { get; set; }

        /// <summary>
        /// Value Type {FLAT, PERCENT}
        /// </summary>
        [JsonProperty("valueType", ItemConverterType = typeof(StringEnumConverter))]
        public Models.FeeValueTypeEnum ValueType { get; set; }

        /// <summary>
        /// Alternative Id of the fee (fee id in your system)
        /// </summary>
        [JsonProperty("altId", NullValueHandling = NullValueHandling.Ignore)]
        public string AltId { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"Fee : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is Fee other &&
                ((this.BeginDate == null && other.BeginDate == null) || (this.BeginDate?.Equals(other.BeginDate) == true)) &&
                ((this.EndDate == null && other.EndDate == null) || (this.EndDate?.Equals(other.EndDate) == true)) &&
                this.EntityType.Equals(other.EntityType) &&
                this.FeeType.Equals(other.FeeType) &&
                ((this.Option == null && other.Option == null) || (this.Option?.Equals(other.Option) == true)) &&
                ((this.Name == null && other.Name == null) || (this.Name?.Equals(other.Name) == true)) &&
                ((this.TaxType == null && other.TaxType == null) || (this.TaxType?.Equals(other.TaxType) == true)) &&
                this.Unit.Equals(other.Unit) &&
                this.MValue.Equals(other.MValue) &&
                this.ValueType.Equals(other.ValueType) &&
                ((this.AltId == null && other.AltId == null) || (this.AltId?.Equals(other.AltId) == true));
        }
        

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.BeginDate = {(this.BeginDate == null ? "null" : this.BeginDate.ToString())}");
            toStringOutput.Add($"this.EndDate = {(this.EndDate == null ? "null" : this.EndDate.ToString())}");
            toStringOutput.Add($"this.EntityType = {this.EntityType}");
            toStringOutput.Add($"this.FeeType = {this.FeeType}");
            toStringOutput.Add($"this.Option = {(this.Option == null ? "null" : this.Option.ToString())}");
            toStringOutput.Add($"this.Name = {(this.Name == null ? "null" : this.Name == string.Empty ? "" : this.Name)}");
            toStringOutput.Add($"this.TaxType = {(this.TaxType == null ? "null" : this.TaxType.ToString())}");
            toStringOutput.Add($"this.Unit = {this.Unit}");
            toStringOutput.Add($"this.MValue = {this.MValue}");
            toStringOutput.Add($"this.ValueType = {this.ValueType}");
            toStringOutput.Add($"this.AltId = {(this.AltId == null ? "null" : this.AltId == string.Empty ? "" : this.AltId)}");
        }
    }
}