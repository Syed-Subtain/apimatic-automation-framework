// <copyright file="LicenseInfoResponse.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace SupplierAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using SupplierAPI.Standard;
    using SupplierAPI.Standard.Utilities;

    /// <summary>
    /// LicenseInfoResponse.
    /// </summary>
    public class LicenseInfoResponse
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="LicenseInfoResponse"/> class.
        /// </summary>
        public LicenseInfoResponse()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="LicenseInfoResponse"/> class.
        /// </summary>
        /// <param name="data">data.</param>
        /// <param name="meta">meta.</param>
        /// <param name="warnings">warnings.</param>
        /// <param name="errors">errors.</param>
        public LicenseInfoResponse(
            List<Models.LicenseResponseDataDetail> data = null,
            List<Models.LicenseRequirementMeta> meta = null,
            List<string> warnings = null,
            List<string> errors = null)
        {
            this.Data = data;
            this.Meta = meta;
            this.Warnings = warnings;
            this.Errors = errors;
        }

        /// <summary>
        /// Gets or sets Data.
        /// </summary>
        [JsonProperty("data", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.LicenseResponseDataDetail> Data { get; set; }

        /// <summary>
        /// Gets or sets Meta.
        /// </summary>
        [JsonProperty("meta", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.LicenseRequirementMeta> Meta { get; set; }

        /// <summary>
        /// List of warning messages
        /// </summary>
        [JsonProperty("warnings", NullValueHandling = NullValueHandling.Ignore)]
        public List<string> Warnings { get; set; }

        /// <summary>
        /// List of error messages
        /// </summary>
        [JsonProperty("errors", NullValueHandling = NullValueHandling.Ignore)]
        public List<string> Errors { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"LicenseInfoResponse : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is LicenseInfoResponse other &&
                ((this.Data == null && other.Data == null) || (this.Data?.Equals(other.Data) == true)) &&
                ((this.Meta == null && other.Meta == null) || (this.Meta?.Equals(other.Meta) == true)) &&
                ((this.Warnings == null && other.Warnings == null) || (this.Warnings?.Equals(other.Warnings) == true)) &&
                ((this.Errors == null && other.Errors == null) || (this.Errors?.Equals(other.Errors) == true));
        }
        

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.Data = {(this.Data == null ? "null" : $"[{string.Join(", ", this.Data)} ]")}");
            toStringOutput.Add($"this.Meta = {(this.Meta == null ? "null" : $"[{string.Join(", ", this.Meta)} ]")}");
            toStringOutput.Add($"this.Warnings = {(this.Warnings == null ? "null" : $"[{string.Join(", ", this.Warnings)} ]")}");
            toStringOutput.Add($"this.Errors = {(this.Errors == null ? "null" : $"[{string.Join(", ", this.Errors)} ]")}");
        }
    }
}