// <copyright file="ProductImagePushNotification.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace SupplierAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using SupplierAPI.Standard;
    using SupplierAPI.Standard.Utilities;

    /// <summary>
    /// ProductImagePushNotification.
    /// </summary>
    public class ProductImagePushNotification
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ProductImagePushNotification"/> class.
        /// </summary>
        public ProductImagePushNotification()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ProductImagePushNotification"/> class.
        /// </summary>
        /// <param name="name">name.</param>
        /// <param name="productId">productId.</param>
        /// <param name="images">images.</param>
        /// <param name="altId">altId.</param>
        public ProductImagePushNotification(
            string name,
            string productId,
            List<Models.ImagePushNotification> images,
            string altId = null)
        {
            this.Name = name;
            this.ProductId = productId;
            this.AltId = altId;
            this.Images = images;
        }

        /// <summary>
        /// name of the object
        /// </summary>
        [JsonProperty("name")]
        public string Name { get; set; }

        /// <summary>
        /// product id
        /// </summary>
        [JsonProperty("productId")]
        public string ProductId { get; set; }

        /// <summary>
        /// product alternate id
        /// </summary>
        [JsonProperty("altId", NullValueHandling = NullValueHandling.Ignore)]
        public string AltId { get; set; }

        /// <summary>
        /// Gets or sets Images.
        /// </summary>
        [JsonProperty("images")]
        public List<Models.ImagePushNotification> Images { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"ProductImagePushNotification : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is ProductImagePushNotification other &&
                ((this.Name == null && other.Name == null) || (this.Name?.Equals(other.Name) == true)) &&
                ((this.ProductId == null && other.ProductId == null) || (this.ProductId?.Equals(other.ProductId) == true)) &&
                ((this.AltId == null && other.AltId == null) || (this.AltId?.Equals(other.AltId) == true)) &&
                ((this.Images == null && other.Images == null) || (this.Images?.Equals(other.Images) == true));
        }
        

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.Name = {(this.Name == null ? "null" : this.Name == string.Empty ? "" : this.Name)}");
            toStringOutput.Add($"this.ProductId = {(this.ProductId == null ? "null" : this.ProductId == string.Empty ? "" : this.ProductId)}");
            toStringOutput.Add($"this.AltId = {(this.AltId == null ? "null" : this.AltId == string.Empty ? "" : this.AltId)}");
            toStringOutput.Add($"this.Images = {(this.Images == null ? "null" : $"[{string.Join(", ", this.Images)} ]")}");
        }
    }
}