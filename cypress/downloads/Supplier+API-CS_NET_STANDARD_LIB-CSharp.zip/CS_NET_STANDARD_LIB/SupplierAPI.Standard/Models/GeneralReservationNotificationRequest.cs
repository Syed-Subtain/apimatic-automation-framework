// <copyright file="GeneralReservationNotificationRequest.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace SupplierAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using SupplierAPI.Standard;
    using SupplierAPI.Standard.Utilities;

    /// <summary>
    /// GeneralReservationNotificationRequest.
    /// </summary>
    public class GeneralReservationNotificationRequest
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="GeneralReservationNotificationRequest"/> class.
        /// </summary>
        public GeneralReservationNotificationRequest()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="GeneralReservationNotificationRequest"/> class.
        /// </summary>
        /// <param name="reservationNotificationRequest">reservationNotificationRequest.</param>
        /// <param name="action">action.</param>
        public GeneralReservationNotificationRequest(
            Models.NewReservationNotificationObject reservationNotificationRequest,
            Models.GeneralReservationNotificationActionTypeEnum action)
        {
            this.ReservationNotificationRequest = reservationNotificationRequest;
            this.Action = action;
        }

        /// <summary>
        /// Gets or sets ReservationNotificationRequest.
        /// </summary>
        [JsonProperty("reservationNotificationRequest")]
        public Models.NewReservationNotificationObject ReservationNotificationRequest { get; set; }

        /// <summary>
        /// Gets or sets Action.
        /// </summary>
        [JsonProperty("action", ItemConverterType = typeof(StringEnumConverter))]
        public Models.GeneralReservationNotificationActionTypeEnum Action { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"GeneralReservationNotificationRequest : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is GeneralReservationNotificationRequest other &&
                ((this.ReservationNotificationRequest == null && other.ReservationNotificationRequest == null) || (this.ReservationNotificationRequest?.Equals(other.ReservationNotificationRequest) == true)) &&
                this.Action.Equals(other.Action);
        }
        

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.ReservationNotificationRequest = {(this.ReservationNotificationRequest == null ? "null" : this.ReservationNotificationRequest.ToString())}");
            toStringOutput.Add($"this.Action = {this.Action}");
        }
    }
}