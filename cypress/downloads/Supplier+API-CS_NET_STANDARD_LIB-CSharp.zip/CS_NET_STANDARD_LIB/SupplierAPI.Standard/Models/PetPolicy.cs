// <copyright file="PetPolicy.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace SupplierAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using SupplierAPI.Standard;
    using SupplierAPI.Standard.Utilities;

    /// <summary>
    /// PetPolicy.
    /// </summary>
    public class PetPolicy
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="PetPolicy"/> class.
        /// </summary>
        public PetPolicy()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="PetPolicy"/> class.
        /// </summary>
        /// <param name="allowedPets">allowedPets.</param>
        /// <param name="chargePets">chargePets.</param>
        public PetPolicy(
            Models.AllowedPetsTypeEnum allowedPets,
            string chargePets = null)
        {
            this.AllowedPets = allowedPets;
            this.ChargePets = chargePets;
        }

        /// <summary>
        /// Gets or sets AllowedPets.
        /// </summary>
        [JsonProperty("allowedPets", ItemConverterType = typeof(StringEnumConverter))]
        public Models.AllowedPetsTypeEnum AllowedPets { get; set; }

        /// <summary>
        /// Charge parking. Example: “Free”, “$ 100”.
        /// </summary>
        [JsonProperty("chargePets", NullValueHandling = NullValueHandling.Ignore)]
        public string ChargePets { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"PetPolicy : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is PetPolicy other &&
                this.AllowedPets.Equals(other.AllowedPets) &&
                ((this.ChargePets == null && other.ChargePets == null) || (this.ChargePets?.Equals(other.ChargePets) == true));
        }
        

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.AllowedPets = {this.AllowedPets}");
            toStringOutput.Add($"this.ChargePets = {(this.ChargePets == null ? "null" : this.ChargePets == string.Empty ? "" : this.ChargePets)}");
        }
    }
}