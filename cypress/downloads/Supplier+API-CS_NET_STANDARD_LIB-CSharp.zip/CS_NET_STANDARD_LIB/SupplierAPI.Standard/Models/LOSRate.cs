// <copyright file="LOSRate.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace SupplierAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using SupplierAPI.Standard;
    using SupplierAPI.Standard.Utilities;

    /// <summary>
    /// LOSRate.
    /// </summary>
    public class LOSRate
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="LOSRate"/> class.
        /// </summary>
        public LOSRate()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="LOSRate"/> class.
        /// </summary>
        /// <param name="checkInDate">checkInDate.</param>
        /// <param name="maxGuests">maxGuests.</param>
        /// <param name="losValue">losValue.</param>
        /// <param name="currency">currency.</param>
        public LOSRate(
            DateTime checkInDate,
            int maxGuests,
            List<double> losValue,
            string currency = null)
        {
            this.CheckInDate = checkInDate;
            this.MaxGuests = maxGuests;
            this.LosValue = losValue;
            this.Currency = currency;
        }

        /// <summary>
        /// Check-in Date. Date should be in format "yyyy-MM-dd"
        /// </summary>
        [JsonConverter(typeof(CustomDateTimeConverter), "yyyy'-'MM'-'dd")]
        [JsonProperty("checkInDate")]
        public DateTime CheckInDate { get; set; }

        /// <summary>
        /// Max guests for check in date
        /// </summary>
        [JsonProperty("maxGuests")]
        public int MaxGuests { get; set; }

        /// <summary>
        /// List rates value per day. First value is for reservation for 1 day. Secoon. If you do not support booking for some specific number of days, set value 0 for that element in array.nd value is for reservation for 2 days, and so on. If you do not support booking for some specific number of days, set value 0 for that element in array.
        /// </summary>
        [JsonProperty("losValue")]
        public List<double> LosValue { get; set; }

        /// <summary>
        /// Currency for rates. It will be visiable only in GET response. You should not set this field in request since we will use product currency for every rate.
        /// </summary>
        [JsonProperty("currency", NullValueHandling = NullValueHandling.Ignore)]
        public string Currency { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"LOSRate : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is LOSRate other &&
                this.CheckInDate.Equals(other.CheckInDate) &&
                this.MaxGuests.Equals(other.MaxGuests) &&
                ((this.LosValue == null && other.LosValue == null) || (this.LosValue?.Equals(other.LosValue) == true)) &&
                ((this.Currency == null && other.Currency == null) || (this.Currency?.Equals(other.Currency) == true));
        }
        

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.CheckInDate = {this.CheckInDate}");
            toStringOutput.Add($"this.MaxGuests = {this.MaxGuests}");
            toStringOutput.Add($"this.LosValue = {(this.LosValue == null ? "null" : $"[{string.Join(", ", this.LosValue)} ]")}");
            toStringOutput.Add($"this.Currency = {(this.Currency == null ? "null" : this.Currency == string.Empty ? "" : this.Currency)}");
        }
    }
}