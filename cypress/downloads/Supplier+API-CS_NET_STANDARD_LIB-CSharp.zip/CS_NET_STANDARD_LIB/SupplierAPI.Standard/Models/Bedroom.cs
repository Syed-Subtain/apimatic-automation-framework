// <copyright file="Bedroom.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace SupplierAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using SupplierAPI.Standard;
    using SupplierAPI.Standard.Utilities;

    /// <summary>
    /// Bedroom.
    /// </summary>
    public class Bedroom
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="Bedroom"/> class.
        /// </summary>
        public Bedroom()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="Bedroom"/> class.
        /// </summary>
        /// <param name="beds">beds.</param>
        /// <param name="type">type.</param>
        /// <param name="privateBathroom">privateBathroom.</param>
        public Bedroom(
            Models.Beds beds,
            Models.BedroomTypeEnum type,
            bool privateBathroom)
        {
            this.Beds = beds;
            this.Type = type;
            this.PrivateBathroom = privateBathroom;
        }

        /// <summary>
        /// Gets or sets Beds.
        /// </summary>
        [JsonProperty("beds")]
        public Models.Beds Beds { get; set; }

        /// <summary>
        /// Gets or sets Type.
        /// </summary>
        [JsonProperty("type", ItemConverterType = typeof(StringEnumConverter))]
        public Models.BedroomTypeEnum Type { get; set; }

        /// <summary>
        /// Room have private bathroom
        /// </summary>
        [JsonProperty("privateBathroom")]
        public bool PrivateBathroom { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"Bedroom : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is Bedroom other &&
                ((this.Beds == null && other.Beds == null) || (this.Beds?.Equals(other.Beds) == true)) &&
                this.Type.Equals(other.Type) &&
                this.PrivateBathroom.Equals(other.PrivateBathroom);
        }
        

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.Beds = {(this.Beds == null ? "null" : this.Beds.ToString())}");
            toStringOutput.Add($"this.Type = {this.Type}");
            toStringOutput.Add($"this.PrivateBathroom = {this.PrivateBathroom}");
        }
    }
}