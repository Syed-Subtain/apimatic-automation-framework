// <copyright file="Authorization.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace SupplierAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using SupplierAPI.Standard;
    using SupplierAPI.Standard.Utilities;

    /// <summary>
    /// Authorization.
    /// </summary>
    public class Authorization
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="Authorization"/> class.
        /// </summary>
        public Authorization()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="Authorization"/> class.
        /// </summary>
        /// <param name="token">token.</param>
        /// <param name="message">message.</param>
        /// <param name="isError">is_error.</param>
        /// <param name="errorMessage">errorMessage.</param>
        /// <param name="organizationId">organizationId.</param>
        /// <param name="supplierId">supplierId.</param>
        /// <param name="partyId">partyId.</param>
        /// <param name="name">name.</param>
        /// <param name="currency">currency.</param>
        /// <param name="code">code.</param>
        public Authorization(
            string token,
            string message,
            bool isError,
            List<string> errorMessage,
            int organizationId,
            int supplierId,
            int partyId,
            string name,
            string currency,
            string code = null)
        {
            this.Token = token;
            this.Message = message;
            this.IsError = isError;
            this.ErrorMessage = errorMessage;
            this.Code = code;
            this.OrganizationId = organizationId;
            this.SupplierId = supplierId;
            this.PartyId = partyId;
            this.Name = name;
            this.Currency = currency;
        }

        /// <summary>
        /// Generated token for authorization. It must be used in every request to API as param jwt. Token is valid for 1h
        /// </summary>
        [JsonProperty("token")]
        public string Token { get; set; }

        /// <summary>
        /// Message
        /// </summary>
        [JsonProperty("message")]
        public string Message { get; set; }

        /// <summary>
        /// Is request success or not
        /// </summary>
        [JsonProperty("is_error")]
        public bool IsError { get; set; }

        /// <summary>
        /// Error Message(s) in Array format
        /// </summary>
        [JsonProperty("errorMessage")]
        public List<string> ErrorMessage { get; set; }

        /// <summary>
        /// Response code
        /// </summary>
        [JsonProperty("code", NullValueHandling = NullValueHandling.Ignore)]
        public string Code { get; set; }

        /// <summary>
        /// Organization id - PMS ID
        /// </summary>
        [JsonProperty("organizationId")]
        public int OrganizationId { get; set; }

        /// <summary>
        /// Supplier ID (Property Manager ID - or PMS ID - depend on account on which you are logged in)
        /// </summary>
        [JsonProperty("supplierId")]
        public int SupplierId { get; set; }

        /// <summary>
        /// Deprecated field. It will be removed in version 3.3. Please use supplierId field instead
        /// </summary>
        [JsonProperty("partyId")]
        public int PartyId { get; set; }

        /// <summary>
        /// Account name
        /// </summary>
        [JsonProperty("name")]
        public string Name { get; set; }

        /// <summary>
        /// Account currency
        /// </summary>
        [JsonProperty("currency")]
        public string Currency { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"Authorization : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is Authorization other &&
                ((this.Token == null && other.Token == null) || (this.Token?.Equals(other.Token) == true)) &&
                ((this.Message == null && other.Message == null) || (this.Message?.Equals(other.Message) == true)) &&
                this.IsError.Equals(other.IsError) &&
                ((this.ErrorMessage == null && other.ErrorMessage == null) || (this.ErrorMessage?.Equals(other.ErrorMessage) == true)) &&
                ((this.Code == null && other.Code == null) || (this.Code?.Equals(other.Code) == true)) &&
                this.OrganizationId.Equals(other.OrganizationId) &&
                this.SupplierId.Equals(other.SupplierId) &&
                this.PartyId.Equals(other.PartyId) &&
                ((this.Name == null && other.Name == null) || (this.Name?.Equals(other.Name) == true)) &&
                ((this.Currency == null && other.Currency == null) || (this.Currency?.Equals(other.Currency) == true));
        }
        

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.Token = {(this.Token == null ? "null" : this.Token == string.Empty ? "" : this.Token)}");
            toStringOutput.Add($"this.Message = {(this.Message == null ? "null" : this.Message == string.Empty ? "" : this.Message)}");
            toStringOutput.Add($"this.IsError = {this.IsError}");
            toStringOutput.Add($"this.ErrorMessage = {(this.ErrorMessage == null ? "null" : $"[{string.Join(", ", this.ErrorMessage)} ]")}");
            toStringOutput.Add($"this.Code = {(this.Code == null ? "null" : this.Code == string.Empty ? "" : this.Code)}");
            toStringOutput.Add($"this.OrganizationId = {this.OrganizationId}");
            toStringOutput.Add($"this.SupplierId = {this.SupplierId}");
            toStringOutput.Add($"this.PartyId = {this.PartyId}");
            toStringOutput.Add($"this.Name = {(this.Name == null ? "null" : this.Name == string.Empty ? "" : this.Name)}");
            toStringOutput.Add($"this.Currency = {(this.Currency == null ? "null" : this.Currency == string.Empty ? "" : this.Currency)}");
        }
    }
}