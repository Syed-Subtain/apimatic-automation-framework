// <copyright file="ChannelMarkUpYieldInfo.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace SupplierAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using SupplierAPI.Standard;
    using SupplierAPI.Standard.Utilities;

    /// <summary>
    /// ChannelMarkUpYieldInfo.
    /// </summary>
    public class ChannelMarkUpYieldInfo
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ChannelMarkUpYieldInfo"/> class.
        /// </summary>
        public ChannelMarkUpYieldInfo()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ChannelMarkUpYieldInfo"/> class.
        /// </summary>
        /// <param name="beginDate">beginDate.</param>
        /// <param name="endDate">endDate.</param>
        /// <param name="amount">amount.</param>
        /// <param name="modifier">modifier.</param>
        /// <param name="channelAbbreviation">channelAbbreviation.</param>
        public ChannelMarkUpYieldInfo(
            string beginDate,
            string endDate,
            double amount,
            string modifier,
            string channelAbbreviation)
        {
            this.BeginDate = beginDate;
            this.EndDate = endDate;
            this.Amount = amount;
            this.Modifier = modifier;
            this.ChannelAbbreviation = channelAbbreviation;
        }

        /// <summary>
        /// begin date
        /// </summary>
        [JsonProperty("beginDate")]
        public string BeginDate { get; set; }

        /// <summary>
        /// end date
        /// </summary>
        [JsonProperty("endDate")]
        public string EndDate { get; set; }

        /// <summary>
        /// the amount
        /// </summary>
        [JsonProperty("amount")]
        public double Amount { get; set; }

        /// <summary>
        /// modifier
        /// </summary>
        [JsonProperty("modifier")]
        public string Modifier { get; set; }

        /// <summary>
        /// channel abbreviation
        /// </summary>
        [JsonProperty("channelAbbreviation")]
        public string ChannelAbbreviation { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"ChannelMarkUpYieldInfo : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is ChannelMarkUpYieldInfo other &&
                ((this.BeginDate == null && other.BeginDate == null) || (this.BeginDate?.Equals(other.BeginDate) == true)) &&
                ((this.EndDate == null && other.EndDate == null) || (this.EndDate?.Equals(other.EndDate) == true)) &&
                this.Amount.Equals(other.Amount) &&
                ((this.Modifier == null && other.Modifier == null) || (this.Modifier?.Equals(other.Modifier) == true)) &&
                ((this.ChannelAbbreviation == null && other.ChannelAbbreviation == null) || (this.ChannelAbbreviation?.Equals(other.ChannelAbbreviation) == true));
        }
        

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.BeginDate = {(this.BeginDate == null ? "null" : this.BeginDate == string.Empty ? "" : this.BeginDate)}");
            toStringOutput.Add($"this.EndDate = {(this.EndDate == null ? "null" : this.EndDate == string.Empty ? "" : this.EndDate)}");
            toStringOutput.Add($"this.Amount = {this.Amount}");
            toStringOutput.Add($"this.Modifier = {(this.Modifier == null ? "null" : this.Modifier == string.Empty ? "" : this.Modifier)}");
            toStringOutput.Add($"this.ChannelAbbreviation = {(this.ChannelAbbreviation == null ? "null" : this.ChannelAbbreviation == string.Empty ? "" : this.ChannelAbbreviation)}");
        }
    }
}