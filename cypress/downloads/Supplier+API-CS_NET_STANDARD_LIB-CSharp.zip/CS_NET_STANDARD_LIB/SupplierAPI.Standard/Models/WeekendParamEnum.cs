// <copyright file="WeekendParamEnum.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace SupplierAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Runtime.Serialization;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using SupplierAPI.Standard;
    using SupplierAPI.Standard.Utilities;

    /// <summary>
    /// WeekendParamEnum.
    /// </summary>
    [JsonConverter(typeof(StringEnumConverter))]
    public enum WeekendParamEnum
    {
        /// <summary>
        /// DAYSOFWEEKENDSATSUN.
        /// </summary>
        [EnumMember(Value = "DAYS_OF_WEEKEND_SAT_SUN")]
        DAYSOFWEEKENDSATSUN,

        /// <summary>
        /// DAYSOFWEEKENDFRISAT.
        /// </summary>
        [EnumMember(Value = "DAYS_OF_WEEKEND_FRI_SAT")]
        DAYSOFWEEKENDFRISAT,

        /// <summary>
        /// DAYSOFWEEKENDFRISATSUN.
        /// </summary>
        [EnumMember(Value = "DAYS_OF_WEEKEND_FRI_SAT_SUN")]
        DAYSOFWEEKENDFRISATSUN,

        /// <summary>
        /// DAYSOFWEEKENDTHUFRISAT.
        /// </summary>
        [EnumMember(Value = "DAYS_OF_WEEKEND_THU_FRI_SAT")]
        DAYSOFWEEKENDTHUFRISAT,

        /// <summary>
        /// DAYSOFWEEKENDTHUFRISATSUN.
        /// </summary>
        [EnumMember(Value = "DAYS_OF_WEEKEND_THU_FRI_SAT_SUN")]
        DAYSOFWEEKENDTHUFRISATSUN
    }
}