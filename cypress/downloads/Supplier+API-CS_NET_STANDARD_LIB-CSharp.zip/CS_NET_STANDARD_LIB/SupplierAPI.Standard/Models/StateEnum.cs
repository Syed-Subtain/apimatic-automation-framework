// <copyright file="StateEnum.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace SupplierAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Runtime.Serialization;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using SupplierAPI.Standard;
    using SupplierAPI.Standard.Utilities;

    /// <summary>
    /// StateEnum.
    /// </summary>
    [JsonConverter(typeof(StringEnumConverter))]
    public enum StateEnum
    {
        /// <summary>
        /// NOTVISIBLE.
        /// </summary>
        [EnumMember(Value = "NOT_VISIBLE")]
        NOTVISIBLE,

        /// <summary>
        /// VISIBLE.
        /// </summary>
        [EnumMember(Value = "VISIBLE")]
        VISIBLE,

        /// <summary>
        /// COMINGSOON.
        /// </summary>
        [EnumMember(Value = "COMING_SOON")]
        COMINGSOON
    }
}