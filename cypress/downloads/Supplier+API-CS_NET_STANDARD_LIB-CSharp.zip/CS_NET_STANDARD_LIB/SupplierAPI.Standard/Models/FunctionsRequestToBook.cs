// <copyright file="FunctionsRequestToBook.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace SupplierAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using SupplierAPI.Standard;
    using SupplierAPI.Standard.Utilities;

    /// <summary>
    /// FunctionsRequestToBook.
    /// </summary>
    public class FunctionsRequestToBook
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="FunctionsRequestToBook"/> class.
        /// </summary>
        public FunctionsRequestToBook()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="FunctionsRequestToBook"/> class.
        /// </summary>
        /// <param name="requestToBookType">requestToBookType.</param>
        /// <param name="reservationId">reservationId.</param>
        /// <param name="requestToBookDeclineReasonType">requestToBookDeclineReasonType.</param>
        /// <param name="declineMessageToGuest">declineMessageToGuest.</param>
        public FunctionsRequestToBook(
            Models.RequestToBookTypeEnum requestToBookType,
            int reservationId,
            Models.RequestToBookDeclineReasonTypeEnum? requestToBookDeclineReasonType = null,
            string declineMessageToGuest = null)
        {
            this.RequestToBookType = requestToBookType;
            this.RequestToBookDeclineReasonType = requestToBookDeclineReasonType;
            this.DeclineMessageToGuest = declineMessageToGuest;
            this.ReservationId = reservationId;
        }

        /// <summary>
        /// Gets or sets RequestToBookType.
        /// </summary>
        [JsonProperty("requestToBookType", ItemConverterType = typeof(StringEnumConverter))]
        public Models.RequestToBookTypeEnum RequestToBookType { get; set; }

        /// <summary>
        /// Gets or sets RequestToBookDeclineReasonType.
        /// </summary>
        [JsonProperty("requestToBookDeclineReasonType", ItemConverterType = typeof(StringEnumConverter), NullValueHandling = NullValueHandling.Ignore)]
        public Models.RequestToBookDeclineReasonTypeEnum? RequestToBookDeclineReasonType { get; set; }

        /// <summary>
        /// Message to guest
        /// </summary>
        [JsonProperty("declineMessageToGuest", NullValueHandling = NullValueHandling.Ignore)]
        public string DeclineMessageToGuest { get; set; }

        /// <summary>
        /// Reservation for request to book
        /// </summary>
        [JsonProperty("reservationId")]
        public int ReservationId { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"FunctionsRequestToBook : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is FunctionsRequestToBook other &&
                this.RequestToBookType.Equals(other.RequestToBookType) &&
                ((this.RequestToBookDeclineReasonType == null && other.RequestToBookDeclineReasonType == null) || (this.RequestToBookDeclineReasonType?.Equals(other.RequestToBookDeclineReasonType) == true)) &&
                ((this.DeclineMessageToGuest == null && other.DeclineMessageToGuest == null) || (this.DeclineMessageToGuest?.Equals(other.DeclineMessageToGuest) == true)) &&
                this.ReservationId.Equals(other.ReservationId);
        }
        

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.RequestToBookType = {this.RequestToBookType}");
            toStringOutput.Add($"this.RequestToBookDeclineReasonType = {(this.RequestToBookDeclineReasonType == null ? "null" : this.RequestToBookDeclineReasonType.ToString())}");
            toStringOutput.Add($"this.DeclineMessageToGuest = {(this.DeclineMessageToGuest == null ? "null" : this.DeclineMessageToGuest == string.Empty ? "" : this.DeclineMessageToGuest)}");
            toStringOutput.Add($"this.ReservationId = {this.ReservationId}");
        }
    }
}