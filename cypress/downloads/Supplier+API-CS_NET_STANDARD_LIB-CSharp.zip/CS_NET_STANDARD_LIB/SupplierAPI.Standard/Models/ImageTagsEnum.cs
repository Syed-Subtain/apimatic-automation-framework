// <copyright file="ImageTagsEnum.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace SupplierAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using SupplierAPI.Standard;
    using SupplierAPI.Standard.Utilities;

    /// <summary>
    /// ImageTagsEnum.
    /// </summary>
    public enum ImageTagsEnum
    {
        /// <summary>
        ///Shower
        /// Enum1.
        /// </summary>
        Enum1 = 1,

        /// <summary>
        ///Toilet
        /// Enum2.
        /// </summary>
        Enum2 = 2,

        /// <summary>
        ///Property building
        /// Enum3.
        /// </summary>
        Enum3 = 3,

        /// <summary>
        ///patio
        /// Enum4.
        /// </summary>
        Enum4 = 4,

        /// <summary>
        ///Nearby landmark
        /// Enum5.
        /// </summary>
        Enum5 = 5,

        /// <summary>
        ///Staff
        /// Enum6.
        /// </summary>
        Enum6 = 6,

        /// <summary>
        ///Restaurant/places to eat
        /// Enum7.
        /// </summary>
        Enum7 = 7,

        /// <summary>
        ///Communal lounge/ TV room
        /// Enum8.
        /// </summary>
        Enum8 = 8,

        /// <summary>
        ///Facade/entrance
        /// Enum10.
        /// </summary>
        Enum10 = 10,

        /// <summary>
        ///People
        /// Enum43.
        /// </summary>
        Enum43 = 43,

        /// <summary>
        ///Spring
        /// Enum11.
        /// </summary>
        Enum11 = 11,

        /// <summary>
        ///Bed
        /// Enum13.
        /// </summary>
        Enum13 = 13,

        /// <summary>
        ///Off site
        /// Enum14.
        /// </summary>
        Enum14 = 14,

        /// <summary>
        ///Food close-up
        /// Enum37.
        /// </summary>
        Enum37 = 37,

        /// <summary>
        ///Day
        /// Enum41.
        /// </summary>
        Enum41 = 41,

        /// <summary>
        ///Night
        /// Enum42.
        /// </summary>
        Enum42 = 42,

        /// <summary>
        ///Property logo or sign
        /// Enum50.
        /// </summary>
        Enum50 = 50,

        /// <summary>
        ///Neighbourhood
        /// Enum55.
        /// </summary>
        Enum55 = 55,

        /// <summary>
        ///Natural landscape
        /// Enum61.
        /// </summary>
        Enum61 = 61,

        /// <summary>
        ///Activities
        /// Enum70.
        /// </summary>
        Enum70 = 70,

        /// <summary>
        ///Bird's eye view
        /// Enum74.
        /// </summary>
        Enum74 = 74,

        /// <summary>
        ///Winter
        /// Enum81.
        /// </summary>
        Enum81 = 81,

        /// <summary>
        ///Summer
        /// Enum82.
        /// </summary>
        Enum82 = 82,

        /// <summary>
        ///BBQ facilities
        /// Enum87.
        /// </summary>
        Enum87 = 87,

        /// <summary>
        ///Billiard
        /// Enum89.
        /// </summary>
        Enum89 = 89,

        /// <summary>
        ///Bowling
        /// Enum90.
        /// </summary>
        Enum90 = 90,

        /// <summary>
        ///Casino
        /// Enum94.
        /// </summary>
        Enum94 = 94,

        /// <summary>
        ///Place of worship
        /// Enum95.
        /// </summary>
        Enum95 = 95,

        /// <summary>
        ///Children play ground
        /// Enum96.
        /// </summary>
        Enum96 = 96,

        /// <summary>
        ///Darts
        /// Enum97.
        /// </summary>
        Enum97 = 97,

        /// <summary>
        ///Fishing
        /// Enum100.
        /// </summary>
        Enum100 = 100,

        /// <summary>
        ///Game Room
        /// Enum102.
        /// </summary>
        Enum102 = 102,

        /// <summary>
        ///Garden
        /// Enum103.
        /// </summary>
        Enum103 = 103,

        /// <summary>
        ///Golf course
        /// Enum104.
        /// </summary>
        Enum104 = 104,

        /// <summary>
        ///Horse-riding
        /// Enum106.
        /// </summary>
        Enum106 = 106,

        /// <summary>
        ///Hot Spring Bath
        /// Enum107.
        /// </summary>
        Enum107 = 107,

        /// <summary>
        ///Table tennis
        /// Enum141.
        /// </summary>
        Enum141 = 141,

        /// <summary>
        ///Hot Tub
        /// Enum108.
        /// </summary>
        Enum108 = 108,

        /// <summary>
        ///Karaoke
        /// Enum112.
        /// </summary>
        Enum112 = 112,

        /// <summary>
        ///Library
        /// Enum113.
        /// </summary>
        Enum113 = 113,

        /// <summary>
        ///Massage
        /// Enum114.
        /// </summary>
        Enum114 = 114,

        /// <summary>
        ///Minigolf
        /// Enum115.
        /// </summary>
        Enum115 = 115,

        /// <summary>
        ///Nightclub / DJ
        /// Enum116.
        /// </summary>
        Enum116 = 116,

        /// <summary>
        ///Sauna
        /// Enum124.
        /// </summary>
        Enum124 = 124,

        /// <summary>
        ///On-site shops
        /// Enum125.
        /// </summary>
        Enum125 = 125,

        /// <summary>
        ///Ski School
        /// Enum128.
        /// </summary>
        Enum128 = 128,

        /// <summary>
        ///Skiing
        /// Enum131.
        /// </summary>
        Enum131 = 131,

        /// <summary>
        ///Squash
        /// Enum137.
        /// </summary>
        Enum137 = 137,

        /// <summary>
        ///Snorkeling
        /// Enum133.
        /// </summary>
        Enum133 = 133,

        /// <summary>
        ///Solarium
        /// Enum134.
        /// </summary>
        Enum134 = 134,

        /// <summary>
        ///Steam room
        /// Enum143.
        /// </summary>
        Enum143 = 143,

        /// <summary>
        ///Bathroom
        /// Enum153.
        /// </summary>
        Enum153 = 153,

        /// <summary>
        ///TV and multimedia
        /// Enum154.
        /// </summary>
        Enum154 = 154,

        /// <summary>
        ///Coffee/tea facilities
        /// Enum155.
        /// </summary>
        Enum155 = 155,

        /// <summary>
        ///View (from property/room)
        /// Enum156.
        /// </summary>
        Enum156 = 156,

        /// <summary>
        ///Balcony/Terrace
        /// Enum157.
        /// </summary>
        Enum157 = 157,

        /// <summary>
        ///Kitchen or kitchenette
        /// Enum158.
        /// </summary>
        Enum158 = 158,

        /// <summary>
        ///Living room
        /// Enum159.
        /// </summary>
        Enum159 = 159,

        /// <summary>
        ///Lobby or reception
        /// Enum160.
        /// </summary>
        Enum160 = 160,

        /// <summary>
        ///Lounge or bar
        /// Enum161.
        /// </summary>
        Enum161 = 161,

        /// <summary>
        ///Spa and wellness centre/facili
        /// Enum164.
        /// </summary>
        Enum164 = 164,

        /// <summary>
        ///Fitness centre/facilities
        /// Enum165.
        /// </summary>
        Enum165 = 165,

        /// <summary>
        ///Food and drinks
        /// Enum167.
        /// </summary>
        Enum167 = 167,

        /// <summary>
        ///Other
        /// Enum172.
        /// </summary>
        Enum172 = 172,

        /// <summary>
        ///Photo of the whole room
        /// Enum173.
        /// </summary>
        Enum173 = 173,

        /// <summary>
        ///Business facilities
        /// Enum177.
        /// </summary>
        Enum177 = 177,

        /// <summary>
        ///Banquet/Function facilities
        /// Enum178.
        /// </summary>
        Enum178 = 178,

        /// <summary>
        ///Decorative detail
        /// Enum179.
        /// </summary>
        Enum179 = 179,

        /// <summary>
        ///Seating area
        /// Enum182.
        /// </summary>
        Enum182 = 182,

        /// <summary>
        ///Floor plan
        /// Enum183.
        /// </summary>
        Enum183 = 183,

        /// <summary>
        ///Dining area
        /// Enum184.
        /// </summary>
        Enum184 = 184,

        /// <summary>
        ///Beach
        /// Enum185.
        /// </summary>
        Enum185 = 185,

        /// <summary>
        ///Aqua park
        /// Enum186.
        /// </summary>
        Enum186 = 186,

        /// <summary>
        ///Tennis court
        /// Enum187.
        /// </summary>
        Enum187 = 187,

        /// <summary>
        ///Windsurfing
        /// Enum188.
        /// </summary>
        Enum188 = 188,

        /// <summary>
        ///Canoeing
        /// Enum189.
        /// </summary>
        Enum189 = 189,

        /// <summary>
        ///Hiking
        /// Enum190.
        /// </summary>
        Enum190 = 190,

        /// <summary>
        ///Cycling
        /// Enum191.
        /// </summary>
        Enum191 = 191,

        /// <summary>
        ///Diving
        /// Enum192.
        /// </summary>
        Enum192 = 192,

        /// <summary>
        ///Kids's club
        /// Enum193.
        /// </summary>
        Enum193 = 193,

        /// <summary>
        ///Evening entertainment
        /// Enum194.
        /// </summary>
        Enum194 = 194,

        /// <summary>
        ///Logo/Certificate/Sign
        /// Enum197.
        /// </summary>
        Enum197 = 197,

        /// <summary>
        ///Animals
        /// Enum198.
        /// </summary>
        Enum198 = 198,

        /// <summary>
        ///Bedroom
        /// Enum199.
        /// </summary>
        Enum199 = 199,

        /// <summary>
        ///Communal kitchen
        /// Enum204.
        /// </summary>
        Enum204 = 204,

        /// <summary>
        ///Autumn
        /// Enum205.
        /// </summary>
        Enum205 = 205,

        /// <summary>
        ///On site
        /// Enum240.
        /// </summary>
        Enum240 = 240,

        /// <summary>
        ///Meeting/conference room
        /// Enum241.
        /// </summary>
        Enum241 = 241,

        /// <summary>
        ///Food
        /// Enum242.
        /// </summary>
        Enum242 = 242,

        /// <summary>
        ///Text overlay
        /// Enum245.
        /// </summary>
        Enum245 = 245,

        /// <summary>
        ///Pets
        /// Enum246.
        /// </summary>
        Enum246 = 246,

        /// <summary>
        ///Guests
        /// Enum247.
        /// </summary>
        Enum247 = 247,

        /// <summary>
        ///City view
        /// Enum248.
        /// </summary>
        Enum248 = 248,

        /// <summary>
        ///Garden view
        /// Enum249.
        /// </summary>
        Enum249 = 249,

        /// <summary>
        ///Lake view
        /// Enum250.
        /// </summary>
        Enum250 = 250,

        /// <summary>
        ///Landmark view
        /// Enum251.
        /// </summary>
        Enum251 = 251,

        /// <summary>
        ///Mountain view
        /// Enum252.
        /// </summary>
        Enum252 = 252,

        /// <summary>
        ///Pool view
        /// Enum253.
        /// </summary>
        Enum253 = 253,

        /// <summary>
        ///River view
        /// Enum254.
        /// </summary>
        Enum254 = 254,

        /// <summary>
        ///Sea view
        /// Enum255.
        /// </summary>
        Enum255 = 255,

        /// <summary>
        ///Street view
        /// Enum256.
        /// </summary>
        Enum256 = 256,

        /// <summary>
        ///Area and facilities
        /// Enum257.
        /// </summary>
        Enum257 = 257,

        /// <summary>
        ///Supermarket/grocery shop
        /// Enum258.
        /// </summary>
        Enum258 = 258,

        /// <summary>
        ///Shopping Area
        /// Enum259.
        /// </summary>
        Enum259 = 259,

        /// <summary>
        ///Swimming pool
        /// Enum260.
        /// </summary>
        Enum260 = 260,

        /// <summary>
        ///Sports
        /// Enum261.
        /// </summary>
        Enum261 = 261,

        /// <summary>
        ///Entertainment
        /// Enum262.
        /// </summary>
        Enum262 = 262,

        /// <summary>
        ///Meals
        /// Enum263.
        /// </summary>
        Enum263 = 263,

        /// <summary>
        ///Breakfast
        /// Enum264.
        /// </summary>
        Enum264 = 264,

        /// <summary>
        ///Continental breakfast
        /// Enum265.
        /// </summary>
        Enum265 = 265,

        /// <summary>
        ///Buffet breakfast
        /// Enum266.
        /// </summary>
        Enum266 = 266,

        /// <summary>
        ///Asian breakfast
        /// Enum267.
        /// </summary>
        Enum267 = 267,

        /// <summary>
        ///Italian breakfast
        /// Enum268.
        /// </summary>
        Enum268 = 268,

        /// <summary>
        ///English/Irish breakfast
        /// Enum269.
        /// </summary>
        Enum269 = 269,

        /// <summary>
        ///American breakfast
        /// Enum270.
        /// </summary>
        Enum270 = 270,

        /// <summary>
        ///Lunch
        /// Enum271.
        /// </summary>
        Enum271 = 271,

        /// <summary>
        ///Dinner
        /// Enum272.
        /// </summary>
        Enum272 = 272,

        /// <summary>
        ///Drinks
        /// Enum273.
        /// </summary>
        Enum273 = 273,

        /// <summary>
        ///Alcoholic drinks
        /// Enum274.
        /// </summary>
        Enum274 = 274,

        /// <summary>
        ///Non alcoholic drinks
        /// Enum275.
        /// </summary>
        Enum275 = 275,

        /// <summary>
        ///Seasons
        /// Enum276.
        /// </summary>
        Enum276 = 276,

        /// <summary>
        ///Time of day
        /// Enum277.
        /// </summary>
        Enum277 = 277,

        /// <summary>
        ///Location
        /// Enum278.
        /// </summary>
        Enum278 = 278,

        /// <summary>
        ///Sunrise
        /// Enum279.
        /// </summary>
        Enum279 = 279,

        /// <summary>
        ///Sunset
        /// Enum280.
        /// </summary>
        Enum280 = 280,

        /// <summary>
        ///children
        /// Enum281.
        /// </summary>
        Enum281 = 281,

        /// <summary>
        ///young children
        /// Enum282.
        /// </summary>
        Enum282 = 282,

        /// <summary>
        ///older children
        /// Enum283.
        /// </summary>
        Enum283 = 283,

        /// <summary>
        ///group of guests
        /// Enum284.
        /// </summary>
        Enum284 = 284,

        /// <summary>
        ///cot
        /// Enum285.
        /// </summary>
        Enum285 = 285,

        /// <summary>
        ///bunk bed
        /// Enum286.
        /// </summary>
        Enum286 = 286,

        /// <summary>
        ///Certificate/Award
        /// Enum287.
        /// </summary>
        Enum287 = 287,

        /// <summary>
        ///ADAM
        /// Enum288.
        /// </summary>
        Enum288 = 288,

        /// <summary>
        ///Open Air Bath
        /// Enum289.
        /// </summary>
        Enum289 = 289,

        /// <summary>
        ///Public Bath
        /// Enum290.
        /// </summary>
        Enum290 = 290,

        /// <summary>
        ///Family
        /// Enum291.
        /// </summary>
        Enum291 = 291
    }
}