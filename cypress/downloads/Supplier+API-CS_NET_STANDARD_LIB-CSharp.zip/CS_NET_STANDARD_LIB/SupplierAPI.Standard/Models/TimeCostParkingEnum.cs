// <copyright file="TimeCostParkingEnum.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace SupplierAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Runtime.Serialization;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using SupplierAPI.Standard;
    using SupplierAPI.Standard.Utilities;

    /// <summary>
    /// TimeCostParkingEnum.
    /// </summary>
    [JsonConverter(typeof(StringEnumConverter))]
    public enum TimeCostParkingEnum
    {
        /// <summary>
        /// PerHour.
        /// </summary>
        [EnumMember(Value = "PerHour")]
        PerHour,

        /// <summary>
        /// PerWeek.
        /// </summary>
        [EnumMember(Value = "PerWeek")]
        PerWeek,

        /// <summary>
        /// PerStay.
        /// </summary>
        [EnumMember(Value = "PerStay")]
        PerStay,

        /// <summary>
        /// PerDay.
        /// </summary>
        [EnumMember(Value = "PerDay")]
        PerDay
    }
}