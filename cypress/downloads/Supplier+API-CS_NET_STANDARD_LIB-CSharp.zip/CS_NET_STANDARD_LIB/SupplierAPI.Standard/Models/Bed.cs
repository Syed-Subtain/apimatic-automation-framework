// <copyright file="Bed.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace SupplierAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using SupplierAPI.Standard;
    using SupplierAPI.Standard.Utilities;

    /// <summary>
    /// Bed.
    /// </summary>
    public class Bed
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="Bed"/> class.
        /// </summary>
        public Bed()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="Bed"/> class.
        /// </summary>
        /// <param name="bedType">bedType.</param>
        /// <param name="count">count.</param>
        public Bed(
            string bedType,
            int count)
        {
            this.BedType = bedType;
            this.Count = count;
        }

        /// <summary>
        /// Bed code BedTypes are given in Appendix.
        /// </summary>
        [JsonProperty("bedType")]
        public string BedType { get; set; }

        /// <summary>
        /// Number of bed
        /// </summary>
        [JsonProperty("count")]
        public int Count { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"Bed : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is Bed other &&
                ((this.BedType == null && other.BedType == null) || (this.BedType?.Equals(other.BedType) == true)) &&
                this.Count.Equals(other.Count);
        }
        

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.BedType = {(this.BedType == null ? "null" : this.BedType == string.Empty ? "" : this.BedType)}");
            toStringOutput.Add($"this.Count = {this.Count}");
        }
    }
}