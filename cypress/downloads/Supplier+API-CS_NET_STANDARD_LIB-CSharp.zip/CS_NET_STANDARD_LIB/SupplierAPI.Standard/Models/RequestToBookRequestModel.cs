// <copyright file="RequestToBookRequestModel.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace SupplierAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using SupplierAPI.Standard;
    using SupplierAPI.Standard.Utilities;

    /// <summary>
    /// RequestToBookRequestModel.
    /// </summary>
    public class RequestToBookRequestModel
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="RequestToBookRequestModel"/> class.
        /// </summary>
        public RequestToBookRequestModel()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="RequestToBookRequestModel"/> class.
        /// </summary>
        /// <param name="rezcasterNotificationRequest">rezcasterNotificationRequest.</param>
        /// <param name="action">action.</param>
        /// <param name="reservationId">reservationId.</param>
        /// <param name="expiresAt">expires_at.</param>
        /// <param name="messageToHost">messageToHost.</param>
        public RequestToBookRequestModel(
            Models.ReservationNotificationObject rezcasterNotificationRequest,
            string action,
            int reservationId,
            DateTime expiresAt,
            string messageToHost = null)
        {
            this.RezcasterNotificationRequest = rezcasterNotificationRequest;
            this.Action = action;
            this.ReservationId = reservationId;
            this.MessageToHost = messageToHost;
            this.ExpiresAt = expiresAt;
        }

        /// <summary>
        /// Gets or sets RezcasterNotificationRequest.
        /// </summary>
        [JsonProperty("rezcasterNotificationRequest")]
        public Models.ReservationNotificationObject RezcasterNotificationRequest { get; set; }

        /// <summary>
        /// RESERVATION_REQUEST
        /// </summary>
        [JsonProperty("action")]
        public string Action { get; set; }

        /// <summary>
        /// ID of reservation in BookingPal
        /// </summary>
        [JsonProperty("reservationId")]
        public int ReservationId { get; set; }

        /// <summary>
        /// Message from Guest to host
        /// </summary>
        [JsonProperty("messageToHost", NullValueHandling = NullValueHandling.Ignore)]
        public string MessageToHost { get; set; }

        /// <summary>
        /// expires time. Date is in format "yyyy-MM-dd"
        /// </summary>
        [JsonConverter(typeof(CustomDateTimeConverter), "yyyy'-'MM'-'dd")]
        [JsonProperty("expires_at")]
        public DateTime ExpiresAt { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"RequestToBookRequestModel : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is RequestToBookRequestModel other &&
                ((this.RezcasterNotificationRequest == null && other.RezcasterNotificationRequest == null) || (this.RezcasterNotificationRequest?.Equals(other.RezcasterNotificationRequest) == true)) &&
                ((this.Action == null && other.Action == null) || (this.Action?.Equals(other.Action) == true)) &&
                this.ReservationId.Equals(other.ReservationId) &&
                ((this.MessageToHost == null && other.MessageToHost == null) || (this.MessageToHost?.Equals(other.MessageToHost) == true)) &&
                this.ExpiresAt.Equals(other.ExpiresAt);
        }
        

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.RezcasterNotificationRequest = {(this.RezcasterNotificationRequest == null ? "null" : this.RezcasterNotificationRequest.ToString())}");
            toStringOutput.Add($"this.Action = {(this.Action == null ? "null" : this.Action == string.Empty ? "" : this.Action)}");
            toStringOutput.Add($"this.ReservationId = {this.ReservationId}");
            toStringOutput.Add($"this.MessageToHost = {(this.MessageToHost == null ? "null" : this.MessageToHost == string.Empty ? "" : this.MessageToHost)}");
            toStringOutput.Add($"this.ExpiresAt = {this.ExpiresAt}");
        }
    }
}