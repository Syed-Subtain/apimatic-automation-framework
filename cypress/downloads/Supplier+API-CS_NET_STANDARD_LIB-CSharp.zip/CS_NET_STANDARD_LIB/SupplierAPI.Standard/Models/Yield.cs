// <copyright file="Yield.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace SupplierAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using SupplierAPI.Standard;
    using SupplierAPI.Standard.Utilities;

    /// <summary>
    /// Yield.
    /// </summary>
    public class Yield
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="Yield"/> class.
        /// </summary>
        public Yield()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="Yield"/> class.
        /// </summary>
        /// <param name="beginDate">beginDate.</param>
        /// <param name="endDate">endDate.</param>
        /// <param name="amount">amount.</param>
        /// <param name="modifier">modifier.</param>
        /// <param name="weekendParam">weekendParam.</param>
        /// <param name="param">param.</param>
        public Yield(
            DateTime beginDate,
            DateTime endDate,
            double amount,
            Models.YieldModifierEnum modifier,
            Models.WeekendParamEnum? weekendParam = null,
            int? param = null)
        {
            this.BeginDate = beginDate;
            this.EndDate = endDate;
            this.Amount = amount;
            this.Modifier = modifier;
            this.WeekendParam = weekendParam;
            this.Param = param;
        }

        /// <summary>
        /// From date. Date should be in format "yyyy-MM-dd"
        /// </summary>
        [JsonConverter(typeof(CustomDateTimeConverter), "yyyy'-'MM'-'dd")]
        [JsonProperty("beginDate")]
        public DateTime BeginDate { get; set; }

        /// <summary>
        /// To date. Date should be in format "yyyy-MM-dd"
        /// </summary>
        [JsonConverter(typeof(CustomDateTimeConverter), "yyyy'-'MM'-'dd")]
        [JsonProperty("endDate")]
        public DateTime EndDate { get; set; }

        /// <summary>
        /// Yield amount
        /// </summary>
        [JsonProperty("amount")]
        public double Amount { get; set; }

        /// <summary>
        /// Gets or sets Modifier.
        /// </summary>
        [JsonProperty("modifier", ItemConverterType = typeof(StringEnumConverter))]
        public Models.YieldModifierEnum Modifier { get; set; }

        /// <summary>
        /// Gets or sets WeekendParam.
        /// </summary>
        [JsonProperty("weekendParam", ItemConverterType = typeof(StringEnumConverter), NullValueHandling = NullValueHandling.Ignore)]
        public Models.WeekendParamEnum? WeekendParam { get; set; }

        /// <summary>
        /// Parameter. It can verify depending on what YMR was set. More details about params you can see in the description above.
        /// </summary>
        [JsonProperty("param", NullValueHandling = NullValueHandling.Ignore)]
        public int? Param { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"Yield : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is Yield other &&
                this.BeginDate.Equals(other.BeginDate) &&
                this.EndDate.Equals(other.EndDate) &&
                this.Amount.Equals(other.Amount) &&
                this.Modifier.Equals(other.Modifier) &&
                ((this.WeekendParam == null && other.WeekendParam == null) || (this.WeekendParam?.Equals(other.WeekendParam) == true)) &&
                ((this.Param == null && other.Param == null) || (this.Param?.Equals(other.Param) == true));
        }
        

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.BeginDate = {this.BeginDate}");
            toStringOutput.Add($"this.EndDate = {this.EndDate}");
            toStringOutput.Add($"this.Amount = {this.Amount}");
            toStringOutput.Add($"this.Modifier = {this.Modifier}");
            toStringOutput.Add($"this.WeekendParam = {(this.WeekendParam == null ? "null" : this.WeekendParam.ToString())}");
            toStringOutput.Add($"this.Param = {(this.Param == null ? "null" : this.Param.ToString())}");
        }
    }
}