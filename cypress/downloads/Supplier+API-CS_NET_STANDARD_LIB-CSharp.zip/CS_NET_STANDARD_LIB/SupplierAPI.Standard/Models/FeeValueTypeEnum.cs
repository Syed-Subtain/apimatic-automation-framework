// <copyright file="FeeValueTypeEnum.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace SupplierAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Runtime.Serialization;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using SupplierAPI.Standard;
    using SupplierAPI.Standard.Utilities;

    /// <summary>
    /// FeeValueTypeEnum.
    /// </summary>
    [JsonConverter(typeof(StringEnumConverter))]
    public enum FeeValueTypeEnum
    {
        /// <summary>
        ///Value of fee will be added in Quote
        /// FLAT.
        /// </summary>
        [EnumMember(Value = "FLAT")]
        FLAT,

        /// <summary>
        ///Fee will be charged like percent value of rent
        /// PERCENT.
        /// </summary>
        [EnumMember(Value = "PERCENT")]
        PERCENT
    }
}