// <copyright file="CompanyDetails.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace SupplierAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using SupplierAPI.Standard;
    using SupplierAPI.Standard.Utilities;

    /// <summary>
    /// CompanyDetails.
    /// </summary>
    public class CompanyDetails
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="CompanyDetails"/> class.
        /// </summary>
        public CompanyDetails()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="CompanyDetails"/> class.
        /// </summary>
        /// <param name="accountId">accountId.</param>
        /// <param name="companyName">companyName.</param>
        /// <param name="language">language.</param>
        /// <param name="fullName">fullName.</param>
        /// <param name="companyAddress">companyAddress.</param>
        /// <param name="website">website.</param>
        /// <param name="email">email.</param>
        /// <param name="phone">phone.</param>
        /// <param name="currency">currency.</param>
        /// <param name="password">password.</param>
        public CompanyDetails(
            string accountId,
            string companyName,
            string language,
            string fullName,
            Models.CompanyAddress companyAddress,
            string website,
            string email,
            Models.Phone phone,
            string currency,
            string password = null)
        {
            this.AccountId = accountId;
            this.CompanyName = companyName;
            this.Language = language;
            this.FullName = fullName;
            this.CompanyAddress = companyAddress;
            this.Website = website;
            this.Email = email;
            this.Phone = phone;
            this.Password = password;
            this.Currency = currency;
        }

        /// <summary>
        /// Unique ID of PM in PMS
        /// </summary>
        [JsonProperty("accountId")]
        public string AccountId { get; set; }

        /// <summary>
        /// Name of PM
        /// </summary>
        [JsonProperty("companyName")]
        public string CompanyName { get; set; }

        /// <summary>
        /// Language 2 letter value  as ISO 639-1 code
        /// </summary>
        [JsonProperty("language")]
        public string Language { get; set; }

        /// <summary>
        /// First and Last Name
        /// </summary>
        [JsonProperty("fullName")]
        public string FullName { get; set; }

        /// <summary>
        /// Gets or sets CompanyAddress.
        /// </summary>
        [JsonProperty("companyAddress")]
        public Models.CompanyAddress CompanyAddress { get; set; }

        /// <summary>
        /// Company (PM) website URL
        /// </summary>
        [JsonProperty("website")]
        public string Website { get; set; }

        /// <summary>
        /// Email of PM. Email need to be unique in BP system, so you might receive error if we already have this email in our system
        /// </summary>
        [JsonProperty("email")]
        public string Email { get; set; }

        /// <summary>
        /// Gets or sets Phone.
        /// </summary>
        [JsonProperty("phone")]
        public Models.Phone Phone { get; set; }

        /// <summary>
        /// Password for accessing PM. If the password is not passed in the request random password will be generated and returned in response. Password will be in response only on create and if it is manually generated. Special characters are not allowed, instead use UTF-8 codes, for example instead of # use %23
        /// </summary>
        [JsonProperty("password", NullValueHandling = NullValueHandling.Ignore)]
        public string Password { get; set; }

        /// <summary>
        /// PM default currency. ISO 4217 code is required
        /// </summary>
        [JsonProperty("currency")]
        public string Currency { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"CompanyDetails : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is CompanyDetails other &&
                ((this.AccountId == null && other.AccountId == null) || (this.AccountId?.Equals(other.AccountId) == true)) &&
                ((this.CompanyName == null && other.CompanyName == null) || (this.CompanyName?.Equals(other.CompanyName) == true)) &&
                ((this.Language == null && other.Language == null) || (this.Language?.Equals(other.Language) == true)) &&
                ((this.FullName == null && other.FullName == null) || (this.FullName?.Equals(other.FullName) == true)) &&
                ((this.CompanyAddress == null && other.CompanyAddress == null) || (this.CompanyAddress?.Equals(other.CompanyAddress) == true)) &&
                ((this.Website == null && other.Website == null) || (this.Website?.Equals(other.Website) == true)) &&
                ((this.Email == null && other.Email == null) || (this.Email?.Equals(other.Email) == true)) &&
                ((this.Phone == null && other.Phone == null) || (this.Phone?.Equals(other.Phone) == true)) &&
                ((this.Password == null && other.Password == null) || (this.Password?.Equals(other.Password) == true)) &&
                ((this.Currency == null && other.Currency == null) || (this.Currency?.Equals(other.Currency) == true));
        }
        

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.AccountId = {(this.AccountId == null ? "null" : this.AccountId == string.Empty ? "" : this.AccountId)}");
            toStringOutput.Add($"this.CompanyName = {(this.CompanyName == null ? "null" : this.CompanyName == string.Empty ? "" : this.CompanyName)}");
            toStringOutput.Add($"this.Language = {(this.Language == null ? "null" : this.Language == string.Empty ? "" : this.Language)}");
            toStringOutput.Add($"this.FullName = {(this.FullName == null ? "null" : this.FullName == string.Empty ? "" : this.FullName)}");
            toStringOutput.Add($"this.CompanyAddress = {(this.CompanyAddress == null ? "null" : this.CompanyAddress.ToString())}");
            toStringOutput.Add($"this.Website = {(this.Website == null ? "null" : this.Website == string.Empty ? "" : this.Website)}");
            toStringOutput.Add($"this.Email = {(this.Email == null ? "null" : this.Email == string.Empty ? "" : this.Email)}");
            toStringOutput.Add($"this.Phone = {(this.Phone == null ? "null" : this.Phone.ToString())}");
            toStringOutput.Add($"this.Password = {(this.Password == null ? "null" : this.Password == string.Empty ? "" : this.Password)}");
            toStringOutput.Add($"this.Currency = {(this.Currency == null ? "null" : this.Currency == string.Empty ? "" : this.Currency)}");
        }
    }
}