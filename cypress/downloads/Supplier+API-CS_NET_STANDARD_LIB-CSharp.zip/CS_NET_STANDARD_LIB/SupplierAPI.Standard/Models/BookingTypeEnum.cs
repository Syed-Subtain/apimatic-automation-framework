// <copyright file="BookingTypeEnum.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace SupplierAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Runtime.Serialization;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using SupplierAPI.Standard;
    using SupplierAPI.Standard.Utilities;

    /// <summary>
    /// BookingTypeEnum.
    /// </summary>
    [JsonConverter(typeof(StringEnumConverter))]
    public enum BookingTypeEnum
    {
        /// <summary>
        /// Instant.
        /// </summary>
        [EnumMember(Value = "Instant")]
        Instant,

        /// <summary>
        /// RequestToBook.
        /// </summary>
        [EnumMember(Value = "RequestToBook")]
        RequestToBook,

        /// <summary>
        /// Both.
        /// </summary>
        [EnumMember(Value = "Both")]
        Both
    }
}