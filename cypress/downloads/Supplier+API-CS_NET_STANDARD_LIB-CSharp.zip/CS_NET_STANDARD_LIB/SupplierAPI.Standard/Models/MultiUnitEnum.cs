// <copyright file="MultiUnitEnum.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace SupplierAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Runtime.Serialization;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using SupplierAPI.Standard;
    using SupplierAPI.Standard.Utilities;

    /// <summary>
    /// MultiUnitEnum.
    /// </summary>
    [JsonConverter(typeof(StringEnumConverter))]
    public enum MultiUnitEnum
    {
        /// <summary>
        ///Enum type for MultiUnit property type
        /// MLT.
        /// </summary>
        [EnumMember(Value = "MLT")]
        MLT,

        /// <summary>
        ///Enum type for Owner (hotel) property type
        /// OWN.
        /// </summary>
        [EnumMember(Value = "OWN")]
        OWN
    }
}