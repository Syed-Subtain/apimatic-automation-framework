// <copyright file="CancelReservationNotificationObject.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace SupplierAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using SupplierAPI.Standard;
    using SupplierAPI.Standard.Utilities;

    /// <summary>
    /// CancelReservationNotificationObject.
    /// </summary>
    public class CancelReservationNotificationObject
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="CancelReservationNotificationObject"/> class.
        /// </summary>
        public CancelReservationNotificationObject()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="CancelReservationNotificationObject"/> class.
        /// </summary>
        /// <param name="reservationId">reservationId.</param>
        /// <param name="productId">productId.</param>
        /// <param name="supplierId">supplierId.</param>
        /// <param name="channelName">channelName.</param>
        /// <param name="confirmationId">confirmationId.</param>
        /// <param name="uniqueKey">uniqueKey.</param>
        /// <param name="newState">newState.</param>
        /// <param name="customerName">customerName.</param>
        /// <param name="fromDate">fromDate.</param>
        /// <param name="toDate">toDate.</param>
        /// <param name="adult">adult.</param>
        /// <param name="child">child.</param>
        /// <param name="email">email.</param>
        /// <param name="total">total.</param>
        /// <param name="agentName">agentName.</param>
        /// <param name="phone">phone.</param>
        /// <param name="notes">notes.</param>
        /// <param name="creditCardType">creditCardType.</param>
        public CancelReservationNotificationObject(
            string reservationId,
            string productId,
            int supplierId,
            string channelName,
            string confirmationId,
            string uniqueKey,
            string newState,
            string customerName,
            DateTime fromDate,
            DateTime toDate,
            int adult,
            int child,
            string email,
            double total,
            string agentName = null,
            string phone = null,
            string notes = null,
            string creditCardType = null)
        {
            this.ReservationId = reservationId;
            this.ProductId = productId;
            this.SupplierId = supplierId;
            this.AgentName = agentName;
            this.ChannelName = channelName;
            this.ConfirmationId = confirmationId;
            this.UniqueKey = uniqueKey;
            this.NewState = newState;
            this.CustomerName = customerName;
            this.FromDate = fromDate;
            this.ToDate = toDate;
            this.Adult = adult;
            this.Child = child;
            this.Email = email;
            this.Phone = phone;
            this.Notes = notes;
            this.CreditCardType = creditCardType;
            this.Total = total;
        }

        /// <summary>
        /// Id of the reservation in BookingPal
        /// </summary>
        [JsonProperty("reservationId")]
        public string ReservationId { get; set; }

        /// <summary>
        /// Id of the product in BookingPal
        /// </summary>
        [JsonProperty("productId")]
        public string ProductId { get; set; }

        /// <summary>
        /// Id of the property manager
        /// </summary>
        [JsonProperty("supplierId")]
        public int SupplierId { get; set; }

        /// <summary>
        /// DEPRECATED. Use channelName instead. Agent name/Channel name
        /// </summary>
        [JsonProperty("agentName", NullValueHandling = NullValueHandling.Ignore)]
        public string AgentName { get; set; }

        /// <summary>
        /// Agent name/Channel name
        /// </summary>
        [JsonProperty("channelName")]
        public string ChannelName { get; set; }

        /// <summary>
        /// Channel confirmation code
        /// </summary>
        [JsonProperty("confirmationId")]
        public string ConfirmationId { get; set; }

        /// <summary>
        /// Unique code to identify that the request is from BookingPal. This value is unique for every PMS (and it will be different in different environments).
        /// </summary>
        [JsonProperty("uniqueKey")]
        public string UniqueKey { get; set; }

        /// <summary>
        /// It will always be "Cancelled" in this request
        /// </summary>
        [JsonProperty("newState")]
        public string NewState { get; set; }

        /// <summary>
        /// Guest full name (in format firstName lastName)
        /// </summary>
        [JsonProperty("customerName")]
        public string CustomerName { get; set; }

        /// <summary>
        /// Reservation date from. Date is in format "yyyy-MM-dd"
        /// </summary>
        [JsonConverter(typeof(CustomDateTimeConverter), "yyyy'-'MM'-'dd")]
        [JsonProperty("fromDate")]
        public DateTime FromDate { get; set; }

        /// <summary>
        /// Reservation date to. Date is in format "yyyy-MM-dd"
        /// </summary>
        [JsonConverter(typeof(CustomDateTimeConverter), "yyyy'-'MM'-'dd")]
        [JsonProperty("toDate")]
        public DateTime ToDate { get; set; }

        /// <summary>
        /// Number of adults
        /// </summary>
        [JsonProperty("adult")]
        public int Adult { get; set; }

        /// <summary>
        /// Number of children
        /// </summary>
        [JsonProperty("child")]
        public int Child { get; set; }

        /// <summary>
        /// Guest email
        /// </summary>
        [JsonProperty("email")]
        public string Email { get; set; }

        /// <summary>
        /// Guest phone
        /// </summary>
        [JsonProperty("phone", NullValueHandling = NullValueHandling.Ignore)]
        public string Phone { get; set; }

        /// <summary>
        /// Guest notes
        /// </summary>
        [JsonProperty("notes", NullValueHandling = NullValueHandling.Ignore)]
        public string Notes { get; set; }

        /// <summary>
        /// Credit card type
        /// </summary>
        [JsonProperty("creditCardType", NullValueHandling = NullValueHandling.Ignore)]
        public string CreditCardType { get; set; }

        /// <summary>
        /// Best available rate (This is the total value that guests will pay, including rate, fees, taxes, and all commissions. )
        /// </summary>
        [JsonProperty("total")]
        public double Total { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"CancelReservationNotificationObject : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is CancelReservationNotificationObject other &&
                ((this.ReservationId == null && other.ReservationId == null) || (this.ReservationId?.Equals(other.ReservationId) == true)) &&
                ((this.ProductId == null && other.ProductId == null) || (this.ProductId?.Equals(other.ProductId) == true)) &&
                this.SupplierId.Equals(other.SupplierId) &&
                ((this.AgentName == null && other.AgentName == null) || (this.AgentName?.Equals(other.AgentName) == true)) &&
                ((this.ChannelName == null && other.ChannelName == null) || (this.ChannelName?.Equals(other.ChannelName) == true)) &&
                ((this.ConfirmationId == null && other.ConfirmationId == null) || (this.ConfirmationId?.Equals(other.ConfirmationId) == true)) &&
                ((this.UniqueKey == null && other.UniqueKey == null) || (this.UniqueKey?.Equals(other.UniqueKey) == true)) &&
                ((this.NewState == null && other.NewState == null) || (this.NewState?.Equals(other.NewState) == true)) &&
                ((this.CustomerName == null && other.CustomerName == null) || (this.CustomerName?.Equals(other.CustomerName) == true)) &&
                this.FromDate.Equals(other.FromDate) &&
                this.ToDate.Equals(other.ToDate) &&
                this.Adult.Equals(other.Adult) &&
                this.Child.Equals(other.Child) &&
                ((this.Email == null && other.Email == null) || (this.Email?.Equals(other.Email) == true)) &&
                ((this.Phone == null && other.Phone == null) || (this.Phone?.Equals(other.Phone) == true)) &&
                ((this.Notes == null && other.Notes == null) || (this.Notes?.Equals(other.Notes) == true)) &&
                ((this.CreditCardType == null && other.CreditCardType == null) || (this.CreditCardType?.Equals(other.CreditCardType) == true)) &&
                this.Total.Equals(other.Total);
        }
        

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.ReservationId = {(this.ReservationId == null ? "null" : this.ReservationId == string.Empty ? "" : this.ReservationId)}");
            toStringOutput.Add($"this.ProductId = {(this.ProductId == null ? "null" : this.ProductId == string.Empty ? "" : this.ProductId)}");
            toStringOutput.Add($"this.SupplierId = {this.SupplierId}");
            toStringOutput.Add($"this.AgentName = {(this.AgentName == null ? "null" : this.AgentName == string.Empty ? "" : this.AgentName)}");
            toStringOutput.Add($"this.ChannelName = {(this.ChannelName == null ? "null" : this.ChannelName == string.Empty ? "" : this.ChannelName)}");
            toStringOutput.Add($"this.ConfirmationId = {(this.ConfirmationId == null ? "null" : this.ConfirmationId == string.Empty ? "" : this.ConfirmationId)}");
            toStringOutput.Add($"this.UniqueKey = {(this.UniqueKey == null ? "null" : this.UniqueKey == string.Empty ? "" : this.UniqueKey)}");
            toStringOutput.Add($"this.NewState = {(this.NewState == null ? "null" : this.NewState == string.Empty ? "" : this.NewState)}");
            toStringOutput.Add($"this.CustomerName = {(this.CustomerName == null ? "null" : this.CustomerName == string.Empty ? "" : this.CustomerName)}");
            toStringOutput.Add($"this.FromDate = {this.FromDate}");
            toStringOutput.Add($"this.ToDate = {this.ToDate}");
            toStringOutput.Add($"this.Adult = {this.Adult}");
            toStringOutput.Add($"this.Child = {this.Child}");
            toStringOutput.Add($"this.Email = {(this.Email == null ? "null" : this.Email == string.Empty ? "" : this.Email)}");
            toStringOutput.Add($"this.Phone = {(this.Phone == null ? "null" : this.Phone == string.Empty ? "" : this.Phone)}");
            toStringOutput.Add($"this.Notes = {(this.Notes == null ? "null" : this.Notes == string.Empty ? "" : this.Notes)}");
            toStringOutput.Add($"this.CreditCardType = {(this.CreditCardType == null ? "null" : this.CreditCardType == string.Empty ? "" : this.CreditCardType)}");
            toStringOutput.Add($"this.Total = {this.Total}");
        }
    }
}