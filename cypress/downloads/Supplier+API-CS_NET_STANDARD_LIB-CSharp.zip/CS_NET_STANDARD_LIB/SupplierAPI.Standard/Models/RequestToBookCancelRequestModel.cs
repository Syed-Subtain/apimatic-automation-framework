// <copyright file="RequestToBookCancelRequestModel.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace SupplierAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using SupplierAPI.Standard;
    using SupplierAPI.Standard.Utilities;

    /// <summary>
    /// RequestToBookCancelRequestModel.
    /// </summary>
    public class RequestToBookCancelRequestModel
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="RequestToBookCancelRequestModel"/> class.
        /// </summary>
        public RequestToBookCancelRequestModel()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="RequestToBookCancelRequestModel"/> class.
        /// </summary>
        /// <param name="action">action.</param>
        /// <param name="reservationId">reservationId.</param>
        public RequestToBookCancelRequestModel(
            string action,
            int reservationId)
        {
            this.Action = action;
            this.ReservationId = reservationId;
        }

        /// <summary>
        /// RESERVATION_REQUEST_VOIDED
        /// </summary>
        [JsonProperty("action")]
        public string Action { get; set; }

        /// <summary>
        /// ID of reservation in BookingPal
        /// </summary>
        [JsonProperty("reservationId")]
        public int ReservationId { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"RequestToBookCancelRequestModel : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is RequestToBookCancelRequestModel other &&
                ((this.Action == null && other.Action == null) || (this.Action?.Equals(other.Action) == true)) &&
                this.ReservationId.Equals(other.ReservationId);
        }
        

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.Action = {(this.Action == null ? "null" : this.Action == string.Empty ? "" : this.Action)}");
            toStringOutput.Add($"this.ReservationId = {this.ReservationId}");
        }
    }
}