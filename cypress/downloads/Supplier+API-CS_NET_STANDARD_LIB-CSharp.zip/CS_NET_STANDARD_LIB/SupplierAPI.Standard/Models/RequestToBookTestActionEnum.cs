// <copyright file="RequestToBookTestActionEnum.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace SupplierAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Runtime.Serialization;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using SupplierAPI.Standard;
    using SupplierAPI.Standard.Utilities;

    /// <summary>
    /// RequestToBookTestActionEnum.
    /// </summary>
    [JsonConverter(typeof(StringEnumConverter))]
    public enum RequestToBookTestActionEnum
    {
        /// <summary>
        ///Send example request like you got request to book cancellation notification.
        /// RESERVATIONREQUESTVOIDED.
        /// </summary>
        [EnumMember(Value = "RESERVATION_REQUEST_VOIDED")]
        RESERVATIONREQUESTVOIDED,

        /// <summary>
        ///Send example request like you got request to book notification.
        /// RESERVATIONREQUEST.
        /// </summary>
        [EnumMember(Value = "RESERVATION_REQUEST")]
        RESERVATIONREQUEST
    }
}