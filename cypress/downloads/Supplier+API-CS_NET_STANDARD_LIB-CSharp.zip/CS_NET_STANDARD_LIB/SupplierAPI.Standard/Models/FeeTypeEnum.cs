// <copyright file="FeeTypeEnum.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace SupplierAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Runtime.Serialization;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using SupplierAPI.Standard;
    using SupplierAPI.Standard.Utilities;

    /// <summary>
    /// FeeTypeEnum.
    /// </summary>
    [JsonConverter(typeof(StringEnumConverter))]
    public enum FeeTypeEnum
    {
        /// <summary>
        /// GENERAL.
        /// </summary>
        [EnumMember(Value = "GENERAL")]
        GENERAL,

        /// <summary>
        /// PETFEE.
        /// </summary>
        [EnumMember(Value = "PET_FEE")]
        PETFEE,

        /// <summary>
        /// DEPOSIT.
        /// </summary>
        [EnumMember(Value = "DEPOSIT")]
        DEPOSIT
    }
}