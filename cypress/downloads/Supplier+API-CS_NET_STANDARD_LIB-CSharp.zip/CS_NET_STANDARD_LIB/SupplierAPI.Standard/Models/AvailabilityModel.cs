// <copyright file="AvailabilityModel.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace SupplierAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using SupplierAPI.Standard;
    using SupplierAPI.Standard.Utilities;

    /// <summary>
    /// AvailabilityModel.
    /// </summary>
    public class AvailabilityModel
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="AvailabilityModel"/> class.
        /// </summary>
        public AvailabilityModel()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="AvailabilityModel"/> class.
        /// </summary>
        /// <param name="beginDate">beginDate.</param>
        /// <param name="endDate">endDate.</param>
        /// <param name="availability">availability.</param>
        public AvailabilityModel(
            DateTime beginDate,
            DateTime endDate,
            bool availability)
        {
            this.BeginDate = beginDate;
            this.EndDate = endDate;
            this.Availability = availability;
        }

        /// <summary>
        /// Beginning date of date range for which availability is applied. Date should be in format "yyyy-MM-dd"
        /// </summary>
        [JsonConverter(typeof(CustomDateTimeConverter), "yyyy'-'MM'-'dd")]
        [JsonProperty("beginDate")]
        public DateTime BeginDate { get; set; }

        /// <summary>
        /// End date of date range for which availability is applied. Additional clarification: If you have reservation from 2020/08/05 - 2020/08/09, so checkout is on 2020/08/09 - you should send end date 2020/08/08, since 2020/08/09 is actually open for new reservation. Date should be in format "yyyy-MM-dd"
        /// </summary>
        [JsonConverter(typeof(CustomDateTimeConverter), "yyyy'-'MM'-'dd")]
        [JsonProperty("endDate")]
        public DateTime EndDate { get; set; }

        /// <summary>
        /// Determines if the dates are available or not. Our system saves only not available dates, so it is enough that you sent only not available dates. But if you want to open dates that you previously sent that are not available, you need to send that these dates are available over API.
        /// </summary>
        [JsonProperty("availability")]
        public bool Availability { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"AvailabilityModel : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is AvailabilityModel other &&
                this.BeginDate.Equals(other.BeginDate) &&
                this.EndDate.Equals(other.EndDate) &&
                this.Availability.Equals(other.Availability);
        }
        

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.BeginDate = {this.BeginDate}");
            toStringOutput.Add($"this.EndDate = {this.EndDate}");
            toStringOutput.Add($"this.Availability = {this.Availability}");
        }
    }
}