// <copyright file="CheckOut.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace SupplierAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using SupplierAPI.Standard;
    using SupplierAPI.Standard.Utilities;

    /// <summary>
    /// CheckOut.
    /// </summary>
    public class CheckOut
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="CheckOut"/> class.
        /// </summary>
        public CheckOut()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="CheckOut"/> class.
        /// </summary>
        /// <param name="monday">monday.</param>
        /// <param name="tuesday">tuesday.</param>
        /// <param name="wednesday">wednesday.</param>
        /// <param name="thursday">thursday.</param>
        /// <param name="friday">friday.</param>
        /// <param name="saturday">saturday.</param>
        /// <param name="sunday">sunday.</param>
        public CheckOut(
            bool monday,
            bool tuesday,
            bool wednesday,
            bool thursday,
            bool friday,
            bool saturday,
            bool sunday)
        {
            this.Monday = monday;
            this.Tuesday = tuesday;
            this.Wednesday = wednesday;
            this.Thursday = thursday;
            this.Friday = friday;
            this.Saturday = saturday;
            this.Sunday = sunday;
        }

        /// <summary>
        /// Determines if check out could be made on monday
        /// </summary>
        [JsonProperty("monday")]
        public bool Monday { get; set; }

        /// <summary>
        /// Determines if check out could be made on tuesday
        /// </summary>
        [JsonProperty("tuesday")]
        public bool Tuesday { get; set; }

        /// <summary>
        /// Determines if check out could be made on wednesday
        /// </summary>
        [JsonProperty("wednesday")]
        public bool Wednesday { get; set; }

        /// <summary>
        /// Determines if check out could be made on thursday
        /// </summary>
        [JsonProperty("thursday")]
        public bool Thursday { get; set; }

        /// <summary>
        /// Determines if check out could be made on friday
        /// </summary>
        [JsonProperty("friday")]
        public bool Friday { get; set; }

        /// <summary>
        /// Determines if check out could be made on saturday
        /// </summary>
        [JsonProperty("saturday")]
        public bool Saturday { get; set; }

        /// <summary>
        /// Determines if check out could be made on sunday
        /// </summary>
        [JsonProperty("sunday")]
        public bool Sunday { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"CheckOut : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is CheckOut other &&
                this.Monday.Equals(other.Monday) &&
                this.Tuesday.Equals(other.Tuesday) &&
                this.Wednesday.Equals(other.Wednesday) &&
                this.Thursday.Equals(other.Thursday) &&
                this.Friday.Equals(other.Friday) &&
                this.Saturday.Equals(other.Saturday) &&
                this.Sunday.Equals(other.Sunday);
        }
        

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.Monday = {this.Monday}");
            toStringOutput.Add($"this.Tuesday = {this.Tuesday}");
            toStringOutput.Add($"this.Wednesday = {this.Wednesday}");
            toStringOutput.Add($"this.Thursday = {this.Thursday}");
            toStringOutput.Add($"this.Friday = {this.Friday}");
            toStringOutput.Add($"this.Saturday = {this.Saturday}");
            toStringOutput.Add($"this.Sunday = {this.Sunday}");
        }
    }
}