// <copyright file="MessagingController.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace SupplierAPI.Standard.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Dynamic;
    using System.Globalization;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading;
    using System.Threading.Tasks;
    using Newtonsoft.Json.Converters;
    using SupplierAPI.Standard;
    using SupplierAPI.Standard.Authentication;
    using SupplierAPI.Standard.Http.Client;
    using SupplierAPI.Standard.Http.Request;
    using SupplierAPI.Standard.Http.Request.Configuration;
    using SupplierAPI.Standard.Http.Response;
    using SupplierAPI.Standard.Utilities;

    /// <summary>
    /// MessagingController.
    /// </summary>
    public class MessagingController : BaseController
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="MessagingController"/> class.
        /// </summary>
        /// <param name="config"> config instance. </param>
        /// <param name="httpClient"> httpClient. </param>
        /// <param name="authManagers"> authManager. </param>
        /// <param name="httpCallBack"> httpCallBack. </param>
        internal MessagingController(IConfiguration config, IHttpClient httpClient, IDictionary<string, IAuthManager> authManagers, HttpCallBack httpCallBack = null)
            : base(config, httpClient, authManagers, httpCallBack)
        {
        }

        /// <summary>
        /// This function allows the logged in user to get all message threads or message threads with unresponded message from guest for whole PM. You need to use PM credentials. There is also paging as optional values. If you do not pass this value, we will return first page and 10 threads per page. And in heading you will get a link for the next page.
        /// </summary>
        /// <param name="page">Required parameter: Number of current page.</param>
        /// <param name="limit">Required parameter: Limit of how many threads will be showed at one page.</param>
        /// <param name="threadType">Required parameter: Request all threads or only threads with  unanswered message {new,all}.</param>
        /// <returns>Returns the Models.GetMessageThreadsResponse response from the API call.</returns>
        public Models.GetMessageThreadsResponse GetMessageThreads(
                int page,
                int limit,
                string threadType)
        {
            Task<Models.GetMessageThreadsResponse> t = this.GetMessageThreadsAsync(page, limit, threadType);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// This function allows the logged in user to get all message threads or message threads with unresponded message from guest for whole PM. You need to use PM credentials. There is also paging as optional values. If you do not pass this value, we will return first page and 10 threads per page. And in heading you will get a link for the next page.
        /// </summary>
        /// <param name="page">Required parameter: Number of current page.</param>
        /// <param name="limit">Required parameter: Limit of how many threads will be showed at one page.</param>
        /// <param name="threadType">Required parameter: Request all threads or only threads with  unanswered message {new,all}.</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.GetMessageThreadsResponse response from the API call.</returns>
        public async Task<Models.GetMessageThreadsResponse> GetMessageThreadsAsync(
                int page,
                int limit,
                string threadType,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/message/allthreads/{threadType}");

            // process optional template parameters.
            ApiHelper.AppendUrlWithTemplateParameters(queryBuilder, new Dictionary<string, object>()
            {
                { "threadType", threadType },
            });

            // prepare specfied query parameters.
            var queryParams = new Dictionary<string, object>()
            {
                { "page", page },
                { "limit", limit },
            };

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
            };

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().Get(queryBuilder.ToString(), headers, queryParameters: queryParams);

            if (this.HttpCallBack != null)
            {
                this.HttpCallBack.OnBeforeHttpRequestEventHandler(this.GetClientInstance(), httpRequest);
            }

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);
            if (this.HttpCallBack != null)
            {
                this.HttpCallBack.OnAfterHttpResponseEventHandler(this.GetClientInstance(), response);
            }

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.GetMessageThreadsResponse>(response.Body);
        }

        /// <summary>
        /// This function will allow PM to post new messages in already existing threads.
        /// </summary>
        /// <param name="body">Required parameter: Example: .</param>
        /// <returns>Returns the Models.APIResponseWithoutData response from the API call.</returns>
        public Models.APIResponseWithoutData PostNewMessageForSpecificThread(
                Models.PostNewMessageForSpecificThreadRequest body)
        {
            Task<Models.APIResponseWithoutData> t = this.PostNewMessageForSpecificThreadAsync(body);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// This function will allow PM to post new messages in already existing threads.
        /// </summary>
        /// <param name="body">Required parameter: Example: .</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.APIResponseWithoutData response from the API call.</returns>
        public async Task<Models.APIResponseWithoutData> PostNewMessageForSpecificThreadAsync(
                Models.PostNewMessageForSpecificThreadRequest body,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/message");

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "Content-Type", "application/json" },
            };

            // append body params.
            var bodyText = ApiHelper.JsonSerialize(body);

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().PostBody(queryBuilder.ToString(), headers, bodyText);

            if (this.HttpCallBack != null)
            {
                this.HttpCallBack.OnBeforeHttpRequestEventHandler(this.GetClientInstance(), httpRequest);
            }

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);
            if (this.HttpCallBack != null)
            {
                this.HttpCallBack.OnAfterHttpResponseEventHandler(this.GetClientInstance(), response);
            }

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.APIResponseWithoutData>(response.Body);
        }

        /// <summary>
        /// This function allows the logged in user to get a list of all messages from passed thread Id. You need to use PM credentials.
        /// </summary>
        /// <param name="threadId">Required parameter: ID of the thread.</param>
        /// <returns>Returns the Models.GetMessageListForSpecificThreadResponse response from the API call.</returns>
        public Models.GetMessageListForSpecificThreadResponse GetMessageListForSpecificThread(
                string threadId)
        {
            Task<Models.GetMessageListForSpecificThreadResponse> t = this.GetMessageListForSpecificThreadAsync(threadId);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// This function allows the logged in user to get a list of all messages from passed thread Id. You need to use PM credentials.
        /// </summary>
        /// <param name="threadId">Required parameter: ID of the thread.</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.GetMessageListForSpecificThreadResponse response from the API call.</returns>
        public async Task<Models.GetMessageListForSpecificThreadResponse> GetMessageListForSpecificThreadAsync(
                string threadId,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/message/specificthread/{threadId}/");

            // process optional template parameters.
            ApiHelper.AppendUrlWithTemplateParameters(queryBuilder, new Dictionary<string, object>()
            {
                { "threadId", threadId },
            });

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
            };

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().Get(queryBuilder.ToString(), headers);

            if (this.HttpCallBack != null)
            {
                this.HttpCallBack.OnBeforeHttpRequestEventHandler(this.GetClientInstance(), httpRequest);
            }

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);
            if (this.HttpCallBack != null)
            {
                this.HttpCallBack.OnAfterHttpResponseEventHandler(this.GetClientInstance(), response);
            }

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.GetMessageListForSpecificThreadResponse>(response.Body);
        }
    }
}