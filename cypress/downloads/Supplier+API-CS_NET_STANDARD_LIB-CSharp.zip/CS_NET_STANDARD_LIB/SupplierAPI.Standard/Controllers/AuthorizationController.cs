// <copyright file="AuthorizationController.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace SupplierAPI.Standard.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Dynamic;
    using System.Globalization;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading;
    using System.Threading.Tasks;
    using Newtonsoft.Json.Converters;
    using SupplierAPI.Standard;
    using SupplierAPI.Standard.Authentication;
    using SupplierAPI.Standard.Http.Client;
    using SupplierAPI.Standard.Http.Request;
    using SupplierAPI.Standard.Http.Request.Configuration;
    using SupplierAPI.Standard.Http.Response;
    using SupplierAPI.Standard.Utilities;

    /// <summary>
    /// AuthorizationController.
    /// </summary>
    public class AuthorizationController : BaseController
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="AuthorizationController"/> class.
        /// </summary>
        /// <param name="config"> config instance. </param>
        /// <param name="httpClient"> httpClient. </param>
        /// <param name="authManagers"> authManager. </param>
        /// <param name="httpCallBack"> httpCallBack. </param>
        internal AuthorizationController(IConfiguration config, IHttpClient httpClient, IDictionary<string, IAuthManager> authManagers, HttpCallBack httpCallBack = null)
            : base(config, httpClient, authManagers, httpCallBack)
        {
        }

        /// <summary>
        /// In order to begin utilizing the platform APIs, your application must be authenticated and authorized to access domain resources. Follow the URL with your credentials and obtain an authorization token which is used in every request.
        /// You will have 2 types of tokens. One is on the PMS level, and this one should be used when you send requests related to PMS/PM data. For managing properties, you will need a token on PM level, with PM credentials. For every API call it will be noted which API credentials you should use.
        /// </summary>
        /// <param name="username">Required parameter: Your account email address (for PMS or PM).</param>
        /// <param name="password">Required parameter: Your password.</param>
        /// <returns>Returns the Models.Authorization response from the API call.</returns>
        public Models.Authorization Login(
                string username,
                string password)
        {
            Task<Models.Authorization> t = this.LoginAsync(username, password);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// In order to begin utilizing the platform APIs, your application must be authenticated and authorized to access domain resources. Follow the URL with your credentials and obtain an authorization token which is used in every request.
        /// You will have 2 types of tokens. One is on the PMS level, and this one should be used when you send requests related to PMS/PM data. For managing properties, you will need a token on PM level, with PM credentials. For every API call it will be noted which API credentials you should use.
        /// </summary>
        /// <param name="username">Required parameter: Your account email address (for PMS or PM).</param>
        /// <param name="password">Required parameter: Your password.</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.Authorization response from the API call.</returns>
        public async Task<Models.Authorization> LoginAsync(
                string username,
                string password,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/authc/login");

            // prepare specfied query parameters.
            var queryParams = new Dictionary<string, object>()
            {
                { "username", username },
                { "password", password },
            };

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
            };

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().Get(queryBuilder.ToString(), headers, queryParameters: queryParams);

            if (this.HttpCallBack != null)
            {
                this.HttpCallBack.OnBeforeHttpRequestEventHandler(this.GetClientInstance(), httpRequest);
            }

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);
            if (this.HttpCallBack != null)
            {
                this.HttpCallBack.OnAfterHttpResponseEventHandler(this.GetClientInstance(), response);
            }

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.Authorization>(response.Body);
        }
    }
}