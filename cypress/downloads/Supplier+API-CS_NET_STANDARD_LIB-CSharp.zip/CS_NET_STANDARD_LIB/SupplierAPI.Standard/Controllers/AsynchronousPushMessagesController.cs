// <copyright file="AsynchronousPushMessagesController.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace SupplierAPI.Standard.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Dynamic;
    using System.Globalization;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading;
    using System.Threading.Tasks;
    using Newtonsoft.Json.Converters;
    using SupplierAPI.Standard;
    using SupplierAPI.Standard.Authentication;
    using SupplierAPI.Standard.Http.Client;
    using SupplierAPI.Standard.Http.Request;
    using SupplierAPI.Standard.Http.Request.Configuration;
    using SupplierAPI.Standard.Http.Response;
    using SupplierAPI.Standard.Utilities;

    /// <summary>
    /// AsynchronousPushMessagesController.
    /// </summary>
    public class AsynchronousPushMessagesController : BaseController
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="AsynchronousPushMessagesController"/> class.
        /// </summary>
        /// <param name="config"> config instance. </param>
        /// <param name="httpClient"> httpClient. </param>
        /// <param name="authManagers"> authManager. </param>
        /// <param name="httpCallBack"> httpCallBack. </param>
        internal AsynchronousPushMessagesController(IConfiguration config, IHttpClient httpClient, IDictionary<string, IAuthManager> authManagers, HttpCallBack httpCallBack = null)
            : base(config, httpClient, authManagers, httpCallBack)
        {
        }

        /// <summary>
        /// This is POST request - push notifications (webhooks) which BookingPal will send on PMS endpoint (which is set in push notification API, field - asyncPush) after something is executed in BP. This is necessary since some API calls like validation, onboarding, etc are done over queue in our system, so you will get an asynchronous response.
        /// In these requests, we do not have expected responses from the PMS system. Since these are just notifications.
        /// Important note: In this doc to be able to test this - you need to set a full URL on the Configure button in the right section.
        /// </summary>
        /// <param name="body">Required parameter: Example: .</param>
        public void ValidationPushAsynchronousMessage(
                Models.ValidationAsynchronousPushMessageRequest body)
        {
            Task t = this.ValidationPushAsynchronousMessageAsync(body);
            ApiHelper.RunTaskSynchronously(t);
        }

        /// <summary>
        /// This is POST request - push notifications (webhooks) which BookingPal will send on PMS endpoint (which is set in push notification API, field - asyncPush) after something is executed in BP. This is necessary since some API calls like validation, onboarding, etc are done over queue in our system, so you will get an asynchronous response.
        /// In these requests, we do not have expected responses from the PMS system. Since these are just notifications.
        /// Important note: In this doc to be able to test this - you need to set a full URL on the Configure button in the right section.
        /// </summary>
        /// <param name="body">Required parameter: Example: .</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the void response from the API call.</returns>
        public async Task ValidationPushAsynchronousMessageAsync(
                Models.ValidationAsynchronousPushMessageRequest body,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri(Server.PushServer);

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/push");

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "Content-Type", "application/json" },
            };

            // append body params.
            var bodyText = ApiHelper.JsonSerialize(body);

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().PostBody(queryBuilder.ToString(), headers, bodyText);

            if (this.HttpCallBack != null)
            {
                this.HttpCallBack.OnBeforeHttpRequestEventHandler(this.GetClientInstance(), httpRequest);
            }

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);
            if (this.HttpCallBack != null)
            {
                this.HttpCallBack.OnAfterHttpResponseEventHandler(this.GetClientInstance(), response);
            }

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);
        }

        /// <summary>
        /// This is POST request - push notifications (webhooks) which BookingPal will send on PMS endpoint (which is set in push notification API, field - asyncPush) after something is executed in BP. This is necessary since some API calls like validation, onboarding, etc are done over queue in our system, so you will get an asynchronous response.
        /// In these requests, we do not have expected responses from the PMS system. Since these are just notifications.
        /// Important note: In this doc to be able to test this - you need to set a full URL on the Configure button in the right section.
        /// </summary>
        /// <param name="body">Required parameter: Example: .</param>
        public void ProductImagePushAsynchronousMessage(
                Models.ProductImageAsynchronousPushMessageRequest body)
        {
            Task t = this.ProductImagePushAsynchronousMessageAsync(body);
            ApiHelper.RunTaskSynchronously(t);
        }

        /// <summary>
        /// This is POST request - push notifications (webhooks) which BookingPal will send on PMS endpoint (which is set in push notification API, field - asyncPush) after something is executed in BP. This is necessary since some API calls like validation, onboarding, etc are done over queue in our system, so you will get an asynchronous response.
        /// In these requests, we do not have expected responses from the PMS system. Since these are just notifications.
        /// Important note: In this doc to be able to test this - you need to set a full URL on the Configure button in the right section.
        /// </summary>
        /// <param name="body">Required parameter: Example: .</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the void response from the API call.</returns>
        public async Task ProductImagePushAsynchronousMessageAsync(
                Models.ProductImageAsynchronousPushMessageRequest body,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri(Server.PushServer);

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/pushImage");

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "Content-Type", "application/json" },
            };

            // append body params.
            var bodyText = ApiHelper.JsonSerialize(body);

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().PostBody(queryBuilder.ToString(), headers, bodyText);

            if (this.HttpCallBack != null)
            {
                this.HttpCallBack.OnBeforeHttpRequestEventHandler(this.GetClientInstance(), httpRequest);
            }

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);
            if (this.HttpCallBack != null)
            {
                this.HttpCallBack.OnAfterHttpResponseEventHandler(this.GetClientInstance(), response);
            }

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);
        }
    }
}