// <copyright file="TestingOfMessageAPICallsController.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace SupplierAPI.Standard.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Dynamic;
    using System.Globalization;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading;
    using System.Threading.Tasks;
    using Newtonsoft.Json.Converters;
    using SupplierAPI.Standard;
    using SupplierAPI.Standard.Authentication;
    using SupplierAPI.Standard.Http.Client;
    using SupplierAPI.Standard.Http.Request;
    using SupplierAPI.Standard.Http.Request.Configuration;
    using SupplierAPI.Standard.Http.Response;
    using SupplierAPI.Standard.Utilities;

    /// <summary>
    /// TestingOfMessageAPICallsController.
    /// </summary>
    public class TestingOfMessageAPICallsController : BaseController
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="TestingOfMessageAPICallsController"/> class.
        /// </summary>
        /// <param name="config"> config instance. </param>
        /// <param name="httpClient"> httpClient. </param>
        /// <param name="authManagers"> authManager. </param>
        /// <param name="httpCallBack"> httpCallBack. </param>
        internal TestingOfMessageAPICallsController(IConfiguration config, IHttpClient httpClient, IDictionary<string, IAuthManager> authManagers, HttpCallBack httpCallBack = null)
            : base(config, httpClient, authManagers, httpCallBack)
        {
        }

        /// <summary>
        /// This function allows the logged in user to get all message threads or message threads with an unresponded message from guest for the whole PM. You need to use PM credentials. There is also paging as optional values. If you do not pass this value, we will return the first page and 10 threads per page.
        /// Since API calls for messages depend on channel connections and these values will exist in BookingPal only if guests on channel create some message, these calls can work only on production. So for testing purposes we’ve  built an additional endpoint with the same API calls where you will be able to test these calls.
        /// Note: To be able to test these calls, you need to have at least 1 property, since we will in response return you messages for 1 property from your PM.
        /// </summary>
        /// <param name="page">Required parameter: Example: .</param>
        /// <param name="limit">Required parameter: Example: .</param>
        /// <param name="threadType">Required parameter: Request all threads or only threads with unanswered message {new,all}.</param>
        /// <returns>Returns the Models.GetMessageThreadsResponse response from the API call.</returns>
        public Models.GetMessageThreadsResponse GetTestMessageThreads(
                int page,
                int limit,
                string threadType)
        {
            Task<Models.GetMessageThreadsResponse> t = this.GetTestMessageThreadsAsync(page, limit, threadType);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// This function allows the logged in user to get all message threads or message threads with an unresponded message from guest for the whole PM. You need to use PM credentials. There is also paging as optional values. If you do not pass this value, we will return the first page and 10 threads per page.
        /// Since API calls for messages depend on channel connections and these values will exist in BookingPal only if guests on channel create some message, these calls can work only on production. So for testing purposes we’ve  built an additional endpoint with the same API calls where you will be able to test these calls.
        /// Note: To be able to test these calls, you need to have at least 1 property, since we will in response return you messages for 1 property from your PM.
        /// </summary>
        /// <param name="page">Required parameter: Example: .</param>
        /// <param name="limit">Required parameter: Example: .</param>
        /// <param name="threadType">Required parameter: Request all threads or only threads with unanswered message {new,all}.</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.GetMessageThreadsResponse response from the API call.</returns>
        public async Task<Models.GetMessageThreadsResponse> GetTestMessageThreadsAsync(
                int page,
                int limit,
                string threadType,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/messageTest/allthreads/{threadType}");

            // process optional template parameters.
            ApiHelper.AppendUrlWithTemplateParameters(queryBuilder, new Dictionary<string, object>()
            {
                { "threadType", threadType },
            });

            // prepare specfied query parameters.
            var queryParams = new Dictionary<string, object>()
            {
                { "page", page },
                { "limit", limit },
            };

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
            };

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().Get(queryBuilder.ToString(), headers, queryParameters: queryParams);

            if (this.HttpCallBack != null)
            {
                this.HttpCallBack.OnBeforeHttpRequestEventHandler(this.GetClientInstance(), httpRequest);
            }

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);
            if (this.HttpCallBack != null)
            {
                this.HttpCallBack.OnAfterHttpResponseEventHandler(this.GetClientInstance(), response);
            }

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.GetMessageThreadsResponse>(response.Body);
        }

        /// <summary>
        /// Since API calls for messages depend on channel connections and these values will exist in BookingPal only if guests on channel create some message, these calls can work only on production. So for testing purposes, we’ve built an additional endpoint with the same API calls where you will be able to test these calls.
        /// This function allows the logged-in user to get a list of all messages from passed thread Id. You need to use PM credentials.
        /// Note: To be able to test these calls, you need to have at least 1 property, since we will in response return you messages for 1 property from your PM.
        /// </summary>
        /// <param name="threadId">Required parameter: ID of thread.</param>
        /// <returns>Returns the Models.GetMessageListForSpecificThreadResponse response from the API call.</returns>
        public Models.GetMessageListForSpecificThreadResponse GetTestMessageListForSpecificThread(
                string threadId)
        {
            Task<Models.GetMessageListForSpecificThreadResponse> t = this.GetTestMessageListForSpecificThreadAsync(threadId);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// Since API calls for messages depend on channel connections and these values will exist in BookingPal only if guests on channel create some message, these calls can work only on production. So for testing purposes, we’ve built an additional endpoint with the same API calls where you will be able to test these calls.
        /// This function allows the logged-in user to get a list of all messages from passed thread Id. You need to use PM credentials.
        /// Note: To be able to test these calls, you need to have at least 1 property, since we will in response return you messages for 1 property from your PM.
        /// </summary>
        /// <param name="threadId">Required parameter: ID of thread.</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.GetMessageListForSpecificThreadResponse response from the API call.</returns>
        public async Task<Models.GetMessageListForSpecificThreadResponse> GetTestMessageListForSpecificThreadAsync(
                string threadId,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/messageTest/specificthread/{threadId}");

            // process optional template parameters.
            ApiHelper.AppendUrlWithTemplateParameters(queryBuilder, new Dictionary<string, object>()
            {
                { "threadId", threadId },
            });

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
            };

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().Get(queryBuilder.ToString(), headers);

            if (this.HttpCallBack != null)
            {
                this.HttpCallBack.OnBeforeHttpRequestEventHandler(this.GetClientInstance(), httpRequest);
            }

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);
            if (this.HttpCallBack != null)
            {
                this.HttpCallBack.OnAfterHttpResponseEventHandler(this.GetClientInstance(), response);
            }

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.GetMessageListForSpecificThreadResponse>(response.Body);
        }

        /// <summary>
        /// This function will allow PM to post new messages in already existing threads. Since this call is only for testing - we will not actually save these passed values.
        /// Since API calls for messages depend on channel connections and these values will exist in BookingPal only if guests on channel create some message, these calls can work only on production. So for testing purposes, we’ve built an additional endpoint with the same API calls where you will be able to test these calls.
        /// Note: To be able to test these calls, you need to have at least 1 property, since we will in response return to you messages for 1 property from your PM.
        /// </summary>
        /// <param name="body">Required parameter: Example: .</param>
        /// <returns>Returns the Models.APIResponseWithoutData response from the API call.</returns>
        public Models.APIResponseWithoutData PostNewTestMessageForSpecificThread(
                Models.PostNewMessageForSpecificThreadRequest body)
        {
            Task<Models.APIResponseWithoutData> t = this.PostNewTestMessageForSpecificThreadAsync(body);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// This function will allow PM to post new messages in already existing threads. Since this call is only for testing - we will not actually save these passed values.
        /// Since API calls for messages depend on channel connections and these values will exist in BookingPal only if guests on channel create some message, these calls can work only on production. So for testing purposes, we’ve built an additional endpoint with the same API calls where you will be able to test these calls.
        /// Note: To be able to test these calls, you need to have at least 1 property, since we will in response return to you messages for 1 property from your PM.
        /// </summary>
        /// <param name="body">Required parameter: Example: .</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.APIResponseWithoutData response from the API call.</returns>
        public async Task<Models.APIResponseWithoutData> PostNewTestMessageForSpecificThreadAsync(
                Models.PostNewMessageForSpecificThreadRequest body,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/messageTest");

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "Content-Type", "application/json" },
            };

            // append body params.
            var bodyText = ApiHelper.JsonSerialize(body);

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().PostBody(queryBuilder.ToString(), headers, bodyText);

            if (this.HttpCallBack != null)
            {
                this.HttpCallBack.OnBeforeHttpRequestEventHandler(this.GetClientInstance(), httpRequest);
            }

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);
            if (this.HttpCallBack != null)
            {
                this.HttpCallBack.OnAfterHttpResponseEventHandler(this.GetClientInstance(), response);
            }

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.APIResponseWithoutData>(response.Body);
        }
    }
}