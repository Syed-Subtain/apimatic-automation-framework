// <copyright file="RatesAndAvailabilityController.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace SupplierAPI.Standard.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Dynamic;
    using System.Globalization;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading;
    using System.Threading.Tasks;
    using Newtonsoft.Json.Converters;
    using SupplierAPI.Standard;
    using SupplierAPI.Standard.Authentication;
    using SupplierAPI.Standard.Http.Client;
    using SupplierAPI.Standard.Http.Request;
    using SupplierAPI.Standard.Http.Request.Configuration;
    using SupplierAPI.Standard.Http.Response;
    using SupplierAPI.Standard.Utilities;

    /// <summary>
    /// RatesAndAvailabilityController.
    /// </summary>
    public class RatesAndAvailabilityController : BaseController
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="RatesAndAvailabilityController"/> class.
        /// </summary>
        /// <param name="config"> config instance. </param>
        /// <param name="httpClient"> httpClient. </param>
        /// <param name="authManagers"> authManager. </param>
        /// <param name="httpCallBack"> httpCallBack. </param>
        internal RatesAndAvailabilityController(IConfiguration config, IHttpClient httpClient, IDictionary<string, IAuthManager> authManagers, HttpCallBack httpCallBack = null)
            : base(config, httpClient, authManagers, httpCallBack)
        {
        }

        /// <summary>
        /// Create and update calls are the same. When data is sent, if the data already exists in BookingPal - that data will be updated. Otherwise it will be created (inserted). If you want to update data for some period, you should just send data for these dates. All other data (for other dates) will remain untouched. This allows you to update only changed periods and we will not delete previously sent data for other periods.
        /// In the case of a first data push, all data for one property should be sent in one request.  When making updates or changes to existing data, then all changed data should be sent in one request.
        /// Note: Even property is set on LOS rates - you can use this call and send rates per day with all restrictions. These rates with restrictions will be used on channels which do not allow LOS rates.
        /// This API call can not be used for OWN properties.
        /// Important: Maximum allowed end date in any data type is 3 years in future.
        /// Every API call in this section should be with PM credentials.
        /// </summary>
        /// <param name="body">Required parameter: Example: .</param>
        /// <returns>Returns the Models.RatesAvailabilityResponse response from the API call.</returns>
        public Models.RatesAvailabilityResponse CreateAndUpdateRatesAndAvailability(
                Models.CreateandUpdateRatesandAvailabilityRequest body)
        {
            Task<Models.RatesAvailabilityResponse> t = this.CreateAndUpdateRatesAndAvailabilityAsync(body);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// Create and update calls are the same. When data is sent, if the data already exists in BookingPal - that data will be updated. Otherwise it will be created (inserted). If you want to update data for some period, you should just send data for these dates. All other data (for other dates) will remain untouched. This allows you to update only changed periods and we will not delete previously sent data for other periods.
        /// In the case of a first data push, all data for one property should be sent in one request.  When making updates or changes to existing data, then all changed data should be sent in one request.
        /// Note: Even property is set on LOS rates - you can use this call and send rates per day with all restrictions. These rates with restrictions will be used on channels which do not allow LOS rates.
        /// This API call can not be used for OWN properties.
        /// Important: Maximum allowed end date in any data type is 3 years in future.
        /// Every API call in this section should be with PM credentials.
        /// </summary>
        /// <param name="body">Required parameter: Example: .</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.RatesAvailabilityResponse response from the API call.</returns>
        public async Task<Models.RatesAvailabilityResponse> CreateAndUpdateRatesAndAvailabilityAsync(
                Models.CreateandUpdateRatesandAvailabilityRequest body,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/ra");

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "Content-Type", "application/json" },
            };

            // append body params.
            var bodyText = ApiHelper.JsonSerialize(body);

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().PostBody(queryBuilder.ToString(), headers, bodyText);

            if (this.HttpCallBack != null)
            {
                this.HttpCallBack.OnBeforeHttpRequestEventHandler(this.GetClientInstance(), httpRequest);
            }

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);
            if (this.HttpCallBack != null)
            {
                this.HttpCallBack.OnAfterHttpResponseEventHandler(this.GetClientInstance(), response);
            }

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.RatesAvailabilityResponse>(response.Body);
        }

        /// <summary>
        /// This function allows logged in users to get rates and availability for the specific product.
        /// Every API call in this section should be with PM credentials.
        /// </summary>
        /// <param name="contentType">Required parameter: Example: .</param>
        /// <param name="productId">Required parameter: ID of the property.</param>
        /// <returns>Returns the Models.RatesAvailabilityResponse response from the API call.</returns>
        public Models.RatesAvailabilityResponse GetRatesAndAvailabilityProductID(
                string contentType,
                string productId)
        {
            Task<Models.RatesAvailabilityResponse> t = this.GetRatesAndAvailabilityProductIDAsync(contentType, productId);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// This function allows logged in users to get rates and availability for the specific product.
        /// Every API call in this section should be with PM credentials.
        /// </summary>
        /// <param name="contentType">Required parameter: Example: .</param>
        /// <param name="productId">Required parameter: ID of the property.</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.RatesAvailabilityResponse response from the API call.</returns>
        public async Task<Models.RatesAvailabilityResponse> GetRatesAndAvailabilityProductIDAsync(
                string contentType,
                string productId,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/ra/{productId}");

            // process optional template parameters.
            ApiHelper.AppendUrlWithTemplateParameters(queryBuilder, new Dictionary<string, object>()
            {
                { "productId", productId },
            });

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "Content-Type", contentType },
            };

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().Get(queryBuilder.ToString(), headers);

            if (this.HttpCallBack != null)
            {
                this.HttpCallBack.OnBeforeHttpRequestEventHandler(this.GetClientInstance(), httpRequest);
            }

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);
            if (this.HttpCallBack != null)
            {
                this.HttpCallBack.OnAfterHttpResponseEventHandler(this.GetClientInstance(), response);
            }

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.RatesAvailabilityResponse>(response.Body);
        }
    }
}