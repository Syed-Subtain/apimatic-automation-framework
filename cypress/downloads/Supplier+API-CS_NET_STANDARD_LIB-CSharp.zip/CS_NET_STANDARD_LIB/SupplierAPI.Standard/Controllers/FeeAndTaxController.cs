// <copyright file="FeeAndTaxController.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace SupplierAPI.Standard.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Dynamic;
    using System.Globalization;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading;
    using System.Threading.Tasks;
    using Newtonsoft.Json.Converters;
    using SupplierAPI.Standard;
    using SupplierAPI.Standard.Authentication;
    using SupplierAPI.Standard.Http.Client;
    using SupplierAPI.Standard.Http.Request;
    using SupplierAPI.Standard.Http.Request.Configuration;
    using SupplierAPI.Standard.Http.Response;
    using SupplierAPI.Standard.Utilities;

    /// <summary>
    /// FeeAndTaxController.
    /// </summary>
    public class FeeAndTaxController : BaseController
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="FeeAndTaxController"/> class.
        /// </summary>
        /// <param name="config"> config instance. </param>
        /// <param name="httpClient"> httpClient. </param>
        /// <param name="authManagers"> authManager. </param>
        /// <param name="httpCallBack"> httpCallBack. </param>
        internal FeeAndTaxController(IConfiguration config, IHttpClient httpClient, IDictionary<string, IAuthManager> authManagers, HttpCallBack httpCallBack = null)
            : base(config, httpClient, authManagers, httpCallBack)
        {
        }

        /// <summary>
        /// This function allows the logged in user to set fees (i.e. cleaning fee, damage waiver, extra bed, extra person etc.) and taxes for the specific product. Here, you always need to send all fees and taxes for one property. All fees or taxes which were in our system for that property and which are not in the new request will be deleted. Taxes in the BookingPal system will always have percent value. .
        /// If you want to delete all fees and/or taxes for one property (if you do not have fees and taxes in your system for one property) send an empty list of fees and.or taxes. In short when you use this request you need to always send us a full list of fees and taxes per property, since we will do a full update.
        /// Note: Security deposits on Airbnb must be between 100 and 5000 USD. Any value smaller or larger will default to the largest accepted value. If currencies are not in USD, BookingPal will first convert the currency to USD before posting the security deposit on Airbnb.
        /// </summary>
        /// <param name="body">Required parameter: Example: .</param>
        /// <returns>Returns the Models.FeeTaxResponse response from the API call.</returns>
        public Models.FeeTaxResponse CreateFeeAndTax(
                Models.CreateFeesandTaxesRequest body)
        {
            Task<Models.FeeTaxResponse> t = this.CreateFeeAndTaxAsync(body);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// This function allows the logged in user to set fees (i.e. cleaning fee, damage waiver, extra bed, extra person etc.) and taxes for the specific product. Here, you always need to send all fees and taxes for one property. All fees or taxes which were in our system for that property and which are not in the new request will be deleted. Taxes in the BookingPal system will always have percent value. .
        /// If you want to delete all fees and/or taxes for one property (if you do not have fees and taxes in your system for one property) send an empty list of fees and.or taxes. In short when you use this request you need to always send us a full list of fees and taxes per property, since we will do a full update.
        /// Note: Security deposits on Airbnb must be between 100 and 5000 USD. Any value smaller or larger will default to the largest accepted value. If currencies are not in USD, BookingPal will first convert the currency to USD before posting the security deposit on Airbnb.
        /// </summary>
        /// <param name="body">Required parameter: Example: .</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.FeeTaxResponse response from the API call.</returns>
        public async Task<Models.FeeTaxResponse> CreateFeeAndTaxAsync(
                Models.CreateFeesandTaxesRequest body,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/taxfee");

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "Content-Type", "application/json" },
            };

            // append body params.
            var bodyText = ApiHelper.JsonSerialize(body);

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().PostBody(queryBuilder.ToString(), headers, bodyText);

            if (this.HttpCallBack != null)
            {
                this.HttpCallBack.OnBeforeHttpRequestEventHandler(this.GetClientInstance(), httpRequest);
            }

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);
            if (this.HttpCallBack != null)
            {
                this.HttpCallBack.OnAfterHttpResponseEventHandler(this.GetClientInstance(), response);
            }

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.FeeTaxResponse>(response.Body);
        }

        /// <summary>
        /// This function allows the logged in user to get a fee list for the specific product.
        /// </summary>
        /// <param name="productId">Required parameter: ID of the property.</param>
        /// <returns>Returns the Models.FeeTaxResponse response from the API call.</returns>
        public Models.FeeTaxResponse GetFeeAndTaxListByProductId(
                string productId)
        {
            Task<Models.FeeTaxResponse> t = this.GetFeeAndTaxListByProductIdAsync(productId);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// This function allows the logged in user to get a fee list for the specific product.
        /// </summary>
        /// <param name="productId">Required parameter: ID of the property.</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.FeeTaxResponse response from the API call.</returns>
        public async Task<Models.FeeTaxResponse> GetFeeAndTaxListByProductIdAsync(
                string productId,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/taxfee/{productId}");

            // process optional template parameters.
            ApiHelper.AppendUrlWithTemplateParameters(queryBuilder, new Dictionary<string, object>()
            {
                { "productId", productId },
            });

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
            };

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().Get(queryBuilder.ToString(), headers);

            if (this.HttpCallBack != null)
            {
                this.HttpCallBack.OnBeforeHttpRequestEventHandler(this.GetClientInstance(), httpRequest);
            }

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);
            if (this.HttpCallBack != null)
            {
                this.HttpCallBack.OnAfterHttpResponseEventHandler(this.GetClientInstance(), response);
            }

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.FeeTaxResponse>(response.Body);
        }
    }
}