// <copyright file="ValidationController.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace SupplierAPI.Standard.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Dynamic;
    using System.Globalization;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading;
    using System.Threading.Tasks;
    using Newtonsoft.Json.Converters;
    using SupplierAPI.Standard;
    using SupplierAPI.Standard.Authentication;
    using SupplierAPI.Standard.Http.Client;
    using SupplierAPI.Standard.Http.Request;
    using SupplierAPI.Standard.Http.Request.Configuration;
    using SupplierAPI.Standard.Http.Response;
    using SupplierAPI.Standard.Utilities;

    /// <summary>
    /// ValidationController.
    /// </summary>
    public class ValidationController : BaseController
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ValidationController"/> class.
        /// </summary>
        /// <param name="config"> config instance. </param>
        /// <param name="httpClient"> httpClient. </param>
        /// <param name="authManagers"> authManager. </param>
        /// <param name="httpCallBack"> httpCallBack. </param>
        internal ValidationController(IConfiguration config, IHttpClient httpClient, IDictionary<string, IAuthManager> authManagers, HttpCallBack httpCallBack = null)
            : base(config, httpClient, authManagers, httpCallBack)
        {
        }

        /// <summary>
        /// This function will allow the PMS to call the BookingPal property validation job for a list of properties from request. These properties must belong to the current user and authorization token should be on PM level.
        /// Also, we will run validation only for properties that are activated. If you deactivate property - we will not validate this property.
        /// </summary>
        /// <param name="body">Required parameter: Example: .</param>
        /// <returns>Returns the Models.APIResponseWithoutData response from the API call.</returns>
        public Models.APIResponseWithoutData BookingPalValidationJobListOfProperties(
                Models.ValidationForListOfPropertiesRequest body)
        {
            Task<Models.APIResponseWithoutData> t = this.BookingPalValidationJobListOfPropertiesAsync(body);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// This function will allow the PMS to call the BookingPal property validation job for a list of properties from request. These properties must belong to the current user and authorization token should be on PM level.
        /// Also, we will run validation only for properties that are activated. If you deactivate property - we will not validate this property.
        /// </summary>
        /// <param name="body">Required parameter: Example: .</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.APIResponseWithoutData response from the API call.</returns>
        public async Task<Models.APIResponseWithoutData> BookingPalValidationJobListOfPropertiesAsync(
                Models.ValidationForListOfPropertiesRequest body,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/validation");

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "Content-Type", "application/json" },
            };

            // append body params.
            var bodyText = ApiHelper.JsonSerialize(body);

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().PostBody(queryBuilder.ToString(), headers, bodyText);

            if (this.HttpCallBack != null)
            {
                this.HttpCallBack.OnBeforeHttpRequestEventHandler(this.GetClientInstance(), httpRequest);
            }

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);
            if (this.HttpCallBack != null)
            {
                this.HttpCallBack.OnAfterHttpResponseEventHandler(this.GetClientInstance(), response);
            }

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.APIResponseWithoutData>(response.Body);
        }

        /// <summary>
        /// This function will allow the PMC to call the BookingPal property validation job for all properties identified which belong to the current user. Authorization token should be on PM level. .
        /// Also we will run validation only for properties which are activated. If you deactivate property - we will not validate this property.
        /// After the request you will get a response indicating if messages were processed or not. If the request is good your request for the validator job will be put into a queue. Once the request is processed, BookingPal will send an async push message per property informing the user if a property is valid or not, and if it is not valid - with reasons why the validation failed. This message will be sent on the endpoint which was entered in section Push Notifications, field asyncPush.
        /// Note: If the property is distributed already on some channel - this property will not be moved to an Incomplete state. Also if you have property on Incomplete state because of some reason, and you update this data which causes that property is on ‘Incomplete’ property will not be moved automatically to a valid state. Instead, you should run a Validation job manually for that property or wait for our automatic validation job which we are running once per day. .
        /// To make the property ready for Onboarding you should run validation first. if the property is valid - it will be ready for onboarding. Otherwise - the property will be in Incomplete state. Also, we will run validation only for properties that are activated. If you deactivate property - we will not validate this property.
        /// </summary>
        /// <returns>Returns the Models.APIResponseWithoutData response from the API call.</returns>
        public Models.APIResponseWithoutData BookingPalValidationJobFullPM()
        {
            Task<Models.APIResponseWithoutData> t = this.BookingPalValidationJobFullPMAsync();
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// This function will allow the PMC to call the BookingPal property validation job for all properties identified which belong to the current user. Authorization token should be on PM level. .
        /// Also we will run validation only for properties which are activated. If you deactivate property - we will not validate this property.
        /// After the request you will get a response indicating if messages were processed or not. If the request is good your request for the validator job will be put into a queue. Once the request is processed, BookingPal will send an async push message per property informing the user if a property is valid or not, and if it is not valid - with reasons why the validation failed. This message will be sent on the endpoint which was entered in section Push Notifications, field asyncPush.
        /// Note: If the property is distributed already on some channel - this property will not be moved to an Incomplete state. Also if you have property on Incomplete state because of some reason, and you update this data which causes that property is on ‘Incomplete’ property will not be moved automatically to a valid state. Instead, you should run a Validation job manually for that property or wait for our automatic validation job which we are running once per day. .
        /// To make the property ready for Onboarding you should run validation first. if the property is valid - it will be ready for onboarding. Otherwise - the property will be in Incomplete state. Also, we will run validation only for properties that are activated. If you deactivate property - we will not validate this property.
        /// </summary>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.APIResponseWithoutData response from the API call.</returns>
        public async Task<Models.APIResponseWithoutData> BookingPalValidationJobFullPMAsync(CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/validation");

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
            };

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().Get(queryBuilder.ToString(), headers);

            if (this.HttpCallBack != null)
            {
                this.HttpCallBack.OnBeforeHttpRequestEventHandler(this.GetClientInstance(), httpRequest);
            }

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);
            if (this.HttpCallBack != null)
            {
                this.HttpCallBack.OnAfterHttpResponseEventHandler(this.GetClientInstance(), response);
            }

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.APIResponseWithoutData>(response.Body);
        }
    }
}