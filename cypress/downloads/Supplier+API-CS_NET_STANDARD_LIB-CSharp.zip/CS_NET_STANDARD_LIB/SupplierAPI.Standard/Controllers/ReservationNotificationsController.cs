// <copyright file="ReservationNotificationsController.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace SupplierAPI.Standard.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Dynamic;
    using System.Globalization;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading;
    using System.Threading.Tasks;
    using Newtonsoft.Json.Converters;
    using SupplierAPI.Standard;
    using SupplierAPI.Standard.Authentication;
    using SupplierAPI.Standard.Http.Client;
    using SupplierAPI.Standard.Http.Request;
    using SupplierAPI.Standard.Http.Request.Configuration;
    using SupplierAPI.Standard.Http.Response;
    using SupplierAPI.Standard.Utilities;

    /// <summary>
    /// ReservationNotificationsController.
    /// </summary>
    public class ReservationNotificationsController : BaseController
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ReservationNotificationsController"/> class.
        /// </summary>
        /// <param name="config"> config instance. </param>
        /// <param name="httpClient"> httpClient. </param>
        /// <param name="authManagers"> authManager. </param>
        /// <param name="httpCallBack"> httpCallBack. </param>
        internal ReservationNotificationsController(IConfiguration config, IHttpClient httpClient, IDictionary<string, IAuthManager> authManagers, HttpCallBack httpCallBack = null)
            : base(config, httpClient, authManagers, httpCallBack)
        {
        }

        /// <summary>
        /// This function allows logged-in users to get all reservations for the specific product.
        /// </summary>
        /// <param name="productId">Required parameter: Product ID.</param>
        /// <returns>Returns the Models.ReservationGetResponse response from the API call.</returns>
        public Models.ReservationGetResponse GetReservationByProduct(
                string productId)
        {
            Task<Models.ReservationGetResponse> t = this.GetReservationByProductAsync(productId);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// This function allows logged-in users to get all reservations for the specific product.
        /// </summary>
        /// <param name="productId">Required parameter: Product ID.</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.ReservationGetResponse response from the API call.</returns>
        public async Task<Models.ReservationGetResponse> GetReservationByProductAsync(
                string productId,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/reservation/{productId}");

            // process optional template parameters.
            ApiHelper.AppendUrlWithTemplateParameters(queryBuilder, new Dictionary<string, object>()
            {
                { "productId", productId },
            });

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
            };

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().Get(queryBuilder.ToString(), headers);

            if (this.HttpCallBack != null)
            {
                this.HttpCallBack.OnBeforeHttpRequestEventHandler(this.GetClientInstance(), httpRequest);
            }

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);
            if (this.HttpCallBack != null)
            {
                this.HttpCallBack.OnAfterHttpResponseEventHandler(this.GetClientInstance(), response);
            }

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.ReservationGetResponse>(response.Body);
        }

        /// <summary>
        /// This function allows logged-in users to get reservation data by its reservation ID.
        /// </summary>
        /// <param name="reservationId">Required parameter: Reservation ID.</param>
        /// <returns>Returns the Models.ReservationGetResponse response from the API call.</returns>
        public Models.ReservationGetResponse GetReservationById(
                string reservationId)
        {
            Task<Models.ReservationGetResponse> t = this.GetReservationByIdAsync(reservationId);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// This function allows logged-in users to get reservation data by its reservation ID.
        /// </summary>
        /// <param name="reservationId">Required parameter: Reservation ID.</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.ReservationGetResponse response from the API call.</returns>
        public async Task<Models.ReservationGetResponse> GetReservationByIdAsync(
                string reservationId,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/reservation/getReservation/{reservationId}");

            // process optional template parameters.
            ApiHelper.AppendUrlWithTemplateParameters(queryBuilder, new Dictionary<string, object>()
            {
                { "reservationId", reservationId },
            });

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
            };

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().Get(queryBuilder.ToString(), headers);

            if (this.HttpCallBack != null)
            {
                this.HttpCallBack.OnBeforeHttpRequestEventHandler(this.GetClientInstance(), httpRequest);
            }

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);
            if (this.HttpCallBack != null)
            {
                this.HttpCallBack.OnAfterHttpResponseEventHandler(this.GetClientInstance(), response);
            }

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.ReservationGetResponse>(response.Body);
        }

        /// <summary>
        /// This API call will return a list of reservations that belong to the current user.
        /// </summary>
        /// <param name="page">Optional parameter: The page number for the query.</param>
        /// <param name="limit">Optional parameter: The limit of records per each page (max 50 records per page).</param>
        /// <returns>Returns the Models.ReservationGetResponse response from the API call.</returns>
        public Models.ReservationGetResponse GetReservationByPM(
                double? page = null,
                double? limit = null)
        {
            Task<Models.ReservationGetResponse> t = this.GetReservationByPMAsync(page, limit);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// This API call will return a list of reservations that belong to the current user.
        /// </summary>
        /// <param name="page">Optional parameter: The page number for the query.</param>
        /// <param name="limit">Optional parameter: The limit of records per each page (max 50 records per page).</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.ReservationGetResponse response from the API call.</returns>
        public async Task<Models.ReservationGetResponse> GetReservationByPMAsync(
                double? page = null,
                double? limit = null,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/reservation");

            // prepare specfied query parameters.
            var queryParams = new Dictionary<string, object>()
            {
                { "page", page },
                { "limit", limit },
            };

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
            };

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().Get(queryBuilder.ToString(), headers, queryParameters: queryParams);

            if (this.HttpCallBack != null)
            {
                this.HttpCallBack.OnBeforeHttpRequestEventHandler(this.GetClientInstance(), httpRequest);
            }

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);
            if (this.HttpCallBack != null)
            {
                this.HttpCallBack.OnAfterHttpResponseEventHandler(this.GetClientInstance(), response);
            }

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.ReservationGetResponse>(response.Body);
        }

        /// <summary>
        /// This function sends reservation notification requests to the provided link "reservationLink" in the Push Notification API call. .
        /// This is a new API cal added instead of deprecated separate API calls for sending a new reservation request and sending cancel reservation request.
        /// So when BookingPal gets a new reservation, or when some existing reservation is updated or canceled - we will push this POST request to the "reservationLink" link which you set in BookingPal for your PMS (in the Push Notification section). .
        /// VERY IMPORTANT: Set "reservationLink" in the Push Notification section only when you implement a new Push function API call. This will be a flag for us that you switched to the new Reservation function.
        /// Important note: In this doc to be able to test this - you need to set a full URL on the Configure button in the right section.
        /// Note: Credit card data will be sent only if PMS should process payment in their system.
        /// Also, data that will be passed to PMS depends on channels - and do we get all of this data. So you should be aware that some data like for example customer address data maybe be mising.
        /// Additional note: Some channels support modification. When you implement this function we will process modification over action type 'UPDATE' and you will get the same reservation ID as you got when the reservation is created, so you will know which reservation should be modified.
        /// </summary>
        /// <param name="body">Required parameter: Example: .</param>
        /// <returns>Returns the Models.ReservationPushResponse response from the API call.</returns>
        public Models.ReservationPushResponse GeneralReservationNotificationPUSH(
                Models.GeneralReservationNotificationRequest body)
        {
            Task<Models.ReservationPushResponse> t = this.GeneralReservationNotificationPUSHAsync(body);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// This function sends reservation notification requests to the provided link "reservationLink" in the Push Notification API call. .
        /// This is a new API cal added instead of deprecated separate API calls for sending a new reservation request and sending cancel reservation request.
        /// So when BookingPal gets a new reservation, or when some existing reservation is updated or canceled - we will push this POST request to the "reservationLink" link which you set in BookingPal for your PMS (in the Push Notification section). .
        /// VERY IMPORTANT: Set "reservationLink" in the Push Notification section only when you implement a new Push function API call. This will be a flag for us that you switched to the new Reservation function.
        /// Important note: In this doc to be able to test this - you need to set a full URL on the Configure button in the right section.
        /// Note: Credit card data will be sent only if PMS should process payment in their system.
        /// Also, data that will be passed to PMS depends on channels - and do we get all of this data. So you should be aware that some data like for example customer address data maybe be mising.
        /// Additional note: Some channels support modification. When you implement this function we will process modification over action type 'UPDATE' and you will get the same reservation ID as you got when the reservation is created, so you will know which reservation should be modified.
        /// </summary>
        /// <param name="body">Required parameter: Example: .</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.ReservationPushResponse response from the API call.</returns>
        public async Task<Models.ReservationPushResponse> GeneralReservationNotificationPUSHAsync(
                Models.GeneralReservationNotificationRequest body,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/reservation");

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "Content-Type", "application/json" },
            };

            // append body params.
            var bodyText = ApiHelper.JsonSerialize(body);

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().PostBody(queryBuilder.ToString(), headers, bodyText);

            if (this.HttpCallBack != null)
            {
                this.HttpCallBack.OnBeforeHttpRequestEventHandler(this.GetClientInstance(), httpRequest);
            }

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);
            if (this.HttpCallBack != null)
            {
                this.HttpCallBack.OnAfterHttpResponseEventHandler(this.GetClientInstance(), response);
            }

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.ReservationPushResponse>(response.Body);
        }

        /// <summary>
        /// DEPRECATED. Instead, check General Reservation Notification.
        /// This function sends the request to the provided link about a new reservation. So when BookingPal gets a new reservation - we will push this POST request to the link which you set in BookingPal for your PMS (in Push Notification section). .
        /// Important note: In this doc to be able to test this - you need to set a full URL on the Configure button in the right section.
        /// Note: Credit card data will be sent only if PMS should process payment in their system.
        /// Also, data that will be passed to PMS depends on channels - and do we get all of this data. So we have column ‘Mandatory’ to be aware that some data will be missing if we do not get them from a channel (like some guest address data).
        /// Additional note: Some channels support modification. At this moment we will process modification first by canceling the current reservation and then we will process the new regular reservation. In these cases for tracking purposes, you can use channel reservation ID (confirmationID) which should be the same in these cases.
        /// </summary>
        /// <param name="body">Required parameter: Example: .</param>
        /// <returns>Returns the Models.ReservationPushResponse response from the API call.</returns>
        public Models.ReservationPushResponse NewReservationNotificationPUSH(
                Models.ReservationNotificationObject body)
        {
            Task<Models.ReservationPushResponse> t = this.NewReservationNotificationPUSHAsync(body);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// DEPRECATED. Instead, check General Reservation Notification.
        /// This function sends the request to the provided link about a new reservation. So when BookingPal gets a new reservation - we will push this POST request to the link which you set in BookingPal for your PMS (in Push Notification section). .
        /// Important note: In this doc to be able to test this - you need to set a full URL on the Configure button in the right section.
        /// Note: Credit card data will be sent only if PMS should process payment in their system.
        /// Also, data that will be passed to PMS depends on channels - and do we get all of this data. So we have column ‘Mandatory’ to be aware that some data will be missing if we do not get them from a channel (like some guest address data).
        /// Additional note: Some channels support modification. At this moment we will process modification first by canceling the current reservation and then we will process the new regular reservation. In these cases for tracking purposes, you can use channel reservation ID (confirmationID) which should be the same in these cases.
        /// </summary>
        /// <param name="body">Required parameter: Example: .</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.ReservationPushResponse response from the API call.</returns>
        public async Task<Models.ReservationPushResponse> NewReservationNotificationPUSHAsync(
                Models.ReservationNotificationObject body,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/create");

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "Content-Type", "application/json" },
            };

            // append body params.
            var bodyText = ApiHelper.JsonSerialize(body);

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().PostBody(queryBuilder.ToString(), headers, bodyText);

            if (this.HttpCallBack != null)
            {
                this.HttpCallBack.OnBeforeHttpRequestEventHandler(this.GetClientInstance(), httpRequest);
            }

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);
            if (this.HttpCallBack != null)
            {
                this.HttpCallBack.OnAfterHttpResponseEventHandler(this.GetClientInstance(), response);
            }

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.ReservationPushResponse>(response.Body);
        }

        /// <summary>
        /// DEPRECATED. Instead, check General Reservation Notification.
        /// This function sends the request to the provided link about the reservation cancellation. So when BookingPal gets a cancel reservation request from the channel - we will push this POST request to the link which you set in BookingPal for your PMS (in Push Notification section).
        /// Important note: In this doc to be able to test this - you need to set a full URL on the Configure button in the right section.
        /// </summary>
        /// <param name="body">Required parameter: Example: .</param>
        /// <returns>Returns the Models.ReservationPushResponse response from the API call.</returns>
        public Models.ReservationPushResponse ReservationCancellationNotificationPUSH(
                Models.CancelReservationNotificationObject body)
        {
            Task<Models.ReservationPushResponse> t = this.ReservationCancellationNotificationPUSHAsync(body);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// DEPRECATED. Instead, check General Reservation Notification.
        /// This function sends the request to the provided link about the reservation cancellation. So when BookingPal gets a cancel reservation request from the channel - we will push this POST request to the link which you set in BookingPal for your PMS (in Push Notification section).
        /// Important note: In this doc to be able to test this - you need to set a full URL on the Configure button in the right section.
        /// </summary>
        /// <param name="body">Required parameter: Example: .</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.ReservationPushResponse response from the API call.</returns>
        public async Task<Models.ReservationPushResponse> ReservationCancellationNotificationPUSHAsync(
                Models.CancelReservationNotificationObject body,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/cancel");

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "Content-Type", "application/json" },
            };

            // append body params.
            var bodyText = ApiHelper.JsonSerialize(body);

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().PostBody(queryBuilder.ToString(), headers, bodyText);

            if (this.HttpCallBack != null)
            {
                this.HttpCallBack.OnBeforeHttpRequestEventHandler(this.GetClientInstance(), httpRequest);
            }

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);
            if (this.HttpCallBack != null)
            {
                this.HttpCallBack.OnAfterHttpResponseEventHandler(this.GetClientInstance(), response);
            }

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.ReservationPushResponse>(response.Body);
        }
    }
}