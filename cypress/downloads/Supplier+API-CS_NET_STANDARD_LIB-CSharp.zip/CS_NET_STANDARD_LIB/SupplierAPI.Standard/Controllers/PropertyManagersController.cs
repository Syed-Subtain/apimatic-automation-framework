// <copyright file="PropertyManagersController.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace SupplierAPI.Standard.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Dynamic;
    using System.Globalization;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading;
    using System.Threading.Tasks;
    using Newtonsoft.Json.Converters;
    using SupplierAPI.Standard;
    using SupplierAPI.Standard.Authentication;
    using SupplierAPI.Standard.Http.Client;
    using SupplierAPI.Standard.Http.Request;
    using SupplierAPI.Standard.Http.Request.Configuration;
    using SupplierAPI.Standard.Http.Response;
    using SupplierAPI.Standard.Utilities;

    /// <summary>
    /// PropertyManagersController.
    /// </summary>
    public class PropertyManagersController : BaseController
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="PropertyManagersController"/> class.
        /// </summary>
        /// <param name="config"> config instance. </param>
        /// <param name="httpClient"> httpClient. </param>
        /// <param name="authManagers"> authManager. </param>
        /// <param name="httpCallBack"> httpCallBack. </param>
        internal PropertyManagersController(IConfiguration config, IHttpClient httpClient, IDictionary<string, IAuthManager> authManagers, HttpCallBack httpCallBack = null)
            : base(config, httpClient, authManagers, httpCallBack)
        {
        }

        /// <summary>
        /// This API call will return a list of property managers (PM) that have been created in the BookingPal platform that is associated with your PMS.
        /// In all requests in this API section, you need to use your PMS credentials.
        /// </summary>
        /// <returns>Returns the Models.GetPMsList response from the API call.</returns>
        public Models.GetPMsList PMList()
        {
            Task<Models.GetPMsList> t = this.PMListAsync();
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// This API call will return a list of property managers (PM) that have been created in the BookingPal platform that is associated with your PMS.
        /// In all requests in this API section, you need to use your PMS credentials.
        /// </summary>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.GetPMsList response from the API call.</returns>
        public async Task<Models.GetPMsList> PMListAsync(CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/pmlist");

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
            };

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().Get(queryBuilder.ToString(), headers);

            if (this.HttpCallBack != null)
            {
                this.HttpCallBack.OnBeforeHttpRequestEventHandler(this.GetClientInstance(), httpRequest);
            }

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);
            if (this.HttpCallBack != null)
            {
                this.HttpCallBack.OnAfterHttpResponseEventHandler(this.GetClientInstance(), response);
            }

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.GetPMsList>(response.Body);
        }

        /// <summary>
        /// This API call will allow the PMS to pass all data to BookingPal that is required for registering a new PM (Property Manager). All fields are mandatory - PMS must pass this data in order for a PM account to be created. You need to use PMS credentials for this request.
        /// </summary>
        /// <param name="body">Required parameter: Example: .</param>
        /// <returns>Returns the Models.PropertyManagerDetailsResponse response from the API call.</returns>
        public Models.PropertyManagerDetailsResponse CreateNewPropertyManager(
                Models.CreateNewUpdatePropertyManagerRequest body)
        {
            Task<Models.PropertyManagerDetailsResponse> t = this.CreateNewPropertyManagerAsync(body);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// This API call will allow the PMS to pass all data to BookingPal that is required for registering a new PM (Property Manager). All fields are mandatory - PMS must pass this data in order for a PM account to be created. You need to use PMS credentials for this request.
        /// </summary>
        /// <param name="body">Required parameter: Example: .</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.PropertyManagerDetailsResponse response from the API call.</returns>
        public async Task<Models.PropertyManagerDetailsResponse> CreateNewPropertyManagerAsync(
                Models.CreateNewUpdatePropertyManagerRequest body,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/pm");

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "Content-Type", "application/json" },
            };

            // append body params.
            var bodyText = ApiHelper.JsonSerialize(body);

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().PostBody(queryBuilder.ToString(), headers, bodyText);

            if (this.HttpCallBack != null)
            {
                this.HttpCallBack.OnBeforeHttpRequestEventHandler(this.GetClientInstance(), httpRequest);
            }

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);
            if (this.HttpCallBack != null)
            {
                this.HttpCallBack.OnAfterHttpResponseEventHandler(this.GetClientInstance(), response);
            }

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.PropertyManagerDetailsResponse>(response.Body);
        }

        /// <summary>
        /// This function will return a property manager’s details that belong to the current user. You need to use your PMS API credentials. .
        /// Request Body parameters are the same as for creating PM.
        /// Response is the same as in creating a Property Manager function. Here you do not need to pass all root level fields, but if some are used - all fields inside are mandatory:.
        /// - in CompanyDetails Model you can pass any field, and none of them is mandatory.
        /// - in Policies Model - you can pass any field,  and none of them is mandatory.
        /// - if you do use PaymentPolicy - all fields inside are mandatory.
        /// - if you do use CancellationPolicy - all fields inside are mandatory.
        /// - if you use Payment Model - all fields inside are mandatory.
        /// </summary>
        /// <param name="contentType">Required parameter: Example: .</param>
        /// <param name="id">Required parameter: Property Manager ID.</param>
        /// <returns>Returns the Models.PropertyManagerDetailsResponse response from the API call.</returns>
        public Models.PropertyManagerDetailsResponse GetPropertyManagerDetailData(
                string contentType,
                string id)
        {
            Task<Models.PropertyManagerDetailsResponse> t = this.GetPropertyManagerDetailDataAsync(contentType, id);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// This function will return a property manager’s details that belong to the current user. You need to use your PMS API credentials. .
        /// Request Body parameters are the same as for creating PM.
        /// Response is the same as in creating a Property Manager function. Here you do not need to pass all root level fields, but if some are used - all fields inside are mandatory:.
        /// - in CompanyDetails Model you can pass any field, and none of them is mandatory.
        /// - in Policies Model - you can pass any field,  and none of them is mandatory.
        /// - if you do use PaymentPolicy - all fields inside are mandatory.
        /// - if you do use CancellationPolicy - all fields inside are mandatory.
        /// - if you use Payment Model - all fields inside are mandatory.
        /// </summary>
        /// <param name="contentType">Required parameter: Example: .</param>
        /// <param name="id">Required parameter: Property Manager ID.</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.PropertyManagerDetailsResponse response from the API call.</returns>
        public async Task<Models.PropertyManagerDetailsResponse> GetPropertyManagerDetailDataAsync(
                string contentType,
                string id,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/pm/{id}");

            // process optional template parameters.
            ApiHelper.AppendUrlWithTemplateParameters(queryBuilder, new Dictionary<string, object>()
            {
                { "id", id },
            });

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "Content-Type", contentType },
            };

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().Get(queryBuilder.ToString(), headers);

            if (this.HttpCallBack != null)
            {
                this.HttpCallBack.OnBeforeHttpRequestEventHandler(this.GetClientInstance(), httpRequest);
            }

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);
            if (this.HttpCallBack != null)
            {
                this.HttpCallBack.OnAfterHttpResponseEventHandler(this.GetClientInstance(), response);
            }

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.PropertyManagerDetailsResponse>(response.Body);
        }

        /// <summary>
        /// This function will update a property manager’s details. In case of an update you do not need to pass all information, but if you have values in one section - all fields inside are mandatory.
        /// </summary>
        /// <param name="id">Required parameter: Property Manager ID.</param>
        /// <param name="body">Required parameter: Example: .</param>
        /// <returns>Returns the Models.PropertyManagerDetailsResponse response from the API call.</returns>
        public Models.PropertyManagerDetailsResponse UpdatePropertyManagerDetails(
                string id,
                Models.CreateNewUpdatePropertyManagerRequest body)
        {
            Task<Models.PropertyManagerDetailsResponse> t = this.UpdatePropertyManagerDetailsAsync(id, body);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// This function will update a property manager’s details. In case of an update you do not need to pass all information, but if you have values in one section - all fields inside are mandatory.
        /// </summary>
        /// <param name="id">Required parameter: Property Manager ID.</param>
        /// <param name="body">Required parameter: Example: .</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.PropertyManagerDetailsResponse response from the API call.</returns>
        public async Task<Models.PropertyManagerDetailsResponse> UpdatePropertyManagerDetailsAsync(
                string id,
                Models.CreateNewUpdatePropertyManagerRequest body,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/pm/{id}");

            // process optional template parameters.
            ApiHelper.AppendUrlWithTemplateParameters(queryBuilder, new Dictionary<string, object>()
            {
                { "id", id },
            });

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "Content-Type", "application/json" },
            };

            // append body params.
            var bodyText = ApiHelper.JsonSerialize(body);

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().PutBody(queryBuilder.ToString(), headers, bodyText);

            if (this.HttpCallBack != null)
            {
                this.HttpCallBack.OnBeforeHttpRequestEventHandler(this.GetClientInstance(), httpRequest);
            }

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);
            if (this.HttpCallBack != null)
            {
                this.HttpCallBack.OnAfterHttpResponseEventHandler(this.GetClientInstance(), response);
            }

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.PropertyManagerDetailsResponse>(response.Body);
        }
    }
}