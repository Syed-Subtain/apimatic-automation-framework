// <copyright file="LOSPricingController.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace SupplierAPI.Standard.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Dynamic;
    using System.Globalization;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading;
    using System.Threading.Tasks;
    using Newtonsoft.Json.Converters;
    using SupplierAPI.Standard;
    using SupplierAPI.Standard.Authentication;
    using SupplierAPI.Standard.Http.Client;
    using SupplierAPI.Standard.Http.Request;
    using SupplierAPI.Standard.Http.Request.Configuration;
    using SupplierAPI.Standard.Http.Response;
    using SupplierAPI.Standard.Utilities;

    /// <summary>
    /// LOSPricingController.
    /// </summary>
    public class LOSPricingController : BaseController
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="LOSPricingController"/> class.
        /// </summary>
        /// <param name="config"> config instance. </param>
        /// <param name="httpClient"> httpClient. </param>
        /// <param name="authManagers"> authManager. </param>
        /// <param name="httpCallBack"> httpCallBack. </param>
        internal LOSPricingController(IConfiguration config, IHttpClient httpClient, IDictionary<string, IAuthManager> authManagers, HttpCallBack httpCallBack = null)
            : base(config, httpClient, authManagers, httpCallBack)
        {
        }

        /// <summary>
        /// Introduction: You can use this function if you would like to send BookingPal different prices for various Length of Stays with the same starting date.
        /// LOS Pricing will be a different method in sending rates to BookingPal and is defined as pricing sent for a specific “Stay ranges”, In the LOS  method you are setting specific rates based on the Length of Stay. (This is a different way to push rates to BookingPal. ).
        /// For date periods of 1 to 30 days a specific rate need to enter check-in date and a rate for every possible reservation starting at that date (i.e. 1 day, 2 days, up to 30 days, 30 days is the maximum value allowed for this field) you will need to send BookingPal total rate value for that period. .
        /// Maximum LOS number of days is 30. All other LOS values after 30 will not be saved. If you do not support reservation for some specific number of dates - send value 0.00 for this LOS number of days. Keep in mind that all values not sent for any specific check-in date will be considered as 0, and reservation for this number of days will not be possible.
        /// Field maxGuests allows you to set different rates per different number of guests. If you do not have different rate values per number of guests - you can send the value for maximum number of guests, and all others will have the same rate.
        /// For MLT REP - you should use daily rates. .
        /// It is suggested to manage availability over “rates and availability” API call, and to close/open dates over this call.
        /// Note: this API call can be used only if you set supportedLosRates = true on the product. Otherwise using this API for specific product is not possible.
        /// </summary>
        /// <param name="body">Required parameter: Example: .</param>
        /// <returns>Returns the Models.LOSRatesResponse response from the API call.</returns>
        public Models.LOSRatesResponse CreateAndUpdateLOSLengthOfStayPricing(
                Models.CreateAndUpdateLOSRequest body)
        {
            Task<Models.LOSRatesResponse> t = this.CreateAndUpdateLOSLengthOfStayPricingAsync(body);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// Introduction: You can use this function if you would like to send BookingPal different prices for various Length of Stays with the same starting date.
        /// LOS Pricing will be a different method in sending rates to BookingPal and is defined as pricing sent for a specific “Stay ranges”, In the LOS  method you are setting specific rates based on the Length of Stay. (This is a different way to push rates to BookingPal. ).
        /// For date periods of 1 to 30 days a specific rate need to enter check-in date and a rate for every possible reservation starting at that date (i.e. 1 day, 2 days, up to 30 days, 30 days is the maximum value allowed for this field) you will need to send BookingPal total rate value for that period. .
        /// Maximum LOS number of days is 30. All other LOS values after 30 will not be saved. If you do not support reservation for some specific number of dates - send value 0.00 for this LOS number of days. Keep in mind that all values not sent for any specific check-in date will be considered as 0, and reservation for this number of days will not be possible.
        /// Field maxGuests allows you to set different rates per different number of guests. If you do not have different rate values per number of guests - you can send the value for maximum number of guests, and all others will have the same rate.
        /// For MLT REP - you should use daily rates. .
        /// It is suggested to manage availability over “rates and availability” API call, and to close/open dates over this call.
        /// Note: this API call can be used only if you set supportedLosRates = true on the product. Otherwise using this API for specific product is not possible.
        /// </summary>
        /// <param name="body">Required parameter: Example: .</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.LOSRatesResponse response from the API call.</returns>
        public async Task<Models.LOSRatesResponse> CreateAndUpdateLOSLengthOfStayPricingAsync(
                Models.CreateAndUpdateLOSRequest body,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/losrates");

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "Content-Type", "application/json" },
            };

            // append body params.
            var bodyText = ApiHelper.JsonSerialize(body);

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().PostBody(queryBuilder.ToString(), headers, bodyText);

            if (this.HttpCallBack != null)
            {
                this.HttpCallBack.OnBeforeHttpRequestEventHandler(this.GetClientInstance(), httpRequest);
            }

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);
            if (this.HttpCallBack != null)
            {
                this.HttpCallBack.OnAfterHttpResponseEventHandler(this.GetClientInstance(), response);
            }

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.LOSRatesResponse>(response.Body);
        }

        /// <summary>
        /// This function allows the logged in user to get a LOS rate for property.
        /// </summary>
        /// <param name="productId">Required parameter: Property ID in BookingPal.</param>
        /// <returns>Returns the Models.LOSRatesResponse response from the API call.</returns>
        public Models.LOSRatesResponse GetLosPricesListByProductID(
                string productId)
        {
            Task<Models.LOSRatesResponse> t = this.GetLosPricesListByProductIDAsync(productId);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// This function allows the logged in user to get a LOS rate for property.
        /// </summary>
        /// <param name="productId">Required parameter: Property ID in BookingPal.</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.LOSRatesResponse response from the API call.</returns>
        public async Task<Models.LOSRatesResponse> GetLosPricesListByProductIDAsync(
                string productId,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/losrates/{productId}");

            // process optional template parameters.
            ApiHelper.AppendUrlWithTemplateParameters(queryBuilder, new Dictionary<string, object>()
            {
                { "productId", productId },
            });

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
            };

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().Get(queryBuilder.ToString(), headers);

            if (this.HttpCallBack != null)
            {
                this.HttpCallBack.OnBeforeHttpRequestEventHandler(this.GetClientInstance(), httpRequest);
            }

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);
            if (this.HttpCallBack != null)
            {
                this.HttpCallBack.OnAfterHttpResponseEventHandler(this.GetClientInstance(), response);
            }

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.LOSRatesResponse>(response.Body);
        }
    }
}