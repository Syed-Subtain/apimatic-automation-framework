// <copyright file="YieldsController.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace SupplierAPI.Standard.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Dynamic;
    using System.Globalization;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading;
    using System.Threading.Tasks;
    using Newtonsoft.Json.Converters;
    using SupplierAPI.Standard;
    using SupplierAPI.Standard.Authentication;
    using SupplierAPI.Standard.Http.Client;
    using SupplierAPI.Standard.Http.Request;
    using SupplierAPI.Standard.Http.Request.Configuration;
    using SupplierAPI.Standard.Http.Response;
    using SupplierAPI.Standard.Utilities;

    /// <summary>
    /// YieldsController.
    /// </summary>
    public class YieldsController : BaseController
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="YieldsController"/> class.
        /// </summary>
        /// <param name="config"> config instance. </param>
        /// <param name="httpClient"> httpClient. </param>
        /// <param name="authManagers"> authManager. </param>
        /// <param name="httpCallBack"> httpCallBack. </param>
        internal YieldsController(IConfiguration config, IHttpClient httpClient, IDictionary<string, IAuthManager> authManagers, HttpCallBack httpCallBack = null)
            : base(config, httpClient, authManagers, httpCallBack)
        {
        }

        /// <summary>
        /// This function allows user to post yield by property manager.
        /// </summary>
        /// <param name="propertyManager">Required parameter: Example: .</param>
        /// <param name="body">Required parameter: Example: .</param>
        /// <returns>Returns the Models.APIResponseWithoutData response from the API call.</returns>
        public Models.APIResponseWithoutData PostYieldByPropertyManager(
                string propertyManager,
                Models.ChannelMarkUpYield body)
        {
            Task<Models.APIResponseWithoutData> t = this.PostYieldByPropertyManagerAsync(propertyManager, body);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// This function allows user to post yield by property manager.
        /// </summary>
        /// <param name="propertyManager">Required parameter: Example: .</param>
        /// <param name="body">Required parameter: Example: .</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.APIResponseWithoutData response from the API call.</returns>
        public async Task<Models.APIResponseWithoutData> PostYieldByPropertyManagerAsync(
                string propertyManager,
                Models.ChannelMarkUpYield body,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/yield/{propertyManager}");

            // process optional template parameters.
            ApiHelper.AppendUrlWithTemplateParameters(queryBuilder, new Dictionary<string, object>()
            {
                { "propertyManager", propertyManager },
            });

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "Content-Type", "application/json" },
            };

            // append body params.
            var bodyText = ApiHelper.JsonSerialize(body);

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().PostBody(queryBuilder.ToString(), headers, bodyText);

            if (this.HttpCallBack != null)
            {
                this.HttpCallBack.OnBeforeHttpRequestEventHandler(this.GetClientInstance(), httpRequest);
            }

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);
            if (this.HttpCallBack != null)
            {
                this.HttpCallBack.OnAfterHttpResponseEventHandler(this.GetClientInstance(), response);
            }

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.APIResponseWithoutData>(response.Body);
        }

        /// <summary>
        /// This function allows the logged in user to get yield management rules list per Property Manager.
        /// </summary>
        /// <param name="channelAbbreviation">Required parameter: Channel Abbreviation.</param>
        /// <param name="partyChannelMarkupId">Required parameter: Party Channel Markup Id.</param>
        /// <param name="propertyManager">Required parameter: Example: .</param>
        /// <returns>Returns the Models.APIResponseWithoutData response from the API call.</returns>
        public Models.APIResponseWithoutData DeleteYMRListByPropertyManager(
                string channelAbbreviation,
                string partyChannelMarkupId,
                string propertyManager)
        {
            Task<Models.APIResponseWithoutData> t = this.DeleteYMRListByPropertyManagerAsync(channelAbbreviation, partyChannelMarkupId, propertyManager);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// This function allows the logged in user to get yield management rules list per Property Manager.
        /// </summary>
        /// <param name="channelAbbreviation">Required parameter: Channel Abbreviation.</param>
        /// <param name="partyChannelMarkupId">Required parameter: Party Channel Markup Id.</param>
        /// <param name="propertyManager">Required parameter: Example: .</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.APIResponseWithoutData response from the API call.</returns>
        public async Task<Models.APIResponseWithoutData> DeleteYMRListByPropertyManagerAsync(
                string channelAbbreviation,
                string partyChannelMarkupId,
                string propertyManager,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/yield/{propertyManager}");

            // process optional template parameters.
            ApiHelper.AppendUrlWithTemplateParameters(queryBuilder, new Dictionary<string, object>()
            {
                { "propertyManager", propertyManager },
            });

            // prepare specfied query parameters.
            var queryParams = new Dictionary<string, object>()
            {
                { "channelAbbreviation", channelAbbreviation },
                { "partyChannelMarkupId", partyChannelMarkupId },
            };

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
            };

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().Delete(queryBuilder.ToString(), headers, null, queryParameters: queryParams);

            if (this.HttpCallBack != null)
            {
                this.HttpCallBack.OnBeforeHttpRequestEventHandler(this.GetClientInstance(), httpRequest);
            }

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);
            if (this.HttpCallBack != null)
            {
                this.HttpCallBack.OnAfterHttpResponseEventHandler(this.GetClientInstance(), response);
            }

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.APIResponseWithoutData>(response.Body);
        }

        /// <summary>
        /// This function allows the logged in user to get yield management rules list per Property Manager.
        /// </summary>
        /// <param name="propertyManager">Required parameter: Property Manager ID.</param>
        /// <param name="channelAbbreviation">Optional parameter: Channel Abbreviation ID.</param>
        /// <returns>Returns the Models.YieldResponseByPropertyManager response from the API call.</returns>
        public Models.YieldResponseByPropertyManager GetYMRListByPropertyManager(
                string propertyManager,
                string channelAbbreviation = null)
        {
            Task<Models.YieldResponseByPropertyManager> t = this.GetYMRListByPropertyManagerAsync(propertyManager, channelAbbreviation);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// This function allows the logged in user to get yield management rules list per Property Manager.
        /// </summary>
        /// <param name="propertyManager">Required parameter: Property Manager ID.</param>
        /// <param name="channelAbbreviation">Optional parameter: Channel Abbreviation ID.</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.YieldResponseByPropertyManager response from the API call.</returns>
        public async Task<Models.YieldResponseByPropertyManager> GetYMRListByPropertyManagerAsync(
                string propertyManager,
                string channelAbbreviation = null,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/yield/{propertyManager}");

            // process optional template parameters.
            ApiHelper.AppendUrlWithTemplateParameters(queryBuilder, new Dictionary<string, object>()
            {
                { "propertyManager", propertyManager },
            });

            // prepare specfied query parameters.
            var queryParams = new Dictionary<string, object>()
            {
                { "channelAbbreviation", channelAbbreviation },
            };

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
            };

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().Get(queryBuilder.ToString(), headers, queryParameters: queryParams);

            if (this.HttpCallBack != null)
            {
                this.HttpCallBack.OnBeforeHttpRequestEventHandler(this.GetClientInstance(), httpRequest);
            }

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);
            if (this.HttpCallBack != null)
            {
                this.HttpCallBack.OnAfterHttpResponseEventHandler(this.GetClientInstance(), response);
            }

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.YieldResponseByPropertyManager>(response.Body);
        }

        /// <summary>
        /// This function allows the logged-in user to add yield management rules for the specific product. Yield management rules can affect the final price of the property depending on some special conditions (like the length of stay, early booking, etc.). These rules automate price manipulations, on an inquiry by inquiry basis. When set criteria are met, they help maximize revenue and occupancy.
        /// How is the price calculated?.
        /// The price for a night is calculated based on the basic price and the yield management rules.
        /// - If no YMR:.
        /// {basic price per night} = price per night.
        /// - If YMR is set it can Increase/decrease percent or increase/decrease amount:.
        ///   {basic price per night} + {yield amount} = {price per night}.
        ///   or.
        ///   {basic price per night} - {yield amount} = {price per night}.
        /// The below examples will use the scenario to walk you step by step and explain how the price is calculated based on different YMRs. .
        /// Let’s say that the basic price per night for 2016 is 100 USD.
        /// This function is used also for updating yield. So if you already create a specific yield for some date - and you send a new one - we will update the yield for this date.
        /// If you need to delete a specific yield type - you can send an empty list for that type.
        /// Important: The maximum allowed end date is 3 years in the future.
        /// </summary>
        /// <param name="body">Required parameter: Example: .</param>
        /// <returns>Returns the Models.YieldResponse response from the API call.</returns>
        public Models.YieldResponse CreateYMR(
                Models.CreateYieldRequest body)
        {
            Task<Models.YieldResponse> t = this.CreateYMRAsync(body);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// This function allows the logged-in user to add yield management rules for the specific product. Yield management rules can affect the final price of the property depending on some special conditions (like the length of stay, early booking, etc.). These rules automate price manipulations, on an inquiry by inquiry basis. When set criteria are met, they help maximize revenue and occupancy.
        /// How is the price calculated?.
        /// The price for a night is calculated based on the basic price and the yield management rules.
        /// - If no YMR:.
        /// {basic price per night} = price per night.
        /// - If YMR is set it can Increase/decrease percent or increase/decrease amount:.
        ///   {basic price per night} + {yield amount} = {price per night}.
        ///   or.
        ///   {basic price per night} - {yield amount} = {price per night}.
        /// The below examples will use the scenario to walk you step by step and explain how the price is calculated based on different YMRs. .
        /// Let’s say that the basic price per night for 2016 is 100 USD.
        /// This function is used also for updating yield. So if you already create a specific yield for some date - and you send a new one - we will update the yield for this date.
        /// If you need to delete a specific yield type - you can send an empty list for that type.
        /// Important: The maximum allowed end date is 3 years in the future.
        /// </summary>
        /// <param name="body">Required parameter: Example: .</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.YieldResponse response from the API call.</returns>
        public async Task<Models.YieldResponse> CreateYMRAsync(
                Models.CreateYieldRequest body,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/yield");

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "Content-Type", "application/json" },
            };

            // append body params.
            var bodyText = ApiHelper.JsonSerialize(body);

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().PostBody(queryBuilder.ToString(), headers, bodyText);

            if (this.HttpCallBack != null)
            {
                this.HttpCallBack.OnBeforeHttpRequestEventHandler(this.GetClientInstance(), httpRequest);
            }

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);
            if (this.HttpCallBack != null)
            {
                this.HttpCallBack.OnAfterHttpResponseEventHandler(this.GetClientInstance(), response);
            }

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.YieldResponse>(response.Body);
        }

        /// <summary>
        /// This function allows the logged in user to get yield management rules list of the specific product.
        /// </summary>
        /// <param name="productId">Required parameter: ID of the property.</param>
        /// <returns>Returns the Models.YieldResponse response from the API call.</returns>
        public Models.YieldResponse GetYMRListByProductID(
                string productId)
        {
            Task<Models.YieldResponse> t = this.GetYMRListByProductIDAsync(productId);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// This function allows the logged in user to get yield management rules list of the specific product.
        /// </summary>
        /// <param name="productId">Required parameter: ID of the property.</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.YieldResponse response from the API call.</returns>
        public async Task<Models.YieldResponse> GetYMRListByProductIDAsync(
                string productId,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/yield/{productId}");

            // process optional template parameters.
            ApiHelper.AppendUrlWithTemplateParameters(queryBuilder, new Dictionary<string, object>()
            {
                { "productId", productId },
            });

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
            };

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().Get(queryBuilder.ToString(), headers);

            if (this.HttpCallBack != null)
            {
                this.HttpCallBack.OnBeforeHttpRequestEventHandler(this.GetClientInstance(), httpRequest);
            }

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);
            if (this.HttpCallBack != null)
            {
                this.HttpCallBack.OnAfterHttpResponseEventHandler(this.GetClientInstance(), response);
            }

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.YieldResponse>(response.Body);
        }
    }
}