// <copyright file="SupplierAPIClient.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace SupplierAPI.Standard
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Net;
    using System.Text;
    using SupplierAPI.Standard.Authentication;
    using SupplierAPI.Standard.Controllers;
    using SupplierAPI.Standard.Http.Client;
    using SupplierAPI.Standard.Utilities;

    /// <summary>
    /// The gateway for the SDK. This class acts as a factory for Controller and
    /// holds the configuration of the SDK.
    /// </summary>
    public sealed class SupplierAPIClient : IConfiguration
    {
        // A map of environments and their corresponding servers/baseurls
        private static readonly Dictionary<Environment, Dictionary<Server, string>> EnvironmentsMap =
            new Dictionary<Environment, Dictionary<Server, string>>
        {
            {
                Environment.Production, new Dictionary<Server, string>
                {
                    { Server.Default, "https://apidemo.mybookingpal.com" },
                    { Server.PushServer, "https://www.yourEndpoint.url" },
                }
            },
            {
                Environment.Environment2, new Dictionary<Server, string>
                {
                    { Server.Default, "{pushServerUrl}" },
                    { Server.PushServer, "https://www.yourEndpoint.url" },
                }
            },
        };

        private readonly IDictionary<string, IAuthManager> authManagers;
        private readonly IHttpClient httpClient;
        private readonly HttpCallBack httpCallBack;
        private readonly CustomQueryAuthenticationManager customQueryAuthenticationManager;

        private readonly Lazy<PropertyManagersController> propertyManagers;
        private readonly Lazy<AuthorizationController> authorization;
        private readonly Lazy<ImagesController> images;
        private readonly Lazy<RatesAndAvailabilityController> ratesAndAvailability;
        private readonly Lazy<FeeAndTaxController> feeAndTax;
        private readonly Lazy<FeeAndTaxMandatoryAtThePropertyLevelController> feeAndTaxMandatoryAtThePropertyLevel;
        private readonly Lazy<YieldsController> yields;
        private readonly Lazy<TestingOfMessageAPICallsController> testingOfMessageAPICalls;
        private readonly Lazy<MessagingController> messaging;
        private readonly Lazy<PushNotificationController> pushNotification;
        private readonly Lazy<ReservationNotificationsController> reservationNotifications;
        private readonly Lazy<AsynchronousPushMessagesController> asynchronousPushMessages;
        private readonly Lazy<LicensesController> licenses;
        private readonly Lazy<ProductController> product;
        private readonly Lazy<ValidationController> validation;
        private readonly Lazy<RequestToBookController> requestToBook;
        private readonly Lazy<LOSPricingController> lOSPricing;
        private readonly Lazy<ConfigurationInSupplierAPIController> configurationInSupplierAPI;

        private SupplierAPIClient(
            Environment environment,
            string pushServerUrl,
            string jwt,
            IDictionary<string, IAuthManager> authManagers,
            IHttpClient httpClient,
            HttpCallBack httpCallBack,
            IHttpClientConfiguration httpClientConfiguration)
        {
            this.Environment = environment;
            this.PushServerUrl = pushServerUrl;
            this.httpCallBack = httpCallBack;
            this.httpClient = httpClient;
            this.authManagers = (authManagers == null) ? new Dictionary<string, IAuthManager>() : new Dictionary<string, IAuthManager>(authManagers);
            this.HttpClientConfiguration = httpClientConfiguration;

            this.propertyManagers = new Lazy<PropertyManagersController>(
                () => new PropertyManagersController(this, this.httpClient, this.authManagers, this.httpCallBack));
            this.authorization = new Lazy<AuthorizationController>(
                () => new AuthorizationController(this, this.httpClient, this.authManagers, this.httpCallBack));
            this.images = new Lazy<ImagesController>(
                () => new ImagesController(this, this.httpClient, this.authManagers, this.httpCallBack));
            this.ratesAndAvailability = new Lazy<RatesAndAvailabilityController>(
                () => new RatesAndAvailabilityController(this, this.httpClient, this.authManagers, this.httpCallBack));
            this.feeAndTax = new Lazy<FeeAndTaxController>(
                () => new FeeAndTaxController(this, this.httpClient, this.authManagers, this.httpCallBack));
            this.feeAndTaxMandatoryAtThePropertyLevel = new Lazy<FeeAndTaxMandatoryAtThePropertyLevelController>(
                () => new FeeAndTaxMandatoryAtThePropertyLevelController(this, this.httpClient, this.authManagers, this.httpCallBack));
            this.yields = new Lazy<YieldsController>(
                () => new YieldsController(this, this.httpClient, this.authManagers, this.httpCallBack));
            this.testingOfMessageAPICalls = new Lazy<TestingOfMessageAPICallsController>(
                () => new TestingOfMessageAPICallsController(this, this.httpClient, this.authManagers, this.httpCallBack));
            this.messaging = new Lazy<MessagingController>(
                () => new MessagingController(this, this.httpClient, this.authManagers, this.httpCallBack));
            this.pushNotification = new Lazy<PushNotificationController>(
                () => new PushNotificationController(this, this.httpClient, this.authManagers, this.httpCallBack));
            this.reservationNotifications = new Lazy<ReservationNotificationsController>(
                () => new ReservationNotificationsController(this, this.httpClient, this.authManagers, this.httpCallBack));
            this.asynchronousPushMessages = new Lazy<AsynchronousPushMessagesController>(
                () => new AsynchronousPushMessagesController(this, this.httpClient, this.authManagers, this.httpCallBack));
            this.licenses = new Lazy<LicensesController>(
                () => new LicensesController(this, this.httpClient, this.authManagers, this.httpCallBack));
            this.product = new Lazy<ProductController>(
                () => new ProductController(this, this.httpClient, this.authManagers, this.httpCallBack));
            this.validation = new Lazy<ValidationController>(
                () => new ValidationController(this, this.httpClient, this.authManagers, this.httpCallBack));
            this.requestToBook = new Lazy<RequestToBookController>(
                () => new RequestToBookController(this, this.httpClient, this.authManagers, this.httpCallBack));
            this.lOSPricing = new Lazy<LOSPricingController>(
                () => new LOSPricingController(this, this.httpClient, this.authManagers, this.httpCallBack));
            this.configurationInSupplierAPI = new Lazy<ConfigurationInSupplierAPIController>(
                () => new ConfigurationInSupplierAPIController(this, this.httpClient, this.authManagers, this.httpCallBack));

            if (this.authManagers.ContainsKey("global"))
            {
                this.customQueryAuthenticationManager = (CustomQueryAuthenticationManager)this.authManagers["global"];
            }

            if (!this.authManagers.ContainsKey("global")
                || !this.CustomQueryAuthenticationCredentials.Equals(jwt))
            {
                this.customQueryAuthenticationManager = new CustomQueryAuthenticationManager(jwt);
                this.authManagers["global"] = this.customQueryAuthenticationManager;
            }
        }

        /// <summary>
        /// Gets PropertyManagersController controller.
        /// </summary>
        public PropertyManagersController PropertyManagersController => this.propertyManagers.Value;

        /// <summary>
        /// Gets AuthorizationController controller.
        /// </summary>
        public AuthorizationController AuthorizationController => this.authorization.Value;

        /// <summary>
        /// Gets ImagesController controller.
        /// </summary>
        public ImagesController ImagesController => this.images.Value;

        /// <summary>
        /// Gets RatesAndAvailabilityController controller.
        /// </summary>
        public RatesAndAvailabilityController RatesAndAvailabilityController => this.ratesAndAvailability.Value;

        /// <summary>
        /// Gets FeeAndTaxController controller.
        /// </summary>
        public FeeAndTaxController FeeAndTaxController => this.feeAndTax.Value;

        /// <summary>
        /// Gets FeeAndTaxMandatoryAtThePropertyLevelController controller.
        /// </summary>
        public FeeAndTaxMandatoryAtThePropertyLevelController FeeAndTaxMandatoryAtThePropertyLevelController => this.feeAndTaxMandatoryAtThePropertyLevel.Value;

        /// <summary>
        /// Gets YieldsController controller.
        /// </summary>
        public YieldsController YieldsController => this.yields.Value;

        /// <summary>
        /// Gets TestingOfMessageAPICallsController controller.
        /// </summary>
        public TestingOfMessageAPICallsController TestingOfMessageAPICallsController => this.testingOfMessageAPICalls.Value;

        /// <summary>
        /// Gets MessagingController controller.
        /// </summary>
        public MessagingController MessagingController => this.messaging.Value;

        /// <summary>
        /// Gets PushNotificationController controller.
        /// </summary>
        public PushNotificationController PushNotificationController => this.pushNotification.Value;

        /// <summary>
        /// Gets ReservationNotificationsController controller.
        /// </summary>
        public ReservationNotificationsController ReservationNotificationsController => this.reservationNotifications.Value;

        /// <summary>
        /// Gets AsynchronousPushMessagesController controller.
        /// </summary>
        public AsynchronousPushMessagesController AsynchronousPushMessagesController => this.asynchronousPushMessages.Value;

        /// <summary>
        /// Gets LicensesController controller.
        /// </summary>
        public LicensesController LicensesController => this.licenses.Value;

        /// <summary>
        /// Gets ProductController controller.
        /// </summary>
        public ProductController ProductController => this.product.Value;

        /// <summary>
        /// Gets ValidationController controller.
        /// </summary>
        public ValidationController ValidationController => this.validation.Value;

        /// <summary>
        /// Gets RequestToBookController controller.
        /// </summary>
        public RequestToBookController RequestToBookController => this.requestToBook.Value;

        /// <summary>
        /// Gets LOSPricingController controller.
        /// </summary>
        public LOSPricingController LOSPricingController => this.lOSPricing.Value;

        /// <summary>
        /// Gets ConfigurationInSupplierAPIController controller.
        /// </summary>
        public ConfigurationInSupplierAPIController ConfigurationInSupplierAPIController => this.configurationInSupplierAPI.Value;

        /// <summary>
        /// Gets the configuration of the Http Client associated with this client.
        /// </summary>
        public IHttpClientConfiguration HttpClientConfiguration { get; }

        /// <summary>
        /// Gets Environment.
        /// Current API environment.
        /// </summary>
        public Environment Environment { get; }

        /// <summary>
        /// Gets PushServerUrl.
        /// In some API call BookingPal will send POST request (push message) to the PMS for URL which you provide in API 'Push Notification'. You can test these calls to in this documentation, just you will need to set your URL here on specific API call, on Configure button in the right section of specific API function.
        /// </summary>
        public string PushServerUrl { get; }

        /// <summary>
        /// Gets auth managers.
        /// </summary>
        internal IDictionary<string, IAuthManager> AuthManagers => this.authManagers;

        /// <summary>
        /// Gets http client.
        /// </summary>
        internal IHttpClient HttpClient => this.httpClient;

        /// <summary>
        /// Gets http callback.
        /// </summary>
        internal HttpCallBack HttpCallBack => this.httpCallBack;

        /// <summary>
        /// Gets the credentials to use with CustomQueryAuthentication.
        /// </summary>
        public ICustomQueryAuthenticationCredentials CustomQueryAuthenticationCredentials => this.customQueryAuthenticationManager;

        /// <summary>
        /// Gets the URL for a particular alias in the current environment and appends
        /// it with template parameters.
        /// </summary>
        /// <param name="alias">Default value:DEFAULT.</param>
        /// <returns>Returns the baseurl.</returns>
        public string GetBaseUri(Server alias = Server.Default)
        {
            StringBuilder url = new StringBuilder(EnvironmentsMap[this.Environment][alias]);
            ApiHelper.AppendUrlWithTemplateParameters(url, this.GetBaseUriParameters());

            return url.ToString();
        }

        /// <summary>
        /// Creates an object of the SupplierAPIClient using the values provided for the builder.
        /// </summary>
        /// <returns>Builder.</returns>
        public Builder ToBuilder()
        {
            Builder builder = new Builder()
                .Environment(this.Environment)
                .PushServerUrl(this.PushServerUrl)
                .CustomQueryAuthenticationCredentials(this.customQueryAuthenticationManager.Jwt)
                .HttpCallBack(this.httpCallBack)
                .HttpClient(this.httpClient)
                .AuthManagers(this.authManagers)
                .HttpClientConfig(config => config.Build());

            return builder;
        }

        /// <inheritdoc/>
        public override string ToString()
        {
            return
                $"Environment = {this.Environment}, " +
                $"PushServerUrl = {this.PushServerUrl}, " +
                $"HttpClientConfiguration = {this.HttpClientConfiguration}, ";
        }

        /// <summary>
        /// Creates the client using builder.
        /// </summary>
        /// <returns> SupplierAPIClient.</returns>
        internal static SupplierAPIClient CreateFromEnvironment()
        {
            var builder = new Builder();

            string environment = System.Environment.GetEnvironmentVariable("SUPPLIER_API_STANDARD_ENVIRONMENT");
            string pushServerUrl = System.Environment.GetEnvironmentVariable("SUPPLIER_API_STANDARD_PUSH_SERVER_URL");
            string jwt = System.Environment.GetEnvironmentVariable("SUPPLIER_API_STANDARD_JWT");

            if (environment != null)
            {
                builder.Environment(ApiHelper.JsonDeserialize<Environment>($"\"{environment}\""));
            }

            if (pushServerUrl != null)
            {
                builder.PushServerUrl(pushServerUrl);
            }

            if (jwt != null)
            {
                builder.CustomQueryAuthenticationCredentials(jwt);
            }

            return builder.Build();
        }

        /// <summary>
        /// Makes a list of the BaseURL parameters.
        /// </summary>
        /// <returns>Returns the parameters list.</returns>
        private List<KeyValuePair<string, object>> GetBaseUriParameters()
        {
            List<KeyValuePair<string, object>> kvpList = new List<KeyValuePair<string, object>>()
            {
                new KeyValuePair<string, object>("pushServerUrl", this.PushServerUrl),
            };
            return kvpList;
        }

        /// <summary>
        /// Builder class.
        /// </summary>
        public class Builder
        {
            private Environment environment = SupplierAPI.Standard.Environment.Production;
            private string pushServerUrl = "https://www.yourEndpoint.url";
            private string jwt = "";
            private IDictionary<string, IAuthManager> authManagers = new Dictionary<string, IAuthManager>();
            private HttpClientConfiguration.Builder httpClientConfig = new HttpClientConfiguration.Builder();
            private IHttpClient httpClient;
            private HttpCallBack httpCallBack;

            /// <summary>
            /// Sets credentials for CustomQueryAuthentication.
            /// </summary>
            /// <param name="jwt">Jwt.</param>
            /// <returns>Builder.</returns>
            public Builder CustomQueryAuthenticationCredentials(string jwt)
            {
                this.jwt = jwt ?? throw new ArgumentNullException(nameof(jwt));
                return this;
            }

            /// <summary>
            /// Sets Environment.
            /// </summary>
            /// <param name="environment"> Environment. </param>
            /// <returns> Builder. </returns>
            public Builder Environment(Environment environment)
            {
                this.environment = environment;
                return this;
            }

            /// <summary>
            /// Sets PushServerUrl.
            /// </summary>
            /// <param name="pushServerUrl"> PushServerUrl. </param>
            /// <returns> Builder. </returns>
            public Builder PushServerUrl(string pushServerUrl)
            {
                this.pushServerUrl = pushServerUrl ?? throw new ArgumentNullException(nameof(pushServerUrl));
                return this;
            }

            /// <summary>
            /// Sets HttpClientConfig.
            /// </summary>
            /// <param name="action"> Action. </param>
            /// <returns>Builder.</returns>
            public Builder HttpClientConfig(Action<HttpClientConfiguration.Builder> action)
            {
                if (action is null)
                {
                    throw new ArgumentNullException(nameof(action));
                }

                action(this.httpClientConfig);
                return this;
            }

            /// <summary>
            /// Sets the IHttpClient for the Builder.
            /// </summary>
            /// <param name="httpClient"> http client. </param>
            /// <returns>Builder.</returns>
            internal Builder HttpClient(IHttpClient httpClient)
            {
                this.httpClient = httpClient ?? throw new ArgumentNullException(nameof(httpClient));
                return this;
            }

            /// <summary>
            /// Sets the authentication managers for the Builder.
            /// </summary>
            /// <param name="authManagers"> auth managers. </param>
            /// <returns>Builder.</returns>
            internal Builder AuthManagers(IDictionary<string, IAuthManager> authManagers)
            {
                this.authManagers = authManagers ?? throw new ArgumentNullException(nameof(authManagers));
                return this;
            }

            /// <summary>
            /// Sets the HttpCallBack for the Builder.
            /// </summary>
            /// <param name="httpCallBack"> http callback. </param>
            /// <returns>Builder.</returns>
            internal Builder HttpCallBack(HttpCallBack httpCallBack)
            {
                this.httpCallBack = httpCallBack;
                return this;
            }

            /// <summary>
            /// Creates an object of the SupplierAPIClient using the values provided for the builder.
            /// </summary>
            /// <returns>SupplierAPIClient.</returns>
            public SupplierAPIClient Build()
            {
                this.httpClient = new HttpClientWrapper(this.httpClientConfig.Build());

                return new SupplierAPIClient(
                    this.environment,
                    this.pushServerUrl,
                    this.jwt,
                    this.authManagers,
                    this.httpClient,
                    this.httpCallBack,
                    this.httpClientConfig.Build());
            }
        }
    }
}
