// <copyright file="CustomQueryAuthenticationManager.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace SupplierAPI.Standard.Authentication
{
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using SupplierAPI.Standard.Http.Request;

    /// <summary>
    /// CustomQueryAuthenticationManager.
    /// </summary>
    internal class CustomQueryAuthenticationManager : ICustomQueryAuthenticationCredentials, IAuthManager
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="CustomQueryAuthenticationManager"/> class.
        /// </summary>
        /// <param name="jwt">jwt.</param>
        public CustomQueryAuthenticationManager(string jwt)
        {
            this.Jwt = jwt;
        }

        /// <summary>
        /// Gets jwt.
        /// </summary>
        public string Jwt { get; }

        /// <summary>
        /// Check if credentials match.
        /// </summary>
        /// <param name="jwt"> jwt.</param>
        /// <returns> The boolean value.</returns>
        public bool Equals(string jwt)
        {
            return jwt.Equals(this.Jwt);
        }

        /// <inheritdoc/>
        public HttpRequest Apply(HttpRequest httpRequest)
        {
            httpRequest.AddQueryParameters(new Dictionary<string, object>
            {
                { "jwt", this.Jwt },
            });

            return httpRequest;
        }

        /// <inheritdoc/>
        public Task<HttpRequest> ApplyAsync(HttpRequest httpRequest)
        {
            return Task.FromResult(this.Apply(httpRequest));
        }
    }
}
