// <copyright file="ICustomQueryAuthenticationCredentials.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace SupplierAPI.Standard.Authentication
{
    using System;

    public interface ICustomQueryAuthenticationCredentials
    {
        /// <summary>
        /// Gets jwt.
        /// </summary>
        string Jwt { get; }

        /// <summary>
        ///  Returns true if credentials matched.
        /// </summary>
        bool Equals(string jwt);
    }
}