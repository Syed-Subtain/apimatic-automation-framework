// <copyright file="LOSPricingControllerTest.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace SupplierAPI.Tests
{
    using System;
    using System.Collections.Generic;
    using System.Globalization;
    using System.IO;
    using System.Threading.Tasks;
    using Newtonsoft.Json.Converters;
    using NUnit.Framework;
    using SupplierAPI.Standard;
    using SupplierAPI.Standard.Controllers;
    using SupplierAPI.Standard.Exceptions;
    using SupplierAPI.Standard.Http.Client;
    using SupplierAPI.Standard.Http.Response;
    using SupplierAPI.Standard.Utilities;
    using SupplierAPI.Tests.Helpers;

    /// <summary>
    /// LOSPricingControllerTest.
    /// </summary>
    [TestFixture]
    public class LOSPricingControllerTest : ControllerTestBase
    {
        /// <summary>
        /// Controller instance (for all tests).
        /// </summary>
        private LOSPricingController controller;

        /// <summary>
        /// Setup test class.
        /// </summary>
        [OneTimeSetUp]
        public void SetUpDerived()
        {
            this.controller = this.Client.LOSPricingController;
        }

        /// <summary>
        /// This function allows the logged in user to get a LOS rate for property..
        /// </summary>
        /// <returns>A <see cref="Task"/> representing the asynchronous unit test.</returns>
        [Test]
        public async Task TestTestGetLosPricesListByProductID()
        {
            // Parameters for the API call
            string productId = "1235124634";

            // Perform API call
            Standard.Models.LOSRatesResponse result = null;
            try
            {
                result = await this.controller.GetLosPricesListByProductIDAsync(productId);
            }
            catch (ApiException)
            {
            }

            // Test response code
            Assert.AreEqual(200, this.HttpCallBackHandler.Response.StatusCode, "Status should be 200");

            // Test headers
            Dictionary<string, string> headers = new Dictionary<string, string>();
            headers.Add("Content-Type", null);

            Assert.IsTrue(
                    TestHelper.AreHeadersProperSubsetOf (
                    headers,
                    this.HttpCallBackHandler.Response.Headers),
                    "Headers should match");

            // Test whether the captured response is as we expected
            Assert.IsNotNull(result, "Result should exist");
            Assert.IsTrue(
                    TestHelper.IsJsonObjectProperSubsetOf(
                    "{\"message\":\"\",\"errorMessage\":[],\"is_error\":false,\"code\":\"\",\"data\":\"[{\\\"productId\\\":1235124634,\\\"losRates\\\":[{\\\"checkInDate\\\":\\\"2020-05-21\\\",\\\"currency\\\":\\\"RSD\\\",\\\"maxGuests\\\":4,\\\"losValue\\\":[111,112,123,250,300,350,400,450,500,550,600,650,700,750,800,850,900,950,550,510,570,520,500,510,590,580,560,540,0,0]},{\\\"checkInDate\\\":\\\"2020-06-20\\\",\\\"currency\\\":\\\"RSD\\\",\\\"maxGuests\\\":3,\\\"losValue\\\":[100,150,200,250,300,0,0,450,500,550,600,650,700,750,800,850,900,950,550,510,570,520,500,510,590,121,122,123,0,0]}]}]\"}",
                    TestHelper.ConvertStreamToString(this.HttpCallBackHandler.Response.RawBody),
                    false,
                    true,
                    false),
                    "Response body should have matching keys");
        }
    }
}