// <copyright file="MessagingControllerTest.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace SupplierAPI.Tests
{
    using System;
    using System.Collections.Generic;
    using System.Globalization;
    using System.IO;
    using System.Threading.Tasks;
    using Newtonsoft.Json.Converters;
    using NUnit.Framework;
    using SupplierAPI.Standard;
    using SupplierAPI.Standard.Controllers;
    using SupplierAPI.Standard.Exceptions;
    using SupplierAPI.Standard.Http.Client;
    using SupplierAPI.Standard.Http.Response;
    using SupplierAPI.Standard.Utilities;
    using SupplierAPI.Tests.Helpers;

    /// <summary>
    /// MessagingControllerTest.
    /// </summary>
    [TestFixture]
    public class MessagingControllerTest : ControllerTestBase
    {
        /// <summary>
        /// Controller instance (for all tests).
        /// </summary>
        private MessagingController controller;

        /// <summary>
        /// Setup test class.
        /// </summary>
        [OneTimeSetUp]
        public void SetUpDerived()
        {
            this.controller = this.Client.MessagingController;
        }

        /// <summary>
        /// This function allows the logged in user to get all message threads or message threads with unresponded message from guest for whole PM. You need to use PM credentials. There is also paging as optional values. If you do not pass this value, we will return first page and 10 threads per page. And in heading you will get a link for the next page..
        /// </summary>
        /// <returns>A <see cref="Task"/> representing the asynchronous unit test.</returns>
        [Test]
        public async Task TestTestGetMessageThreads()
        {
            // Parameters for the API call
            int page = 1;
            int limit = 5;
            string threadType = "all";

            // Perform API call
            Standard.Models.GetMessageThreadsResponse result = null;
            try
            {
                result = await this.controller.GetMessageThreadsAsync(page, limit, threadType);
            }
            catch (ApiException)
            {
            }

            // Test response code
            Assert.AreEqual(200, this.HttpCallBackHandler.Response.StatusCode, "Status should be 200");

            // Test headers
            Dictionary<string, string> headers = new Dictionary<string, string>();
            headers.Add("Content-Type", null);

            Assert.IsTrue(
                    TestHelper.AreHeadersProperSubsetOf (
                    headers,
                    this.HttpCallBackHandler.Response.Headers),
                    "Headers should match");

            // Test whether the captured response is as we expected
            Assert.IsNotNull(result, "Result should exist");
            Assert.IsTrue(
                    TestHelper.IsJsonObjectProperSubsetOf(
                    "{\"message\":\"\",\"errorMessage\":[],\"is_error\":false,\"code\":\"\",\"data\":[{\"threads\":[{\"id\":68241,\"lastMessageSentAt\":\"2019-12-03 00:00:00\",\"lastMessageText\":\"Message KHSroelMoR\",\"channelName\":\"AirBnB\",\"channelABB\":\"ABB\",\"guestName\":\"Test Guest Name 2 \",\"guestEmailAddress\":\"autoeelcbl@atxjarv.uri\",\"productId\":1235124634,\"reservationId\":119557886,\"dateFrom\":\"2019-12-02\",\"dateTo\":\"2019-12-04\"},{\"id\":68257,\"lastMessageSentAt\":\"2019-12-03 00:00:00\",\"lastMessageText\":\"Message ytgdVvQpQm\",\"channelThreadId\":\"33157740\",\"channelName\":\"AirBnB\",\"channelABB\":\"ABB\",\"guestName\":\"Test Guest Name 1\",\"guestEmailAddress\":\"autoppresf@at81.sla\",\"productId\":1235124634,\"dateFrom\":\"2019-12-02\",\"dateTo\":\"2019-12-04\"}]}]}",
                    TestHelper.ConvertStreamToString(this.HttpCallBackHandler.Response.RawBody),
                    false,
                    true,
                    false),
                    "Response body should have matching keys");
        }

        /// <summary>
        /// This function will allow PM to post new messages in already existing threads..
        /// </summary>
        /// <returns>A <see cref="Task"/> representing the asynchronous unit test.</returns>
        [Test]
        public async Task TestTestPostNewMessageForSpecificThread()
        {
            // Parameters for the API call
            Standard.Models.PostNewMessageForSpecificThreadRequest body = ApiHelper.JsonDeserialize<Standard.Models.PostNewMessageForSpecificThreadRequest>("{\"data\":{\"threadId\":5656,\"message\":\"New message\"}}");

            // Perform API call
            Standard.Models.APIResponseWithoutData result = null;
            try
            {
                result = await this.controller.PostNewMessageForSpecificThreadAsync(body);
            }
            catch (ApiException)
            {
            }

            // Test response code
            Assert.AreEqual(200, this.HttpCallBackHandler.Response.StatusCode, "Status should be 200");

            // Test headers
            Dictionary<string, string> headers = new Dictionary<string, string>();
            headers.Add("Content-Type", null);

            Assert.IsTrue(
                    TestHelper.AreHeadersProperSubsetOf (
                    headers,
                    this.HttpCallBackHandler.Response.Headers),
                    "Headers should match");

            // Test whether the captured response is as we expected
            Assert.IsNotNull(result, "Result should exist");
            Assert.IsTrue(
                    TestHelper.IsJsonObjectProperSubsetOf(
                    "{\"message\":\"Your request was received and put in queue\",\"errorMessage\":[],\"is_error\":false,\"code\":\"\"}",
                    TestHelper.ConvertStreamToString(this.HttpCallBackHandler.Response.RawBody),
                    false,
                    true,
                    false),
                    "Response body should have matching keys");
        }

        /// <summary>
        /// This function allows the logged in user to get a list of all messages from passed thread Id. You need to use PM credentials.
        ///
        ///.
        /// </summary>
        /// <returns>A <see cref="Task"/> representing the asynchronous unit test.</returns>
        [Test]
        public async Task TestTestGetMessageListForSpecificThread()
        {
            // Parameters for the API call
            string threadId = "123";

            // Perform API call
            Standard.Models.GetMessageListForSpecificThreadResponse result = null;
            try
            {
                result = await this.controller.GetMessageListForSpecificThreadAsync(threadId);
            }
            catch (ApiException)
            {
            }

            // Test response code
            Assert.AreEqual(200, this.HttpCallBackHandler.Response.StatusCode, "Status should be 200");

            // Test headers
            Dictionary<string, string> headers = new Dictionary<string, string>();
            headers.Add("Content-Type", null);

            Assert.IsTrue(
                    TestHelper.AreHeadersProperSubsetOf (
                    headers,
                    this.HttpCallBackHandler.Response.Headers),
                    "Headers should match");

            // Test whether the captured response is as we expected
            Assert.IsNotNull(result, "Result should exist");
            Assert.IsTrue(
                    TestHelper.IsJsonObjectProperSubsetOf(
                    "{\"message\":\"\",\"errorMessage\":[],\"code\":\"\",\"data\":[{\"messages\":[{\"id\":68233,\"message\":\"Message pmuNXJFzWQ\",\"createdAt\":\"2019-12-03 12:31:47\",\"user\":\"GUEST\",\"channelMessageId\":\"2221139318748986368\"},{\"id\":68234,\"message\":\"i would like to know soon so i can know whether to get another bnb or hotel\",\"createdAt\":\"2019-10-21 16:49:30\",\"user\":\"GUEST\",\"channelMessageId\":\"2221139318748986369\"},{\"id\":68235,\"message\":\"??\",\"createdAt\":\"2019-10-21 16:49:31\",\"user\":\"GUEST\",\"channelMessageId\":\"2221139318748986370\"},{\"id\":68236,\"message\":\"Hello, How does the chalet work? Will we be staying with other people? I see there are 5 apartments. So someone will be living above us below us? Thank you. \",\"createdAt\":\"2019-10-21 16:49:31\",\"user\":\"GUEST\",\"channelMessageId\":\"2221139318748986371\"}]}],\"is_error\":false}",
                    TestHelper.ConvertStreamToString(this.HttpCallBackHandler.Response.RawBody),
                    false,
                    true,
                    false),
                    "Response body should have matching keys");
        }
    }
}