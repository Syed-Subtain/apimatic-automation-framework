// <copyright file="PropertyManagersControllerTest.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace SupplierAPI.Tests
{
    using System;
    using System.Collections.Generic;
    using System.Globalization;
    using System.IO;
    using System.Threading.Tasks;
    using Newtonsoft.Json.Converters;
    using NUnit.Framework;
    using SupplierAPI.Standard;
    using SupplierAPI.Standard.Controllers;
    using SupplierAPI.Standard.Exceptions;
    using SupplierAPI.Standard.Http.Client;
    using SupplierAPI.Standard.Http.Response;
    using SupplierAPI.Standard.Utilities;
    using SupplierAPI.Tests.Helpers;

    /// <summary>
    /// PropertyManagersControllerTest.
    /// </summary>
    [TestFixture]
    public class PropertyManagersControllerTest : ControllerTestBase
    {
        /// <summary>
        /// Controller instance (for all tests).
        /// </summary>
        private PropertyManagersController controller;

        /// <summary>
        /// Setup test class.
        /// </summary>
        [OneTimeSetUp]
        public void SetUpDerived()
        {
            this.controller = this.Client.PropertyManagersController;
        }

        /// <summary>
        /// This API call will allow the PMS to pass all data to BookingPal that is required for registering a new PM (Property Manager). All fields are mandatory - PMS must pass this data in order for a PM account to be created. You need to use PMS credentials for this request..
        /// </summary>
        /// <returns>A <see cref="Task"/> representing the asynchronous unit test.</returns>
        [Test]
        public async Task TestTestCreateNewPropertyManager()
        {
            // Parameters for the API call
            Standard.Models.CreateNewUpdatePropertyManagerRequest body = ApiHelper.JsonDeserialize<Standard.Models.CreateNewUpdatePropertyManagerRequest>("{\"data\":{\"isCompany\":true,\"companyDetails\":{\"accountId\":\"132\",\"companyName\":\"Test PM\",\"language\":\"en\",\"fullName\":\"Test PM\",\"companyAddress\":{\"country\":\"US\",\"state\":\"Test State\",\"streetAddress\":\"Test Street\",\"city\":\"Test City\",\"zip\":\"13245\"},\"website\":\"www.testsite.com\",\"email\":\"apimaticPMemail@test.com\",\"phone\":{\"countryCode\":\"+321\",\"number\":\"132456\"},\"password\":\"password\",\"currency\":\"USD\"},\"policies\":{\"paymentPolicy\":{\"type\":\"SPLIT\",\"splitPayment\":{\"depositType\":\"FLAT\",\"value\":4,\"secondPaymentDays\":30}},\"cancellationPolicy\":{\"type\":\"MANUAL\",\"manualPolicy\":{\"type\":\"FLAT\",\"manualPolicies\":[{\"chargeValue\":20,\"beforeDays\":34,\"cancellationFee\":1},{\"chargeValue\":12,\"beforeDays\":45,\"cancellationFee\":2}]}},\"feeTaxMandatory\":{\"isFeeMandatory\":true,\"isTaxMandatory\":true},\"terms\":\"www.test.com\",\"checkInTime\":\"10:00:00\",\"checkOutTime\":\"16:00:00\",\"leadTime\":2},\"payment\":{\"paymentType\":\"MAIL_CHECK\",\"creditCard\":{\"creditCardType\":\"POST\",\"paymentGateways\":{\"paymentGatewaysType\":\"AUTHORIZE_NET\",\"user\":\"test\",\"secret\":\"test\",\"additionalField1\":\"\",\"additionalField2\":\"\"},\"creditCardList\":[\"AMERICAN_EXPRESS\",\"DINERS_CLUB\"]}},\"ownerInfo\":{\"language\":\"EN\",\"value\":\"ownerInfo on EN\"},\"neighborhoodOverview\":{\"language\":\"EN\",\"value\":\"neighborhoodOverview on EN\"}}}");

            // Perform API call
            Standard.Models.PropertyManagerDetailsResponse result = null;
            try
            {
                result = await this.controller.CreateNewPropertyManagerAsync(body);
            }
            catch (ApiException)
            {
            }

            // Test response code
            Assert.AreEqual(200, this.HttpCallBackHandler.Response.StatusCode, "Status should be 200");

            // Test headers
            Dictionary<string, string> headers = new Dictionary<string, string>();
            headers.Add("Content-Type", null);

            Assert.IsTrue(
                    TestHelper.AreHeadersProperSubsetOf (
                    headers,
                    this.HttpCallBackHandler.Response.Headers),
                    "Headers should match");

            // Test whether the captured response is as we expected
            Assert.IsNotNull(result, "Result should exist");
            Assert.IsTrue(
                    TestHelper.IsJsonObjectProperSubsetOf(
                    "{\"message\":\"\",\"errorMessage\":[],\"is_error\":false,\"code\":\"\",\"data\":[{\"companyDetails\":{\"accountId\":\"132\",\"companyName\":\"Test PM\",\"language\":\"en\",\"fullName\":\"Test PM\",\"companyAddress\":{\"country\":\"US\",\"state\":\"Test State\",\"streetAddress\":\"Test Street\",\"city\":\"Test City\",\"zip\":\"13245\"},\"website\":\"www.testsite.com\",\"email\":\"apimaticPMemail@test.com\",\"phone\":{\"countryCode\":\"+321\",\"number\":\"132456\"},\"password\":\"password\",\"currency\":\"USD\"},\"policies\":{\"paymentPolicy\":{\"type\":\"SPLIT\",\"splitPayment\":{\"depositType\":\"FLAT\",\"value\":4,\"secondPaymentDays\":30}},\"cancellationPolicy\":{\"type\":\"MANUAL\",\"manualPolicy\":{\"type\":\"FLAT\",\"manualPolicies\":[{\"chargeValue\":20,\"beforeDays\":34,\"cancellationFee\":1},{\"chargeValue\":12,\"beforeDays\":45,\"cancellationFee\":2}]}},\"feeTaxMandatory\":{\"isFeeMandatory\":true,\"isTaxMandatory\":true},\"terms\":\"www.test.com\",\"checkInTime\":\"10:00:00\",\"checkOutTime\":\"16:00:00\",\"leadTime\":2},\"payment\":{\"paymentType\":\"MAIL_CHECK\",\"creditCard\":{\"creditCardType\":\"POST\",\"creditCardList\":[\"AMERICAN_EXPRESS\",\"DINERS_CLUB\",\"DISCOVER\",\"MASTER_CARD\",\"VISA\"],\"paymentGateways\":{\"paymentGatewaysType\":\"AUTHORIZE_NET\"}}},\"id\":61692801,\"isCompany\":true,\"ownerInfo\":{\"language\":\"EN\",\"value\":\"ownerInfo on EN\"},\"neighborhoodOverview\":{\"language\":\"EN\",\"value\":\"neighborhoodOverview on EN\"}}]}",
                    TestHelper.ConvertStreamToString(this.HttpCallBackHandler.Response.RawBody),
                    false,
                    true,
                    false),
                    "Response body should have matching keys");
        }

        /// <summary>
        /// This function will return a property manager’s details that belong to the current user. You need to use your PMS API credentials. 
        ///
        ///Request Body parameters are the same as for creating PM.
        ///
        ///Response is the same as in creating a Property Manager function. Here you do not need to pass all root level fields, but if some are used - all fields inside are mandatory:
        ///- in CompanyDetails Model you can pass any field, and none of them is mandatory
        ///- in Policies Model - you can pass any field,  and none of them is mandatory
        ///- if you do use PaymentPolicy - all fields inside are mandatory
        ///- if you do use CancellationPolicy - all fields inside are mandatory
        ///- if you use Payment Model - all fields inside are mandatory.
        /// </summary>
        /// <returns>A <see cref="Task"/> representing the asynchronous unit test.</returns>
        [Test]
        public async Task TestTestGetPropertyManagerDetailData()
        {
            // Parameters for the API call
            string contentType = "application/json";
            string id = "61692799";

            // Perform API call
            Standard.Models.PropertyManagerDetailsResponse result = null;
            try
            {
                result = await this.controller.GetPropertyManagerDetailDataAsync(contentType, id);
            }
            catch (ApiException)
            {
            }

            // Test response code
            Assert.AreEqual(200, this.HttpCallBackHandler.Response.StatusCode, "Status should be 200");

            // Test headers
            Dictionary<string, string> headers = new Dictionary<string, string>();
            headers.Add("Content-Type", null);

            Assert.IsTrue(
                    TestHelper.AreHeadersProperSubsetOf (
                    headers,
                    this.HttpCallBackHandler.Response.Headers),
                    "Headers should match");

            // Test whether the captured response is as we expected
            Assert.IsNotNull(result, "Result should exist");
            Assert.IsTrue(
                    TestHelper.IsJsonObjectProperSubsetOf(
                    "{\"message\":\"\",\"errorMessage\":[],\"is_error\":false,\"code\":\"\",\"data\":[{\"isCompany\":false,\"companyDetails\":{\"accountId\":\"132\",\"companyName\":\"Test PM\",\"language\":\"en\",\"fullName\":\"Test PM\",\"companyAddress\":{\"country\":\"US\",\"state\":\"Test State\",\"streetAddress\":\"Test Street\",\"city\":\"Test City\",\"zip\":\"13245\"},\"website\":\"www.testsite.com\",\"email\":\"apimaticTest@test.com\",\"phone\":{\"countryCode\":\"+321\",\"number\":\"132456\"},\"currency\":\"USD\"},\"policies\":{\"paymentPolicy\":{\"type\":\"SPLIT\",\"splitPayment\":{\"depositType\":\"FLAT\",\"value\":4,\"secondPaymentDays\":30}},\"cancellationPolicy\":{\"type\":\"MANUAL\",\"manualPolicy\":{\"type\":\"FLAT\",\"manualPolicies\":[{\"chargeValue\":20,\"beforeDays\":34,\"cancellationFee\":1},{\"chargeValue\":12,\"beforeDays\":45,\"cancellationFee\":2}]}},\"feeTaxMandatory\":{\"isFeeMandatory\":true,\"isTaxMandatory\":true},\"terms\":\"www.test.com\",\"checkInTime\":\"10:00:00\",\"checkOutTime\":\"16:00:00\",\"leadTime\":2},\"payment\":{\"paymentType\":\"MAIL_CHECK\",\"creditCard\":{\"creditCardType\":\"POST\",\"creditCardList\":[\"AMERICAN_EXPRESS\",\"DINERS_CLUB\",\"DISCOVER\",\"MASTER_CARD\",\"VISA\"],\"paymentGateways\":{\"paymentGatewaysType\":\"AUTHORIZE_NET\"}}},\"id\":61692799,\"ownerInfo\":{\"language\":\"EN\",\"value\":\"ownerInfo on EN\"},\"neighborhoodOverview\":{\"language\":\"EN\",\"value\":\"neighborhoodOverview on EN\"}}]}",
                    TestHelper.ConvertStreamToString(this.HttpCallBackHandler.Response.RawBody),
                    false,
                    true,
                    false),
                    "Response body should have matching keys");
        }
    }
}