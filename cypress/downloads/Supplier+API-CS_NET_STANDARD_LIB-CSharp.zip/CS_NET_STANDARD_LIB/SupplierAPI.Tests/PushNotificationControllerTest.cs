// <copyright file="PushNotificationControllerTest.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace SupplierAPI.Tests
{
    using System;
    using System.Collections.Generic;
    using System.Globalization;
    using System.IO;
    using System.Threading.Tasks;
    using Newtonsoft.Json.Converters;
    using NUnit.Framework;
    using SupplierAPI.Standard;
    using SupplierAPI.Standard.Controllers;
    using SupplierAPI.Standard.Exceptions;
    using SupplierAPI.Standard.Http.Client;
    using SupplierAPI.Standard.Http.Response;
    using SupplierAPI.Standard.Utilities;
    using SupplierAPI.Tests.Helpers;

    /// <summary>
    /// PushNotificationControllerTest.
    /// </summary>
    [TestFixture]
    public class PushNotificationControllerTest : ControllerTestBase
    {
        /// <summary>
        /// Controller instance (for all tests).
        /// </summary>
        private PushNotificationController controller;

        /// <summary>
        /// Setup test class.
        /// </summary>
        [OneTimeSetUp]
        public void SetUpDerived()
        {
            this.controller = this.Client.PushNotificationController;
        }

        /// <summary>
        /// Provide the links on which the requests about reservation notification will be sent. Links should be https.
        ///These links should be set on PMS level, so please use your PMS credentials. 
        ///
        ///IMPORTANT: If you set 'reservationLink' value - all reservation push notifications will go on this endpoint (so any new reservation, cancel reservation, update reservation, request to book, request to book cancel). And before you do this - you should implement a new push reservation API call 'General Reservation Notification - PUSH' - since you will get then all reservation notifications over this method..
        /// </summary>
        /// <returns>A <see cref="Task"/> representing the asynchronous unit test.</returns>
        [Test]
        public async Task TestTestPushNotificationLinks()
        {
            // Parameters for the API call
            Standard.Models.PushNotificationLinksRequest body = ApiHelper.JsonDeserialize<Standard.Models.PushNotificationLinksRequest>("{\"data\":{\"bookLink\":\"https://newreservationnotification.link\",\"cancelLink\":\"https://cancelreservation.link\",\"asyncPush\":\"https://asyncpush.link\",\"requestToBook\":\"https://requestToBook.link\",\"reservationLink\":\"https://reservation.link\"}}");

            // Perform API call
            Standard.Models.PushNotificationLinksResponse result = null;
            try
            {
                result = await this.controller.PushNotificationLinksAsync(body);
            }
            catch (ApiException)
            {
            }

            // Test response code
            Assert.AreEqual(200, this.HttpCallBackHandler.Response.StatusCode, "Status should be 200");

            // Test headers
            Dictionary<string, string> headers = new Dictionary<string, string>();
            headers.Add("Content-Type", null);

            Assert.IsTrue(
                    TestHelper.AreHeadersProperSubsetOf (
                    headers,
                    this.HttpCallBackHandler.Response.Headers),
                    "Headers should match");

            // Test whether the captured response is as we expected
            Assert.IsNotNull(result, "Result should exist");
            Assert.IsTrue(
                    TestHelper.IsJsonObjectProperSubsetOf(
                    "{\"message\":\"\",\"errorMessage\":[],\"is_error\":false,\"code\":\"\",\"data\":[{\"bookLink\":\"https://newreservationnotification.link\",\"cancelLink\":\"https://cancelreservation.link\",\"asyncPush\":\"https://asyncpush.link\",\"requestToBook\":\"https://requestToBook.link\"}]}",
                    TestHelper.ConvertStreamToString(this.HttpCallBackHandler.Response.RawBody),
                    false,
                    true,
                    false),
                    "Response body should have matching keys");
        }

        /// <summary>
        /// This will return all notification URLs which are set. It will work on PMS level, so use PMS credentials.
        ///
        ///.
        /// </summary>
        /// <returns>A <see cref="Task"/> representing the asynchronous unit test.</returns>
        [Test]
        public async Task TestTestGetNotificationLinks()
        {
            // Perform API call
            Standard.Models.PushNotificationLinksResponse result = null;
            try
            {
                result = await this.controller.GetNotificationLinksAsync();
            }
            catch (ApiException)
            {
            }

            // Test response code
            Assert.AreEqual(200, this.HttpCallBackHandler.Response.StatusCode, "Status should be 200");

            // Test headers
            Dictionary<string, string> headers = new Dictionary<string, string>();
            headers.Add("Content-Type", null);

            Assert.IsTrue(
                    TestHelper.AreHeadersProperSubsetOf (
                    headers,
                    this.HttpCallBackHandler.Response.Headers),
                    "Headers should match");

            // Test whether the captured response is as we expected
            Assert.IsNotNull(result, "Result should exist");
            Assert.IsTrue(
                    TestHelper.IsJsonObjectProperSubsetOf(
                    "{\"message\":\"\",\"errorMessage\":[],\"is_error\":false,\"code\":\"\",\"data\":[{\"bookLink\":\"https://newreservationnotification.link\",\"cancelLink\":\"https://cancelreservation.link\",\"asyncPush\":\"https://asyncpush.link\",\"requestToBook\":\"https://requestToBook.link\",\"reservationLink\":\"https://reservation.link\"}]}",
                    TestHelper.ConvertStreamToString(this.HttpCallBackHandler.Response.RawBody),
                    false,
                    true,
                    false),
                    "Response body should have matching keys");
        }
    }
}