// <copyright file="AuthorizationControllerTest.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace SupplierAPI.Tests
{
    using System;
    using System.Collections.Generic;
    using System.Globalization;
    using System.IO;
    using System.Threading.Tasks;
    using Newtonsoft.Json.Converters;
    using NUnit.Framework;
    using SupplierAPI.Standard;
    using SupplierAPI.Standard.Controllers;
    using SupplierAPI.Standard.Exceptions;
    using SupplierAPI.Standard.Http.Client;
    using SupplierAPI.Standard.Http.Response;
    using SupplierAPI.Standard.Utilities;
    using SupplierAPI.Tests.Helpers;

    /// <summary>
    /// AuthorizationControllerTest.
    /// </summary>
    [TestFixture]
    public class AuthorizationControllerTest : ControllerTestBase
    {
        /// <summary>
        /// Controller instance (for all tests).
        /// </summary>
        private AuthorizationController controller;

        /// <summary>
        /// Setup test class.
        /// </summary>
        [OneTimeSetUp]
        public void SetUpDerived()
        {
            this.controller = this.Client.AuthorizationController;
        }

        /// <summary>
        /// In order to begin utilizing the platform APIs, your application must be authenticated and authorized to access domain resources. Follow the URL with your credentials and obtain an authorization token which is used in every request.
        ///You will have 2 types of tokens. One is on the PMS level, and this one should be used when you send requests related to PMS/PM data. For managing properties, you will need a token on PM level, with PM credentials. For every API call it will be noted which API credentials you should use..
        /// </summary>
        /// <returns>A <see cref="Task"/> representing the asynchronous unit test.</returns>
        [Test]
        public async Task TestTestLogin()
        {
            // Parameters for the API call
            string username = "apimaticTest@test.com";
            string password = "password";

            // Perform API call
            Standard.Models.Authorization result = null;
            try
            {
                result = await this.controller.LoginAsync(username, password);
            }
            catch (ApiException)
            {
            }

            // Test response code
            Assert.AreEqual(200, this.HttpCallBackHandler.Response.StatusCode, "Status should be 200");

            // Test headers
            Dictionary<string, string> headers = new Dictionary<string, string>();
            headers.Add("Content-Type", null);

            Assert.IsTrue(
                    TestHelper.AreHeadersProperSubsetOf (
                    headers,
                    this.HttpCallBackHandler.Response.Headers),
                    "Headers should match");

            // Test whether the captured response is as we expected
            Assert.IsNotNull(result, "Result should exist");
            Assert.IsTrue(
                    TestHelper.IsJsonObjectProperSubsetOf(
                    "{\"message\":\"\",\"errorMessage\":[],\"is_error\":false,\"code\":\"\",\"token\":\"a9eaf5b0-c433-450e-991d-8011fc4aa264\",\"partyId\":61692799,\"organizationId\":61690131,\"name\":\"Update Name\",\"currency\":\"USD\",\"supplierId\":61692799}",
                    TestHelper.ConvertStreamToString(this.HttpCallBackHandler.Response.RawBody),
                    false,
                    true,
                    false),
                    "Response body should have matching keys");
        }
    }
}