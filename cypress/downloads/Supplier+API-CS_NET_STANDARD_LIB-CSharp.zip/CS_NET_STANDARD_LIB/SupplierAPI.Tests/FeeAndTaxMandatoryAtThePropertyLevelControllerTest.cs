// <copyright file="FeeAndTaxMandatoryAtThePropertyLevelControllerTest.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace SupplierAPI.Tests
{
    using System;
    using System.Collections.Generic;
    using System.Globalization;
    using System.IO;
    using System.Threading.Tasks;
    using Newtonsoft.Json.Converters;
    using NUnit.Framework;
    using SupplierAPI.Standard;
    using SupplierAPI.Standard.Controllers;
    using SupplierAPI.Standard.Exceptions;
    using SupplierAPI.Standard.Http.Client;
    using SupplierAPI.Standard.Http.Response;
    using SupplierAPI.Standard.Utilities;
    using SupplierAPI.Tests.Helpers;

    /// <summary>
    /// FeeAndTaxMandatoryAtThePropertyLevelControllerTest.
    /// </summary>
    [TestFixture]
    public class FeeAndTaxMandatoryAtThePropertyLevelControllerTest : ControllerTestBase
    {
        /// <summary>
        /// Controller instance (for all tests).
        /// </summary>
        private FeeAndTaxMandatoryAtThePropertyLevelController controller;

        /// <summary>
        /// Setup test class.
        /// </summary>
        [OneTimeSetUp]
        public void SetUpDerived()
        {
            this.controller = this.Client.FeeAndTaxMandatoryAtThePropertyLevelController;
        }

        /// <summary>
        /// This function allows the logged in user to import or update a fee and tax mandatory..
        /// </summary>
        /// <returns>A <see cref="Task"/> representing the asynchronous unit test.</returns>
        [Test]
        public async Task TestTestImportOrUpdateFeeAndTaxMandatory()
        {
            // Parameters for the API call
            Standard.Models.SetFeeAndTaxValidationSettingRequest body = ApiHelper.JsonDeserialize<Standard.Models.SetFeeAndTaxValidationSettingRequest>("{\"data\":{\"validationSettings\":[{\"productId\":1235124634,\"isFeeMandatory\":false,\"isTaxMandatory\":false}]}}");

            // Perform API call
            Standard.Models.APIResponseWithoutData result = null;
            try
            {
                result = await this.controller.ImportOrUpdateFeeAndTaxMandatoryAsync(body);
            }
            catch (ApiException)
            {
            }

            // Test response code
            Assert.AreEqual(200, this.HttpCallBackHandler.Response.StatusCode, "Status should be 200");

            // Test headers
            Dictionary<string, string> headers = new Dictionary<string, string>();
            headers.Add("Content-Type", null);

            Assert.IsTrue(
                    TestHelper.AreHeadersProperSubsetOf (
                    headers,
                    this.HttpCallBackHandler.Response.Headers),
                    "Headers should match");

            // Test whether the captured response is as we expected
            Assert.IsNotNull(result, "Result should exist");
            Assert.IsTrue(
                    TestHelper.IsJsonObjectProperSubsetOf(
                    "{\"message\":\"For product ids [1235124634] the validation settings are imported!\",\"errorMessage\":[],\"is_error\":false,\"code\":\"\"}",
                    TestHelper.ConvertStreamToString(this.HttpCallBackHandler.Response.RawBody),
                    false,
                    true,
                    false),
                    "Response body should have matching keys");
        }

        /// <summary>
        /// This function allows the logged in user to get info about current set for all PM properties are fees/taxes set to be mandatory or not.
        ///
        ///.
        /// </summary>
        /// <returns>A <see cref="Task"/> representing the asynchronous unit test.</returns>
        [Test]
        public async Task TestTestGetFeeAndTaxMandatory()
        {
            // Perform API call
            Standard.Models.FeeTaxValidationSettingResponse result = null;
            try
            {
                result = await this.controller.GetFeeAndTaxMandatoryAsync();
            }
            catch (ApiException)
            {
            }

            // Test response code
            Assert.AreEqual(200, this.HttpCallBackHandler.Response.StatusCode, "Status should be 200");

            // Test headers
            Dictionary<string, string> headers = new Dictionary<string, string>();
            headers.Add("Content-Type", null);

            Assert.IsTrue(
                    TestHelper.AreHeadersProperSubsetOf (
                    headers,
                    this.HttpCallBackHandler.Response.Headers),
                    "Headers should match");

            // Test whether the captured response is as we expected
            Assert.IsNotNull(result, "Result should exist");
            Assert.IsTrue(
                    TestHelper.IsJsonObjectProperSubsetOf(
                    "{\"message\":\"\",\"errorMessage\":[],\"is_error\":false,\"code\":\"\",\"data\":[{\"validationSettings\":[{\"productId\":1235124634,\"isFeeMandatory\":false,\"isTaxMandatory\":false},{\"productId\":1235124636,\"isFeeMandatory\":true,\"isTaxMandatory\":true},{\"productId\":1235124637,\"isFeeMandatory\":true,\"isTaxMandatory\":true}]}]}",
                    TestHelper.ConvertStreamToString(this.HttpCallBackHandler.Response.RawBody),
                    false,
                    true,
                    false),
                    "Response body should have matching keys");
        }

        /// <summary>
        /// This function allows the logged in user to remove any setup on property level and to return on default (which is that fee/taxes are mandatory). This API call will accept a list of properties.
        ///
        ///.
        /// </summary>
        /// <returns>A <see cref="Task"/> representing the asynchronous unit test.</returns>
        [Test]
        public async Task TestTestRemoveValidationSettings()
        {
            // Parameters for the API call
            Standard.Models.PropertyListRequest body = ApiHelper.JsonDeserialize<Standard.Models.PropertyListRequest>("{\"data\":[1235124634]}");

            // Perform API call
            Standard.Models.APIResponseWithoutData result = null;
            try
            {
                result = await this.controller.RemoveValidationSettingsAsync(body);
            }
            catch (ApiException)
            {
            }

            // Test response code
            Assert.AreEqual(200, this.HttpCallBackHandler.Response.StatusCode, "Status should be 200");

            // Test headers
            Dictionary<string, string> headers = new Dictionary<string, string>();
            headers.Add("Content-Type", null);

            Assert.IsTrue(
                    TestHelper.AreHeadersProperSubsetOf (
                    headers,
                    this.HttpCallBackHandler.Response.Headers),
                    "Headers should match");

            // Test whether the captured response is as we expected
            Assert.IsNotNull(result, "Result should exist");
            Assert.IsTrue(
                    TestHelper.IsJsonObjectProperSubsetOf(
                    "{\"message\":\"For product ids [1235124634] the validation settings will be removed!\",\"errorMessage\":[],\"is_error\":false,\"code\":\"\"}",
                    TestHelper.ConvertStreamToString(this.HttpCallBackHandler.Response.RawBody),
                    false,
                    true,
                    false),
                    "Response body should have matching keys");
        }
    }
}