// <copyright file="YieldsControllerTest.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace SupplierAPI.Tests
{
    using System;
    using System.Collections.Generic;
    using System.Globalization;
    using System.IO;
    using System.Threading.Tasks;
    using Newtonsoft.Json.Converters;
    using NUnit.Framework;
    using SupplierAPI.Standard;
    using SupplierAPI.Standard.Controllers;
    using SupplierAPI.Standard.Exceptions;
    using SupplierAPI.Standard.Http.Client;
    using SupplierAPI.Standard.Http.Response;
    using SupplierAPI.Standard.Utilities;
    using SupplierAPI.Tests.Helpers;

    /// <summary>
    /// YieldsControllerTest.
    /// </summary>
    [TestFixture]
    public class YieldsControllerTest : ControllerTestBase
    {
        /// <summary>
        /// Controller instance (for all tests).
        /// </summary>
        private YieldsController controller;

        /// <summary>
        /// Setup test class.
        /// </summary>
        [OneTimeSetUp]
        public void SetUpDerived()
        {
            this.controller = this.Client.YieldsController;
        }

        /// <summary>
        /// This function allows the logged in user to get yield management rules list per Property Manager.
        ///
        ///.
        /// </summary>
        /// <returns>A <see cref="Task"/> representing the asynchronous unit test.</returns>
        [Test]
        public async Task TestTestDeleteYMRListByPropertyManager()
        {
            // Parameters for the API call
            string channelAbbreviation = "BKG";
            string partyChannelMarkupId = "1837282";
            string propertyManager = "{propertyManager}";

            // Perform API call
            Standard.Models.APIResponseWithoutData result = null;
            try
            {
                result = await this.controller.DeleteYMRListByPropertyManagerAsync(channelAbbreviation, partyChannelMarkupId, propertyManager);
            }
            catch (ApiException)
            {
            }

            // Test response code
            Assert.AreEqual(200, this.HttpCallBackHandler.Response.StatusCode, "Status should be 200");

            // Test headers
            Dictionary<string, string> headers = new Dictionary<string, string>();
            headers.Add("Content-Type", null);

            Assert.IsTrue(
                    TestHelper.AreHeadersProperSubsetOf (
                    headers,
                    this.HttpCallBackHandler.Response.Headers),
                    "Headers should match");
        }

        /// <summary>
        /// This function allows the logged in user to get yield management rules list per Property Manager.
        ///
        ///.
        /// </summary>
        /// <returns>A <see cref="Task"/> representing the asynchronous unit test.</returns>
        [Test]
        public async Task TestTestGetYMRListByPropertyManager()
        {
            // Parameters for the API call
            string propertyManager = "1235124634";
            string channelAbbreviation = "HAC";

            // Perform API call
            Standard.Models.YieldResponseByPropertyManager result = null;
            try
            {
                result = await this.controller.GetYMRListByPropertyManagerAsync(propertyManager, channelAbbreviation);
            }
            catch (ApiException)
            {
            }

            // Test response code
            Assert.AreEqual(200, this.HttpCallBackHandler.Response.StatusCode, "Status should be 200");

            // Test headers
            Dictionary<string, string> headers = new Dictionary<string, string>();
            headers.Add("Content-Type", null);

            Assert.IsTrue(
                    TestHelper.AreHeadersProperSubsetOf (
                    headers,
                    this.HttpCallBackHandler.Response.Headers),
                    "Headers should match");
        }

        /// <summary>
        /// This function allows the logged-in user to add yield management rules for the specific product. Yield management rules can affect the final price of the property depending on some special conditions (like the length of stay, early booking, etc.). These rules automate price manipulations, on an inquiry by inquiry basis. When set criteria are met, they help maximize revenue and occupancy.
        ///
        ///How is the price calculated?
        ///The price for a night is calculated based on the basic price and the yield management rules.
        ///
        ///- If no YMR:
        ///{basic price per night} = price per night
        ///- If YMR is set it can Increase/decrease percent or increase/decrease amount:
        ///  {basic price per night} + {yield amount} = {price per night}
        ///  or
        ///  {basic price per night} - {yield amount} = {price per night}
        ///
        ///The below examples will use the scenario to walk you step by step and explain how the price is calculated based on different YMRs. 
        ///Let’s say that the basic price per night for 2016 is 100 USD.
        ///
        ///This function is used also for updating yield. So if you already create a specific yield for some date - and you send a new one - we will update the yield for this date.
        ///If you need to delete a specific yield type - you can send an empty list for that type.
        ///
        ///Important: The maximum allowed end date is 3 years in the future..
        /// </summary>
        /// <returns>A <see cref="Task"/> representing the asynchronous unit test.</returns>
        [Test]
        public async Task TestTestCreateYMR()
        {
            // Parameters for the API call
            Standard.Models.CreateYieldRequest body = ApiHelper.JsonDeserialize<Standard.Models.CreateYieldRequest>("{\"data\":{\"productId\":1235124634,\"weekend\":[{\"beginDate\":\"2020-02-10\",\"endDate\":\"2021-02-15\",\"amount\":18,\"modifier\":\"DECREASE_PERCENT\",\"weekendParam\":\"DAYS_OF_WEEKEND_SAT_SUN\"}],\"lengthOfStay\":[{\"beginDate\":\"2020-02-10\",\"endDate\":\"2021-02-15\",\"amount\":34,\"modifier\":\"INCREASE_AMOUNT\",\"param\":7}],\"dateRange\":[{\"beginDate\":\"2020-04-10\",\"endDate\":\"2020-04-15\",\"amount\":35,\"modifier\":\"INCREASE_AMOUNT\"},{\"beginDate\":\"2020-05-16\",\"endDate\":\"2020-05-25\",\"amount\":25,\"modifier\":\"INCREASE_PERCENT\"}]}}");

            // Perform API call
            Standard.Models.YieldResponse result = null;
            try
            {
                result = await this.controller.CreateYMRAsync(body);
            }
            catch (ApiException)
            {
            }

            // Test response code
            Assert.AreEqual(200, this.HttpCallBackHandler.Response.StatusCode, "Status should be 200");

            // Test headers
            Dictionary<string, string> headers = new Dictionary<string, string>();
            headers.Add("Content-Type", null);

            Assert.IsTrue(
                    TestHelper.AreHeadersProperSubsetOf (
                    headers,
                    this.HttpCallBackHandler.Response.Headers),
                    "Headers should match");

            // Test whether the captured response is as we expected
            Assert.IsNotNull(result, "Result should exist");
            Assert.IsTrue(
                    TestHelper.IsJsonObjectProperSubsetOf(
                    "{\"message\":\"\",\"errorMessage\":[],\"is_error\":false,\"code\":\"\",\"data\":[{\"productId\":1235124634,\"weekend\":[{\"beginDate\":\"2020-03-17\",\"endDate\":\"2021-02-15\",\"amount\":18,\"modifier\":\"DECREASE_PERCENT\",\"weekendParam\":\"DAYS_OF_WEEKEND_SAT_SUN\"}],\"lengthOfStay\":[{\"beginDate\":\"2020-03-17\",\"endDate\":\"2021-02-15\",\"amount\":34,\"modifier\":\"INCREASE_AMOUNT\",\"param\":7}],\"dateRange\":[{\"beginDate\":\"2020-04-10\",\"endDate\":\"2020-04-15\",\"amount\":35,\"modifier\":\"INCREASE_AMOUNT\"},{\"beginDate\":\"2020-05-16\",\"endDate\":\"2020-05-25\",\"amount\":25,\"modifier\":\"INCREASE_PERCENT\"}]}]}",
                    TestHelper.ConvertStreamToString(this.HttpCallBackHandler.Response.RawBody),
                    false,
                    true,
                    false),
                    "Response body should have matching keys");
        }

        /// <summary>
        /// This function allows the logged in user to get yield management rules list of the specific product.
        ///
        ///
        ///.
        /// </summary>
        /// <returns>A <see cref="Task"/> representing the asynchronous unit test.</returns>
        [Test]
        public async Task TestTestGetYMRListByProductID()
        {
            // Parameters for the API call
            string productId = "1235124634";

            // Perform API call
            Standard.Models.YieldResponse result = null;
            try
            {
                result = await this.controller.GetYMRListByProductIDAsync(productId);
            }
            catch (ApiException)
            {
            }

            // Test response code
            Assert.AreEqual(200, this.HttpCallBackHandler.Response.StatusCode, "Status should be 200");

            // Test headers
            Dictionary<string, string> headers = new Dictionary<string, string>();
            headers.Add("Content-Type", null);

            Assert.IsTrue(
                    TestHelper.AreHeadersProperSubsetOf (
                    headers,
                    this.HttpCallBackHandler.Response.Headers),
                    "Headers should match");

            // Test whether the captured response is as we expected
            Assert.IsNotNull(result, "Result should exist");
            Assert.IsTrue(
                    TestHelper.IsJsonObjectProperSubsetOf(
                    "{\"message\":\"\",\"errorMessage\":[],\"is_error\":false,\"code\":\"\",\"data\":[{\"productId\":1235124634,\"weekend\":[{\"beginDate\":\"2020-03-17\",\"endDate\":\"2021-02-15\",\"amount\":18,\"modifier\":\"DECREASE_PERCENT\",\"weekendParam\":\"DAYS_OF_WEEKEND_SAT_SUN\"}],\"lengthOfStay\":[{\"beginDate\":\"2020-03-17\",\"endDate\":\"2021-02-15\",\"amount\":34,\"modifier\":\"INCREASE_AMOUNT\",\"param\":7}],\"dateRange\":[{\"beginDate\":\"2020-04-10\",\"endDate\":\"2020-04-15\",\"amount\":35,\"modifier\":\"INCREASE_AMOUNT\"},{\"beginDate\":\"2020-05-16\",\"endDate\":\"2020-05-25\",\"amount\":25,\"modifier\":\"INCREASE_PERCENT\"}]}]}",
                    TestHelper.ConvertStreamToString(this.HttpCallBackHandler.Response.RawBody),
                    false,
                    true,
                    false),
                    "Response body should have matching keys");
        }
    }
}