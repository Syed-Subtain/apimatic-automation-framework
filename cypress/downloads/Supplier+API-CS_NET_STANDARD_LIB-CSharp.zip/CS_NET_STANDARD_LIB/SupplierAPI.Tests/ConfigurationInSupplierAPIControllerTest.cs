// <copyright file="ConfigurationInSupplierAPIControllerTest.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace SupplierAPI.Tests
{
    using System;
    using System.Collections.Generic;
    using System.Globalization;
    using System.IO;
    using System.Threading.Tasks;
    using Newtonsoft.Json.Converters;
    using NUnit.Framework;
    using SupplierAPI.Standard;
    using SupplierAPI.Standard.Controllers;
    using SupplierAPI.Standard.Exceptions;
    using SupplierAPI.Standard.Http.Client;
    using SupplierAPI.Standard.Http.Response;
    using SupplierAPI.Standard.Utilities;
    using SupplierAPI.Tests.Helpers;

    /// <summary>
    /// ConfigurationInSupplierAPIControllerTest.
    /// </summary>
    [TestFixture]
    public class ConfigurationInSupplierAPIControllerTest : ControllerTestBase
    {
        /// <summary>
        /// Controller instance (for all tests).
        /// </summary>
        private ConfigurationInSupplierAPIController controller;

        /// <summary>
        /// Setup test class.
        /// </summary>
        [OneTimeSetUp]
        public void SetUpDerived()
        {
            this.controller = this.Client.ConfigurationInSupplierAPIController;
        }

        /// <summary>
        /// This function allows the logged in user to get an channels configuration..
        /// </summary>
        /// <returns>A <see cref="Task"/> representing the asynchronous unit test.</returns>
        [Test]
        public async Task TestTestConfigurationInSupplierAPI()
        {
            // Perform API call
            Standard.Models.ChannelConfigurationResponse result = null;
            try
            {
                result = await this.controller.ConfigurationInSupplierAPIAsync();
            }
            catch (ApiException)
            {
            }

            // Test response code
            Assert.AreEqual(200, this.HttpCallBackHandler.Response.StatusCode, "Status should be 200");

            // Test headers
            Dictionary<string, string> headers = new Dictionary<string, string>();
            headers.Add("Content-Type", null);

            Assert.IsTrue(
                    TestHelper.AreHeadersProperSubsetOf (
                    headers,
                    this.HttpCallBackHandler.Response.Headers),
                    "Headers should match");

            // Test whether the captured response is as we expected
            Assert.IsNotNull(result, "Result should exist");
            Assert.IsTrue(
                    TestHelper.IsJsonObjectProperSubsetOf(
                    "{\"message\":\"\",\"errorMessage\":[],\"code\":\"\",\"data\":[{\"name\":\"Booking.com\",\"abbreviation\":\"BKG\",\"logo\":\"https://s3.amazonaws.com/mybookingpal/pictures/raz/320331/320331/bookingWizard.png\",\"state\":\"VISIBLE\",\"supportValidation\":true,\"supportCreate\":true,\"supportConnect\":true,\"supportOpenClose\":true,\"supportStaticUpdate\":true,\"supportImageUpdate\":true,\"supportDynamicUpdate\":true,\"supportSynchronization\":false,\"supportCreateChannelAccount\":true,\"supportAuthorization\":true,\"supportGather\":true,\"supportChannelCancellationPolicy\":true,\"supportCancelFormPm\":false,\"supportModificationFromPm\":false,\"bookingType\":\"Instant\",\"ratesAndAvailabilityMapping\":\"MapToRatePlan\",\"acceptsPropertyType\":\"Both\",\"nativePropertyType\":\"Hotels\",\"minimumProperties\":0}],\"is_error\":false}",
                    TestHelper.ConvertStreamToString(this.HttpCallBackHandler.Response.RawBody),
                    false,
                    true,
                    false),
                    "Response body should have matching keys");
        }
    }
}