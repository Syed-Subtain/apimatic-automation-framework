// <copyright file="RatesAndAvailabilityControllerTest.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace SupplierAPI.Tests
{
    using System;
    using System.Collections.Generic;
    using System.Globalization;
    using System.IO;
    using System.Threading.Tasks;
    using Newtonsoft.Json.Converters;
    using NUnit.Framework;
    using SupplierAPI.Standard;
    using SupplierAPI.Standard.Controllers;
    using SupplierAPI.Standard.Exceptions;
    using SupplierAPI.Standard.Http.Client;
    using SupplierAPI.Standard.Http.Response;
    using SupplierAPI.Standard.Utilities;
    using SupplierAPI.Tests.Helpers;

    /// <summary>
    /// RatesAndAvailabilityControllerTest.
    /// </summary>
    [TestFixture]
    public class RatesAndAvailabilityControllerTest : ControllerTestBase
    {
        /// <summary>
        /// Controller instance (for all tests).
        /// </summary>
        private RatesAndAvailabilityController controller;

        /// <summary>
        /// Setup test class.
        /// </summary>
        [OneTimeSetUp]
        public void SetUpDerived()
        {
            this.controller = this.Client.RatesAndAvailabilityController;
        }

        /// <summary>
        /// This function allows logged in users to get rates and availability for the specific product.
        ///Every API call in this section should be with PM credentials..
        /// </summary>
        /// <returns>A <see cref="Task"/> representing the asynchronous unit test.</returns>
        [Test]
        public async Task TestTestGetRatesAndAvailabilityProductID()
        {
            // Parameters for the API call
            string contentType = "application/json";
            string productId = "1235124634";

            // Perform API call
            Standard.Models.RatesAvailabilityResponse result = null;
            try
            {
                result = await this.controller.GetRatesAndAvailabilityProductIDAsync(contentType, productId);
            }
            catch (ApiException)
            {
            }

            // Test response code
            Assert.AreEqual(200, this.HttpCallBackHandler.Response.StatusCode, "Status should be 200");

            // Test headers
            Dictionary<string, string> headers = new Dictionary<string, string>();
            headers.Add("Content-Type", null);

            Assert.IsTrue(
                    TestHelper.AreHeadersProperSubsetOf (
                    headers,
                    this.HttpCallBackHandler.Response.Headers),
                    "Headers should match");

            // Test whether the captured response is as we expected
            Assert.IsNotNull(result, "Result should exist");
            Assert.IsTrue(
                    TestHelper.IsJsonObjectProperSubsetOf(
                    "{\"message\":\"\",\"errorMessage\":[],\"is_error\":false,\"code\":\"\",\"data\":[{\"productId\":1235124634,\"leadTime\":2,\"rates\":[{\"beginDate\":\"2020-03-17\",\"endDate\":\"2021-01-25\",\"amount\":137}],\"minStays\":[{\"beginDate\":\"2020-03-17\",\"endDate\":\"2021-01-25\",\"minStay\":5}],\"maxStays\":[{\"beginDate\":\"2020-03-17\",\"endDate\":\"2021-01-25\",\"maxStay\":20}],\"restrictions\":[{\"beginDate\":\"2020-03-23\",\"endDate\":\"2021-01-25\",\"checkIn\":{\"monday\":false,\"tuesday\":false,\"wednesday\":false,\"thursday\":false,\"friday\":false,\"saturday\":true,\"sunday\":true},\"checkOut\":{\"monday\":false,\"tuesday\":false,\"wednesday\":false,\"thursday\":false,\"friday\":false,\"saturday\":true,\"sunday\":true}},{\"beginDate\":\"2021-01-25\",\"endDate\":\"2021-02-01\",\"checkIn\":{\"monday\":false,\"tuesday\":true,\"wednesday\":true,\"thursday\":true,\"friday\":true,\"saturday\":true,\"sunday\":true},\"checkOut\":{\"monday\":false,\"tuesday\":true,\"wednesday\":true,\"thursday\":true,\"friday\":true,\"saturday\":true,\"sunday\":true}},{\"beginDate\":\"2020-03-16\",\"endDate\":\"2020-03-23\",\"checkIn\":{\"monday\":true,\"tuesday\":false,\"wednesday\":false,\"thursday\":false,\"friday\":false,\"saturday\":true,\"sunday\":true},\"checkOut\":{\"monday\":true,\"tuesday\":false,\"wednesday\":false,\"thursday\":false,\"friday\":false,\"saturday\":true,\"sunday\":true}}],\"availabilities\":[{\"beginDate\":\"2020-04-20\",\"endDate\":\"2020-04-25\",\"availability\":false}]}]}",
                    TestHelper.ConvertStreamToString(this.HttpCallBackHandler.Response.RawBody),
                    false,
                    true,
                    false),
                    "Response body should have matching keys");
        }
    }
}