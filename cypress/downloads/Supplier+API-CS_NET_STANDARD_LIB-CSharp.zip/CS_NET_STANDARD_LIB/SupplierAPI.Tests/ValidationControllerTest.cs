// <copyright file="ValidationControllerTest.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace SupplierAPI.Tests
{
    using System;
    using System.Collections.Generic;
    using System.Globalization;
    using System.IO;
    using System.Threading.Tasks;
    using Newtonsoft.Json.Converters;
    using NUnit.Framework;
    using SupplierAPI.Standard;
    using SupplierAPI.Standard.Controllers;
    using SupplierAPI.Standard.Exceptions;
    using SupplierAPI.Standard.Http.Client;
    using SupplierAPI.Standard.Http.Response;
    using SupplierAPI.Standard.Utilities;
    using SupplierAPI.Tests.Helpers;

    /// <summary>
    /// ValidationControllerTest.
    /// </summary>
    [TestFixture]
    public class ValidationControllerTest : ControllerTestBase
    {
        /// <summary>
        /// Controller instance (for all tests).
        /// </summary>
        private ValidationController controller;

        /// <summary>
        /// Setup test class.
        /// </summary>
        [OneTimeSetUp]
        public void SetUpDerived()
        {
            this.controller = this.Client.ValidationController;
        }

        /// <summary>
        /// This function will allow the PMS to call the BookingPal property validation job for a list of properties from request. These properties must belong to the current user and authorization token should be on PM level.
        ///Also, we will run validation only for properties that are activated. If you deactivate property - we will not validate this property..
        /// </summary>
        /// <returns>A <see cref="Task"/> representing the asynchronous unit test.</returns>
        [Test]
        public async Task TestTestBookingPalValidationJobListOfProperties()
        {
            // Parameters for the API call
            Standard.Models.ValidationForListOfPropertiesRequest body = ApiHelper.JsonDeserialize<Standard.Models.ValidationForListOfPropertiesRequest>("{\"data\":{\"productIds\":[1235124634,1235124636]}}");

            // Perform API call
            Standard.Models.APIResponseWithoutData result = null;
            try
            {
                result = await this.controller.BookingPalValidationJobListOfPropertiesAsync(body);
            }
            catch (ApiException)
            {
            }

            // Test response code
            Assert.AreEqual(200, this.HttpCallBackHandler.Response.StatusCode, "Status should be 200");

            // Test headers
            Dictionary<string, string> headers = new Dictionary<string, string>();
            headers.Add("Content-Type", null);

            Assert.IsTrue(
                    TestHelper.AreHeadersProperSubsetOf (
                    headers,
                    this.HttpCallBackHandler.Response.Headers),
                    "Headers should match");

            // Test whether the captured response is as we expected
            Assert.IsNotNull(result, "Result should exist");
            Assert.IsTrue(
                    TestHelper.IsJsonObjectProperSubsetOf(
                    "{\"message\":\"Your request was received and put in queue\",\"errorMessage\":[],\"is_error\":false,\"code\":\"\"}",
                    TestHelper.ConvertStreamToString(this.HttpCallBackHandler.Response.RawBody),
                    false,
                    true,
                    false),
                    "Response body should have matching keys");
        }

        /// <summary>
        /// This function will allow the PMC to call the BookingPal property validation job for all properties identified which belong to the current user. Authorization token should be on PM level. 
        ///Also we will run validation only for properties which are activated. If you deactivate property - we will not validate this property.
        ///
        ///After the request you will get a response indicating if messages were processed or not. If the request is good your request for the validator job will be put into a queue. Once the request is processed, BookingPal will send an async push message per property informing the user if a property is valid or not, and if it is not valid - with reasons why the validation failed. This message will be sent on the endpoint which was entered in section Push Notifications, field asyncPush.
        ///
        ///Note: If the property is distributed already on some channel - this property will not be moved to an Incomplete state. Also if you have property on Incomplete state because of some reason, and you update this data which causes that property is on ‘Incomplete’ property will not be moved automatically to a valid state. Instead, you should run a Validation job manually for that property or wait for our automatic validation job which we are running once per day. 
        ///
        ///To make the property ready for Onboarding you should run validation first. if the property is valid - it will be ready for onboarding. Otherwise - the property will be in Incomplete state. Also, we will run validation only for properties that are activated. If you deactivate property - we will not validate this property..
        /// </summary>
        /// <returns>A <see cref="Task"/> representing the asynchronous unit test.</returns>
        [Test]
        public async Task TestTestBookingPalValidationJobFullPM()
        {
            // Perform API call
            Standard.Models.APIResponseWithoutData result = null;
            try
            {
                result = await this.controller.BookingPalValidationJobFullPMAsync();
            }
            catch (ApiException)
            {
            }

            // Test response code
            Assert.AreEqual(200, this.HttpCallBackHandler.Response.StatusCode, "Status should be 200");

            // Test headers
            Dictionary<string, string> headers = new Dictionary<string, string>();
            headers.Add("Content-Type", null);

            Assert.IsTrue(
                    TestHelper.AreHeadersProperSubsetOf (
                    headers,
                    this.HttpCallBackHandler.Response.Headers),
                    "Headers should match");

            // Test whether the captured response is as we expected
            Assert.IsNotNull(result, "Result should exist");
            Assert.IsTrue(
                    TestHelper.IsJsonObjectProperSubsetOf(
                    "{\"message\":\"Your request was received and put in queue\",\"errorMessage\":[],\"is_error\":false,\"code\":\"\"}",
                    TestHelper.ConvertStreamToString(this.HttpCallBackHandler.Response.RawBody),
                    false,
                    true,
                    false),
                    "Response body should have matching keys");
        }
    }
}