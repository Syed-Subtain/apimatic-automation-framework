// <copyright file="ImagesControllerTest.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace SupplierAPI.Tests
{
    using System;
    using System.Collections.Generic;
    using System.Globalization;
    using System.IO;
    using System.Threading.Tasks;
    using Newtonsoft.Json.Converters;
    using NUnit.Framework;
    using SupplierAPI.Standard;
    using SupplierAPI.Standard.Controllers;
    using SupplierAPI.Standard.Exceptions;
    using SupplierAPI.Standard.Http.Client;
    using SupplierAPI.Standard.Http.Response;
    using SupplierAPI.Standard.Utilities;
    using SupplierAPI.Tests.Helpers;

    /// <summary>
    /// ImagesControllerTest.
    /// </summary>
    [TestFixture]
    public class ImagesControllerTest : ControllerTestBase
    {
        /// <summary>
        /// Controller instance (for all tests).
        /// </summary>
        private ImagesController controller;

        /// <summary>
        /// Setup test class.
        /// </summary>
        [OneTimeSetUp]
        public void SetUpDerived()
        {
            this.controller = this.Client.ImagesController;
        }

        /// <summary>
        /// This function allows logged in user to get image list for the existing product.
        /// </summary>
        /// <returns>A <see cref="Task"/> representing the asynchronous unit test.</returns>
        [Test]
        public async Task TestTestGetImageListByProductID()
        {
            // Parameters for the API call
            string productId = "1235124634";

            // Perform API call
            Standard.Models.GetImageListByProductID result = null;
            try
            {
                result = await this.controller.GetImageListByProductIDAsync(productId);
            }
            catch (ApiException)
            {
            }

            // Test response code
            Assert.AreEqual(200, this.HttpCallBackHandler.Response.StatusCode, "Status should be 200");

            // Test headers
            Dictionary<string, string> headers = new Dictionary<string, string>();
            headers.Add("Content-Type", null);

            Assert.IsTrue(
                    TestHelper.AreHeadersProperSubsetOf (
                    headers,
                    this.HttpCallBackHandler.Response.Headers),
                    "Headers should match");

            // Test whether the captured response is as we expected
            Assert.IsNotNull(result, "Result should exist");
            Assert.IsTrue(
                    TestHelper.IsJsonObjectProperSubsetOf(
                    "{\"message\":\"\",\"errorMessage\":[],\"is_error\":false,\"code\":\"\",\"data\":[{\"productId\":1235124634,\"images\":[{\"url\":\"http://aff.bstatic.com/images/hotel/max500/110/11069098.jpg\",\"tags\":[4,5,6],\"urlMbp\":\"https://s3.amazonaws.com/mybookingpal/pictures/n2ujn/n2ujn/1235124634/11069098.jpg\",\"sort\":1},{\"url\":\"http://aff.bstatic.com/images/hotel/max500/110/11069099.jpg\",\"tags\":[4,5,6],\"urlMbp\":\"https://s3.amazonaws.com/mybookingpal/pictures/n2ujn/n2ujn/1235124634/11069099.jpg\",\"sort\":2},{\"url\":\"http://aff.bstatic.com/images/hotel/max500/110/11069100.jpg\",\"tags\":[4,5,6],\"urlMbp\":\"https://s3.amazonaws.com/mybookingpal/pictures/n2ujn/n2ujn/1235124634/11069100.jpg\",\"sort\":3},{\"url\":\"http://aff.bstatic.com/images/hotel/max500/110/11069101.jpg\",\"tags\":[4,5,6],\"urlMbp\":\"https://s3.amazonaws.com/mybookingpal/pictures/n2ujn/n2ujn/1235124634/11069101.jpg\",\"sort\":4},{\"url\":\"http://aff.bstatic.com/images/hotel/max500/110/11069102.jpg\",\"tags\":[4,5,6],\"urlMbp\":\"https://s3.amazonaws.com/mybookingpal/pictures/n2ujn/n2ujn/1235124634/11069102.jpg\",\"sort\":5},{\"url\":\"http://aff.bstatic.com/images/hotel/max500/110/11069103.jpg\",\"tags\":[4,5,6],\"urlMbp\":\"https://s3.amazonaws.com/mybookingpal/pictures/n2ujn/n2ujn/1235124634/11069103.jpg\",\"sort\":6},{\"url\":\"http://aff.bstatic.com/images/hotel/max500/110/11069104.jpg\",\"tags\":[4,5,6],\"urlMbp\":\"https://s3.amazonaws.com/mybookingpal/pictures/n2ujn/n2ujn/1235124634/11069104.jpg\",\"sort\":7},{\"url\":\"http://aff.bstatic.com/images/hotel/max500/110/11069105.jpg\",\"tags\":[4,5,6],\"urlMbp\":\"https://s3.amazonaws.com/mybookingpal/pictures/n2ujn/n2ujn/1235124634/11069105.jpg\",\"sort\":8},{\"url\":\"http://aff.bstatic.com/images/hotel/max500/110/11069106.jpg\",\"tags\":[4,5,6],\"urlMbp\":\"https://s3.amazonaws.com/mybookingpal/pictures/n2ujn/n2ujn/1235124634/11069106.jpg\",\"sort\":9},{\"url\":\"http://aff.bstatic.com/images/hotel/max500/110/11069107.jpg\",\"tags\":[4,5,6],\"urlMbp\":\"https://s3.amazonaws.com/mybookingpal/pictures/n2ujn/n2ujn/1235124634/11069107.jpg\",\"sort\":10},{\"url\":\"http://aff.bstatic.com/images/hotel/max500/110/11069108.jpg\",\"tags\":[4,5,6],\"urlMbp\":\"https://s3.amazonaws.com/mybookingpal/pictures/n2ujn/n2ujn/1235124634/11069108.jpg\",\"sort\":11},{\"url\":\"http://aff.bstatic.com/images/hotel/max500/110/11069109.jpg\",\"tags\":[4,5,6],\"urlMbp\":\"https://s3.amazonaws.com/mybookingpal/pictures/n2ujn/n2ujn/1235124634/11069109.jpg\",\"sort\":12}]}]}",
                    TestHelper.ConvertStreamToString(this.HttpCallBackHandler.Response.RawBody),
                    false,
                    true,
                    false),
                    "Response body should have matching keys");
        }

        /// <summary>
        /// This function allows the logged user to upload images for the existing product. Images will be sorted in order how they are sent in the request. The first image sent in request will be used as the “Main Image”. (Image re-ordering can also be done within the BookingPal platform manually by users). Images that were in the system, and that aren’t in the request, will be deleted. So the function will do a full update of images..
        /// </summary>
        /// <returns>A <see cref="Task"/> representing the asynchronous unit test.</returns>
        [Test]
        public async Task TestTestFullupdateimages()
        {
            // Parameters for the API call
            Standard.Models.FullupdateImagesRequest body = ApiHelper.JsonDeserialize<Standard.Models.FullupdateImagesRequest>("{\"data\":{\"productId\":1234893572,\"images\":[{\"url\":\"http://aff.bstatic.com/images/hotel/max500/110/11069097.jpg\",\"tags\":[1,2,3]},{\"url\":\"http://aff.bstatic.com/images/hotel/max500/110/11069097.jpg\",\"tags\":[1,2,3]}]}}");

            // Perform API call
            Standard.Models.APIResponseWithoutData result = null;
            try
            {
                result = await this.controller.FullupdateimagesAsync(body);
            }
            catch (ApiException)
            {
            }

            // Test response code
            Assert.AreEqual(200, this.HttpCallBackHandler.Response.StatusCode, "Status should be 200");

            // Test headers
            Dictionary<string, string> headers = new Dictionary<string, string>();
            headers.Add("Content-Type", null);

            Assert.IsTrue(
                    TestHelper.AreHeadersProperSubsetOf (
                    headers,
                    this.HttpCallBackHandler.Response.Headers),
                    "Headers should match");

            // Test whether the captured response is as we expected
            Assert.IsNotNull(result, "Result should exist");
            Assert.IsTrue(
                    TestHelper.IsJsonObjectProperSubsetOf(
                    "{\"message\":\"Your request was received and put in queue\",\"errorMessage\":[],\"is_error\":false,\"code\":\"\"}",
                    TestHelper.ConvertStreamToString(this.HttpCallBackHandler.Response.RawBody),
                    false,
                    true,
                    false),
                    "Response body should have matching keys");
        }

        /// <summary>
        /// This function allows the logged in user to upload 1 image for the existing product. Every new image will be sorted to the end. The first image sent will be used as the “Main Image”. (Image re-ordering can also be done within the BookingPal platform manually by users).
        /// </summary>
        /// <returns>A <see cref="Task"/> representing the asynchronous unit test.</returns>
        [Test]
        public async Task TestTestAddimage()
        {
            // Parameters for the API call
            Standard.Models.AddImageRequest body = ApiHelper.JsonDeserialize<Standard.Models.AddImageRequest>("{\"data\":{\"productId\":1234879670,\"image\":{\"url\":\"http://www.pm-name.com/prop_img/1_2345_5_19.jpg\",\"tags\":[1,2,3]}}}");

            // Perform API call
            Standard.Models.APIResponseWithoutData result = null;
            try
            {
                result = await this.controller.AddimageAsync(body);
            }
            catch (ApiException)
            {
            }

            // Test response code
            Assert.AreEqual(200, this.HttpCallBackHandler.Response.StatusCode, "Status should be 200");

            // Test headers
            Dictionary<string, string> headers = new Dictionary<string, string>();
            headers.Add("Content-Type", null);

            Assert.IsTrue(
                    TestHelper.AreHeadersProperSubsetOf (
                    headers,
                    this.HttpCallBackHandler.Response.Headers),
                    "Headers should match");

            // Test whether the captured response is as we expected
            Assert.IsNotNull(result, "Result should exist");
            Assert.IsTrue(
                    TestHelper.IsJsonObjectProperSubsetOf(
                    "{\"message\":\"Your request was received and put in queue\",\"errorMessage\":[],\"is_error\":false,\"code\":\"\"}",
                    TestHelper.ConvertStreamToString(this.HttpCallBackHandler.Response.RawBody),
                    false,
                    true,
                    false),
                    "Response body should have matching keys");
        }

        /// <summary>
        /// This function allows the logged in user to delete image(s) from the existing product..
        /// </summary>
        /// <returns>A <see cref="Task"/> representing the asynchronous unit test.</returns>
        [Test]
        public async Task TestTestDeleteListOfImages()
        {
            // Perform API call
            Standard.Models.APIResponseWithoutData result = null;
            try
            {
                result = await this.controller.DeleteListOfImagesAsync();
            }
            catch (ApiException)
            {
            }

            // Test response code
            Assert.AreEqual(200, this.HttpCallBackHandler.Response.StatusCode, "Status should be 200");

            // Test headers
            Dictionary<string, string> headers = new Dictionary<string, string>();
            headers.Add("Content-Type", null);

            Assert.IsTrue(
                    TestHelper.AreHeadersProperSubsetOf (
                    headers,
                    this.HttpCallBackHandler.Response.Headers),
                    "Headers should match");

            // Test whether the captured response is as we expected
            Assert.IsNotNull(result, "Result should exist");
            Assert.IsTrue(
                    TestHelper.IsJsonObjectProperSubsetOf(
                    "{\"message\":\"Images are sent for processing!\",\"errorMessage\":[],\"is_error\":false,\"code\":\"\"}",
                    TestHelper.ConvertStreamToString(this.HttpCallBackHandler.Response.RawBody),
                    false,
                    true,
                    false),
                    "Response body should have matching keys");
        }

        /// <summary>
        /// This function allows logged in user to delete images..
        /// </summary>
        /// <returns>A <see cref="Task"/> representing the asynchronous unit test.</returns>
        [Test]
        public async Task TestTestDeleteAllImagesPerProperty()
        {
            // Parameters for the API call
            string contentType = "application/json";
            string productId = "1235124634";

            // Perform API call
            Standard.Models.APIResponseWithoutData result = null;
            try
            {
                result = await this.controller.DeleteAllImagesPerPropertyAsync(contentType, productId);
            }
            catch (ApiException)
            {
            }

            // Test response code
            Assert.AreEqual(200, this.HttpCallBackHandler.Response.StatusCode, "Status should be 200");

            // Test headers
            Dictionary<string, string> headers = new Dictionary<string, string>();
            headers.Add("Content-Type", null);

            Assert.IsTrue(
                    TestHelper.AreHeadersProperSubsetOf (
                    headers,
                    this.HttpCallBackHandler.Response.Headers),
                    "Headers should match");

            // Test whether the captured response is as we expected
            Assert.IsNotNull(result, "Result should exist");
            Assert.IsTrue(
                    TestHelper.IsJsonObjectProperSubsetOf(
                    "{\"message\":\"Your request was received and put in queue\",\"errorMessage\":[],\"is_error\":false,\"code\":\"\"}",
                    TestHelper.ConvertStreamToString(this.HttpCallBackHandler.Response.RawBody),
                    false,
                    true,
                    false),
                    "Response body should have matching keys");
        }
    }
}