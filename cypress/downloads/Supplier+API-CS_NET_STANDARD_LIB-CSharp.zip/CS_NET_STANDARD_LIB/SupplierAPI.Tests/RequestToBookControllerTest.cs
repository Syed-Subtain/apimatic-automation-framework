// <copyright file="RequestToBookControllerTest.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace SupplierAPI.Tests
{
    using System;
    using System.Collections.Generic;
    using System.Globalization;
    using System.IO;
    using System.Threading.Tasks;
    using Newtonsoft.Json.Converters;
    using NUnit.Framework;
    using SupplierAPI.Standard;
    using SupplierAPI.Standard.Controllers;
    using SupplierAPI.Standard.Exceptions;
    using SupplierAPI.Standard.Http.Client;
    using SupplierAPI.Standard.Http.Response;
    using SupplierAPI.Standard.Utilities;
    using SupplierAPI.Tests.Helpers;

    /// <summary>
    /// RequestToBookControllerTest.
    /// </summary>
    [TestFixture]
    public class RequestToBookControllerTest : ControllerTestBase
    {
        /// <summary>
        /// Controller instance (for all tests).
        /// </summary>
        private RequestToBookController controller;

        /// <summary>
        /// Setup test class.
        /// </summary>
        [OneTimeSetUp]
        public void SetUpDerived()
        {
            this.controller = this.Client.RequestToBookController;
        }

        /// <summary>
        /// This will be a request which we will send to PMS when we get a request to book from the channel.
        ///So when BookingPal gets a new request to book request - we will push this POST request to the link which you set in BookingPal for your PMS (in Push Notification section if you set link "reservationLink" - notification will be sent on this link. Otherwise it will be set on link "requestToBook"). 
        ///
        ///Important note: In this doc to be able to test this - you need to set a full URL on the Configure button in the right section..
        /// </summary>
        /// <returns>A <see cref="Task"/> representing the asynchronous unit test.</returns>
        [Test]
        public async Task TestTestRequestToBookRequest()
        {
            // Parameters for the API call
            Standard.Models.RequestToBookRequestModel body = ApiHelper.JsonDeserialize<Standard.Models.RequestToBookRequestModel>("{\"rezcasterNotificationRequest\":{\"reservationId\":\"107\",\"productId\":\"1234561234\",\"supplierId\":\"3731837\",\"channelName\":\"Airbnb\",\"confirmationId\":\"ZSC213123123A\",\"customerName\":\"dasdasd\",\"fromDate\":\"2019-05-17\",\"toDate\":\"2019-05-23\",\"adult\":2,\"child\":0,\"address\":\"asdasd\",\"city\":\"asdasd\",\"zip\":\"asdasd\",\"email\":\"andrewtesttest222@gmail.com\",\"phone\":\"4234234\",\"notes\":\"customer test message\",\"creditCardType\":\"1\",\"creditCardNumber\":\"4111111111111111\",\"creditCardExpirationMonth\":\"12\",\"creditCardExpirationYear\":\"2023\",\"creditCardCid\":\"123\",\"total\":652,\"fees\":[{\"id\":\"937-4\",\"name\":\"Cleaning Fee\",\"value\":110},{\"id\":\"355\",\"name\":\"Limited Damage Waiver\",\"value\":60},{\"id\":\"1298\",\"name\":\"Processing Fee\",\"value\":40}],\"taxes\":[{\"id\":\"22\",\"name\":\"State of Florida-Lake County State Tax\",\"value\":5},{\"id\":\"23\",\"name\":\"Tax-Lake County County Tax\",\"value\":15}],\"newState\":\"Provisional\",\"commission\":{\"channelCommission\":10,\"commission\":12},\"rate\":{\"originalRackRate\":400,\"netRate\":400,\"newPublishedRackRate\":422},\"country\":\"US\",\"state\":\"asdasda\",\"uniqueKey\":\"f207c4c029cb1ea1\"},\"action\":\"RESERVATION_REQUEST\",\"reservationId\":1234561234,\"expires_at\":\"2020-03-17\",\"messageToHost\":\"Test\"}");

            // Perform API call
            Standard.Models.ReservationPushResponse result = null;
            try
            {
                result = await this.controller.RequestToBookRequestAsync(body);
            }
            catch (ApiException)
            {
            }

            // Test response code
            Assert.AreEqual(200, this.HttpCallBackHandler.Response.StatusCode, "Status should be 200");

            // Test headers
            Dictionary<string, string> headers = new Dictionary<string, string>();
            headers.Add("Content-Type", null);

            Assert.IsTrue(
                    TestHelper.AreHeadersProperSubsetOf (
                    headers,
                    this.HttpCallBackHandler.Response.Headers),
                    "Headers should match");

            // Test whether the captured response is as we expected
            Assert.IsNotNull(result, "Result should exist");
            Assert.IsTrue(
                    TestHelper.IsJsonObjectProperSubsetOf(
                    "{\"altId\":\"45717\",\"is_error\":false,\"code\":\"\",\"message\":\"Request to book is accepted.\"}",
                    TestHelper.ConvertStreamToString(this.HttpCallBackHandler.Response.RawBody),
                    false,
                    true,
                    false),
                    "Response body should have matching keys");
        }

        /// <summary>
        /// This is an API call that you should use for accepting on avoiding requests to book..
        /// </summary>
        /// <returns>A <see cref="Task"/> representing the asynchronous unit test.</returns>
        [Test]
        public async Task TestTestRequestToBookAnswerFromPMS()
        {
            // Parameters for the API call
            Standard.Models.RequestToBookAnswerFromPMSRequest body = ApiHelper.JsonDeserialize<Standard.Models.RequestToBookAnswerFromPMSRequest>("{\"data\":{\"requestToBookType\":\"DENY\",\"requestToBookDeclineReasonType\":\"DATES_NOT_AVAILABLE\",\"declineMessageToGuest\":\"these dates are not available any more. \",\"reservationId\":1235124634}}");

            // Perform API call
            Standard.Models.APIResponseWithoutData result = null;
            try
            {
                result = await this.controller.RequestToBookAnswerFromPMSAsync(body);
            }
            catch (ApiException)
            {
            }

            // Test response code
            Assert.AreEqual(200, this.HttpCallBackHandler.Response.StatusCode, "Status should be 200");

            // Test headers
            Dictionary<string, string> headers = new Dictionary<string, string>();
            headers.Add("Content-Type", null);

            Assert.IsTrue(
                    TestHelper.AreHeadersProperSubsetOf (
                    headers,
                    this.HttpCallBackHandler.Response.Headers),
                    "Headers should match");

            // Test whether the captured response is as we expected
            Assert.IsNotNull(result, "Result should exist");
            Assert.IsTrue(
                    TestHelper.IsJsonObjectProperSubsetOf(
                    "{\"message\":\"Request to book answer accepted\",\"errorMessage\":[],\"is_error\":false,\"code\":\"\"}",
                    TestHelper.ConvertStreamToString(this.HttpCallBackHandler.Response.RawBody),
                    false,
                    true,
                    false),
                    "Response body should have matching keys");
        }

        /// <summary>
        /// Since you can not get the request to book on our test environment (since this first needs to be created on the channel) We provide the possibility for PMS to test this request with some random filled data in our system. So when you call this API function - we will send you push notification for the request to book for a provided property ID..
        /// </summary>
        /// <returns>A <see cref="Task"/> representing the asynchronous unit test.</returns>
        [Test]
        public async Task TestTestRequestToBookTest()
        {
            // Parameters for the API call
            Standard.Models.RequestToBookTestRequest body = ApiHelper.JsonDeserialize<Standard.Models.RequestToBookTestRequest>("{\"data\":{\"action\":\"RESERVATION_REQUEST_VOIDED\",\"productId\":1235124634}}");

            // Perform API call
            Standard.Models.APIResponseWithoutData result = null;
            try
            {
                result = await this.controller.RequestToBookTestAsync(body);
            }
            catch (ApiException)
            {
            }

            // Test response code
            Assert.AreEqual(200, this.HttpCallBackHandler.Response.StatusCode, "Status should be 200");

            // Test headers
            Dictionary<string, string> headers = new Dictionary<string, string>();
            headers.Add("Content-Type", null);

            Assert.IsTrue(
                    TestHelper.AreHeadersProperSubsetOf (
                    headers,
                    this.HttpCallBackHandler.Response.Headers),
                    "Headers should match");

            // Test whether the captured response is as we expected
            Assert.IsNotNull(result, "Result should exist");
            Assert.IsTrue(
                    TestHelper.IsJsonObjectProperSubsetOf(
                    "{\"message\":\"Request to book test accepted\",\"errorMessage\":[],\"is_error\":false,\"code\":\"\",\"data\":[]}",
                    TestHelper.ConvertStreamToString(this.HttpCallBackHandler.Response.RawBody),
                    false,
                    true,
                    false),
                    "Response body should have matching keys");
        }
    }
}