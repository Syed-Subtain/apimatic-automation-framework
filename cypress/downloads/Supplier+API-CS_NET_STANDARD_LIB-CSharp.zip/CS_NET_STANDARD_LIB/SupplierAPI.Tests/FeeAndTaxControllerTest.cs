// <copyright file="FeeAndTaxControllerTest.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace SupplierAPI.Tests
{
    using System;
    using System.Collections.Generic;
    using System.Globalization;
    using System.IO;
    using System.Threading.Tasks;
    using Newtonsoft.Json.Converters;
    using NUnit.Framework;
    using SupplierAPI.Standard;
    using SupplierAPI.Standard.Controllers;
    using SupplierAPI.Standard.Exceptions;
    using SupplierAPI.Standard.Http.Client;
    using SupplierAPI.Standard.Http.Response;
    using SupplierAPI.Standard.Utilities;
    using SupplierAPI.Tests.Helpers;

    /// <summary>
    /// FeeAndTaxControllerTest.
    /// </summary>
    [TestFixture]
    public class FeeAndTaxControllerTest : ControllerTestBase
    {
        /// <summary>
        /// Controller instance (for all tests).
        /// </summary>
        private FeeAndTaxController controller;

        /// <summary>
        /// Setup test class.
        /// </summary>
        [OneTimeSetUp]
        public void SetUpDerived()
        {
            this.controller = this.Client.FeeAndTaxController;
        }

        /// <summary>
        /// This function allows the logged in user to set fees (i.e. cleaning fee, damage waiver, extra bed, extra person etc.) and taxes for the specific product. Here, you always need to send all fees and taxes for one property. All fees or taxes which were in our system for that property and which are not in the new request will be deleted. Taxes in the BookingPal system will always have percent value. 
        ///
        ///If you want to delete all fees and/or taxes for one property (if you do not have fees and taxes in your system for one property) send an empty list of fees and.or taxes. In short when you use this request you need to always send us a full list of fees and taxes per property, since we will do a full update.
        ///
        ///Note: Security deposits on Airbnb must be between 100 and 5000 USD. Any value smaller or larger will default to the largest accepted value. If currencies are not in USD, BookingPal will first convert the currency to USD before posting the security deposit on Airbnb..
        /// </summary>
        /// <returns>A <see cref="Task"/> representing the asynchronous unit test.</returns>
        [Test]
        public async Task TestTestCreateFeeAndTax()
        {
            // Parameters for the API call
            Standard.Models.CreateFeesandTaxesRequest body = ApiHelper.JsonDeserialize<Standard.Models.CreateFeesandTaxesRequest>("{\"data\":{\"productId\":1235124634,\"fees\":[{\"entityType\":\"OPTIONAL\",\"feeType\":\"GENERAL\",\"option\":3,\"name\":\"RetestFeeHF\",\"beginDate\":\"2020-02-26\",\"endDate\":\"2020-12-12\",\"taxType\":\"TAXABLE\",\"unit\":\"PER_DAY_PER_PERSON_EXTRA\",\"value\":88,\"valueType\":\"PERCENT\"}],\"taxes\":[{\"name\":\"Tax reTestAT\",\"type\":\"SalesTaxIncluded\",\"value\":55,\"altId\":\"11\"}]}}");

            // Perform API call
            Standard.Models.FeeTaxResponse result = null;
            try
            {
                result = await this.controller.CreateFeeAndTaxAsync(body);
            }
            catch (ApiException)
            {
            }

            // Test response code
            Assert.AreEqual(200, this.HttpCallBackHandler.Response.StatusCode, "Status should be 200");

            // Test headers
            Dictionary<string, string> headers = new Dictionary<string, string>();
            headers.Add("Content-Type", null);

            Assert.IsTrue(
                    TestHelper.AreHeadersProperSubsetOf (
                    headers,
                    this.HttpCallBackHandler.Response.Headers),
                    "Headers should match");

            // Test whether the captured response is as we expected
            Assert.IsNotNull(result, "Result should exist");
            Assert.IsTrue(
                    TestHelper.IsJsonObjectProperSubsetOf(
                    "{\"message\":\"\",\"errorMessage\":[],\"is_error\":false,\"code\":\"\",\"data\":[{\"productId\":1235124634,\"fees\":[{\"beginDate\":\"2020-02-26\",\"endDate\":\"2020-12-12\",\"entityType\":\"OPTIONAL\",\"feeType\":\"GENERAL\",\"option\":3,\"name\":\"RetestFeeHF\",\"taxType\":\"TAXABLE\",\"unit\":\"PER_DAY_PER_PERSON_EXTRA\",\"value\":88,\"valueType\":\"PERCENT\"}],\"taxes\":[{\"name\":\"Tax reTestAT\",\"type\":\"SalesTaxIncluded\",\"value\":55,\"altId\":\"11\"}]}]}",
                    TestHelper.ConvertStreamToString(this.HttpCallBackHandler.Response.RawBody),
                    false,
                    true,
                    false),
                    "Response body should have matching keys");
        }

        /// <summary>
        /// This function allows the logged in user to get a fee list for the specific product..
        /// </summary>
        /// <returns>A <see cref="Task"/> representing the asynchronous unit test.</returns>
        [Test]
        public async Task TestTestGetFeeAndTaxListByProductId()
        {
            // Parameters for the API call
            string productId = "1235124634";

            // Perform API call
            Standard.Models.FeeTaxResponse result = null;
            try
            {
                result = await this.controller.GetFeeAndTaxListByProductIdAsync(productId);
            }
            catch (ApiException)
            {
            }

            // Test response code
            Assert.AreEqual(200, this.HttpCallBackHandler.Response.StatusCode, "Status should be 200");

            // Test headers
            Dictionary<string, string> headers = new Dictionary<string, string>();
            headers.Add("Content-Type", null);

            Assert.IsTrue(
                    TestHelper.AreHeadersProperSubsetOf (
                    headers,
                    this.HttpCallBackHandler.Response.Headers),
                    "Headers should match");

            // Test whether the captured response is as we expected
            Assert.IsNotNull(result, "Result should exist");
            Assert.IsTrue(
                    TestHelper.IsJsonObjectProperSubsetOf(
                    "{\"message\":\"\",\"errorMessage\":[],\"is_error\":false,\"code\":\"\",\"data\":[{\"productId\":1235124634,\"fees\":[{\"beginDate\":\"2020-02-26\",\"endDate\":\"2020-12-12\",\"entityType\":\"OPTIONAL\",\"feeType\":\"GENERAL\",\"option\":3,\"name\":\"RetestFeeHF\",\"taxType\":\"TAXABLE\",\"unit\":\"PER_DAY_PER_PERSON_EXTRA\",\"value\":88,\"valueType\":\"PERCENT\"}],\"taxes\":[{\"name\":\"Tax reTestAT\",\"type\":\"SalesTaxIncluded\",\"value\":55,\"altId\":\"11\"}]}]}",
                    TestHelper.ConvertStreamToString(this.HttpCallBackHandler.Response.RawBody),
                    false,
                    true,
                    false),
                    "Response body should have matching keys");
        }
    }
}