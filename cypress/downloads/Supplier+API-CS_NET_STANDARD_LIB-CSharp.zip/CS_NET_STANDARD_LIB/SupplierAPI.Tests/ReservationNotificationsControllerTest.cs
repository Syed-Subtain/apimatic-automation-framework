// <copyright file="ReservationNotificationsControllerTest.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace SupplierAPI.Tests
{
    using System;
    using System.Collections.Generic;
    using System.Globalization;
    using System.IO;
    using System.Threading.Tasks;
    using Newtonsoft.Json.Converters;
    using NUnit.Framework;
    using SupplierAPI.Standard;
    using SupplierAPI.Standard.Controllers;
    using SupplierAPI.Standard.Exceptions;
    using SupplierAPI.Standard.Http.Client;
    using SupplierAPI.Standard.Http.Response;
    using SupplierAPI.Standard.Utilities;
    using SupplierAPI.Tests.Helpers;

    /// <summary>
    /// ReservationNotificationsControllerTest.
    /// </summary>
    [TestFixture]
    public class ReservationNotificationsControllerTest : ControllerTestBase
    {
        /// <summary>
        /// Controller instance (for all tests).
        /// </summary>
        private ReservationNotificationsController controller;

        /// <summary>
        /// Setup test class.
        /// </summary>
        [OneTimeSetUp]
        public void SetUpDerived()
        {
            this.controller = this.Client.ReservationNotificationsController;
        }

        /// <summary>
        /// This function allows logged-in users to get all reservations for the specific product..
        /// </summary>
        /// <returns>A <see cref="Task"/> representing the asynchronous unit test.</returns>
        [Test]
        public async Task TestTestGetReservationByProduct()
        {
            // Parameters for the API call
            string productId = "1235124634";

            // Perform API call
            Standard.Models.ReservationGetResponse result = null;
            try
            {
                result = await this.controller.GetReservationByProductAsync(productId);
            }
            catch (ApiException)
            {
            }

            // Test response code
            Assert.AreEqual(200, this.HttpCallBackHandler.Response.StatusCode, "Status should be 200");

            // Test headers
            Dictionary<string, string> headers = new Dictionary<string, string>();
            headers.Add("Content-Type", null);

            Assert.IsTrue(
                    TestHelper.AreHeadersProperSubsetOf (
                    headers,
                    this.HttpCallBackHandler.Response.Headers),
                    "Headers should match");

            // Test whether the captured response is as we expected
            Assert.IsNotNull(result, "Result should exist");
            Assert.IsTrue(
                    TestHelper.IsJsonObjectProperSubsetOf(
                    "{\"message\":\"\",\"errorMessage\":[],\"is_error\":false,\"code\":\"\",\"data\":[{\"reservationId\":\"107\",\"productId\":\"1235124634\",\"supplierId\":\"61692799\",\"channelName\":\"TestAndrew\",\"confirmationId\":\"ZSC213123123A\",\"customerName\":\"dasdasd\",\"fromDate\":\"2019-05-17\",\"toDate\":\"2019-05-23\",\"adult\":2,\"child\":0,\"email\":\"apimaticTest@test.com\",\"phone\":\"4234234\",\"notes\":\"customer test message\",\"total\":200,\"fees\":[{\"id\":\"937-4\",\"name\":\"Cleaning Fee\",\"value\":110},{\"id\":\"355\",\"name\":\"Limited Damage Waiver\",\"value\":60},{\"id\":\"1298\",\"name\":\"Processing Fee\",\"value\":40}],\"taxes\":[{\"id\":\"22\",\"name\":\"State of Florida-Lake County State Tax\",\"value\":5},{\"id\":\"22\",\"name\":\"State of Florida-Lake County State Tax\",\"value\":5},{\"id\":\"23\",\"name\":\"Tax-Lake County County Tax\",\"value\":15},{\"id\":\"23\",\"name\":\"Tax-Lake County County Tax\",\"value\":10}],\"newState\":\"Provisional\",\"commission\":{\"channelCommission\":10,\"commission\":12},\"rate\":{\"originalRackRate\":10,\"netRate\":12,\"newPublishedRackRate\":11},\"uniqueKey\":\"f207c4c029cb1ea1\"}]}",
                    TestHelper.ConvertStreamToString(this.HttpCallBackHandler.Response.RawBody),
                    false,
                    true,
                    false),
                    "Response body should have matching keys");
        }

        /// <summary>
        /// This API call will return a list of reservations that belong to the current user..
        /// </summary>
        /// <returns>A <see cref="Task"/> representing the asynchronous unit test.</returns>
        [Test]
        public async Task TestTestGetReservationByPM()
        {
            // Parameters for the API call
            double? page = 3;
            double? limit = 25;

            // Perform API call
            Standard.Models.ReservationGetResponse result = null;
            try
            {
                result = await this.controller.GetReservationByPMAsync(page, limit);
            }
            catch (ApiException)
            {
            }

            // Test response code
            Assert.AreEqual(200, this.HttpCallBackHandler.Response.StatusCode, "Status should be 200");

            // Test headers
            Dictionary<string, string> headers = new Dictionary<string, string>();
            headers.Add("Content-Type", null);

            Assert.IsTrue(
                    TestHelper.AreHeadersProperSubsetOf (
                    headers,
                    this.HttpCallBackHandler.Response.Headers),
                    "Headers should match");

            // Test whether the captured response is as we expected
            Assert.IsNotNull(result, "Result should exist");
            Assert.IsTrue(
                    TestHelper.IsJsonObjectProperSubsetOf(
                    "{\"message\":\"\",\"errorMessage\":[],\"is_error\":false,\"code\":\"\",\"data\":[{\"reservationId\":\"107\",\"productId\":\"1234816374\",\"supplierId\":\"3731837\",\"channelName\":\"TestAndrew\",\"confirmationId\":\"ZSC213123123A\",\"customerName\":\"dasdasd\",\"fromDate\":\"2019-05-17\",\"toDate\":\"2019-05-23\",\"adult\":2,\"child\":0,\"email\":\"andrewtesttest222@gmail.com\",\"phone\":\"4234234\",\"notes\":\"customer test message\",\"total\":200,\"fees\":[{\"id\":\"937-4\",\"name\":\"Cleaning Fee\",\"value\":110},{\"id\":\"355\",\"name\":\"Limited Damage Waiver\",\"value\":60},{\"id\":\"1298\",\"name\":\"Processing Fee\",\"value\":40}],\"taxes\":[{\"id\":\"22\",\"name\":\"State of Florida-Lake County State Tax\",\"value\":5},{\"id\":\"22\",\"name\":\"State of Florida-Lake County State Tax\",\"value\":5},{\"id\":\"23\",\"name\":\"Tax-Lake County County Tax\",\"value\":15},{\"id\":\"23\",\"name\":\"Tax-Lake County County Tax\",\"value\":10}],\"newState\":\"Provisional\",\"commission\":{\"channelCommission\":10,\"commission\":12},\"rate\":{\"originalRackRate\":10,\"netRate\":12,\"newPublishedRackRate\":11},\"uniqueKey\":\"f207c4c029cb1ea1\"}]}",
                    TestHelper.ConvertStreamToString(this.HttpCallBackHandler.Response.RawBody),
                    false,
                    true,
                    false),
                    "Response body should have matching keys");
        }

        /// <summary>
        /// DEPRECATED. Instead, check General Reservation Notification.
        ///
        ///This function sends the request to the provided link about a new reservation. So when BookingPal gets a new reservation - we will push this POST request to the link which you set in BookingPal for your PMS (in Push Notification section). 
        ///
        ///Important note: In this doc to be able to test this - you need to set a full URL on the Configure button in the right section.
        ///
        ///Note: Credit card data will be sent only if PMS should process payment in their system.
        ///Also, data that will be passed to PMS depends on channels - and do we get all of this data. So we have column ‘Mandatory’ to be aware that some data will be missing if we do not get them from a channel (like some guest address data).
        ///Additional note: Some channels support modification. At this moment we will process modification first by canceling the current reservation and then we will process the new regular reservation. In these cases for tracking purposes, you can use channel reservation ID (confirmationID) which should be the same in these cases..
        /// </summary>
        /// <returns>A <see cref="Task"/> representing the asynchronous unit test.</returns>
        [Test]
        public async Task TestTestNewReservationNotificationPUSH()
        {
            // Parameters for the API call
            Standard.Models.ReservationNotificationObject body = ApiHelper.JsonDeserialize<Standard.Models.ReservationNotificationObject>("{\"reservationId\":\"107\",\"productId\":\"1234816374\",\"supplierId\":\"3731837\",\"channelName\":\"Airbnb\",\"confirmationId\":\"ZSC213123123A\",\"customerName\":\"dasdasd\",\"fromDate\":\"2019-05-17\",\"toDate\":\"2019-05-23\",\"adult\":2,\"child\":0,\"address\":\"asdasd\",\"city\":\"asdasd\",\"zip\":\"asdasd\",\"email\":\"andrewtesttest222@gmail.com\",\"phone\":\"4234234\",\"notes\":\"customer test message\",\"creditCardType\":\"1\",\"creditCardNumber\":\"4111111111111111\",\"creditCardExpirationMonth\":\"12\",\"creditCardExpirationYear\":\"2023\",\"creditCardCid\":\"123\",\"total\":652,\"fees\":[{\"id\":\"937-4\",\"name\":\"Cleaning Fee\",\"value\":110},{\"id\":\"355\",\"name\":\"Limited Damage Waiver\",\"value\":60},{\"id\":\"1298\",\"name\":\"Processing Fee\",\"value\":40}],\"taxes\":[{\"id\":\"22\",\"name\":\"State of Florida-Lake County State Tax\",\"value\":5},{\"id\":\"23\",\"name\":\"Tax-Lake County County Tax\",\"value\":15}],\"newState\":\"Provisional\",\"commission\":{\"channelCommission\":10,\"commission\":12},\"rate\":{\"originalRackRate\":400,\"netRate\":400,\"newPublishedRackRate\":422},\"country\":\"US\",\"state\":\"asdasda\",\"uniqueKey\":\"f207c4c029cb1ea1\"}");

            // Perform API call
            Standard.Models.ReservationPushResponse result = null;
            try
            {
                result = await this.controller.NewReservationNotificationPUSHAsync(body);
            }
            catch (ApiException)
            {
            }

            // Test response code
            Assert.AreEqual(200, this.HttpCallBackHandler.Response.StatusCode, "Status should be 200");

            // Test headers
            Dictionary<string, string> headers = new Dictionary<string, string>();
            headers.Add("Content-Type", null);

            Assert.IsTrue(
                    TestHelper.AreHeadersProperSubsetOf (
                    headers,
                    this.HttpCallBackHandler.Response.Headers),
                    "Headers should match");

            // Test whether the captured response is as we expected
            Assert.IsNotNull(result, "Result should exist");
            Assert.IsTrue(
                    TestHelper.IsJsonObjectProperSubsetOf(
                    "{\"altId\":\"45717\",\"is_error\":false,\"code\":\"\",\"message\":\"Reservation is processed.\"}",
                    TestHelper.ConvertStreamToString(this.HttpCallBackHandler.Response.RawBody),
                    false,
                    true,
                    false),
                    "Response body should have matching keys");
        }

        /// <summary>
        /// DEPRECATED. Instead, check General Reservation Notification.
        ///
        ///This function sends the request to the provided link about the reservation cancellation. So when BookingPal gets a cancel reservation request from the channel - we will push this POST request to the link which you set in BookingPal for your PMS (in Push Notification section).
        ///
        ///Important note: In this doc to be able to test this - you need to set a full URL on the Configure button in the right section..
        /// </summary>
        /// <returns>A <see cref="Task"/> representing the asynchronous unit test.</returns>
        [Test]
        public async Task TestTestReservationCancellationNotificationPUSH()
        {
            // Parameters for the API call
            Standard.Models.CancelReservationNotificationObject body = ApiHelper.JsonDeserialize<Standard.Models.CancelReservationNotificationObject>("{\"reservationId\":\"7534\",\"productId\":\"12969\",\"supplierId\":161637256,\"channelName\":\"Airbnb\",\"confirmationId\":\"ZSC213123123A\",\"customerName\":\"Michael, Johnson\",\"fromDate\":\"2020-02-26\",\"toDate\":\"2020-02-27\",\"adult\":1,\"child\":0,\"email\":\"autoorlu@atvc.gen\",\"phone\":\"+384135213\",\"notes\":\"test notes\",\"total\":28.16,\"uniqueKey\":\"227317348c176f71a502d2c65c2f75d3\",\"newState\":\"Cancelled\"}");

            // Perform API call
            Standard.Models.ReservationPushResponse result = null;
            try
            {
                result = await this.controller.ReservationCancellationNotificationPUSHAsync(body);
            }
            catch (ApiException)
            {
            }

            // Test response code
            Assert.AreEqual(200, this.HttpCallBackHandler.Response.StatusCode, "Status should be 200");

            // Test headers
            Dictionary<string, string> headers = new Dictionary<string, string>();
            headers.Add("Content-Type", null);

            Assert.IsTrue(
                    TestHelper.AreHeadersProperSubsetOf (
                    headers,
                    this.HttpCallBackHandler.Response.Headers),
                    "Headers should match");

            // Test whether the captured response is as we expected
            Assert.IsNotNull(result, "Result should exist");
            Assert.IsTrue(
                    TestHelper.IsJsonObjectProperSubsetOf(
                    "{\"altId\":\"45717\",\"is_error\":false,\"code\":\"\",\"message\":\"Cancellation accepted\"}",
                    TestHelper.ConvertStreamToString(this.HttpCallBackHandler.Response.RawBody),
                    false,
                    true,
                    false),
                    "Response body should have matching keys");
        }
    }
}