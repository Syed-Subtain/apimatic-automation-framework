
# Client Class Documentation

The following parameters are configurable for the API Client:

| Parameter | Type | Description |
|  --- | --- | --- |
| `PushServerUrl` | `string` | In some API call BookingPal will send POST request (push message) to the PMS for URL which you provide in API 'Push Notification'. You can test these calls to in this documentation, just you will need to set your URL here on specific API call, on Configure button in the right section of specific API function<br>*Default*: `"https://www.yourEndpoint.url"` |
| `Environment` | Environment | The API environment. <br> **Default: `Environment.Production`** |
| `Timeout` | `TimeSpan` | Http client timeout.<br>*Default*: `TimeSpan.FromSeconds(100)` |
| `Jwt` | `string` | Token which need to be passed in every request as GET parameter. You will get this token in authorization response. Token is valid 1 hour. |

The API client can be initialized as follows:

```csharp
SupplierAPI.Standard.SupplierAPIClient client = new SupplierAPI.Standard.SupplierAPIClient.Builder()
    .CustomQueryAuthenticationCredentials("jwt")
    .Environment(SupplierAPI.Standard.Environment.Production)
    .PushServerUrl("https://www.yourEndpoint.url")
    .HttpClientConfig(config => config.NumberOfRetries(0))
    .Build();
```

## Supplier APIClient Class

The gateway for the SDK. This class acts as a factory for the Controllers and also holds the configuration of the SDK.

### Controllers

| Name | Description |
|  --- | --- |
| PropertyManagersController | Gets PropertyManagersController controller. |
| AuthorizationController | Gets AuthorizationController controller. |
| ImagesController | Gets ImagesController controller. |
| RatesAndAvailabilityController | Gets RatesAndAvailabilityController controller. |
| FeeAndTaxController | Gets FeeAndTaxController controller. |
| FeeAndTaxMandatoryAtThePropertyLevelController | Gets FeeAndTaxMandatoryAtThePropertyLevelController controller. |
| YieldsController | Gets YieldsController controller. |
| TestingOfMessageAPICallsController | Gets TestingOfMessageAPICallsController controller. |
| MessagingController | Gets MessagingController controller. |
| PushNotificationController | Gets PushNotificationController controller. |
| ReservationNotificationsController | Gets ReservationNotificationsController controller. |
| AsynchronousPushMessagesController | Gets AsynchronousPushMessagesController controller. |
| LicensesController | Gets LicensesController controller. |
| ProductController | Gets ProductController controller. |
| ValidationController | Gets ValidationController controller. |
| RequestToBookController | Gets RequestToBookController controller. |
| LOSPricingController | Gets LOSPricingController controller. |
| ConfigurationInSupplierAPIController | Gets ConfigurationInSupplierAPIController controller. |

### Properties

| Name | Description | Type |
|  --- | --- | --- |
| HttpClientConfiguration | Gets the configuration of the Http Client associated with this client. | `IHttpClientConfiguration` |
| Timeout | Http client timeout. | `TimeSpan` |
| Environment | Current API environment. | `Environment` |
| PushServerUrl | In some API call BookingPal will send POST request (push message) to the PMS for URL which you provide in API 'Push Notification'. You can test these calls to in this documentation, just you will need to set your URL here on specific API call, on Configure button in the right section of specific API function | `string` |

### Methods

| Name | Description | Return Type |
|  --- | --- | --- |
| `GetBaseUri(Server alias = Server.Default)` | Gets the URL for a particular alias in the current environment and appends it with template parameters. | `string` |
| `ToBuilder()` | Creates an object of the Supplier APIClient using the values provided for the builder. | `Builder` |

## Supplier APIClient Builder Class

Class to build instances of Supplier APIClient.

### Methods

| Name | Description | Return Type |
|  --- | --- | --- |
| `HttpClientConfiguration(Action<HttpClientConfiguration.Builder> action)` | Gets the configuration of the Http Client associated with this client. | `Builder` |
| `Timeout(TimeSpan timeout)` | Http client timeout. | `Builder` |
| `Environment(Environment environment)` | Current API environment. | `Builder` |
| `PushServerUrl(string pushServerUrl)` | In some API call BookingPal will send POST request (push message) to the PMS for URL which you provide in API 'Push Notification'. You can test these calls to in this documentation, just you will need to set your URL here on specific API call, on Configure button in the right section of specific API function | `Builder` |

