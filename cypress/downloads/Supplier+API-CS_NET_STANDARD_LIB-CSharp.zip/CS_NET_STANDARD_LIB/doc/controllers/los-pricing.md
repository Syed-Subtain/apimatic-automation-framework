# LOS Pricing

```csharp
LOSPricingController lOSPricingController = client.LOSPricingController;
```

## Class Name

`LOSPricingController`

## Methods

* [Create and Update LOS Length of Stay Pricing](../../doc/controllers/los-pricing.md#create-and-update-los-length-of-stay-pricing)
* [Get Los Prices List by Product ID](../../doc/controllers/los-pricing.md#get-los-prices-list-by-product-id)


# Create and Update LOS Length of Stay Pricing

Introduction: You can use this function if you would like to send BookingPal different prices for various Length of Stays with the same starting date.

LOS Pricing will be a different method in sending rates to BookingPal and is defined as pricing sent for a specific “Stay ranges”, In the LOS  method you are setting specific rates based on the Length of Stay. (This is a different way to push rates to BookingPal. )

For date periods of 1 to 30 days a specific rate need to enter check-in date and a rate for every possible reservation starting at that date (i.e. 1 day, 2 days, up to 30 days, 30 days is the maximum value allowed for this field) you will need to send BookingPal total rate value for that period.

Maximum LOS number of days is 30. All other LOS values after 30 will not be saved. If you do not support reservation for some specific number of dates - send value 0.00 for this LOS number of days. Keep in mind that all values not sent for any specific check-in date will be considered as 0, and reservation for this number of days will not be possible.
Field maxGuests allows you to set different rates per different number of guests. If you do not have different rate values per number of guests - you can send the value for maximum number of guests, and all others will have the same rate.

For MLT REP - you should use daily rates.

It is suggested to manage availability over “rates and availability” API call, and to close/open dates over this call.

Note: this API call can be used only if you set supportedLosRates = true on the product. Otherwise using this API for specific product is not possible.

```csharp
CreateAndUpdateLOSLengthOfStayPricingAsync(
    Models.CreateAndUpdateLOSRequest body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`Models.CreateAndUpdateLOSRequest`](../../doc/models/create-and-update-los-request.md) | Body, Required | - |

## Response Type

[`Task<Models.LOSRatesResponse>`](../../doc/models/los-rates-response.md)

## Example Usage

```csharp
var body = new CreateAndUpdateLOSRequest();
body.Data = new LOSRatesProduct();
body.Data.ProductId = 192;
body.Data.LosRates = new List<LOSRate>();

var bodyDataLosRates0 = new LOSRate();
bodyDataLosRates0.CheckInDate = DateTime.Parse("2016-03-13");
bodyDataLosRates0.MaxGuests = 43;
bodyDataLosRates0.LosValue = new List<double>();
bodyDataLosRates0.LosValue.Add(193.13);
bodyDataLosRates0.LosValue.Add(193.14);
bodyDataLosRates0.LosValue.Add(193.15);
body.Data.LosRates.Add(bodyDataLosRates0);


try
{
    LOSRatesResponse result = await lOSPricingController.CreateAndUpdateLOSLengthOfStayPricingAsync(body);
}
catch (ApiException e){};
```

## Example Response *(as JSON)*

```json
{
  "message": "",
  "errorMessage": [],
  "is_error": false,
  "code": "",
  "data": "[{\"productId\":1235124634,\"losRates\":[{\"checkInDate\":\"2020-05-21T00:00:00.000+0000\",\"currency\":\"RSD\",\"maxGuests\":4,\"losValue\":[111,112,123,250,300,350,400,450,500,550,600,650,700,750,800,850,900,950,550,510,570,520,500,510,590,580,560,540,0,0]},{\"checkInDate\":\"2020-06-20T00:00:00.000+0000\",\"currency\":\"RSD\",\"maxGuests\":3,\"losValue\":[100,150,200,250,300,0,0,450,500,550,600,650,700,750,800,850,900,950,550,510,570,520,500,510,590,121,122,123,0,0]}]}]"
}
```


# Get Los Prices List by Product ID

This function allows the logged in user to get a LOS rate for property.

```csharp
GetLosPricesListByProductIDAsync(
    string productId)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `productId` | `string` | Template, Required | Property ID in BookingPal |

## Response Type

[`Task<Models.LOSRatesResponse>`](../../doc/models/los-rates-response.md)

## Example Usage

```csharp
string productId = "1235124634";

try
{
    LOSRatesResponse result = await lOSPricingController.GetLosPricesListByProductIDAsync(productId);
}
catch (ApiException e){};
```

## Example Response *(as JSON)*

```json
{
  "message": "",
  "errorMessage": [],
  "is_error": false,
  "code": "",
  "data": "[{\"productId\":1235124634,\"losRates\":[{\"checkInDate\":\"2020-05-21T00:00:00.000+0000\",\"currency\":\"RSD\",\"maxGuests\":4,\"losValue\":[111,112,123,250,300,350,400,450,500,550,600,650,700,750,800,850,900,950,550,510,570,520,500,510,590,580,560,540,0,0]},{\"checkInDate\":\"2020-06-20T00:00:00.000+0000\",\"currency\":\"RSD\",\"maxGuests\":3,\"losValue\":[100,150,200,250,300,0,0,450,500,550,600,650,700,750,800,850,900,950,550,510,570,520,500,510,590,121,122,123,0,0]}]}]"
}
```

