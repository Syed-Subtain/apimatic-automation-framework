# Request to Book

```csharp
RequestToBookController requestToBookController = client.RequestToBookController;
```

## Class Name

`RequestToBookController`

## Methods

* [Request to Book-Request](../../doc/controllers/request-to-book.md#request-to-book-request)
* [Request to Book-Answer From PMS](../../doc/controllers/request-to-book.md#request-to-book-answer-from-pms)
* [Request to Book-Test](../../doc/controllers/request-to-book.md#request-to-book-test)


# Request to Book-Request

This will be a request which we will send to PMS when we get a request to book from the channel.
So when BookingPal gets a new request to book request - we will push this POST request to the link which you set in BookingPal for your PMS (in Push Notification section if you set link "reservationLink" - notification will be sent on this link. Otherwise it will be set on link "requestToBook").

Important note: In this doc to be able to test this - you need to set a full URL on the Configure button in the right section.

:information_source: **Note** This endpoint does not require authentication.

```csharp
RequestToBookRequestAsync(
    Models.RequestToBookRequestModel body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`Models.RequestToBookRequestModel`](../../doc/models/request-to-book-request-model.md) | Body, Required | - |

## Response Type

[`Task<Models.ReservationPushResponse>`](../../doc/models/reservation-push-response.md)

## Example Usage

```csharp
var body = new RequestToBookRequestModel();
body.RezcasterNotificationRequest = new ReservationNotificationObject();
body.RezcasterNotificationRequest.ReservationId = "107";
body.RezcasterNotificationRequest.ProductId = "1234816374";
body.RezcasterNotificationRequest.SupplierId = "3731837";
body.RezcasterNotificationRequest.ChannelName = "Airbnb";
body.RezcasterNotificationRequest.ConfirmationId = "dasdasd";
body.RezcasterNotificationRequest.UniqueKey = "uniqueKey4";
body.RezcasterNotificationRequest.NewState = ReservationStateEnum.Cancelled;
body.RezcasterNotificationRequest.CustomerName = "John Smith";
body.RezcasterNotificationRequest.FromDate = DateTime.Parse("2016-03-13");
body.RezcasterNotificationRequest.ToDate = DateTime.Parse("2016-03-13");
body.RezcasterNotificationRequest.Adult = 2;
body.RezcasterNotificationRequest.Child = 0;
body.RezcasterNotificationRequest.Email = "andrewtesttest222@gmail.com";
body.RezcasterNotificationRequest.Total = 23.76;
body.RezcasterNotificationRequest.Fees = new List<ReservationFeeNotificationModel>();

var bodyRezcasterNotificationRequestFees0 = new ReservationFeeNotificationModel();
bodyRezcasterNotificationRequestFees0.Name = "Cleaning Fee";
bodyRezcasterNotificationRequestFees0.MValue = 144.53;
bodyRezcasterNotificationRequestFees0.Id = "937-4";
body.RezcasterNotificationRequest.Fees.Add(bodyRezcasterNotificationRequestFees0);

var bodyRezcasterNotificationRequestFees1 = new ReservationFeeNotificationModel();
bodyRezcasterNotificationRequestFees1.Name = "Cleaning Fee";
bodyRezcasterNotificationRequestFees1.MValue = 144.54;
bodyRezcasterNotificationRequestFees1.Id = "937-4";
body.RezcasterNotificationRequest.Fees.Add(bodyRezcasterNotificationRequestFees1);

body.RezcasterNotificationRequest.Taxes = new List<ReservationTaxNotificationModel>();

var bodyRezcasterNotificationRequestTaxes0 = new ReservationTaxNotificationModel();
bodyRezcasterNotificationRequestTaxes0.Name = "State of Florida-Lake County State Tax";
bodyRezcasterNotificationRequestTaxes0.MValue = 134.53;
bodyRezcasterNotificationRequestTaxes0.Id = "22";
body.RezcasterNotificationRequest.Taxes.Add(bodyRezcasterNotificationRequestTaxes0);

var bodyRezcasterNotificationRequestTaxes1 = new ReservationTaxNotificationModel();
bodyRezcasterNotificationRequestTaxes1.Name = "State of Florida-Lake County State Tax";
bodyRezcasterNotificationRequestTaxes1.MValue = 134.54;
bodyRezcasterNotificationRequestTaxes1.Id = "22";
body.RezcasterNotificationRequest.Taxes.Add(bodyRezcasterNotificationRequestTaxes1);

body.RezcasterNotificationRequest.Commission = new ReservationCommissionsNotificationModel();
body.RezcasterNotificationRequest.Commission.ChannelCommission = 69.7;
body.RezcasterNotificationRequest.Commission.Commission = 0.14;
body.RezcasterNotificationRequest.Rate = new ReservationRateNotifcationModel();
body.RezcasterNotificationRequest.Rate.OriginalRackRate = 16.12;
body.RezcasterNotificationRequest.Rate.NetRate = 47;
body.RezcasterNotificationRequest.Rate.NewPublishedRackRate = 87.72;
body.Action = "RESERVATION_REQUEST";
body.ReservationId = 252;
body.ExpiresAt = DateTime.Parse("2016-03-13");

try
{
    ReservationPushResponse result = await requestToBookController.RequestToBookRequestAsync(body);
}
catch (ApiException e){};
```

## Example Response *(as JSON)*

```json
{
  "altId": "45717",
  "is_error": false,
  "code": "",
  "message": "Request to book is accepted."
}
```


# Request to Book-Answer From PMS

This is an API call that you should use for accepting on avoiding requests to book.

```csharp
RequestToBookAnswerFromPMSAsync(
    Models.RequestToBookAnswerFromPMSRequest body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`Models.RequestToBookAnswerFromPMSRequest`](../../doc/models/request-to-book-answer-from-pms-request.md) | Body, Required | - |

## Response Type

[`Task<Models.APIResponseWithoutData>`](../../doc/models/api-response-without-data.md)

## Example Usage

```csharp
var body = new RequestToBookAnswerFromPMSRequest();
body.Data = new FunctionsRequestToBook();
body.Data.RequestToBookType = RequestToBookTypeEnum.DENY;
body.Data.ReservationId = 1235124634;
body.Data.RequestToBookDeclineReasonType = RequestToBookDeclineReasonTypeEnum.DATESNOTAVAILABLE;
body.Data.DeclineMessageToGuest = "these dates are not available any more. ";

try
{
    APIResponseWithoutData result = await requestToBookController.RequestToBookAnswerFromPMSAsync(body);
}
catch (ApiException e){};
```

## Example Response *(as JSON)*

```json
{
  "message": "Request to book answer accepted",
  "errorMessage": [],
  "is_error": false,
  "code": ""
}
```


# Request to Book-Test

Since you can not get the request to book on our test environment (since this first needs to be created on the channel) We provide the possibility for PMS to test this request with some random filled data in our system. So when you call this API function - we will send you push notification for the request to book for a provided property ID.

```csharp
RequestToBookTestAsync(
    Models.RequestToBookTestRequest body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`Models.RequestToBookTestRequest`](../../doc/models/request-to-book-test-request.md) | Body, Required | - |

## Response Type

[`Task<Models.APIResponseWithoutData>`](../../doc/models/api-response-without-data.md)

## Example Usage

```csharp
var body = new RequestToBookTestRequest();
body.Data = new FunctionsRequestToBookTest();
body.Data.Action = RequestToBookTestActionEnum.RESERVATIONREQUESTVOIDED;
body.Data.ProductId = 1235124634;

try
{
    APIResponseWithoutData result = await requestToBookController.RequestToBookTestAsync(body);
}
catch (ApiException e){};
```

## Example Response *(as JSON)*

```json
{
  "message": "Request to book test accepted",
  "errorMessage": [],
  "is_error": false,
  "code": "",
  "data": []
}
```

