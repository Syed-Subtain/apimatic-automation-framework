# Asynchronous Push Messages

```csharp
AsynchronousPushMessagesController asynchronousPushMessagesController = client.AsynchronousPushMessagesController;
```

## Class Name

`AsynchronousPushMessagesController`

## Methods

* [Validation Push Asynchronous Message](../../doc/controllers/asynchronous-push-messages.md#validation-push-asynchronous-message)
* [Product Image Push Asynchronous Message](../../doc/controllers/asynchronous-push-messages.md#product-image-push-asynchronous-message)


# Validation Push Asynchronous Message

This is POST request - push notifications (webhooks) which BookingPal will send on PMS endpoint (which is set in push notification API, field - asyncPush) after something is executed in BP. This is necessary since some API calls like validation, onboarding, etc are done over queue in our system, so you will get an asynchronous response.

In these requests, we do not have expected responses from the PMS system. Since these are just notifications.

Important note: In this doc to be able to test this - you need to set a full URL on the Configure button in the right section.

:information_source: **Note** This endpoint does not require authentication.

```csharp
ValidationPushAsynchronousMessageAsync(
    Models.ValidationAsynchronousPushMessageRequest body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`Models.ValidationAsynchronousPushMessageRequest`](../../doc/models/validation-asynchronous-push-message-request.md) | Body, Required | - |

## Response Type

`Task`

## Example Usage

```csharp
var body = new ValidationAsynchronousPushMessageRequest();
body.SupplierId = 636753;
body.Type = "BP_VALIDATION";
body.Validation = new List<AsynchronousValidationModel>();

var bodyValidation0 = new AsynchronousValidationModel();
bodyValidation0.ProductId = 291358;
bodyValidation0.Valid = true;
bodyValidation0.ValidationErrors = "null";
body.Validation.Add(bodyValidation0);

var bodyValidation1 = new AsynchronousValidationModel();
bodyValidation1.ProductId = 291356;
bodyValidation1.Valid = false;
bodyValidation1.ValidationErrors = "noPrice;";
body.Validation.Add(bodyValidation1);


try
{
    await asynchronousPushMessagesController.ValidationPushAsynchronousMessageAsync(body);
}
catch (ApiException e){};
```


# Product Image Push Asynchronous Message

This is POST request - push notifications (webhooks) which BookingPal will send on PMS endpoint (which is set in push notification API, field - asyncPush) after something is executed in BP. This is necessary since some API calls like validation, onboarding, etc are done over queue in our system, so you will get an asynchronous response.

In these requests, we do not have expected responses from the PMS system. Since these are just notifications.

Important note: In this doc to be able to test this - you need to set a full URL on the Configure button in the right section.

:information_source: **Note** This endpoint does not require authentication.

```csharp
ProductImagePushAsynchronousMessageAsync(
    Models.ProductImageAsynchronousPushMessageRequest body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`Models.ProductImageAsynchronousPushMessageRequest`](../../doc/models/product-image-asynchronous-push-message-request.md) | Body, Required | - |

## Response Type

`Task`

## Example Usage

```csharp
var body = new ProductImageAsynchronousPushMessageRequest();
body.SupplierId = 61692827;
body.Type = "PROCESSING_IMAGES";
body.ProcessingImage = new List<ProductImagePushNotification>();

var bodyProcessingImage0 = new ProductImagePushNotification();
bodyProcessingImage0.Name = "Riverwalk Inn Wizard";
bodyProcessingImage0.ProductId = "1235138415";
bodyProcessingImage0.Images = new List<ImagePushNotification>();

var bodyProcessingImage0Images0 = new ImagePushNotification();
bodyProcessingImage0Images0.Success = true;
bodyProcessingImage0Images0.Type = TypeEnum.IMPORT;
bodyProcessingImage0Images0.Url = "https://www.staymarquis.com/uploads/homeaway/1570665600_odQZP_bedroom62.jpg";
bodyProcessingImage0Images0.Version = "2021-01-29T11:53:31.000+0000";
bodyProcessingImage0.Images.Add(bodyProcessingImage0Images0);

bodyProcessingImage0.AltId = "123";
body.ProcessingImage.Add(bodyProcessingImage0);


try
{
    await asynchronousPushMessagesController.ProductImagePushAsynchronousMessageAsync(body);
}
catch (ApiException e){};
```

