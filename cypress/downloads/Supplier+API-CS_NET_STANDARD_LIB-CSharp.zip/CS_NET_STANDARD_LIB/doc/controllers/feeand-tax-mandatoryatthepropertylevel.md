# Feeand Tax Mandatoryatthepropertylevel

```csharp
FeeandTaxMandatoryatthepropertylevelController feeandTaxMandatoryatthepropertylevelController = client.FeeandTaxMandatoryatthepropertylevelController;
```

## Class Name

`FeeandTaxMandatoryatthepropertylevelController`

## Methods

* [Import or Update Fee and Tax Mandatory](../../doc/controllers/feeand-tax-mandatoryatthepropertylevel.md#import-or-update-fee-and-tax-mandatory)
* [Get Fee and Tax Mandatory](../../doc/controllers/feeand-tax-mandatoryatthepropertylevel.md#get-fee-and-tax-mandatory)
* [Remove Validation Settings](../../doc/controllers/feeand-tax-mandatoryatthepropertylevel.md#remove-validation-settings)


# Import or Update Fee and Tax Mandatory

This function allows the logged in user to import or update a fee and tax mandatory.

```csharp
ImportOrUpdateFeeAndTaxMandatoryAsync(
    Models.SetFeeAndTaxValidationSettingRequest body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`Models.SetFeeAndTaxValidationSettingRequest`](../../doc/models/set-fee-and-tax-validation-setting-request.md) | Body, Required | - |

## Response Type

[`Task<Models.APIResponseWithoutData>`](../../doc/models/api-response-without-data.md)

## Example Usage

```csharp
var body = new SetFeeAndTaxValidationSettingRequest();
body.Data = new FeeTaxValidationSettings();
body.Data.ValidationSettings = new List<FeeTaxMandatorySetting>();

var bodyDataValidationSettings0 = new FeeTaxMandatorySetting();
bodyDataValidationSettings0.ProductId = 1235124634;
bodyDataValidationSettings0.IsFeeMandatory = false;
bodyDataValidationSettings0.IsTaxMandatory = false;
body.Data.ValidationSettings.Add(bodyDataValidationSettings0);


try
{
    APIResponseWithoutData result = await feeAndTaxMandatoryAtThePropertyLevelController.ImportOrUpdateFeeAndTaxMandatoryAsync(body);
}
catch (ApiException e){};
```

## Example Response *(as JSON)*

```json
{
  "message": "For product ids [1235124634] the validation settings are imported!",
  "errorMessage": [],
  "is_error": false,
  "code": ""
}
```


# Get Fee and Tax Mandatory

This function allows the logged in user to get info about current set for all PM properties are fees/taxes set to be mandatory or not.

```csharp
GetFeeAndTaxMandatoryAsync()
```

## Response Type

[`Task<Models.FeeTaxValidationSettingResponse>`](../../doc/models/fee-tax-validation-setting-response.md)

## Example Usage

```csharp
try
{
    FeeTaxValidationSettingResponse result = await feeAndTaxMandatoryAtThePropertyLevelController.GetFeeAndTaxMandatoryAsync();
}
catch (ApiException e){};
```

## Example Response *(as JSON)*

```json
{
  "message": "",
  "errorMessage": [],
  "is_error": false,
  "code": "",
  "data": [
    {
      "validationSettings": [
        {
          "productId": 1235124634,
          "isFeeMandatory": false,
          "isTaxMandatory": false
        },
        {
          "productId": 1235124636,
          "isFeeMandatory": true,
          "isTaxMandatory": true
        },
        {
          "productId": 1235124637,
          "isFeeMandatory": true,
          "isTaxMandatory": true
        }
      ]
    }
  ]
}
```


# Remove Validation Settings

This function allows the logged in user to remove any setup on property level and to return on default (which is that fee/taxes are mandatory). This API call will accept a list of properties.

```csharp
RemoveValidationSettingsAsync(
    Models.PropertyListRequest body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`Models.PropertyListRequest`](../../doc/models/property-list-request.md) | Body, Required | - |

## Response Type

[`Task<Models.APIResponseWithoutData>`](../../doc/models/api-response-without-data.md)

## Example Usage

```csharp
var body = new PropertyListRequest();
body.Data = new List<int>();
body.Data.Add(1235124634);

try
{
    APIResponseWithoutData result = await feeAndTaxMandatoryAtThePropertyLevelController.RemoveValidationSettingsAsync(body);
}
catch (ApiException e){};
```

## Example Response *(as JSON)*

```json
{
  "message": "For product ids [1235124634] the validation settings will be removed!",
  "errorMessage": [],
  "is_error": false,
  "code": ""
}
```

