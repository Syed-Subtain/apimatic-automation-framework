# Product

Every API call in this section should be with PM credentials.

```csharp
ProductController productController = client.ProductController;
```

## Class Name

`ProductController`

## Methods

* [Create Product](../../doc/controllers/product.md#create-product)
* [Activation List Product](../../doc/controllers/product.md#activation-list-product)
* [Deactivation List Product](../../doc/controllers/product.md#deactivation-list-product)
* [Delete Product](../../doc/controllers/product.md#delete-product)
* [Get Product List](../../doc/controllers/product.md#get-product-list)
* [Update Product](../../doc/controllers/product.md#update-product)
* [Delete List Product](../../doc/controllers/product.md#delete-list-product)
* [Get Product by ID](../../doc/controllers/product.md#get-product-by-id)


# Create Product

This function allows a logged in user to create new product. You can only send one product in each request.

```csharp
CreateProductAsync(
    Models.CreateUpdatePropertyRequest body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`Models.CreateUpdatePropertyRequest`](../../doc/models/create-update-property-request.md) | Body, Required | - |

## Response Type

[`Task<Models.ProductResponse>`](../../doc/models/product-response.md)

## Example Usage

```csharp
var body = new CreateUpdatePropertyRequest();
body.Data = new Property();
body.Data.Name = "name6";
body.Data.Rooms = 186;
body.Data.Bathrooms = 6;
body.Data.Persons = 198;
body.Data.PropertyType = PropertyTypesEnum.PCT101;
body.Data.Currency = "currency6";
body.Data.SupportedLosRates = false;

try
{
    ProductResponse result = await productController.CreateProductAsync(body);
}
catch (ApiException e){};
```


# Activation List Product

This function allows logged in user to activate a list of products in BookingPal. Products MUST be activated successfully before they can be distributed to any channel.

Note: When a product is successfully activated it will be queued for the internal BP validation function and you will receive async push messages when the validation is completed - like it is described in the Validation section.

```csharp
ActivationListProductAsync(
    Models.PropertyListRequest body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`Models.PropertyListRequest`](../../doc/models/property-list-request.md) | Body, Required | - |

## Response Type

[`Task<Models.APIResponseWithoutData>`](../../doc/models/api-response-without-data.md)

## Example Usage

```csharp
var body = new PropertyListRequest();
body.Data = new List<int>();
body.Data.Add(1235124634);
body.Data.Add(1235124636);

try
{
    APIResponseWithoutData result = await productController.ActivationListProductAsync(body);
}
catch (ApiException e){};
```

## Example Response *(as JSON)*

```json
{
  "message": "Property with ids [1235124634, 1235124636] will be put in Queue for validation. Please expect response over push message.",
  "errorMessage": [],
  "is_error": false,
  "code": ""
}
```


# Deactivation List Product

This function allows the logged in user to deactivate a list of products. This function will also close the calendars on every channel the products have been listed on.

```csharp
DeactivationListProductAsync(
    Models.PropertyListRequest body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`Models.PropertyListRequest`](../../doc/models/property-list-request.md) | Body, Required | - |

## Response Type

[`Task<Models.APIResponseWithoutData>`](../../doc/models/api-response-without-data.md)

## Example Usage

```csharp
var body = new PropertyListRequest();
body.Data = new List<int>();
body.Data.Add(1235124634);
body.Data.Add(1235124636);

try
{
    APIResponseWithoutData result = await productController.DeactivationListProductAsync(body);
}
catch (ApiException e){};
```

## Example Response *(as JSON)*

```json
{
  "message": "Product with ids [1235124634, 1235124636] are Deactivated!",
  "errorMessage": [],
  "is_error": false,
  "code": ""
}
```


# Delete Product

This function allows the logged in user to delete product.

```csharp
DeleteProductAsync(
    string productId)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `productId` | `string` | Template, Required | Property ID |

## Response Type

[`Task<Models.APIResponseWithoutData>`](../../doc/models/api-response-without-data.md)

## Example Usage

```csharp
string productId = "1235124636";

try
{
    APIResponseWithoutData result = await productController.DeleteProductAsync(productId);
}
catch (ApiException e){};
```

## Example Response *(as JSON)*

```json
{
  "message": "Product with id 1235124636 was deleted",
  "errorMessage": [],
  "is_error": false,
  "code": ""
}
```


# Get Product List

This API call will return a list of properties that belong to the current user. This means that a user has to be logged in with products created already.
Every API call in this section should be with PM credentials.

```csharp
GetProductListAsync(
    double? page = null,
    double? limit = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `page` | `double?` | Query, Optional | The page number for the query |
| `limit` | `double?` | Query, Optional | The limit of records per each page (max 50 records per page) |

## Response Type

[`Task<Models.ProductResponse>`](../../doc/models/product-response.md)

## Example Usage

```csharp
double? page = 110.38;
double? limit = 237.24;

try
{
    ProductResponse result = await productController.GetProductListAsync(page, limit);
}
catch (ApiException e){};
```


# Update Product

This function allows a logged in user to update product details.

Request parameters and request example will be the same as in the create product API. The only field that must be added is the product id.

You need to have all other parameters which were used in the create API call that you want to keep (AltID can’t be updated). Everything that you do not send as an update will be deleted (overwritten).

Response parameters and response examples are the same as in the create product API.

```csharp
UpdateProductAsync(
    Models.CreateUpdatePropertyRequest body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`Models.CreateUpdatePropertyRequest`](../../doc/models/create-update-property-request.md) | Body, Required | - |

## Response Type

[`Task<Models.ProductResponse>`](../../doc/models/product-response.md)

## Example Usage

```csharp
var body = new CreateUpdatePropertyRequest();
body.Data = new Property();
body.Data.Name = "name6";
body.Data.Rooms = 186;
body.Data.Bathrooms = 6;
body.Data.Persons = 198;
body.Data.PropertyType = PropertyTypesEnum.PCT101;
body.Data.Currency = "currency6";
body.Data.SupportedLosRates = false;

try
{
    ProductResponse result = await productController.UpdateProductAsync(body);
}
catch (ApiException e){};
```


# Delete List Product

This function allows logged in user to delete list of products.

```csharp
DeleteListProductAsync()
```

## Response Type

[`Task<Models.APIResponseWithoutData>`](../../doc/models/api-response-without-data.md)

## Example Usage

```csharp
try
{
    APIResponseWithoutData result = await productController.DeleteListProductAsync();
}
catch (ApiException e){};
```

## Example Response *(as JSON)*

```json
{
  "message": "Product with ids [1235124636, 1235124637] was deleted",
  "errorMessage": [],
  "is_error": false,
  "code": ""
}
```


# Get Product by ID

This function allows logged in user to get a specific product.

```csharp
GetProductByIDAsync(
    string productId)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `productId` | `string` | Template, Required | Id of the property |

## Response Type

[`Task<Models.ProductResponse>`](../../doc/models/product-response.md)

## Example Usage

```csharp
string productId = "1235124634";

try
{
    ProductResponse result = await productController.GetProductByIDAsync(productId);
}
catch (ApiException e){};
```

