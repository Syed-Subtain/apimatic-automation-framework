# Licenses

```csharp
LicensesController licensesController = client.LicensesController;
```

## Class Name

`LicensesController`

## Methods

* [Put License Req](../../doc/controllers/licenses.md#put-license-req)
* [Get License Req](../../doc/controllers/licenses.md#get-license-req)
* [Bdc License Requirements](../../doc/controllers/licenses.md#bdc-license-requirements)


# Put License Req

This function allows system to send license information for a property, so channel can use it.

```csharp
PutLicenseReqAsync(
    string productId,
    Models.LicenseUpdate body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `productId` | `string` | Template, Required | Product ID |
| `body` | [`Models.LicenseUpdate`](../../doc/models/license-update.md) | Body, Required | - |

## Response Type

[`Task<Models.LicenseUpdateResponse>`](../../doc/models/license-update-response.md)

## Example Usage

```csharp
string productId = "61692799";
var body = new LicenseUpdate();
body.Data = new List<LicenseData>();

var bodyData0 = new LicenseData();
bodyData0.ContentData = new List<LicenseDataContent>();

var bodyData0ContentData0 = new LicenseDataContent();
bodyData0.ContentData.Add(bodyData0ContentData0);

bodyData0.VariantId = "variantId1";
body.Data.Add(bodyData0);

var bodyData1 = new LicenseData();
bodyData1.ContentData = new List<LicenseDataContent>();

var bodyData1ContentData0 = new LicenseDataContent();
bodyData1.ContentData.Add(bodyData1ContentData0);

var bodyData1ContentData1 = new LicenseDataContent();
bodyData1.ContentData.Add(bodyData1ContentData1);

bodyData1.VariantId = "variantId2";
body.Data.Add(bodyData1);

var bodyData2 = new LicenseData();
bodyData2.ContentData = new List<LicenseDataContent>();

var bodyData2ContentData0 = new LicenseDataContent();
bodyData2.ContentData.Add(bodyData2ContentData0);

var bodyData2ContentData1 = new LicenseDataContent();
bodyData2.ContentData.Add(bodyData2ContentData1);

var bodyData2ContentData2 = new LicenseDataContent();
bodyData2.ContentData.Add(bodyData2ContentData2);

bodyData2.VariantId = "variantId3";
body.Data.Add(bodyData2);


try
{
    LicenseUpdateResponse result = await licensesController.PutLicenseReqAsync(productId, body);
}
catch (ApiException e){};
```


# Get License Req

This function allows system to get licenses information for a property.

```csharp
GetLicenseReqAsync(
    string productId)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `productId` | `string` | Template, Required | Product ID |

## Response Type

[`Task<Models.LicenseGetResponse>`](../../doc/models/license-get-response.md)

## Example Usage

```csharp
string productId = "61692799";

try
{
    LicenseGetResponse result = await licensesController.GetLicenseReqAsync(productId);
}
catch (ApiException e){};
```


# Bdc License Requirements

This function will get the BDC License Requirements

```csharp
BdcLicenseRequirementsAsync(
    string productId)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `productId` | `string` | Template, Required | Product ID |

## Response Type

[`Task<Models.LicenseRequirementResponse>`](../../doc/models/license-requirement-response.md)

## Example Usage

```csharp
string productId = "61692799";

try
{
    LicenseRequirementResponse result = await licensesController.BdcLicenseRequirementsAsync(productId);
}
catch (ApiException e){};
```

