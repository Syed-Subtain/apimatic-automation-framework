# Ratesand Availability

```csharp
RatesandAvailabilityController ratesandAvailabilityController = client.RatesandAvailabilityController;
```

## Class Name

`RatesandAvailabilityController`

## Methods

* [Create and Update Rates and Availability](../../doc/controllers/ratesand-availability.md#create-and-update-rates-and-availability)
* [Get Rates and Availability Product ID](../../doc/controllers/ratesand-availability.md#get-rates-and-availability-product-id)


# Create and Update Rates and Availability

Create and update calls are the same. When data is sent, if the data already exists in BookingPal - that data will be updated. Otherwise it will be created (inserted). If you want to update data for some period, you should just send data for these dates. All other data (for other dates) will remain untouched. This allows you to update only changed periods and we will not delete previously sent data for other periods.

In the case of a first data push, all data for one property should be sent in one request.  When making updates or changes to existing data, then all changed data should be sent in one request.

Note: Even property is set on LOS rates - you can use this call and send rates per day with all restrictions. These rates with restrictions will be used on channels which do not allow LOS rates.
This API call can not be used for OWN properties.
Important: Maximum allowed end date in any data type is 3 years in future.

Every API call in this section should be with PM credentials.

```csharp
CreateAndUpdateRatesAndAvailabilityAsync(
    Models.CreateandUpdateRatesandAvailabilityRequest body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`Models.CreateandUpdateRatesandAvailabilityRequest`](../../doc/models/createand-update-ratesand-availability-request.md) | Body, Required | - |

## Response Type

[`Task<Models.RatesAvailabilityResponse>`](../../doc/models/rates-availability-response.md)

## Example Usage

```csharp
var body = new CreateandUpdateRatesandAvailabilityRequest();
body.Data = new RatesAvailability();
body.Data.ProductId = 192;

try
{
    RatesAvailabilityResponse result = await ratesAndAvailabilityController.CreateAndUpdateRatesAndAvailabilityAsync(body);
}
catch (ApiException e){};
```


# Get Rates and Availability Product ID

This function allows logged in users to get rates and availability for the specific product.
Every API call in this section should be with PM credentials.

```csharp
GetRatesAndAvailabilityProductIDAsync(
    string contentType,
    string productId)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `contentType` | `string` | Header, Required | - |
| `productId` | `string` | Template, Required | ID of the property |

## Response Type

[`Task<Models.RatesAvailabilityResponse>`](../../doc/models/rates-availability-response.md)

## Example Usage

```csharp
string contentType = "application/json";
string productId = "1235124634";

try
{
    RatesAvailabilityResponse result = await ratesAndAvailabilityController.GetRatesAndAvailabilityProductIDAsync(contentType, productId);
}
catch (ApiException e){};
```

