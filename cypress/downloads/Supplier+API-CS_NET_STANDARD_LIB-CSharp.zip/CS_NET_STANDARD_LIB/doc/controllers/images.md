# Images

Every API call in this section should be with PM credentials.

This is a list of functions to work with property images. Important note is that upload or delete images will be done over an automatic cron job. So it will be done some time after your call, depending on the number of requests which are waiting before your request.
Important note: Please make sure to put full URL to image, and to not use some links which will forward our system to another link since images might not be imported.

```csharp
ImagesController imagesController = client.ImagesController;
```

## Class Name

`ImagesController`

## Methods

* [Get Image List by Product ID](../../doc/controllers/images.md#get-image-list-by-product-id)
* [Fullupdateimages](../../doc/controllers/images.md#fullupdateimages)
* [Addimage](../../doc/controllers/images.md#addimage)
* [Delete List of Images](../../doc/controllers/images.md#delete-list-of-images)
* [Delete All Images Per Property](../../doc/controllers/images.md#delete-all-images-per-property)


# Get Image List by Product ID

This function allows logged in user to get image list for the existing product

```csharp
GetImageListByProductIDAsync(
    string productId)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `productId` | `string` | Template, Required | ID of the property |

## Response Type

[`Task<Models.GetImageListByProductID>`](../../doc/models/get-image-list-by-product-id.md)

## Example Usage

```csharp
string productId = "1235124634";

try
{
    GetImageListByProductID result = await imagesController.GetImageListByProductIDAsync(productId);
}
catch (ApiException e){};
```

## Example Response *(as JSON)*

```json
{
  "message": "",
  "errorMessage": [],
  "is_error": false,
  "code": "",
  "data": [
    {
      "productId": 1235124634,
      "images": [
        {
          "url": "http://aff.bstatic.com/images/hotel/max500/110/11069098.jpg",
          "tags": [
            4,
            5,
            6
          ],
          "urlMbp": "https://s3.amazonaws.com/mybookingpal/pictures/n2ujn/n2ujn/1235124634/11069098.jpg",
          "sort": 1
        },
        {
          "url": "http://aff.bstatic.com/images/hotel/max500/110/11069099.jpg",
          "tags": [
            4,
            5,
            6
          ],
          "urlMbp": "https://s3.amazonaws.com/mybookingpal/pictures/n2ujn/n2ujn/1235124634/11069099.jpg",
          "sort": 2
        },
        {
          "url": "http://aff.bstatic.com/images/hotel/max500/110/11069100.jpg",
          "tags": [
            4,
            5,
            6
          ],
          "urlMbp": "https://s3.amazonaws.com/mybookingpal/pictures/n2ujn/n2ujn/1235124634/11069100.jpg",
          "sort": 3
        },
        {
          "url": "http://aff.bstatic.com/images/hotel/max500/110/11069101.jpg",
          "tags": [
            4,
            5,
            6
          ],
          "urlMbp": "https://s3.amazonaws.com/mybookingpal/pictures/n2ujn/n2ujn/1235124634/11069101.jpg",
          "sort": 4
        },
        {
          "url": "http://aff.bstatic.com/images/hotel/max500/110/11069102.jpg",
          "tags": [
            4,
            5,
            6
          ],
          "urlMbp": "https://s3.amazonaws.com/mybookingpal/pictures/n2ujn/n2ujn/1235124634/11069102.jpg",
          "sort": 5
        },
        {
          "url": "http://aff.bstatic.com/images/hotel/max500/110/11069103.jpg",
          "tags": [
            4,
            5,
            6
          ],
          "urlMbp": "https://s3.amazonaws.com/mybookingpal/pictures/n2ujn/n2ujn/1235124634/11069103.jpg",
          "sort": 6
        },
        {
          "url": "http://aff.bstatic.com/images/hotel/max500/110/11069104.jpg",
          "tags": [
            4,
            5,
            6
          ],
          "urlMbp": "https://s3.amazonaws.com/mybookingpal/pictures/n2ujn/n2ujn/1235124634/11069104.jpg",
          "sort": 7
        },
        {
          "url": "http://aff.bstatic.com/images/hotel/max500/110/11069105.jpg",
          "tags": [
            4,
            5,
            6
          ],
          "urlMbp": "https://s3.amazonaws.com/mybookingpal/pictures/n2ujn/n2ujn/1235124634/11069105.jpg",
          "sort": 8
        },
        {
          "url": "http://aff.bstatic.com/images/hotel/max500/110/11069106.jpg",
          "tags": [
            4,
            5,
            6
          ],
          "urlMbp": "https://s3.amazonaws.com/mybookingpal/pictures/n2ujn/n2ujn/1235124634/11069106.jpg",
          "sort": 9
        },
        {
          "url": "http://aff.bstatic.com/images/hotel/max500/110/11069107.jpg",
          "tags": [
            4,
            5,
            6
          ],
          "urlMbp": "https://s3.amazonaws.com/mybookingpal/pictures/n2ujn/n2ujn/1235124634/11069107.jpg",
          "sort": 10
        },
        {
          "url": "http://aff.bstatic.com/images/hotel/max500/110/11069108.jpg",
          "tags": [
            4,
            5,
            6
          ],
          "urlMbp": "https://s3.amazonaws.com/mybookingpal/pictures/n2ujn/n2ujn/1235124634/11069108.jpg",
          "sort": 11
        },
        {
          "url": "http://aff.bstatic.com/images/hotel/max500/110/11069109.jpg",
          "tags": [
            4,
            5,
            6
          ],
          "urlMbp": "https://s3.amazonaws.com/mybookingpal/pictures/n2ujn/n2ujn/1235124634/11069109.jpg",
          "sort": 12
        }
      ]
    }
  ]
}
```


# Fullupdateimages

This function allows the logged user to upload images for the existing product. Images will be sorted in order how they are sent in the request. The first image sent in request will be used as the “Main Image”. (Image re-ordering can also be done within the BookingPal platform manually by users). Images that were in the system, and that aren’t in the request, will be deleted. So the function will do a full update of images.

```csharp
FullupdateimagesAsync(
    Models.FullupdateImagesRequest body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`Models.FullupdateImagesRequest`](../../doc/models/fullupdate-images-request.md) | Body, Required | - |

## Response Type

[`Task<Models.APIResponseWithoutData>`](../../doc/models/api-response-without-data.md)

## Example Usage

```csharp
var body = new FullupdateImagesRequest();
body.Data = new ImagesURLForFullUpdate();
body.Data.ProductId = 1234893572;
body.Data.Images = new List<AddImage>();

var bodyDataImages0 = new AddImage();
bodyDataImages0.Url = "http://aff.bstatic.com/images/hotel/max500/110/11069097.jpg";
bodyDataImages0.Tags = new List<ImageTagsEnum>();
bodyDataImages0.Tags.Add(ImageTagsEnum.Enum1);
bodyDataImages0.Tags.Add(ImageTagsEnum.Enum2);
bodyDataImages0.Tags.Add(ImageTagsEnum.Enum3);
body.Data.Images.Add(bodyDataImages0);

var bodyDataImages1 = new AddImage();
bodyDataImages1.Url = "http://aff.bstatic.com/images/hotel/max500/110/11069097.jpg";
bodyDataImages1.Tags = new List<ImageTagsEnum>();
bodyDataImages1.Tags.Add(ImageTagsEnum.Enum1);
bodyDataImages1.Tags.Add(ImageTagsEnum.Enum2);
bodyDataImages1.Tags.Add(ImageTagsEnum.Enum3);
body.Data.Images.Add(bodyDataImages1);


try
{
    APIResponseWithoutData result = await imagesController.FullupdateimagesAsync(body);
}
catch (ApiException e){};
```

## Example Response *(as JSON)*

```json
{
  "message": "Your request was received and put in queue",
  "errorMessage": [],
  "is_error": false,
  "code": ""
}
```


# Addimage

This function allows the logged in user to upload 1 image for the existing product. Every new image will be sorted to the end. The first image sent will be used as the “Main Image”. (Image re-ordering can also be done within the BookingPal platform manually by users)

```csharp
AddimageAsync(
    Models.AddImageRequest body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`Models.AddImageRequest`](../../doc/models/add-image-request.md) | Body, Required | - |

## Response Type

[`Task<Models.APIResponseWithoutData>`](../../doc/models/api-response-without-data.md)

## Example Usage

```csharp
var body = new AddImageRequest();
body.Data = new ImageURLForAdd();
body.Data.ProductId = 1234879670;
body.Data.Image = new AddImage();
body.Data.Image.Url = "http://www.pm-name.com/prop_img/1_2345_5_19.jpg";
body.Data.Image.Tags = new List<ImageTagsEnum>();
body.Data.Image.Tags.Add(ImageTagsEnum.Enum1);
body.Data.Image.Tags.Add(ImageTagsEnum.Enum2);
body.Data.Image.Tags.Add(ImageTagsEnum.Enum3);

try
{
    APIResponseWithoutData result = await imagesController.AddimageAsync(body);
}
catch (ApiException e){};
```

## Example Response *(as JSON)*

```json
{
  "message": "Your request was received and put in queue",
  "errorMessage": [],
  "is_error": false,
  "code": ""
}
```


# Delete List of Images

This function allows the logged in user to delete image(s) from the existing product.

```csharp
DeleteListOfImagesAsync()
```

## Response Type

[`Task<Models.APIResponseWithoutData>`](../../doc/models/api-response-without-data.md)

## Example Usage

```csharp
try
{
    APIResponseWithoutData result = await imagesController.DeleteListOfImagesAsync();
}
catch (ApiException e){};
```

## Example Response *(as JSON)*

```json
{
  "message": "Images are sent for processing!",
  "errorMessage": [],
  "is_error": false,
  "code": ""
}
```


# Delete All Images Per Property

This function allows logged in user to delete images.

```csharp
DeleteAllImagesPerPropertyAsync(
    string contentType,
    string productId)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `contentType` | `string` | Header, Required | - |
| `productId` | `string` | Template, Required | ID of property for which you want to delete all images |

## Response Type

[`Task<Models.APIResponseWithoutData>`](../../doc/models/api-response-without-data.md)

## Example Usage

```csharp
string contentType = "application/json";
string productId = "1235124634";

try
{
    APIResponseWithoutData result = await imagesController.DeleteAllImagesPerPropertyAsync(contentType, productId);
}
catch (ApiException e){};
```

## Example Response *(as JSON)*

```json
{
  "message": "Your request was received and put in queue",
  "errorMessage": [],
  "is_error": false,
  "code": ""
}
```

