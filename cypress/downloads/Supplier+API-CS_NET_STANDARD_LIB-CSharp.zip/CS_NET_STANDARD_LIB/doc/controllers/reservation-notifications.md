# Reservation Notifications

```csharp
ReservationNotificationsController reservationNotificationsController = client.ReservationNotificationsController;
```

## Class Name

`ReservationNotificationsController`

## Methods

* [Get Reservation by Product](../../doc/controllers/reservation-notifications.md#get-reservation-by-product)
* [Get Reservation by Id](../../doc/controllers/reservation-notifications.md#get-reservation-by-id)
* [Get Reservation by PM](../../doc/controllers/reservation-notifications.md#get-reservation-by-pm)
* [General Reservation Notification-PUSH](../../doc/controllers/reservation-notifications.md#general-reservation-notification-push)
* [New Reservation Notification-PUSH](../../doc/controllers/reservation-notifications.md#new-reservation-notification-push)
* [Reservation Cancellation Notification-PUSH](../../doc/controllers/reservation-notifications.md#reservation-cancellation-notification-push)


# Get Reservation by Product

This function allows logged-in users to get all reservations for the specific product.

```csharp
GetReservationByProductAsync(
    string productId)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `productId` | `string` | Template, Required | Product ID |

## Response Type

[`Task<Models.ReservationGetResponse>`](../../doc/models/reservation-get-response.md)

## Example Usage

```csharp
string productId = "1235124634";

try
{
    ReservationGetResponse result = await reservationNotificationsController.GetReservationByProductAsync(productId);
}
catch (ApiException e){};
```


# Get Reservation by Id

This function allows logged-in users to get reservation data by its reservation ID.

```csharp
GetReservationByIdAsync(
    string reservationId)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `reservationId` | `string` | Template, Required | Reservation ID |

## Response Type

[`Task<Models.ReservationGetResponse>`](../../doc/models/reservation-get-response.md)

## Example Usage

```csharp
string reservationId = "1235124634";

try
{
    ReservationGetResponse result = await reservationNotificationsController.GetReservationByIdAsync(reservationId);
}
catch (ApiException e){};
```


# Get Reservation by PM

This API call will return a list of reservations that belong to the current user.

```csharp
GetReservationByPMAsync(
    double? page = null,
    double? limit = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `page` | `double?` | Query, Optional | The page number for the query |
| `limit` | `double?` | Query, Optional | The limit of records per each page (max 50 records per page) |

## Response Type

[`Task<Models.ReservationGetResponse>`](../../doc/models/reservation-get-response.md)

## Example Usage

```csharp
double? page = 110.38;
double? limit = 237.24;

try
{
    ReservationGetResponse result = await reservationNotificationsController.GetReservationByPMAsync(page, limit);
}
catch (ApiException e){};
```


# General Reservation Notification-PUSH

This function sends reservation notification requests to the provided link "reservationLink" in the Push Notification API call.
This is a new API cal added instead of deprecated separate API calls for sending a new reservation request and sending cancel reservation request.

So when BookingPal gets a new reservation, or when some existing reservation is updated or canceled - we will push this POST request to the "reservationLink" link which you set in BookingPal for your PMS (in the Push Notification section).
VERY IMPORTANT: Set "reservationLink" in the Push Notification section only when you implement a new Push function API call. This will be a flag for us that you switched to the new Reservation function.

Important note: In this doc to be able to test this - you need to set a full URL on the Configure button in the right section.

Note: Credit card data will be sent only if PMS should process payment in their system.
Also, data that will be passed to PMS depends on channels - and do we get all of this data. So you should be aware that some data like for example customer address data maybe be mising.
Additional note: Some channels support modification. When you implement this function we will process modification over action type 'UPDATE' and you will get the same reservation ID as you got when the reservation is created, so you will know which reservation should be modified.

```csharp
GeneralReservationNotificationPUSHAsync(
    Models.GeneralReservationNotificationRequest body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`Models.GeneralReservationNotificationRequest`](../../doc/models/general-reservation-notification-request.md) | Body, Required | - |

## Response Type

[`Task<Models.ReservationPushResponse>`](../../doc/models/reservation-push-response.md)

## Example Usage

```csharp
var body = new GeneralReservationNotificationRequest();
body.ReservationNotificationRequest = new NewReservationNotificationObject();
body.ReservationNotificationRequest.ReservationId = "107";
body.ReservationNotificationRequest.ProductId = "1234816374";
body.ReservationNotificationRequest.SupplierId = "3731837";
body.ReservationNotificationRequest.ChannelName = "Airbnb";
body.ReservationNotificationRequest.ConfirmationId = "dasdasd";
body.ReservationNotificationRequest.UniqueKey = "uniqueKey4";
body.ReservationNotificationRequest.NewState = ReservationStateEnum.Cancelled;
body.ReservationNotificationRequest.CustomerName = "John Smith";
body.ReservationNotificationRequest.FromDate = DateTime.Parse("2016-03-13");
body.ReservationNotificationRequest.ToDate = DateTime.Parse("2016-03-13");
body.ReservationNotificationRequest.Adult = 2;
body.ReservationNotificationRequest.Child = 0;
body.ReservationNotificationRequest.Email = "andrewtesttest222@gmail.com";
body.ReservationNotificationRequest.Total = 105.94;
body.Action = GeneralReservationNotificationActionTypeEnum.CREATE;

try
{
    ReservationPushResponse result = await reservationNotificationsController.GeneralReservationNotificationPUSHAsync(body);
}
catch (ApiException e){};
```

## Example Response *(as JSON)*

```json
{
  "altId": "45717",
  "is_error": false,
  "code": "",
  "message": "Reservation is processed."
}
```


# New Reservation Notification-PUSH

DEPRECATED. Instead, check General Reservation Notification.

This function sends the request to the provided link about a new reservation. So when BookingPal gets a new reservation - we will push this POST request to the link which you set in BookingPal for your PMS (in Push Notification section).

Important note: In this doc to be able to test this - you need to set a full URL on the Configure button in the right section.

Note: Credit card data will be sent only if PMS should process payment in their system.
Also, data that will be passed to PMS depends on channels - and do we get all of this data. So we have column ‘Mandatory’ to be aware that some data will be missing if we do not get them from a channel (like some guest address data).
Additional note: Some channels support modification. At this moment we will process modification first by canceling the current reservation and then we will process the new regular reservation. In these cases for tracking purposes, you can use channel reservation ID (confirmationID) which should be the same in these cases.

:information_source: **Note** This endpoint does not require authentication.

```csharp
NewReservationNotificationPUSHAsync(
    Models.ReservationNotificationObject body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`Models.ReservationNotificationObject`](../../doc/models/reservation-notification-object.md) | Body, Required | - |

## Response Type

[`Task<Models.ReservationPushResponse>`](../../doc/models/reservation-push-response.md)

## Example Usage

```csharp
var body = new ReservationNotificationObject();
body.ReservationId = "107";
body.ProductId = "1234816374";
body.SupplierId = "3731837";
body.ChannelName = "Airbnb";
body.ConfirmationId = "dasdasd";
body.UniqueKey = "uniqueKey4";
body.NewState = ReservationStateEnum.Cancelled;
body.CustomerName = "John Smith";
body.FromDate = DateTime.Parse("2016-03-13");
body.ToDate = DateTime.Parse("2016-03-13");
body.Adult = 2;
body.Child = 0;
body.Email = "andrewtesttest222@gmail.com";
body.Total = 248.34;
body.Fees = new List<ReservationFeeNotificationModel>();

var bodyFees0 = new ReservationFeeNotificationModel();
bodyFees0.Name = "Cleaning Fee";
bodyFees0.MValue = 128.43;
bodyFees0.Id = "937-4";
body.Fees.Add(bodyFees0);

body.Taxes = new List<ReservationTaxNotificationModel>();

var bodyTaxes0 = new ReservationTaxNotificationModel();
bodyTaxes0.Name = "State of Florida-Lake County State Tax";
bodyTaxes0.MValue = 34.71;
bodyTaxes0.Id = "22";
body.Taxes.Add(bodyTaxes0);

body.Commission = new ReservationCommissionsNotificationModel();
body.Commission.ChannelCommission = 66.2;
body.Commission.Commission = 135.76;
body.Rate = new ReservationRateNotifcationModel();
body.Rate.OriginalRackRate = 62.3;
body.Rate.NetRate = 93.18;
body.Rate.NewPublishedRackRate = 41.54;

try
{
    ReservationPushResponse result = await reservationNotificationsController.NewReservationNotificationPUSHAsync(body);
}
catch (ApiException e){};
```

## Example Response *(as JSON)*

```json
{
  "altId": "45717",
  "is_error": false,
  "code": "",
  "message": "Reservation is processed."
}
```


# Reservation Cancellation Notification-PUSH

DEPRECATED. Instead, check General Reservation Notification.

This function sends the request to the provided link about the reservation cancellation. So when BookingPal gets a cancel reservation request from the channel - we will push this POST request to the link which you set in BookingPal for your PMS (in Push Notification section).

Important note: In this doc to be able to test this - you need to set a full URL on the Configure button in the right section.

:information_source: **Note** This endpoint does not require authentication.

```csharp
ReservationCancellationNotificationPUSHAsync(
    Models.CancelReservationNotificationObject body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`Models.CancelReservationNotificationObject`](../../doc/models/cancel-reservation-notification-object.md) | Body, Required | - |

## Response Type

[`Task<Models.ReservationPushResponse>`](../../doc/models/reservation-push-response.md)

## Example Usage

```csharp
var body = new CancelReservationNotificationObject();
body.ReservationId = "107";
body.ProductId = "1234816374";
body.SupplierId = 3731837;
body.ChannelName = "TestAndrew";
body.ConfirmationId = "dasdasd";
body.UniqueKey = "uniqueKey4";
body.NewState = "newState8";
body.CustomerName = "John Smith";
body.FromDate = DateTime.Parse("2016-03-13");
body.ToDate = DateTime.Parse("2016-03-13");
body.Adult = 2;
body.Child = 0;
body.Email = "andrewtesttest222@gmail.com";
body.Total = 248.34;

try
{
    ReservationPushResponse result = await reservationNotificationsController.ReservationCancellationNotificationPUSHAsync(body);
}
catch (ApiException e){};
```

## Example Response *(as JSON)*

```json
{
  "altId": "45717",
  "is_error": false,
  "code": "",
  "message": "Cancellation accepted"
}
```

