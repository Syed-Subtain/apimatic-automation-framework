# Testingofmessage AP Icalls

```csharp
TestingofmessageAPIcallsController testingofmessageAPIcallsController = client.TestingofmessageAPIcallsController;
```

## Class Name

`TestingofmessageAPIcallsController`

## Methods

* [Get Test Message Threads](../../doc/controllers/testingofmessage-ap-icalls.md#get-test-message-threads)
* [Get Test Message List for Specific Thread](../../doc/controllers/testingofmessage-ap-icalls.md#get-test-message-list-for-specific-thread)
* [Post New Test Message for Specific Thread](../../doc/controllers/testingofmessage-ap-icalls.md#post-new-test-message-for-specific-thread)


# Get Test Message Threads

This function allows the logged in user to get all message threads or message threads with an unresponded message from guest for the whole PM. You need to use PM credentials. There is also paging as optional values. If you do not pass this value, we will return the first page and 10 threads per page.

Since API calls for messages depend on channel connections and these values will exist in BookingPal only if guests on channel create some message, these calls can work only on production. So for testing purposes we’ve  built an additional endpoint with the same API calls where you will be able to test these calls.

Note: To be able to test these calls, you need to have at least 1 property, since we will in response return you messages for 1 property from your PM.

```csharp
GetTestMessageThreadsAsync(
    int page,
    int limit,
    string threadType)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `page` | `int` | Query, Required | - |
| `limit` | `int` | Query, Required | - |
| `threadType` | `string` | Template, Required | Request all threads or only threads with unanswered message {new,all} |

## Response Type

[`Task<Models.GetMessageThreadsResponse>`](../../doc/models/get-message-threads-response.md)

## Example Usage

```csharp
int page = 2;
int limit = 5;
string threadType = "threadType6";

try
{
    GetMessageThreadsResponse result = await testingOfMessageAPICallsController.GetTestMessageThreadsAsync(page, limit, threadType);
}
catch (ApiException e){};
```


# Get Test Message List for Specific Thread

Since API calls for messages depend on channel connections and these values will exist in BookingPal only if guests on channel create some message, these calls can work only on production. So for testing purposes, we’ve built an additional endpoint with the same API calls where you will be able to test these calls.

This function allows the logged-in user to get a list of all messages from passed thread Id. You need to use PM credentials

Note: To be able to test these calls, you need to have at least 1 property, since we will in response return you messages for 1 property from your PM.

```csharp
GetTestMessageListForSpecificThreadAsync(
    string threadId)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `threadId` | `string` | Template, Required | ID of thread |

## Response Type

[`Task<Models.GetMessageListForSpecificThreadResponse>`](../../doc/models/get-message-list-for-specific-thread-response.md)

## Example Usage

```csharp
string threadId = "123";

try
{
    GetMessageListForSpecificThreadResponse result = await testingOfMessageAPICallsController.GetTestMessageListForSpecificThreadAsync(threadId);
}
catch (ApiException e){};
```

## Example Response *(as JSON)*

```json
{
  "message": "",
  "errorMessage": [],
  "is_error": false,
  "code": "",
  "data": [
    {
      "messages": [
        {
          "message": "Test message",
          "createdAt": "2019-11-25T12:32:39.000+0000",
          "user": "PROPERTY_MANAGER"
        }
      ]
    }
  ]
}
```


# Post New Test Message for Specific Thread

This function will allow PM to post new messages in already existing threads. Since this call is only for testing - we will not actually save these passed values.

Since API calls for messages depend on channel connections and these values will exist in BookingPal only if guests on channel create some message, these calls can work only on production. So for testing purposes, we’ve built an additional endpoint with the same API calls where you will be able to test these calls.

Note: To be able to test these calls, you need to have at least 1 property, since we will in response return to you messages for 1 property from your PM.

```csharp
PostNewTestMessageForSpecificThreadAsync(
    Models.PostNewMessageForSpecificThreadRequest body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`Models.PostNewMessageForSpecificThreadRequest`](../../doc/models/post-new-message-for-specific-thread-request.md) | Body, Required | - |

## Response Type

[`Task<Models.APIResponseWithoutData>`](../../doc/models/api-response-without-data.md)

## Example Usage

```csharp
var body = new PostNewMessageForSpecificThreadRequest();
body.Data = new MessageRequestFromSupplier();
body.Data.ThreadId = 5656;
body.Data.Message = "new message";

try
{
    APIResponseWithoutData result = await testingOfMessageAPICallsController.PostNewTestMessageForSpecificThreadAsync(body);
}
catch (ApiException e){};
```

## Example Response *(as JSON)*

```json
{
  "message": "Your request was received and put in queue",
  "errorMessage": [],
  "is_error": false,
  "code": ""
}
```

