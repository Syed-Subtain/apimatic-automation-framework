# Push Notification

```csharp
PushNotificationController pushNotificationController = client.PushNotificationController;
```

## Class Name

`PushNotificationController`

## Methods

* [Push Notification Links](../../doc/controllers/push-notification.md#push-notification-links)
* [Get Notification Links](../../doc/controllers/push-notification.md#get-notification-links)


# Push Notification Links

Provide the links on which the requests about reservation notification will be sent. Links should be https.
These links should be set on PMS level, so please use your PMS credentials.

IMPORTANT: If you set 'reservationLink' value - all reservation push notifications will go on this endpoint (so any new reservation, cancel reservation, update reservation, request to book, request to book cancel). And before you do this - you should implement a new push reservation API call 'General Reservation Notification - PUSH' - since you will get then all reservation notifications over this method.

```csharp
PushNotificationLinksAsync(
    Models.PushNotificationLinksRequest body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`Models.PushNotificationLinksRequest`](../../doc/models/push-notification-links-request.md) | Body, Required | - |

## Response Type

[`Task<Models.PushNotificationLinksResponse>`](../../doc/models/push-notification-links-response.md)

## Example Usage

```csharp
var body = new PushNotificationLinksRequest();
body.Data = new PushNotificationLinksModel();
body.Data.BookLink = "https://newreservationnotification.link";
body.Data.CancelLink = "https://cancelreservation.link";
body.Data.AsyncPush = "https://asyncpush.link";
body.Data.RequestToBook = "https://requestToBook.link";
body.Data.ReservationLink = "https://reservation.link";

try
{
    PushNotificationLinksResponse result = await pushNotificationController.PushNotificationLinksAsync(body);
}
catch (ApiException e){};
```

## Example Response *(as JSON)*

```json
{
  "message": "",
  "errorMessage": [],
  "is_error": false,
  "code": "",
  "data": [
    {
      "bookLink": "https://newreservationnotification.link",
      "cancelLink": "https://cancelreservation.link",
      "asyncPush": "https://asyncpush.link",
      "requestToBook": "https://requestToBook.link"
    }
  ]
}
```


# Get Notification Links

This will return all notification URLs which are set. It will work on PMS level, so use PMS credentials.

```csharp
GetNotificationLinksAsync()
```

## Response Type

[`Task<Models.PushNotificationLinksResponse>`](../../doc/models/push-notification-links-response.md)

## Example Usage

```csharp
try
{
    PushNotificationLinksResponse result = await pushNotificationController.GetNotificationLinksAsync();
}
catch (ApiException e){};
```

## Example Response *(as JSON)*

```json
{
  "message": "",
  "errorMessage": [],
  "is_error": false,
  "code": "",
  "data": [
    {
      "bookLink": "https://newreservationnotification.link",
      "cancelLink": "https://cancelreservation.link",
      "asyncPush": "https://asyncpush.link",
      "requestToBook": "https://requestToBook.link",
      "reservationLink": "https://reservation.link"
    }
  ]
}
```

