# Yields

Every API call in this section should be with PM credentials.

Warning: Do not enable the Yields API if not yet certified. BookingPal will no longer certify new partners on this API.

If you are already certified to use the Yields API, no changes are required.

If your system requires the modification of a base price, please include any yields in the per night price for the applicable dates. For more advance yields and pricing strategies, please consider using length-of-stay (LOS) pricing.

```csharp
YieldsController yieldsController = client.YieldsController;
```

## Class Name

`YieldsController`

## Methods

* [Post Yield by Property Manager](../../doc/controllers/yields.md#post-yield-by-property-manager)
* [Delete YMR List by Property Manager](../../doc/controllers/yields.md#delete-ymr-list-by-property-manager)
* [Get YMR List by Property Manager](../../doc/controllers/yields.md#get-ymr-list-by-property-manager)
* [Create YMR](../../doc/controllers/yields.md#create-ymr)
* [Get YMR List by Product ID](../../doc/controllers/yields.md#get-ymr-list-by-product-id)


# Post Yield by Property Manager

This function allows user to post yield by property manager

```csharp
PostYieldByPropertyManagerAsync(
    string propertyManager,
    Models.ChannelMarkUpYield body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `propertyManager` | `string` | Template, Required | - |
| `body` | [`Models.ChannelMarkUpYield`](../../doc/models/channel-mark-up-yield.md) | Body, Required | - |

## Response Type

[`Task<Models.APIResponseWithoutData>`](../../doc/models/api-response-without-data.md)

## Example Usage

```csharp
string propertyManager = "propertyManager4";
var body = new ChannelMarkUpYield();
body.ChannelMarkup = new ChannelMarkUpYieldInfo();
body.ChannelMarkup.BeginDate = "beginDate2";
body.ChannelMarkup.EndDate = "endDate6";
body.ChannelMarkup.Amount = 101.56;
body.ChannelMarkup.Modifier = "modifier8";
body.ChannelMarkup.ChannelAbbreviation = "channelAbbreviation8";

try
{
    APIResponseWithoutData result = await yieldsController.PostYieldByPropertyManagerAsync(propertyManager, body);
}
catch (ApiException e){};
```

## Example Response *(as JSON)*

```json
{
  "message": "Property with ids [1235124634, 1235124636] will be put in Queue for validation. Please expect response over push message.",
  "errorMessage": [],
  "is_error": false,
  "code": ""
}
```


# Delete YMR List by Property Manager

This function allows the logged in user to get yield management rules list per Property Manager.

```csharp
DeleteYMRListByPropertyManagerAsync(
    string channelAbbreviation,
    string partyChannelMarkupId,
    string propertyManager)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `channelAbbreviation` | `string` | Query, Required | Channel Abbreviation |
| `partyChannelMarkupId` | `string` | Query, Required | Party Channel Markup Id |
| `propertyManager` | `string` | Template, Required | - |

## Response Type

[`Task<Models.APIResponseWithoutData>`](../../doc/models/api-response-without-data.md)

## Example Usage

```csharp
string channelAbbreviation = "BKG";
string partyChannelMarkupId = "1837282";
string propertyManager = "propertyManager4";

try
{
    APIResponseWithoutData result = await yieldsController.DeleteYMRListByPropertyManagerAsync(channelAbbreviation, partyChannelMarkupId, propertyManager);
}
catch (ApiException e){};
```


# Get YMR List by Property Manager

This function allows the logged in user to get yield management rules list per Property Manager.

```csharp
GetYMRListByPropertyManagerAsync(
    string propertyManager,
    string channelAbbreviation = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `propertyManager` | `string` | Template, Required | Property Manager ID |
| `channelAbbreviation` | `string` | Query, Optional | Channel Abbreviation ID |

## Response Type

[`Task<Models.YieldResponseByPropertyManager>`](../../doc/models/yield-response-by-property-manager.md)

## Example Usage

```csharp
string propertyManager = "1235124634";
string channelAbbreviation = "HAC";

try
{
    YieldResponseByPropertyManager result = await yieldsController.GetYMRListByPropertyManagerAsync(propertyManager, channelAbbreviation);
}
catch (ApiException e){};
```


# Create YMR

This function allows the logged-in user to add yield management rules for the specific product. Yield management rules can affect the final price of the property depending on some special conditions (like the length of stay, early booking, etc.). These rules automate price manipulations, on an inquiry by inquiry basis. When set criteria are met, they help maximize revenue and occupancy.

How is the price calculated?
The price for a night is calculated based on the basic price and the yield management rules.

- If no YMR:
  {basic price per night} = price per night
- If YMR is set it can Increase/decrease percent or increase/decrease amount:
  {basic price per night} + {yield amount} = {price per night}
  or
  {basic price per night} - {yield amount} = {price per night}

The below examples will use the scenario to walk you step by step and explain how the price is calculated based on different YMRs.
Let’s say that the basic price per night for 2016 is 100 USD.

This function is used also for updating yield. So if you already create a specific yield for some date - and you send a new one - we will update the yield for this date.
If you need to delete a specific yield type - you can send an empty list for that type.

Important: The maximum allowed end date is 3 years in the future.

```csharp
CreateYMRAsync(
    Models.CreateYieldRequest body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`Models.CreateYieldRequest`](../../doc/models/create-yield-request.md) | Body, Required | - |

## Response Type

[`Task<Models.YieldResponse>`](../../doc/models/yield-response.md)

## Example Usage

```csharp
var body = new CreateYieldRequest();
body.Data = new TransportYield();
body.Data.ProductId = 192;

try
{
    YieldResponse result = await yieldsController.CreateYMRAsync(body);
}
catch (ApiException e){};
```


# Get YMR List by Product ID

This function allows the logged in user to get yield management rules list of the specific product.

```csharp
GetYMRListByProductIDAsync(
    string productId)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `productId` | `string` | Template, Required | ID of the property |

## Response Type

[`Task<Models.YieldResponse>`](../../doc/models/yield-response.md)

## Example Usage

```csharp
string productId = "1235124634";

try
{
    YieldResponse result = await yieldsController.GetYMRListByProductIDAsync(productId);
}
catch (ApiException e){};
```

