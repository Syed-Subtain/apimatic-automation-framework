
# Reservation Commissions Notification Model

## Structure

`ReservationCommissionsNotificationModel`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ChannelCommission` | `double?` | Optional | Channel commission |
| `Commission` | `double?` | Optional | BookingPal commission |

## Example (as JSON)

```json
{
  "channelCommission": 10,
  "commission": 12
}
```

