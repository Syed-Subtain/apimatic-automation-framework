
# Rates Availability Response

Rates Availability response

## Structure

`RatesAvailabilityResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Message` | `string` | Required | text info message |
| `ErrorMessage` | `List<string>` | Required | List of error messages |
| `IsError` | `bool` | Required | Is error (default = false) |
| `Code` | `string` | Required | Code of message |
| `Data` | [`List<Models.RatesAvailability>`](../../doc/models/rates-availability.md) | Required | List of models. This is a deprecated field. It will be removed in version 3.3. (This is only for Create and update requests, so you will not get this data in response). On GET request you will get data here. |

## Example (as JSON)

```json
{
  "message": "Your request was received and put in queue",
  "errorMessage": [],
  "is_error": false,
  "code": "",
  "data": []
}
```

