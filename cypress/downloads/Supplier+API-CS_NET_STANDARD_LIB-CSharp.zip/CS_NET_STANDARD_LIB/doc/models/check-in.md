
# Check In

## Structure

`CheckIn`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Monday` | `bool` | Required | Determines if check in could be made on monday |
| `Tuesday` | `bool` | Required | Determines if check in could be made on tuesday |
| `Wednesday` | `bool` | Required | Determines if check in could be made on wednesday |
| `Thursday` | `bool` | Required | Determines if check in could be made on thursday |
| `Friday` | `bool` | Required | Determines if check in could be made on friday |
| `Saturday` | `bool` | Required | Determines if check in could be made on saturday |
| `Sunday` | `bool` | Required | Determines if check in could be made on sunday |

## Example (as JSON)

```json
{
  "monday": false,
  "tuesday": false,
  "wednesday": false,
  "thursday": false,
  "friday": false,
  "saturday": true,
  "sunday": true
}
```

