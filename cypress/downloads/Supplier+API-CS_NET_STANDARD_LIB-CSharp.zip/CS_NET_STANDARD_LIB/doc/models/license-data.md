
# License Data

## Structure

`LicenseData`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ContentData` | [`List<Models.LicenseDataContent>`](../../doc/models/license-data-content.md) | Required | - |
| `VariantId` | `string` | Required | Variant ID |

## Example (as JSON)

```json
{
  "contentData": [
    {
      "name": null,
      "value": null
    },
    {
      "name": null,
      "value": null
    },
    {
      "name": null,
      "value": null
    }
  ],
  "variantId": "variantId0"
}
```

