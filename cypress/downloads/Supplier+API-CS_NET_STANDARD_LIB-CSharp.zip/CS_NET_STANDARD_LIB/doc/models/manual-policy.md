
# Manual Policy

## Structure

`ManualPolicy`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Type` | [`Models.ManualPolicyTypeEnum`](../../doc/models/manual-policy-type-enum.md) | Required | - |
| `ManualPolicies` | [`List<Models.ManualPolicies>`](../../doc/models/manual-policies.md) | Required | Model |

## Example (as JSON)

```json
{
  "type": "FLAT",
  "manualPolicies": [
    {
      "chargeValue": 20,
      "beforeDays": 34,
      "cancellationFee": 1
    },
    {
      "chargeValue": 12,
      "beforeDays": 45,
      "cancellationFee": 2
    }
  ]
}
```

