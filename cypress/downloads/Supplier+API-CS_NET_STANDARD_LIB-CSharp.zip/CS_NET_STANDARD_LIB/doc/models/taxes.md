
# Taxes

## Structure

`Taxes`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Name` | `string` | Required | Tax name |
| `Type` | [`Models.TaxisTypeEnum?`](../../doc/models/taxis-type-enum.md) | Optional | - |
| `MValue` | `double` | Required | Tax value |
| `AltId` | `string` | Optional | Alternative Id of the tax (tax id in your system) |

## Example (as JSON)

```json
{
  "name": "Tax reTestAT",
  "type": "SalesTaxIncluded",
  "value": 55,
  "altId": "11"
}
```

