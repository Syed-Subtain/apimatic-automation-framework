
# Fee Unit Enum

## Enumeration

`FeeUnitEnum`

## Fields

| Name |
|  --- |
| `PERSTAY` |
| `PERDAY` |
| `PERPERSON` |
| `PERDAYPERPERSON` |
| `PERDAYPERPERSONEXTRA` |

## Example

```
PER_STAY
```

