
# General Reservation Notification Action Type Enum

## Enumeration

`GeneralReservationNotificationActionTypeEnum`

## Fields

| Name | Description |
|  --- | --- |
| `CREATE` | Action for new reservation. |
| `UPDATE` | Action for update of existing reservation. |
| `CANCEL` | Action for cancelling of existing reservation. |

## Example

```
CREATE
```

