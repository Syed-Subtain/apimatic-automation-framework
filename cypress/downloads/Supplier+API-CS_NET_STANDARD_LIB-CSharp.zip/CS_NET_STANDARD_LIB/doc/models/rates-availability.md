
# Rates Availability

Rates Availability model

## Structure

`RatesAvailability`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ProductId` | `int` | Required | ID of the product |
| `LeadTime` | `int?` | Optional | Number of days before reservation in which reservation couldn’t be made. Allowed values are 0-7. If this value is set on property level - it will be used before than value on PM level. |
| `Rates` | [`List<Models.Rate>`](../../doc/models/rate.md) | Optional | List of models |
| `MinStays` | [`List<Models.MinStayModel>`](../../doc/models/min-stay-model.md) | Optional | List of models |
| `MaxStays` | [`List<Models.MaxStayModel>`](../../doc/models/max-stay-model.md) | Optional | List of models |
| `Restrictions` | [`List<Models.Restriction>`](../../doc/models/restriction.md) | Optional | List of models |
| `Availabilities` | [`List<Models.AvailabilityModel>`](../../doc/models/availability-model.md) | Optional | List of models |
| `AvailableCount` | [`List<Models.AvailableCount>`](../../doc/models/available-count.md) | Optional | List of models (Only for MLT properties) |

## Example (as JSON)

```json
{
  "productId": 98,
  "leadTime": null,
  "rates": null,
  "minStays": null,
  "maxStays": null,
  "restrictions": null,
  "availabilities": null,
  "availableCount": null
}
```

