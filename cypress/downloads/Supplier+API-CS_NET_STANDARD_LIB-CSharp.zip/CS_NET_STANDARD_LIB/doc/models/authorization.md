
# Authorization

Authorization (Login) response

## Structure

`Authorization`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Token` | `string` | Required | Generated token for authorization. It must be used in every request to API as param jwt. Token is valid for 1h |
| `Message` | `string` | Required | Message |
| `IsError` | `bool` | Required | Is request success or not |
| `ErrorMessage` | `List<string>` | Required | Error Message(s) in Array format |
| `Code` | `string` | Optional | Response code |
| `OrganizationId` | `int` | Required | Organization id - PMS ID |
| `SupplierId` | `int` | Required | Supplier ID (Property Manager ID - or PMS ID - depend on account on which you are logged in) |
| `PartyId` | `int` | Required | Deprecated field. It will be removed in version 3.3. Please use supplierId field instead |
| `Name` | `string` | Required | Account name |
| `Currency` | `string` | Required | Account currency |

## Example (as JSON)

```json
{
  "message": "",
  "errorMessage": [],
  "is_error": false,
  "code": "",
  "token": "a9eaf5b0-c433-450e-991d-8011fc4aa264",
  "partyId": 61692799,
  "organizationId": 61690131,
  "name": "Update Name",
  "currency": "USD",
  "supplierId": 61692799
}
```

