
# Bedroom Type Enum

## Enumeration

`BedroomTypeEnum`

## Fields

| Name |
|  --- |
| `Bedroom` |
| `EnumLivingRoom` |

## Example

```
Bedroom
```

