
# License Requirement Response Object

## Structure

`LicenseRequirementResponseObject`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Data` | [`List<Models.LicenseRequirementsDataObjectDetail>`](../../doc/models/license-requirements-data-object-detail.md) | Optional | - |
| `Meta` | [`List<Models.LicenseRequirementMeta>`](../../doc/models/license-requirement-meta.md) | Optional | - |
| `Warnings` | `List<string>` | Optional | List of warning messages |
| `Errors` | `List<string>` | Optional | List of error messages |

## Example (as JSON)

```json
{
  "data": null,
  "meta": null,
  "warnings": null,
  "errors": null
}
```

