
# Key Collection

## Structure

`KeyCollection`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Type` | `string` | Required | required string where accepted strings = {"primary"} |
| `CheckInMethod` | [`Models.KeyCollectionCheckinmethodEnum`](../../doc/models/key-collection-checkinmethod-enum.md) | Required | - |
| `AdditionalInfo` | [`Models.KeyCollectionadditionalinformation`](../../doc/models/key-collectionadditionalinformation.md) | Required | - |

## Example (as JSON)

```json
{
  "type": "primary",
  "checkInMethod": "doorman",
  "additionalInfo": {
    "instruction": {
      "how": "how example",
      "when": "when example"
    }
  }
}
```

