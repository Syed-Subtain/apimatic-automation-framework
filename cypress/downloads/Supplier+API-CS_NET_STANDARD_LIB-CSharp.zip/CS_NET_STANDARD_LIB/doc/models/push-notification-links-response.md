
# Push Notification Links Response

## Structure

`PushNotificationLinksResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Message` | `string` | Required | text info message |
| `ErrorMessage` | `List<string>` | Required | List of error messages |
| `IsError` | `bool` | Required | Is error (default = false) |
| `Code` | `string` | Required | Code of message |
| `Data` | [`List<Models.PushNotificationLinksModel>`](../../doc/models/push-notification-links-model.md) | Required | List of Models |

## Example (as JSON)

```json
{
  "message": "",
  "errorMessage": [],
  "is_error": false,
  "code": "",
  "data": [
    {
      "bookLink": "https://newreservationnotification.link",
      "cancelLink": "https://cancelreservation.link",
      "asyncPush": "https://asyncpush.link",
      "requestToBook": "https://requestToBook.link",
      "useJson": true
    }
  ]
}
```

