
# Reservation Tax Notification Model

Model used for taxes in reservation push notification

## Structure

`ReservationTaxNotificationModel`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Id` | `string` | Optional | Tax altID (alt ID which PMS sent over API) |
| `Name` | `string` | Required | Tax name |
| `MValue` | `double` | Required | Tax value |

## Example (as JSON)

```json
{
  "id": "22",
  "name": "State of Florida-Lake County State Tax",
  "value": 5
}
```

