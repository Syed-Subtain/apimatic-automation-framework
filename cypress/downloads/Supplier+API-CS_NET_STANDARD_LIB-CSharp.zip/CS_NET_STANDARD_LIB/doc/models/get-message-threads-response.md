
# Get Message Threads Response

## Structure

`GetMessageThreadsResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Message` | `string` | Required | Text info message |
| `ErrorMessage` | `List<string>` | Required | Text info message |
| `IsError` | `bool` | Required | Is error (default = false) |
| `Code` | `string` | Required | Code of message |
| `Data` | [`List<Models.ThreadsModel>`](../../doc/models/threads-model.md) | Required | List of Models |

## Example (as JSON)

```json
{
  "message": "",
  "errorMessage": [],
  "is_error": false,
  "code": "",
  "data": [
    {
      "threads": []
    }
  ]
}
```

