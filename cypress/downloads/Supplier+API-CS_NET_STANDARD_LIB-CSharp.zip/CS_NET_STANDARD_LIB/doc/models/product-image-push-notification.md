
# Product Image Push Notification

## Structure

`ProductImagePushNotification`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Name` | `string` | Required | name of the object |
| `ProductId` | `string` | Required | product id |
| `AltId` | `string` | Optional | product alternate id |
| `Images` | [`List<Models.ImagePushNotification>`](../../doc/models/image-push-notification.md) | Required | - |

## Example (as JSON)

```json
{
  "name": null,
  "productId": null,
  "images": {
    "success": null,
    "type": "IMPORT",
    "url": null,
    "version": null
  }
}
```

