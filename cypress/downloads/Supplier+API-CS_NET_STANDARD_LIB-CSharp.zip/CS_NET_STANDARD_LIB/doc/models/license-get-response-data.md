
# License Get Response Data

## Structure

`LicenseGetResponseData`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ProductId` | `string` | Optional | name of the property |
| `Level` | `string` | Optional | Level of the property for the name above |
| `LicenseInformationResponse` | [`List<Models.LicenseInfoResponse>`](../../doc/models/license-info-response.md) | Optional | - |

## Example (as JSON)

```json
{
  "productId": null,
  "level": null,
  "licenseInformationResponse": null
}
```

