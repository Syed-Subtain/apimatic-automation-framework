
# Fee Tax Mandatory Setting

## Structure

`FeeTaxMandatorySetting`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ProductId` | `int` | Required | Product id |
| `IsFeeMandatory` | `bool` | Required | Fee is mandatory |
| `IsTaxMandatory` | `bool` | Required | Tax is mandatory |

## Example (as JSON)

```json
{
  "productId": 1235124634,
  "isFeeMandatory": false,
  "isTaxMandatory": false
}
```

