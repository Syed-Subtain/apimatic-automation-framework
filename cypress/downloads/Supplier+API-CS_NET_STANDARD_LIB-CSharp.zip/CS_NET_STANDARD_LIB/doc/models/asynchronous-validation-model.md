
# Asynchronous Validation Model

Model for Validation messages

## Structure

`AsynchronousValidationModel`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ProductId` | `int` | Required | Id of product in BookingPal |
| `ValidationErrors` | `string` | Optional | Error message - explanation what are problems if validation failed. |
| `Valid` | `bool` | Required | Is product valid |

## Example (as JSON)

```json
{
  "productId": 291356,
  "validationErrors": "noPrice;",
  "valid": false
}
```

