
# Max Stay Model

## Structure

`MaxStayModel`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `BeginDate` | `DateTime` | Required | Beginning date of date range for which max stay is applied. Date should be in format "yyyy-MM-dd" |
| `EndDate` | `DateTime` | Required | End date of date range for which max stay is applied. Date should be in format "yyyy-MM-dd" |
| `MaxStay` | `int` | Required | Number of days that will be applied for max stay |

## Example (as JSON)

```json
{
  "beginDate": "2016-03-13",
  "endDate": "2016-03-13",
  "maxStay": 24
}
```

