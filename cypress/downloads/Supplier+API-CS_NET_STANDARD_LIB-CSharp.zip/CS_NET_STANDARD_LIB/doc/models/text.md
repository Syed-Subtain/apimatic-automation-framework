
# Text

## Structure

`Text`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Language` | `string` | Required | Language 2 letter value  as ISO 639-1 code (https://en.wikipedia.org/wiki/List_of_ISO_639-1_codes) |
| `MValue` | `string` | Required | Text value. Send here only plain text. Do not use HTML or any other characters. |

## Example (as JSON)

```json
{
  "language": "EN",
  "value": "Main description on EN!"
}
```

