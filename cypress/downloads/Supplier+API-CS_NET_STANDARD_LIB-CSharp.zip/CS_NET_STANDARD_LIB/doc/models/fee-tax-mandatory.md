
# Fee Tax Mandatory

## Structure

`FeeTaxMandatory`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `IsFeeMandatory` | `bool` | Required | Used in BookingPal validator. Info does property require any fee or not. Default value is TRUE. This setup can be overridden on property level with different API call, which is stronger. |
| `IsTaxMandatory` | `bool` | Required | Used in BookingPal validator. Info does property require any tax or not. Default value is TRUE. This setup can be overridden on property level with different API call, which is stronger. |

## Example (as JSON)

```json
{
  "isFeeMandatory": true,
  "isTaxMandatory": true
}
```

