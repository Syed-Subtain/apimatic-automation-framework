
# Deposit Type Enum

First payment deposit type.

## Enumeration

`DepositTypeEnum`

## Fields

| Name |
|  --- |
| `PERCENTAGE` |
| `FLAT` |
| `NON` |

## Example

```
PERCENTAGE
```

