
# Channel Mark up Yield

## Structure

`ChannelMarkUpYield`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ChannelMarkup` | [`Models.ChannelMarkUpYieldInfo`](../../doc/models/channel-mark-up-yield-info.md) | Required | - |

## Example (as JSON)

```json
{
  "channelMarkup": {
    "beginDate": "beginDate4",
    "endDate": "endDate2",
    "amount": 237.32,
    "modifier": "modifier4",
    "channelAbbreviation": "channelAbbreviation4"
  }
}
```

