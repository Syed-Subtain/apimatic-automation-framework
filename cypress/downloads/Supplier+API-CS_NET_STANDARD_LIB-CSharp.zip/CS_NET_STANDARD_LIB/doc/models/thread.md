
# Thread

## Structure

`Thread`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Id` | `int` | Required | Thread ID |
| `LastMessageSentAt` | `string` | Required | Time when last message was sent |
| `LastMessageText` | `string` | Required | Last message text |
| `ChannelThreadId` | `string` | Optional | Channel thread ID |
| `ChannelName` | `string` | Required | Channel from where come reservation |
| `ChannelABB` | [`Models.ChannelABBEnum`](../../doc/models/channel-abb-enum.md) | Required | - |
| `GuestName` | `string` | Required | Name of guest |
| `GuestEmailAddress` | `string` | Optional | Email of guest |
| `ProductId` | `int` | Required | ID of product in BookingPal database |
| `ReservationId` | `int?` | Optional | ID of reservation |
| `DateFrom` | `DateTime` | Required | Start date of reservation. Date is in format "yyyy-MM-dd" |
| `DateTo` | `DateTime` | Required | End date of reservation. Date is in format "yyyy-MM-dd" |

## Example (as JSON)

```json
{
  "id": null,
  "lastMessageSentAt": null,
  "lastMessageText": null,
  "channelName": null,
  "channelABB": "BKG",
  "guestName": null,
  "productId": null,
  "dateFrom": null,
  "dateTo": null
}
```

