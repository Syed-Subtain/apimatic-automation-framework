
# License Update Response Data

## Structure

`LicenseUpdateResponseData`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ProductId` | `string` | Optional | product ID |
| `Response` | [`List<Models.LicenseUpdateResponseDataDetail>`](../../doc/models/license-update-response-data-detail.md) | Optional | - |

## Example (as JSON)

```json
{
  "productId": null,
  "response": null
}
```

