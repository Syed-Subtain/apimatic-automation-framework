
# Space Unit Enum

## Enumeration

`SpaceUnitEnum`

## Fields

| Name |
|  --- |
| `SQM` |
| `SQFT` |

## Example

```
SQ_M
```

