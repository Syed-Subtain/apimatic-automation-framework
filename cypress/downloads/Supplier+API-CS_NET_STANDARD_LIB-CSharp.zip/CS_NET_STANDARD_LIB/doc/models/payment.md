
# Payment

## Structure

`Payment`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `PaymentType` | [`Models.PaymentTypeEnum`](../../doc/models/payment-type-enum.md) | Required | - |
| `CreditCard` | [`Models.CreditCard`](../../doc/models/credit-card.md) | Optional | - |

## Example (as JSON)

```json
{
  "paymentType": "MAIL_CHECK",
  "creditCard": {
    "creditCardType": "POST",
    "paymentGateways": {
      "paymentGatewaysType": "AUTHORIZE_NET",
      "user": "test",
      "secret": "test",
      "additionalField1": "",
      "additionalField2": ""
    },
    "creditCardList": [
      "AMERICAN_EXPRESS",
      "DINERS_CLUB"
    ]
  }
}
```

