
# Policy

## Structure

`Policy`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `InternetPolicy` | [`Models.InternetPolicy`](../../doc/models/internet-policy.md) | Optional | - |
| `ParkingPolicy` | [`Models.ParkingPolicy`](../../doc/models/parking-policy.md) | Optional | - |
| `PetPolicy` | [`Models.PetPolicy`](../../doc/models/pet-policy.md) | Optional | - |
| `ChildrenAllowed` | `bool` | Required | Children policy |
| `SmokingAllowed` | `bool` | Required | Smoking policy |

## Example (as JSON)

```json
{
  "internetPolicy": {
    "accessInternet": true,
    "kindOfInternet": "WiFi",
    "availableInternet": "AllAreas",
    "chargeInternet": "Free"
  },
  "parkingPolicy": {
    "accessParking": true,
    "locatedParking": "OnSite",
    "privateParking": true,
    "chargeParking": "$ 150",
    "timeCostParking": "PerStay",
    "necessaryReservationParking": "NotPossible"
  },
  "petPolicy": {
    "allowedPets": "Allowed",
    "chargePets": "Free"
  },
  "childrenAllowed": true,
  "smokingAllowed": false
}
```

