
# License Update Response

## Structure

`LicenseUpdateResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Message` | `string` | Optional | text info message |
| `ErrorMessage` | `List<string>` | Optional | List of error messages |
| `IsError` | `bool?` | Optional | Is error (default = false) |
| `Code` | `string` | Optional | Code of message |
| `Data` | [`List<Models.LicenseUpdateResponseData>`](../../doc/models/license-update-response-data.md) | Optional | License Update Response Data |

## Example (as JSON)

```json
{
  "message": null,
  "errorMessage": null,
  "is_error": null,
  "code": null,
  "data": null
}
```

