
# Phone

## Structure

`Phone`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `CountryCode` | `string` | Required | Country code prefix in phone number. For example “+1”. |
| `Number` | `string` | Required | Phone number |

## Example (as JSON)

```json
{
  "countryCode": "321",
  "number": "132456"
}
```

