
# Available Count

## Structure

`AvailableCount`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `BeginDate` | `DateTime` | Required | Beginning date of date range for which count is applied. Date should be in format "yyyy-MM-dd" |
| `EndDate` | `DateTime` | Required | End date of date range for which count  is applied. Date should be in format "yyyy-MM-dd" |
| `Count` | `int` | Required | Number of available rooms |

## Example (as JSON)

```json
{
  "beginDate": "2016-03-13",
  "endDate": "2016-03-13",
  "count": 60
}
```

