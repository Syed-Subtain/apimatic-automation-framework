
# Company Details

## Structure

`CompanyDetails`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `AccountId` | `string` | Required | Unique ID of PM in PMS |
| `CompanyName` | `string` | Required | Name of PM |
| `Language` | `string` | Required | Language 2 letter value  as ISO 639-1 code |
| `FullName` | `string` | Required | First and Last Name |
| `CompanyAddress` | [`Models.CompanyAddress`](../../doc/models/company-address.md) | Required | - |
| `Website` | `string` | Required | Company (PM) website URL |
| `Email` | `string` | Required | Email of PM. Email need to be unique in BP system, so you might receive error if we already have this email in our system |
| `Phone` | [`Models.Phone`](../../doc/models/phone.md) | Required | - |
| `Password` | `string` | Optional | Password for accessing PM. If the password is not passed in the request random password will be generated and returned in response. Password will be in response only on create and if it is manually generated. Special characters are not allowed, instead use UTF-8 codes, for example instead of # use %23 |
| `Currency` | `string` | Required | PM default currency. ISO 4217 code is required |

## Example (as JSON)

```json
{
  "accountId": "132",
  "companyName": "Test PM",
  "language": "en",
  "fullName": "Test PM",
  "companyAddress": {
    "country": "US",
    "state": "Test State",
    "streetAddress": "Test Street",
    "city": "Test City",
    "zip": "13245"
  },
  "website": "www.testsite.com",
  "email": "apimaticPMemail@test.com",
  "phone": {
    "countryCode": "321",
    "number": "132456"
  },
  "password": "password",
  "currency": "USD"
}
```

