
# Reservation Rate Notifcation Model

## Structure

`ReservationRateNotifcationModel`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `OriginalRackRate` | `double?` | Optional | Original rack rate. Rate received from PMS (rate without additional channel commission or any additional markup) |
| `NetRate` | `double?` | Optional | Net rate (rate which PM will get - so without any additional commissions). |
| `NewPublishedRackRate` | `double?` | Optional | New published rack rate (rate which guest paid - rate with all commissions). |

## Example (as JSON)

```json
{
  "originalRackRate": 400,
  "netRate": 400,
  "newPublishedRackRate": 422
}
```

