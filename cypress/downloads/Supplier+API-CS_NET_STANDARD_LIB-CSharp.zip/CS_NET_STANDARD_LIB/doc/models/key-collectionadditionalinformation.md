
# Key Collectionadditionalinformation

## Structure

`KeyCollectionadditionalinformation`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Instruction` | [`Models.KeyCollectionadditionalinformationinstruction`](../../doc/models/key-collectionadditionalinformationinstruction.md) | Required | - |

## Example (as JSON)

```json
{
  "instruction": {
    "how": "how example",
    "when": "when example"
  }
}
```

