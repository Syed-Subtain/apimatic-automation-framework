
# Fee Value Type Enum

Value Type {FLAT, PERCENT}

## Enumeration

`FeeValueTypeEnum`

## Fields

| Name | Description |
|  --- | --- |
| `FLAT` | Value of fee will be added in Quote |
| `PERCENT` | Fee will be charged like percent value of rent |

## Example

```
FLAT
```

