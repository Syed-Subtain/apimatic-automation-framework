
# Payment Gateways Type Enum

## Enumeration

`PaymentGatewaysTypeEnum`

## Fields

| Name |
|  --- |
| `PAYPAL` |
| `AUTHORIZENET` |
| `BRIDGEPAY` |
| `PAYBOX` |
| `DIBS` |
| `OGONE` |
| `DOCDATA` |
| `PAYGATE` |

## Example

```
PAYPAL
```

