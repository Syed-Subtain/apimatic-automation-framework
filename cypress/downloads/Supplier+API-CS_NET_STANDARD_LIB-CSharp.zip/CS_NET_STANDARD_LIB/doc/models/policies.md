
# Policies

## Structure

`Policies`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `PaymentPolicy` | [`Models.PaymentPolicy`](../../doc/models/payment-policy.md) | Required | - |
| `CancellationPolicy` | [`Models.CancellationPolicy`](../../doc/models/cancellation-policy.md) | Required | - |
| `FeeTaxMandatory` | [`Models.FeeTaxMandatory`](../../doc/models/fee-tax-mandatory.md) | Required | - |
| `Terms` | `string` | Required | Full URL to PM terms and conditions |
| `CheckInTime` | `string` | Required | Time of Check in (HH:MM:SS) |
| `CheckOutTime` | `string` | Required | Time of Check out (HH:MM:SS) |
| `LeadTime` | `int` | Required | Minimum number of days before check-in for which reservation is allowed to be booked. Allowed values are 0-7. |

## Example (as JSON)

```json
{
  "paymentPolicy": {
    "type": "SPLIT",
    "splitPayment": {
      "depositType": "FLAT",
      "value": 4,
      "secondPaymentDays": 30
    }
  },
  "cancellationPolicy": {
    "type": "MANUAL",
    "manualPolicy": {
      "type": "FLAT",
      "manualPolicies": [
        {
          "chargeValue": 20,
          "beforeDays": 34,
          "cancellationFee": 1
        },
        {
          "chargeValue": 12,
          "beforeDays": 45,
          "cancellationFee": 2
        }
      ]
    }
  },
  "feeTaxMandatory": {
    "isFeeMandatory": true,
    "isTaxMandatory": true
  },
  "terms": "www.test.com",
  "checkInTime": "36000",
  "checkOutTime": "57600",
  "leadTime": 2
}
```

