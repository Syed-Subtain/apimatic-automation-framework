
# Channel Mark up Yield Info

## Structure

`ChannelMarkUpYieldInfo`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `BeginDate` | `string` | Required | begin date |
| `EndDate` | `string` | Required | end date |
| `Amount` | `double` | Required | the amount |
| `Modifier` | `string` | Required | modifier |
| `ChannelAbbreviation` | `string` | Required | channel abbreviation |

## Example (as JSON)

```json
{
  "beginDate": "beginDate6",
  "endDate": "endDate2",
  "amount": 56.78,
  "modifier": "modifier6",
  "channelAbbreviation": "channelAbbreviation6"
}
```

