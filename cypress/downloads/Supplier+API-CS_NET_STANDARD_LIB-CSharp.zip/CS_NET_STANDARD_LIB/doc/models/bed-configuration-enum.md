
# Bed Configuration Enum

## Enumeration

`BedConfigurationEnum`

## Fields

| Name | Description |
|  --- | --- |
| `RMA58` | King bed |
| `RMA86` | Queen bed |
| `RMA102` | Sofa bed |
| `RMA113` | Twin bed |
| `RMA200` | Futon |
| `RMA201` | Murphy bed |
| `RMA203` | Single bed |
| `RMA6032` | Bunk bed |
| `RMA33` | Double bed |
| `RMA26` | Cribs |
| `RMA6038` | Extra bed |
| `RMA6118` | Couch |
| `RMA6119` | Air mattress |
| `RMA6120` | Floor mattress |
| `RMA6121` | Toddler bed |
| `RMA6122` | Hammock |

## Example

```
RMA58
```

