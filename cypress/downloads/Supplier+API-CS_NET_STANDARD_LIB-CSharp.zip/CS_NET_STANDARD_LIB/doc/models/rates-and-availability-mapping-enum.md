
# Rates and Availability Mapping Enum

Channel rates And Availability Mapping

## Enumeration

`RatesAndAvailabilityMappingEnum`

## Fields

| Name |
|  --- |
| `MapToProperty` |
| `MapToRoom` |
| `MapToRatePlan` |

## Example

```
MapToProperty
```

