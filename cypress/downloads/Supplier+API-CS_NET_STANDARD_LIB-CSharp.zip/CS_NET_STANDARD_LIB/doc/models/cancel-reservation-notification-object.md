
# Cancel Reservation Notification Object

## Structure

`CancelReservationNotificationObject`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ReservationId` | `string` | Required | Id of the reservation in BookingPal |
| `ProductId` | `string` | Required | Id of the product in BookingPal |
| `SupplierId` | `int` | Required | Id of the property manager |
| `AgentName` | `string` | Optional | DEPRECATED. Use channelName instead. Agent name/Channel name |
| `ChannelName` | `string` | Required | Agent name/Channel name |
| `ConfirmationId` | `string` | Required | Channel confirmation code |
| `UniqueKey` | `string` | Required | Unique code to identify that the request is from BookingPal. This value is unique for every PMS (and it will be different in different environments). |
| `NewState` | `string` | Required | It will always be "Cancelled" in this request |
| `CustomerName` | `string` | Required | Guest full name (in format firstName lastName) |
| `FromDate` | `DateTime` | Required | Reservation date from. Date is in format "yyyy-MM-dd" |
| `ToDate` | `DateTime` | Required | Reservation date to. Date is in format "yyyy-MM-dd" |
| `Adult` | `int` | Required | Number of adults |
| `Child` | `int` | Required | Number of children |
| `Email` | `string` | Required | Guest email |
| `Phone` | `string` | Optional | Guest phone |
| `Notes` | `string` | Optional | Guest notes |
| `CreditCardType` | `string` | Optional | Credit card type |
| `Total` | `double` | Required | Best available rate (This is the total value that guests will pay, including rate, fees, taxes, and all commissions. ) |

## Example (as JSON)

```json
{
  "reservationId": "107",
  "productId": "1234816374",
  "supplierId": 3731837,
  "channelName": "TestAndrew",
  "confirmationId": "dasdasd",
  "uniqueKey": null,
  "newState": null,
  "customerName": "John Smith",
  "fromDate": null,
  "toDate": null,
  "adult": 2,
  "child": 0,
  "email": "andrewtesttest222@gmail.com",
  "total": null
}
```

