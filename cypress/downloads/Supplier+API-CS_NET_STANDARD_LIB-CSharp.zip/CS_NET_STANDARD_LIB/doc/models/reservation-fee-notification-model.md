
# Reservation Fee Notification Model

Model used for fees in reservation push notification

## Structure

`ReservationFeeNotificationModel`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Id` | `string` | Optional | Fee altID (alt ID which PMS sent over API) |
| `Name` | `string` | Required | Fee name |
| `MValue` | `double` | Required | Fee value |

## Example (as JSON)

```json
{
  "id": "937-4",
  "name": "Cleaning Fee",
  "value": 110
}
```

