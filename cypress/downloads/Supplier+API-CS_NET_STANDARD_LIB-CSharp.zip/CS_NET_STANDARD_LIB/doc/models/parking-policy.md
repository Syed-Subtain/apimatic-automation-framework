
# Parking Policy

## Structure

`ParkingPolicy`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `AccessParking` | `bool` | Required | Access parking into properties {true,false} |
| `LocatedParking` | [`Models.LocatedParkingTypeEnum?`](../../doc/models/located-parking-type-enum.md) | Optional | - |
| `PrivateParking` | `bool?` | Optional | Parking is private or no. {true,false} |
| `ChargeParking` | `string` | Optional | Charge parking. Example: “Free”, “$ 100”. |
| `TimeCostParking` | [`Models.TimeCostParkingEnum?`](../../doc/models/time-cost-parking-enum.md) | Optional | - |
| `NecessaryReservationParking` | [`Models.ReservationParkingTypeEnum?`](../../doc/models/reservation-parking-type-enum.md) | Optional | - |

## Example (as JSON)

```json
{
  "accessParking": true,
  "locatedParking": "OnSite",
  "privateParking": true,
  "chargeParking": "$ 150",
  "timeCostParking": "PerStay",
  "necessaryReservationParking": "NotPossible"
}
```

