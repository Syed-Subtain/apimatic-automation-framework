
# License Get Response

## Structure

`LicenseGetResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Message` | `string` | Optional | text info message |
| `ErrorMessage` | `List<string>` | Optional | List of error messages |
| `IsError` | `bool?` | Optional | Is error (default = false) |
| `Code` | `string` | Optional | Code of message |
| `Data` | [`List<Models.LicenseGetResponseData>`](../../doc/models/license-get-response-data.md) | Optional | License Information Data |

## Example (as JSON)

```json
{
  "message": null,
  "errorMessage": null,
  "is_error": null,
  "code": null,
  "data": null
}
```

