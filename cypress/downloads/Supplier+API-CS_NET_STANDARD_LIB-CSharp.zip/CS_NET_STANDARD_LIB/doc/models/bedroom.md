
# Bedroom

## Structure

`Bedroom`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Beds` | [`Models.Beds`](../../doc/models/beds.md) | Required | - |
| `Type` | [`Models.BedroomTypeEnum`](../../doc/models/bedroom-type-enum.md) | Required | - |
| `PrivateBathroom` | `bool` | Required | Room have private bathroom |

## Example (as JSON)

```json
{
  "beds": {
    "bed": [
      {
        "bedType": "RMA113",
        "count": 1
      },
      {
        "bedType": "RMA58",
        "count": 1
      }
    ]
  },
  "type": "Bedroom",
  "privateBathroom": false
}
```

