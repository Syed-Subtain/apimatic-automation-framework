
# Bed

## Structure

`Bed`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `BedType` | `string` | Required | Bed code BedTypes are given in Appendix. |
| `Count` | `int` | Required | Number of bed |

## Example (as JSON)

```json
{
  "bedType": "RMA113",
  "count": 1
}
```

