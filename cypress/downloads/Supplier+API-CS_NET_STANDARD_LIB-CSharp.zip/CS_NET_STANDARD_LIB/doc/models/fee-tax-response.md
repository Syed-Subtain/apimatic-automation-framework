
# Fee Tax Response

Response for Create or Get FeeTax API call

## Structure

`FeeTaxResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Message` | `string` | Required | Text info message |
| `ErrorMessage` | `List<string>` | Required | List of error messages |
| `IsError` | `bool` | Required | Is error (default = false) |
| `Code` | `string` | Required | Code of message |
| `Data` | [`List<Models.FeesandTaxes>`](../../doc/models/feesand-taxes.md) | Required | List of models |

## Example (as JSON)

```json
{
  "message": "message0",
  "errorMessage": [
    "errorMessage2",
    "errorMessage3",
    "errorMessage4"
  ],
  "is_error": false,
  "code": "code8",
  "data": [
    {
      "productId": 69,
      "fees": null,
      "taxes": null
    },
    {
      "productId": 70,
      "fees": null,
      "taxes": null
    }
  ]
}
```

