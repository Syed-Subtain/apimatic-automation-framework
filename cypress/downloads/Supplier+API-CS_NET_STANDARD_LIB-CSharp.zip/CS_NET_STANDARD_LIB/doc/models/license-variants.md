
# License Variants

## Structure

`LicenseVariants`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Id` | `string` | Optional | ID of the variant |
| `Name` | `string` | Optional | name of the variant |
| `Content` | [`List<Models.LicenseVariantsContent>`](../../doc/models/license-variants-content.md) | Optional | - |

## Example (as JSON)

```json
{
  "id": null,
  "name": null,
  "content": null
}
```

