
# License Requirement Meta

## Structure

`LicenseRequirementMeta`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Ruid` | `string` | Optional | requirement unique id meta data |

## Example (as JSON)

```json
{
  "ruid": null
}
```

