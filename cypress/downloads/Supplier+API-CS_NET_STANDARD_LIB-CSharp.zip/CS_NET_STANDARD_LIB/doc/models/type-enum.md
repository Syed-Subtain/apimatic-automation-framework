
# Type Enum

image type

## Enumeration

`TypeEnum`

## Fields

| Name |
|  --- |
| `IMPORT` |
| `DELETE` |

## Example

```
IMPORT
```

