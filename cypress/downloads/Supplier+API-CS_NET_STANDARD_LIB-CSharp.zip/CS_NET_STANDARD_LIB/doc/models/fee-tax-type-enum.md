
# Fee Tax Type Enum

## Enumeration

`FeeTaxTypeEnum`

## Fields

| Name |
|  --- |
| `TAXABLE` |
| `NOTTAXABLE` |

## Example

```
TAXABLE
```

