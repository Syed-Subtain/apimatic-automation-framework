
# Functions Request to Book

Request to book answer model

## Structure

`FunctionsRequestToBook`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `RequestToBookType` | [`Models.RequestToBookTypeEnum`](../../doc/models/request-to-book-type-enum.md) | Required | - |
| `RequestToBookDeclineReasonType` | [`Models.RequestToBookDeclineReasonTypeEnum?`](../../doc/models/request-to-book-decline-reason-type-enum.md) | Optional | - |
| `DeclineMessageToGuest` | `string` | Optional | Message to guest |
| `ReservationId` | `int` | Required | Reservation for request to book |

## Example (as JSON)

```json
{
  "requestToBookType": "DENY",
  "requestToBookDeclineReasonType": "DATES_NOT_AVAILABLE",
  "declineMessageToGuest": "these dates are not available any more. ",
  "reservationId": 1235124634
}
```

