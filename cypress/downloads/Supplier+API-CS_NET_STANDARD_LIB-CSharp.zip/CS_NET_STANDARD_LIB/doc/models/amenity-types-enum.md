
# Amenity Types Enum

## Enumeration

`AmenityTypesEnum`

## Fields

| Name | Description |
|  --- | --- |
| `ACC111` | Arboretum |
| `ACC112` | Autumn foliage |
| `ACC113` | Cave |
| `ACC114` | Duty Free |
| `ACC115` | Nude beach |
| `ACC116` | Rain forest |
| `ACC117` | Reef |
| `ACC118` | Ruins |
| `ACC119` | Outdoor lanai gazebo covered |
| `ACC120` | Volcano |
| `ACC123` | Rural |
| `ACC14` | Church |
| `ACC24` | Hospital |
| `ACC25` | Lake |
| `ACC27` | Library |
| `ACC28` | Marina |
| `ACC29` | Market |
| `ACC31` | Mountain |
| `ACC32` | Museum |
| `ACC33` | Ocean |
| `ACC39` | Recreation center |
| `ACC40` | Resort |
| `ACC41` | Restaurant |
| `ACC42` | River |
| `ACC45` | Ski area |
| `ACC47` | Store |
| `ACC5` | Beach |
| `ACC50` | Movie Theater |
| `ACC54` | Water park |
| `ACC55` | Waterfront |
| `ACC56` | Winery |
| `ACC57` | Zoo |
| `ACC59` | Festival |
| `ACC73` | Bar |
| `ACC74` | Bay |
| `ACC82` | Synagogue |
| `ACC90` | Botanical garden |
| `ACC95` | Natural attraction |
| `HAC1` | 24 Hour Reception Desk |
| `HAC101` | Wheelchair access |
| `HAC116` | Accessible parking |
| `HAC122` | Shops and commercial services |
| `HAC14` | Business library |
| `HAC149` | Grocery shopping service available |
| `HAC15` | Car rental desk |
| `HAC154` | Medical Facilities Service |
| `HAC156` | All-inclusive meal plan |
| `HAC157` | Buffet breakfast |
| `HAC159` | Continental breakfast |
| `HAC16` | Casino |
| `HAC160` | Full meal plan |
| `HAC165` | Lounges/bars |
| `HAC168` | Onsite laundry |
| `HAC173` | Breakfast served in restaurant |
| `HAC176` | Full service housekeeping |
| `HAC186` | Street side parking |
| `HAC193` | Children's play area |
| `HAC195` | Disco |
| `HAC196` | Early check-in |
| `HAC197` | Locker room |
| `HAC198` | Non-smoking rooms (generic) |
| `HAC202` | Bicycle rentals |
| `HAC204` | Late check-out available |
| `HAC21` | Coin operated laundry |
| `HAC22` | Concierge desk |
| `HAC226` | Catering services |
| `HAC228` | Business center |
| `HAC230` | Secured parking |
| `HAC231` | Racquetball |
| `HAC232` | Snow sports |
| `HAC233` | Tennis court |
| `HAC234` | Water sports |
| `HAC236` | Golf |
| `HAC237` | Horseback riding |
| `HAC238` | Oceanfront |
| `HAC239` | Beachfront |
| `HAC241` | Ironing board |
| `HAC242` | Heated guest rooms |
| `HAC246` | Thalassotherapy |
| `HAC25` | Courtyard |
| `HAC254` | Connecting rooms |
| `HAC26` | Currency exchange |
| `HAC262` | Kitchenette |
| `HAC265` | Welcome drink |
| `HAC269` | Meeting rooms |
| `HAC272` | Snow skiing |
| `HAC273` | Water skiing |
| `HAC280` | Grocery store |
| `HAC282` | Airport shuttle service |
| `HAC283` | Luggage service |
| `HAC29` | Door man |
| `HAC292` | Newspaper |
| `HAC301` | Food and beverage discount |
| `HAC309` | Welcome gift |
| `HAC310` | Hypoallergenic rooms |
| `HAC312` | Smoke-free property |
| `HAC316` | Electric car charging stations |
| `HAC32` | Duty free shop |
| `HAC327` | Events ticket service |
| `HAC33` | Elevators |
| `HAC334` | Summer terrace |
| `HAC34` | Executive floor |
| `HAC342` | Snack bar |
| `HAC345` | Fitness center |
| `HAC348` | Health and beauty services |
| `HAC36` | Express check-in |
| `HAC37` | Express check-out |
| `HAC41` | Free airport shuttle |
| `HAC42` | Free parking |
| `HAC44` | Game room |
| `HAC45` | Gift/News stand |
| `HAC49` | Heated pool |
| `HAC5` | Air conditioning |
| `HAC50` | Housekeeping - daily |
| `HAC5033` | Ski Storage |
| `HAC51` | Housekeeping - weekly |
| `HAC53` | Indoor parking |
| `HAC54` | Indoor pool |
| `HAC55` | Jacuzzi |
| `HAC60` | Live entertainment |
| `HAC6002` | Chef Services |
| `HAC6008` | Ski rental |
| `HAC6010` | Child toddler seat |
| `HAC6013` | Photographer |
| `HAC6014` | Chauffeur/cars |
| `HAC6019` | Soap/Shampoo |
| `HAC6020` | Boat |
| `HAC6024` | Self checkin |
| `HAC6025` | pack-n-play |
| `HAC6026` | Other services staff |
| `HAC6027` | Games |
| `HAC6028` | Petanque |
| `HAC6029` | Car necessary |
| `HAC6030` | Car not necessary |
| `HAC6031` | Car recommended |
| `HAC6032` | Synagogues |
| `HAC6033` | EV charger |
| `HAC6034` | Long term stays allowed |
| `HAC6035` | Cleaning before checkout |
| `HAC6036` | Beach essentials |
| `HAC6037` | Wide hallway clearance |
| `HAC6038` | Home step free access |
| `HAC6039` | Path to entrance lit at night |
| `HAC6040` | Home wide doorway |
| `HAC6041` | Flat smooth pathway to front door |
| `HAC6042` | Disabled parking spot |
| `HAC6043` | HAC6043 |
| `HAC6044` | Cycling Trips |
| `HAC6045` | Included housekeeping |
| `HAC6046` | Staffed Property |
| `HAC6047` | Near a train/subway station |
| `HAC6048` | Nearby local nightlife |
| `HAC6049` | Shared residential building |
| `HAC6050` | 24/7 Support |
| `HAC6051` | Butler |
| `HAC6052` | Concierge Services |
| `HAC6053` | In-person Check-in |
| `HAC6054` | Carbon Monoxide Detector + Smoke Detector |
| `HAC6055` | Professionally Cleaned |
| `HAC6056` | Accessible Parking: Indoor |
| `HAC6057` | Accessible Parking: Indoor, 1 spot |
| `HAC6058` | Accessible Parking: Indoor, 2 spots |
| `HAC6059` | Accessible Parking: Outdoor |
| `HAC6060` | Accessible Parking: Outdoor, 1 spot |
| `HAC6061` | Accessible Parking: Outdoor, 2 spots |
| `HAC6062` | Beach Access |
| `HAC6063` | Business Facilities |
| `HAC6064` | Courtyard: Shared |
| `HAC6065` | Courtyard: Private Use |
| `HAC6066` | Fire Pit |
| `HAC6067` | Fitness Center: Access to community facilities |
| `HAC6068` | Fitness Center: Private |
| `HAC6069` | Heli-pad |
| `HAC6070` | Home Theatre System |
| `HAC6072` | Lakefront |
| `HAC6073` | Laundry Facilities |
| `HAC6074` | Outdoor Dining Area: Private |
| `HAC6075` | Outdoor Dining Area: Shared |
| `HAC6076` | Outdoor Dining Area: Screened-in |
| `HAC6077` | Outdoor Dining Area: Seats 10 |
| `HAC6078` | Outdoor Dining Area: Seats 12 |
| `HAC6079` | Outdoor Dining Area: Seats 20+ |
| `HAC6080` | Outdoor Furniture Area |
| `HAC6081` | Outdoor Furniture Area: Sun Loungers |
| `HAC6082` | Outdoor Furniture Area: Dining Area |
| `HAC6084` | Pool: Infinity Edge |
| `HAC6085` | Pool: Saltwater |
| `HAC6086` | Pool: Community Access |
| `HAC6087` | Riverfront |
| `HAC6088` | Sauna: Private |
| `HAC6089` | Sauna: Shared |
| `HAC6090` | Sauna: En-suite |
| `HAC6091` | Seafront |
| `HAC6092` | Ski rental: Available for additional fee |
| `HAC6093` | Ski rental: Rental cost included with stay |
| `HAC6095` | Steam room |
| `HAC6096` | Bathroom Amenities: Robe included |
| `HAC6097` | Children’s play area: Indoor |
| `HAC6098` | Children’s play area: Outdoor |
| `HAC6099` | High Chair |
| `HAC61` | Massage services |
| `HAC6100` | Table Tennis: Indoor |
| `HAC6101` | Table Tennis: Outdoor |
| `HAC6102` | Television: Plasma |
| `HAC6103` | Television: Flat screen |
| `HAC6104` | Television: Smart |
| `HAC6105` | Water Sports: Available for rent |
| `HAC6106` | Water Sports: Available for additional fee |
| `HAC6107` | Baby Sitting: On request |
| `HAC6108` | Baby Sitting: Available for additional fee |
| `HAC6109` | Bartender |
| `HAC6110` | Bartender: On request |
| `HAC6111` | Bartender: Available for additional fee |
| `HAC6113` | Butler: On request |
| `HAC6114` | Butler: Available for additional fee |
| `HAC6115` | Chef Services: Included |
| `HAC6116` | Chef Services: Available for additional fee |
| `HAC6117` | Chef Services: Working schedule |
| `HAC6118` | Concierge Services: AM only |
| `HAC6119` | Concierge Services: PM only |
| `HAC6120` | Concierge Services: Weekends only |
| `HAC6121` | Dry Cleaning: On request |
| `HAC6122` | Dry Cleaning: Available for additional fee |
| `HAC6123` | Gardener |
| `HAC6124` | Grocery shopping service available: On request |
| `HAC6125` | Grocery shopping service available: Available for additional fee |
| `HAC6126` | Housekeeping: 2x Daily |
| `HAC6127` | Housekeeping: Additional Services |
| `HAC6128` | Housekeeping: Additional services available on request |
| `HAC6129` | Housekeeping: Additional services available for extra fee |
| `HAC6130` | House Manager |
| `HAC6131` | In-person Welcome |
| `HAC6132` | Laundry Services |
| `HAC6133` | Laundry Services: Availabe for additional fee |
| `HAC6134` | Meal Included: Breakfast |
| `HAC6135` | Meal Included: 3 meals/ day |
| `HAC6136` | Meal Included: Available for additional fee |
| `HAC6137` | Valet Parking: On request |
| `HAC6138` | Valet Parking: Available for additional fee |
| `HAC62` | Nightclub |
| `HAC66` | Outdoor pool |
| `HAC7` | ATM/Cash machine |
| `HAC71` | Pool |
| `HAC76` | Restaurant |
| `HAC77` | Room service |
| `HAC78` | Safe deposit box |
| `HAC79` | Sauna |
| `HAC8` | Baby sitting |
| `HAC81` | Shoe shine stand |
| `HAC83` | Solarium |
| `HAC86` | Steam bath |
| `HAC9` | BBQ/Picnic area |
| `HAC91` | Tour/sightseeing desk |
| `HAC94` | Truck parking |
| `HAC96` | Dry cleaning |
| `HAC97` | Valet parking |
| `HAC98` | Vending machines |
| `RMA1` | Adjoining rooms |
| `RMA10` | Bathrobe |
| `RMA100` | Smoke detectors |
| `RMA102` | Sofa bed |
| `RMA103` | Speaker phone |
| `RMA104` | Stereo |
| `RMA105` | Stove |
| `RMA107` | Telephone |
| `RMA108` | Telephone for hearing impaired |
| `RMA11` | Bathroom amenities |
| `RMA111` | Trouser/Pant press |
| `RMA113` | Twin bed |
| `RMA115` | VCR movies |
| `RMA117` | Video games |
| `RMA119` | Wake-up calls |
| `RMA126` | Air conditioning individually controlled in room |
| `RMA127` | Bathtub &whirlpool separate |
| `RMA129` | CD  player |
| `RMA13` | Bathtub |
| `RMA133` | Desk with electrical outlet |
| `RMA135` | Foam pillows |
| `RMA138` | Marble bathroom |
| `RMA139` | List of movie channels available |
| `RMA14` | Bathtub only |
| `RMA141` | Oversized bathtub |
| `RMA142` | Shower |
| `RMA143` | Sink in-room |
| `RMA144` | Soundproofed room |
| `RMA146` | Tables and chairs |
| `RMA147` | Two-line phone |
| `RMA149` | Washer/dryer |
| `RMA15` | Bathtub or Shower |
| `RMA151` | Welcome gift |
| `RMA155` | Separate tub and shower |
| `RMA157` | Ceiling fan |
| `RMA158` | CNN available |
| `RMA16` | Bidet |
| `RMA161` | Accessible room |
| `RMA162` | Closets in room |
| `RMA163` | DVD player |
| `RMA164` | Mini-refrigerator |
| `RMA166` | Heating |
| `RMA167` | Toaster |
| `RMA170` | International calls |
| `RMA175` | Long distance calls |
| `RMA18` | Cable television |
| `RMA186` | Hypoallergenic bed |
| `RMA19` | Coffee/Tea maker |
| `RMA190` | Meal included - continental breakfast |
| `RMA191` | Meal included - dinner |
| `RMA192` | Meal included - lunch |
| `RMA193` | Shared bathroom |
| `RMA194` | Telephone TDD/Textphone |
| `RMA195` | Water bed |
| `RMA2` | Air conditioning |
| `RMA20` | Color television |
| `RMA200` | Futon |
| `RMA201` | Murphy bed |
| `RMA203` | Single bed |
| `RMA204` | Annex room |
| `RMA205` | Free newspaper |
| `RMA207` | Complimentary high speed internet in room |
| `RMA21` | Computer |
| `RMA210` | Satellite television |
| `RMA214` | iPod docking station |
| `RMA217` | Satellite radio |
| `RMA218` | Video on demand |
| `RMA22` | Connecting rooms |
| `RMA220` | Gulf view |
| `RMA223` | Mountain view |
| `RMA224` | Ocean view |
| `RMA227` | Premium movie channels |
| `RMA228` | Slippers |
| `RMA230` | Chair provided with desk |
| `RMA231` | Pillow top mattress |
| `RMA234` | Luxury linen type |
| `RMA242` | Instant hot water |
| `RMA245` | RMA245 |
| `RMA246` | High Definition (HD) Flat Panel Television - 32 inches or greater |
| `RMA25` | Cordless phone |
| `RMA251` | TV |
| `RMA254` | Video game player: |
| `RMA256` | Dining room seats |
| `RMA258` | Mobile/cellular phones |
| `RMA259` | Movies |
| `RMA26` | Cribs |
| `RMA260` | Multiple closets |
| `RMA262` | Safe large enough to accommodate a laptop |
| `RMA265` | Bluray player |
| `RMA268` | Non-allergenic room |
| `RMA269` | Pillow type |
| `RMA270` | Seating area with sofa/chair |
| `RMA271` | Separate toilet area |
| `RMA273` | Widescreen TV |
| `RMA276` | Separate tub or shower |
| `RMA279` | Children's playpen |
| `RMA28` | Desk |
| `RMA280` | Plunge pool |
| `RMA29` | Desk with lamp |
| `RMA3` | Alarm clock |
| `RMA32` | Dishwasher |
| `RMA33` | Double bed |
| `RMA38` | Fax machine |
| `RMA41` | Fireplace |
| `RMA45` | Free local calls |
| `RMA46` | Free movies/video |
| `RMA47` | Full kitchen |
| `RMA49` | Grecian tub |
| `RMA5` | AM/FM radio |
| `RMA50` | Hairdryer |
| `RMA5005` | Bath |
| `RMA5020` | Spa Bath |
| `RMA5085` | Dining Area |
| `RMA5086` | Electric Kettle |
| `RMA5091` | Towels/Linens At Surcharge |
| `RMA5126` | Dining Table |
| `RMA5145` | Baby safety gates |
| `RMA55` | Iron |
| `RMA56` | Ironing board |
| `RMA57` | Whirpool |
| `RMA58` | King bed |
| `RMA59` | Kitchen |
| `RMA6` | Baby listening device |
| `RMA60` | Kitchen supplies |
| `RMA6001` | Towels available |
| `RMA6003` | Cats allowed |
| `RMA6004` | Dogs allowed |
| `RMA6005` | CD library |
| `RMA6010` | Separate entrance |
| `RMA6012` | Beach view |
| `RMA6013` | Pool view |
| `RMA6017` | Water view |
| `RMA6018` | Electronic room key |
| `RMA6021` | Fire extinguishers |
| `RMA6027` | Golf view |
| `RMA6028` | Ground floor |
| `RMA6029` | Lake view |
| `RMA6030` | City view |
| `RMA6031` | Harbor view |
| `RMA6032` | Bunk bed |
| `RMA6033` | Washer |
| `RMA6034` | Dryer |
| `RMA6035` | Hangers |
| `RMA6036` | Laptop Friendly Workspace |
| `RMA6037` | Essentials |
| `RMA6038` | Extra bed |
| `RMA6039` | Patio |
| `RMA6040` | iPad |
| `RMA6042` | Living room |
| `RMA6045` | Outdoor furniture |
| `RMA6046` | Outdoor dinning area |
| `RMA6051` | Garden view |
| `RMA6052` | River view |
| `RMA6053` | Park view |
| `RMA6054` | Game Console - Xbox 360 |
| `RMA6055` | Game Console - PS2 |
| `RMA6056` | Game Console - PS3 |
| `RMA6057` | Game Console - Nintendo Wii |
| `RMA6058` | Linen |
| `RMA6059` | Carpeted floor |
| `RMA6060` | Tiled floor |
| `RMA6061` | Parquet Floor |
| `RMA6062` | Upper Floor Reachable By Stairs Only |
| `RMA6063` | Semi-Detached |
| `RMA6064` | Detached |
| `RMA6065` | Mosquito Net |
| `RMA6066` | Cleaning Included |
| `RMA6067` | Carbon monoxide detector |
| `RMA6068` | First aid kit |
| `RMA6071` | Buzzer/wireless intercom |
| `RMA6072` | Safety card |
| `RMA6073` | Lock on bedroom door |
| `RMA6074` | Smart lock |
| `RMA6075` | Private entrance |
| `RMA6076` | Outlet covers |
| `RMA6077` | Baby bath |
| `RMA6078` | Stair gates |
| `RMA6079` | Window guards |
| `RMA6080` | Table corner guards |
| `RMA6081` | Fireplace guards |
| `RMA6082` | Room darkening shades |
| `RMA6083` | Childrens dinnerware |
| `RMA6084` | Children’s books and toys |
| `RMA6085` | Breakfast not available |
| `RMA6086` | Dinner booking possible |
| `RMA6087` | Dinner not available |
| `RMA6088` | House cleaning optional |
| `RMA6089` | Lunch booking possible |
| `RMA6090` | Lunch not available |
| `RMA6091` | Wood stove |
| `RMA6092` | Dining Highchair |
| `RMA6093` | Dining Raclette |
| `RMA6094` | Dining room |
| `RMA6095` | Dining spices |
| `RMA6096` | Meals guests furnish own |
| `RMA6097` | Limited accessibility |
| `RMA6098` | Wheelchair inaccessible |
| `RMA6099` | Breakfast booking possible |
| `RMA61` | Kitchenette |
| `RMA6100` | Extra pillows and blankets |
| `RMA6101` | Ethernet connection |
| `RMA6102` | Pocket wifi |
| `RMA6103` | Cooking basics |
| `RMA6104` | Changing table |
| `RMA6105` | Bedroom step free access |
| `RMA6106` | Wide clearance to bed |
| `RMA6107` | Bedroom wide doorway |
| `RMA6108` | Accessible height bed |
| `RMA6109` | Bathroom step free access |
| `RMA6110` | Grab rails in shower and toilet |
| `RMA6111` | Accessible height toilet |
| `RMA6112` | Rollin shower with bench |
| `RMA6113` | Bathroom wide doorway |
| `RMA6114` | Tub with shower bench |
| `RMA6115` | Wide clearance to shower and toilet |
| `RMA6116` | Handheld shower hear |
| `RMA6117` | Single level home |
| `RMA6118` | Couch |
| `RMA6119` | Air mattress |
| `RMA6120` | Floor mattress |
| `RMA6121` | Toddler bed |
| `RMA6122` | Hammock |
| `RMA6123` | Freezer |
| `RMA6124` | Private yard |
| `RMA6125` | Ensuite |
| `RMA6126` | High-Speed Wifi |
| `RMA6127` | Patio/Balcony |
| `RMA6128` | Balcony: Garden View |
| `RMA6129` | Balcony: City View |
| `RMA6130` | Balcony: Ocean View |
| `RMA6131` | Balcony: Mountain View |
| `RMA6132` | Fireplace: Wood burning |
| `RMA6133` | Fireplace: Gas |
| `RMA6134` | Fireplace: Electric |
| `RMA6135` | Pizza Oven |
| `RMA6136` | Air Conditioning: Central |
| `RMA6137` | Air Conditioning: Partial |
| `RMA6138` | RMA6138 Air Conditioning: In rooms |
| `RMA6139` | Baby Crib |
| `RMA6140` | Barbeque Grill: Gas |
| `RMA6141` | Barbeque Grill: Propane |
| `RMA6142` | Barbeque Grill: Charcoal |
| `RMA6144` | Premium Linens & Towels |
| `RMA6145` | Kitchen Essentials |
| `RMA6146` | In-unit Washer |
| `RMA6147` | Self-controlled heating/cooling system |
| `RMA6148` | Private living room |
| `RMA6149` | Amenity toilet |
| `RMA6150` | Amenity combo tub shower |
| `RMA6151` | Amenity outdoor shower |
| `RMA6154` | Entertainment Books |
| `RMA6155` | Entertainment Toys |
| `RMA6156` | Security System |
| `RMA6157` | Private Dock |
| `RMA6158` | Indoor Fireplace |
| `RMA63` | Laptop |
| `RMA64` | Large desk |
| `RMA67` | Loft |
| `RMA68` | Microwave |
| `RMA69` | Minibar |
| `RMA7` | Balcony/Lanai/Terrace |
| `RMA72` | Multi-line phone |
| `RMA77` | Oven |
| `RMA78` | Pay per view movies on TV |
| `RMA8` | Barbeque grills |
| `RMA80` | Phone in bathroom |
| `RMA81` | Plates and bowls |
| `RMA85` | Private bathroom |
| `RMA86` | Queen bed |
| `RMA88` | Refrigerator |
| `RMA89` | Refrigerator with ice maker |
| `RMA9` | Bath tub with spray jets |
| `RMA91` | Rollaway bed |
| `RMA92` | Safe |
| `RMA94` | Separate closet |
| `RMA97` | Shower only |
| `RMA98` | Silverware/utensils |
| `RMA99` | Sitting area |
| `RST101` | Windsurfing |
| `RST104` | Hot tub |
| `RST105` | Hunting |
| `RST108` | Mountain climbing |
| `RST111` | Billiards |
| `RST112` | Rock climbing |
| `RST116` | Surfing |
| `RST117` | Table tennis |
| `RST120` | Snow mobiling |
| `RST123` | Outdoor pool |
| `RST127` | Bird watching |
| `RST129` | Children's pool |
| `RST13` | Cross country skiing |
| `RST133` | Gambling |
| `RST134` | Garden |
| `RST137` | Ice skating |
| `RST14` | Dart board |
| `RST149` | Canoeing |
| `RST151` | Outlet shopping |
| `RST156` | Ski in/out facilities |
| `RST157` | Tennis professional |
| `RST160` | Diving |
| `RST161` | Walking track |
| `RST169` | Bikes Available (Free) |
| `RST170` | Away from it all |
| `RST171` | Budget |
| `RST172` | Farm holidays |
| `RST173` | Historic |
| `RST174` | Holiday complex |
| `RST175` | Romantic |
| `RST176` | Tourist attractions |
| `RST177` | Eco tourism |
| `RST178` | Luaus |
| `RST179` | Paddle boating |
| `RST180` | Sledding |
| `RST181` | Thermalisme |
| `RST182` | Whale watching |
| `RST183` | Hot air ballooning |
| `RST184` | Shelling |
| `RST185` | Adventure |
| `RST186` | Rural countryside retreats |
| `RST187` | Trampoline |
| `RST20` | Fishing |
| `RST25` | Fly fishing |
| `RST34` | Golf |
| `RST35` | Gym |
| `RST4` | Basketball court |
| `RST5028` | Ski-to-door access |
| `RST60` | Hiking trail |
| `RST63` | Jet-ski |
| `RST65` | Kayaking |
| `RST67` | Miniature golf |
| `RST68` | Mountain biking trail |
| `RST7` | Boating |
| `RST71` | Outdoor tennis courts |
| `RST73` | Parasailing |
| `RST74` | Playground |
| `RST79` | River rafting |
| `RST80` | Sailing |
| `RST82` | Scuba diving |
| `RST86` | Snorkeling |
| `RST87` | Snow boarding |
| `RST9` | Bowling alley |
| `RST92` | Squash court |
| `RST96` | Tubing |

## Example

```
ACC111
```

