
# License Update Response Data Detail

## Structure

`LicenseUpdateResponseDataDetail`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Meta` | [`List<Models.LicenseRequirementMeta>`](../../doc/models/license-requirement-meta.md) | Optional | - |
| `Data` | [`List<Models.LicenseResponseIndicatorData>`](../../doc/models/license-response-indicator-data.md) | Optional | - |
| `Warnings` | `List<string>` | Optional | List of warning messages |
| `Errors` | `List<string>` | Optional | List of error messages |

## Example (as JSON)

```json
{
  "meta": null,
  "data": null,
  "warnings": null,
  "errors": null
}
```

