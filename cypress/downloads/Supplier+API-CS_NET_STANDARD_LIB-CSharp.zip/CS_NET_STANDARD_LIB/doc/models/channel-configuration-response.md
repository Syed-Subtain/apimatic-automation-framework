
# Channel Configuration Response

## Structure

`ChannelConfigurationResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Message` | `string` | Required | text info message |
| `ErrorMessage` | `List<string>` | Required | List of error messages |
| `IsError` | `bool` | Required | Is error (default = false) |
| `Code` | `string` | Required | Code of message |
| `Data` | [`List<Models.ChannelConfigurationDetail>`](../../doc/models/channel-configuration-detail.md) | Required | - |

## Example (as JSON)

```json
{
  "message": "message0",
  "errorMessage": [
    "errorMessage2",
    "errorMessage3",
    "errorMessage4"
  ],
  "is_error": false,
  "code": "code8",
  "data": [
    {
      "name": null,
      "abbreviation": null,
      "logo": null,
      "state": null,
      "supportValidation": null,
      "supportCreate": null,
      "supportConnect": null,
      "supportOpenClose": null,
      "supportStaticUpdate": null,
      "supportDynamicUpdate": null,
      "supportSynchronization": null,
      "supportCreateChannelAccount": null,
      "supportAuthorization": null,
      "supportCancelFormPm": null,
      "supportModificationFromPm": null,
      "supportGather": null,
      "supportChannelCancellationPolicy": null,
      "bookingType": null,
      "ratesAndAvailabilityMapping": null,
      "acceptsPropertyType": null,
      "nativePropertyType": null,
      "minimumProperties": null
    },
    {
      "name": null,
      "abbreviation": null,
      "logo": null,
      "state": null,
      "supportValidation": null,
      "supportCreate": null,
      "supportConnect": null,
      "supportOpenClose": null,
      "supportStaticUpdate": null,
      "supportDynamicUpdate": null,
      "supportSynchronization": null,
      "supportCreateChannelAccount": null,
      "supportAuthorization": null,
      "supportCancelFormPm": null,
      "supportModificationFromPm": null,
      "supportGather": null,
      "supportChannelCancellationPolicy": null,
      "bookingType": null,
      "ratesAndAvailabilityMapping": null,
      "acceptsPropertyType": null,
      "nativePropertyType": null,
      "minimumProperties": null
    }
  ]
}
```

