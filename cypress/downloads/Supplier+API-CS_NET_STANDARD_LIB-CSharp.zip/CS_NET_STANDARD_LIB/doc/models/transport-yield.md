
# Transport Yield

## Structure

`TransportYield`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ProductId` | `int` | Required | ID of the product |
| `Weekend` | [`List<Models.Yield>`](../../doc/models/yield.md) | Optional | Set a specific date range in which you would like to manipulate the basic price per night on weekends.  For example you will set the YMR date range from 01.07.2016-31.07.2016 param - (Friday, Saturday=0; Saturday, Sunday=1) yield amount = 20 modifier - Increase Percent Price per night in the period from 01.07.2016 to 31.07.2016 will be 100 USD in working days and 100 + 20% = 120 USD in weekends (Friday, Saturday or Saturday, Sunday, depending on what was selected). |
| `LengthOfStay` | [`List<Models.Yield>`](../../doc/models/yield.md) | Optional | Automatically applies price modifications to inquiries based on the number of nights the inquiries are for.  For example you will set the YMR date range from 01.07.2016-31.07.2017 param - {Length of Stay}. Let’s say you set 15 days. yield amount = 5 modifier - Decrease Percent Price per night if you made a reservation for 15 or more days will be 100 - 5% = 95 USD |
| `DateRange` | [`List<Models.Yield>`](../../doc/models/yield.md) | Optional | Set a specific date range in which you would like to manipulate the basic price per night.  For example you will set the YMR date range from 01.07.2016-31.07.2016 yield amount = 20 modifier - Increase Percent Price per night in the period from 01.07.2016 to 31.07.2016 will be 100 + 20% = 120 USD |
| `ChannelMarkup` | [`List<Models.ChannelMarkUpYieldInfo>`](../../doc/models/channel-mark-up-yield-info.md) | Optional | - |

## Example (as JSON)

```json
{
  "productId": 98,
  "weekend": null,
  "lengthOfStay": null,
  "dateRange": null,
  "channelMarkup": null
}
```

