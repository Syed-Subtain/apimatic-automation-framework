
# Weekend Param Enum

## Enumeration

`WeekendParamEnum`

## Fields

| Name |
|  --- |
| `DAYSOFWEEKENDSATSUN` |
| `DAYSOFWEEKENDFRISAT` |
| `DAYSOFWEEKENDFRISATSUN` |
| `DAYSOFWEEKENDTHUFRISAT` |
| `DAYSOFWEEKENDTHUFRISATSUN` |

## Example

```
DAYS_OF_WEEKEND_SAT_SUN
```

