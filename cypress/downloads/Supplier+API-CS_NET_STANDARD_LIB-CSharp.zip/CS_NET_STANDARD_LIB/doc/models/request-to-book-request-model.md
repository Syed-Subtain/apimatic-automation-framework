
# Request to Book Request Model

Model for request to book API request

## Structure

`RequestToBookRequestModel`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `RezcasterNotificationRequest` | [`Models.ReservationNotificationObject`](../../doc/models/reservation-notification-object.md) | Required | - |
| `Action` | `string` | Required | RESERVATION_REQUEST |
| `ReservationId` | `int` | Required | ID of reservation in BookingPal |
| `MessageToHost` | `string` | Optional | Message from Guest to host |
| `ExpiresAt` | `DateTime` | Required | expires time. Date is in format "yyyy-MM-dd" |

## Example (as JSON)

```json
{
  "rezcasterNotificationRequest": {
    "reservationId": "107",
    "productId": "1234816374",
    "supplierId": "3731837",
    "channelName": "Airbnb",
    "confirmationId": "dasdasd",
    "uniqueKey": null,
    "newState": "Cancelled",
    "customerName": "John Smith",
    "fromDate": null,
    "toDate": null,
    "adult": 2,
    "child": 0,
    "email": "andrewtesttest222@gmail.com",
    "total": null,
    "fees": {
      "id": "937-4",
      "name": "Cleaning Fee",
      "value": 110
    },
    "taxes": {
      "id": "22",
      "name": "State of Florida-Lake County State Tax",
      "value": 5
    },
    "commission": {
      "channelCommission": 10,
      "commission": 12
    },
    "rate": {
      "originalRackRate": 400,
      "netRate": 400,
      "newPublishedRackRate": 422
    }
  },
  "action": "RESERVATION_REQUEST",
  "reservationId": null,
  "expires_at": null
}
```

