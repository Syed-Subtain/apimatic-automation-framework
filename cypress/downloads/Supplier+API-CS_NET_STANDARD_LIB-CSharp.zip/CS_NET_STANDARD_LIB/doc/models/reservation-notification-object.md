
# Reservation Notification Object

## Structure

`ReservationNotificationObject`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ReservationId` | `string` | Required | Id of the reservation in BookingPal |
| `ProductId` | `string` | Required | Id of the product in BookingPal |
| `SupplierId` | `string` | Required | Id of the property manager |
| `AgentName` | `string` | Optional | DEPRECATED - use channelName Agent name/Channel name |
| `ChannelName` | `string` | Required | Channel name |
| `ConfirmationId` | `string` | Required | Channel confirmation code |
| `UniqueKey` | `string` | Required | Unique code to identify that the request is from BookingPal. This value is unique for every PMS (and it will be different in different environments). |
| `NewState` | [`Models.ReservationStateEnum`](../../doc/models/reservation-state-enum.md) | Required | Possible Reservation states |
| `CustomerName` | `string` | Required | Guest full name (in format firstName lastName) |
| `FromDate` | `DateTime` | Required | Reservation date from. Date is in format "yyyy-MM-dd" |
| `ToDate` | `DateTime` | Required | Reservation date to. Date is in format "yyyy-MM-dd" |
| `Adult` | `int` | Required | number of adults |
| `Child` | `int` | Required | number of children |
| `Address` | `string` | Optional | Guest address |
| `City` | `string` | Optional | Guest city |
| `Zip` | `string` | Optional | Guest zip code |
| `Country` | `string` | Optional | Guest country |
| `State` | `string` | Optional | Guest state |
| `Email` | `string` | Required | Guest email |
| `Phone` | `string` | Optional | Guest phone |
| `Notes` | `string` | Optional | Guest notes |
| `CreditCardType` | `string` | Optional | Credit card type |
| `CreditCardNumber` | `string` | Optional | Credit card number |
| `CreditCardExpirationMonth` | `string` | Optional | Credit card expiration month |
| `CreditCardExpirationYear` | `string` | Optional | Credit card expiration yea |
| `CreditCardCid` | `string` | Optional | Credit card cid |
| `Total` | `double` | Required | Best available rate (This is the total value that guests will pay, including rate, fees, taxes, and all commissions. ) |
| `Fees` | [`List<Models.ReservationFeeNotificationModel>`](../../doc/models/reservation-fee-notification-model.md) | Required | List of models |
| `Taxes` | [`List<Models.ReservationTaxNotificationModel>`](../../doc/models/reservation-tax-notification-model.md) | Required | List of models |
| `Commission` | [`Models.ReservationCommissionsNotificationModel`](../../doc/models/reservation-commissions-notification-model.md) | Required | - |
| `Rate` | [`Models.ReservationRateNotifcationModel`](../../doc/models/reservation-rate-notifcation-model.md) | Required | - |

## Example (as JSON)

```json
{
  "reservationId": "107",
  "productId": "1234816374",
  "supplierId": "3731837",
  "channelName": "Airbnb",
  "confirmationId": "dasdasd",
  "uniqueKey": null,
  "newState": "Cancelled",
  "customerName": "John Smith",
  "fromDate": null,
  "toDate": null,
  "adult": 2,
  "child": 0,
  "email": "andrewtesttest222@gmail.com",
  "total": null,
  "fees": {
    "id": "937-4",
    "name": "Cleaning Fee",
    "value": 110
  },
  "taxes": {
    "id": "22",
    "name": "State of Florida-Lake County State Tax",
    "value": 5
  },
  "commission": {
    "channelCommission": 10,
    "commission": 12
  },
  "rate": {
    "originalRackRate": 400,
    "netRate": 400,
    "newPublishedRackRate": 422
  }
}
```

