
# P Ms

Property Manager model

## Structure

`PMs`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Id` | `int` | Required | ID of the property manager |
| `Name` | `string` | Required | Name of the property manager’s company |
| `ExtraName` | `string` | Required | Contact person |
| `EmailAddress` | `string` | Required | Email of the property manager |

## Example (as JSON)

```json
{
  "id": 61690133,
  "name": "Test name",
  "extraName": "Test fullname",
  "emailAddress": "test001@gmail.com"
}
```

