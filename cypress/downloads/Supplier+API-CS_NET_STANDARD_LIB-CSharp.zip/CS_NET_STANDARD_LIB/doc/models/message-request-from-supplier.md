
# Message Request From Supplier

## Structure

`MessageRequestFromSupplier`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ThreadId` | `int` | Required | ID of thread |
| `Message` | `string` | Required | Message text |

## Example (as JSON)

```json
{
  "threadId": 5656,
  "message": "new message"
}
```

