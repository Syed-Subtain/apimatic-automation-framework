
# License Requirement Response

## Structure

`LicenseRequirementResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Message` | `string` | Required | text info message |
| `ErrorMessage` | `List<string>` | Required | List of error messages |
| `IsError` | `bool` | Required | Is error (default = false) |
| `Code` | `string` | Required | Code of message |
| `Data` | [`List<Models.LicenseReqData>`](../../doc/models/license-req-data.md) | Required | License Requirements Data |

## Example (as JSON)

```json
{
  "message": "message0",
  "errorMessage": [
    "errorMessage2",
    "errorMessage3",
    "errorMessage4"
  ],
  "is_error": false,
  "code": "code8",
  "data": [
    {
      "productId": null,
      "licenseRequirementResponse": null
    },
    {
      "productId": null,
      "licenseRequirementResponse": null
    }
  ]
}
```

