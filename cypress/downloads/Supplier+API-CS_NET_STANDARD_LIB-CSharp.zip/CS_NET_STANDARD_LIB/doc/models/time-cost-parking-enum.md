
# Time Cost Parking Enum

## Enumeration

`TimeCostParkingEnum`

## Fields

| Name |
|  --- |
| `PerHour` |
| `PerWeek` |
| `PerStay` |
| `PerDay` |

## Example

```
PerHour
```

