
# Image URL for Add

Model with one image URL for one property used for inserting new image

## Structure

`ImageURLForAdd`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ProductId` | `int` | Required | Id of the product |
| `Image` | [`Models.AddImage`](../../doc/models/add-image.md) | Required | Object for adding images |

## Example (as JSON)

```json
{
  "productId": 1234879670,
  "image": {
    "url": "http://www.pm-name.com/prop_img/1_2345_5_19.jpg",
    "tags": [
      1,
      2,
      3
    ]
  }
}
```

