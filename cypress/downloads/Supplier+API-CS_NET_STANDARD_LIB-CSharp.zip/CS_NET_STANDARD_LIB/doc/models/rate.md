
# Rate

## Structure

`Rate`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `BeginDate` | `DateTime` | Required | Beginning date of date range for which rate is applied. Date should be in format "yyyy-MM-dd" |
| `EndDate` | `DateTime` | Required | End date of date range for which rate is applied. Date should be in format "yyyy-MM-dd" |
| `Amount` | `double` | Required | Value of rate, needs to be higher than 0, otherwise it will not be imported |

## Example (as JSON)

```json
{
  "beginDate": "2016-03-13",
  "endDate": "2016-03-13",
  "amount": 56.78
}
```

