
# Split Payment

## Structure

`SplitPayment`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `DepositType` | [`Models.DepositTypeEnum`](../../doc/models/deposit-type-enum.md) | Required | First payment deposit type. |
| `MValue` | `double` | Required | First payment value |
| `SecondPaymentDays` | `int` | Required | Number of days before check-in when second payment is required. |

## Example (as JSON)

```json
{
  "depositType": "FLAT",
  "value": 4,
  "secondPaymentDays": 30
}
```

