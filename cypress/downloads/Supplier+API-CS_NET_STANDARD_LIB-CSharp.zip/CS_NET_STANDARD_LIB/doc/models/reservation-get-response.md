
# Reservation Get Response

Response for Get reservation calls

## Structure

`ReservationGetResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Message` | `string` | Required | text info message |
| `ErrorMessage` | `List<string>` | Required | List of all errors occurred. |
| `IsError` | `bool` | Required | Is error (default = false) |
| `Code` | `string` | Required | Code of message |
| `Data` | [`List<Models.ReservationNotificationObject>`](../../doc/models/reservation-notification-object.md) | Required | List of Reservation models |

## Example (as JSON)

```json
{
  "message": null,
  "errorMessage": null,
  "is_error": null,
  "code": null,
  "data": {
    "reservationId": "107",
    "productId": "1234816374",
    "supplierId": "3731837",
    "channelName": "Airbnb",
    "confirmationId": "dasdasd",
    "uniqueKey": null,
    "newState": "Cancelled",
    "customerName": "John Smith",
    "fromDate": null,
    "toDate": null,
    "adult": 2,
    "child": 0,
    "email": "andrewtesttest222@gmail.com",
    "total": null,
    "fees": {
      "id": "937-4",
      "name": "Cleaning Fee",
      "value": 110
    },
    "taxes": {
      "id": "22",
      "name": "State of Florida-Lake County State Tax",
      "value": 5
    },
    "commission": {
      "channelCommission": 10,
      "commission": 12
    },
    "rate": {
      "originalRackRate": 400,
      "netRate": 400,
      "newPublishedRackRate": 422
    }
  }
}
```

