
# Credit Card

## Structure

`CreditCard`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `CreditCardType` | [`Models.CreditCardTypeEnum`](../../doc/models/credit-card-type-enum.md) | Required | - |
| `PaymentGateways` | [`Models.PaymentGateways`](../../doc/models/payment-gateways.md) | Optional | - |
| `CreditCardList` | [`List<Models.CreditCardListEnum>`](../../doc/models/credit-card-list-enum.md) | Optional | List of acceptable credit cards. Allowed only if type is TRANSMIT. {MASTER_CARD,VISA,AMERICAN_EXPRESS,DINERS_CLUB,DISCOVER}. If POST method selected it will select all creditCardList. |

## Example (as JSON)

```json
{
  "creditCardType": "POST",
  "paymentGateways": {
    "paymentGatewaysType": "AUTHORIZE_NET",
    "user": "test",
    "secret": "test",
    "additionalField1": "",
    "additionalField2": ""
  },
  "creditCardList": [
    "AMERICAN_EXPRESS",
    "DINERS_CLUB"
  ]
}
```

