
# License Variants Content

## Structure

`LicenseVariantsContent`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Name` | `string` | Optional | name of the variant |
| `DataType` | `string` | Optional | data type of the variant |
| `Required` | `string` | Optional | indicator if content is required |

## Example (as JSON)

```json
{
  "name": null,
  "dataType": null,
  "required": null
}
```

