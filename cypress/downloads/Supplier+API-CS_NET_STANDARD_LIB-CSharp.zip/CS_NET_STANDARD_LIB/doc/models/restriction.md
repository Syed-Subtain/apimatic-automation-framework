
# Restriction

## Structure

`Restriction`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `BeginDate` | `DateTime` | Required | Beginning date of date range for which restriction is applied. Date should be in format "yyyy-MM-dd" |
| `EndDate` | `DateTime` | Required | End date of date range for which restriction is applied. Date should be in format "yyyy-MM-dd" |
| `CheckIn` | [`Models.CheckIn`](../../doc/models/check-in.md) | Required | - |
| `CheckOut` | [`Models.CheckOut`](../../doc/models/check-out.md) | Required | - |

## Example (as JSON)

```json
{
  "beginDate": null,
  "endDate": null,
  "checkIn": {
    "monday": false,
    "tuesday": false,
    "wednesday": false,
    "thursday": false,
    "friday": false,
    "saturday": true,
    "sunday": true
  },
  "checkOut": {
    "monday": false,
    "tuesday": false,
    "wednesday": false,
    "thursday": false,
    "friday": false,
    "saturday": true,
    "sunday": true
  }
}
```

