
# Functions Request to Book Test

## Structure

`FunctionsRequestToBookTest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Action` | [`Models.RequestToBookTestActionEnum`](../../doc/models/request-to-book-test-action-enum.md) | Required | Allowed values for request to book Test action |
| `ProductId` | `int` | Required | Product id for test request to book |

## Example (as JSON)

```json
{
  "action": "RESERVATION_REQUEST_VOIDED",
  "productId": 1235124634
}
```

