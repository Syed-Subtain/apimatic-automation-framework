
# Company Address

## Structure

`CompanyAddress`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Country` | `string` | Required | Country of PM. Require 2 letter ISO code |
| `State` | `string` | Required | State (Region) of PM. Required for US properties. |
| `StreetAddress` | `string` | Required | Street address of PM. |
| `City` | `string` | Required | City of PM |
| `Zip` | `string` | Required | Zip code (postal code) of PM. |

## Example (as JSON)

```json
{
  "country": "US",
  "state": "Test State",
  "streetAddress": "Test Street",
  "city": "Test City",
  "zip": "13245"
}
```

