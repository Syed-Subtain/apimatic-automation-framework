
# Location

## Structure

`Location`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `PostalCode` | `string` | Required | Postal code of property (Zip code) |
| `Country` | `string` | Required | Country of property. Require 2 letter ISO code |
| `Region` | `string` | Required | State (Region) of PM. Required for US properties. |
| `City` | `string` | Required | City of property |
| `Street` | `string` | Required | Street of property |
| `ZipCode9` | `string` | Required | Set only for US properties (format should be zip5-xxxx) |

## Example (as JSON)

```json
{
  "postalCode": "60606",
  "country": "US",
  "region": "Illinois",
  "city": "Chicago",
  "street": "210 North Wells Street",
  "zipCode9": "60606-1330"
}
```

