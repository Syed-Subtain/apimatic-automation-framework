
# Image Push Notification

## Structure

`ImagePushNotification`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Success` | `bool` | Required | Processing Image success status |
| `Type` | [`Models.TypeEnum`](../../doc/models/type-enum.md) | Required | image type |
| `Url` | `string` | Required | image URL |
| `Version` | `string` | Required | Versoin for processing image |

## Example (as JSON)

```json
{
  "success": null,
  "type": "IMPORT",
  "url": null,
  "version": null
}
```

