
# Image URL List

Model with list of URLs for one property

## Structure

`ImageURLList`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ProductId` | `int` | Required | Id of the product |
| `Images` | [`List<Models.Image>`](../../doc/models/image.md) | Required | Images for property |

## Example (as JSON)

```json
{
  "productId": 1234893572,
  "images": [
    {
      "url": "http://aff.bstatic.com/images/hotel/max500/110/11069097.jpg",
      "tags": [
        1,
        2,
        3
      ]
    },
    {
      "url": "http://aff.bstatic.com/images/hotel/max500/110/11069097.jpg",
      "tags": [
        1,
        2,
        3
      ]
    }
  ]
}
```

