
# License Response Content Data

## Structure

`LicenseResponseContentData`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Name` | `string` | Optional | name of the license |
| `MValue` | `string` | Optional | value of the license |

## Example (as JSON)

```json
{
  "name": null,
  "value": null
}
```

