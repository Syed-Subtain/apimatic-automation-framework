
# Post New Message for Specific Thread Request

## Structure

`PostNewMessageForSpecificThreadRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Data` | [`Models.MessageRequestFromSupplier`](../../doc/models/message-request-from-supplier.md) | Required | - |

## Example (as JSON)

```json
{
  "data": {
    "threadId": 5656,
    "message": "New message"
  }
}
```

