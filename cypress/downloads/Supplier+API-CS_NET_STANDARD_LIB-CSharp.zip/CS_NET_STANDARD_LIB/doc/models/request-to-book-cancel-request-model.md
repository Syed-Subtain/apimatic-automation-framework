
# Request to Book Cancel Request Model

Model for request to book cancel API request

## Structure

`RequestToBookCancelRequestModel`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Action` | `string` | Required | RESERVATION_REQUEST_VOIDED |
| `ReservationId` | `int` | Required | ID of reservation in BookingPal |

## Example (as JSON)

```json
{
  "action": "RESERVATION_REQUEST_VOIDED",
  "reservationId": 12345612345
}
```

