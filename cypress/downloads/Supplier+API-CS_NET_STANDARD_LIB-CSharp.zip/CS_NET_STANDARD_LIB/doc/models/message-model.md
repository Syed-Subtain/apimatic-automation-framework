
# Message Model

Model for one message

## Structure

`MessageModel`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Id` | `int?` | Optional | Id of message |
| `Message` | `string` | Required | Message text |
| `CreatedAt` | `string` | Required | Time when message created |
| `User` | [`Models.UserEnum`](../../doc/models/user-enum.md) | Required | - |
| `ChannelMessageId` | `string` | Optional | Channel Message ID |

## Example (as JSON)

```json
{
  "id": 68233,
  "message": "Test message",
  "createdAt": "2019-11-25T12:32:39.000+0000",
  "user": "PROPERTY_MANAGER",
  "channelMessageId": "2221139318748986368"
}
```

