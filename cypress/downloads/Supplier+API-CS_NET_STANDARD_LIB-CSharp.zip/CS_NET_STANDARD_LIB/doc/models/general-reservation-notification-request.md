
# General Reservation Notification Request

## Structure

`GeneralReservationNotificationRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ReservationNotificationRequest` | [`Models.NewReservationNotificationObject`](../../doc/models/new-reservation-notification-object.md) | Required | - |
| `Action` | [`Models.GeneralReservationNotificationActionTypeEnum`](../../doc/models/general-reservation-notification-action-type-enum.md) | Required | - |

## Example (as JSON)

```json
{
  "reservationNotificationRequest": {
    "reservationId": "107",
    "productId": "1234816374",
    "supplierId": "3731837",
    "channelName": "Airbnb",
    "confirmationId": "dasdasd",
    "uniqueKey": null,
    "newState": "Cancelled",
    "customerName": "John Smith",
    "fromDate": null,
    "toDate": null,
    "adult": 2,
    "child": 0,
    "email": "andrewtesttest222@gmail.com",
    "total": null
  },
  "action": "CREATE"
}
```

