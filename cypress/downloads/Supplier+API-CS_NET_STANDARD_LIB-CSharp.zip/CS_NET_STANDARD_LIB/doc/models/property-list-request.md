
# Property List Request

Request Model for list of properties

## Structure

`PropertyListRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Data` | `List<int>` | Required | List of property IDs (ID from BookingPal system). At least one ID need to be present. |

## Example (as JSON)

```json
{
  "data": [
    1235124636,
    1235124637
  ]
}
```

