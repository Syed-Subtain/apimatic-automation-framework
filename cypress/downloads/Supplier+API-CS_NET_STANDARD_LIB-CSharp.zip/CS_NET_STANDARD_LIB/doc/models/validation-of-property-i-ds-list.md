
# Validation of Property I Ds List

## Structure

`ValidationOfPropertyIDsList`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ProductIds` | `List<int>` | Required | List of properties for validation |

## Example (as JSON)

```json
{
  "productIds": [
    1235124634,
    1235124636
  ]
}
```

