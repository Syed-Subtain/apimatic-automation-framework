
# Yield Response by Property Manager

## Structure

`YieldResponseByPropertyManager`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Message` | `string` | Required | text info message |
| `ErrorMessage` | `List<string>` | Required | List of error messages |
| `IsError` | `bool` | Required | Is error (default = false) |
| `Code` | `string` | Required | Code of message |
| `Data` | [`Models.ChannelMarkUpYield`](../../doc/models/channel-mark-up-yield.md) | Required | - |

## Example (as JSON)

```json
{
  "message": "message0",
  "errorMessage": [
    "errorMessage2",
    "errorMessage3",
    "errorMessage4"
  ],
  "is_error": false,
  "code": "code8",
  "data": {
    "channelMarkup": {
      "beginDate": "beginDate6",
      "endDate": "endDate2",
      "amount": 5.22,
      "modifier": "modifier6",
      "channelAbbreviation": "channelAbbreviation4"
    }
  }
}
```

