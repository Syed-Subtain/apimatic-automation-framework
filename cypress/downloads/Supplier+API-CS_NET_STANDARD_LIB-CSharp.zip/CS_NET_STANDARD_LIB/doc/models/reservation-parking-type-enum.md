
# Reservation Parking Type Enum

## Enumeration

`ReservationParkingTypeEnum`

## Fields

| Name |
|  --- |
| `NoReservationNeeded` |
| `NotPossible` |
| `ReservationNeeded` |

## Example

```
NoReservationNeeded
```

