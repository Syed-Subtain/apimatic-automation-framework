
# License Requirements Data Object Detail

## Structure

`LicenseRequirementsDataObjectDetail`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Name` | `string` | Optional | name of the property |
| `Level` | `string` | Optional | Level of the property for the name above |
| `Variants` | [`List<Models.LicenseVariants>`](../../doc/models/license-variants.md) | Optional | - |
| `Active` | `string` | Optional | active/inactive indicator |
| `Id` | `string` | Optional | ID of the requirement. |

## Example (as JSON)

```json
{
  "name": null,
  "level": null,
  "variants": null,
  "active": null,
  "id": null
}
```

