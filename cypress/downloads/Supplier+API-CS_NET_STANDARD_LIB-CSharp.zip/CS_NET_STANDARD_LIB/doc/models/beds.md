
# Beds

## Structure

`Beds`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Bed` | [`List<Models.Bed>`](../../doc/models/bed.md) | Required | List beds per room |

## Example (as JSON)

```json
{
  "bed": [
    {
      "bedType": "RMA113",
      "count": 1
    },
    {
      "bedType": "RMA58",
      "count": 1
    }
  ]
}
```

