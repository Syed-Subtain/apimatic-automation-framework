
# Internet Policy

## Structure

`InternetPolicy`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `AccessInternet` | `bool` | Required | Access internet into properties |
| `KindOfInternet` | [`Models.KindOfInternetTypeEnum?`](../../doc/models/kind-of-internet-type-enum.md) | Optional | - |
| `AvailableInternet` | [`Models.AvailableInternetEnum?`](../../doc/models/available-internet-enum.md) | Optional | - |
| `ChargeInternet` | `string` | Optional | Charge internet. Example: “Free”, “$ 100”. |

## Example (as JSON)

```json
{
  "accessInternet": true,
  "kindOfInternet": "WiFi",
  "availableInternet": "AllAreas",
  "chargeInternet": "Free"
}
```

