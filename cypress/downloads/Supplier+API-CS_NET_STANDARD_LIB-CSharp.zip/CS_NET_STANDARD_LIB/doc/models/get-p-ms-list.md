
# Get P Ms List

## Structure

`GetPMsList`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Message` | `string` | Required | Text info message |
| `ErrorMessage` | `List<string>` | Required | List of error messages |
| `IsError` | `bool` | Required | Is error (default = false) |
| `Code` | `string` | Optional | Code of message |
| `Data` | [`List<Models.PMs>`](../../doc/models/p-ms.md) | Optional | List of PMs models |

## Example (as JSON)

```json
{
  "message": "",
  "errorMessage": [],
  "is_error": false,
  "code": "",
  "data": [
    {
      "id": 61690133,
      "name": "Test name",
      "extraName": "Test fullname",
      "emailAddress": "test001@gmail.com"
    },
    {
      "id": 61690517,
      "name": "Test",
      "extraName": "Test",
      "emailAddress": "testa002@gmail.com"
    },
    {
      "id": 61690534,
      "name": "Test",
      "extraName": "Test",
      "emailAddress": "testa003@gmail.com"
    },
    {
      "id": 61691075,
      "name": "Test",
      "extraName": "Test",
      "emailAddress": "testa004@gmail.com"
    },
    {
      "id": 61691076,
      "name": "Test",
      "extraName": "Test",
      "emailAddress": "testa005@gmail.com"
    },
    {
      "id": 61691729,
      "name": "Test",
      "extraName": "Test",
      "emailAddress": "testa103@gmail.com"
    },
    {
      "id": 61691731,
      "name": "Update Name",
      "extraName": "Update Full Name",
      "emailAddress": "te@gmail.com"
    },
    {
      "id": 61691732,
      "name": "Update Name",
      "extraName": "Update Full Name",
      "emailAddress": "testa026@gmail.com"
    },
    {
      "id": 61691733,
      "name": "Test",
      "extraName": "Test",
      "emailAddress": "testa027@gmail.com"
    },
    {
      "id": 61691734,
      "name": "Test",
      "extraName": "Test",
      "emailAddress": "testa028@gmail.com"
    },
    {
      "id": 61691735,
      "name": "Test",
      "extraName": "Test",
      "emailAddress": "testa029@gmail.com"
    },
    {
      "id": 61691736,
      "name": "Update Name",
      "extraName": "Update Full Name",
      "emailAddress": "testa0031@gmail.com"
    },
    {
      "id": 61691737,
      "name": "Update Name",
      "extraName": "Update Full Name",
      "emailAddress": "testa0032@gmail.com"
    },
    {
      "id": 61691803,
      "name": "Update Name",
      "extraName": "Update Full Name",
      "emailAddress": "testa035@gmail.com"
    },
    {
      "id": 61691852,
      "name": "Test",
      "extraName": "Test",
      "emailAddress": "testa036@gmail.com"
    },
    {
      "id": 61691861,
      "name": "Auto-lyxpz company name",
      "extraName": "Auto-dzvjr full name",
      "emailAddress": "wnvuyqfya213@pqclbzs.rli"
    },
    {
      "id": 61691868,
      "name": "Update Name",
      "extraName": "Update Full Name",
      "emailAddress": "testa038@gmail.com"
    },
    {
      "id": 61691875,
      "name": "Test",
      "extraName": "Test",
      "emailAddress": "TestPM001@gmail.com"
    },
    {
      "id": 61691876,
      "name": "Test",
      "extraName": "Test",
      "emailAddress": "TestPM002@gmail.com"
    },
    {
      "id": 61691877,
      "name": "Test",
      "extraName": "Test",
      "emailAddress": "TestPM003@gmail.com"
    },
    {
      "id": 61691878,
      "name": "Test",
      "extraName": "Test",
      "emailAddress": "TestPM004@gmail.com"
    },
    {
      "id": 61691879,
      "name": "Test",
      "extraName": "Test",
      "emailAddress": "TestPM005@gmail.com"
    },
    {
      "id": 61691880,
      "name": "Test",
      "extraName": "Test",
      "emailAddress": "TestPM006@gmail.com"
    },
    {
      "id": 61691881,
      "name": "Test",
      "extraName": "Test",
      "emailAddress": "TestPM007@gmail.com"
    },
    {
      "id": 61691882,
      "name": "Test",
      "extraName": "Test",
      "emailAddress": "TestPM008@gmail.com"
    },
    {
      "id": 61691883,
      "name": "Test",
      "extraName": "Test",
      "emailAddress": "TestPM009@gmail.com"
    },
    {
      "id": 61691884,
      "name": "Test",
      "extraName": "Test",
      "emailAddress": "TestPM010@gmail.com"
    },
    {
      "id": 61691885,
      "name": "Test",
      "extraName": "Test",
      "emailAddress": "TestPM011@gmail.com"
    },
    {
      "id": 61691886,
      "name": "Test",
      "extraName": "Test",
      "emailAddress": "TestPM012@gmail.com"
    },
    {
      "id": 61691887,
      "name": "Test",
      "extraName": "Test",
      "emailAddress": "TestPM014@gmail.com"
    },
    {
      "id": 61691888,
      "name": "Test",
      "extraName": "Test",
      "emailAddress": "TestPM015@gmail.com"
    },
    {
      "id": 61691889,
      "name": "Test",
      "extraName": "Test",
      "emailAddress": "TestPM016@gmail.com"
    },
    {
      "id": 61691896,
      "name": "Test",
      "extraName": "Test",
      "emailAddress": "TestPM017@gmail.com"
    },
    {
      "id": 61691897,
      "name": "Test",
      "extraName": "Test",
      "emailAddress": "TestPM018@gmail.com"
    },
    {
      "id": 61691898,
      "name": "Test",
      "extraName": "Test",
      "emailAddress": "TestPM019@gmail.com"
    },
    {
      "id": 61691899,
      "name": "Test",
      "extraName": "Test",
      "emailAddress": "TestPM020@gmail.com"
    },
    {
      "id": 61691900,
      "name": "Test",
      "extraName": "Test",
      "emailAddress": "TestPM021@gmail.com"
    },
    {
      "id": 61691903,
      "name": "Test",
      "extraName": "Test",
      "emailAddress": "testa0141234@gmail.com"
    },
    {
      "id": 61691904,
      "name": "Test",
      "extraName": "Test",
      "emailAddress": "testa01412345@gmail.com"
    },
    {
      "id": 61691905,
      "name": "Test",
      "extraName": "Test",
      "emailAddress": "TestPM022@gmail.com"
    },
    {
      "id": 61691906,
      "name": "Test",
      "extraName": "Test",
      "emailAddress": "TestPM023@gmail.com"
    },
    {
      "id": 61691907,
      "name": "Test",
      "extraName": "Test",
      "emailAddress": "testa014123452@gmail.com"
    },
    {
      "id": 61691908,
      "name": "Test",
      "extraName": "Test",
      "emailAddress": "testa0141234521@gmail.com"
    },
    {
      "id": 61691909,
      "name": "Test",
      "extraName": "Test",
      "emailAddress": "TestPM024@gmail.com"
    },
    {
      "id": 61691910,
      "name": "Test",
      "extraName": "Test",
      "emailAddress": "TestPM025@gmail.com"
    },
    {
      "id": 61691911,
      "name": "Test",
      "extraName": "Test",
      "emailAddress": "TestPM026@gmail.com"
    },
    {
      "id": 61691979,
      "name": "Test",
      "extraName": "Test",
      "emailAddress": "TestPM028@gmail.com"
    },
    {
      "id": 61692003,
      "name": "Test",
      "extraName": "Test",
      "emailAddress": "TestPM030@gmail.com"
    },
    {
      "id": 61692065,
      "name": "Test",
      "extraName": "Test",
      "emailAddress": "TestPM031@gmail.com"
    },
    {
      "id": 61692066,
      "name": "Test",
      "extraName": "Test",
      "emailAddress": "TestPM032@gmail.com"
    },
    {
      "id": 61692067,
      "name": "Test",
      "extraName": "Test",
      "emailAddress": "TestPM033@gmail.com"
    },
    {
      "id": 61692068,
      "name": "Update Name",
      "extraName": "Update Full Name",
      "emailAddress": "TestPM034@gmail.com"
    },
    {
      "id": 61692418,
      "name": "Test",
      "extraName": "Test",
      "emailAddress": "TestPM01130@gmail.com"
    },
    {
      "id": 61692455,
      "name": "Test",
      "extraName": "Test",
      "emailAddress": "TestPM035@gmail.com"
    },
    {
      "id": 61692456,
      "name": "Test",
      "extraName": "Test",
      "emailAddress": "TestPM036@gmail.com"
    },
    {
      "id": 61692457,
      "name": "Test",
      "extraName": "Test",
      "emailAddress": "TestPM037@gmail.com"
    },
    {
      "id": 61692552,
      "name": "Update Name",
      "extraName": "Update Full Name",
      "emailAddress": "TestPM038@gmail.com"
    },
    {
      "id": 61692554,
      "name": "Test",
      "extraName": "Test",
      "emailAddress": "TestPM999MJ@gmail.com"
    },
    {
      "id": 61692695,
      "name": "Test",
      "extraName": "Test",
      "emailAddress": "testa133@gmail.com"
    },
    {
      "id": 61692769,
      "name": "Test",
      "extraName": "Test",
      "emailAddress": "TestPM050@gmail.com"
    },
    {
      "id": 61692782,
      "name": "Test",
      "extraName": "Test",
      "emailAddress": "TestPMCreateProduct@gmail.com"
    },
    {
      "id": 61692785,
      "name": "Test",
      "extraName": "Test",
      "emailAddress": "TestPM055@gmail.com"
    },
    {
      "id": 61692787,
      "name": "Test",
      "extraName": "Test",
      "emailAddress": "TestPM056@gmail.com"
    },
    {
      "id": 61692789,
      "name": "Test",
      "extraName": "Test",
      "emailAddress": "TestPM057@gmail.com"
    },
    {
      "id": 61692790,
      "name": "Test Wiz",
      "extraName": "Test Wiz",
      "emailAddress": "TestPM058@gmail.com"
    },
    {
      "id": 61692791,
      "name": "Test wiz1",
      "extraName": "Test wiz1",
      "emailAddress": "TestPM059@gmail.com"
    },
    {
      "id": 61692793,
      "name": "Test wiz1",
      "extraName": "Test wiz1",
      "emailAddress": "TestPM060@gmail.com"
    },
    {
      "id": 61692794,
      "name": "Test wiz1",
      "extraName": "Test wiz1",
      "emailAddress": "TestPM061@gmail.com"
    },
    {
      "id": 61692795,
      "name": "Test wiz",
      "extraName": "Test wiz",
      "emailAddress": "TestPM062@gmail.com"
    },
    {
      "id": 61692797,
      "name": "Wizard Demo",
      "extraName": "Wizard Demo",
      "emailAddress": "wizarddemo@gmail.com"
    },
    {
      "id": 61692799,
      "name": "Test PM",
      "extraName": "Test PM",
      "emailAddress": "apimaticTest@test.com"
    }
  ]
}
```

