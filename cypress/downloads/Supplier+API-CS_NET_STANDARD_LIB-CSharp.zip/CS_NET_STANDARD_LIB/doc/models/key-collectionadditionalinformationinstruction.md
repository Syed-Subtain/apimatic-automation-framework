
# Key Collectionadditionalinformationinstruction

## Structure

`KeyCollectionadditionalinformationinstruction`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `How` | `string` | Required | how key should be collected |
| `When` | `string` | Required | when key should be collected |

## Example (as JSON)

```json
{
  "how": "how example",
  "when": "when example"
}
```

