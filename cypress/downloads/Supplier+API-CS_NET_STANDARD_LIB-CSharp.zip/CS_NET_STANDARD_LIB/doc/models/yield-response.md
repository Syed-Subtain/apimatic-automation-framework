
# Yield Response

## Structure

`YieldResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Message` | `string` | Required | text info message |
| `ErrorMessage` | `List<string>` | Required | List of error messages |
| `IsError` | `bool` | Required | Is error (default = false) |
| `Code` | `string` | Required | Code of message |
| `Data` | [`List<Models.TransportYield>`](../../doc/models/transport-yield.md) | Required | List of Models |

## Example (as JSON)

```json
{
  "message": "message0",
  "errorMessage": [
    "errorMessage2",
    "errorMessage3",
    "errorMessage4"
  ],
  "is_error": false,
  "code": "code8",
  "data": [
    {
      "productId": 69,
      "weekend": null,
      "lengthOfStay": null,
      "dateRange": null,
      "channelMarkup": null
    },
    {
      "productId": 70,
      "weekend": null,
      "lengthOfStay": null,
      "dateRange": null,
      "channelMarkup": null
    }
  ]
}
```

