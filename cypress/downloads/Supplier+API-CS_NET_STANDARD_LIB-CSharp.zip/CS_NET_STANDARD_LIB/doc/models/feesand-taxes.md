
# Feesand Taxes

## Structure

`FeesandTaxes`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ProductId` | `int` | Required | ID of the product |
| `Fees` | [`List<Models.Fee>`](../../doc/models/fee.md) | Optional | List of models |
| `Taxes` | [`List<Models.Taxes>`](../../doc/models/taxes.md) | Optional | List of models |

## Example (as JSON)

```json
{
  "productId": 98,
  "fees": null,
  "taxes": null
}
```

