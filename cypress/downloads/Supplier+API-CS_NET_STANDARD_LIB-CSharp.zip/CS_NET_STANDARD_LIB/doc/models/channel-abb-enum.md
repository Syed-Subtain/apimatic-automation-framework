
# Channel ABB Enum

## Enumeration

`ChannelABBEnum`

## Fields

| Name |
|  --- |
| `BKG` |
| `ABB` |
| `EXP` |
| `EXPHC` |
| `HAC` |

## Example

```
BKG
```

