
# Property Manager Details Response

## Structure

`PropertyManagerDetailsResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Message` | `string` | Required | text info message |
| `ErrorMessage` | `List<string>` | Required | List of error messages |
| `IsError` | `bool` | Required | Is error (default = false) |
| `Code` | `string` | Required | Code of message |
| `Data` | [`List<Models.Company>`](../../doc/models/company.md) | Required | List of models |

## Example (as JSON)

```json
{
  "message": "",
  "errorMessage": [],
  "is_error": false,
  "code": "",
  "data": [
    {
      "companyDetails": {
        "accountId": "132",
        "companyName": "Test PM",
        "language": "en",
        "fullName": "Test PM",
        "companyAddress": {
          "country": "US",
          "state": "Test State",
          "streetAddress": "Test Street",
          "city": "Test City",
          "zip": "13245"
        },
        "website": "www.testsite.com",
        "email": "apimaticTest@test.com",
        "phone": {
          "countryCode": "321",
          "number": "132456"
        },
        "currency": "USD"
      },
      "policies": {
        "paymentPolicy": {
          "type": "SPLIT",
          "splitPayment": {
            "depositType": "FLAT",
            "value": 4,
            "secondPaymentDays": 30
          }
        },
        "cancellationPolicy": {
          "type": "MANUAL",
          "manualPolicy": {
            "type": "FLAT",
            "manualPolicies": [
              {
                "chargeValue": 20,
                "beforeDays": 34,
                "cancellationFee": 1
              },
              {
                "chargeValue": 12,
                "beforeDays": 45,
                "cancellationFee": 2
              }
            ]
          }
        },
        "feeTaxMandatory": {
          "isFeeMandatory": true,
          "isTaxMandatory": true
        },
        "terms": "www.test.com",
        "checkInTime": "36000",
        "checkOutTime": "57600",
        "leadTime": 2
      },
      "payment": {
        "paymentType": "MAIL_CHECK",
        "creditCard": {
          "creditCardType": "POST",
          "creditCardList": [
            "AMERICAN_EXPRESS",
            "DINERS_CLUB",
            "DISCOVER",
            "MASTER_CARD",
            "VISA"
          ],
          "paymentGateways": {
            "paymentGatewaysType": "AUTHORIZE_NET"
          }
        }
      },
      "id": 61692799,
      "isCompany": false,
      "ownerInfo": {
        "language": "EN",
        "value": "ownerInfo on EN"
      },
      "neighborhoodOverview": {
        "language": "EN",
        "value": "neighborhoodOverview on EN"
      }
    }
  ]
}
```

