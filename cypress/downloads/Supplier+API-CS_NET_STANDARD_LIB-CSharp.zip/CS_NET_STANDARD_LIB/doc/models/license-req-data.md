
# License Req Data

## Structure

`LicenseReqData`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ProductId` | `string` | Optional | Product ID |
| `LicenseRequirementResponse` | [`List<Models.LicenseRequirementResponseObject>`](../../doc/models/license-requirement-response-object.md) | Optional | License Requirement Response Object |

## Example (as JSON)

```json
{
  "productId": null,
  "licenseRequirementResponse": null
}
```

