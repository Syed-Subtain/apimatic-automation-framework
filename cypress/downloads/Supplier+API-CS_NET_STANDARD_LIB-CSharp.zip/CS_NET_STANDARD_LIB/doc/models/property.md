
# Property

## Structure

`Property`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Name` | `string` | Required | Name of the property to display in the list |
| `Id` | `int?` | Optional | Property ID in BookingPal |
| `AltId` | `int?` | Optional | Alternative Id of the property (ID in your PMS system).   Note: this field can not be updated, so this field will not be used during update. |
| `SupplierId` | `int?` | Optional | Id of the Property Manager (not be used for creating new property. Property will have ID of current authorized user) |
| `Rooms` | `int` | Required | Number of bedrooms. Number of bedrooms should be > 0. Value 0 is only allowed in case property type  is Studio (PCT46 or PCT110) |
| `Bathrooms` | `int` | Required | Number of bathrooms |
| `Toilets` | `int?` | Optional | Number of toilets |
| `TotalBeds` | `int?` | Optional | Property’s total number of beds |
| `Space` | `double?` | Optional | Property size |
| `SpaceUnit` | [`Models.SpaceUnitEnum?`](../../doc/models/space-unit-enum.md) | Optional | - |
| `Persons` | `int` | Required | Maximum number of allowed adults |
| `Childs` | `int?` | Optional | Number of allowed children (from 7 to 12 years) |
| `Latitude` | `double?` | Optional | Latitude of the property (Must set field latitude and longitude or location) |
| `Longitude` | `double?` | Optional | Longitude of the property (Must set field latitude and longitude or location) |
| `LivingRoom` | `int?` | Optional | Number of Living rooms |
| `Notes` | [`Models.Notes`](../../doc/models/notes.md) | Optional | Model where you can define different kinds of text values. If you need to delete some kind of texts, for example short description, you can do this on Update call (PUT), and you need to pass empty array for texts value, for example :  "shortDescription": {  "texts": [  ] } |
| `AttributesWithQuantity` | [`List<Models.AttributesWithQuantity>`](../../doc/models/attributes-with-quantity.md) | Optional | Use this param instead of previous if you need to set quantity more than 1 of attributes. If use both in POST request this will overwrite the previous list (under param attributes). |
| `NearbyAmenities` | [`List<Models.NearbyAmenity>`](../../doc/models/nearby-amenity.md) | Optional | List of Nearby Attributes models. Check allowed values in Appendix. |
| `PropertyType` | [`Models.PropertyTypesEnum`](../../doc/models/property-types-enum.md) | Required | - |
| `BedroomConfiguration` | [`Models.BedroomConfiguration`](../../doc/models/bedroom-configuration.md) | Optional | - |
| `CheckInTime` | `string` | Optional | Time of Check in (HH:MM:SS) |
| `CheckInToTime` | `string` | Optional | Time Check in to (HH:MM:SS) |
| `CheckOutTime` | `string` | Optional | Time of Check out (HH:MM:SS) |
| `Currency` | `string` | Required | Property currency. ISO 4217 code is required. |
| `Policy` | [`Models.Policy`](../../doc/models/policy.md) | Optional | - |
| `Location` | [`Models.Location`](../../doc/models/location.md) | Optional | - |
| `SupportedLosRates` | `bool` | Required | If true - means that the property supports only LOS rates. So daily rates can not be sent and updated. Default is false. |
| `TaxNumber` | `string` | Optional | Tax number for the property |
| `MultiUnit` | [`Models.MultiUnitEnum?`](../../doc/models/multi-unit-enum.md) | Optional | Enum for product multyunit type. |
| `ParentId` | `int?` | Optional | This fields should not be used unless your property is not MLT (check field multiunit). In this case you must set owner (parent) id property to which this property will belong. Also you can not update this property. |
| `PropertyRating` | `double?` | Optional | Property rating. A floating point number representing the aggregate property rating (0-5). |
| `RatingNumber` | `int?` | Optional | Rating Number. Number of ratings that the property has (Non-negative integer) |
| `MinimumRentingAge` | `int?` | Optional | Minimum renting age. If you want to remove previously added value - send value 0. |
| `BasePrice` | `double?` | Optional | Display value that channels use when guests search without dates. Min value = 10 USD; Max value = 25,000 USD |
| `BuiltDate` | `DateTime?` | Optional | Date when property were built. Format YYYY-MM-DD HH:MM:SS |
| `RenovatingDate` | `DateTime?` | Optional | Date when property last time were renovated. Format YYYY-MM-DD HH:MM:SS |
| `RentingDate` | `DateTime?` | Optional | Date from when property is rented. Format YYYY-MM-DD HH:MM:SS |
| `HostLocation` | `bool?` | Optional | Indicator, whether the host is living in the property or not. Default is FALSE. |
| `KeyCollection` | [`Models.KeyCollection`](../../doc/models/key-collection.md) | Optional | - |
| `NeighborhoodOverview` | [`Models.Text`](../../doc/models/text.md) | Optional | - |
| `About` | [`Models.Text`](../../doc/models/text.md) | Optional | - |

## Example (as JSON)

```json
{
  "name": null,
  "rooms": null,
  "bathrooms": null,
  "persons": null,
  "propertyType": "PCT101",
  "currency": null,
  "supportedLosRates": null
}
```

