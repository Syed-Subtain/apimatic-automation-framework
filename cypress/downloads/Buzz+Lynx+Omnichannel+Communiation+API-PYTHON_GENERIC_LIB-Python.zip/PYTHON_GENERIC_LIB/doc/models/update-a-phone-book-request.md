
# Update a Phone Book Request

## Structure

`UpdateAPhoneBookRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `name` | `string` | Required | - |
| `attribute_3` | `string` | Required | - |

## Example (as JSON)

```json
{
  "name": "Soccer Moms and Dads",
  "attribute_3": "ID"
}
```

