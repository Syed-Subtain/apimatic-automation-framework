
# Getting Started with API Financings - Open Banking Brasil

## Introduction

API de informações de operações de financiamentos do Open Banking Brasil – Fase 2.
API que retorna informações de operações de crédito do tipo financiamento, mantidas nas instituições transmissoras por seus clientes, incluindo dados como denominação, modalidade, número do contrato, tarifas, prazo, prestações, pagamentos, amortizações, garantias, encargos e taxas de juros remuneratórios.\
Não possui segregação entre pessoa natural e pessoa jurídica.\
Requer consentimento do cliente para todos os `endpoints`.

### Orientações

A `Role`  do diretório de participantes relacionada à presente API é a `DADOS`.\
Para todos os `endpoints` desta API é previsto o envio de um `token` através do header `Authorization`.\
Este token deverá estar relacionado ao consentimento (`consentId`) mantido na instituição transmissora dos dados, o qual permitirá a pesquisa e retorno, na API em questão, dos
dados relacionados ao `consentId` específico relacionado.\
Os dados serão devolvidos na consulta desde que o `consentId` relacionado corresponda a um consentimento válido e com o status `AUTHORISED`.\
É também necessário que o recurso em questão (conta, contrato, etc) esteja disponível na instituição transmissora (ou seja, sem boqueios de qualquer natureza e com todas as autorizações/consentimentos já autorizados).\
Além disso as `permissions` necessárias deverão ter sido solicitadas quando da criação do consentimento relacionado (`consentId`).\
Relacionamos a seguir as `permissions` necessárias para a consulta de dados em cada `endpoint` da presente API.

#### Observação

- No endpoint `/contracts/{contratId}/payments` a paginação ocorrerá sob os dados contidos no campo `releases` do tipo lista.

#### Permissions necessárias para a API Financings

Para cada um dos paths desta API, além dos escopos (`scopes`) indicados existem `permissions` que deverão ser observadas:

##### `/contracts`

- permissions:
  - GET: **FINANCINGS_READ**

##### `/contracts/{contractId}`

- permissions:
  - GET **FINANCINGS_READ**

##### `/contracts/{contractId}/warranties`

- permissions:
  - GET: **FINANCINGS_WARRANTIES_READ**

##### `/contracts/{contractId}/scheduled-instalments`

- permissions:
  - GET: **FINANCINGS_SCHEDULED_INSTALMENTS_READ**

##### `/contracts/{contractId}/payments`

- permissions:
  - GET: **FINANCINGS_PAYMENTS_READ**

## Building

You must have Python `3 >=3.7, <= 3.9` installed on your system to install and run this SDK. This SDK package depends on other Python packages like nose, jsonpickle etc. These dependencies are defined in the `requirements.txt` file that comes with the SDK. To resolve these dependencies, you can use the PIP Dependency manager. Install it by following steps at [https://pip.pypa.io/en/stable/installing/](https://pip.pypa.io/en/stable/installing/).

Python and PIP executables should be defined in your PATH. Open command prompt and type `pip --version`. This should display the version of the PIP Dependency Manager installed if your installation was successful and the paths are properly defined.

* Using command line, navigate to the directory containing the generated files (including `requirements.txt`) for the SDK.
* Run the command `pip install -r requirements.txt`. This should install all the required dependencies.

![Building SDK - Step 1](https://apidocs.io/illustration/python?workspaceFolder=Apifinancingsopenbankingbrasil-Python&step=installDependencies)

## Installation

The following section explains how to use the apifinancingsopenbankingbrasil library in a new project.

### 1. Open Project in an IDE

Open up a Python IDE like PyCharm. The basic workflow presented here is also applicable if you prefer using a different editor or IDE.

![Open project in PyCharm - Step 1](https://apidocs.io/illustration/python?workspaceFolder=Apifinancingsopenbankingbrasil-Python&step=pyCharm)

Click on `Open` in PyCharm to browse to your generated SDK directory and then click `OK`.

![Open project in PyCharm - Step 2](https://apidocs.io/illustration/python?workspaceFolder=Apifinancingsopenbankingbrasil-Python&step=openProject0)

The project files will be displayed in the side bar as follows:

![Open project in PyCharm - Step 3](https://apidocs.io/illustration/python?workspaceFolder=Apifinancingsopenbankingbrasil-Python&projectName=apifinancingsopenbankingbrasil&step=openProject1)

### 2. Add a new Test Project

Create a new directory by right clicking on the solution name as shown below:

![Add a new project in PyCharm - Step 1](https://apidocs.io/illustration/python?workspaceFolder=Apifinancingsopenbankingbrasil-Python&projectName=apifinancingsopenbankingbrasil&step=createDirectory)

Name the directory as "test".

![Add a new project in PyCharm - Step 2](https://apidocs.io/illustration/python?workspaceFolder=Apifinancingsopenbankingbrasil-Python&step=nameDirectory)

Add a python file to this project.

![Add a new project in PyCharm - Step 3](https://apidocs.io/illustration/python?workspaceFolder=Apifinancingsopenbankingbrasil-Python&projectName=apifinancingsopenbankingbrasil&step=createFile)

Name it "testSDK".

![Add a new project in PyCharm - Step 4](https://apidocs.io/illustration/python?workspaceFolder=Apifinancingsopenbankingbrasil-Python&projectName=apifinancingsopenbankingbrasil&step=nameFile)

In your python file you will be required to import the generated python library using the following code lines

```python
from apifinancingsopenbankingbrasil.apifinancingsopenbankingbrasil_client import ApifinancingsopenbankingbrasilClient
```

![Add a new project in PyCharm - Step 5](https://apidocs.io/illustration/python?workspaceFolder=Apifinancingsopenbankingbrasil-Python&projectName=apifinancingsopenbankingbrasil&libraryName=apifinancingsopenbankingbrasil.apifinancingsopenbankingbrasil_client&className=ApifinancingsopenbankingbrasilClient&step=projectFiles)

After this you can write code to instantiate an API client object, get a controller object and  make API calls. Sample code is given in the subsequent sections.

### 3. Run the Test Project

To run the file within your test project, right click on your Python file inside your Test project and click on `Run`

![Run Test Project - Step 1](https://apidocs.io/illustration/python?workspaceFolder=Apifinancingsopenbankingbrasil-Python&projectName=apifinancingsopenbankingbrasil&libraryName=apifinancingsopenbankingbrasil.apifinancingsopenbankingbrasil_client&className=ApifinancingsopenbankingbrasilClient&step=runProject)

## Initialize the API Client

**_Note:_** Documentation for the client can be found [here.](doc/client.md)

The following parameters are configurable for the API Client:

| Parameter | Type | Description |
|  --- | --- | --- |
| `environment` | Environment | The API environment. <br> **Default: `Environment.PRODUCTION`** |
| `http_client_instance` | `HttpClient` | The Http Client passed from the sdk user for making requests |
| `override_http_client_configuration` | `bool` | The value which determines to override properties of the passed Http Client from the sdk user |
| `http_call_back` | `HttpCallBack` | The callback value that is invoked before and after an HTTP call is made to an endpoint |
| `timeout` | `float` | The value to use for connection timeout. <br> **Default: 60** |
| `max_retries` | `int` | The number of times to retry an endpoint call if it fails. <br> **Default: 0** |
| `backoff_factor` | `float` | A backoff factor to apply between attempts after the second try. <br> **Default: 2** |
| `retry_statuses` | `Array of int` | The http statuses on which retry is to be done. <br> **Default: [408, 413, 429, 500, 502, 503, 504, 521, 522, 524]** |
| `retry_methods` | `Array of string` | The http methods on which retry is to be done. <br> **Default: ['GET', 'PUT']** |
| `bearer_access_token` | `string` | The OAuth 2.0 Access Token to use for API requests. |
| `authorization_code_client_id` | `string` | OAuth 2 Client ID |
| `authorization_code_client_secret` | `string` | OAuth 2 Client Secret |
| `authorization_code_redirect_uri` | `string` | OAuth 2 Redirection endpoint or Callback Uri |
| `authorization_code_token` | `OAuthToken` | Object for storing information about the OAuth token |
| `authorization_code_scopes` | `AuthorizationCodeScopeEnum` |  |

The API client can be initialized as follows:

```python
from apifinancingsopenbankingbrasil.apifinancingsopenbankingbrasil_client import ApifinancingsopenbankingbrasilClient
from apifinancingsopenbankingbrasil.configuration import Environment

client = ApifinancingsopenbankingbrasilClient(
    bearer_access_token='BearerAccessToken',
    authorization_code_client_id='AuthorizationCodeClientId',
    authorization_code_client_secret='AuthorizationCodeClientSecret',
    authorization_code_redirect_uri='AuthorizationCodeRedirectUri',
    authorization_code_scopes = [AuthorizationCodeScopeEnum.FINANCINGS, AuthorizationCodeScopeEnum.CONSENTCONSENTID],
    environment=Environment.PRODUCTION,)
```

## Environments

The SDK can be configured to use a different environment for making API calls. Available environments are:

### Fields

| Name | Description |
|  --- | --- |
| production | **Default** Servidor de Produção |
| environment2 | Servidor de Produção |
| environment3 | Servidor de Produção |
| environment4 | Servidor de Homologação |
| environment5 | Servidor de Homologação |
| environment6 | Servidor de Homologação |

## Authorization

This API uses `OAuth 2 Bearer token`, `OAuth 2 Authorization Code Grant`.

## Authorization Code Grant

Your application must obtain user authorization before it can execute an endpoint call incase this SDK chooses to use *OAuth 2.0 Authorization Code Grant*. This authorization includes the following steps

### 1\. Obtain user consent

To obtain user's consent, you must redirect the user to the authorization page.The `get_authorization_url()` method creates the URL to the authorization page. You must pass the scopes for which you need permission to access.

```python
auth_url = client.auth_managers['oAuth2Security'].get_authorization_url()
```

### 2\. Handle the OAuth server response

Once the user responds to the consent request, the OAuth 2.0 server responds to your application's access request by redirecting the user to the redirect URI specified set in `Configuration`.

If the user approves the request, the authorization code will be sent as the `code` query string:

```
https://example.com/oauth/callback?code=XXXXXXXXXXXXXXXXXXXXXXXXX
```

If the user does not approve the request, the response contains an `error` query string:

```
https://example.com/oauth/callback?error=access_denied
```

### 3\. Authorize the client using the code

After the server receives the code, it can exchange this for an *access token*. The access token is an object containing information for authorizing client requests and refreshing the token itself.

```python
try:
    client.auth_managers['oAuth2Security'].fetch_token('code')
except OAuthProviderException as ex:
    # handle exception
except APIException as ex:
    # handle exception
```

### Scopes

Scopes enable your application to only request access to the resources it needs while enabling users to control the amount of access they grant to your application. Available scopes are defined in the `AuthorizationCodeScopeEnum` enumeration.

| Scope Name | Description |
|  --- | --- |
| `FINANCINGS` | Escopo necessário para acesso à API Financings. O controle dos endpoints específicos é feito via permissions. |
| `CONSENTCONSENTID` |  |

### Refreshing the token

An access token may expire after sometime. To extend its lifetime, you must refresh the token.

```python
if client.auth_managers['oAuth2Security'].is_token_expired():
    try:
        client.auth_managers['oAuth2Security'].refresh_token()
    except OAuthProviderException as ex:
        # handle exception
```

If a token expires, an exception will be thrown before the next endpoint call requiring authentication.

### Storing an access token for reuse

It is recommended that you store the access token for reuse.

```python
# store token
save_token_to_database(client.config.authorization_code_token)
```

### Creating a client from a stored token

To authorize a client from a stored access token, just set the access token in Configuration along with the other configuration parameters before creating the client:

```python
client = ApifinancingsopenbankingbrasilClient()
client.config.authorization_code_token = load_token_from_database()
```

### Complete example

```python
from apifinancingsopenbankingbrasil.apifinancingsopenbankingbrasil_client import ApifinancingsopenbankingbrasilClient
from apifinancingsopenbankingbrasil.models.authorization_code_scope_enum import AuthorizationCodeScopeEnum
from apifinancingsopenbankingbrasil.exceptions.o_auth_provider_exception import OAuthProviderException

# function for storing token to database
def save_token_to_database(token):
    # code to save the token to database
    pass

# function for loading token from database
def load_token_from_database():
    # load token from database and return it (return None if no token exists)
    pass

from apifinancingsopenbankingbrasil.apifinancingsopenbankingbrasil_client import ApifinancingsopenbankingbrasilClient
from apifinancingsopenbankingbrasil.configuration import Environment

client = ApifinancingsopenbankingbrasilClient(
    bearer_access_token='BearerAccessToken',
    authorization_code_client_id='AuthorizationCodeClientId',
    authorization_code_client_secret='AuthorizationCodeClientSecret',
    authorization_code_redirect_uri='AuthorizationCodeRedirectUri',
    authorization_code_scopes = [AuthorizationCodeScopeEnum.FINANCINGS, AuthorizationCodeScopeEnum.CONSENTCONSENTID],
    environment=Environment.PRODUCTION,)
# callback for storing token for reuse when token is updated
client.config.o_auth_callback = save_token_to_database

# obtain access token, needed for client to be authorized
previous_token = load_token_from_database()
if previous_token:
    # restore previous access token
    client.config.authorization_code_token = previous_token
else:
    # redirect user to a page that handles authorization
    pass

# the client is now authorized and you can use controllers to make endpoint calls
```

## List of APIs

* [O Auth Authorization](doc/controllers/o-auth-authorization.md)
* [Financings](doc/controllers/financings.md)

## Classes Documentation

* [Utility Classes](doc/utility-classes.md)
* [HttpResponse](doc/http-response.md)
* [HttpRequest](doc/http-request.md)

