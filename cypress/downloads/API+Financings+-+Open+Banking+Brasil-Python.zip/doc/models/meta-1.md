
# Meta 1

Meta informações referente à API requisitada.

## Structure

`Meta1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `request_date_time` | `datetime` | Required | Data e hora da consulta, conforme especificação RFC-3339, formato UTC. |

## Example (as JSON)

```json
{
  "requestDateTime": "2016-03-13T12:52:32.123Z"
}
```

