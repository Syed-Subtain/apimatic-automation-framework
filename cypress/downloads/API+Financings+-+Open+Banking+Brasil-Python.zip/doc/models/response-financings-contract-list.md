
# Response Financings Contract List

## Structure

`ResponseFinancingsContractList`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `data` | [`List of FinancingsListContract`](../../doc/models/financings-list-contract.md) | Required | **Constraints**: *Minimum Items*: `0` |
| `links` | [`Links`](../../doc/models/links.md) | Required | Referências para outros recusos da API requisitada. |
| `meta` | [`Meta`](../../doc/models/meta.md) | Required | Meta informações referente à API requisitada. |

## Example (as JSON)

```json
{
  "data": [
    {
      "contractId": "contractId7",
      "brandName": "brandName1",
      "companyCnpj": "companyCnpj9",
      "productType": "FINANCIAMENTOS",
      "productSubType": "COMERCIALIZACAO",
      "ipocCode": "ipocCode5"
    },
    {
      "contractId": "contractId8",
      "brandName": "brandName2",
      "companyCnpj": "companyCnpj0",
      "productType": "FINANCIAMENTOS_RURAIS",
      "productSubType": "FINANCIAMENTO_HABITACIONAL_SFH",
      "ipocCode": "ipocCode6"
    }
  ],
  "links": {
    "self": "self2",
    "first": null,
    "prev": null,
    "next": null,
    "last": null
  },
  "meta": {
    "totalRecords": 122,
    "totalPages": 52,
    "requestDateTime": "2016-03-13T12:52:32.123Z"
  }
}
```

