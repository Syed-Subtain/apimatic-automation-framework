
# Financings Fee Over Parcel

## Structure

`FinancingsFeeOverParcel`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `fee_name` | `string` | Required | Denominação da Tarifa pactuada.<br>**Constraints**: *Maximum Length*: `140`, *Pattern*: `[\w\W\s]*` |
| `fee_code` | `string` | Required | Sigla identificadora da tarifa pactuada.<br>**Constraints**: *Maximum Length*: `140`, *Pattern*: `[\w\W\s]*` |
| `fee_amount` | `string` | Required | Valor monetário da tarifa pactuada no contrato.<br><br>Expresso em valor monetário com no mínimo 2 casas e no máximo 4 casas decimais.<br>**Constraints**: *Minimum Length*: `4`, *Maximum Length*: `20`, *Pattern*: `^\d{1,15}\.\d{2,4}$` |

## Example (as JSON)

```json
{
  "feeName": "feeName2",
  "feeCode": "feeCode8",
  "feeAmount": "feeAmount6"
}
```

