
# Meta

Meta informações referente à API requisitada.

## Structure

`Meta`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `total_records` | `int` | Required | Número total de registros no resultado |
| `total_pages` | `int` | Required | Número total de páginas no resultado |
| `request_date_time` | `datetime` | Required | Data e hora da consulta, conforme especificação RFC-3339, formato UTC. |

## Example (as JSON)

```json
{
  "totalRecords": 76,
  "totalPages": 98,
  "requestDateTime": "2016-03-13T12:52:32.123Z"
}
```

