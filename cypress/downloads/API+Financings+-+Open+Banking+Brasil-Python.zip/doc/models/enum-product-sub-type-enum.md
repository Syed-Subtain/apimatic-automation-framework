
# Enum Product Sub Type Enum

"Sub tipo da modalidades de crédito contratadas, conforme  circular 4.015 e descrição do DOC3040 do SCR). (Vide Enum)
Aquisição de bens veículos automotores, Aquisição de bens de outros bens, Microcrédito, Custeio, Investimento, Industrialização, Comercialização, Financiamento habitacional SFH e Financiamento habitacional exceto SFH"

## Enumeration

`EnumProductSubTypeEnum`

## Fields

| Name |
|  --- |
| `AQUISICAO_BENS_VEICULOS_AUTOMOTORES` |
| `AQUISICAO_BENS_OUTROS_BENS` |
| `MICROCREDITO` |
| `CUSTEIO` |
| `INVESTIMENTO` |
| `INDUSTRIALIZACAO` |
| `COMERCIALIZACAO` |
| `FINANCIAMENTO_HABITACIONAL_SFH` |
| `FINANCIAMENTO_HABITACIONAL_EXCETO_SFH` |

