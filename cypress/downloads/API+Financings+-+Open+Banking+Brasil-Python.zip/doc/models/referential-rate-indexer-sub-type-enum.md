
# Referential Rate Indexer Sub Type Enum

"Sub tipos de taxas referenciais ou indexadores, conforme Anexo 5: Taxa referencial ou Indexador (Indx), do Documento 3040"

## Enumeration

`ReferentialRateIndexerSubTypeEnum`

## Fields

| Name |
|  --- |
| `SEM_SUB_TIPO_INDEXADOR` |
| `PRE_FIXADO` |
| `TR_TBF` |
| `TJLP` |
| `LIBOR` |
| `TLP` |
| `OUTRAS_TAXAS_POS_FIXADAS` |
| `CDI` |
| `SELIC` |
| `OUTRAS_TAXAS_FLUTUANTES` |
| `IGPM` |
| `IPCA` |
| `IPCC` |
| `OUTROS_INDICES_PRECO` |
| `TCR_PRE` |
| `TCR_POS` |
| `TRFC_PRE` |
| `TRFC_POS` |
| `OUTROS_INDEXADORES` |

