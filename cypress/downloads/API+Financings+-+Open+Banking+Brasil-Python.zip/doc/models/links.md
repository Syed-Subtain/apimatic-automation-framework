
# Links

Referências para outros recusos da API requisitada.

## Structure

`Links`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `self` | `string` | Required | URI completo que gerou a resposta atual.<br>**Constraints**: *Maximum Length*: `2000`, *Pattern*: `^(https:\/\/)?(www\.)?[-a-zA-Z0-9@:%._\+~#=]{2,256}\.[a-z]{2,6}\b([-a-zA-Z0-9@:%_\+.~#?&\/\/=]*)$` |
| `first` | `string` | Optional | URI da primeira página que originou essa lista de resultados. Restrição - Obrigatório quando não for a primeira página da resposta<br>**Constraints**: *Maximum Length*: `2000`, *Pattern*: `^(https:\/\/)?(www\.)?[-a-zA-Z0-9@:%._\+~#=]{2,256}\.[a-z]{2,6}\b([-a-zA-Z0-9@:%_\+.~#?&\/\/=]*)$` |
| `prev` | `string` | Optional | URI da página anterior dessa lista de resultados. Restrição - 	Obrigatório quando não for a primeira página da resposta<br>**Constraints**: *Maximum Length*: `2000`, *Pattern*: `^(https:\/\/)?(www\.)?[-a-zA-Z0-9@:%._\+~#=]{2,256}\.[a-z]{2,6}\b([-a-zA-Z0-9@:%_\+.~#?&\/\/=]*)$` |
| `next` | `string` | Optional | URI da próxima página dessa lista de resultados. Restrição - Obrigatório quando não for a última página da resposta<br>**Constraints**: *Maximum Length*: `2000`, *Pattern*: `^(https:\/\/)?(www\.)?[-a-zA-Z0-9@:%._\+~#=]{2,256}\.[a-z]{2,6}\b([-a-zA-Z0-9@:%_\+.~#?&\/\/=]*)$` |
| `last` | `string` | Optional | URI da última página dessa lista de resultados. Restrição - Obrigatório quando não for a última página da resposta<br>**Constraints**: *Maximum Length*: `2000`, *Pattern*: `^(https:\/\/)?(www\.)?[-a-zA-Z0-9@:%._\+~#=]{2,256}\.[a-z]{2,6}\b([-a-zA-Z0-9@:%_\+.~#?&\/\/=]*)$` |

## Example (as JSON)

```json
{
  "self": "self8",
  "first": null,
  "prev": null,
  "next": null,
  "last": null
}
```

