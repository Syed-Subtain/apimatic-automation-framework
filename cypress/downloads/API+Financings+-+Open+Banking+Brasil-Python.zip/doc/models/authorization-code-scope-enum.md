
# Authorization Code Scope Enum

OAuth 2 scopes supported by the API

## Enumeration

`AuthorizationCodeScopeEnum`

## Fields

| Name | Description |
|  --- | --- |
| `FINANCINGS` | Escopo necessário para acesso à API Financings. O controle dos endpoints específicos é feito via permissions. |
| `CONSENTCONSENTID` |  |

