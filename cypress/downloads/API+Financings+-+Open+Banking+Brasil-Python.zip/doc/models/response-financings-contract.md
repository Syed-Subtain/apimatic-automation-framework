
# Response Financings Contract

## Structure

`ResponseFinancingsContract`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `data` | [`FinancingsContract`](../../doc/models/financings-contract.md) | Required | Conjunto de informações referentes à identificação da operação de crédito de financiamentos |
| `links` | [`Links`](../../doc/models/links.md) | Required | Referências para outros recusos da API requisitada. |
| `meta` | [`Meta`](../../doc/models/meta.md) | Required | Meta informações referente à API requisitada. |

## Example (as JSON)

```json
{
  "data": {
    "contractNumber": "contractNumber0",
    "ipocCode": "ipocCode0",
    "productName": "productName0",
    "productType": "FINANCIAMENTOS_RURAIS",
    "productSubType": "AQUISICAO_BENS_OUTROS_BENS",
    "contractDate": "2016-03-13",
    "disbursementDates": null,
    "settlementDate": null,
    "contractAmount": null,
    "currency": null,
    "dueDate": null,
    "instalmentPeriodicity": "QUINZENAL",
    "instalmentPeriodicityAdditionalInfo": null,
    "firstInstalmentDueDate": null,
    "CET": null,
    "amortizationScheduled": "SEM_SISTEMA_AMORTIZACAO",
    "amortizationScheduledAdditionalInfo": null,
    "interestRates": [
      {
        "taxType": "EFETIVA",
        "interestRateType": "COMPOSTO",
        "taxPeriodicity": "AA",
        "calculation": "21/252",
        "referentialRateIndexerType": "FLUTUANTES",
        "referentialRateIndexerSubType": null,
        "referentialRateIndexerAdditionalInfo": null,
        "preFixedRate": null,
        "postFixedRate": null,
        "additionalInfo": null
      },
      {
        "taxType": "NOMINAL",
        "interestRateType": "SIMPLES",
        "taxPeriodicity": "AM",
        "calculation": "30/360",
        "referentialRateIndexerType": "INDICES_PRECOS",
        "referentialRateIndexerSubType": null,
        "referentialRateIndexerAdditionalInfo": null,
        "preFixedRate": null,
        "postFixedRate": null,
        "additionalInfo": null
      },
      {
        "taxType": "EFETIVA",
        "interestRateType": "COMPOSTO",
        "taxPeriodicity": "AA",
        "calculation": "30/365",
        "referentialRateIndexerType": "CREDITO_RURAL",
        "referentialRateIndexerSubType": null,
        "referentialRateIndexerAdditionalInfo": null,
        "preFixedRate": null,
        "postFixedRate": null,
        "additionalInfo": null
      }
    ],
    "contractedFees": [
      {
        "feeName": "feeName6",
        "feeCode": "feeCode0",
        "feeChargeType": "UNICA",
        "feeCharge": "FIXO",
        "feeAmount": null,
        "feeRate": null
      }
    ],
    "contractedFinanceCharges": [
      {
        "chargeType": "JUROS_MORA_ATRASO",
        "chargeAdditionalInfo": null,
        "chargeRate": null
      },
      {
        "chargeType": "IOF_CONTRATACAO",
        "chargeAdditionalInfo": null,
        "chargeRate": null
      }
    ]
  },
  "links": {
    "self": "self2",
    "first": null,
    "prev": null,
    "next": null,
    "last": null
  },
  "meta": {
    "totalRecords": 122,
    "totalPages": 52,
    "requestDateTime": "2016-03-13T12:52:32.123Z"
  }
}
```

