
# Calculation Enum

Base de cálculo

## Enumeration

`CalculationEnum`

## Fields

| Name |
|  --- |
| `ENUM_21252` |
| `ENUM_30360` |
| `ENUM_30365` |

