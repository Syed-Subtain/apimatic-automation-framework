
# Response Error

## Structure

`ResponseError`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `errors` | [`List of Error`](../../doc/models/error.md) | Required | **Constraints**: *Minimum Items*: `1`, *Maximum Items*: `13` |
| `meta` | [`Meta1`](../../doc/models/meta-1.md) | Optional | Meta informações referente à API requisitada. |

## Example (as JSON)

```json
{
  "errors": [
    {
      "code": "code3",
      "title": "title1",
      "detail": "detail1"
    },
    {
      "code": "code4",
      "title": "title2",
      "detail": "detail2"
    },
    {
      "code": "code5",
      "title": "title3",
      "detail": "detail3"
    }
  ],
  "meta": null
}
```

