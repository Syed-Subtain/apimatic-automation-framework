
# Error

## Structure

`Error`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `code` | `string` | Required | Código de erro específico do endpoint<br>**Constraints**: *Maximum Length*: `255`, *Pattern*: `[\w\W\s]*` |
| `title` | `string` | Required | Título legível por humanos deste erro específico<br>**Constraints**: *Maximum Length*: `255`, *Pattern*: `[\w\W\s]*` |
| `detail` | `string` | Required | Descrição legível por humanos deste erro específico<br>**Constraints**: *Maximum Length*: `2048`, *Pattern*: `[\w\W\s]*` |

## Example (as JSON)

```json
{
  "code": "code8",
  "title": "title4",
  "detail": "detail6"
}
```

