
# Financings Warranties

Conjunto de informações referentes à identificação da operação de crédito de financiamento.

## Structure

`FinancingsWarranties`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `currency` | `string` | Optional | Moeda referente ao valor da garantia, segundo modelo ISO-4217. p.ex. 'BRL'. Todos os valores monetários informados estão representados com a moeda vigente do Brasil<br>**Constraints**: *Maximum Length*: `3`, *Pattern*: `^(\w{3}){1}$` |
| `warranty_type` | [`WarrantyTypeEnum`](../../doc/models/warranty-type-enum.md) | Required | Denominação/Identificação do tipo da garantia que avaliza a Modalidade da Operação de Crédito contratada  (Doc 3040, Anexo 12) |
| `warranty_sub_type` | [`WarrantySubTypeEnum`](../../doc/models/warranty-sub-type-enum.md) | Required | Denominação/Identificação do sub tipo da garantia que avaliza a Modalidade da Operação de Crédito contratada (Doc 3040, Anexo 12). |
| `warranty_amount` | `string` | Optional | Valor original da garantia. Expresso em valor monetário com no mínimo 2 casas e no máximo 4 casas decimais.<br>**Constraints**: *Minimum Length*: `4`, *Maximum Length*: `20`, *Pattern*: `^\d{1,15}\.\d{2,4}$` |

## Example (as JSON)

```json
{
  "currency": null,
  "warrantyType": "OPERACOES_GARANTIDAS_OUTRAS_ENTIDADES",
  "warrantySubType": "ACOES_DEBENTURES",
  "warrantyAmount": null
}
```

