
# Warranty Type Enum

Denominação/Identificação do tipo da garantia que avaliza a Modalidade da Operação de Crédito contratada  (Doc 3040, Anexo 12)

## Enumeration

`WarrantyTypeEnum`

## Fields

| Name |
|  --- |
| `CESSAO_DIREITOS_CREDITORIOS` |
| `CAUCAO` |
| `PENHOR` |
| `ALIENACAO_FIDUCIARIA` |
| `HIPOTECA` |
| `OPERACOES_GARANTIDAS_PELO_GOVERNO` |
| `OUTRAS_GARANTIAS_NAO_FIDEJUSSORIAS` |
| `SEGUROS_ASSEMELHADOS` |
| `GARANTIA_FIDEJUSSORIA` |
| `BENS_ARRENDADOS` |
| `GARANTIAS_INTERNACIONAIS` |
| `OPERACOES_GARANTIDAS_OUTRAS_ENTIDADES` |
| `ACORDOS_COMPENSACAO` |

