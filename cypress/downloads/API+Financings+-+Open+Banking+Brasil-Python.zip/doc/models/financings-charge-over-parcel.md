
# Financings Charge Over Parcel

## Structure

`FinancingsChargeOverParcel`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `charge_type` | [`EnumContractFinanceChargeTypeEnum`](../../doc/models/enum-contract-finance-charge-type-enum.md) | Required | Tipo de encargo pactuado no contrato. |
| `charge_amount` | `string` | Required | Valor do pagamento do encargo pago fora da parcela. Expresso em valor monetário com no mínimo 2 casas e no máximo 4 casas decimais.<br>**Constraints**: *Minimum Length*: `4`, *Maximum Length*: `20`, *Pattern*: `^\d{1,15}\.\d{2,4}$` |
| `charge_additional_info` | `string` | Optional | Campo livre para preenchimento das informações adicionais referente ao encargo.<br><br>[Restrição] Obrigatório quando chargeType for igual 'OUTROS'.<br>**Constraints**: *Maximum Length*: `140`, *Pattern*: `[\w\W\s]*` |

## Example (as JSON)

```json
{
  "chargeType": "IOF_CONTRATACAO",
  "chargeAmount": "chargeAmount0",
  "chargeAdditionalInfo": null
}
```

