
# Referential Rate Indexer Type Enum

"Tipos de taxas referenciais ou indexadores, conforme Anexo 5: Taxa referencial ou Indexador (Indx), do Documento 3040"

## Enumeration

`ReferentialRateIndexerTypeEnum`

## Fields

| Name |
|  --- |
| `SEM_TIPO_INDEXADOR` |
| `PRE_FIXADO` |
| `POS_FIXADO` |
| `FLUTUANTES` |
| `INDICES_PRECOS` |
| `CREDITO_RURAL` |
| `OUTROS_INDEXADORES` |

