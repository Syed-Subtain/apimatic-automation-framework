
# Financings Releases

Lista dos pagamentos realizados no período

## Structure

`FinancingsReleases`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `payment_id` | `string` | Optional | Identificador de pagamento de responsabilidade de cada Instituição transmissora.<br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `100`, *Pattern*: `^[a-zA-Z0-9][a-zA-Z0-9-]{0,99}$` |
| `is_over_parcel_payment` | `bool` | Required | Identifica se é um pagamento pactuado (false) ou avulso (true). |
| `instalment_id` | `string` | Optional | Identificador de parcela, de responsabilidade de cada Instituição transmissora.  <br>[Restrição] Informação de envio obrigatório quando isOverParcelPayment tiver o valor FALSE.<br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `100`, *Pattern*: `^[a-zA-Z0-9][a-zA-Z0-9-]{0,99}$` |
| `paid_date` | `date` | Required | Data efetiva do pagamento referente ao contrato da modalidade de crédito consultada, conforme especificação RFC-3339. p.ex. 2014-03-19 |
| `currency` | `string` | Required | Moeda referente ao valor monetário informado, segundo modelo ISO-4217. p.ex. 'BRL'.<br>Todos os valores monetários informados estão representados com a moeda vigente do Brasil.<br>**Constraints**: *Maximum Length*: `3`, *Pattern*: `^(\w{3}){1}$` |
| `paid_amount` | `string` | Required | Valor do pagamento referente ao  contrato da modalidade de crédito consultada.<br>Expresso em valor monetário com no mínimo 2 casas e no máximo 4 casas decimais.<br>**Constraints**: *Minimum Length*: `4`, *Maximum Length*: `20`, *Pattern*: `^\d{1,15}\.\d{2,4}$` |
| `over_parcel` | [`FinancingsOverParcel`](../../doc/models/financings-over-parcel.md) | Optional | Objeto das tarifas e encargos que foram pagos fora da parcela.<br><br>[Restrição] Informação deve ser enviada caso ela exista. |

## Example (as JSON)

```json
{
  "paymentId": null,
  "isOverParcelPayment": false,
  "instalmentId": null,
  "paidDate": "2016-03-13",
  "currency": "currency0",
  "paidAmount": "paidAmount6",
  "overParcel": null
}
```

