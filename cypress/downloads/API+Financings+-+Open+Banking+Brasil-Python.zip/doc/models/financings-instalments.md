
# Financings Instalments

Conjunto de informações referentes às parcelas / prestações da operação de crédito de financiamentos contratada

## Structure

`FinancingsInstalments`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `type_number_of_instalments` | [`TypeNumberOfInstalmentsEnum`](../../doc/models/type-number-of-instalments-enum.md) | Required | Tipo de prazo total do contrato referente à modalidade de crédito informada. |
| `total_number_of_instalments` | `float` | Optional | Prazo Total segundo o tipo (dia, semana, mês, ano) referente à Modalidade de Crédito informada.<br><br>[Restrição] Obrigatoriamente deve ser preenchido caso o typeNumberOfInstalments seja diferente de SEM_PRAZO_TOTAL.<br>**Constraints**: `<= 999999` |
| `type_contract_remaining` | [`TypeContractRemainingEnum`](../../doc/models/type-contract-remaining-enum.md) | Required | Tipo de prazo remanescente do contrato referente à modalidade de crédito informada. |
| `contract_remaining_number` | `float` | Optional | Prazo Remanescente segundo o tipo (dia, semana, mês, ano) referente à Modalidade de Crédito informada.<br><br>[Restrição] Obrigatoriamente deve ser preenchido caso o typeContractRemaining seja diferente de SEM_PRAZO_REMANESCENTE.<br>**Constraints**: `<= 999999` |
| `paid_instalments` | `float` | Required | Quantidade de prestações pagas. (No caso de modalidades que não possuam parcelas, o número de prestações é igual a zero)<br>**Constraints**: `<= 999` |
| `due_instalments` | `float` | Optional | Quantidade de prestações a vencer.<br><br>[Restrição] Obrigatório para modalidades que possuam parcelas.<br>**Constraints**: `<= 999` |
| `past_due_instalments` | `float` | Optional | Quantidade de prestações vencidas.<br><br>[Restrição] Obrigatório para modalidades que possuam parcelas.<br>**Constraints**: `<= 999` |
| `balloon_payments` | [`List of FinancingsBalloonPayment`](../../doc/models/financings-balloon-payment.md) | Optional | Lista que traz as datas de vencimento e valor das parcelas não regulares do contrato da modalidade de crédito consultada<br>**Constraints**: *Minimum Items*: `1` |

## Example (as JSON)

```json
{
  "typeNumberOfInstalments": "ANO",
  "totalNumberOfInstalments": null,
  "typeContractRemaining": "SEM_PRAZO_REMANESCENTE",
  "contractRemainingNumber": null,
  "paidInstalments": 243.94,
  "dueInstalments": null,
  "pastDueInstalments": null,
  "balloonPayments": null
}
```

