
# Enum Product Type Enum

"Tipo da modalidade de crédito contratada, conforme  circular 4.015 e descrição do DOC3040 do SCR). (Vide Enum)
Financiamentos, Financiamentos rurais  e Financiamentos imobiliários"

## Enumeration

`EnumProductTypeEnum`

## Fields

| Name |
|  --- |
| `FINANCIAMENTOS` |
| `FINANCIAMENTOS_RURAIS` |
| `FINANCIAMENTOS_IMOBILIARIOS` |

