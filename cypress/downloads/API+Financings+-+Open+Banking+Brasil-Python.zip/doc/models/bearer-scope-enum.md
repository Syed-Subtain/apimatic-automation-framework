
# Bearer Scope Enum

OAuth 2 scopes supported by the API

## Enumeration

`BearerScopeEnum`

## Fields

| Name |
|  --- |
| `OPENID` |

