# O Auth Authorization

```python
o_auth_authorization_controller = client.o_auth_authorization
```

## Class Name

`OAuthAuthorizationController`

## Methods

* [Authorization Code Auth Request Token](../../doc/controllers/o-auth-authorization.md#authorization-code-auth-request-token)
* [Authorization Code Auth Refresh Token](../../doc/controllers/o-auth-authorization.md#authorization-code-auth-refresh-token)


# Authorization Code Auth Request Token

Create a new OAuth 2 token for authorization code auth.

:information_source: **Note** This endpoint does not require authentication.

```python
def authorization_code_auth_request_token(self,
                                         authorization,
                                         code,
                                         redirect_uri,
                                         _optional_form_parameters=None)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `authorization` | `string` | Header, Required | Authorization header in Basic auth format |
| `code` | `string` | Form, Required | Authorization Code |
| `redirect_uri` | `string` | Form, Required | Redirect Uri |
| `_optional_form_parameters` | `array` | Optional | Pass additional field parameters. |

## Response Type

[`OAuthToken`](../../doc/models/o-auth-token.md)

## Example Usage

```python
authorization = 'Authorization8'
code = 'code8'
redirect_uri = 'redirect_uri8'
_optional_form_parameters = {'key0' : 'additionalFieldParams9' } 

result = o_auth_authorization_controller.authorization_code_auth_request_token(authorization, code, redirect_uri, _optional_form_parameters)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | OAuth 2 provider returned an error. | [`OAuthProviderException`](../../doc/models/o-auth-provider-exception.md) |
| 401 | OAuth 2 provider says client authentication failed. | [`OAuthProviderException`](../../doc/models/o-auth-provider-exception.md) |


# Authorization Code Auth Refresh Token

Obtain a new access token using a refresh token for authorization code auth

:information_source: **Note** This endpoint does not require authentication.

```python
def authorization_code_auth_refresh_token(self,
                                         authorization,
                                         refresh_token,
                                         scope=None,
                                         _optional_form_parameters=None)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `authorization` | `string` | Header, Required | Authorization header in Basic auth format |
| `refresh_token` | `string` | Form, Required | Refresh token |
| `scope` | `string` | Form, Optional | Requested scopes as a space-delimited list. |
| `_optional_form_parameters` | `array` | Optional | Pass additional field parameters. |

## Response Type

[`OAuthToken`](../../doc/models/o-auth-token.md)

## Example Usage

```python
authorization = 'Authorization8'
refresh_token = 'refresh_token0'
_optional_form_parameters = {'key0' : 'additionalFieldParams9' } 

result = o_auth_authorization_controller.authorization_code_auth_refresh_token(authorization, refresh_token, None, _optional_form_parameters)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | OAuth 2 provider returned an error. | [`OAuthProviderException`](../../doc/models/o-auth-provider-exception.md) |
| 401 | OAuth 2 provider says client authentication failed. | [`OAuthProviderException`](../../doc/models/o-auth-provider-exception.md) |

