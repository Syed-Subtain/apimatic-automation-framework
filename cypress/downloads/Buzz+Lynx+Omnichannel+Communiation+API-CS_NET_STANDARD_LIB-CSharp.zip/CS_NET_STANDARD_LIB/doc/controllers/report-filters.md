# Report Filters

```csharp
ReportFiltersController reportFiltersController = client.ReportFiltersController;
```

## Class Name

`ReportFiltersController`


# Get a Report S Filters

`GET /iwin/api/v1/reports/{id}/filters`

Get a report's filters.

```csharp
GetAReportSFiltersAsync(
    string accept,
    string id)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `accept` | `string` | Header, Required | - |
| `id` | `string` | Template, Required | - |

## Response Type

`Task`

## Example Usage

```csharp
string accept = "application/json";
string id = "id0";

try
{
    await reportFiltersController.GetAReportSFiltersAsync(accept, id);
}
catch (ApiException e){};
```

