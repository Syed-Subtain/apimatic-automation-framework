# Sent Schedule Replies

A sent schedule can receive replies from message recipients. The replies can be read from this resource.
You can use this resource to act on replies in your application.

```csharp
SentScheduleRepliesController sentScheduleRepliesController = client.SentScheduleRepliesController;
```

## Class Name

`SentScheduleRepliesController`


# Get All Sent Schedule Replies

`GET /iwin/api/v1/sentschedules/{id}/replies`

View all the replies that were sent as a response to a scheduled message.

```csharp
GetAllSentScheduleRepliesAsync(
    string accept,
    string id)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `accept` | `string` | Header, Required | - |
| `id` | `string` | Template, Required | - |

## Response Type

`Task`

## Example Usage

```csharp
string accept = "application/json";
string id = "id0";

try
{
    await sentScheduleRepliesController.GetAllSentScheduleRepliesAsync(accept, id);
}
catch (ApiException e){};
```

