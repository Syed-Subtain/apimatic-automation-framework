# Sent Schedule Messages

View messages sent as part of a scheduled campaign. This would be all the messages that has been sent out as a sent schedule run.

```csharp
SentScheduleMessagesController sentScheduleMessagesController = client.SentScheduleMessagesController;
```

## Class Name

`SentScheduleMessagesController`


# Get All Sent Schedule Messages

`GET /iwin/api/v1/sentschedules/{id}/messages`

View all the messages sent out as part of a scheduled message run.

```csharp
GetAllSentScheduleMessagesAsync(
    string accept,
    string id)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `accept` | `string` | Header, Required | - |
| `id` | `string` | Template, Required | - |

## Response Type

`Task`

## Example Usage

```csharp
string accept = "application/json";
string id = "id0";

try
{
    await sentScheduleMessagesController.GetAllSentScheduleMessagesAsync(accept, id);
}
catch (ApiException e){};
```

