# Reports

```csharp
ReportsController reportsController = client.ReportsController;
```

## Class Name

`ReportsController`

## Methods

* [Get All Reports](../../doc/controllers/reports.md#get-all-reports)
* [Get a Report](../../doc/controllers/reports.md#get-a-report)


# Get All Reports

`GET /iwin/api/v1/reports`

Get all your reports.

```csharp
GetAllReportsAsync(
    string accept)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `accept` | `string` | Header, Required | - |

## Response Type

`Task`

## Example Usage

```csharp
string accept = "application/json";

try
{
    await reportsController.GetAllReportsAsync(accept);
}
catch (ApiException e){};
```


# Get a Report

`GET /iwin/api/v1/reports/{id}`

Get a report's data.

The parameters for this request will be determined by the report's filters.

See the next section on how to view a report's filters.

If a filter was not passed in, the default value for the filter will be used.

```csharp
GetAReportAsync(
    string accept)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `accept` | `string` | Header, Required | - |

## Response Type

`Task`

## Example Usage

```csharp
string accept = "application/json";

try
{
    await reportsController.GetAReportAsync(accept);
}
catch (ApiException e){};
```

