# Competitions

```csharp
CompetitionsController competitionsController = client.CompetitionsController;
```

## Class Name

`CompetitionsController`


# Get Competitions

`GET /iwin-competition/api/v1/competitions`

Get all your competitions (registered premium rated SMSes). To learn more about our Short Codes, go to http://www.iwin.co.za/shortcodes/.

```csharp
GetCompetitionsAsync(
    string accept)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `accept` | `string` | Header, Required | - |

## Response Type

`Task`

## Example Usage

```csharp
string accept = "application/json";

try
{
    await competitionsController.GetCompetitionsAsync(accept);
}
catch (ApiException e){};
```

