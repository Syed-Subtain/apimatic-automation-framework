# Phone Books

Phone books are groups of people that can be messaged at once.

```csharp
PhoneBooksController phoneBooksController = client.PhoneBooksController;
```

## Class Name

`PhoneBooksController`

## Methods

* [Update a Phone Book](../../doc/controllers/phone-books.md#update-a-phone-book)
* [Create a New Phone Book](../../doc/controllers/phone-books.md#create-a-new-phone-book)
* [Get a Phone Book](../../doc/controllers/phone-books.md#get-a-phone-book)
* [Get All Phone Books](../../doc/controllers/phone-books.md#get-all-phone-books)
* [Delete a Phone Book](../../doc/controllers/phone-books.md#delete-a-phone-book)


# Update a Phone Book

`PUT /iwin/api/v1/phonebooks/{id}`

Update a phone book. Values not present in the request will not be updated.

```csharp
UpdateAPhoneBookAsync(
    string contentType,
    string accept,
    Models.UpdateAPhoneBookRequest body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `contentType` | `string` | Header, Required | - |
| `accept` | `string` | Header, Required | - |
| `body` | [`Models.UpdateAPhoneBookRequest`](../../doc/models/update-a-phone-book-request.md) | Body, Required | - |

## Response Type

`Task`

## Example Usage

```csharp
string contentType = "application/json";
string accept = "application/json";
var body = new UpdateAPhoneBookRequest();
body.Name = "Soccer Moms and Dads";
body.Attribute3 = "ID";

try
{
    await phoneBooksController.UpdateAPhoneBookAsync(contentType, accept, body);
}
catch (ApiException e){};
```


# Create a New Phone Book

`POST /iwin/api/v1/phonebooks`

Add a new phone book. A phone book and its phone book entries are created separately. The phone book attribute fields are fields
that can be named to send personalized messages. For example, if attribute_1 has a value of "ID", a token
called &lt;ID&gt; can be used in messages, and the phone book entry (recipient) detail will be replaced in the message.

```csharp
CreateANewPhoneBookAsync(
    string contentType,
    string accept,
    Models.CreateANewPhoneBookRequest body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `contentType` | `string` | Header, Required | - |
| `accept` | `string` | Header, Required | - |
| `body` | [`Models.CreateANewPhoneBookRequest`](../../doc/models/create-a-new-phone-book-request.md) | Body, Required | - |

## Response Type

`Task`

## Example Usage

```csharp
string contentType = "application/json";
string accept = "application/json";
var body = new CreateANewPhoneBookRequest();
body.Name = "Soccer Moms";
body.Attribute1 = "ChildName";
body.Attribute2 = "Team";
body.Attribute3 = "AgeGroup";
body.Attribute4 = "Position";
body.Attribute5 = "ShirtSize";

try
{
    await phoneBooksController.CreateANewPhoneBookAsync(contentType, accept, body);
}
catch (ApiException e){};
```


# Get a Phone Book

`GET /iwin/api/v1/phonebooks/{id}`

View a single phone book.

```csharp
GetAPhoneBookAsync(
    string accept,
    string id)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `accept` | `string` | Header, Required | - |
| `id` | `string` | Template, Required | - |

## Response Type

`Task`

## Example Usage

```csharp
string accept = "application/json";
string id = "id0";

try
{
    await phoneBooksController.GetAPhoneBookAsync(accept, id);
}
catch (ApiException e){};
```


# Get All Phone Books

`GET /iwin/api/v1/phonebooks`

Get a list of all the phone books.

```csharp
GetAllPhoneBooksAsync(
    string accept)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `accept` | `string` | Header, Required | - |

## Response Type

`Task`

## Example Usage

```csharp
string accept = "application/json";

try
{
    await phoneBooksController.GetAllPhoneBooksAsync(accept);
}
catch (ApiException e){};
```


# Delete a Phone Book

`DELETE /iwin/api/v1/phonebooks/{id}`

Delete a phone book. Phone books already in use by a schedule cannot be deleted unless the schedule is also deleted.

```csharp
DeleteAPhoneBookAsync(
    string accept,
    string phoneBookId)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `accept` | `string` | Header, Required | - |
| `phoneBookId` | `string` | Template, Required | - |

## Response Type

`Task`

## Example Usage

```csharp
string accept = "application/json";
string phoneBookId = "phoneBookId2";

try
{
    await phoneBooksController.DeleteAPhoneBookAsync(accept, phoneBookId);
}
catch (ApiException e){};
```

