# Phone Books Entries

A phone book has multiple phone book entries containing recipient's details. If you plan on using tokens in your
messages, it is advisable to store the additonal attribute details for each phone book entry.

```csharp
PhoneBooksEntriesController phoneBooksEntriesController = client.PhoneBooksEntriesController;
```

## Class Name

`PhoneBooksEntriesController`

## Methods

* [Delete Phone Book Entry](../../doc/controllers/phone-books-entries.md#delete-phone-book-entry)
* [Get a Phone Book Entry](../../doc/controllers/phone-books-entries.md#get-a-phone-book-entry)
* [Create a New Phone Book Entry](../../doc/controllers/phone-books-entries.md#create-a-new-phone-book-entry)
* [Update Phone Book Entry](../../doc/controllers/phone-books-entries.md#update-phone-book-entry)
* [Get Phone Book Entries](../../doc/controllers/phone-books-entries.md#get-phone-book-entries)


# Delete Phone Book Entry

`DELETE /iwin/api/v1/phonebooks/{id}/entries/{entry_id}`

Delete a phone book entry.

```csharp
DeletePhoneBookEntryAsync(
    string accept,
    string id,
    string entryId)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `accept` | `string` | Header, Required | - |
| `id` | `string` | Template, Required | - |
| `entryId` | `string` | Template, Required | - |

## Response Type

`Task`

## Example Usage

```csharp
string accept = "application/json";
string id = "id0";
string entryId = "entryId2";

try
{
    await phoneBooksEntriesController.DeletePhoneBookEntryAsync(accept, id, entryId);
}
catch (ApiException e){};
```


# Get a Phone Book Entry

`GET /iwin/api/v1/phonebooks/{id}/entries/{entry_id}`

Get a single phone book entry.

```csharp
GetAPhoneBookEntryAsync(
    string accept,
    string id)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `accept` | `string` | Header, Required | - |
| `id` | `string` | Template, Required | - |

## Response Type

`Task`

## Example Usage

```csharp
string accept = "application/json";
string id = "id0";

try
{
    await phoneBooksEntriesController.GetAPhoneBookEntryAsync(accept, id);
}
catch (ApiException e){};
```


# Create a New Phone Book Entry

`POST /iwin/api/v1/phonebooks/{id}/entries`

Add a new phone book entry.

```csharp
CreateANewPhoneBookEntryAsync(
    string contentType,
    string accept,
    Models.CreateANewPhoneBookEntryRequest body,
    string id)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `contentType` | `string` | Header, Required | - |
| `accept` | `string` | Header, Required | - |
| `body` | [`Models.CreateANewPhoneBookEntryRequest`](../../doc/models/create-a-new-phone-book-entry-request.md) | Body, Required | - |
| `id` | `string` | Template, Required | - |

## Response Type

`Task`

## Example Usage

```csharp
string contentType = "application/json";
string accept = "application/json";
var body = new CreateANewPhoneBookEntryRequest();
body.MobileNumber = "mobile_number4";
body.Title = "title8";
body.FirstName = "first_name6";
body.LastName = "last_name4";
body.Attribute1 = "attribute_18";
body.Attribute2 = "attribute_28";
body.Attribute3 = "attribute_38";
body.Attribute4 = "attribute_46";
body.Attribute5 = "attribute_50";
string id = "id0";

try
{
    await phoneBooksEntriesController.CreateANewPhoneBookEntryAsync(contentType, accept, body, id);
}
catch (ApiException e){};
```


# Update Phone Book Entry

`PUT /iwin/api/v1/phonebooks/{id}/entries/{entry_id}`

Update a phone book entry. Only the values present in the request will be updated - the rest will be left unchanged.

```csharp
UpdatePhoneBookEntryAsync(
    string contentType,
    string accept,
    Models.UpdatePhoneBookEntryRequest body,
    string id,
    string entryId)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `contentType` | `string` | Header, Required | - |
| `accept` | `string` | Header, Required | - |
| `body` | [`Models.UpdatePhoneBookEntryRequest`](../../doc/models/update-phone-book-entry-request.md) | Body, Required | - |
| `id` | `string` | Template, Required | - |
| `entryId` | `string` | Template, Required | - |

## Response Type

`Task`

## Example Usage

```csharp
string contentType = "application/json";
string accept = "application/json";
var body = new UpdatePhoneBookEntryRequest();
body.MobileNumber = "821838384234";
body.Title = "Mrs";
body.FirstName = "Holly";
body.LastName = "Hunter";
body.Attribute1 = "Myron";
body.Attribute2 = "Team B";
string id = "id0";
string entryId = "entryId2";

try
{
    await phoneBooksEntriesController.UpdatePhoneBookEntryAsync(contentType, accept, body, id, entryId);
}
catch (ApiException e){};
```


# Get Phone Book Entries

`GET /iwin/api/v1/phonebooks/{id}/entries`

Get all the entries in a phone book.

```csharp
GetPhoneBookEntriesAsync(
    string accept,
    string id)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `accept` | `string` | Header, Required | - |
| `id` | `string` | Template, Required | - |

## Response Type

`Task`

## Example Usage

```csharp
string accept = "application/json";
string id = "id0";

try
{
    await phoneBooksEntriesController.GetPhoneBookEntriesAsync(accept, id);
}
catch (ApiException e){};
```

