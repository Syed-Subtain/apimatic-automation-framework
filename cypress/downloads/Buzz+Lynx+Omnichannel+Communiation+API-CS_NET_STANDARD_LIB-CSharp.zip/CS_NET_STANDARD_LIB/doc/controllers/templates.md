# Templates

Message templates are stored messages that can be resent and reused. Tokens can be used to personalize messages. To use a token,
wrap the token name in <>, all uppercase. Tokens must be defined in the associated phone book's attributes 1 to 5.

```csharp
TemplatesController templatesController = client.TemplatesController;
```

## Class Name

`TemplatesController`

## Methods

* [Create a New Template](../../doc/controllers/templates.md#create-a-new-template)
* [Delete a Template](../../doc/controllers/templates.md#delete-a-template)
* [Get All Templates](../../doc/controllers/templates.md#get-all-templates)
* [Get a Template](../../doc/controllers/templates.md#get-a-template)
* [Update a Template](../../doc/controllers/templates.md#update-a-template)


# Create a New Template

`POST /iwin/api/v1/templates`

Create a new template. A phone book ID can optionally be passed in, if you would like to use tokens in your messages.

```csharp
CreateANewTemplateAsync(
    string contentType,
    string accept,
    Models.CreateANewTemplateRequest body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `contentType` | `string` | Header, Required | - |
| `accept` | `string` | Header, Required | - |
| `body` | [`Models.CreateANewTemplateRequest`](../../doc/models/create-a-new-template-request.md) | Body, Required | - |

## Response Type

`Task`

## Example Usage

```csharp
string contentType = "application/json";
string accept = "application/json";
var body = new CreateANewTemplateRequest();
body.Name = "Soccer Practice Reminder";
body.Text = "Reminder: There is soccer practice on Wednesday at 16:00.";
body.PhoneBookId = "123";

try
{
    await templatesController.CreateANewTemplateAsync(contentType, accept, body);
}
catch (ApiException e){};
```


# Delete a Template

`DELETE /iwin/api/v1/templates/{id}`

Delete a template. A template can only be deleted if it does not belong to a schedule.

```csharp
DeleteATemplateAsync(
    string accept,
    string templateId)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `accept` | `string` | Header, Required | - |
| `templateId` | `string` | Template, Required | - |

## Response Type

`Task`

## Example Usage

```csharp
string accept = "application/json";
string templateId = "templateId0";

try
{
    await templatesController.DeleteATemplateAsync(accept, templateId);
}
catch (ApiException e){};
```


# Get All Templates

`GET /iwin/api/v1/templates`

Get all your message templates.

```csharp
GetAllTemplatesAsync(
    string accept)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `accept` | `string` | Header, Required | - |

## Response Type

`Task`

## Example Usage

```csharp
string accept = "application/json";

try
{
    await templatesController.GetAllTemplatesAsync(accept);
}
catch (ApiException e){};
```


# Get a Template

`GET /iwin/api/v1/templates/{id}`

Get a template.

```csharp
GetATemplateAsync(
    string accept,
    string templateId)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `accept` | `string` | Header, Required | - |
| `templateId` | `string` | Template, Required | - |

## Response Type

`Task`

## Example Usage

```csharp
string accept = "application/json";
string templateId = "templateId0";

try
{
    await templatesController.GetATemplateAsync(accept, templateId);
}
catch (ApiException e){};
```


# Update a Template

`PUT /iwin/api/v1/templates/{id}`

Update a template.

```csharp
UpdateATemplateAsync(
    string contentType,
    string accept,
    Models.UpdateATemplateRequest body,
    string templateId)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `contentType` | `string` | Header, Required | - |
| `accept` | `string` | Header, Required | - |
| `body` | [`Models.UpdateATemplateRequest`](../../doc/models/update-a-template-request.md) | Body, Required | - |
| `templateId` | `string` | Template, Required | - |

## Response Type

`Task`

## Example Usage

```csharp
string contentType = "application/json";
string accept = "application/json";
var body = new UpdateATemplateRequest();
body.Name = "Soccer Practice Reminder";
body.Text = "Reminder: There is soccer practice on Tuesday at 16:00.";
body.PhoneBookId = "123";
string templateId = "templateId0";

try
{
    await templatesController.UpdateATemplateAsync(contentType, accept, body, templateId);
}
catch (ApiException e){};
```

