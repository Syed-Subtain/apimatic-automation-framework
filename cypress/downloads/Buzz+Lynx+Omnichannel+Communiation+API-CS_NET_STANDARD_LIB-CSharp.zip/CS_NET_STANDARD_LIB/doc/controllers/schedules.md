# Schedules

While messages are great for sending out some messages on an ad-hoc basis, schedules are more suited for
sending out messages to regular groups. Schedules are also very useful for personalised messages.
There are two types of schedules:

- `once off` - Once off schedules will be sent only once.

- `recurring` - Recurring schedules will be sent between the start and end date, on the interval specified.

```csharp
SchedulesController schedulesController = client.SchedulesController;
```

## Class Name

`SchedulesController`

## Methods

* [Create a New Schedule](../../doc/controllers/schedules.md#create-a-new-schedule)
* [Get a Schedule](../../doc/controllers/schedules.md#get-a-schedule)
* [Update Activate a Schedule](../../doc/controllers/schedules.md#update-activate-a-schedule)
* [Delete a Schedule](../../doc/controllers/schedules.md#delete-a-schedule)
* [Update Suspend a Schedule](../../doc/controllers/schedules.md#update-suspend-a-schedule)
* [Get All Schedules](../../doc/controllers/schedules.md#get-all-schedules)


# Create a New Schedule

`POST /iwin/api/v1/schedules`

Create a new schedule.

```csharp
CreateANewScheduleAsync(
    string contentType,
    string accept,
    Models.CreateANewScheduleRequest body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `contentType` | `string` | Header, Required | - |
| `accept` | `string` | Header, Required | - |
| `body` | [`Models.CreateANewScheduleRequest`](../../doc/models/create-a-new-schedule-request.md) | Body, Required | - |

## Response Type

`Task`

## Example Usage

```csharp
string contentType = "application/json";
string accept = "application/json";
var body = new CreateANewScheduleRequest();
body.Name = "Soccer Practice Reminder";
body.Type = "recurring";
body.StartDate = "2015-11-08 14:00";
body.EndDate = "2015-11-20 14:00";
body.PhoneBookId = "59196";
body.TemplateId = "8465";
body.IntervalType = "days";
body.Interval = 30;

try
{
    await schedulesController.CreateANewScheduleAsync(contentType, accept, body);
}
catch (ApiException e){};
```


# Get a Schedule

`GET /iwin/api/v1/schedules/{id}`

Get a single schedule.

```csharp
GetAScheduleAsync(
    string accept,
    string scheduleId)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `accept` | `string` | Header, Required | - |
| `scheduleId` | `string` | Template, Required | - |

## Response Type

`Task`

## Example Usage

```csharp
string accept = "application/json";
string scheduleId = "scheduleId2";

try
{
    await schedulesController.GetAScheduleAsync(accept, scheduleId);
}
catch (ApiException e){};
```


# Update Activate a Schedule

`PUT /iwin/api/v1/schedules/{id}/activate`

It is only necessary to activate a schedule if it was suspended explicitly. After activation, the schedule status will be "active".

```csharp
UpdateActivateAScheduleAsync(
    string accept,
    string scheduleId)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `accept` | `string` | Header, Required | - |
| `scheduleId` | `string` | Template, Required | - |

## Response Type

`Task`

## Example Usage

```csharp
string accept = "application/json";
string scheduleId = "scheduleId2";

try
{
    await schedulesController.UpdateActivateAScheduleAsync(accept, scheduleId);
}
catch (ApiException e){};
```


# Delete a Schedule

`DELETE /iwin/api/v1/schedules/{id}`

Only schedules in status "suspended" can be deleted. Call `PUT /iwin/api/v1/schedules/{id}/suspend` to suspend a schedule.

```csharp
DeleteAScheduleAsync(
    string accept,
    string scheduleId)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `accept` | `string` | Header, Required | - |
| `scheduleId` | `string` | Template, Required | - |

## Response Type

`Task`

## Example Usage

```csharp
string accept = "application/json";
string scheduleId = "scheduleId2";

try
{
    await schedulesController.DeleteAScheduleAsync(accept, scheduleId);
}
catch (ApiException e){};
```


# Update Suspend a Schedule

`PUT /iwin/api/v1/schedules/{id}/suspend`

Suspending a schedule will temporary stop a scedule from running, until it is activated again. After suspending a schedule, the schedule status will be "suspended".

```csharp
UpdateSuspendAScheduleAsync(
    string accept,
    string scheduleId)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `accept` | `string` | Header, Required | - |
| `scheduleId` | `string` | Template, Required | - |

## Response Type

`Task`

## Example Usage

```csharp
string accept = "application/json";
string scheduleId = "scheduleId2";

try
{
    await schedulesController.UpdateSuspendAScheduleAsync(accept, scheduleId);
}
catch (ApiException e){};
```


# Get All Schedules

`GET /iwin/api/v1/schedules`

Get all schedules, both active and suspended.

```csharp
GetAllSchedulesAsync(
    string accept)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `accept` | `string` | Header, Required | - |

## Response Type

`Task`

## Example Usage

```csharp
string accept = "application/json";

try
{
    await schedulesController.GetAllSchedulesAsync(accept);
}
catch (ApiException e){};
```

