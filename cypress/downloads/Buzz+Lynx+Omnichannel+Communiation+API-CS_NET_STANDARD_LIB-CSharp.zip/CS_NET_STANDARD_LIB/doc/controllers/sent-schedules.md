# Sent Schedules

View schedules that have been sent. Each time a schedule is executed, a new sent schedule resource entry is added, which is viewable via the sentschedules resource.

For example, if a schedule is set up to run every 30 days, every 30 days an entry will be added to this resource. This enables you to view schedule that have been executed already.

```csharp
SentSchedulesController sentSchedulesController = client.SentSchedulesController;
```

## Class Name

`SentSchedulesController`

## Methods

* [Get All Sent Schedules](../../doc/controllers/sent-schedules.md#get-all-sent-schedules)
* [Get a Sent Schedule](../../doc/controllers/sent-schedules.md#get-a-sent-schedule)


# Get All Sent Schedules

`GET /iwin/api/v1/sentschedules`

Get a list of all the schedules that have been kicked off. The total messages sent by the schedule can be seen.

```csharp
GetAllSentSchedulesAsync(
    string accept)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `accept` | `string` | Header, Required | - |

## Response Type

`Task`

## Example Usage

```csharp
string accept = "application/json";

try
{
    await sentSchedulesController.GetAllSentSchedulesAsync(accept);
}
catch (ApiException e){};
```


# Get a Sent Schedule

`GET /iwin/api/v1/sentschedules/{id}`

Get a single sent schedule item. Extra information (successful, failed, delivered, pending and reply totals) can be seen from viewing a single sent schedule.

```csharp
GetASentScheduleAsync(
    string accept,
    string sentScheduleId)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `accept` | `string` | Header, Required | - |
| `sentScheduleId` | `string` | Template, Required | - |

## Response Type

`Task`

## Example Usage

```csharp
string accept = "application/json";
string sentScheduleId = "sentScheduleId8";

try
{
    await sentSchedulesController.GetASentScheduleAsync(accept, sentScheduleId);
}
catch (ApiException e){};
```

