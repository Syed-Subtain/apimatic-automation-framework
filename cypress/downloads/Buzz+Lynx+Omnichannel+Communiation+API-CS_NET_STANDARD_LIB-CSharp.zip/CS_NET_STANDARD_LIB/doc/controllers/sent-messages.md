# Sent Messages

View messages that have been sent. Sent messages can be used to monitor delivery status.

```csharp
SentMessagesController sentMessagesController = client.SentMessagesController;
```

## Class Name

`SentMessagesController`


# Get View Sent Messages

`GET /iwin/api/v1/sentmessages`

View all the sent messages.

```csharp
GetViewSentMessagesAsync(
    string accept)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `accept` | `string` | Header, Required | - |

## Response Type

`Task`

## Example Usage

```csharp
string accept = "application/json";

try
{
    await sentMessagesController.GetViewSentMessagesAsync(accept);
}
catch (ApiException e){};
```

