# Account

The account resource provides an interface to update your Iwin account.

```csharp
AccountController accountController = client.AccountController;
```

## Class Name

`AccountController`

## Methods

* [Get Account](../../doc/controllers/account.md#get-account)
* [Update Account](../../doc/controllers/account.md#update-account)


# Get Account

`GET /iwin/api/v1/account`

See your account details.

```csharp
GetAccountAsync(
    string accept)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `accept` | `string` | Header, Required | - |

## Response Type

`Task`

## Example Usage

```csharp
string accept = "application/json";

try
{
    await accountController.GetAccountAsync(accept);
}
catch (ApiException e){};
```


# Update Account

`PUT /iwin/api/v1/account`

Update your account details.

```csharp
UpdateAccountAsync(
    string contentType,
    string accept,
    Models.UpdateAccountRequest body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `contentType` | `string` | Header, Required | - |
| `accept` | `string` | Header, Required | - |
| `body` | [`Models.UpdateAccountRequest`](../../doc/models/update-account-request.md) | Body, Required | - |

## Response Type

`Task`

## Example Usage

```csharp
string contentType = "application/json";
string accept = "application/json";
var body = new UpdateAccountRequest();
body.FirstName = "Holly";
body.LastName = "Soccer practice will be on the 7th at 6.";
body.Email = "holly.hunter@company.com";
body.MobileNumber = "5557756235";
body.Password = "hunter";

try
{
    await accountController.UpdateAccountAsync(contentType, accept, body);
}
catch (ApiException e){};
```

