
# Send Messages Request

## Structure

`SendMessagesRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `MobileNumbers` | `string` | Required | - |
| `Message` | `string` | Required | - |

## Example (as JSON)

```json
{
  "mobile_numbers": "5558328328,55553942432",
  "message": "Soccer practice will be on the 7th at 6."
}
```

