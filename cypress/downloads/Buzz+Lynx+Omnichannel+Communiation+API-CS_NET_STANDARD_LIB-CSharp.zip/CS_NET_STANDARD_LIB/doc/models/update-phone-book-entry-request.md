
# Update Phone Book Entry Request

## Structure

`UpdatePhoneBookEntryRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `MobileNumber` | `string` | Required | - |
| `Title` | `string` | Required | - |
| `FirstName` | `string` | Required | - |
| `LastName` | `string` | Required | - |
| `Attribute1` | `string` | Required | - |
| `Attribute2` | `string` | Required | - |

## Example (as JSON)

```json
{
  "mobile_number": "821838384234",
  "title": "Mrs",
  "first_name": "Holly",
  "last_name": "Hunter",
  "attribute_1": "Myron",
  "attribute_2": "Team B"
}
```

