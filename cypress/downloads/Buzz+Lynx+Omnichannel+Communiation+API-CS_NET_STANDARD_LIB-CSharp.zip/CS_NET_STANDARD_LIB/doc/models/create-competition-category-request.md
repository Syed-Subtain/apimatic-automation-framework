
# Create Competition Category Request

## Structure

`CreateCompetitionCategoryRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Name` | `string` | Required | - |
| `Text` | `string` | Required | - |
| `CreateDate` | `string` | Required | - |

## Example (as JSON)

```json
{
  "name": "Soccer Practice Reminder",
  "text": "Reminder: There is soccer practice on Wednesday at 16:00.",
  "create_date": "2015-12-08 16:47:45"
}
```

