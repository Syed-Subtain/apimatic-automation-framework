// <copyright file="SentSchedulesControllerTest.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace BuzzLynxOmnichannelCommuniationAPI.Tests
{
    using System;
    using System.Collections.Generic;
    using System.Globalization;
    using System.IO;
    using System.Threading.Tasks;
    using BuzzLynxOmnichannelCommuniationAPI.Standard;
    using BuzzLynxOmnichannelCommuniationAPI.Standard.Controllers;
    using BuzzLynxOmnichannelCommuniationAPI.Standard.Exceptions;
    using BuzzLynxOmnichannelCommuniationAPI.Standard.Http.Client;
    using BuzzLynxOmnichannelCommuniationAPI.Standard.Http.Response;
    using BuzzLynxOmnichannelCommuniationAPI.Standard.Utilities;
    using BuzzLynxOmnichannelCommuniationAPI.Tests.Helpers;
    using Newtonsoft.Json.Converters;
    using NUnit.Framework;

    /// <summary>
    /// SentSchedulesControllerTest.
    /// </summary>
    [TestFixture]
    public class SentSchedulesControllerTest : ControllerTestBase
    {
        /// <summary>
        /// Controller instance (for all tests).
        /// </summary>
        private SentSchedulesController controller;

        /// <summary>
        /// Setup test class.
        /// </summary>
        [OneTimeSetUp]
        public void SetUpDerived()
        {
            this.controller = this.Client.SentSchedulesController;
        }

        /// <summary>
        /// `GET /iwin/api/v1/sentschedules`
        ///
        ///Get a list of all the schedules that have been kicked off. The total messages sent by the schedule can be seen.
        ///
        ///.
        /// </summary>
        /// <returns>A <see cref="Task"/> representing the asynchronous unit test.</returns>
        [Test]
        public async Task TestGetAllSentSchedules()
        {
            // Parameters for the API call
            string accept = "application/json";

            // Perform API call
            try
            {
                await this.controller.GetAllSentSchedulesAsync(accept);
            }
            catch (ApiException)
            {
            }

            // Test response code
            Assert.AreEqual(200, this.HttpCallBackHandler.Response.StatusCode, "Status should be 200");
        }
    }
}