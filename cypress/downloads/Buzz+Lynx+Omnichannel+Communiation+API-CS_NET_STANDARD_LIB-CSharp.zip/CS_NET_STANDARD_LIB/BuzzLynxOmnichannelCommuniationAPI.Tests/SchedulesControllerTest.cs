// <copyright file="SchedulesControllerTest.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace BuzzLynxOmnichannelCommuniationAPI.Tests
{
    using System;
    using System.Collections.Generic;
    using System.Globalization;
    using System.IO;
    using System.Threading.Tasks;
    using BuzzLynxOmnichannelCommuniationAPI.Standard;
    using BuzzLynxOmnichannelCommuniationAPI.Standard.Controllers;
    using BuzzLynxOmnichannelCommuniationAPI.Standard.Exceptions;
    using BuzzLynxOmnichannelCommuniationAPI.Standard.Http.Client;
    using BuzzLynxOmnichannelCommuniationAPI.Standard.Http.Response;
    using BuzzLynxOmnichannelCommuniationAPI.Standard.Utilities;
    using BuzzLynxOmnichannelCommuniationAPI.Tests.Helpers;
    using Newtonsoft.Json.Converters;
    using NUnit.Framework;

    /// <summary>
    /// SchedulesControllerTest.
    /// </summary>
    [TestFixture]
    public class SchedulesControllerTest : ControllerTestBase
    {
        /// <summary>
        /// Controller instance (for all tests).
        /// </summary>
        private SchedulesController controller;

        /// <summary>
        /// Setup test class.
        /// </summary>
        [OneTimeSetUp]
        public void SetUpDerived()
        {
            this.controller = this.Client.SchedulesController;
        }

        /// <summary>
        /// `POST /iwin/api/v1/schedules`
        ///
        ///Create a new schedule.
        ///
        ///.
        /// </summary>
        /// <returns>A <see cref="Task"/> representing the asynchronous unit test.</returns>
        [Test]
        public async Task TestCreateANewSchedule()
        {
            // Parameters for the API call
            string contentType = "application/json";
            string accept = "application/json";
            Standard.Models.CreateANewScheduleRequest body = ApiHelper.JsonDeserialize<Standard.Models.CreateANewScheduleRequest>("{
  \"name\": \"Soccer Practice Reminder\",
  \"type\": \"recurring\",
  \"start_date\": \"2015-11-08 14:00\",
  \"end_date\": \"2015-11-20 14:00\",
  \"phone_book_id\": \"59196\",
  \"template_id\": \"8465\",
  \"interval_type\": \"days\",
  \"interval\": 30
}");

            // Perform API call
            try
            {
                await this.controller.CreateANewScheduleAsync(contentType, accept, body);
            }
            catch (ApiException)
            {
            }

            // Test response code
            Assert.AreEqual(200, this.HttpCallBackHandler.Response.StatusCode, "Status should be 200");
        }

        /// <summary>
        /// `GET /iwin/api/v1/schedules`
        ///
        ///Get all schedules, both active and suspended.
        ///
        ///.
        /// </summary>
        /// <returns>A <see cref="Task"/> representing the asynchronous unit test.</returns>
        [Test]
        public async Task TestGetAllSchedules()
        {
            // Parameters for the API call
            string accept = "application/json";

            // Perform API call
            try
            {
                await this.controller.GetAllSchedulesAsync(accept);
            }
            catch (ApiException)
            {
            }

            // Test response code
            Assert.AreEqual(200, this.HttpCallBackHandler.Response.StatusCode, "Status should be 200");
        }
    }
}