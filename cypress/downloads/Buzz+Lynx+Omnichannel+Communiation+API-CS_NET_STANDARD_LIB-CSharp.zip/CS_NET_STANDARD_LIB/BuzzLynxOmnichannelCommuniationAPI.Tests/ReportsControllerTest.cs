// <copyright file="ReportsControllerTest.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace BuzzLynxOmnichannelCommuniationAPI.Tests
{
    using System;
    using System.Collections.Generic;
    using System.Globalization;
    using System.IO;
    using System.Threading.Tasks;
    using BuzzLynxOmnichannelCommuniationAPI.Standard;
    using BuzzLynxOmnichannelCommuniationAPI.Standard.Controllers;
    using BuzzLynxOmnichannelCommuniationAPI.Standard.Exceptions;
    using BuzzLynxOmnichannelCommuniationAPI.Standard.Http.Client;
    using BuzzLynxOmnichannelCommuniationAPI.Standard.Http.Response;
    using BuzzLynxOmnichannelCommuniationAPI.Standard.Utilities;
    using BuzzLynxOmnichannelCommuniationAPI.Tests.Helpers;
    using Newtonsoft.Json.Converters;
    using NUnit.Framework;

    /// <summary>
    /// ReportsControllerTest.
    /// </summary>
    [TestFixture]
    public class ReportsControllerTest : ControllerTestBase
    {
        /// <summary>
        /// Controller instance (for all tests).
        /// </summary>
        private ReportsController controller;

        /// <summary>
        /// Setup test class.
        /// </summary>
        [OneTimeSetUp]
        public void SetUpDerived()
        {
            this.controller = this.Client.ReportsController;
        }

        /// <summary>
        /// `GET /iwin/api/v1/reports`
        ///
        ///Get all your reports.
        ///
        ///.
        /// </summary>
        /// <returns>A <see cref="Task"/> representing the asynchronous unit test.</returns>
        [Test]
        public async Task TestGetAllReports()
        {
            // Parameters for the API call
            string accept = "application/json";

            // Perform API call
            try
            {
                await this.controller.GetAllReportsAsync(accept);
            }
            catch (ApiException)
            {
            }

            // Test response code
            Assert.AreEqual(200, this.HttpCallBackHandler.Response.StatusCode, "Status should be 200");
        }

        /// <summary>
        /// `GET /iwin/api/v1/reports/{id}`
        ///
        ///Get a report's data.
        ///
        ///The parameters for this request will be determined by the report's filters. 
        ///
        ///See the next section on how to view a report's filters.
        ///
        ///If a filter was not passed in, the default value for the filter will be used.
        ///
        ///
        ///.
        /// </summary>
        /// <returns>A <see cref="Task"/> representing the asynchronous unit test.</returns>
        [Test]
        public async Task TestGetAReport()
        {
            // Parameters for the API call
            string accept = "application/json";

            // Perform API call
            try
            {
                await this.controller.GetAReportAsync(accept);
            }
            catch (ApiException)
            {
            }

            // Test response code
            Assert.AreEqual(200, this.HttpCallBackHandler.Response.StatusCode, "Status should be 200");
        }
    }
}