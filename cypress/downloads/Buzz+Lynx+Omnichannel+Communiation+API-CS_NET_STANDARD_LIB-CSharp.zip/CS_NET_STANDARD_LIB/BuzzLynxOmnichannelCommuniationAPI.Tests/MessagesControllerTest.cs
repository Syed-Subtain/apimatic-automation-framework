// <copyright file="MessagesControllerTest.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace BuzzLynxOmnichannelCommuniationAPI.Tests
{
    using System;
    using System.Collections.Generic;
    using System.Globalization;
    using System.IO;
    using System.Threading.Tasks;
    using BuzzLynxOmnichannelCommuniationAPI.Standard;
    using BuzzLynxOmnichannelCommuniationAPI.Standard.Controllers;
    using BuzzLynxOmnichannelCommuniationAPI.Standard.Exceptions;
    using BuzzLynxOmnichannelCommuniationAPI.Standard.Http.Client;
    using BuzzLynxOmnichannelCommuniationAPI.Standard.Http.Response;
    using BuzzLynxOmnichannelCommuniationAPI.Standard.Utilities;
    using BuzzLynxOmnichannelCommuniationAPI.Tests.Helpers;
    using Newtonsoft.Json.Converters;
    using NUnit.Framework;

    /// <summary>
    /// MessagesControllerTest.
    /// </summary>
    [TestFixture]
    public class MessagesControllerTest : ControllerTestBase
    {
        /// <summary>
        /// Controller instance (for all tests).
        /// </summary>
        private MessagesController controller;

        /// <summary>
        /// Setup test class.
        /// </summary>
        [OneTimeSetUp]
        public void SetUpDerived()
        {
            this.controller = this.Client.MessagesController;
        }

        /// <summary>
        /// `POST /iwin/api/v1/messages`
        ///
        ///Send a message to one or more recipients.
        ///
        ///.
        /// </summary>
        /// <returns>A <see cref="Task"/> representing the asynchronous unit test.</returns>
        [Test]
        public async Task TestSendMessages()
        {
            // Parameters for the API call
            string contentType = "application/json";
            string accept = "application/json";
            Standard.Models.SendMessagesRequest body = ApiHelper.JsonDeserialize<Standard.Models.SendMessagesRequest>("{
  \"mobile_numbers\": \"5558328328,55553942432\",
  \"message\": \"Soccer practice will be on the 7th at 6.\"
}");

            // Perform API call
            try
            {
                await this.controller.CreateSendMessagesAsync(contentType, accept, body);
            }
            catch (ApiException)
            {
            }

            // Test response code
            Assert.AreEqual(200, this.HttpCallBackHandler.Response.StatusCode, "Status should be 200");
        }

        /// <summary>
        /// `GET /iwin-competition/api/v1/competitions/messages`
        ///
        ///Get all the messages received for all your short codes, with their categories. If you run a competition, the messages will contain the votes per category, per short code.
        ///The short code is your premium rate SMS number. The short code and competition ID is linked together. The total field contains the amount of messages received for this competition and category.
        ///
        ///.
        /// </summary>
        /// <returns>A <see cref="Task"/> representing the asynchronous unit test.</returns>
        [Test]
        public async Task TestGetMessages()
        {
            // Parameters for the API call
            string accept = "application/json";

            // Perform API call
            try
            {
                await this.controller.GetMessagesAsync(accept);
            }
            catch (ApiException)
            {
            }

            // Test response code
            Assert.AreEqual(200, this.HttpCallBackHandler.Response.StatusCode, "Status should be 200");
        }
    }
}