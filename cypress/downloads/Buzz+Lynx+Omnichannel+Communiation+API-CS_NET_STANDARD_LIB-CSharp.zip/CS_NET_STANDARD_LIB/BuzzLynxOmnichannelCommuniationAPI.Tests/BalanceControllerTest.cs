// <copyright file="BalanceControllerTest.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace BuzzLynxOmnichannelCommuniationAPI.Tests
{
    using System;
    using System.Collections.Generic;
    using System.Globalization;
    using System.IO;
    using System.Threading.Tasks;
    using BuzzLynxOmnichannelCommuniationAPI.Standard;
    using BuzzLynxOmnichannelCommuniationAPI.Standard.Controllers;
    using BuzzLynxOmnichannelCommuniationAPI.Standard.Exceptions;
    using BuzzLynxOmnichannelCommuniationAPI.Standard.Http.Client;
    using BuzzLynxOmnichannelCommuniationAPI.Standard.Http.Response;
    using BuzzLynxOmnichannelCommuniationAPI.Standard.Utilities;
    using BuzzLynxOmnichannelCommuniationAPI.Tests.Helpers;
    using Newtonsoft.Json.Converters;
    using NUnit.Framework;

    /// <summary>
    /// BalanceControllerTest.
    /// </summary>
    [TestFixture]
    public class BalanceControllerTest : ControllerTestBase
    {
        /// <summary>
        /// Controller instance (for all tests).
        /// </summary>
        private BalanceController controller;

        /// <summary>
        /// Setup test class.
        /// </summary>
        [OneTimeSetUp]
        public void SetUpDerived()
        {
            this.controller = this.Client.BalanceController;
        }

        /// <summary>
        /// `GET /iwin/api/v1/balance`
        ///
        ///Get your Iwin balance. Your balance is the number of messages that can be sent until your account balance is depleted.
        ///
        ///.
        /// </summary>
        /// <returns>A <see cref="Task"/> representing the asynchronous unit test.</returns>
        [Test]
        public async Task TestGetBalance()
        {
            // Parameters for the API call
            string accept = "application/json";

            // Perform API call
            try
            {
                await this.controller.GetBalanceAsync(accept);
            }
            catch (ApiException)
            {
            }

            // Test response code
            Assert.AreEqual(200, this.HttpCallBackHandler.Response.StatusCode, "Status should be 200");
        }
    }
}