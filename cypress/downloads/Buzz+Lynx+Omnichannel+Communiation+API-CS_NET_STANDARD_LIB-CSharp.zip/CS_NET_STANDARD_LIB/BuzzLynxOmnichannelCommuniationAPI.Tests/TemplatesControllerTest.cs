// <copyright file="TemplatesControllerTest.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace BuzzLynxOmnichannelCommuniationAPI.Tests
{
    using System;
    using System.Collections.Generic;
    using System.Globalization;
    using System.IO;
    using System.Threading.Tasks;
    using BuzzLynxOmnichannelCommuniationAPI.Standard;
    using BuzzLynxOmnichannelCommuniationAPI.Standard.Controllers;
    using BuzzLynxOmnichannelCommuniationAPI.Standard.Exceptions;
    using BuzzLynxOmnichannelCommuniationAPI.Standard.Http.Client;
    using BuzzLynxOmnichannelCommuniationAPI.Standard.Http.Response;
    using BuzzLynxOmnichannelCommuniationAPI.Standard.Utilities;
    using BuzzLynxOmnichannelCommuniationAPI.Tests.Helpers;
    using Newtonsoft.Json.Converters;
    using NUnit.Framework;

    /// <summary>
    /// TemplatesControllerTest.
    /// </summary>
    [TestFixture]
    public class TemplatesControllerTest : ControllerTestBase
    {
        /// <summary>
        /// Controller instance (for all tests).
        /// </summary>
        private TemplatesController controller;

        /// <summary>
        /// Setup test class.
        /// </summary>
        [OneTimeSetUp]
        public void SetUpDerived()
        {
            this.controller = this.Client.TemplatesController;
        }

        /// <summary>
        /// `POST /iwin/api/v1/templates`
        ///
        ///Create a new template. A phone book ID can optionally be passed in, if you would like to use tokens in your messages.
        ///
        ///.
        /// </summary>
        /// <returns>A <see cref="Task"/> representing the asynchronous unit test.</returns>
        [Test]
        public async Task TestCreateANewTemplate()
        {
            // Parameters for the API call
            string contentType = "application/json";
            string accept = "application/json";
            Standard.Models.CreateANewTemplateRequest body = ApiHelper.JsonDeserialize<Standard.Models.CreateANewTemplateRequest>("{
  \"name\": \"Soccer Practice Reminder\",
  \"text\": \"Reminder: There is soccer practice on Wednesday at 16:00.\",
  \"phone_book_id\": \"123\"
}");

            // Perform API call
            try
            {
                await this.controller.CreateANewTemplateAsync(contentType, accept, body);
            }
            catch (ApiException)
            {
            }

            // Test response code
            Assert.AreEqual(200, this.HttpCallBackHandler.Response.StatusCode, "Status should be 200");
        }

        /// <summary>
        /// `GET /iwin/api/v1/templates`
        ///
        ///Get all your message templates.
        ///
        ///.
        /// </summary>
        /// <returns>A <see cref="Task"/> representing the asynchronous unit test.</returns>
        [Test]
        public async Task TestGetAllTemplates()
        {
            // Parameters for the API call
            string accept = "application/json";

            // Perform API call
            try
            {
                await this.controller.GetAllTemplatesAsync(accept);
            }
            catch (ApiException)
            {
            }

            // Test response code
            Assert.AreEqual(200, this.HttpCallBackHandler.Response.StatusCode, "Status should be 200");
        }
    }
}