// <copyright file="PhoneBooksControllerTest.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace BuzzLynxOmnichannelCommuniationAPI.Tests
{
    using System;
    using System.Collections.Generic;
    using System.Globalization;
    using System.IO;
    using System.Threading.Tasks;
    using BuzzLynxOmnichannelCommuniationAPI.Standard;
    using BuzzLynxOmnichannelCommuniationAPI.Standard.Controllers;
    using BuzzLynxOmnichannelCommuniationAPI.Standard.Exceptions;
    using BuzzLynxOmnichannelCommuniationAPI.Standard.Http.Client;
    using BuzzLynxOmnichannelCommuniationAPI.Standard.Http.Response;
    using BuzzLynxOmnichannelCommuniationAPI.Standard.Utilities;
    using BuzzLynxOmnichannelCommuniationAPI.Tests.Helpers;
    using Newtonsoft.Json.Converters;
    using NUnit.Framework;

    /// <summary>
    /// PhoneBooksControllerTest.
    /// </summary>
    [TestFixture]
    public class PhoneBooksControllerTest : ControllerTestBase
    {
        /// <summary>
        /// Controller instance (for all tests).
        /// </summary>
        private PhoneBooksController controller;

        /// <summary>
        /// Setup test class.
        /// </summary>
        [OneTimeSetUp]
        public void SetUpDerived()
        {
            this.controller = this.Client.PhoneBooksController;
        }

        /// <summary>
        /// `PUT /iwin/api/v1/phonebooks/{id}`
        ///
        ///Update a phone book. Values not present in the request will not be updated.
        ///
        ///.
        /// </summary>
        /// <returns>A <see cref="Task"/> representing the asynchronous unit test.</returns>
        [Test]
        public async Task TestUpdateAPhoneBook()
        {
            // Parameters for the API call
            string contentType = "application/json";
            string accept = "application/json";
            Standard.Models.UpdateAPhoneBookRequest body = ApiHelper.JsonDeserialize<Standard.Models.UpdateAPhoneBookRequest>("{
  \"name\": \"Soccer Moms and Dads\",
  \"attribute_3\": \"ID\"
}");

            // Perform API call
            try
            {
                await this.controller.UpdateAPhoneBookAsync(contentType, accept, body);
            }
            catch (ApiException)
            {
            }

            // Test response code
            Assert.AreEqual(200, this.HttpCallBackHandler.Response.StatusCode, "Status should be 200");
        }

        /// <summary>
        /// `GET /iwin/api/v1/phonebooks`
        ///
        ///Get a list of all the phone books.
        ///
        ///.
        /// </summary>
        /// <returns>A <see cref="Task"/> representing the asynchronous unit test.</returns>
        [Test]
        public async Task TestGetAllPhoneBooks()
        {
            // Parameters for the API call
            string accept = "application/json";

            // Perform API call
            try
            {
                await this.controller.GetAllPhoneBooksAsync(accept);
            }
            catch (ApiException)
            {
            }

            // Test response code
            Assert.AreEqual(200, this.HttpCallBackHandler.Response.StatusCode, "Status should be 200");
        }
    }
}