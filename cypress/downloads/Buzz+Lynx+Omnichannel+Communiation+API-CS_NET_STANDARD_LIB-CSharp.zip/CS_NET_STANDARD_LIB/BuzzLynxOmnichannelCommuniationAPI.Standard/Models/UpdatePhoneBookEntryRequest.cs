// <copyright file="UpdatePhoneBookEntryRequest.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace BuzzLynxOmnichannelCommuniationAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using BuzzLynxOmnichannelCommuniationAPI.Standard;
    using BuzzLynxOmnichannelCommuniationAPI.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// UpdatePhoneBookEntryRequest.
    /// </summary>
    public class UpdatePhoneBookEntryRequest
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="UpdatePhoneBookEntryRequest"/> class.
        /// </summary>
        public UpdatePhoneBookEntryRequest()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="UpdatePhoneBookEntryRequest"/> class.
        /// </summary>
        /// <param name="mobileNumber">mobile_number.</param>
        /// <param name="title">title.</param>
        /// <param name="firstName">first_name.</param>
        /// <param name="lastName">last_name.</param>
        /// <param name="attribute1">attribute_1.</param>
        /// <param name="attribute2">attribute_2.</param>
        public UpdatePhoneBookEntryRequest(
            string mobileNumber,
            string title,
            string firstName,
            string lastName,
            string attribute1,
            string attribute2)
        {
            this.MobileNumber = mobileNumber;
            this.Title = title;
            this.FirstName = firstName;
            this.LastName = lastName;
            this.Attribute1 = attribute1;
            this.Attribute2 = attribute2;
        }

        /// <summary>
        /// Gets or sets MobileNumber.
        /// </summary>
        [JsonProperty("mobile_number")]
        public string MobileNumber { get; set; }

        /// <summary>
        /// Gets or sets Title.
        /// </summary>
        [JsonProperty("title")]
        public string Title { get; set; }

        /// <summary>
        /// Gets or sets FirstName.
        /// </summary>
        [JsonProperty("first_name")]
        public string FirstName { get; set; }

        /// <summary>
        /// Gets or sets LastName.
        /// </summary>
        [JsonProperty("last_name")]
        public string LastName { get; set; }

        /// <summary>
        /// Gets or sets Attribute1.
        /// </summary>
        [JsonProperty("attribute_1")]
        public string Attribute1 { get; set; }

        /// <summary>
        /// Gets or sets Attribute2.
        /// </summary>
        [JsonProperty("attribute_2")]
        public string Attribute2 { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"UpdatePhoneBookEntryRequest : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is UpdatePhoneBookEntryRequest other &&
                ((this.MobileNumber == null && other.MobileNumber == null) || (this.MobileNumber?.Equals(other.MobileNumber) == true)) &&
                ((this.Title == null && other.Title == null) || (this.Title?.Equals(other.Title) == true)) &&
                ((this.FirstName == null && other.FirstName == null) || (this.FirstName?.Equals(other.FirstName) == true)) &&
                ((this.LastName == null && other.LastName == null) || (this.LastName?.Equals(other.LastName) == true)) &&
                ((this.Attribute1 == null && other.Attribute1 == null) || (this.Attribute1?.Equals(other.Attribute1) == true)) &&
                ((this.Attribute2 == null && other.Attribute2 == null) || (this.Attribute2?.Equals(other.Attribute2) == true));
        }
        

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.MobileNumber = {(this.MobileNumber == null ? "null" : this.MobileNumber == string.Empty ? "" : this.MobileNumber)}");
            toStringOutput.Add($"this.Title = {(this.Title == null ? "null" : this.Title == string.Empty ? "" : this.Title)}");
            toStringOutput.Add($"this.FirstName = {(this.FirstName == null ? "null" : this.FirstName == string.Empty ? "" : this.FirstName)}");
            toStringOutput.Add($"this.LastName = {(this.LastName == null ? "null" : this.LastName == string.Empty ? "" : this.LastName)}");
            toStringOutput.Add($"this.Attribute1 = {(this.Attribute1 == null ? "null" : this.Attribute1 == string.Empty ? "" : this.Attribute1)}");
            toStringOutput.Add($"this.Attribute2 = {(this.Attribute2 == null ? "null" : this.Attribute2 == string.Empty ? "" : this.Attribute2)}");
        }
    }
}