// <copyright file="CreateANewTemplateRequest.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace BuzzLynxOmnichannelCommuniationAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using BuzzLynxOmnichannelCommuniationAPI.Standard;
    using BuzzLynxOmnichannelCommuniationAPI.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// CreateANewTemplateRequest.
    /// </summary>
    public class CreateANewTemplateRequest
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="CreateANewTemplateRequest"/> class.
        /// </summary>
        public CreateANewTemplateRequest()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="CreateANewTemplateRequest"/> class.
        /// </summary>
        /// <param name="name">name.</param>
        /// <param name="text">text.</param>
        /// <param name="phoneBookId">phone_book_id.</param>
        public CreateANewTemplateRequest(
            string name,
            string text,
            string phoneBookId)
        {
            this.Name = name;
            this.Text = text;
            this.PhoneBookId = phoneBookId;
        }

        /// <summary>
        /// Gets or sets Name.
        /// </summary>
        [JsonProperty("name")]
        public string Name { get; set; }

        /// <summary>
        /// Gets or sets Text.
        /// </summary>
        [JsonProperty("text")]
        public string Text { get; set; }

        /// <summary>
        /// Gets or sets PhoneBookId.
        /// </summary>
        [JsonProperty("phone_book_id")]
        public string PhoneBookId { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"CreateANewTemplateRequest : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is CreateANewTemplateRequest other &&
                ((this.Name == null && other.Name == null) || (this.Name?.Equals(other.Name) == true)) &&
                ((this.Text == null && other.Text == null) || (this.Text?.Equals(other.Text) == true)) &&
                ((this.PhoneBookId == null && other.PhoneBookId == null) || (this.PhoneBookId?.Equals(other.PhoneBookId) == true));
        }
        

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.Name = {(this.Name == null ? "null" : this.Name == string.Empty ? "" : this.Name)}");
            toStringOutput.Add($"this.Text = {(this.Text == null ? "null" : this.Text == string.Empty ? "" : this.Text)}");
            toStringOutput.Add($"this.PhoneBookId = {(this.PhoneBookId == null ? "null" : this.PhoneBookId == string.Empty ? "" : this.PhoneBookId)}");
        }
    }
}