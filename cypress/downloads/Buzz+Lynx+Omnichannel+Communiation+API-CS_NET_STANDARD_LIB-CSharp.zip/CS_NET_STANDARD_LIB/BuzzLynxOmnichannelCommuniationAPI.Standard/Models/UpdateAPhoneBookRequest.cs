// <copyright file="UpdateAPhoneBookRequest.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace BuzzLynxOmnichannelCommuniationAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using BuzzLynxOmnichannelCommuniationAPI.Standard;
    using BuzzLynxOmnichannelCommuniationAPI.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// UpdateAPhoneBookRequest.
    /// </summary>
    public class UpdateAPhoneBookRequest
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="UpdateAPhoneBookRequest"/> class.
        /// </summary>
        public UpdateAPhoneBookRequest()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="UpdateAPhoneBookRequest"/> class.
        /// </summary>
        /// <param name="name">name.</param>
        /// <param name="attribute3">attribute_3.</param>
        public UpdateAPhoneBookRequest(
            string name,
            string attribute3)
        {
            this.Name = name;
            this.Attribute3 = attribute3;
        }

        /// <summary>
        /// Gets or sets Name.
        /// </summary>
        [JsonProperty("name")]
        public string Name { get; set; }

        /// <summary>
        /// Gets or sets Attribute3.
        /// </summary>
        [JsonProperty("attribute_3")]
        public string Attribute3 { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"UpdateAPhoneBookRequest : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is UpdateAPhoneBookRequest other &&
                ((this.Name == null && other.Name == null) || (this.Name?.Equals(other.Name) == true)) &&
                ((this.Attribute3 == null && other.Attribute3 == null) || (this.Attribute3?.Equals(other.Attribute3) == true));
        }
        

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.Name = {(this.Name == null ? "null" : this.Name == string.Empty ? "" : this.Name)}");
            toStringOutput.Add($"this.Attribute3 = {(this.Attribute3 == null ? "null" : this.Attribute3 == string.Empty ? "" : this.Attribute3)}");
        }
    }
}