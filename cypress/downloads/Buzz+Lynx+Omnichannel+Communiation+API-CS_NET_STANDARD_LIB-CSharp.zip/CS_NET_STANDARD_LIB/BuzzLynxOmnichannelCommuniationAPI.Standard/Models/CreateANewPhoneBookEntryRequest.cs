// <copyright file="CreateANewPhoneBookEntryRequest.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace BuzzLynxOmnichannelCommuniationAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using BuzzLynxOmnichannelCommuniationAPI.Standard;
    using BuzzLynxOmnichannelCommuniationAPI.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// CreateANewPhoneBookEntryRequest.
    /// </summary>
    public class CreateANewPhoneBookEntryRequest
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="CreateANewPhoneBookEntryRequest"/> class.
        /// </summary>
        public CreateANewPhoneBookEntryRequest()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="CreateANewPhoneBookEntryRequest"/> class.
        /// </summary>
        /// <param name="mobileNumber">mobile_number.</param>
        /// <param name="title">title.</param>
        /// <param name="firstName">first_name.</param>
        /// <param name="lastName">last_name.</param>
        /// <param name="attribute1">attribute_1.</param>
        /// <param name="attribute2">attribute_2.</param>
        /// <param name="attribute3">attribute_3.</param>
        /// <param name="attribute4">attribute_4.</param>
        /// <param name="attribute5">attribute_5.</param>
        public CreateANewPhoneBookEntryRequest(
            string mobileNumber,
            string title,
            string firstName,
            string lastName,
            string attribute1,
            string attribute2,
            string attribute3,
            string attribute4,
            string attribute5)
        {
            this.MobileNumber = mobileNumber;
            this.Title = title;
            this.FirstName = firstName;
            this.LastName = lastName;
            this.Attribute1 = attribute1;
            this.Attribute2 = attribute2;
            this.Attribute3 = attribute3;
            this.Attribute4 = attribute4;
            this.Attribute5 = attribute5;
        }

        /// <summary>
        /// Gets or sets MobileNumber.
        /// </summary>
        [JsonProperty("mobile_number")]
        public string MobileNumber { get; set; }

        /// <summary>
        /// Gets or sets Title.
        /// </summary>
        [JsonProperty("title")]
        public string Title { get; set; }

        /// <summary>
        /// Gets or sets FirstName.
        /// </summary>
        [JsonProperty("first_name")]
        public string FirstName { get; set; }

        /// <summary>
        /// Gets or sets LastName.
        /// </summary>
        [JsonProperty("last_name")]
        public string LastName { get; set; }

        /// <summary>
        /// Custom Attribute 1 for phone book entry
        /// </summary>
        [JsonProperty("attribute_1")]
        public string Attribute1 { get; set; }

        /// <summary>
        /// Custom Attribute 2 for phone book entry
        /// </summary>
        [JsonProperty("attribute_2")]
        public string Attribute2 { get; set; }

        /// <summary>
        /// Custom Attribute 3 for phone book entry
        /// </summary>
        [JsonProperty("attribute_3")]
        public string Attribute3 { get; set; }

        /// <summary>
        /// Custom Attribute 4 for phone book entry
        /// </summary>
        [JsonProperty("attribute_4")]
        public string Attribute4 { get; set; }

        /// <summary>
        /// Custom Attribute 5 for phone book entry
        /// </summary>
        [JsonProperty("attribute_5")]
        public string Attribute5 { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"CreateANewPhoneBookEntryRequest : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is CreateANewPhoneBookEntryRequest other &&
                ((this.MobileNumber == null && other.MobileNumber == null) || (this.MobileNumber?.Equals(other.MobileNumber) == true)) &&
                ((this.Title == null && other.Title == null) || (this.Title?.Equals(other.Title) == true)) &&
                ((this.FirstName == null && other.FirstName == null) || (this.FirstName?.Equals(other.FirstName) == true)) &&
                ((this.LastName == null && other.LastName == null) || (this.LastName?.Equals(other.LastName) == true)) &&
                ((this.Attribute1 == null && other.Attribute1 == null) || (this.Attribute1?.Equals(other.Attribute1) == true)) &&
                ((this.Attribute2 == null && other.Attribute2 == null) || (this.Attribute2?.Equals(other.Attribute2) == true)) &&
                ((this.Attribute3 == null && other.Attribute3 == null) || (this.Attribute3?.Equals(other.Attribute3) == true)) &&
                ((this.Attribute4 == null && other.Attribute4 == null) || (this.Attribute4?.Equals(other.Attribute4) == true)) &&
                ((this.Attribute5 == null && other.Attribute5 == null) || (this.Attribute5?.Equals(other.Attribute5) == true));
        }
        

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.MobileNumber = {(this.MobileNumber == null ? "null" : this.MobileNumber == string.Empty ? "" : this.MobileNumber)}");
            toStringOutput.Add($"this.Title = {(this.Title == null ? "null" : this.Title == string.Empty ? "" : this.Title)}");
            toStringOutput.Add($"this.FirstName = {(this.FirstName == null ? "null" : this.FirstName == string.Empty ? "" : this.FirstName)}");
            toStringOutput.Add($"this.LastName = {(this.LastName == null ? "null" : this.LastName == string.Empty ? "" : this.LastName)}");
            toStringOutput.Add($"this.Attribute1 = {(this.Attribute1 == null ? "null" : this.Attribute1 == string.Empty ? "" : this.Attribute1)}");
            toStringOutput.Add($"this.Attribute2 = {(this.Attribute2 == null ? "null" : this.Attribute2 == string.Empty ? "" : this.Attribute2)}");
            toStringOutput.Add($"this.Attribute3 = {(this.Attribute3 == null ? "null" : this.Attribute3 == string.Empty ? "" : this.Attribute3)}");
            toStringOutput.Add($"this.Attribute4 = {(this.Attribute4 == null ? "null" : this.Attribute4 == string.Empty ? "" : this.Attribute4)}");
            toStringOutput.Add($"this.Attribute5 = {(this.Attribute5 == null ? "null" : this.Attribute5 == string.Empty ? "" : this.Attribute5)}");
        }
    }
}