// <copyright file="CreateCompetitionCategoryRequest.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace BuzzLynxOmnichannelCommuniationAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using BuzzLynxOmnichannelCommuniationAPI.Standard;
    using BuzzLynxOmnichannelCommuniationAPI.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// CreateCompetitionCategoryRequest.
    /// </summary>
    public class CreateCompetitionCategoryRequest
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="CreateCompetitionCategoryRequest"/> class.
        /// </summary>
        public CreateCompetitionCategoryRequest()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="CreateCompetitionCategoryRequest"/> class.
        /// </summary>
        /// <param name="name">name.</param>
        /// <param name="text">text.</param>
        /// <param name="createDate">create_date.</param>
        public CreateCompetitionCategoryRequest(
            string name,
            string text,
            string createDate)
        {
            this.Name = name;
            this.Text = text;
            this.CreateDate = createDate;
        }

        /// <summary>
        /// Gets or sets Name.
        /// </summary>
        [JsonProperty("name")]
        public string Name { get; set; }

        /// <summary>
        /// Gets or sets Text.
        /// </summary>
        [JsonProperty("text")]
        public string Text { get; set; }

        /// <summary>
        /// Gets or sets CreateDate.
        /// </summary>
        [JsonProperty("create_date")]
        public string CreateDate { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"CreateCompetitionCategoryRequest : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is CreateCompetitionCategoryRequest other &&
                ((this.Name == null && other.Name == null) || (this.Name?.Equals(other.Name) == true)) &&
                ((this.Text == null && other.Text == null) || (this.Text?.Equals(other.Text) == true)) &&
                ((this.CreateDate == null && other.CreateDate == null) || (this.CreateDate?.Equals(other.CreateDate) == true));
        }
        

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.Name = {(this.Name == null ? "null" : this.Name == string.Empty ? "" : this.Name)}");
            toStringOutput.Add($"this.Text = {(this.Text == null ? "null" : this.Text == string.Empty ? "" : this.Text)}");
            toStringOutput.Add($"this.CreateDate = {(this.CreateDate == null ? "null" : this.CreateDate == string.Empty ? "" : this.CreateDate)}");
        }
    }
}