// <copyright file="CreateANewPhoneBookRequest.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace BuzzLynxOmnichannelCommuniationAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using BuzzLynxOmnichannelCommuniationAPI.Standard;
    using BuzzLynxOmnichannelCommuniationAPI.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// CreateANewPhoneBookRequest.
    /// </summary>
    public class CreateANewPhoneBookRequest
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="CreateANewPhoneBookRequest"/> class.
        /// </summary>
        public CreateANewPhoneBookRequest()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="CreateANewPhoneBookRequest"/> class.
        /// </summary>
        /// <param name="name">name.</param>
        /// <param name="attribute1">attribute_1.</param>
        /// <param name="attribute2">attribute_2.</param>
        /// <param name="attribute3">attribute_3.</param>
        /// <param name="attribute4">attribute_4.</param>
        /// <param name="attribute5">attribute_5.</param>
        public CreateANewPhoneBookRequest(
            string name,
            string attribute1 = null,
            string attribute2 = null,
            string attribute3 = null,
            string attribute4 = null,
            string attribute5 = null)
        {
            this.Name = name;
            this.Attribute1 = attribute1;
            this.Attribute2 = attribute2;
            this.Attribute3 = attribute3;
            this.Attribute4 = attribute4;
            this.Attribute5 = attribute5;
        }

        /// <summary>
        /// The name of the phone book (segment)
        /// </summary>
        [JsonProperty("name")]
        public string Name { get; set; }

        /// <summary>
        /// This specification allows you to specify a name for a first extensible attribute for the segment
        /// </summary>
        [JsonProperty("attribute_1", NullValueHandling = NullValueHandling.Ignore)]
        public string Attribute1 { get; set; }

        /// <summary>
        /// This specification allows you to specify a name for a second extensible attribute for the segment
        /// </summary>
        [JsonProperty("attribute_2", NullValueHandling = NullValueHandling.Ignore)]
        public string Attribute2 { get; set; }

        /// <summary>
        /// This specification allows you to specify a name for a third extensible attribute for the segment
        /// </summary>
        [JsonProperty("attribute_3", NullValueHandling = NullValueHandling.Ignore)]
        public string Attribute3 { get; set; }

        /// <summary>
        /// This specification allows you to specify a name for a fourth extensible attribute for the segment
        /// </summary>
        [JsonProperty("attribute_4", NullValueHandling = NullValueHandling.Ignore)]
        public string Attribute4 { get; set; }

        /// <summary>
        /// This specification allows you to specify a name for a fifth extensible attribute for the segment
        /// </summary>
        [JsonProperty("attribute_5", NullValueHandling = NullValueHandling.Ignore)]
        public string Attribute5 { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"CreateANewPhoneBookRequest : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is CreateANewPhoneBookRequest other &&
                ((this.Name == null && other.Name == null) || (this.Name?.Equals(other.Name) == true)) &&
                ((this.Attribute1 == null && other.Attribute1 == null) || (this.Attribute1?.Equals(other.Attribute1) == true)) &&
                ((this.Attribute2 == null && other.Attribute2 == null) || (this.Attribute2?.Equals(other.Attribute2) == true)) &&
                ((this.Attribute3 == null && other.Attribute3 == null) || (this.Attribute3?.Equals(other.Attribute3) == true)) &&
                ((this.Attribute4 == null && other.Attribute4 == null) || (this.Attribute4?.Equals(other.Attribute4) == true)) &&
                ((this.Attribute5 == null && other.Attribute5 == null) || (this.Attribute5?.Equals(other.Attribute5) == true));
        }
        

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.Name = {(this.Name == null ? "null" : this.Name == string.Empty ? "" : this.Name)}");
            toStringOutput.Add($"this.Attribute1 = {(this.Attribute1 == null ? "null" : this.Attribute1 == string.Empty ? "" : this.Attribute1)}");
            toStringOutput.Add($"this.Attribute2 = {(this.Attribute2 == null ? "null" : this.Attribute2 == string.Empty ? "" : this.Attribute2)}");
            toStringOutput.Add($"this.Attribute3 = {(this.Attribute3 == null ? "null" : this.Attribute3 == string.Empty ? "" : this.Attribute3)}");
            toStringOutput.Add($"this.Attribute4 = {(this.Attribute4 == null ? "null" : this.Attribute4 == string.Empty ? "" : this.Attribute4)}");
            toStringOutput.Add($"this.Attribute5 = {(this.Attribute5 == null ? "null" : this.Attribute5 == string.Empty ? "" : this.Attribute5)}");
        }
    }
}