// <copyright file="CreateANewScheduleRequest.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace BuzzLynxOmnichannelCommuniationAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using BuzzLynxOmnichannelCommuniationAPI.Standard;
    using BuzzLynxOmnichannelCommuniationAPI.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// CreateANewScheduleRequest.
    /// </summary>
    public class CreateANewScheduleRequest
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="CreateANewScheduleRequest"/> class.
        /// </summary>
        public CreateANewScheduleRequest()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="CreateANewScheduleRequest"/> class.
        /// </summary>
        /// <param name="name">name.</param>
        /// <param name="type">type.</param>
        /// <param name="startDate">start_date.</param>
        /// <param name="endDate">end_date.</param>
        /// <param name="phoneBookId">phone_book_id.</param>
        /// <param name="templateId">template_id.</param>
        /// <param name="intervalType">interval_type.</param>
        /// <param name="interval">interval.</param>
        public CreateANewScheduleRequest(
            string name,
            string type,
            string startDate,
            string endDate,
            string phoneBookId,
            string templateId,
            string intervalType,
            int interval)
        {
            this.Name = name;
            this.Type = type;
            this.StartDate = startDate;
            this.EndDate = endDate;
            this.PhoneBookId = phoneBookId;
            this.TemplateId = templateId;
            this.IntervalType = intervalType;
            this.Interval = interval;
        }

        /// <summary>
        /// Gets or sets Name.
        /// </summary>
        [JsonProperty("name")]
        public string Name { get; set; }

        /// <summary>
        /// Gets or sets Type.
        /// </summary>
        [JsonProperty("type")]
        public string Type { get; set; }

        /// <summary>
        /// Gets or sets StartDate.
        /// </summary>
        [JsonProperty("start_date")]
        public string StartDate { get; set; }

        /// <summary>
        /// Gets or sets EndDate.
        /// </summary>
        [JsonProperty("end_date")]
        public string EndDate { get; set; }

        /// <summary>
        /// Gets or sets PhoneBookId.
        /// </summary>
        [JsonProperty("phone_book_id")]
        public string PhoneBookId { get; set; }

        /// <summary>
        /// Gets or sets TemplateId.
        /// </summary>
        [JsonProperty("template_id")]
        public string TemplateId { get; set; }

        /// <summary>
        /// Gets or sets IntervalType.
        /// </summary>
        [JsonProperty("interval_type")]
        public string IntervalType { get; set; }

        /// <summary>
        /// Gets or sets Interval.
        /// </summary>
        [JsonProperty("interval")]
        public int Interval { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"CreateANewScheduleRequest : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is CreateANewScheduleRequest other &&
                ((this.Name == null && other.Name == null) || (this.Name?.Equals(other.Name) == true)) &&
                ((this.Type == null && other.Type == null) || (this.Type?.Equals(other.Type) == true)) &&
                ((this.StartDate == null && other.StartDate == null) || (this.StartDate?.Equals(other.StartDate) == true)) &&
                ((this.EndDate == null && other.EndDate == null) || (this.EndDate?.Equals(other.EndDate) == true)) &&
                ((this.PhoneBookId == null && other.PhoneBookId == null) || (this.PhoneBookId?.Equals(other.PhoneBookId) == true)) &&
                ((this.TemplateId == null && other.TemplateId == null) || (this.TemplateId?.Equals(other.TemplateId) == true)) &&
                ((this.IntervalType == null && other.IntervalType == null) || (this.IntervalType?.Equals(other.IntervalType) == true)) &&
                this.Interval.Equals(other.Interval);
        }
        

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.Name = {(this.Name == null ? "null" : this.Name == string.Empty ? "" : this.Name)}");
            toStringOutput.Add($"this.Type = {(this.Type == null ? "null" : this.Type == string.Empty ? "" : this.Type)}");
            toStringOutput.Add($"this.StartDate = {(this.StartDate == null ? "null" : this.StartDate == string.Empty ? "" : this.StartDate)}");
            toStringOutput.Add($"this.EndDate = {(this.EndDate == null ? "null" : this.EndDate == string.Empty ? "" : this.EndDate)}");
            toStringOutput.Add($"this.PhoneBookId = {(this.PhoneBookId == null ? "null" : this.PhoneBookId == string.Empty ? "" : this.PhoneBookId)}");
            toStringOutput.Add($"this.TemplateId = {(this.TemplateId == null ? "null" : this.TemplateId == string.Empty ? "" : this.TemplateId)}");
            toStringOutput.Add($"this.IntervalType = {(this.IntervalType == null ? "null" : this.IntervalType == string.Empty ? "" : this.IntervalType)}");
            toStringOutput.Add($"this.Interval = {this.Interval}");
        }
    }
}