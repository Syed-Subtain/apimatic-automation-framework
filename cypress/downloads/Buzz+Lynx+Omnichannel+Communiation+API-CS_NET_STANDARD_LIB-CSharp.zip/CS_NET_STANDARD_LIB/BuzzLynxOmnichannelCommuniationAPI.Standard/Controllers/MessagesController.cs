// <copyright file="MessagesController.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace BuzzLynxOmnichannelCommuniationAPI.Standard.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Dynamic;
    using System.Globalization;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading;
    using System.Threading.Tasks;
    using BuzzLynxOmnichannelCommuniationAPI.Standard;
    using BuzzLynxOmnichannelCommuniationAPI.Standard.Authentication;
    using BuzzLynxOmnichannelCommuniationAPI.Standard.Http.Client;
    using BuzzLynxOmnichannelCommuniationAPI.Standard.Http.Request;
    using BuzzLynxOmnichannelCommuniationAPI.Standard.Http.Request.Configuration;
    using BuzzLynxOmnichannelCommuniationAPI.Standard.Http.Response;
    using BuzzLynxOmnichannelCommuniationAPI.Standard.Utilities;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// MessagesController.
    /// </summary>
    public class MessagesController : BaseController
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="MessagesController"/> class.
        /// </summary>
        /// <param name="config"> config instance. </param>
        /// <param name="httpClient"> httpClient. </param>
        /// <param name="authManagers"> authManager. </param>
        /// <param name="httpCallBack"> httpCallBack. </param>
        internal MessagesController(IConfiguration config, IHttpClient httpClient, IDictionary<string, IAuthManager> authManagers, HttpCallBack httpCallBack = null)
            : base(config, httpClient, authManagers, httpCallBack)
        {
        }

        /// <summary>
        /// `POST /iwin/api/v1/messages`.
        /// Send a message to one or more recipients.
        /// </summary>
        /// <param name="contentType">Required parameter: Example: .</param>
        /// <param name="accept">Required parameter: Example: .</param>
        /// <param name="body">Required parameter: Example: .</param>
        public void CreateSendMessages(
                string contentType,
                string accept,
                Models.SendMessagesRequest body)
        {
            Task t = this.CreateSendMessagesAsync(contentType, accept, body);
            ApiHelper.RunTaskSynchronously(t);
        }

        /// <summary>
        /// `POST /iwin/api/v1/messages`.
        /// Send a message to one or more recipients.
        /// </summary>
        /// <param name="contentType">Required parameter: Example: .</param>
        /// <param name="accept">Required parameter: Example: .</param>
        /// <param name="body">Required parameter: Example: .</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the void response from the API call.</returns>
        public async Task CreateSendMessagesAsync(
                string contentType,
                string accept,
                Models.SendMessagesRequest body,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/iwin/api/v1/messages");

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "Content-Type", contentType },
                { "Accept", accept },
            };

            // append body params.
            var bodyText = ApiHelper.JsonSerialize(body);

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().PostBody(queryBuilder.ToString(), headers, bodyText);

            if (this.HttpCallBack != null)
            {
                this.HttpCallBack.OnBeforeHttpRequestEventHandler(this.GetClientInstance(), httpRequest);
            }

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);
            if (this.HttpCallBack != null)
            {
                this.HttpCallBack.OnAfterHttpResponseEventHandler(this.GetClientInstance(), response);
            }

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);
        }

        /// <summary>
        /// `GET /iwin-competition/api/v1/competitions/messages`.
        /// Get all the messages received for all your short codes, with their categories. If you run a competition, the messages will contain the votes per category, per short code.
        /// The short code is your premium rate SMS number. The short code and competition ID is linked together. The total field contains the amount of messages received for this competition and category.
        /// </summary>
        /// <param name="accept">Required parameter: Example: .</param>
        public void GetMessages(
                string accept)
        {
            Task t = this.GetMessagesAsync(accept);
            ApiHelper.RunTaskSynchronously(t);
        }

        /// <summary>
        /// `GET /iwin-competition/api/v1/competitions/messages`.
        /// Get all the messages received for all your short codes, with their categories. If you run a competition, the messages will contain the votes per category, per short code.
        /// The short code is your premium rate SMS number. The short code and competition ID is linked together. The total field contains the amount of messages received for this competition and category.
        /// </summary>
        /// <param name="accept">Required parameter: Example: .</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the void response from the API call.</returns>
        public async Task GetMessagesAsync(
                string accept,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/iwin-competition/api/v1/messages");

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "Accept", accept },
            };

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().Get(queryBuilder.ToString(), headers);

            if (this.HttpCallBack != null)
            {
                this.HttpCallBack.OnBeforeHttpRequestEventHandler(this.GetClientInstance(), httpRequest);
            }

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);
            if (this.HttpCallBack != null)
            {
                this.HttpCallBack.OnAfterHttpResponseEventHandler(this.GetClientInstance(), response);
            }

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);
        }
    }
}