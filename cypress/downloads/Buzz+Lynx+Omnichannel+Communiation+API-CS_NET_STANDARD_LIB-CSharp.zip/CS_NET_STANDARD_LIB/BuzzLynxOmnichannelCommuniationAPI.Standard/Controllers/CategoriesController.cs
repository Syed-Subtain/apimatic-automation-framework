// <copyright file="CategoriesController.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace BuzzLynxOmnichannelCommuniationAPI.Standard.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Dynamic;
    using System.Globalization;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading;
    using System.Threading.Tasks;
    using BuzzLynxOmnichannelCommuniationAPI.Standard;
    using BuzzLynxOmnichannelCommuniationAPI.Standard.Authentication;
    using BuzzLynxOmnichannelCommuniationAPI.Standard.Http.Client;
    using BuzzLynxOmnichannelCommuniationAPI.Standard.Http.Request;
    using BuzzLynxOmnichannelCommuniationAPI.Standard.Http.Request.Configuration;
    using BuzzLynxOmnichannelCommuniationAPI.Standard.Http.Response;
    using BuzzLynxOmnichannelCommuniationAPI.Standard.Utilities;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// CategoriesController.
    /// </summary>
    public class CategoriesController : BaseController
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="CategoriesController"/> class.
        /// </summary>
        /// <param name="config"> config instance. </param>
        /// <param name="httpClient"> httpClient. </param>
        /// <param name="authManagers"> authManager. </param>
        /// <param name="httpCallBack"> httpCallBack. </param>
        internal CategoriesController(IConfiguration config, IHttpClient httpClient, IDictionary<string, IAuthManager> authManagers, HttpCallBack httpCallBack = null)
            : base(config, httpClient, authManagers, httpCallBack)
        {
        }

        /// <summary>
        /// `POST /iwin-competition/api/v1/competitions/{id}/categories`.
        /// Create a new compeition category. Note that you can add the same category to multiple competitions at the same time by comma separating the competition IDs, e.g. .
        /// `/iwin-competition/api/v1/competitions/2334,2322/categories`, where `2334` and `2322` are the respective competition IDs.
        /// This is useful for situations where you have more than one short code, e.g. a R2 short code and R30 short code for the same competition, but would like entrants to use either.
        /// Important: Categories refresh every evening at 00:00. If you add a category at 15:00, the category will only be recognised at 00:00.
        /// </summary>
        /// <param name="contentType">Required parameter: Example: .</param>
        /// <param name="accept">Required parameter: Example: .</param>
        /// <param name="body">Required parameter: Example: .</param>
        /// <param name="id">Required parameter: Example: .</param>
        public void CreateCompetitionCategory(
                string contentType,
                string accept,
                Models.CreateCompetitionCategoryRequest body,
                string id)
        {
            Task t = this.CreateCompetitionCategoryAsync(contentType, accept, body, id);
            ApiHelper.RunTaskSynchronously(t);
        }

        /// <summary>
        /// `POST /iwin-competition/api/v1/competitions/{id}/categories`.
        /// Create a new compeition category. Note that you can add the same category to multiple competitions at the same time by comma separating the competition IDs, e.g. .
        /// `/iwin-competition/api/v1/competitions/2334,2322/categories`, where `2334` and `2322` are the respective competition IDs.
        /// This is useful for situations where you have more than one short code, e.g. a R2 short code and R30 short code for the same competition, but would like entrants to use either.
        /// Important: Categories refresh every evening at 00:00. If you add a category at 15:00, the category will only be recognised at 00:00.
        /// </summary>
        /// <param name="contentType">Required parameter: Example: .</param>
        /// <param name="accept">Required parameter: Example: .</param>
        /// <param name="body">Required parameter: Example: .</param>
        /// <param name="id">Required parameter: Example: .</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the void response from the API call.</returns>
        public async Task CreateCompetitionCategoryAsync(
                string contentType,
                string accept,
                Models.CreateCompetitionCategoryRequest body,
                string id,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/iwin-competition/api/v1/competitions/{id}/categories");

            // process optional template parameters.
            ApiHelper.AppendUrlWithTemplateParameters(queryBuilder, new Dictionary<string, object>()
            {
                { "id", id },
            });

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "Content-Type", contentType },
                { "Accept", accept },
            };

            // append body params.
            var bodyText = ApiHelper.JsonSerialize(body);

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().PostBody(queryBuilder.ToString(), headers, bodyText);

            if (this.HttpCallBack != null)
            {
                this.HttpCallBack.OnBeforeHttpRequestEventHandler(this.GetClientInstance(), httpRequest);
            }

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);
            if (this.HttpCallBack != null)
            {
                this.HttpCallBack.OnAfterHttpResponseEventHandler(this.GetClientInstance(), response);
            }

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);
        }

        /// <summary>
        /// `DELETE /iwin-competition/api/v1/competitions/{id}/categories/{code}`.
        /// Delete a category. You can also delete the same category from different competitions in the same call by comma separating the competition IDs.
        /// Important: Categories refresh every evening at 00:00. If you delete a category at 15:00, the category will only be recognised as deleted at 00:00.
        /// </summary>
        /// <param name="accept">Required parameter: Example: .</param>
        /// <param name="id">Required parameter: Example: .</param>
        public void DeleteCompetitionCategory(
                string accept,
                string id)
        {
            Task t = this.DeleteCompetitionCategoryAsync(accept, id);
            ApiHelper.RunTaskSynchronously(t);
        }

        /// <summary>
        /// `DELETE /iwin-competition/api/v1/competitions/{id}/categories/{code}`.
        /// Delete a category. You can also delete the same category from different competitions in the same call by comma separating the competition IDs.
        /// Important: Categories refresh every evening at 00:00. If you delete a category at 15:00, the category will only be recognised as deleted at 00:00.
        /// </summary>
        /// <param name="accept">Required parameter: Example: .</param>
        /// <param name="id">Required parameter: Example: .</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the void response from the API call.</returns>
        public async Task DeleteCompetitionCategoryAsync(
                string accept,
                string id,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/iwin-competition/api/v1/competitions/{id}/categories");

            // process optional template parameters.
            ApiHelper.AppendUrlWithTemplateParameters(queryBuilder, new Dictionary<string, object>()
            {
                { "id", id },
            });

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "Accept", accept },
            };

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().Delete(queryBuilder.ToString(), headers, null);

            if (this.HttpCallBack != null)
            {
                this.HttpCallBack.OnBeforeHttpRequestEventHandler(this.GetClientInstance(), httpRequest);
            }

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);
            if (this.HttpCallBack != null)
            {
                this.HttpCallBack.OnAfterHttpResponseEventHandler(this.GetClientInstance(), response);
            }

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);
        }

        /// <summary>
        /// `GET /iwin-competition/api/v1/competitions/{id}/categories`.
        /// Get all the categories (e.g. entrants) for a competition.
        /// </summary>
        /// <param name="accept">Required parameter: Example: .</param>
        /// <param name="id">Required parameter: Example: .</param>
        public void GetCompetitionCategories(
                string accept,
                string id)
        {
            Task t = this.GetCompetitionCategoriesAsync(accept, id);
            ApiHelper.RunTaskSynchronously(t);
        }

        /// <summary>
        /// `GET /iwin-competition/api/v1/competitions/{id}/categories`.
        /// Get all the categories (e.g. entrants) for a competition.
        /// </summary>
        /// <param name="accept">Required parameter: Example: .</param>
        /// <param name="id">Required parameter: Example: .</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the void response from the API call.</returns>
        public async Task GetCompetitionCategoriesAsync(
                string accept,
                string id,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/iwin-competition/api/v1/competitions/{id}/categories");

            // process optional template parameters.
            ApiHelper.AppendUrlWithTemplateParameters(queryBuilder, new Dictionary<string, object>()
            {
                { "id", id },
            });

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "Accept", accept },
            };

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().Get(queryBuilder.ToString(), headers);

            if (this.HttpCallBack != null)
            {
                this.HttpCallBack.OnBeforeHttpRequestEventHandler(this.GetClientInstance(), httpRequest);
            }

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);
            if (this.HttpCallBack != null)
            {
                this.HttpCallBack.OnAfterHttpResponseEventHandler(this.GetClientInstance(), response);
            }

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);
        }
    }
}