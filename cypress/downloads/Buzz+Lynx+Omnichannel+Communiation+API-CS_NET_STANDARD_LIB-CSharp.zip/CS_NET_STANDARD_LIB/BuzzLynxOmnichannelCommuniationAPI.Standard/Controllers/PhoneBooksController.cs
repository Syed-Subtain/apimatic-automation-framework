// <copyright file="PhoneBooksController.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace BuzzLynxOmnichannelCommuniationAPI.Standard.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Dynamic;
    using System.Globalization;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading;
    using System.Threading.Tasks;
    using BuzzLynxOmnichannelCommuniationAPI.Standard;
    using BuzzLynxOmnichannelCommuniationAPI.Standard.Authentication;
    using BuzzLynxOmnichannelCommuniationAPI.Standard.Http.Client;
    using BuzzLynxOmnichannelCommuniationAPI.Standard.Http.Request;
    using BuzzLynxOmnichannelCommuniationAPI.Standard.Http.Request.Configuration;
    using BuzzLynxOmnichannelCommuniationAPI.Standard.Http.Response;
    using BuzzLynxOmnichannelCommuniationAPI.Standard.Utilities;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// PhoneBooksController.
    /// </summary>
    public class PhoneBooksController : BaseController
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="PhoneBooksController"/> class.
        /// </summary>
        /// <param name="config"> config instance. </param>
        /// <param name="httpClient"> httpClient. </param>
        /// <param name="authManagers"> authManager. </param>
        /// <param name="httpCallBack"> httpCallBack. </param>
        internal PhoneBooksController(IConfiguration config, IHttpClient httpClient, IDictionary<string, IAuthManager> authManagers, HttpCallBack httpCallBack = null)
            : base(config, httpClient, authManagers, httpCallBack)
        {
        }

        /// <summary>
        /// `PUT /iwin/api/v1/phonebooks/{id}`.
        /// Update a phone book. Values not present in the request will not be updated.
        /// </summary>
        /// <param name="contentType">Required parameter: Example: .</param>
        /// <param name="accept">Required parameter: Example: .</param>
        /// <param name="body">Required parameter: Example: .</param>
        public void UpdateAPhoneBook(
                string contentType,
                string accept,
                Models.UpdateAPhoneBookRequest body)
        {
            Task t = this.UpdateAPhoneBookAsync(contentType, accept, body);
            ApiHelper.RunTaskSynchronously(t);
        }

        /// <summary>
        /// `PUT /iwin/api/v1/phonebooks/{id}`.
        /// Update a phone book. Values not present in the request will not be updated.
        /// </summary>
        /// <param name="contentType">Required parameter: Example: .</param>
        /// <param name="accept">Required parameter: Example: .</param>
        /// <param name="body">Required parameter: Example: .</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the void response from the API call.</returns>
        public async Task UpdateAPhoneBookAsync(
                string contentType,
                string accept,
                Models.UpdateAPhoneBookRequest body,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/iwin/api/v1/phonebooks");

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "Content-Type", contentType },
                { "Accept", accept },
            };

            // append body params.
            var bodyText = ApiHelper.JsonSerialize(body);

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().PutBody(queryBuilder.ToString(), headers, bodyText);

            if (this.HttpCallBack != null)
            {
                this.HttpCallBack.OnBeforeHttpRequestEventHandler(this.GetClientInstance(), httpRequest);
            }

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);
            if (this.HttpCallBack != null)
            {
                this.HttpCallBack.OnAfterHttpResponseEventHandler(this.GetClientInstance(), response);
            }

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);
        }

        /// <summary>
        /// `POST /iwin/api/v1/phonebooks`.
        /// Add a new phone book. A phone book and its phone book entries are created separately. The phone book attribute fields are fields .
        /// that can be named to send personalized messages. For example, if attribute_1 has a value of "ID", a token .
        /// called &lt;ID&gt; can be used in messages, and the phone book entry (recipient) detail will be replaced in the message.
        /// </summary>
        /// <param name="contentType">Required parameter: Example: .</param>
        /// <param name="accept">Required parameter: Example: .</param>
        /// <param name="body">Required parameter: Example: .</param>
        public void CreateANewPhoneBook(
                string contentType,
                string accept,
                Models.CreateANewPhoneBookRequest body)
        {
            Task t = this.CreateANewPhoneBookAsync(contentType, accept, body);
            ApiHelper.RunTaskSynchronously(t);
        }

        /// <summary>
        /// `POST /iwin/api/v1/phonebooks`.
        /// Add a new phone book. A phone book and its phone book entries are created separately. The phone book attribute fields are fields .
        /// that can be named to send personalized messages. For example, if attribute_1 has a value of "ID", a token .
        /// called &lt;ID&gt; can be used in messages, and the phone book entry (recipient) detail will be replaced in the message.
        /// </summary>
        /// <param name="contentType">Required parameter: Example: .</param>
        /// <param name="accept">Required parameter: Example: .</param>
        /// <param name="body">Required parameter: Example: .</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the void response from the API call.</returns>
        public async Task CreateANewPhoneBookAsync(
                string contentType,
                string accept,
                Models.CreateANewPhoneBookRequest body,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/iwin/api/v1/phonebooks");

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "Content-Type", contentType },
                { "Accept", accept },
            };

            // append body params.
            var bodyText = ApiHelper.JsonSerialize(body);

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().PostBody(queryBuilder.ToString(), headers, bodyText);

            if (this.HttpCallBack != null)
            {
                this.HttpCallBack.OnBeforeHttpRequestEventHandler(this.GetClientInstance(), httpRequest);
            }

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);
            if (this.HttpCallBack != null)
            {
                this.HttpCallBack.OnAfterHttpResponseEventHandler(this.GetClientInstance(), response);
            }

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);
        }

        /// <summary>
        /// `GET /iwin/api/v1/phonebooks/{id}`.
        /// View a single phone book.
        /// </summary>
        /// <param name="accept">Required parameter: Example: .</param>
        /// <param name="id">Required parameter: Example: .</param>
        public void GetAPhoneBook(
                string accept,
                string id)
        {
            Task t = this.GetAPhoneBookAsync(accept, id);
            ApiHelper.RunTaskSynchronously(t);
        }

        /// <summary>
        /// `GET /iwin/api/v1/phonebooks/{id}`.
        /// View a single phone book.
        /// </summary>
        /// <param name="accept">Required parameter: Example: .</param>
        /// <param name="id">Required parameter: Example: .</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the void response from the API call.</returns>
        public async Task GetAPhoneBookAsync(
                string accept,
                string id,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/iwin/api/v1/phonebooks/{id}");

            // process optional template parameters.
            ApiHelper.AppendUrlWithTemplateParameters(queryBuilder, new Dictionary<string, object>()
            {
                { "id", id },
            });

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "Accept", accept },
            };

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().Get(queryBuilder.ToString(), headers);

            if (this.HttpCallBack != null)
            {
                this.HttpCallBack.OnBeforeHttpRequestEventHandler(this.GetClientInstance(), httpRequest);
            }

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);
            if (this.HttpCallBack != null)
            {
                this.HttpCallBack.OnAfterHttpResponseEventHandler(this.GetClientInstance(), response);
            }

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);
        }

        /// <summary>
        /// `GET /iwin/api/v1/phonebooks`.
        /// Get a list of all the phone books.
        /// </summary>
        /// <param name="accept">Required parameter: Example: .</param>
        public void GetAllPhoneBooks(
                string accept)
        {
            Task t = this.GetAllPhoneBooksAsync(accept);
            ApiHelper.RunTaskSynchronously(t);
        }

        /// <summary>
        /// `GET /iwin/api/v1/phonebooks`.
        /// Get a list of all the phone books.
        /// </summary>
        /// <param name="accept">Required parameter: Example: .</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the void response from the API call.</returns>
        public async Task GetAllPhoneBooksAsync(
                string accept,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/iwin/api/v1/phonebooks");

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "Accept", accept },
            };

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().Get(queryBuilder.ToString(), headers);

            if (this.HttpCallBack != null)
            {
                this.HttpCallBack.OnBeforeHttpRequestEventHandler(this.GetClientInstance(), httpRequest);
            }

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);
            if (this.HttpCallBack != null)
            {
                this.HttpCallBack.OnAfterHttpResponseEventHandler(this.GetClientInstance(), response);
            }

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);
        }

        /// <summary>
        /// `DELETE /iwin/api/v1/phonebooks/{id}`.
        /// Delete a phone book. Phone books already in use by a schedule cannot be deleted unless the schedule is also deleted.
        /// </summary>
        /// <param name="accept">Required parameter: Example: .</param>
        /// <param name="phoneBookId">Required parameter: Example: .</param>
        public void DeleteAPhoneBook(
                string accept,
                string phoneBookId)
        {
            Task t = this.DeleteAPhoneBookAsync(accept, phoneBookId);
            ApiHelper.RunTaskSynchronously(t);
        }

        /// <summary>
        /// `DELETE /iwin/api/v1/phonebooks/{id}`.
        /// Delete a phone book. Phone books already in use by a schedule cannot be deleted unless the schedule is also deleted.
        /// </summary>
        /// <param name="accept">Required parameter: Example: .</param>
        /// <param name="phoneBookId">Required parameter: Example: .</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the void response from the API call.</returns>
        public async Task DeleteAPhoneBookAsync(
                string accept,
                string phoneBookId,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/iwin/api/v1/phonebooks/{phoneBookId}");

            // process optional template parameters.
            ApiHelper.AppendUrlWithTemplateParameters(queryBuilder, new Dictionary<string, object>()
            {
                { "phoneBookId", phoneBookId },
            });

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "Accept", accept },
            };

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().Delete(queryBuilder.ToString(), headers, null);

            if (this.HttpCallBack != null)
            {
                this.HttpCallBack.OnBeforeHttpRequestEventHandler(this.GetClientInstance(), httpRequest);
            }

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);
            if (this.HttpCallBack != null)
            {
                this.HttpCallBack.OnAfterHttpResponseEventHandler(this.GetClientInstance(), response);
            }

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);
        }
    }
}