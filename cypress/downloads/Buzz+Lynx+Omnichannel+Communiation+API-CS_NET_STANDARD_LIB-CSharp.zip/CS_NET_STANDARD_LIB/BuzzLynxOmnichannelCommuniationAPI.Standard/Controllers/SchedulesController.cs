// <copyright file="SchedulesController.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace BuzzLynxOmnichannelCommuniationAPI.Standard.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Dynamic;
    using System.Globalization;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading;
    using System.Threading.Tasks;
    using BuzzLynxOmnichannelCommuniationAPI.Standard;
    using BuzzLynxOmnichannelCommuniationAPI.Standard.Authentication;
    using BuzzLynxOmnichannelCommuniationAPI.Standard.Http.Client;
    using BuzzLynxOmnichannelCommuniationAPI.Standard.Http.Request;
    using BuzzLynxOmnichannelCommuniationAPI.Standard.Http.Request.Configuration;
    using BuzzLynxOmnichannelCommuniationAPI.Standard.Http.Response;
    using BuzzLynxOmnichannelCommuniationAPI.Standard.Utilities;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// SchedulesController.
    /// </summary>
    public class SchedulesController : BaseController
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="SchedulesController"/> class.
        /// </summary>
        /// <param name="config"> config instance. </param>
        /// <param name="httpClient"> httpClient. </param>
        /// <param name="authManagers"> authManager. </param>
        /// <param name="httpCallBack"> httpCallBack. </param>
        internal SchedulesController(IConfiguration config, IHttpClient httpClient, IDictionary<string, IAuthManager> authManagers, HttpCallBack httpCallBack = null)
            : base(config, httpClient, authManagers, httpCallBack)
        {
        }

        /// <summary>
        /// `POST /iwin/api/v1/schedules`.
        /// Create a new schedule.
        /// </summary>
        /// <param name="contentType">Required parameter: Example: .</param>
        /// <param name="accept">Required parameter: Example: .</param>
        /// <param name="body">Required parameter: Example: .</param>
        public void CreateANewSchedule(
                string contentType,
                string accept,
                Models.CreateANewScheduleRequest body)
        {
            Task t = this.CreateANewScheduleAsync(contentType, accept, body);
            ApiHelper.RunTaskSynchronously(t);
        }

        /// <summary>
        /// `POST /iwin/api/v1/schedules`.
        /// Create a new schedule.
        /// </summary>
        /// <param name="contentType">Required parameter: Example: .</param>
        /// <param name="accept">Required parameter: Example: .</param>
        /// <param name="body">Required parameter: Example: .</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the void response from the API call.</returns>
        public async Task CreateANewScheduleAsync(
                string contentType,
                string accept,
                Models.CreateANewScheduleRequest body,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/iwin/api/v1/schedules");

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "Content-Type", contentType },
                { "Accept", accept },
            };

            // append body params.
            var bodyText = ApiHelper.JsonSerialize(body);

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().PostBody(queryBuilder.ToString(), headers, bodyText);

            if (this.HttpCallBack != null)
            {
                this.HttpCallBack.OnBeforeHttpRequestEventHandler(this.GetClientInstance(), httpRequest);
            }

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);
            if (this.HttpCallBack != null)
            {
                this.HttpCallBack.OnAfterHttpResponseEventHandler(this.GetClientInstance(), response);
            }

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);
        }

        /// <summary>
        /// `GET /iwin/api/v1/schedules/{id}`.
        /// Get a single schedule.
        /// </summary>
        /// <param name="accept">Required parameter: Example: .</param>
        /// <param name="scheduleId">Required parameter: Example: .</param>
        public void GetASchedule(
                string accept,
                string scheduleId)
        {
            Task t = this.GetAScheduleAsync(accept, scheduleId);
            ApiHelper.RunTaskSynchronously(t);
        }

        /// <summary>
        /// `GET /iwin/api/v1/schedules/{id}`.
        /// Get a single schedule.
        /// </summary>
        /// <param name="accept">Required parameter: Example: .</param>
        /// <param name="scheduleId">Required parameter: Example: .</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the void response from the API call.</returns>
        public async Task GetAScheduleAsync(
                string accept,
                string scheduleId,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/iwin/api/v1/schedules/{scheduleId}");

            // process optional template parameters.
            ApiHelper.AppendUrlWithTemplateParameters(queryBuilder, new Dictionary<string, object>()
            {
                { "scheduleId", scheduleId },
            });

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "Accept", accept },
            };

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().Get(queryBuilder.ToString(), headers);

            if (this.HttpCallBack != null)
            {
                this.HttpCallBack.OnBeforeHttpRequestEventHandler(this.GetClientInstance(), httpRequest);
            }

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);
            if (this.HttpCallBack != null)
            {
                this.HttpCallBack.OnAfterHttpResponseEventHandler(this.GetClientInstance(), response);
            }

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);
        }

        /// <summary>
        /// `PUT /iwin/api/v1/schedules/{id}/activate`.
        /// It is only necessary to activate a schedule if it was suspended explicitly. After activation, the schedule status will be "active".
        /// </summary>
        /// <param name="accept">Required parameter: Example: .</param>
        /// <param name="scheduleId">Required parameter: Example: .</param>
        public void UpdateActivateASchedule(
                string accept,
                string scheduleId)
        {
            Task t = this.UpdateActivateAScheduleAsync(accept, scheduleId);
            ApiHelper.RunTaskSynchronously(t);
        }

        /// <summary>
        /// `PUT /iwin/api/v1/schedules/{id}/activate`.
        /// It is only necessary to activate a schedule if it was suspended explicitly. After activation, the schedule status will be "active".
        /// </summary>
        /// <param name="accept">Required parameter: Example: .</param>
        /// <param name="scheduleId">Required parameter: Example: .</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the void response from the API call.</returns>
        public async Task UpdateActivateAScheduleAsync(
                string accept,
                string scheduleId,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/iwin/api/v1/schedules/{scheduleId}");

            // process optional template parameters.
            ApiHelper.AppendUrlWithTemplateParameters(queryBuilder, new Dictionary<string, object>()
            {
                { "scheduleId", scheduleId },
            });

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "Accept", accept },
            };

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().Put(queryBuilder.ToString(), headers, null);

            if (this.HttpCallBack != null)
            {
                this.HttpCallBack.OnBeforeHttpRequestEventHandler(this.GetClientInstance(), httpRequest);
            }

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);
            if (this.HttpCallBack != null)
            {
                this.HttpCallBack.OnAfterHttpResponseEventHandler(this.GetClientInstance(), response);
            }

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);
        }

        /// <summary>
        /// `DELETE /iwin/api/v1/schedules/{id}`.
        /// Only schedules in status "suspended" can be deleted. Call `PUT /iwin/api/v1/schedules/{id}/suspend` to suspend a schedule.
        /// </summary>
        /// <param name="accept">Required parameter: Example: .</param>
        /// <param name="scheduleId">Required parameter: Example: .</param>
        public void DeleteASchedule(
                string accept,
                string scheduleId)
        {
            Task t = this.DeleteAScheduleAsync(accept, scheduleId);
            ApiHelper.RunTaskSynchronously(t);
        }

        /// <summary>
        /// `DELETE /iwin/api/v1/schedules/{id}`.
        /// Only schedules in status "suspended" can be deleted. Call `PUT /iwin/api/v1/schedules/{id}/suspend` to suspend a schedule.
        /// </summary>
        /// <param name="accept">Required parameter: Example: .</param>
        /// <param name="scheduleId">Required parameter: Example: .</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the void response from the API call.</returns>
        public async Task DeleteAScheduleAsync(
                string accept,
                string scheduleId,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/iwin/api/v1/schedules/{scheduleId}");

            // process optional template parameters.
            ApiHelper.AppendUrlWithTemplateParameters(queryBuilder, new Dictionary<string, object>()
            {
                { "scheduleId", scheduleId },
            });

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "Accept", accept },
            };

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().Delete(queryBuilder.ToString(), headers, null);

            if (this.HttpCallBack != null)
            {
                this.HttpCallBack.OnBeforeHttpRequestEventHandler(this.GetClientInstance(), httpRequest);
            }

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);
            if (this.HttpCallBack != null)
            {
                this.HttpCallBack.OnAfterHttpResponseEventHandler(this.GetClientInstance(), response);
            }

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);
        }

        /// <summary>
        /// `PUT /iwin/api/v1/schedules/{id}/suspend`.
        /// Suspending a schedule will temporary stop a scedule from running, until it is activated again. After suspending a schedule, the schedule status will be "suspended".
        /// </summary>
        /// <param name="accept">Required parameter: Example: .</param>
        /// <param name="scheduleId">Required parameter: Example: .</param>
        public void UpdateSuspendASchedule(
                string accept,
                string scheduleId)
        {
            Task t = this.UpdateSuspendAScheduleAsync(accept, scheduleId);
            ApiHelper.RunTaskSynchronously(t);
        }

        /// <summary>
        /// `PUT /iwin/api/v1/schedules/{id}/suspend`.
        /// Suspending a schedule will temporary stop a scedule from running, until it is activated again. After suspending a schedule, the schedule status will be "suspended".
        /// </summary>
        /// <param name="accept">Required parameter: Example: .</param>
        /// <param name="scheduleId">Required parameter: Example: .</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the void response from the API call.</returns>
        public async Task UpdateSuspendAScheduleAsync(
                string accept,
                string scheduleId,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/iwin/api/v1/schedules/{scheduleId}");

            // process optional template parameters.
            ApiHelper.AppendUrlWithTemplateParameters(queryBuilder, new Dictionary<string, object>()
            {
                { "scheduleId", scheduleId },
            });

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "Accept", accept },
            };

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().Put(queryBuilder.ToString(), headers, null);

            if (this.HttpCallBack != null)
            {
                this.HttpCallBack.OnBeforeHttpRequestEventHandler(this.GetClientInstance(), httpRequest);
            }

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);
            if (this.HttpCallBack != null)
            {
                this.HttpCallBack.OnAfterHttpResponseEventHandler(this.GetClientInstance(), response);
            }

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);
        }

        /// <summary>
        /// `GET /iwin/api/v1/schedules`.
        /// Get all schedules, both active and suspended.
        /// </summary>
        /// <param name="accept">Required parameter: Example: .</param>
        public void GetAllSchedules(
                string accept)
        {
            Task t = this.GetAllSchedulesAsync(accept);
            ApiHelper.RunTaskSynchronously(t);
        }

        /// <summary>
        /// `GET /iwin/api/v1/schedules`.
        /// Get all schedules, both active and suspended.
        /// </summary>
        /// <param name="accept">Required parameter: Example: .</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the void response from the API call.</returns>
        public async Task GetAllSchedulesAsync(
                string accept,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/iwin/api/v1/schedules");

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "Accept", accept },
            };

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().Get(queryBuilder.ToString(), headers);

            if (this.HttpCallBack != null)
            {
                this.HttpCallBack.OnBeforeHttpRequestEventHandler(this.GetClientInstance(), httpRequest);
            }

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);
            if (this.HttpCallBack != null)
            {
                this.HttpCallBack.OnAfterHttpResponseEventHandler(this.GetClientInstance(), response);
            }

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);
        }
    }
}