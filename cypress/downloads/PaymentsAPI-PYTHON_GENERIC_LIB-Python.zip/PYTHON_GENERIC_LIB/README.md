# Getting Started with PaymentsAPI

## Getting Started

### Introduction

API for sending and managing payments

### Building

You must have Python `2 >=2.7.9` or Python `3 >=3.4` installed on your system to install and run this SDK. This SDK package depends on other Python packages like nose, jsonpickle etc. These dependencies are defined in the `requirements.txt` file that comes with the SDK.To resolve these dependencies, you can use the PIP Dependency manager. Install it by following steps at [https://pip.pypa.io/en/stable/installing/](https://pip.pypa.io/en/stable/installing/).

Python and PIP executables should be defined in your PATH. Open command prompt and type `pip --version`. This should display the version of the PIP Dependency Manager installed if your installation was successful and the paths are properly defined.

* Using command line, navigate to the directory containing the generated files (including `requirements.txt`) for the SDK.
* Run the command `pip install -r requirements.txt`. This should install all the required dependencies.

![Building SDK - Step 1](https://apidocs.io/illustration/python?workspaceFolder=Payments-Python&step=installDependencies)

### Installation

The following section explains how to use the payments library in a new project.

#### 1. Open Project in an IDE

Open up a Python IDE like PyCharm. The basic workflow presented here is also applicable if you prefer using a different editor or IDE.

![Open project in PyCharm - Step 1](https://apidocs.io/illustration/python?workspaceFolder=Payments-Python&step=pyCharm)

Click on `Open` in PyCharm to browse to your generated SDK directory and then click `OK`.

![Open project in PyCharm - Step 2](https://apidocs.io/illustration/python?workspaceFolder=Payments-Python&step=openProject0)

The project files will be displayed in the side bar as follows:

![Open project in PyCharm - Step 3](https://apidocs.io/illustration/python?workspaceFolder=Payments-Python&projectName=payments&step=openProject1)

#### 2. Add a new Test Project

Create a new directory by right clicking on the solution name as shown below:

![Add a new project in PyCharm - Step 1](https://apidocs.io/illustration/python?workspaceFolder=Payments-Python&projectName=payments&step=createDirectory)

Name the directory as "test".

![Add a new project in PyCharm - Step 2](https://apidocs.io/illustration/python?workspaceFolder=Payments-Python&step=nameDirectory)

Add a python file to this project.

![Add a new project in PyCharm - Step 3](https://apidocs.io/illustration/python?workspaceFolder=Payments-Python&projectName=payments&step=createFile)

Name it "testSDK".

![Add a new project in PyCharm - Step 4](https://apidocs.io/illustration/python?workspaceFolder=Payments-Python&projectName=payments&step=nameFile)

In your python file you will be required to import the generated python library using the following code lines

```python
from payments.payments_client import PaymentsClient
```

![Add a new project in PyCharm - Step 5](https://apidocs.io/illustration/python?workspaceFolder=Payments-Python&projectName=payments&libraryName=payments.payments_client&className=PaymentsClient&step=projectFiles)

After this you can write code to instantiate an API client object, get a controller object and  make API calls. Sample code is given in the subsequent sections.

#### 3. Run the Test Project

To run the file within your test project, right click on your Python file inside your Test project and click on `Run`

![Run Test Project - Step 1](https://apidocs.io/illustration/python?workspaceFolder=Payments-Python&projectName=payments&libraryName=payments.payments_client&className=PaymentsClient&step=runProject)

### Initialize the API Client

The following parameters are configurable for the API Client:

| Parameter | Type | Description |
|  --- | --- | --- |
| `bank_id` | `string` | Bank ID (ABA/Routing Number)<br>*Default*: `'123456789'` |
| `x_api_key` | `string` | API Key<br>*Default*: `'XXXCHANGETOAPIKEYXXX'` |
| `base_uri` | `string` | Domain Name<br>*Default*: `'api.example.local'` |
| `base_path` | `string` | URL Base Path<br>*Default*: `'v1'` |
| `environment` | Environment | The API environment. <br> **Default: `Environment.DEFAULT`** |
| `timeout` | `float` | The value to use for connection timeout. <br> **Default: 60** |
| `max_retries` | `int` | The number of times to retry an endpoint call if it fails. <br> **Default: 3** |
| `backoff_factor` | `float` | A backoff factor to apply between attempts after the second try. <br> **Default: 0** |

The API client can be initialized as follows:

```python
from payments.payments_client import PaymentsClient
from payments.configuration import Environment

client = PaymentsClient(
    bank_id='123456789',
    x_api_key='XXXCHANGETOAPIKEYXXX',
    environment = Environment.DEFAULT,
    base_uri = 'api.example.local',
    base_path = 'v1',)
```

### Authorization

This API uses `Custom Header Signature`.

### API Errors

Here is the list of errors that the API might throw.

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Error in Request | [`RequestErrorException`](#request-error) |
| 403 | Forbidden | [`AccessDeniedErrorException`](#access-denied-error) |
| 500 | System Error | [`SystemErrorException`](#system-error) |

## Client Class Documentation

### PaymentsAPI Client

The gateway for the SDK. This class acts as a factory for the Controllers and also holds the configuration of the SDK.

### Controllers

| Name | Description |
|  --- | --- |
| payments | Gets PaymentsController |

## API Reference

### List of APIs

* [Payments](#payments)

### Payments

#### Overview

Payments

##### Get instance

An instance of the `PaymentsController` class can be accessed from the API Client.

```
payments_controller = client.payments
```

#### Approve Payment

Approves a Payment to be sent

```python
def approve_payment(self,
                   payment_id)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `payment_id` | `int` | Template, Required | ID of payment to approve |

##### Response Type

`void`

##### Example Usage

```python
payment_id = 123456

result = payments_controller.approve_payment(payment_id)
```

#### Cancel Payment

Attempts to cancel a Payment. Does not automatically cancel the linked Quote.

```python
def cancel_payment(self,
                  payment_id)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `payment_id` | `int` | Template, Required | ID of payment to cancel |

##### Response Type

`void`

##### Example Usage

```python
payment_id = 123456

result = payments_controller.cancel_payment(payment_id)
```

#### Cancel Quote

Attempts to cancel a Quote

```python
def cancel_quote(self,
                quote_id)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `quote_id` | `int` | Template, Required | ID of quote to refresh |

##### Response Type

`void`

##### Example Usage

```python
quote_id = 123456

result = payments_controller.cancel_quote(quote_id)
```

#### Create Payment

Creates a new Payment

```python
def create_payment(self,
                  payment)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `payment` | [`PaymentData`](#payment-data) | Body, Required | Create Payment Body Data |

##### Response Type

[`Payment`](#payment)

##### Example Usage

```python
payment = PaymentData()
payment.quote_id = 123456
payment.originator = Originator()
payment.originator.name = 'Jake Johnson'
payment.originator.address = Address()
payment.originator.address.address_1 = '555 South North Lane'
payment.originator.address.address_2 = 'Floor 5'
payment.originator.address.city = 'Springfield'
payment.originator.address.state = 'VA'
payment.originator.address.postal_code = '47060'
payment.originator.address.country = 'US'
payment.originator_bank_account = BankAccount()
payment.originator_bank_account.account_number = 'DE89370400440532013000'
payment.originator_bank_account.bank = Bank()
payment.originator_bank_account.bank.routing_code = 'string'
payment.originator_bank_account.bank.swift_code = 'AGCAAM22'
payment.originator_bank_account.bank.name = 'Bank of America'
payment.originator_bank_account.bank.address = Address()
payment.originator_bank_account.bank.address.address_1 = '555 South North Lane'
payment.originator_bank_account.bank.address.address_2 = 'Floor 5'
payment.originator_bank_account.bank.address.city = 'Springfield'
payment.originator_bank_account.bank.address.state = 'VA'
payment.originator_bank_account.bank.address.postal_code = '47060'
payment.originator_bank_account.bank.address.country = 'US'
payment.beneficiary = Beneficiary()
payment.beneficiary.email = 'beneficiary@example.com'
payment.beneficiary.phone_number = '111-111-1111'
payment.beneficiary.name = 'Jake Johnson'
payment.beneficiary.address = Address()
payment.beneficiary.address.address_1 = '555 South North Lane'
payment.beneficiary.address.address_2 = 'Floor 5'
payment.beneficiary.address.city = 'Springfield'
payment.beneficiary.address.state = 'VA'
payment.beneficiary.address.postal_code = '47060'
payment.beneficiary.address.country = 'US'
payment.beneficiary_bank_account = BankAccount()
payment.beneficiary_bank_account.account_number = 'DE89370400440532013000'
payment.beneficiary_bank_account.bank = Bank()
payment.beneficiary_bank_account.bank.routing_code = 'string'
payment.beneficiary_bank_account.bank.swift_code = 'AGCAAM22'
payment.beneficiary_bank_account.bank.name = 'Bank of America'
payment.beneficiary_bank_account.bank.address = Address()
payment.beneficiary_bank_account.bank.address.address_1 = '555 South North Lane'
payment.beneficiary_bank_account.bank.address.address_2 = 'Floor 5'
payment.beneficiary_bank_account.bank.address.city = 'Springfield'
payment.beneficiary_bank_account.bank.address.state = 'VA'
payment.beneficiary_bank_account.bank.address.postal_code = '47060'
payment.beneficiary_bank_account.bank.address.country = 'US'
payment.intermediary_bank_account = BankAccount()
payment.intermediary_bank_account.account_number = 'DE89370400440532013000'
payment.intermediary_bank_account.bank = Bank()
payment.intermediary_bank_account.bank.routing_code = 'string'
payment.intermediary_bank_account.bank.swift_code = 'AGCAAM22'
payment.intermediary_bank_account.bank.name = 'Bank of America'
payment.intermediary_bank_account.bank.address = Address()
payment.intermediary_bank_account.bank.address.address_1 = '555 South North Lane'
payment.intermediary_bank_account.bank.address.address_2 = 'Floor 5'
payment.intermediary_bank_account.bank.address.city = 'Springfield'
payment.intermediary_bank_account.bank.address.state = 'VA'
payment.intermediary_bank_account.bank.address.postal_code = '47060'
payment.intermediary_bank_account.bank.address.country = 'US'
payment.details = PaymentDetails()
payment.details.payment_reference = '1234567890'
payment.details.purpose_of_payment = 'Purchase of Goods'
payment.details.memo = 'Invoice 12345678'

result = payments_controller.create_payment(payment)
```

##### Example Response *(as JSON)*

```json
{
  "id": 987654,
  "quoteId": 123456,
  "originator": {
    "name": "Jake Johnson",
    "address": {
      "address1": "555 South North Lane",
      "address2": "Floor 5",
      "city": "Springfield",
      "state": "VA",
      "postalCode": "47060",
      "country": "US"
    }
  },
  "originatorBankAccount": {
    "accountNumber": "DE89370400440532013000",
    "bank": {
      "name": "Bank of America",
      "address": {
        "address1": "555 South North Lane",
        "address2": "Floor 5",
        "city": "Springfield",
        "state": "VA",
        "postalCode": "47060",
        "country": "US"
      },
      "routingCode": "string",
      "swiftCode": "AGCAAM22"
    }
  },
  "beneficiary": {
    "name": "Jake Johnson",
    "address": {
      "address1": "555 South North Lane",
      "address2": "Floor 5",
      "city": "Springfield",
      "state": "VA",
      "postalCode": "47060",
      "country": "US"
    },
    "email": "beneficiary@example.com",
    "phoneNumber": "111-111-1111"
  },
  "beneficiaryBankAccount": {
    "accountNumber": "DE89370400440532013000",
    "bank": {
      "name": "Bank of America",
      "address": {
        "address1": "555 South North Lane",
        "address2": "Floor 5",
        "city": "Springfield",
        "state": "VA",
        "postalCode": "47060",
        "country": "US"
      },
      "routingCode": "string",
      "swiftCode": "AGCAAM22"
    }
  },
  "intermediaryBankAccount": {
    "accountNumber": "DE89370400440532013000",
    "bank": {
      "name": "Bank of America",
      "address": {
        "address1": "555 South North Lane",
        "address2": "Floor 5",
        "city": "Springfield",
        "state": "VA",
        "postalCode": "47060",
        "country": "US"
      },
      "routingCode": "string",
      "swiftCode": "AGCAAM22"
    }
  },
  "details": {
    "purposeOfPayment": "Purchase of Goods",
    "memo": "Invoice 12345678",
    "paymentReference": "1234567890"
  },
  "status": {
    "approved": false,
    "sent": false
  }
}
```

#### Create Quote

Create new Quote

```python
def create_quote(self,
                quote)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `quote` | [`QuoteData`](#quote-data) | Body, Required | Quote data |

##### Response Type

[`Quote`](#quote)

##### Example Usage

```python
quote = QuoteData()
quote.beneficiary_amount = 12345.67
quote.beneficiary_currency = 'EUR'

result = payments_controller.create_quote(quote)
```

##### Example Response *(as JSON)*

```json
{
  "id": 0,
  "beneficiaryAmount": 12345.67,
  "beneficiaryCurrency": "EUR",
  "originatorAmount": 76543.21,
  "originatorAmountIsFixed": true,
  "exchangeRate": 1.2345,
  "locked": false,
  "revision": 1
}
```

#### Get Quote Cancel Info

```python
def get_quote_cancel_info(self,
                         quote_id)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `quote_id` | `int` | Template, Required | Quote ID |

##### Response Type

[`QuoteCancelInfo`](#quote-cancel-info)

##### Example Usage

```python
quote_id = 123456

result = payments_controller.get_quote_cancel_info(quote_id)
```

#### Lock Quote

Lock the rate for a given Quote

```python
def lock_quote(self,
              quote_id)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `quote_id` | `int` | Template, Required | ID of quote to lock |

##### Response Type

[`Quote`](#quote)

##### Example Usage

```python
quote_id = 123456

result = payments_controller.lock_quote(quote_id)
```

##### Example Response *(as JSON)*

```json
{
  "id": 0,
  "beneficiaryAmount": 12345.67,
  "beneficiaryCurrency": "EUR",
  "originatorAmount": 76543.21,
  "originatorAmountIsFixed": true,
  "exchangeRate": 1.2345,
  "valueDate": "2021-03-01",
  "locked": false,
  "revision": 1
}
```

#### Refresh Quote

Refresh the rates for an existing Quote

```python
def refresh_quote(self,
                 quote_id)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `quote_id` | `int` | Template, Required | ID of quote to refresh |

##### Response Type

[`Quote`](#quote)

##### Example Usage

```python
quote_id = 123456

result = payments_controller.refresh_quote(quote_id)
```

##### Example Response *(as JSON)*

```json
{
  "id": 0,
  "beneficiaryAmount": 12345.67,
  "beneficiaryCurrency": "EUR",
  "originatorAmount": 76543.21,
  "originatorAmountIsFixed": true,
  "exchangeRate": 1.2345,
  "valueDate": "2021-03-01",
  "locked": false,
  "revision": 1
}
```

#### Update Payment

Update the data for a Payment before it is approved or sent

```python
def update_payment(self,
                  payment_id,
                  payment)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `payment_id` | `int` | Template, Required | ID of payment to update |
| `payment` | [`PaymentData`](#payment-data) | Body, Required | Update Payment Body Data |

##### Response Type

[`Payment`](#payment)

##### Example Usage

```python
payment_id = 123456
payment = PaymentData()
payment.quote_id = 123456
payment.originator = Originator()
payment.originator.name = 'Jake Johnson'
payment.originator.address = Address()
payment.originator.address.address_1 = '555 South North Lane'
payment.originator.address.address_2 = 'Floor 5'
payment.originator.address.city = 'Springfield'
payment.originator.address.state = 'VA'
payment.originator.address.postal_code = '47060'
payment.originator.address.country = 'US'
payment.originator_bank_account = BankAccount()
payment.originator_bank_account.account_number = 'DE89370400440532013000'
payment.originator_bank_account.bank = Bank()
payment.originator_bank_account.bank.routing_code = 'string'
payment.originator_bank_account.bank.swift_code = 'AGCAAM22'
payment.originator_bank_account.bank.name = 'Bank of America'
payment.originator_bank_account.bank.address = Address()
payment.originator_bank_account.bank.address.address_1 = '555 South North Lane'
payment.originator_bank_account.bank.address.address_2 = 'Floor 5'
payment.originator_bank_account.bank.address.city = 'Springfield'
payment.originator_bank_account.bank.address.state = 'VA'
payment.originator_bank_account.bank.address.postal_code = '47060'
payment.originator_bank_account.bank.address.country = 'US'
payment.beneficiary = Beneficiary()
payment.beneficiary.email = 'beneficiary@example.com'
payment.beneficiary.phone_number = '111-111-1111'
payment.beneficiary.name = 'Jake Johnson'
payment.beneficiary.address = Address()
payment.beneficiary.address.address_1 = '555 South North Lane'
payment.beneficiary.address.address_2 = 'Floor 5'
payment.beneficiary.address.city = 'Springfield'
payment.beneficiary.address.state = 'VA'
payment.beneficiary.address.postal_code = '47060'
payment.beneficiary.address.country = 'US'
payment.beneficiary_bank_account = BankAccount()
payment.beneficiary_bank_account.account_number = 'DE89370400440532013000'
payment.beneficiary_bank_account.bank = Bank()
payment.beneficiary_bank_account.bank.routing_code = 'string'
payment.beneficiary_bank_account.bank.swift_code = 'AGCAAM22'
payment.beneficiary_bank_account.bank.name = 'Bank of America'
payment.beneficiary_bank_account.bank.address = Address()
payment.beneficiary_bank_account.bank.address.address_1 = '555 South North Lane'
payment.beneficiary_bank_account.bank.address.address_2 = 'Floor 5'
payment.beneficiary_bank_account.bank.address.city = 'Springfield'
payment.beneficiary_bank_account.bank.address.state = 'VA'
payment.beneficiary_bank_account.bank.address.postal_code = '47060'
payment.beneficiary_bank_account.bank.address.country = 'US'
payment.intermediary_bank_account = BankAccount()
payment.intermediary_bank_account.account_number = 'DE89370400440532013000'
payment.intermediary_bank_account.bank = Bank()
payment.intermediary_bank_account.bank.routing_code = 'string'
payment.intermediary_bank_account.bank.swift_code = 'AGCAAM22'
payment.intermediary_bank_account.bank.name = 'Bank of America'
payment.intermediary_bank_account.bank.address = Address()
payment.intermediary_bank_account.bank.address.address_1 = '555 South North Lane'
payment.intermediary_bank_account.bank.address.address_2 = 'Floor 5'
payment.intermediary_bank_account.bank.address.city = 'Springfield'
payment.intermediary_bank_account.bank.address.state = 'VA'
payment.intermediary_bank_account.bank.address.postal_code = '47060'
payment.intermediary_bank_account.bank.address.country = 'US'
payment.details = PaymentDetails()
payment.details.payment_reference = '1234567890'
payment.details.purpose_of_payment = 'Purchase of Goods'
payment.details.memo = 'Invoice 12345678'

result = payments_controller.update_payment(payment_id, payment)
```

##### Example Response *(as JSON)*

```json
{
  "id": 987654,
  "quoteId": 123456,
  "originator": {
    "name": "Jake Johnson",
    "address": {
      "address1": "555 South North Lane",
      "address2": "Floor 5",
      "city": "Springfield",
      "state": "VA",
      "postalCode": "47060",
      "country": "US"
    }
  },
  "originatorBankAccount": {
    "accountNumber": "DE89370400440532013000",
    "bank": {
      "name": "Bank of America",
      "address": {
        "address1": "555 South North Lane",
        "address2": "Floor 5",
        "city": "Springfield",
        "state": "VA",
        "postalCode": "47060",
        "country": "US"
      },
      "routingCode": "string",
      "swiftCode": "AGCAAM22"
    }
  },
  "beneficiary": {
    "name": "Jake Johnson",
    "address": {
      "address1": "555 South North Lane",
      "address2": "Floor 5",
      "city": "Springfield",
      "state": "VA",
      "postalCode": "47060",
      "country": "US"
    },
    "email": "beneficiary@example.com",
    "phoneNumber": "111-111-1111"
  },
  "beneficiaryBankAccount": {
    "accountNumber": "DE89370400440532013000",
    "bank": {
      "name": "Bank of America",
      "address": {
        "address1": "555 South North Lane",
        "address2": "Floor 5",
        "city": "Springfield",
        "state": "VA",
        "postalCode": "47060",
        "country": "US"
      },
      "routingCode": "string",
      "swiftCode": "AGCAAM22"
    }
  },
  "intermediaryBankAccount": {
    "accountNumber": "DE89370400440532013000",
    "bank": {
      "name": "Bank of America",
      "address": {
        "address1": "555 South North Lane",
        "address2": "Floor 5",
        "city": "Springfield",
        "state": "VA",
        "postalCode": "47060",
        "country": "US"
      },
      "routingCode": "string",
      "swiftCode": "AGCAAM22"
    }
  },
  "details": {
    "purposeOfPayment": "Purchase of Goods",
    "memo": "Invoice 12345678",
    "paymentReference": "1234567890"
  },
  "status": {
    "approved": false,
    "sent": false
  }
}
```

#### Validate Iban

Validates an IBAN and returns the bank account information

```python
def validate_iban(self,
                 iban)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `iban` | `string` | Query, Required | Currency that is required by the client, sell foreign currency in exchange for local currency<br>**Constraints**: *Minimum Length*: `10`, *Maximum Length*: `35` |

##### Response Type

[`BankAccount`](#bank-account)

##### Example Usage

```python
iban = 'DE89370400440532013000'

result = payments_controller.validate_iban(iban)
```

##### Example Response *(as JSON)*

```json
{
  "accountNumber": "DE89370400440532013000",
  "bank": {
    "name": "Bank of America",
    "address": {
      "address1": "555 South North Lane",
      "address2": "Floor 5",
      "city": "Springfield",
      "state": "VA",
      "postalCode": "47060",
      "country": "US"
    },
    "routingCode": "string",
    "swiftCode": "AGCAAM22"
  }
}
```

## Model Reference

### Structures

* [Address](#address)
* [Bank](#bank)
* [Bank Account](#bank-account)
* [Beneficiary](#beneficiary)
* [Entity](#entity)
* [Originator](#originator)
* [Payment](#payment)
* [Payment Data](#payment-data)
* [Payment Details](#payment-details)
* [Payment Status](#payment-status)
* [Quote](#quote)
* [Quote Cancel Info](#quote-cancel-info)
* [Quote Data](#quote-data)
* [Quote Details](#quote-details)

#### Address

Address Information

##### Class Name

`Address`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `address_1` | `string` | Required | Address Line 1<br>**Constraints**: *Maximum Length*: `35` |
| `address_2` | `string` | Optional | Address Line 2<br>**Constraints**: *Maximum Length*: `35` |
| `address_3` | `string` | Optional | Address Line 3. Note - Only address3 or (city, state, postalCode) is allowed. Please contact support to configure your account for your desired address formatting.<br>**Constraints**: *Maximum Length*: `35` |
| `city` | `string` | Optional | City<br>**Constraints**: *Maximum Length*: `35` |
| `state` | `string` | Optional | State / Province<br>**Constraints**: *Maximum Length*: `60` |
| `postal_code` | `string` | Optional | Postal Code<br>**Constraints**: *Maximum Length*: `12` |
| `country` | `string` | Required | Country (ISO 3166-1 Alpha-2 Code)<br>**Constraints**: *Minimum Length*: `2`, *Maximum Length*: `2`, *Pattern*: `^[A-Z]{2}$` |

##### Example (as JSON)

```json
{
  "address1": "555 South North Lane",
  "address2": "Floor 5",
  "city": "Springfield",
  "state": "VA",
  "postalCode": "47060",
  "country": "US"
}
```

#### Bank

Bank Information Object

##### Class Name

`Bank`

##### Inherits From

[`Entity`](#entity)

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `routing_code` | `string` | Optional | Country Specific Routing Code (e.g. IFSC code for India). When using for USD wires, please only provide SWIFT code OR routing code (not both)<br>**Constraints**: *Maximum Length*: `35` |
| `swift_code` | `string` | Optional | SWIFT BIC. Required for international wires<br>**Constraints**: *Minimum Length*: `8`, *Maximum Length*: `11`, *Pattern*: `^[A-Za-z0-9]{4}[A-Za-z]{2}[A-Za-z0-9]{2}([A-Za-z0-9]{3})?$` |

##### Example (as JSON)

```json
{
  "name": "Bank of America",
  "address": {
    "address1": "555 South North Lane",
    "address2": "Floor 5",
    "city": "Springfield",
    "state": "VA",
    "postalCode": "47060",
    "country": "US"
  },
  "swiftCode": "AGCAAM22"
}
```

#### Bank Account

Bank Account Information Object.**NOTE** - originatorBankAccount bank data should not be provided when creating a new Payment. This information is retrieved from the database based on the provided bank ID.**NOTE** - bank object is required for all BankAccount objects except originatorBankAccount

##### Class Name

`BankAccount`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `account_number` | `string` | Optional | Bank Account Number / IBAN. Required for Beneficiary Bank. Optional for Intermediary Bank.<br>**Constraints**: *Maximum Length*: `35` |
| `bank` | [`Bank`](#bank) | Optional | Bank Information Object - Required for all banks except Originator |

##### Example (as JSON)

```json
{
  "accountNumber": "DE89370400440532013000",
  "bank": {
    "name": "Bank of America",
    "address": {
      "address1": "555 South North Lane",
      "address2": "Floor 5",
      "city": "Springfield",
      "state": "VA",
      "postalCode": "47060",
      "country": "US"
    },
    "routingCode": "123456789",
    "swiftCode": "AGCAAM22"
  }
}
```

#### Beneficiary

Beneficiary Information Object

##### Class Name

`Beneficiary`

##### Inherits From

[`Entity`](#entity)

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `email` | `string` | Optional | Beneficiary Email Address<br>**Constraints**: *Maximum Length*: `80` |
| `phone_number` | `string` | Optional | Beneficiary Phone Number<br>**Constraints**: *Maximum Length*: `35` |
| `mtype` | [`EntityTypeEnum`](#entity-type) | Optional | Type - individual or company |

##### Example (as JSON)

```json
{
  "name": "Jake Johnson",
  "address": {
    "address1": "555 South North Lane",
    "address2": "Floor 5",
    "city": "Springfield",
    "state": "VA",
    "postalCode": "47060",
    "country": "US"
  },
  "email": "beneficiary@example.com",
  "phoneNumber": "111-111-1111",
  "type": "individual"
}
```

#### Entity

Entity Information Object - base type for Beneficiary, Originator, and Bank

##### Class Name

`Entity`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `name` | `string` | Required | Entity Name<br>**Constraints**: *Maximum Length*: `80` |
| `address` | [`Address`](#address) | Required | Address Information |

##### Example (as JSON)

```json
{
  "name": "Jake Johnson",
  "address": {
    "address1": "555 South North Lane",
    "address2": "Floor 5",
    "city": "Springfield",
    "state": "VA",
    "postalCode": "47060",
    "country": "US"
  }
}
```

#### Originator

Originator Object

##### Class Name

`Originator`

##### Inherits From

[`Entity`](#entity)

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `mtype` | [`EntityTypeEnum`](#entity-type) | Optional | Type - individual or company |

##### Example (as JSON)

```json
{
  "name": "Jake Johnson",
  "address": {
    "address1": "555 South North Lane",
    "address2": "Floor 5",
    "city": "Springfield",
    "state": "VA",
    "postalCode": "47060",
    "country": "US"
  },
  "type": "individual"
}
```

#### Payment

Payment Model

##### Class Name

`Payment`

##### Inherits From

[`PaymentData`](#payment-data)

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Required, Constant | Payment ID |
| `status` | [`PaymentStatus`](#payment-status) | Required, Constant | Payment Status |

##### Example (as JSON)

```json
{
  "id": 987654,
  "quoteId": 123456,
  "originator": {
    "name": "Jake Johnson",
    "address": {
      "address1": "555 South North Lane",
      "address2": "Floor 5",
      "city": "Springfield",
      "state": "VA",
      "postalCode": "47060",
      "country": "US"
    }
  },
  "originatorBankAccount": {
    "accountNumber": "DE89370400440532013000",
    "bank": {
      "name": "Bank of America",
      "address": {
        "address1": "555 South North Lane",
        "address2": "Floor 5",
        "city": "Springfield",
        "state": "VA",
        "postalCode": "47060",
        "country": "US"
      },
      "routingCode": "string",
      "swiftCode": "AGCAAM22"
    }
  },
  "beneficiary": {
    "name": "Jake Johnson",
    "address": {
      "address1": "555 South North Lane",
      "address2": "Floor 5",
      "city": "Springfield",
      "state": "VA",
      "postalCode": "47060",
      "country": "US"
    },
    "email": "beneficiary@example.com",
    "phoneNumber": "111-111-1111"
  },
  "beneficiaryBankAccount": {
    "accountNumber": "DE89370400440532013000",
    "bank": {
      "name": "Bank of America",
      "address": {
        "address1": "555 South North Lane",
        "address2": "Floor 5",
        "city": "Springfield",
        "state": "VA",
        "postalCode": "47060",
        "country": "US"
      },
      "routingCode": "string",
      "swiftCode": "AGCAAM22"
    }
  },
  "intermediaryBankAccount": {
    "accountNumber": "DE89370400440532013000",
    "bank": {
      "name": "Bank of America",
      "address": {
        "address1": "555 South North Lane",
        "address2": "Floor 5",
        "city": "Springfield",
        "state": "VA",
        "postalCode": "47060",
        "country": "US"
      },
      "routingCode": "string",
      "swiftCode": "AGCAAM22"
    }
  },
  "details": {
    "purposeOfPayment": "Purchase of Goods",
    "memo": "Invoice 12345678",
    "paymentReference": "1234567890"
  },
  "status": {
    "approved": false,
    "sent": false
  }
}
```

#### Payment Data

Payment Data Information Object

##### Class Name

`PaymentData`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `quote_id` | `int` | Required | Quote ID |
| `originator` | [`Originator`](#originator) | Required | Originator Information Object |
| `originator_bank_account` | [`BankAccount`](#bank-account) | Optional | Originator Bank Account. Note - originatorBankAccount.accountNumber is the only required field. Name and address information is retrieved from the database |
| `beneficiary` | [`Beneficiary`](#beneficiary) | Required | Beneficiary Information Object |
| `beneficiary_bank_account` | [`BankAccount`](#bank-account) | Optional | Beneficiary Bank Account Object |
| `intermediary_bank_account` | [`BankAccount`](#bank-account) | Optional | Intermediary Bank Account Object |
| `details` | [`PaymentDetails`](#payment-details) | Required | Payment Information Data |

##### Example (as JSON)

```json
{
  "quoteId": 123456,
  "originator": {
    "name": "Jake Johnson",
    "address": {
      "address1": "555 South North Lane",
      "address2": "Floor 5",
      "city": "Springfield",
      "state": "VA",
      "postalCode": "47060",
      "country": "US"
    }
  },
  "originatorBankAccount": {
    "accountNumber": "DE89370400440532013000",
    "bank": {
      "name": "Bank of America",
      "address": {
        "address1": "555 South North Lane",
        "address2": "Floor 5",
        "city": "Springfield",
        "state": "VA",
        "postalCode": "47060",
        "country": "US"
      },
      "routingCode": "string",
      "swiftCode": "AGCAAM22"
    }
  },
  "beneficiary": {
    "name": "Jake Johnson",
    "address": {
      "address1": "555 South North Lane",
      "address2": "Floor 5",
      "city": "Springfield",
      "state": "VA",
      "postalCode": "47060",
      "country": "US"
    },
    "email": "beneficiary@example.com",
    "phoneNumber": "111-111-1111"
  },
  "beneficiaryBankAccount": {
    "accountNumber": "DE89370400440532013000",
    "bank": {
      "name": "Bank of America",
      "address": {
        "address1": "555 South North Lane",
        "address2": "Floor 5",
        "city": "Springfield",
        "state": "VA",
        "postalCode": "47060",
        "country": "US"
      },
      "routingCode": "string",
      "swiftCode": "AGCAAM22"
    }
  },
  "intermediaryBankAccount": {
    "accountNumber": "DE89370400440532013000",
    "bank": {
      "name": "Bank of America",
      "address": {
        "address1": "555 South North Lane",
        "address2": "Floor 5",
        "city": "Springfield",
        "state": "VA",
        "postalCode": "47060",
        "country": "US"
      },
      "routingCode": "string",
      "swiftCode": "AGCAAM22"
    }
  },
  "details": {
    "purposeOfPayment": "Purchase of Goods",
    "memo": "Invoice 12345678",
    "paymentReference": "1234567890"
  }
}
```

#### Payment Details

Payment Information Data

##### Class Name

`PaymentDetails`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `payment_reference` | `string` | Optional | Payment Reference Information<br>**Constraints**: *Maximum Length*: `140` |
| `purpose_of_payment` | `string` | Required | Purpose of payment<br>**Constraints**: *Maximum Length*: `140` |
| `reg_e` | `bool` | Optional | Set to true if this is a Reg E Payment |
| `memo` | `string` | Optional | Deprecated - DO NOT USE<br>**Constraints**: *Maximum Length*: `140` |

##### Example (as JSON)

```json
{
  "paymentReference": "1234567890",
  "purposeOfPayment": "Other"
}
```

#### Payment Status

Payment Information Data

##### Class Name

`PaymentStatus`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `approved` | `bool` | Required, Constant | Set to true once the payment has been approved |
| `sent` | `bool` | Required, Constant | Set to true once the payment has been sent |

##### Example (as JSON)

```json
{
  "approved": false,
  "sent": false
}
```

#### Quote

Quote Information Object

##### Class Name

`Quote`

##### Inherits From

[`QuoteData`](#quote-data)

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Required, Constant | Quote ID |
| `originator_amount_is_fixed` | `bool` | Required, Constant | If true, then the originator amount is fixed to the provided value. If false, then the beneficiary amount is fixed to the provided value. This field is automatically set based on whether the originator or beneficary amount was provided. |
| `exchange_rate` | `float` | Required, Constant | The exchange rate for the quote |
| `value_date` | `date` | Optional, Constant | Value Date - full-date notation as defined by RFC 3339, section 5.6 |
| `locked` | `bool` | Required, Constant | Set to true if the quote rate is locked |
| `revision` | `int` | Required, Constant | Quote revision number. This is automatically incremented each time the quote is refreshed or updated, and starts from 1 |

##### Example (as JSON)

```json
{
  "id": 0,
  "beneficiaryAmount": 12345.67,
  "beneficiaryCurrency": "EUR",
  "originatorAmount": 76543.21,
  "originatorAmountIsFixed": true,
  "exchangeRate": 1.2345,
  "valueDate": "2021-03-01",
  "locked": false,
  "revision": 1
}
```

#### Quote Cancel Info

Cancellation information for a quote prior to being cancelled

##### Class Name

`QuoteCancelInfo`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `quote_id` | `int` | Required, Constant | Quote ID |
| `chargeback_amount` | `float` | Optional, Constant | Chargeback amount if quote is cancelled. Currently always returns null |
| `message` | `string` | Required, Constant | Message regarding the cancellation information |
| `expiration` | `datetime` | Optional, Constant | Expiration time this cancellation information object is valid until. Currently always returns null |

##### Example (as JSON)

```json
{
  "quoteId": 123456,
  "message": "Unable to cancel a quote attached to a sent payment."
}
```

#### Quote Data

Quote Information Object for quote requests

##### Class Name

`QuoteData`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `beneficiary_amount` | `float` | Optional | Amount to send in beneficiary currency. Not required if originatorAmount is provided. |
| `beneficiary_currency` | `string` | Required | Beneficiary currency code in ISO 4217 format<br>**Constraints**: *Minimum Length*: `3`, *Maximum Length*: `3`, *Pattern*: `^[A-Z]{3}$` |
| `originator_amount` | `float` | Optional | Amount to send in originator currency. Not required if beneficiaryAmount is provided |
| `details` | [`QuoteDetails`](#quote-details) | Optional | Quote details |

##### Example (as JSON)

```json
{
  "beneficiaryAmount": 12345.67,
  "beneficiaryCurrency": "EUR"
}
```

#### Quote Details

Quote Details for quote requests

##### Class Name

`QuoteDetails`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `country` | `string` | Required | Country (ISO 3166-1 Alpha-2 Code) for beneficiary bank<br>**Constraints**: *Minimum Length*: `2`, *Maximum Length*: `2`, *Pattern*: `^[A-Z]{2}$` |
| `originator` | [`Originator`](#originator) | Required | Originator Information |
| `beneficiary` | [`Beneficiary`](#beneficiary) | Required | Beneficiary Information |

##### Example (as JSON)

```json
{
  "country": "US",
  "originator": {
    "name": "Jake Johnson",
    "address": {
      "address1": "555 South North Lane",
      "address2": "Floor 5",
      "city": "Springfield",
      "state": "VA",
      "postalCode": "47060",
      "country": "US"
    },
    "type": "individual"
  },
  "beneficiary": {
    "name": "Jake Johnson",
    "address": {
      "address1": "555 South North Lane",
      "address2": "Floor 5",
      "city": "Springfield",
      "state": "VA",
      "postalCode": "47060",
      "country": "US"
    },
    "email": "beneficiary@example.com",
    "phoneNumber": "111-111-1111",
    "type": "individual"
  }
}
```

### Enumerations

* [Entity Type](#entity-type)

#### Entity Type

Available Entity Types

##### Class Name

`EntityTypeEnum`

##### Fields

| Name | Description |
|  --- | --- |
| `INDIVIDUAL` | Individual |
| `COMPANY` | Company |

### Exceptions

* [Access Denied Error](#access-denied-error)
* [Request Error](#request-error)
* [System Error](#system-error)

#### Access Denied Error

Error for Access Denied Exceptions

##### Class Name

`AccessDeniedErrorException`

##### Fields

|  |
| 

##### Example (as JSON)

```json
{}
```

#### Request Error

Format for 400 Errors

##### Class Name

`RequestErrorException`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `message` | `string` | Optional | Message indicating the source of the error in the request |

##### Example (as JSON)

```json
{
  "message": "Error occured while performing field validation"
}
```

#### System Error

##### Class Name

`SystemErrorException`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `message` | `string` | Optional | Message indicating the source of the error in the request |

##### Example (as JSON)

```json
{
  "message": "Error occured while performing field validation"
}
```

## Utility Classes Documentation

### ApiHelper

A utility class for processing API Calls. Also contains classes for supporting standard datetime formats.

#### Methods

| Name | Description |
|  --- | --- |
| json_deserialize | Deserializes a JSON string to a Python dictionary. |

#### Classes

| Name | Description |
|  --- | --- |
| HttpDateTime | A wrapper for datetime to support HTTP date format. |
| UnixDateTime | A wrapper for datetime to support Unix date format. |
| RFC3339DateTime | A wrapper for datetime to support RFC3339 format. |

## Common Code Documentation

### HttpResponse

Http response received.

#### Parameters

| Name | Type | Description |
|  --- | --- | --- |
| status_code | int | The status code returned by the server. |
| reason_phrase | str | The reason phrase returned by the server. |
| headers | dict | Response headers. |
| text | str | Response body. |
| request | HttpRequest | The request that resulted in this response. |

### HttpRequest

Represents a single Http Request.

#### Parameters

| Name | Type | Tag | Description |
|  --- | --- | --- | --- |
| http_method | HttpMethodEnum |  | The HTTP method of the request. |
| query_url | str |  | The endpoint URL for the API request. |
| headers | dict | optional | Request headers. |
| query_parameters | dict | optional | Query parameters to add in the URL. |
| parameters | dict &#124; str | optional | Request body, either as a serialized string or else a list of parameters to form encode. |
| files | dict | optional | Files to be sent with the request. |

