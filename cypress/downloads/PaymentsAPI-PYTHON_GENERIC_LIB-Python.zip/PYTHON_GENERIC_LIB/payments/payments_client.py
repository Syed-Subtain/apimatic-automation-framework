# -*- coding: utf-8 -*-

"""
payments

This file was automatically generated for PeopleHedge by APIMATIC v2.0 (
 https://apimatic.io ).
"""

from payments.decorators import lazy_property
from payments.configuration import Configuration
from payments.configuration import Environment
from payments.controllers.payments_controller import PaymentsController


class PaymentsClient(object):

    @lazy_property
    def payments(self):
        return PaymentsController(self.config)

    def __init__(self, timeout=60, max_retries=3, backoff_factor=0,
                 environment=Environment.DEFAULT, base_uri='api.example.local',
                 base_path='v1', bank_id='123456789',
                 x_api_key='XXXCHANGETOAPIKEYXXX', config=None):
        if config is None:
            self.config = Configuration(timeout=timeout,
                                        max_retries=max_retries,
                                        backoff_factor=backoff_factor,
                                        environment=environment,
                                        base_uri=base_uri, base_path=base_path,
                                        bank_id=bank_id, x_api_key=x_api_key)
        else:
            self.config = config
