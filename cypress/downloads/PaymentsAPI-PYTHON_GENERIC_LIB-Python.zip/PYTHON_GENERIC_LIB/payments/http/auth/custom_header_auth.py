# -*- coding: utf-8 -*-

"""
payments

This file was automatically generated for PeopleHedge by APIMATIC v2.0 (
 https://apimatic.io ).
"""


class CustomHeaderAuth:

    @staticmethod
    def apply(config, http_request):
        """ Add custom authentication to the request.

        Args:
            config (Configuration): The Configuration object which holds the
                authentication information.
            http_request (HttpRequest): The HttpRequest object to which
                authentication will be added.

        """
        http_request.add_header("x-api-key", config.x_api_key)
