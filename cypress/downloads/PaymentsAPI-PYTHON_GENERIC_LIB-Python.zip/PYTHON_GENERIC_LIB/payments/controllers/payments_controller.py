# -*- coding: utf-8 -*-

"""
payments

This file was automatically generated for PeopleHedge by APIMATIC v2.0 (
 https://apimatic.io ).
"""

import logging
from payments.api_helper import APIHelper
from payments.configuration import Server
from payments.controllers.base_controller import BaseController
from payments.http.auth.custom_header_auth import CustomHeaderAuth
from payments.models.payment_data import Payment
from payments.models.quote_data import Quote
from payments.models.bank_account import BankAccount
from payments.models.quote_cancel_info import QuoteCancelInfo


class PaymentsController(BaseController):

    """A Controller to access Endpoints in the payments API."""

    def __init__(self, config, call_back=None):
        super(PaymentsController, self).__init__(config, call_back)
        self.logger = logging.getLogger(__name__)

    def create_payment(self,
                       payment):
        """Does a POST request to /payments.

        Creates a new Payment

        Args:
            payment (PaymentData): Create Payment Body Data

        Returns:
            Payment: Response from the API. successful operation

        Raises:
            APIException: When an error occurs while fetching the data from
                the remote API. This exception includes the HTTP Response
                code, an error message, and the HTTP body that was received in
                the request.

        """
        try:
            self.logger.info('create_payment called.')
    
            # Validate required parameters
            self.logger.info('Validating required parameters for create_payment.')
            self.validate_parameters(payment=payment)
    
            # Prepare query URL
            self.logger.info('Preparing query URL for create_payment.')
            _url_path = '/payments'
            _query_builder = self.config.get_base_uri(Server.DEFAULT)
            _query_builder += _url_path
            _query_url = APIHelper.clean_url(_query_builder)
    
            # Prepare headers
            self.logger.info('Preparing headers for create_payment.')
            _headers = {
                'accept': 'application/json',
                'content-type': 'application/json; charset=utf-8'
            }
    
            # Prepare and execute request
            self.logger.info('Preparing and executing request for create_payment.')
            _request = self.config.http_client.post(_query_url, headers=_headers, parameters=APIHelper.json_serialize(payment))
            CustomHeaderAuth.apply(self.config, _request)
            _response = self.execute_request(_request, name = 'create_payment')
            self.validate_response(_response)
    
            decoded = APIHelper.json_deserialize(_response.text, Payment.from_dictionary)
    
            return decoded

        except Exception as e:
            self.logger.error(e, exc_info = True)
            raise

    def cancel_payment(self,
                       payment_id):
        """Does a DELETE request to /payments/{paymentId}.

        Attempts to cancel a Payment. Does not automatically cancel the linked
        Quote.

        Args:
            payment_id (int): ID of payment to cancel

        Returns:
            void: Response from the API. successful operation

        Raises:
            APIException: When an error occurs while fetching the data from
                the remote API. This exception includes the HTTP Response
                code, an error message, and the HTTP body that was received in
                the request.

        """
        try:
            self.logger.info('cancel_payment called.')
    
            # Validate required parameters
            self.logger.info('Validating required parameters for cancel_payment.')
            self.validate_parameters(payment_id=payment_id)
    
            # Prepare query URL
            self.logger.info('Preparing query URL for cancel_payment.')
            _url_path = '/payments/{paymentId}'
            _url_path = APIHelper.append_url_with_template_parameters(_url_path, {
                'paymentId': {'value': payment_id, 'encode': True}
            })
            _query_builder = self.config.get_base_uri(Server.DEFAULT)
            _query_builder += _url_path
            _query_url = APIHelper.clean_url(_query_builder)
    
            # Prepare and execute request
            self.logger.info('Preparing and executing request for cancel_payment.')
            _request = self.config.http_client.delete(_query_url)
            CustomHeaderAuth.apply(self.config, _request)
            _response = self.execute_request(_request, name = 'cancel_payment')
            self.validate_response(_response)

        except Exception as e:
            self.logger.error(e, exc_info = True)
            raise

    def lock_quote(self,
                   quote_id):
        """Does a POST request to /quotes/{quoteId}/lock.

        Lock the rate for a given Quote

        Args:
            quote_id (int): ID of quote to lock

        Returns:
            Quote: Response from the API. successful operation

        Raises:
            APIException: When an error occurs while fetching the data from
                the remote API. This exception includes the HTTP Response
                code, an error message, and the HTTP body that was received in
                the request.

        """
        try:
            self.logger.info('lock_quote called.')
    
            # Validate required parameters
            self.logger.info('Validating required parameters for lock_quote.')
            self.validate_parameters(quote_id=quote_id)
    
            # Prepare query URL
            self.logger.info('Preparing query URL for lock_quote.')
            _url_path = '/quotes/{quoteId}/lock'
            _url_path = APIHelper.append_url_with_template_parameters(_url_path, {
                'quoteId': {'value': quote_id, 'encode': True}
            })
            _query_builder = self.config.get_base_uri(Server.DEFAULT)
            _query_builder += _url_path
            _query_url = APIHelper.clean_url(_query_builder)
    
            # Prepare headers
            self.logger.info('Preparing headers for lock_quote.')
            _headers = {
                'accept': 'application/json'
            }
    
            # Prepare and execute request
            self.logger.info('Preparing and executing request for lock_quote.')
            _request = self.config.http_client.post(_query_url, headers=_headers)
            CustomHeaderAuth.apply(self.config, _request)
            _response = self.execute_request(_request, name = 'lock_quote')
            self.validate_response(_response)
    
            decoded = APIHelper.json_deserialize(_response.text, Quote.from_dictionary)
    
            return decoded

        except Exception as e:
            self.logger.error(e, exc_info = True)
            raise

    def refresh_quote(self,
                      quote_id):
        """Does a POST request to /quotes/{quoteId}/refresh.

        Refresh the rates for an existing Quote

        Args:
            quote_id (int): ID of quote to refresh

        Returns:
            Quote: Response from the API. successful operation

        Raises:
            APIException: When an error occurs while fetching the data from
                the remote API. This exception includes the HTTP Response
                code, an error message, and the HTTP body that was received in
                the request.

        """
        try:
            self.logger.info('refresh_quote called.')
    
            # Validate required parameters
            self.logger.info('Validating required parameters for refresh_quote.')
            self.validate_parameters(quote_id=quote_id)
    
            # Prepare query URL
            self.logger.info('Preparing query URL for refresh_quote.')
            _url_path = '/quotes/{quoteId}/refresh'
            _url_path = APIHelper.append_url_with_template_parameters(_url_path, {
                'quoteId': {'value': quote_id, 'encode': True}
            })
            _query_builder = self.config.get_base_uri(Server.DEFAULT)
            _query_builder += _url_path
            _query_url = APIHelper.clean_url(_query_builder)
    
            # Prepare headers
            self.logger.info('Preparing headers for refresh_quote.')
            _headers = {
                'accept': 'application/json'
            }
    
            # Prepare and execute request
            self.logger.info('Preparing and executing request for refresh_quote.')
            _request = self.config.http_client.post(_query_url, headers=_headers)
            CustomHeaderAuth.apply(self.config, _request)
            _response = self.execute_request(_request, name = 'refresh_quote')
            self.validate_response(_response)
    
            decoded = APIHelper.json_deserialize(_response.text, Quote.from_dictionary)
    
            return decoded

        except Exception as e:
            self.logger.error(e, exc_info = True)
            raise

    def cancel_quote(self,
                     quote_id):
        """Does a DELETE request to /quotes/{quoteId}.

        Attempts to cancel a Quote

        Args:
            quote_id (int): ID of quote to refresh

        Returns:
            void: Response from the API. successful operation

        Raises:
            APIException: When an error occurs while fetching the data from
                the remote API. This exception includes the HTTP Response
                code, an error message, and the HTTP body that was received in
                the request.

        """
        try:
            self.logger.info('cancel_quote called.')
    
            # Validate required parameters
            self.logger.info('Validating required parameters for cancel_quote.')
            self.validate_parameters(quote_id=quote_id)
    
            # Prepare query URL
            self.logger.info('Preparing query URL for cancel_quote.')
            _url_path = '/quotes/{quoteId}'
            _url_path = APIHelper.append_url_with_template_parameters(_url_path, {
                'quoteId': {'value': quote_id, 'encode': True}
            })
            _query_builder = self.config.get_base_uri(Server.DEFAULT)
            _query_builder += _url_path
            _query_url = APIHelper.clean_url(_query_builder)
    
            # Prepare and execute request
            self.logger.info('Preparing and executing request for cancel_quote.')
            _request = self.config.http_client.delete(_query_url)
            CustomHeaderAuth.apply(self.config, _request)
            _response = self.execute_request(_request, name = 'cancel_quote')
            self.validate_response(_response)

        except Exception as e:
            self.logger.error(e, exc_info = True)
            raise

    def approve_payment(self,
                        payment_id):
        """Does a POST request to /payments/{paymentId}/approve.

        Approves a Payment to be sent

        Args:
            payment_id (int): ID of payment to approve

        Returns:
            void: Response from the API. successful operation

        Raises:
            APIException: When an error occurs while fetching the data from
                the remote API. This exception includes the HTTP Response
                code, an error message, and the HTTP body that was received in
                the request.

        """
        try:
            self.logger.info('approve_payment called.')
    
            # Validate required parameters
            self.logger.info('Validating required parameters for approve_payment.')
            self.validate_parameters(payment_id=payment_id)
    
            # Prepare query URL
            self.logger.info('Preparing query URL for approve_payment.')
            _url_path = '/payments/{paymentId}/approve'
            _url_path = APIHelper.append_url_with_template_parameters(_url_path, {
                'paymentId': {'value': payment_id, 'encode': True}
            })
            _query_builder = self.config.get_base_uri(Server.DEFAULT)
            _query_builder += _url_path
            _query_url = APIHelper.clean_url(_query_builder)
    
            # Prepare and execute request
            self.logger.info('Preparing and executing request for approve_payment.')
            _request = self.config.http_client.post(_query_url)
            CustomHeaderAuth.apply(self.config, _request)
            _response = self.execute_request(_request, name = 'approve_payment')
            self.validate_response(_response)

        except Exception as e:
            self.logger.error(e, exc_info = True)
            raise

    def create_quote(self,
                     quote):
        """Does a POST request to /quotes.

        Create new Quote

        Args:
            quote (QuoteData): Quote data

        Returns:
            Quote: Response from the API. successful operation

        Raises:
            APIException: When an error occurs while fetching the data from
                the remote API. This exception includes the HTTP Response
                code, an error message, and the HTTP body that was received in
                the request.

        """
        try:
            self.logger.info('create_quote called.')
    
            # Validate required parameters
            self.logger.info('Validating required parameters for create_quote.')
            self.validate_parameters(quote=quote)
    
            # Prepare query URL
            self.logger.info('Preparing query URL for create_quote.')
            _url_path = '/quotes'
            _query_builder = self.config.get_base_uri(Server.DEFAULT)
            _query_builder += _url_path
            _query_url = APIHelper.clean_url(_query_builder)
    
            # Prepare headers
            self.logger.info('Preparing headers for create_quote.')
            _headers = {
                'accept': 'application/json',
                'content-type': 'application/json; charset=utf-8'
            }
    
            # Prepare and execute request
            self.logger.info('Preparing and executing request for create_quote.')
            _request = self.config.http_client.post(_query_url, headers=_headers, parameters=APIHelper.json_serialize(quote))
            CustomHeaderAuth.apply(self.config, _request)
            _response = self.execute_request(_request, name = 'create_quote')
            self.validate_response(_response)
    
            decoded = APIHelper.json_deserialize(_response.text, Quote.from_dictionary)
    
            return decoded

        except Exception as e:
            self.logger.error(e, exc_info = True)
            raise

    def validate_iban(self,
                      iban):
        """Does a GET request to /payments/get-bank-account-from-iban.

        Validates an IBAN and returns the bank account information

        Args:
            iban (string): Currency that is required by the client, sell
                foreign currency in exchange for local currency

        Returns:
            BankAccount: Response from the API. successful operation

        Raises:
            APIException: When an error occurs while fetching the data from
                the remote API. This exception includes the HTTP Response
                code, an error message, and the HTTP body that was received in
                the request.

        """
        try:
            self.logger.info('validate_iban called.')
    
            # Validate required parameters
            self.logger.info('Validating required parameters for validate_iban.')
            self.validate_parameters(iban=iban)
    
            # Prepare query URL
            self.logger.info('Preparing query URL for validate_iban.')
            _url_path = '/payments/get-bank-account-from-iban'
            _query_builder = self.config.get_base_uri(Server.DEFAULT)
            _query_builder += _url_path
            _query_parameters = {
                'iban': iban
            }
            _query_builder = APIHelper.append_url_with_query_parameters(
                _query_builder,
                _query_parameters
            )
            _query_url = APIHelper.clean_url(_query_builder)
    
            # Prepare headers
            self.logger.info('Preparing headers for validate_iban.')
            _headers = {
                'accept': 'application/json'
            }
    
            # Prepare and execute request
            self.logger.info('Preparing and executing request for validate_iban.')
            _request = self.config.http_client.get(_query_url, headers=_headers)
            CustomHeaderAuth.apply(self.config, _request)
            _response = self.execute_request(_request, name = 'validate_iban')
            self.validate_response(_response)
    
            decoded = APIHelper.json_deserialize(_response.text, BankAccount.from_dictionary)
    
            return decoded

        except Exception as e:
            self.logger.error(e, exc_info = True)
            raise

    def update_payment(self,
                       payment_id,
                       payment):
        """Does a PUT request to /payments/{paymentId}.

        Update the data for a Payment before it is approved or sent

        Args:
            payment_id (int): ID of payment to update
            payment (PaymentData): Update Payment Body Data

        Returns:
            Payment: Response from the API. successful operation

        Raises:
            APIException: When an error occurs while fetching the data from
                the remote API. This exception includes the HTTP Response
                code, an error message, and the HTTP body that was received in
                the request.

        """
        try:
            self.logger.info('update_payment called.')
    
            # Validate required parameters
            self.logger.info('Validating required parameters for update_payment.')
            self.validate_parameters(payment_id=payment_id,
                                     payment=payment)
    
            # Prepare query URL
            self.logger.info('Preparing query URL for update_payment.')
            _url_path = '/payments/{paymentId}'
            _url_path = APIHelper.append_url_with_template_parameters(_url_path, {
                'paymentId': {'value': payment_id, 'encode': True}
            })
            _query_builder = self.config.get_base_uri(Server.DEFAULT)
            _query_builder += _url_path
            _query_url = APIHelper.clean_url(_query_builder)
    
            # Prepare headers
            self.logger.info('Preparing headers for update_payment.')
            _headers = {
                'accept': 'application/json',
                'content-type': 'application/json; charset=utf-8'
            }
    
            # Prepare and execute request
            self.logger.info('Preparing and executing request for update_payment.')
            _request = self.config.http_client.put(_query_url, headers=_headers, parameters=APIHelper.json_serialize(payment))
            CustomHeaderAuth.apply(self.config, _request)
            _response = self.execute_request(_request, name = 'update_payment')
            self.validate_response(_response)
    
            decoded = APIHelper.json_deserialize(_response.text, Payment.from_dictionary)
    
            return decoded

        except Exception as e:
            self.logger.error(e, exc_info = True)
            raise

    def get_quote_cancel_info(self,
                              quote_id):
        """Does a GET request to /quotes/{quoteId}/cancelInfo.

        TODO: type endpoint description here.

        Args:
            quote_id (int): Quote ID

        Returns:
            QuoteCancelInfo: Response from the API.

        Raises:
            APIException: When an error occurs while fetching the data from
                the remote API. This exception includes the HTTP Response
                code, an error message, and the HTTP body that was received in
                the request.

        """
        try:
            self.logger.info('get_quote_cancel_info called.')
    
            # Validate required parameters
            self.logger.info('Validating required parameters for get_quote_cancel_info.')
            self.validate_parameters(quote_id=quote_id)
    
            # Prepare query URL
            self.logger.info('Preparing query URL for get_quote_cancel_info.')
            _url_path = '/quotes/{quoteId}/cancelInfo'
            _url_path = APIHelper.append_url_with_template_parameters(_url_path, {
                'quoteId': {'value': quote_id, 'encode': True}
            })
            _query_builder = self.config.get_base_uri()
            _query_builder += _url_path
            _query_url = APIHelper.clean_url(_query_builder)
    
            # Prepare headers
            self.logger.info('Preparing headers for get_quote_cancel_info.')
            _headers = {
                'accept': 'application/json'
            }
    
            # Prepare and execute request
            self.logger.info('Preparing and executing request for get_quote_cancel_info.')
            _request = self.config.http_client.get(_query_url, headers=_headers)
            CustomHeaderAuth.apply(self.config, _request)
            _response = self.execute_request(_request, name = 'get_quote_cancel_info')
            self.validate_response(_response)
    
            decoded = APIHelper.json_deserialize(_response.text, QuoteCancelInfo.from_dictionary)
    
            return decoded

        except Exception as e:
            self.logger.error(e, exc_info = True)
            raise
