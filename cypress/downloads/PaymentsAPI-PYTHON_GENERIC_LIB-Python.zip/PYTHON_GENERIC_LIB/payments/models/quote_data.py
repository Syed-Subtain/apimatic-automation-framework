# -*- coding: utf-8 -*-

"""
payments

This file was automatically generated for PeopleHedge by APIMATIC v2.0 (
 https://apimatic.io ).
"""
import dateutil.parser

from payments.models.quote_details import QuoteDetails


class QuoteData(object):

    """Implementation of the 'QuoteData' model.

    Quote Information Object for quote requests

    Attributes:
        beneficiary_amount (float): Amount to send in beneficiary currency.
            Not required if originatorAmount is provided.
        beneficiary_currency (string): Beneficiary currency code in ISO 4217
            format
        originator_amount (float): Amount to send in originator currency. Not
            required if beneficiaryAmount is provided
        details (QuoteDetails): Quote details

    """

    # Create a mapping from Model property names to API property names
    _names = {
        "beneficiary_currency": 'beneficiaryCurrency',
        "beneficiary_amount": 'beneficiaryAmount',
        "originator_amount": 'originatorAmount',
        "details": 'details'
    }

    def __init__(self,
                 beneficiary_currency=None,
                 beneficiary_amount=None,
                 originator_amount=None,
                 details=None):
        """Constructor for the QuoteData class"""

        # Initialize members of the class
        self.beneficiary_amount = beneficiary_amount
        self.beneficiary_currency = beneficiary_currency
        self.originator_amount = originator_amount
        self.details = details

    @classmethod
    def from_dictionary(cls,
                        dictionary):
        """Creates an instance of this model from a dictionary

        Args:
            dictionary (dictionary): A dictionary representation of the object
            as obtained from the deserialization of the server's response. The
            keys MUST match property names in the API description.

        Returns:
            object: An instance of this structure class.

        """
        if dictionary is None:
            return None

        # Extract variables from the dictionary
        beneficiary_currency = dictionary.get('beneficiaryCurrency')
        beneficiary_amount = dictionary.get('beneficiaryAmount')
        originator_amount = dictionary.get('originatorAmount')
        details = QuoteDetails.from_dictionary(dictionary.get('details')) if dictionary.get('details') else None

        # Return an object of this model
        return cls(beneficiary_currency,
                   beneficiary_amount,
                   originator_amount,
                   details)


class Quote(QuoteData):

    """Implementation of the 'Quote' model.

    Quote Information Object
    NOTE: This class inherits from 'QuoteData'.

    Attributes:
        id (int): Quote ID
        originator_amount_is_fixed (bool): If true, then the originator amount
            is fixed to the provided value. If false, then the beneficiary
            amount is fixed to the provided value. This field is automatically
            set based on whether the originator or beneficary amount was
            provided.
        exchange_rate (float): The exchange rate for the quote
        value_date (date): Value Date - full-date notation as defined by RFC
            3339, section 5.6
        locked (bool): Set to true if the quote rate is locked
        revision (int): Quote revision number. This is automatically
            incremented each time the quote is refreshed or updated, and
            starts from 1

    """

    # Create a mapping from Model property names to API property names
    _names = {
        "id": 'id',
        "originator_amount_is_fixed": 'originatorAmountIsFixed',
        "exchange_rate": 'exchangeRate',
        "locked": 'locked',
        "revision": 'revision',
        "beneficiary_currency": 'beneficiaryCurrency',
        "value_date": 'valueDate',
        "beneficiary_amount": 'beneficiaryAmount',
        "originator_amount": 'originatorAmount',
        "details": 'details'
    }

    def __init__(self,
                 id=None,
                 originator_amount_is_fixed=None,
                 exchange_rate=None,
                 locked=None,
                 revision=None,
                 beneficiary_currency=None,
                 value_date=None,
                 beneficiary_amount=None,
                 originator_amount=None,
                 details=None):
        """Constructor for the Quote class"""

        # Initialize members of the class
        self.id = id
        self.originator_amount_is_fixed = originator_amount_is_fixed
        self.exchange_rate = exchange_rate
        self.value_date = value_date
        self.locked = locked
        self.revision = revision

        # Call the constructor for the base class
        super(Quote, self).__init__(beneficiary_currency,
                                    beneficiary_amount,
                                    originator_amount,
                                    details)

    @classmethod
    def from_dictionary(cls,
                        dictionary):
        """Creates an instance of this model from a dictionary

        Args:
            dictionary (dictionary): A dictionary representation of the object
            as obtained from the deserialization of the server's response. The
            keys MUST match property names in the API description.

        Returns:
            object: An instance of this structure class.

        """
        if dictionary is None:
            return None

        # Extract variables from the dictionary
        id = dictionary.get('id')
        originator_amount_is_fixed = dictionary.get('originatorAmountIsFixed')
        exchange_rate = dictionary.get('exchangeRate')
        locked = dictionary.get('locked')
        revision = dictionary.get('revision')
        beneficiary_currency = dictionary.get('beneficiaryCurrency')
        value_date = dateutil.parser.parse(dictionary.get('valueDate')).date() if dictionary.get('valueDate') else None
        beneficiary_amount = dictionary.get('beneficiaryAmount')
        originator_amount = dictionary.get('originatorAmount')
        details = QuoteDetails.from_dictionary(dictionary.get('details')) if dictionary.get('details') else None

        # Return an object of this model
        return cls(id,
                   originator_amount_is_fixed,
                   exchange_rate,
                   locked,
                   revision,
                   beneficiary_currency,
                   value_date,
                   beneficiary_amount,
                   originator_amount,
                   details)
