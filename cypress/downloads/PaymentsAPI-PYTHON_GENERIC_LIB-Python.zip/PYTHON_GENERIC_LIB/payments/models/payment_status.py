# -*- coding: utf-8 -*-

"""
payments

This file was automatically generated for PeopleHedge by APIMATIC v2.0 (
 https://apimatic.io ).
"""


class PaymentStatus(object):

    """Implementation of the 'PaymentStatus' model.

    Payment Information Data

    Attributes:
        approved (bool): Set to true once the payment has been approved
        sent (bool): Set to true once the payment has been sent

    """

    # Create a mapping from Model property names to API property names
    _names = {
        "approved": 'approved',
        "sent": 'sent'
    }

    def __init__(self,
                 approved=None,
                 sent=None):
        """Constructor for the PaymentStatus class"""

        # Initialize members of the class
        self.approved = approved
        self.sent = sent

    @classmethod
    def from_dictionary(cls,
                        dictionary):
        """Creates an instance of this model from a dictionary

        Args:
            dictionary (dictionary): A dictionary representation of the object
            as obtained from the deserialization of the server's response. The
            keys MUST match property names in the API description.

        Returns:
            object: An instance of this structure class.

        """
        if dictionary is None:
            return None

        # Extract variables from the dictionary
        approved = dictionary.get('approved')
        sent = dictionary.get('sent')

        # Return an object of this model
        return cls(approved,
                   sent)
