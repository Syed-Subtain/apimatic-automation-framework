# -*- coding: utf-8 -*-

"""
payments

This file was automatically generated for PeopleHedge by APIMATIC v2.0 (
 https://apimatic.io ).
"""


class PaymentDetails(object):

    """Implementation of the 'PaymentDetails' model.

    Payment Information Data

    Attributes:
        payment_reference (string): Payment Reference Information
        purpose_of_payment (string): Purpose of payment
        reg_e (bool): Set to true if this is a Reg E Payment
        memo (string): Deprecated - DO NOT USE

    """

    # Create a mapping from Model property names to API property names
    _names = {
        "purpose_of_payment": 'purposeOfPayment',
        "payment_reference": 'paymentReference',
        "reg_e": 'regE',
        "memo": 'memo'
    }

    def __init__(self,
                 purpose_of_payment=None,
                 payment_reference=None,
                 reg_e=None,
                 memo=None):
        """Constructor for the PaymentDetails class"""

        # Initialize members of the class
        self.payment_reference = payment_reference
        self.purpose_of_payment = purpose_of_payment
        self.reg_e = reg_e
        self.memo = memo

    @classmethod
    def from_dictionary(cls,
                        dictionary):
        """Creates an instance of this model from a dictionary

        Args:
            dictionary (dictionary): A dictionary representation of the object
            as obtained from the deserialization of the server's response. The
            keys MUST match property names in the API description.

        Returns:
            object: An instance of this structure class.

        """
        if dictionary is None:
            return None

        # Extract variables from the dictionary
        purpose_of_payment = dictionary.get('purposeOfPayment')
        payment_reference = dictionary.get('paymentReference')
        reg_e = dictionary.get('regE')
        memo = dictionary.get('memo')

        # Return an object of this model
        return cls(purpose_of_payment,
                   payment_reference,
                   reg_e,
                   memo)
