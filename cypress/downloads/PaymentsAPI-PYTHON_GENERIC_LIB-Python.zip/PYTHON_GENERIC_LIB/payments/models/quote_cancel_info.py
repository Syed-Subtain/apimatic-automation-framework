# -*- coding: utf-8 -*-

"""
payments

This file was automatically generated for PeopleHedge by APIMATIC v2.0 (
 https://apimatic.io ).
"""
from payments.api_helper import APIHelper


class QuoteCancelInfo(object):

    """Implementation of the 'QuoteCancelInfo' model.

    Cancellation information for a quote prior to being cancelled

    Attributes:
        quote_id (int): Quote ID
        chargeback_amount (float): Chargeback amount if quote is cancelled.
            Currently always returns null
        message (string): Message regarding the cancellation information
        expiration (datetime): Expiration time this cancellation information
            object is valid until. Currently always returns null

    """

    # Create a mapping from Model property names to API property names
    _names = {
        "quote_id": 'quoteId',
        "message": 'message',
        "chargeback_amount": 'chargebackAmount',
        "expiration": 'expiration'
    }

    def __init__(self,
                 quote_id=None,
                 message=None,
                 chargeback_amount=None,
                 expiration=None):
        """Constructor for the QuoteCancelInfo class"""

        # Initialize members of the class
        self.quote_id = quote_id
        self.chargeback_amount = chargeback_amount
        self.message = message
        self.expiration = APIHelper.RFC3339DateTime(expiration) if expiration else None

    @classmethod
    def from_dictionary(cls,
                        dictionary):
        """Creates an instance of this model from a dictionary

        Args:
            dictionary (dictionary): A dictionary representation of the object
            as obtained from the deserialization of the server's response. The
            keys MUST match property names in the API description.

        Returns:
            object: An instance of this structure class.

        """
        if dictionary is None:
            return None

        # Extract variables from the dictionary
        quote_id = dictionary.get('quoteId')
        message = dictionary.get('message')
        chargeback_amount = dictionary.get('chargebackAmount')
        expiration = APIHelper.RFC3339DateTime.from_value(dictionary.get("expiration")).datetime if dictionary.get("expiration") else None

        # Return an object of this model
        return cls(quote_id,
                   message,
                   chargeback_amount,
                   expiration)
