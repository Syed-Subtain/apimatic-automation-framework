# -*- coding: utf-8 -*-

"""
payments

This file was automatically generated for PeopleHedge by APIMATIC v2.0 (
 https://apimatic.io ).
"""


class Address(object):

    """Implementation of the 'Address' model.

    Address Information

    Attributes:
        address_1 (string): Address Line 1
        address_2 (string): Address Line 2
        address_3 (string): Address Line 3. Note - Only address3 or (city,
            state, postalCode) is allowed. Please contact support to configure
            your account for your desired address formatting.
        city (string): City
        state (string): State / Province
        postal_code (string): Postal Code
        country (string): Country (ISO 3166-1 Alpha-2 Code)

    """

    # Create a mapping from Model property names to API property names
    _names = {
        "address_1": 'address1',
        "country": 'country',
        "address_2": 'address2',
        "address_3": 'address3',
        "city": 'city',
        "state": 'state',
        "postal_code": 'postalCode'
    }

    def __init__(self,
                 address_1=None,
                 country=None,
                 address_2=None,
                 address_3=None,
                 city=None,
                 state=None,
                 postal_code=None):
        """Constructor for the Address class"""

        # Initialize members of the class
        self.address_1 = address_1
        self.address_2 = address_2
        self.address_3 = address_3
        self.city = city
        self.state = state
        self.postal_code = postal_code
        self.country = country

    @classmethod
    def from_dictionary(cls,
                        dictionary):
        """Creates an instance of this model from a dictionary

        Args:
            dictionary (dictionary): A dictionary representation of the object
            as obtained from the deserialization of the server's response. The
            keys MUST match property names in the API description.

        Returns:
            object: An instance of this structure class.

        """
        if dictionary is None:
            return None

        # Extract variables from the dictionary
        address_1 = dictionary.get('address1')
        country = dictionary.get('country')
        address_2 = dictionary.get('address2')
        address_3 = dictionary.get('address3')
        city = dictionary.get('city')
        state = dictionary.get('state')
        postal_code = dictionary.get('postalCode')

        # Return an object of this model
        return cls(address_1,
                   country,
                   address_2,
                   address_3,
                   city,
                   state,
                   postal_code)
