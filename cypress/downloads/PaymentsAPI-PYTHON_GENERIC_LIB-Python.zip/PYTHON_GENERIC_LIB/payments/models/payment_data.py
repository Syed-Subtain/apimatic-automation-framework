# -*- coding: utf-8 -*-

"""
payments

This file was automatically generated for PeopleHedge by APIMATIC v2.0 (
 https://apimatic.io ).
"""
from payments.models.bank_account import BankAccount
from payments.models.entity import Beneficiary
from payments.models.entity import Originator
from payments.models.payment_details import PaymentDetails
from payments.models.payment_status import PaymentStatus


class PaymentData(object):

    """Implementation of the 'PaymentData' model.

    Payment Data Information Object

    Attributes:
        quote_id (int): Quote ID
        originator (Originator): Originator Information Object
        originator_bank_account (BankAccount): Originator Bank Account. Note -
            originatorBankAccount.accountNumber is the only required field.
            Name and address information is retrieved from the database
        beneficiary (Beneficiary): Beneficiary Information Object
        beneficiary_bank_account (BankAccount): Beneficiary Bank Account
            Object
        intermediary_bank_account (BankAccount): Intermediary Bank Account
            Object
        details (PaymentDetails): Payment Information Data

    """

    # Create a mapping from Model property names to API property names
    _names = {
        "quote_id": 'quoteId',
        "originator": 'originator',
        "beneficiary": 'beneficiary',
        "details": 'details',
        "originator_bank_account": 'originatorBankAccount',
        "beneficiary_bank_account": 'beneficiaryBankAccount',
        "intermediary_bank_account": 'intermediaryBankAccount'
    }

    def __init__(self,
                 quote_id=None,
                 originator=None,
                 beneficiary=None,
                 details=None,
                 originator_bank_account=None,
                 beneficiary_bank_account=None,
                 intermediary_bank_account=None):
        """Constructor for the PaymentData class"""

        # Initialize members of the class
        self.quote_id = quote_id
        self.originator = originator
        self.originator_bank_account = originator_bank_account
        self.beneficiary = beneficiary
        self.beneficiary_bank_account = beneficiary_bank_account
        self.intermediary_bank_account = intermediary_bank_account
        self.details = details

    @classmethod
    def from_dictionary(cls,
                        dictionary):
        """Creates an instance of this model from a dictionary

        Args:
            dictionary (dictionary): A dictionary representation of the object
            as obtained from the deserialization of the server's response. The
            keys MUST match property names in the API description.

        Returns:
            object: An instance of this structure class.

        """
        if dictionary is None:
            return None

        # Extract variables from the dictionary
        quote_id = dictionary.get('quoteId')
        originator = Originator.from_dictionary(dictionary.get('originator')) if dictionary.get('originator') else None
        beneficiary = Beneficiary.from_dictionary(dictionary.get('beneficiary')) if dictionary.get('beneficiary') else None
        details = PaymentDetails.from_dictionary(dictionary.get('details')) if dictionary.get('details') else None
        originator_bank_account = BankAccount.from_dictionary(dictionary.get('originatorBankAccount')) if dictionary.get('originatorBankAccount') else None
        beneficiary_bank_account = BankAccount.from_dictionary(dictionary.get('beneficiaryBankAccount')) if dictionary.get('beneficiaryBankAccount') else None
        intermediary_bank_account = BankAccount.from_dictionary(dictionary.get('intermediaryBankAccount')) if dictionary.get('intermediaryBankAccount') else None

        # Return an object of this model
        return cls(quote_id,
                   originator,
                   beneficiary,
                   details,
                   originator_bank_account,
                   beneficiary_bank_account,
                   intermediary_bank_account)


class Payment(PaymentData):

    """Implementation of the 'Payment' model.

    Payment Model
    NOTE: This class inherits from 'PaymentData'.

    Attributes:
        id (int): Payment ID
        status (PaymentStatus): Payment Status

    """

    # Create a mapping from Model property names to API property names
    _names = {
        "id": 'id',
        "status": 'status',
        "quote_id": 'quoteId',
        "originator": 'originator',
        "beneficiary": 'beneficiary',
        "details": 'details',
        "originator_bank_account": 'originatorBankAccount',
        "beneficiary_bank_account": 'beneficiaryBankAccount',
        "intermediary_bank_account": 'intermediaryBankAccount'
    }

    def __init__(self,
                 id=None,
                 status=None,
                 quote_id=None,
                 originator=None,
                 beneficiary=None,
                 details=None,
                 originator_bank_account=None,
                 beneficiary_bank_account=None,
                 intermediary_bank_account=None):
        """Constructor for the Payment class"""

        # Initialize members of the class
        self.id = id
        self.status = status

        # Call the constructor for the base class
        super(Payment, self).__init__(quote_id,
                                      originator,
                                      beneficiary,
                                      details,
                                      originator_bank_account,
                                      beneficiary_bank_account,
                                      intermediary_bank_account)

    @classmethod
    def from_dictionary(cls,
                        dictionary):
        """Creates an instance of this model from a dictionary

        Args:
            dictionary (dictionary): A dictionary representation of the object
            as obtained from the deserialization of the server's response. The
            keys MUST match property names in the API description.

        Returns:
            object: An instance of this structure class.

        """
        if dictionary is None:
            return None

        # Extract variables from the dictionary
        id = dictionary.get('id')
        status = PaymentStatus.from_dictionary(dictionary.get('status')) if dictionary.get('status') else None
        quote_id = dictionary.get('quoteId')
        originator = Originator.from_dictionary(dictionary.get('originator')) if dictionary.get('originator') else None
        beneficiary = Beneficiary.from_dictionary(dictionary.get('beneficiary')) if dictionary.get('beneficiary') else None
        details = PaymentDetails.from_dictionary(dictionary.get('details')) if dictionary.get('details') else None
        originator_bank_account = BankAccount.from_dictionary(dictionary.get('originatorBankAccount')) if dictionary.get('originatorBankAccount') else None
        beneficiary_bank_account = BankAccount.from_dictionary(dictionary.get('beneficiaryBankAccount')) if dictionary.get('beneficiaryBankAccount') else None
        intermediary_bank_account = BankAccount.from_dictionary(dictionary.get('intermediaryBankAccount')) if dictionary.get('intermediaryBankAccount') else None

        # Return an object of this model
        return cls(id,
                   status,
                   quote_id,
                   originator,
                   beneficiary,
                   details,
                   originator_bank_account,
                   beneficiary_bank_account,
                   intermediary_bank_account)
