# -*- coding: utf-8 -*-

"""
payments

This file was automatically generated for PeopleHedge by APIMATIC v2.0 (
 https://apimatic.io ).
"""


class EntityTypeEnum(object):

    """Implementation of the 'EntityType' enum.

    Available Entity Types

    Attributes:
        INDIVIDUAL: Individual
        COMPANY: Company

    """

    INDIVIDUAL = 'individual'

    COMPANY = 'company'
