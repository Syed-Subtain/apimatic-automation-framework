# -*- coding: utf-8 -*-

"""
payments

This file was automatically generated for PeopleHedge by APIMATIC v2.0 (
 https://apimatic.io ).
"""
from payments.models.entity import Bank


class BankAccount(object):

    """Implementation of the 'BankAccount' model.

    Bank Account Information Object.**NOTE** - originatorBankAccount bank data
    should not be provided when creating a new Payment. This information is
    retrieved from the database based on the provided bank ID.**NOTE** - bank
    object is required for all BankAccount objects except
    originatorBankAccount

    Attributes:
        account_number (string): Bank Account Number / IBAN. Required for
            Beneficiary Bank. Optional for Intermediary Bank.
        bank (Bank): Bank Information Object - Required for all banks except
            Originator

    """

    # Create a mapping from Model property names to API property names
    _names = {
        "account_number": 'accountNumber',
        "bank": 'bank'
    }

    def __init__(self,
                 account_number=None,
                 bank=None):
        """Constructor for the BankAccount class"""

        # Initialize members of the class
        self.account_number = account_number
        self.bank = bank

    @classmethod
    def from_dictionary(cls,
                        dictionary):
        """Creates an instance of this model from a dictionary

        Args:
            dictionary (dictionary): A dictionary representation of the object
            as obtained from the deserialization of the server's response. The
            keys MUST match property names in the API description.

        Returns:
            object: An instance of this structure class.

        """
        if dictionary is None:
            return None

        # Extract variables from the dictionary
        account_number = dictionary.get('accountNumber')
        bank = Bank.from_dictionary(dictionary.get('bank')) if dictionary.get('bank') else None

        # Return an object of this model
        return cls(account_number,
                   bank)
