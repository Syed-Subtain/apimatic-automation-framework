# -*- coding: utf-8 -*-

"""
payments

This file was automatically generated for PeopleHedge by APIMATIC v2.0 (
 https://apimatic.io ).
"""
from payments.models.address import Address


class Entity(object):

    """Implementation of the 'Entity' model.

    Entity Information Object - base type for Beneficiary, Originator, and
    Bank

    Attributes:
        name (string): Entity Name
        address (Address): Address Information

    """

    # Create a mapping from Model property names to API property names
    _names = {
        "name": 'name',
        "address": 'address'
    }

    def __init__(self,
                 name=None,
                 address=None):
        """Constructor for the Entity class"""

        # Initialize members of the class
        self.name = name
        self.address = address

    @classmethod
    def from_dictionary(cls,
                        dictionary):
        """Creates an instance of this model from a dictionary

        Args:
            dictionary (dictionary): A dictionary representation of the object
            as obtained from the deserialization of the server's response. The
            keys MUST match property names in the API description.

        Returns:
            object: An instance of this structure class.

        """
        if dictionary is None:
            return None

        # Extract variables from the dictionary
        name = dictionary.get('name')
        address = Address.from_dictionary(dictionary.get('address')) if dictionary.get('address') else None

        # Return an object of this model
        return cls(name,
                   address)


class Beneficiary(Entity):

    """Implementation of the 'Beneficiary' model.

    Beneficiary Information Object
    NOTE: This class inherits from 'Entity'.

    Attributes:
        email (string): Beneficiary Email Address
        phone_number (string): Beneficiary Phone Number
        mtype (EntityTypeEnum): Type - individual or company

    """

    # Create a mapping from Model property names to API property names
    _names = {
        "name": 'name',
        "address": 'address',
        "email": 'email',
        "phone_number": 'phoneNumber',
        "mtype": 'type'
    }

    def __init__(self,
                 name=None,
                 address=None,
                 email=None,
                 phone_number=None,
                 mtype=None):
        """Constructor for the Beneficiary class"""

        # Initialize members of the class
        self.email = email
        self.phone_number = phone_number
        self.mtype = mtype

        # Call the constructor for the base class
        super(Beneficiary, self).__init__(name,
                                          address)

    @classmethod
    def from_dictionary(cls,
                        dictionary):
        """Creates an instance of this model from a dictionary

        Args:
            dictionary (dictionary): A dictionary representation of the object
            as obtained from the deserialization of the server's response. The
            keys MUST match property names in the API description.

        Returns:
            object: An instance of this structure class.

        """
        if dictionary is None:
            return None

        # Extract variables from the dictionary
        name = dictionary.get('name')
        address = Address.from_dictionary(dictionary.get('address')) if dictionary.get('address') else None
        email = dictionary.get('email')
        phone_number = dictionary.get('phoneNumber')
        mtype = dictionary.get('type')

        # Return an object of this model
        return cls(name,
                   address,
                   email,
                   phone_number,
                   mtype)


class Bank(Entity):

    """Implementation of the 'Bank' model.

    Bank Information Object
    NOTE: This class inherits from 'Entity'.

    Attributes:
        routing_code (string): Country Specific Routing Code (e.g. IFSC code
            for India). When using for USD wires, please only provide SWIFT
            code OR routing code (not both)
        swift_code (string): SWIFT BIC. Required for international wires

    """

    # Create a mapping from Model property names to API property names
    _names = {
        "name": 'name',
        "address": 'address',
        "routing_code": 'routingCode',
        "swift_code": 'swiftCode'
    }

    def __init__(self,
                 name=None,
                 address=None,
                 routing_code=None,
                 swift_code=None):
        """Constructor for the Bank class"""

        # Initialize members of the class
        self.routing_code = routing_code
        self.swift_code = swift_code

        # Call the constructor for the base class
        super(Bank, self).__init__(name,
                                   address)

    @classmethod
    def from_dictionary(cls,
                        dictionary):
        """Creates an instance of this model from a dictionary

        Args:
            dictionary (dictionary): A dictionary representation of the object
            as obtained from the deserialization of the server's response. The
            keys MUST match property names in the API description.

        Returns:
            object: An instance of this structure class.

        """
        if dictionary is None:
            return None

        # Extract variables from the dictionary
        name = dictionary.get('name')
        address = Address.from_dictionary(dictionary.get('address')) if dictionary.get('address') else None
        routing_code = dictionary.get('routingCode')
        swift_code = dictionary.get('swiftCode')

        # Return an object of this model
        return cls(name,
                   address,
                   routing_code,
                   swift_code)


class Originator(Entity):

    """Implementation of the 'Originator' model.

    Originator Object
    NOTE: This class inherits from 'Entity'.

    Attributes:
        mtype (EntityTypeEnum): Type - individual or company

    """

    # Create a mapping from Model property names to API property names
    _names = {
        "name": 'name',
        "address": 'address',
        "mtype": 'type'
    }

    def __init__(self,
                 name=None,
                 address=None,
                 mtype=None):
        """Constructor for the Originator class"""

        # Initialize members of the class
        self.mtype = mtype

        # Call the constructor for the base class
        super(Originator, self).__init__(name,
                                         address)

    @classmethod
    def from_dictionary(cls,
                        dictionary):
        """Creates an instance of this model from a dictionary

        Args:
            dictionary (dictionary): A dictionary representation of the object
            as obtained from the deserialization of the server's response. The
            keys MUST match property names in the API description.

        Returns:
            object: An instance of this structure class.

        """
        if dictionary is None:
            return None

        # Extract variables from the dictionary
        name = dictionary.get('name')
        address = Address.from_dictionary(dictionary.get('address')) if dictionary.get('address') else None
        mtype = dictionary.get('type')

        # Return an object of this model
        return cls(name,
                   address,
                   mtype)
