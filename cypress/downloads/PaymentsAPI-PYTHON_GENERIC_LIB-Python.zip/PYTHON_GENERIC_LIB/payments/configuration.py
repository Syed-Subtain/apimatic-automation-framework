# -*- coding: utf-8 -*-

"""
payments

This file was automatically generated for PeopleHedge by APIMATIC v2.0 (
 https://apimatic.io ).
"""

from enum import Enum
import logging
import sys

from payments.api_helper import APIHelper
from payments.http.requests_client import RequestsClient
logging.basicConfig(stream=sys.stdout, level=logging.INFO)



class Environment(Enum):
    """An enum for SDK environments"""
    # API default Environment
    DEFAULT = 0


class Server(Enum):
    """An enum for API servers"""
    DEFAULT = 0


class Configuration(object):
    """A class used for configuring the SDK by a user.
    """

    @property
    def http_client(self):
        return self._http_client

    @property
    def timeout(self):
        return self._timeout

    @property
    def max_retries(self):
        return self._max_retries

    @property
    def backoff_factor(self):
        return self._backoff_factor

    @property
    def environment(self):
        return self._environment

    @property
    def base_uri(self):
        return self._base_uri

    @property
    def base_path(self):
        return self._base_path

    @property
    def bank_id(self):
        return self._bank_id

    @property
    def x_api_key(self):
        return self._x_api_key

    def __init__(self, timeout=60, max_retries=3, backoff_factor=0,
                 environment=Environment.DEFAULT, base_uri='api.example.local',
                 base_path='v1', bank_id='123456789',
                 x_api_key='XXXCHANGETOAPIKEYXXX'):
        # The value to use for connection timeout
        self._timeout = timeout

        # The number of times to retry an endpoint call if it fails
        self._max_retries = max_retries

        # A backoff factor to apply between attempts after the second try.
        # urllib3 will sleep for:
        # `{backoff factor} * (2 ** ({number of total retries} - 1))`
        self._backoff_factor = backoff_factor

        # Current API environment
        self._environment = environment

        # Domain Name
        self._base_uri = base_uri

        # URL Base Path
        self._base_path = base_path

        # Bank ID (ABA/Routing Number)
        self._bank_id = bank_id

        # API Key
        self._x_api_key = x_api_key

        # The Http Client to use for making requests.
        self._http_client = self.create_http_client()

    def clone_with(self, timeout=None, max_retries=None, backoff_factor=None,
                   environment=None, base_uri=None, base_path=None,
                   bank_id=None, x_api_key=None):
        timeout = timeout or self.timeout
        max_retries = max_retries or self.max_retries
        backoff_factor = backoff_factor or self.backoff_factor
        environment = environment or self.environment
        base_uri = base_uri or self.base_uri
        base_path = base_path or self.base_path
        bank_id = bank_id or self.bank_id
        x_api_key = x_api_key or self.x_api_key

        return Configuration(timeout=timeout, max_retries=max_retries,
                             backoff_factor=backoff_factor,
                             environment=environment, base_uri=base_uri,
                             base_path=base_path, bank_id=bank_id,
                             x_api_key=x_api_key)

    def create_http_client(self):
        return RequestsClient(timeout=self.timeout,
                              max_retries=self.max_retries,
                              backoff_factor=self.backoff_factor)

    # All the environments the SDK can run in
    environments = {
        Environment.DEFAULT: {
            Server.DEFAULT: 'https://{baseUri}/{basePath}'
        }
    }

    def get_base_uri(self, server=Server.DEFAULT):
        """Generates the appropriate base URI for the environment and the
        server.

        Args:
            server (Configuration.Server): The server enum for which the base
            URI is required.

        Returns:
            String: The base URI.

        """
        parameters = {
            "baseUri": {'value': self.base_uri, 'encode': False},
            "basePath": {'value': self.base_path, 'encode': False},
        }

        return APIHelper.append_url_with_template_parameters(
            self.environments[self.environment][server], parameters
        )

    @classmethod
    def disable_logging(cls):
        """Disable all logging in the SDK
        """
        for handler in logging.root.handlers[:]:
            logging.root.removeHandler(handler)

    @classmethod
    def enable_logging(cls):
        """Enable logging in the SDK
        """
        cls.disable_logging()   # clear previously set logging info
        logging.basicConfig(stream=sys.stdout, level=logging.INFO)
