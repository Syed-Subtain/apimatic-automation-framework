
# Getting Started with Supplier API

## Introduction

![example image](https://i.ibb.co/7bqPkGJ/PMS-integration-workflow.png "An exemplary image")

**Before beginning your work it is necessary that:**

* Your organization is registered and activated
* You have participated in a kick-off meeting
* The opening questionnaire has been filled out
* You have your login and password. (Using it you get a unique session `token` that must be used in every request to API as param `jwt`)

[Contact us](https://bookingpal.com/en/contact-us/) to be registered and get your credentials.

All responses are returned as JSON.

This document covers all the API calls and other methods that can be used to complete Razor-Cloud integration. It is important to note that all parameters are **case sensitive** in this document and should be used as documented.

**Payload Limit:**  for each request, max payload limit is 200Kb

**Responses:**
When a request is successful, a response body will typically be sent back in the form of a JSON object. An exception to this is when a DELETE request is processed, which will result in a successful `200` status and an empty response body.

## Building

You must have Python `3 >=3.7, <= 3.9` installed on your system to install and run this SDK. This SDK package depends on other Python packages like nose, jsonpickle etc. These dependencies are defined in the `requirements.txt` file that comes with the SDK. To resolve these dependencies, you can use the PIP Dependency manager. Install it by following steps at [https://pip.pypa.io/en/stable/installing/](https://pip.pypa.io/en/stable/installing/).

Python and PIP executables should be defined in your PATH. Open command prompt and type `pip --version`. This should display the version of the PIP Dependency Manager installed if your installation was successful and the paths are properly defined.

* Using command line, navigate to the directory containing the generated files (including `requirements.txt`) for the SDK.
* Run the command `pip install -r requirements.txt`. This should install all the required dependencies.

![Building SDK - Step 1](https://apidocs.io/illustration/python?workspaceFolder=Supplierapi-Python&step=installDependencies)

## Installation

The following section explains how to use the supplierapi library in a new project.

### 1. Open Project in an IDE

Open up a Python IDE like PyCharm. The basic workflow presented here is also applicable if you prefer using a different editor or IDE.

![Open project in PyCharm - Step 1](https://apidocs.io/illustration/python?workspaceFolder=Supplierapi-Python&step=pyCharm)

Click on `Open` in PyCharm to browse to your generated SDK directory and then click `OK`.

![Open project in PyCharm - Step 2](https://apidocs.io/illustration/python?workspaceFolder=Supplierapi-Python&step=openProject0)

The project files will be displayed in the side bar as follows:

![Open project in PyCharm - Step 3](https://apidocs.io/illustration/python?workspaceFolder=Supplierapi-Python&projectName=supplierapi&step=openProject1)

### 2. Add a new Test Project

Create a new directory by right clicking on the solution name as shown below:

![Add a new project in PyCharm - Step 1](https://apidocs.io/illustration/python?workspaceFolder=Supplierapi-Python&projectName=supplierapi&step=createDirectory)

Name the directory as "test".

![Add a new project in PyCharm - Step 2](https://apidocs.io/illustration/python?workspaceFolder=Supplierapi-Python&step=nameDirectory)

Add a python file to this project.

![Add a new project in PyCharm - Step 3](https://apidocs.io/illustration/python?workspaceFolder=Supplierapi-Python&projectName=supplierapi&step=createFile)

Name it "testSDK".

![Add a new project in PyCharm - Step 4](https://apidocs.io/illustration/python?workspaceFolder=Supplierapi-Python&projectName=supplierapi&step=nameFile)

In your python file you will be required to import the generated python library using the following code lines

```python
from supplierapi.supplierapi_client import SupplierapiClient
```

![Add a new project in PyCharm - Step 5](https://apidocs.io/illustration/python?workspaceFolder=Supplierapi-Python&projectName=supplierapi&libraryName=supplierapi.supplierapi_client&className=SupplierapiClient&step=projectFiles)

After this you can write code to instantiate an API client object, get a controller object and  make API calls. Sample code is given in the subsequent sections.

### 3. Run the Test Project

To run the file within your test project, right click on your Python file inside your Test project and click on `Run`

![Run Test Project - Step 1](https://apidocs.io/illustration/python?workspaceFolder=Supplierapi-Python&projectName=supplierapi&libraryName=supplierapi.supplierapi_client&className=SupplierapiClient&step=runProject)

## Test the SDK

You can test the generated SDK and the server with test cases. `unittest` is used as the testing framework and `nose` is used as the test runner. You can run the tests as follows:

Navigate to the root directory of the SDK and run the following commands

```
pip install -r test-requirements.txt
nosetests
```

## Initialize the API Client

**_Note:_** Documentation for the client can be found [here.](doc/client.md)

The following parameters are configurable for the API Client:

| Parameter | Type | Description |
|  --- | --- | --- |
| `push_server_url` | `string` | In some API call BookingPal will send POST request (push message) to the PMS for URL which you provide in API 'Push Notification'. You can test these calls to in this documentation, just you will need to set your URL here on specific API call, on Configure button in the right section of specific API function<br>*Default*: `'https://www.yourEndpoint.url'` |
| `environment` | Environment | The API environment. <br> **Default: `Environment.PRODUCTION`** |
| `http_client_instance` | `HttpClient` | The Http Client passed from the sdk user for making requests |
| `override_http_client_configuration` | `bool` | The value which determines to override properties of the passed Http Client from the sdk user |
| `http_call_back` | `HttpCallBack` | The callback value that is invoked before and after an HTTP call is made to an endpoint |
| `timeout` | `float` | The value to use for connection timeout. <br> **Default: 60** |
| `max_retries` | `int` | The number of times to retry an endpoint call if it fails. <br> **Default: 0** |
| `backoff_factor` | `float` | A backoff factor to apply between attempts after the second try. <br> **Default: 2** |
| `retry_statuses` | `Array of int` | The http statuses on which retry is to be done. <br> **Default: [408, 413, 429, 500, 502, 503, 504, 521, 522, 524]** |
| `retry_methods` | `Array of string` | The http methods on which retry is to be done. <br> **Default: ['GET', 'PUT']** |
| `jwt` | `string` | Token which need to be passed in every request as GET parameter. You will get this token in authorization response. Token is valid 1 hour. |

The API client can be initialized as follows:

```python
from supplierapi.supplierapi_client import SupplierapiClient
from supplierapi.configuration import Environment

client = SupplierapiClient(
    jwt='jwt',
    environment=Environment.PRODUCTION,
    push_server_url = 'https://www.yourEndpoint.url',)
```

## Environments

The SDK can be configured to use a different environment for making API calls. Available environments are:

### Fields

| Name | Description |
|  --- | --- |
| production | **Default** BookingPal Supplier API test server |
| environment2 | BookingPal Supplier API test server |

## Authorization

This API uses `Custom Query Parameter`.

## List of APIs

* [Property Managers](doc/controllers/property-managers.md)
* [Ratesand Availability](doc/controllers/ratesand-availability.md)
* [Feeand Tax](doc/controllers/feeand-tax.md)
* [Feeand Tax Mandatoryatthepropertylevel](doc/controllers/feeand-tax-mandatoryatthepropertylevel.md)
* [Testingofmessage AP Icalls](doc/controllers/testingofmessage-ap-icalls.md)
* [Push Notification](doc/controllers/push-notification.md)
* [Reservation Notifications](doc/controllers/reservation-notifications.md)
* [Asynchronous Push Messages](doc/controllers/asynchronous-push-messages.md)
* [Request to Book](doc/controllers/request-to-book.md)
* [LOS Pricing](doc/controllers/los-pricing.md)
* [Configuration in Supplier API](doc/controllers/configuration-in-supplier-api.md)
* [Authorization](doc/controllers/authorization.md)
* [Product](doc/controllers/product.md)
* [Images](doc/controllers/images.md)
* [Yields](doc/controllers/yields.md)
* [Validation](doc/controllers/validation.md)
* [Messaging](doc/controllers/messaging.md)
* [Licenses](doc/controllers/licenses.md)

## Classes Documentation

* [Utility Classes](doc/utility-classes.md)
* [HttpResponse](doc/http-response.md)
* [HttpRequest](doc/http-request.md)

