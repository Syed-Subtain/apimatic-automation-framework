
# Client Class Documentation

The following parameters are configurable for the API Client:

| Parameter | Type | Description |
|  --- | --- | --- |
| `push_server_url` | `string` | In some API call BookingPal will send POST request (push message) to the PMS for URL which you provide in API 'Push Notification'. You can test these calls to in this documentation, just you will need to set your URL here on specific API call, on Configure button in the right section of specific API function<br>*Default*: `'https://www.yourEndpoint.url'` |
| `environment` | Environment | The API environment. <br> **Default: `Environment.PRODUCTION`** |
| `http_client_instance` | `HttpClient` | The Http Client passed from the sdk user for making requests |
| `override_http_client_configuration` | `bool` | The value which determines to override properties of the passed Http Client from the sdk user |
| `http_call_back` | `HttpCallBack` | The callback value that is invoked before and after an HTTP call is made to an endpoint |
| `timeout` | `float` | The value to use for connection timeout. <br> **Default: 60** |
| `max_retries` | `int` | The number of times to retry an endpoint call if it fails. <br> **Default: 0** |
| `backoff_factor` | `float` | A backoff factor to apply between attempts after the second try. <br> **Default: 2** |
| `retry_statuses` | `Array of int` | The http statuses on which retry is to be done. <br> **Default: [408, 413, 429, 500, 502, 503, 504, 521, 522, 524]** |
| `retry_methods` | `Array of string` | The http methods on which retry is to be done. <br> **Default: ['GET', 'PUT']** |
| `jwt` | `string` | Token which need to be passed in every request as GET parameter. You will get this token in authorization response. Token is valid 1 hour. |

The API client can be initialized as follows:

```python
from supplierapi.supplierapi_client import SupplierapiClient
from supplierapi.configuration import Environment

client = SupplierapiClient(
    jwt='jwt',
    environment=Environment.PRODUCTION,
    push_server_url = 'https://www.yourEndpoint.url',)
```

## Supplier API Client

The gateway for the SDK. This class acts as a factory for the Controllers and also holds the configuration of the SDK.

## Controllers

| Name | Description |
|  --- | --- |
| property_managers | Gets PropertyManagersController |
| authorization | Gets AuthorizationController |
| images | Gets ImagesController |
| rates_and_availability | Gets RatesAndAvailabilityController |
| fee_and_tax | Gets FeeAndTaxController |
| fee_and_tax_mandatory_at_the_property_level | Gets FeeAndTaxMandatoryAtThePropertyLevelController |
| yields | Gets YieldsController |
| testing_of_message_api_calls | Gets TestingOfMessageAPICallsController |
| messaging | Gets MessagingController |
| push_notification | Gets PushNotificationController |
| reservation_notifications | Gets ReservationNotificationsController |
| asynchronous_push_messages | Gets AsynchronousPushMessagesController |
| licenses | Gets LicensesController |
| product | Gets ProductController |
| validation | Gets ValidationController |
| request_to_book | Gets RequestToBookController |
| los_pricing | Gets LOSPricingController |
| configuration_in_supplier_api | Gets ConfigurationInSupplierAPIController |

