# Product

Every API call in this section should be with PM credentials.

```python
product_controller = client.product
```

## Class Name

`ProductController`

## Methods

* [Create Product](../../doc/controllers/product.md#create-product)
* [Activation List Product](../../doc/controllers/product.md#activation-list-product)
* [Deactivation List Product](../../doc/controllers/product.md#deactivation-list-product)
* [Delete Product](../../doc/controllers/product.md#delete-product)
* [Get Product List](../../doc/controllers/product.md#get-product-list)
* [Update Product](../../doc/controllers/product.md#update-product)
* [Delete List Product](../../doc/controllers/product.md#delete-list-product)
* [Get Product by ID](../../doc/controllers/product.md#get-product-by-id)


# Create Product

This function allows a logged in user to create new product. You can only send one product in each request.

```python
def create_product(self,
                  body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`CreateUpdatePropertyRequest`](../../doc/models/create-update-property-request.md) | Body, Required | - |

## Response Type

[`ProductResponse`](../../doc/models/product-response.md)

## Example Usage

```python
body = CreateUpdatePropertyRequest()
body.data = Property()
body.data.name = 'name6'
body.data.rooms = 186
body.data.bathrooms = 6
body.data.persons = 198
body.data.property_type = PropertyTypesEnum.PCT101
body.data.currency = 'currency6'
body.data.supported_los_rates = False

result = product_controller.create_product(body)
```


# Activation List Product

This function allows logged in user to activate a list of products in BookingPal. Products MUST be activated successfully before they can be distributed to any channel.

Note: When a product is successfully activated it will be queued for the internal BP validation function and you will receive async push messages when the validation is completed - like it is described in the Validation section.

```python
def activation_list_product(self,
                           body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`PropertyListRequest`](../../doc/models/property-list-request.md) | Body, Required | - |

## Response Type

[`APIResponseWithoutData`](../../doc/models/api-response-without-data.md)

## Example Usage

```python
body = PropertyListRequest()
body.data = [1235124634, 1235124636]

result = product_controller.activation_list_product(body)
```

## Example Response *(as JSON)*

```json
{
  "message": "Property with ids [1235124634, 1235124636] will be put in Queue for validation. Please expect response over push message.",
  "errorMessage": [],
  "is_error": false,
  "code": ""
}
```


# Deactivation List Product

This function allows the logged in user to deactivate a list of products. This function will also close the calendars on every channel the products have been listed on.

```python
def deactivation_list_product(self,
                             body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`PropertyListRequest`](../../doc/models/property-list-request.md) | Body, Required | - |

## Response Type

[`APIResponseWithoutData`](../../doc/models/api-response-without-data.md)

## Example Usage

```python
body = PropertyListRequest()
body.data = [1235124634, 1235124636]

result = product_controller.deactivation_list_product(body)
```

## Example Response *(as JSON)*

```json
{
  "message": "Product with ids [1235124634, 1235124636] are Deactivated!",
  "errorMessage": [],
  "is_error": false,
  "code": ""
}
```


# Delete Product

This function allows the logged in user to delete product.

```python
def delete_product(self,
                  product_id)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `product_id` | `string` | Template, Required | Property ID |

## Response Type

[`APIResponseWithoutData`](../../doc/models/api-response-without-data.md)

## Example Usage

```python
product_id = '1235124636'

result = product_controller.delete_product(product_id)
```

## Example Response *(as JSON)*

```json
{
  "message": "Product with id 1235124636 was deleted",
  "errorMessage": [],
  "is_error": false,
  "code": ""
}
```


# Get Product List

This API call will return a list of properties that belong to the current user. This means that a user has to be logged in with products created already.
Every API call in this section should be with PM credentials.

```python
def get_product_list(self,
                    page=None,
                    limit=None)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `page` | `float` | Query, Optional | The page number for the query |
| `limit` | `float` | Query, Optional | The limit of records per each page (max 50 records per page) |

## Response Type

[`ProductResponse`](../../doc/models/product-response.md)

## Example Usage

```python
page = 110.38
limit = 237.24

result = product_controller.get_product_list(page, limit)
```


# Update Product

This function allows a logged in user to update product details.

Request parameters and request example will be the same as in the create product API. The only field that must be added is the product id.

You need to have all other parameters which were used in the create API call that you want to keep (AltID can’t be updated). Everything that you do not send as an update will be deleted (overwritten).

Response parameters and response examples are the same as in the create product API.

```python
def update_product(self,
                  body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`CreateUpdatePropertyRequest`](../../doc/models/create-update-property-request.md) | Body, Required | - |

## Response Type

[`ProductResponse`](../../doc/models/product-response.md)

## Example Usage

```python
body = CreateUpdatePropertyRequest()
body.data = Property()
body.data.name = 'name6'
body.data.rooms = 186
body.data.bathrooms = 6
body.data.persons = 198
body.data.property_type = PropertyTypesEnum.PCT101
body.data.currency = 'currency6'
body.data.supported_los_rates = False

result = product_controller.update_product(body)
```


# Delete List Product

This function allows logged in user to delete list of products.

```python
def delete_list_product(self)
```

## Response Type

[`APIResponseWithoutData`](../../doc/models/api-response-without-data.md)

## Example Usage

```python
result = product_controller.delete_list_product()
```

## Example Response *(as JSON)*

```json
{
  "message": "Product with ids [1235124636, 1235124637] was deleted",
  "errorMessage": [],
  "is_error": false,
  "code": ""
}
```


# Get Product by ID

This function allows logged in user to get a specific product.

```python
def get_product_by_id(self,
                     product_id)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `product_id` | `string` | Template, Required | Id of the property |

## Response Type

[`ProductResponse`](../../doc/models/product-response.md)

## Example Usage

```python
product_id = '1235124634'

result = product_controller.get_product_by_id(product_id)
```

