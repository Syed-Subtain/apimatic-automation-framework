# Feeand Tax Mandatoryatthepropertylevel

```python
feeand_tax_mandatoryatthepropertylevel_controller = client.feeand_tax_mandatoryatthepropertylevel
```

## Class Name

`FeeandTaxMandatoryatthepropertylevelController`

## Methods

* [Import or Update Fee and Tax Mandatory](../../doc/controllers/feeand-tax-mandatoryatthepropertylevel.md#import-or-update-fee-and-tax-mandatory)
* [Get Fee and Tax Mandatory](../../doc/controllers/feeand-tax-mandatoryatthepropertylevel.md#get-fee-and-tax-mandatory)
* [Remove Validation Settings](../../doc/controllers/feeand-tax-mandatoryatthepropertylevel.md#remove-validation-settings)


# Import or Update Fee and Tax Mandatory

This function allows the logged in user to import or update a fee and tax mandatory.

```python
def import_or_update_fee_and_tax_mandatory(self,
                                          body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`SetFeeAndTaxValidationSettingRequest`](../../doc/models/set-fee-and-tax-validation-setting-request.md) | Body, Required | - |

## Response Type

[`APIResponseWithoutData`](../../doc/models/api-response-without-data.md)

## Example Usage

```python
body = SetFeeAndTaxValidationSettingRequest()
body.data = FeeTaxValidationSettings()
body.data.validation_settings = []

body.data.validation_settings.append(FeeTaxMandatorySetting())
body.data.validation_settings[0].product_id = 1235124634
body.data.validation_settings[0].is_fee_mandatory = False
body.data.validation_settings[0].is_tax_mandatory = False


result = fee_and_tax_mandatory_at_the_property_level_controller.import_or_update_fee_and_tax_mandatory(body)
```

## Example Response *(as JSON)*

```json
{
  "message": "For product ids [1235124634] the validation settings are imported!",
  "errorMessage": [],
  "is_error": false,
  "code": ""
}
```


# Get Fee and Tax Mandatory

This function allows the logged in user to get info about current set for all PM properties are fees/taxes set to be mandatory or not.

```python
def get_fee_and_tax_mandatory(self)
```

## Response Type

[`FeeTaxValidationSettingResponse`](../../doc/models/fee-tax-validation-setting-response.md)

## Example Usage

```python
result = fee_and_tax_mandatory_at_the_property_level_controller.get_fee_and_tax_mandatory()
```

## Example Response *(as JSON)*

```json
{
  "message": "",
  "errorMessage": [],
  "is_error": false,
  "code": "",
  "data": [
    {
      "validationSettings": [
        {
          "productId": 1235124634,
          "isFeeMandatory": false,
          "isTaxMandatory": false
        },
        {
          "productId": 1235124636,
          "isFeeMandatory": true,
          "isTaxMandatory": true
        },
        {
          "productId": 1235124637,
          "isFeeMandatory": true,
          "isTaxMandatory": true
        }
      ]
    }
  ]
}
```


# Remove Validation Settings

This function allows the logged in user to remove any setup on property level and to return on default (which is that fee/taxes are mandatory). This API call will accept a list of properties.

```python
def remove_validation_settings(self,
                              body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`PropertyListRequest`](../../doc/models/property-list-request.md) | Body, Required | - |

## Response Type

[`APIResponseWithoutData`](../../doc/models/api-response-without-data.md)

## Example Usage

```python
body = PropertyListRequest()
body.data = [1235124634]

result = fee_and_tax_mandatory_at_the_property_level_controller.remove_validation_settings(body)
```

## Example Response *(as JSON)*

```json
{
  "message": "For product ids [1235124634] the validation settings will be removed!",
  "errorMessage": [],
  "is_error": false,
  "code": ""
}
```

