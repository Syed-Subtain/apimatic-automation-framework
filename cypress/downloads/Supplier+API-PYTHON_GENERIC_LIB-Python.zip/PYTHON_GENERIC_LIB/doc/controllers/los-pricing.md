# LOS Pricing

```python
los_pricing_controller = client.los_pricing
```

## Class Name

`LOSPricingController`

## Methods

* [Create and Update LOS Length of Stay Pricing](../../doc/controllers/los-pricing.md#create-and-update-los-length-of-stay-pricing)
* [Get Los Prices List by Product ID](../../doc/controllers/los-pricing.md#get-los-prices-list-by-product-id)


# Create and Update LOS Length of Stay Pricing

Introduction: You can use this function if you would like to send BookingPal different prices for various Length of Stays with the same starting date.

LOS Pricing will be a different method in sending rates to BookingPal and is defined as pricing sent for a specific “Stay ranges”, In the LOS  method you are setting specific rates based on the Length of Stay. (This is a different way to push rates to BookingPal. )

For date periods of 1 to 30 days a specific rate need to enter check-in date and a rate for every possible reservation starting at that date (i.e. 1 day, 2 days, up to 30 days, 30 days is the maximum value allowed for this field) you will need to send BookingPal total rate value for that period.

Maximum LOS number of days is 30. All other LOS values after 30 will not be saved. If you do not support reservation for some specific number of dates - send value 0.00 for this LOS number of days. Keep in mind that all values not sent for any specific check-in date will be considered as 0, and reservation for this number of days will not be possible.
Field maxGuests allows you to set different rates per different number of guests. If you do not have different rate values per number of guests - you can send the value for maximum number of guests, and all others will have the same rate.

For MLT REP - you should use daily rates.

It is suggested to manage availability over “rates and availability” API call, and to close/open dates over this call.

Note: this API call can be used only if you set supportedLosRates = true on the product. Otherwise using this API for specific product is not possible.

```python
def create_and_update_los_length_of_stay_pricing(self,
                                                body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`CreateAndUpdateLOSRequest`](../../doc/models/create-and-update-los-request.md) | Body, Required | - |

## Response Type

[`LOSRatesResponse`](../../doc/models/los-rates-response.md)

## Example Usage

```python
body = CreateAndUpdateLOSRequest()
body.data = LOSRatesProduct()
body.data.product_id = 192
body.data.los_rates = []

body.data.los_rates.append(LOSRate())
body.data.los_rates[0].check_in_date = dateutil.parser.parse('2016-03-13').date()
body.data.los_rates[0].max_guests = 43
body.data.los_rates[0].los_value = [193.13, 193.14, 193.15]


result = los_pricing_controller.create_and_update_los_length_of_stay_pricing(body)
```

## Example Response *(as JSON)*

```json
{
  "message": "",
  "errorMessage": [],
  "is_error": false,
  "code": "",
  "data": "[{\"productId\":1235124634,\"losRates\":[{\"checkInDate\":\"2020-05-21T00:00:00.000+0000\",\"currency\":\"RSD\",\"maxGuests\":4,\"losValue\":[111,112,123,250,300,350,400,450,500,550,600,650,700,750,800,850,900,950,550,510,570,520,500,510,590,580,560,540,0,0]},{\"checkInDate\":\"2020-06-20T00:00:00.000+0000\",\"currency\":\"RSD\",\"maxGuests\":3,\"losValue\":[100,150,200,250,300,0,0,450,500,550,600,650,700,750,800,850,900,950,550,510,570,520,500,510,590,121,122,123,0,0]}]}]"
}
```


# Get Los Prices List by Product ID

This function allows the logged in user to get a LOS rate for property.

```python
def get_los_prices_list_by_product_id(self,
                                     product_id)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `product_id` | `string` | Template, Required | Property ID in BookingPal |

## Response Type

[`LOSRatesResponse`](../../doc/models/los-rates-response.md)

## Example Usage

```python
product_id = '1235124634'

result = los_pricing_controller.get_los_prices_list_by_product_id(product_id)
```

## Example Response *(as JSON)*

```json
{
  "message": "",
  "errorMessage": [],
  "is_error": false,
  "code": "",
  "data": "[{\"productId\":1235124634,\"losRates\":[{\"checkInDate\":\"2020-05-21T00:00:00.000+0000\",\"currency\":\"RSD\",\"maxGuests\":4,\"losValue\":[111,112,123,250,300,350,400,450,500,550,600,650,700,750,800,850,900,950,550,510,570,520,500,510,590,580,560,540,0,0]},{\"checkInDate\":\"2020-06-20T00:00:00.000+0000\",\"currency\":\"RSD\",\"maxGuests\":3,\"losValue\":[100,150,200,250,300,0,0,450,500,550,600,650,700,750,800,850,900,950,550,510,570,520,500,510,590,121,122,123,0,0]}]}]"
}
```

