# Yields

Every API call in this section should be with PM credentials.

Warning: Do not enable the Yields API if not yet certified. BookingPal will no longer certify new partners on this API.

If you are already certified to use the Yields API, no changes are required.

If your system requires the modification of a base price, please include any yields in the per night price for the applicable dates. For more advance yields and pricing strategies, please consider using length-of-stay (LOS) pricing.

```python
yields_controller = client.yields
```

## Class Name

`YieldsController`

## Methods

* [Post Yield by Property Manager](../../doc/controllers/yields.md#post-yield-by-property-manager)
* [Delete YMR List by Property Manager](../../doc/controllers/yields.md#delete-ymr-list-by-property-manager)
* [Get YMR List by Property Manager](../../doc/controllers/yields.md#get-ymr-list-by-property-manager)
* [Create YMR](../../doc/controllers/yields.md#create-ymr)
* [Get YMR List by Product ID](../../doc/controllers/yields.md#get-ymr-list-by-product-id)


# Post Yield by Property Manager

This function allows user to post yield by property manager

```python
def post_yield_by_property_manager(self,
                                  property_manager,
                                  body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `property_manager` | `string` | Template, Required | - |
| `body` | [`ChannelMarkUpYield`](../../doc/models/channel-mark-up-yield.md) | Body, Required | - |

## Response Type

[`APIResponseWithoutData`](../../doc/models/api-response-without-data.md)

## Example Usage

```python
property_manager = 'propertyManager4'
body = ChannelMarkUpYield()
body.channel_markup = ChannelMarkUpYieldInfo()
body.channel_markup.begin_date = 'beginDate2'
body.channel_markup.end_date = 'endDate6'
body.channel_markup.amount = 101.56
body.channel_markup.modifier = 'modifier8'
body.channel_markup.channel_abbreviation = 'channelAbbreviation8'

result = yields_controller.post_yield_by_property_manager(property_manager, body)
```

## Example Response *(as JSON)*

```json
{
  "message": "Property with ids [1235124634, 1235124636] will be put in Queue for validation. Please expect response over push message.",
  "errorMessage": [],
  "is_error": false,
  "code": ""
}
```


# Delete YMR List by Property Manager

This function allows the logged in user to get yield management rules list per Property Manager.

```python
def delete_ymr_list_by_property_manager(self,
                                       channel_abbreviation,
                                       party_channel_markup_id,
                                       property_manager)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `channel_abbreviation` | `string` | Query, Required | Channel Abbreviation |
| `party_channel_markup_id` | `string` | Query, Required | Party Channel Markup Id |
| `property_manager` | `string` | Template, Required | - |

## Response Type

[`APIResponseWithoutData`](../../doc/models/api-response-without-data.md)

## Example Usage

```python
channel_abbreviation = 'BKG'
party_channel_markup_id = '1837282'
property_manager = 'propertyManager4'

result = yields_controller.delete_ymr_list_by_property_manager(channel_abbreviation, party_channel_markup_id, property_manager)
```


# Get YMR List by Property Manager

This function allows the logged in user to get yield management rules list per Property Manager.

```python
def get_ymr_list_by_property_manager(self,
                                    property_manager,
                                    channel_abbreviation=None)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `property_manager` | `string` | Template, Required | Property Manager ID |
| `channel_abbreviation` | `string` | Query, Optional | Channel Abbreviation ID |

## Response Type

[`YieldResponseByPropertyManager`](../../doc/models/yield-response-by-property-manager.md)

## Example Usage

```python
property_manager = '1235124634'
channel_abbreviation = 'HAC'

result = yields_controller.get_ymr_list_by_property_manager(property_manager, channel_abbreviation)
```


# Create YMR

This function allows the logged-in user to add yield management rules for the specific product. Yield management rules can affect the final price of the property depending on some special conditions (like the length of stay, early booking, etc.). These rules automate price manipulations, on an inquiry by inquiry basis. When set criteria are met, they help maximize revenue and occupancy.

How is the price calculated?
The price for a night is calculated based on the basic price and the yield management rules.

- If no YMR:
  {basic price per night} = price per night
- If YMR is set it can Increase/decrease percent or increase/decrease amount:
  {basic price per night} + {yield amount} = {price per night}
  or
  {basic price per night} - {yield amount} = {price per night}

The below examples will use the scenario to walk you step by step and explain how the price is calculated based on different YMRs.
Let’s say that the basic price per night for 2016 is 100 USD.

This function is used also for updating yield. So if you already create a specific yield for some date - and you send a new one - we will update the yield for this date.
If you need to delete a specific yield type - you can send an empty list for that type.

Important: The maximum allowed end date is 3 years in the future.

```python
def create_ymr(self,
              body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`CreateYieldRequest`](../../doc/models/create-yield-request.md) | Body, Required | - |

## Response Type

[`YieldResponse`](../../doc/models/yield-response.md)

## Example Usage

```python
body = CreateYieldRequest()
body.data = TransportYield()
body.data.product_id = 192

result = yields_controller.create_ymr(body)
```


# Get YMR List by Product ID

This function allows the logged in user to get yield management rules list of the specific product.

```python
def get_ymr_list_by_product_id(self,
                              product_id)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `product_id` | `string` | Template, Required | ID of the property |

## Response Type

[`YieldResponse`](../../doc/models/yield-response.md)

## Example Usage

```python
product_id = '1235124634'

result = yields_controller.get_ymr_list_by_product_id(product_id)
```

