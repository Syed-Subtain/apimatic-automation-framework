# Licenses

```python
licenses_controller = client.licenses
```

## Class Name

`LicensesController`

## Methods

* [Put License Req](../../doc/controllers/licenses.md#put-license-req)
* [Get License Req](../../doc/controllers/licenses.md#get-license-req)
* [Bdc License Requirements](../../doc/controllers/licenses.md#bdc-license-requirements)


# Put License Req

This function allows system to send license information for a property, so channel can use it.

```python
def put_license_req(self,
                   product_id,
                   body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `product_id` | `string` | Template, Required | Product ID |
| `body` | [`LicenseUpdate`](../../doc/models/license-update.md) | Body, Required | - |

## Response Type

[`LicenseUpdateResponse`](../../doc/models/license-update-response.md)

## Example Usage

```python
product_id = '61692799'
body = LicenseUpdate()
body.data = []

body.data.append(LicenseData())
body.data[0].content_data = []

body.data[0].content_data.append(LicenseDataContent())

body.data[0].variant_id = 'variantId1'

body.data.append(LicenseData())
body.data[1].content_data = []

body.data[1].content_data.append(LicenseDataContent())

body.data[1].content_data.append(LicenseDataContent())

body.data[1].variant_id = 'variantId2'

body.data.append(LicenseData())
body.data[2].content_data = []

body.data[2].content_data.append(LicenseDataContent())

body.data[2].content_data.append(LicenseDataContent())

body.data[2].content_data.append(LicenseDataContent())

body.data[2].variant_id = 'variantId3'


result = licenses_controller.put_license_req(product_id, body)
```


# Get License Req

This function allows system to get licenses information for a property.

```python
def get_license_req(self,
                   product_id)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `product_id` | `string` | Template, Required | Product ID |

## Response Type

[`LicenseGetResponse`](../../doc/models/license-get-response.md)

## Example Usage

```python
product_id = '61692799'

result = licenses_controller.get_license_req(product_id)
```


# Bdc License Requirements

This function will get the BDC License Requirements

```python
def bdc_license_requirements(self,
                            product_id)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `product_id` | `string` | Template, Required | Product ID |

## Response Type

[`LicenseRequirementResponse`](../../doc/models/license-requirement-response.md)

## Example Usage

```python
product_id = '61692799'

result = licenses_controller.bdc_license_requirements(product_id)
```

