# Push Notification

```python
push_notification_controller = client.push_notification
```

## Class Name

`PushNotificationController`

## Methods

* [Push Notification Links](../../doc/controllers/push-notification.md#push-notification-links)
* [Get Notification Links](../../doc/controllers/push-notification.md#get-notification-links)


# Push Notification Links

Provide the links on which the requests about reservation notification will be sent. Links should be https.
These links should be set on PMS level, so please use your PMS credentials.

IMPORTANT: If you set 'reservationLink' value - all reservation push notifications will go on this endpoint (so any new reservation, cancel reservation, update reservation, request to book, request to book cancel). And before you do this - you should implement a new push reservation API call 'General Reservation Notification - PUSH' - since you will get then all reservation notifications over this method.

```python
def push_notification_links(self,
                           body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`PushNotificationLinksRequest`](../../doc/models/push-notification-links-request.md) | Body, Required | - |

## Response Type

[`PushNotificationLinksResponse`](../../doc/models/push-notification-links-response.md)

## Example Usage

```python
body = PushNotificationLinksRequest()
body.data = PushNotificationLinksModel()
body.data.book_link = 'https://newreservationnotification.link'
body.data.cancel_link = 'https://cancelreservation.link'
body.data.async_push = 'https://asyncpush.link'
body.data.request_to_book = 'https://requestToBook.link'
body.data.reservation_link = 'https://reservation.link'

result = push_notification_controller.push_notification_links(body)
```

## Example Response *(as JSON)*

```json
{
  "message": "",
  "errorMessage": [],
  "is_error": false,
  "code": "",
  "data": [
    {
      "bookLink": "https://newreservationnotification.link",
      "cancelLink": "https://cancelreservation.link",
      "asyncPush": "https://asyncpush.link",
      "requestToBook": "https://requestToBook.link"
    }
  ]
}
```


# Get Notification Links

This will return all notification URLs which are set. It will work on PMS level, so use PMS credentials.

```python
def get_notification_links(self)
```

## Response Type

[`PushNotificationLinksResponse`](../../doc/models/push-notification-links-response.md)

## Example Usage

```python
result = push_notification_controller.get_notification_links()
```

## Example Response *(as JSON)*

```json
{
  "message": "",
  "errorMessage": [],
  "is_error": false,
  "code": "",
  "data": [
    {
      "bookLink": "https://newreservationnotification.link",
      "cancelLink": "https://cancelreservation.link",
      "asyncPush": "https://asyncpush.link",
      "requestToBook": "https://requestToBook.link",
      "reservationLink": "https://reservation.link"
    }
  ]
}
```

