# Reservation Notifications

```python
reservation_notifications_controller = client.reservation_notifications
```

## Class Name

`ReservationNotificationsController`

## Methods

* [Get Reservation by Product](../../doc/controllers/reservation-notifications.md#get-reservation-by-product)
* [Get Reservation by Id](../../doc/controllers/reservation-notifications.md#get-reservation-by-id)
* [Get Reservation by PM](../../doc/controllers/reservation-notifications.md#get-reservation-by-pm)
* [General Reservation Notification-PUSH](../../doc/controllers/reservation-notifications.md#general-reservation-notification-push)
* [New Reservation Notification-PUSH](../../doc/controllers/reservation-notifications.md#new-reservation-notification-push)
* [Reservation Cancellation Notification-PUSH](../../doc/controllers/reservation-notifications.md#reservation-cancellation-notification-push)


# Get Reservation by Product

This function allows logged-in users to get all reservations for the specific product.

```python
def get_reservation_by_product(self,
                              product_id)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `product_id` | `string` | Template, Required | Product ID |

## Response Type

[`ReservationGetResponse`](../../doc/models/reservation-get-response.md)

## Example Usage

```python
product_id = '1235124634'

result = reservation_notifications_controller.get_reservation_by_product(product_id)
```


# Get Reservation by Id

This function allows logged-in users to get reservation data by its reservation ID.

```python
def get_reservation_by_id(self,
                         reservation_id)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `reservation_id` | `string` | Template, Required | Reservation ID |

## Response Type

[`ReservationGetResponse`](../../doc/models/reservation-get-response.md)

## Example Usage

```python
reservation_id = '1235124634'

result = reservation_notifications_controller.get_reservation_by_id(reservation_id)
```


# Get Reservation by PM

This API call will return a list of reservations that belong to the current user.

```python
def get_reservation_by_pm(self,
                         page=None,
                         limit=None)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `page` | `float` | Query, Optional | The page number for the query |
| `limit` | `float` | Query, Optional | The limit of records per each page (max 50 records per page) |

## Response Type

[`ReservationGetResponse`](../../doc/models/reservation-get-response.md)

## Example Usage

```python
page = 110.38
limit = 237.24

result = reservation_notifications_controller.get_reservation_by_pm(page, limit)
```


# General Reservation Notification-PUSH

This function sends reservation notification requests to the provided link "reservationLink" in the Push Notification API call.
This is a new API cal added instead of deprecated separate API calls for sending a new reservation request and sending cancel reservation request.

So when BookingPal gets a new reservation, or when some existing reservation is updated or canceled - we will push this POST request to the "reservationLink" link which you set in BookingPal for your PMS (in the Push Notification section).
VERY IMPORTANT: Set "reservationLink" in the Push Notification section only when you implement a new Push function API call. This will be a flag for us that you switched to the new Reservation function.

Important note: In this doc to be able to test this - you need to set a full URL on the Configure button in the right section.

Note: Credit card data will be sent only if PMS should process payment in their system.
Also, data that will be passed to PMS depends on channels - and do we get all of this data. So you should be aware that some data like for example customer address data maybe be mising.
Additional note: Some channels support modification. When you implement this function we will process modification over action type 'UPDATE' and you will get the same reservation ID as you got when the reservation is created, so you will know which reservation should be modified.

```python
def general_reservation_notification_push(self,
                                         body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`GeneralReservationNotificationRequest`](../../doc/models/general-reservation-notification-request.md) | Body, Required | - |

## Response Type

[`ReservationPushResponse`](../../doc/models/reservation-push-response.md)

## Example Usage

```python
body = GeneralReservationNotificationRequest()
body.reservation_notification_request = NewReservationNotificationObject()
body.reservation_notification_request.reservation_id = '107'
body.reservation_notification_request.product_id = '1234816374'
body.reservation_notification_request.supplier_id = '3731837'
body.reservation_notification_request.channel_name = 'Airbnb'
body.reservation_notification_request.confirmation_id = 'dasdasd'
body.reservation_notification_request.unique_key = 'uniqueKey4'
body.reservation_notification_request.new_state = ReservationStateEnum.CANCELLED
body.reservation_notification_request.customer_name = 'John Smith'
body.reservation_notification_request.from_date = dateutil.parser.parse('2016-03-13').date()
body.reservation_notification_request.to_date = dateutil.parser.parse('2016-03-13').date()
body.reservation_notification_request.adult = 2
body.reservation_notification_request.child = 0
body.reservation_notification_request.email = 'andrewtesttest222@gmail.com'
body.reservation_notification_request.total = 105.94
body.action = GeneralReservationNotificationActionTypeEnum.CREATE

result = reservation_notifications_controller.general_reservation_notification_push(body)
```

## Example Response *(as JSON)*

```json
{
  "altId": "45717",
  "is_error": false,
  "code": "",
  "message": "Reservation is processed."
}
```


# New Reservation Notification-PUSH

DEPRECATED. Instead, check General Reservation Notification.

This function sends the request to the provided link about a new reservation. So when BookingPal gets a new reservation - we will push this POST request to the link which you set in BookingPal for your PMS (in Push Notification section).

Important note: In this doc to be able to test this - you need to set a full URL on the Configure button in the right section.

Note: Credit card data will be sent only if PMS should process payment in their system.
Also, data that will be passed to PMS depends on channels - and do we get all of this data. So we have column ‘Mandatory’ to be aware that some data will be missing if we do not get them from a channel (like some guest address data).
Additional note: Some channels support modification. At this moment we will process modification first by canceling the current reservation and then we will process the new regular reservation. In these cases for tracking purposes, you can use channel reservation ID (confirmationID) which should be the same in these cases.

:information_source: **Note** This endpoint does not require authentication.

```python
def new_reservation_notification_push(self,
                                     body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`ReservationNotificationObject`](../../doc/models/reservation-notification-object.md) | Body, Required | - |

## Response Type

[`ReservationPushResponse`](../../doc/models/reservation-push-response.md)

## Example Usage

```python
body = ReservationNotificationObject()
body.reservation_id = '107'
body.product_id = '1234816374'
body.supplier_id = '3731837'
body.channel_name = 'Airbnb'
body.confirmation_id = 'dasdasd'
body.unique_key = 'uniqueKey4'
body.new_state = ReservationStateEnum.CANCELLED
body.customer_name = 'John Smith'
body.from_date = dateutil.parser.parse('2016-03-13').date()
body.to_date = dateutil.parser.parse('2016-03-13').date()
body.adult = 2
body.child = 0
body.email = 'andrewtesttest222@gmail.com'
body.total = 248.34
body.fees = []

body.fees.append(ReservationFeeNotificationModel())
body.fees[0].id = '937-4'
body.fees[0].name = 'Cleaning Fee'
body.fees[0].value = 128.43

body.taxes = []

body.taxes.append(ReservationTaxNotificationModel())
body.taxes[0].id = '22'
body.taxes[0].name = 'State of Florida-Lake County State Tax'
body.taxes[0].value = 34.71

body.commission = ReservationCommissionsNotificationModel()
body.commission.channel_commission = 66.2
body.commission.commission = 135.76
body.rate = ReservationRateNotifcationModel()
body.rate.original_rack_rate = 62.3
body.rate.net_rate = 93.18
body.rate.new_published_rack_rate = 41.54

result = reservation_notifications_controller.new_reservation_notification_push(body)
```

## Example Response *(as JSON)*

```json
{
  "altId": "45717",
  "is_error": false,
  "code": "",
  "message": "Reservation is processed."
}
```


# Reservation Cancellation Notification-PUSH

DEPRECATED. Instead, check General Reservation Notification.

This function sends the request to the provided link about the reservation cancellation. So when BookingPal gets a cancel reservation request from the channel - we will push this POST request to the link which you set in BookingPal for your PMS (in Push Notification section).

Important note: In this doc to be able to test this - you need to set a full URL on the Configure button in the right section.

:information_source: **Note** This endpoint does not require authentication.

```python
def reservation_cancellation_notification_push(self,
                                              body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`CancelReservationNotificationObject`](../../doc/models/cancel-reservation-notification-object.md) | Body, Required | - |

## Response Type

[`ReservationPushResponse`](../../doc/models/reservation-push-response.md)

## Example Usage

```python
body = CancelReservationNotificationObject()
body.reservation_id = '107'
body.product_id = '1234816374'
body.supplier_id = 3731837
body.channel_name = 'TestAndrew'
body.confirmation_id = 'dasdasd'
body.unique_key = 'uniqueKey4'
body.new_state = 'newState8'
body.customer_name = 'John Smith'
body.from_date = dateutil.parser.parse('2016-03-13').date()
body.to_date = dateutil.parser.parse('2016-03-13').date()
body.adult = 2
body.child = 0
body.email = 'andrewtesttest222@gmail.com'
body.total = 248.34

result = reservation_notifications_controller.reservation_cancellation_notification_push(body)
```

## Example Response *(as JSON)*

```json
{
  "altId": "45717",
  "is_error": false,
  "code": "",
  "message": "Cancellation accepted"
}
```

