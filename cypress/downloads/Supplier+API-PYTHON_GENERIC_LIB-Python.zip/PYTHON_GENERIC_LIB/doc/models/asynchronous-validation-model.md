
# Asynchronous Validation Model

Model for Validation messages

## Structure

`AsynchronousValidationModel`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `product_id` | `int` | Required | Id of product in BookingPal |
| `validation_errors` | `string` | Optional | Error message - explanation what are problems if validation failed. |
| `valid` | `bool` | Required | Is product valid |

## Example (as JSON)

```json
{
  "productId": 291356,
  "validationErrors": "noPrice;",
  "valid": false
}
```

