
# Cancellation Policy Type Enum

## Enumeration

`CancellationPolicyTypeEnum`

## Fields

| Name |
|  --- |
| `FULLY_REFUNDABLE` |
| `NON_REFUNDABLE` |
| `MANUAL` |

## Example

```
FULLY_REFUNDABLE
```

