
# Image Tags Enum

## Enumeration

`ImageTagsEnum`

## Fields

| Name | Description |
|  --- | --- |
| `ENUM_1` | Shower |
| `ENUM_2` | Toilet |
| `ENUM_3` | Property building |
| `ENUM_4` | patio |
| `ENUM_5` | Nearby landmark |
| `ENUM_6` | Staff |
| `ENUM_7` | Restaurant/places to eat |
| `ENUM_8` | Communal lounge/ TV room |
| `ENUM_10` | Facade/entrance |
| `ENUM_43` | People |
| `ENUM_11` | Spring |
| `ENUM_13` | Bed |
| `ENUM_14` | Off site |
| `ENUM_37` | Food close-up |
| `ENUM_41` | Day |
| `ENUM_42` | Night |
| `ENUM_50` | Property logo or sign |
| `ENUM_55` | Neighbourhood |
| `ENUM_61` | Natural landscape |
| `ENUM_70` | Activities |
| `ENUM_74` | Bird's eye view |
| `ENUM_81` | Winter |
| `ENUM_82` | Summer |
| `ENUM_87` | BBQ facilities |
| `ENUM_89` | Billiard |
| `ENUM_90` | Bowling |
| `ENUM_94` | Casino |
| `ENUM_95` | Place of worship |
| `ENUM_96` | Children play ground |
| `ENUM_97` | Darts |
| `ENUM_100` | Fishing |
| `ENUM_102` | Game Room |
| `ENUM_103` | Garden |
| `ENUM_104` | Golf course |
| `ENUM_106` | Horse-riding |
| `ENUM_107` | Hot Spring Bath |
| `ENUM_141` | Table tennis |
| `ENUM_108` | Hot Tub |
| `ENUM_112` | Karaoke |
| `ENUM_113` | Library |
| `ENUM_114` | Massage |
| `ENUM_115` | Minigolf |
| `ENUM_116` | Nightclub / DJ |
| `ENUM_124` | Sauna |
| `ENUM_125` | On-site shops |
| `ENUM_128` | Ski School |
| `ENUM_131` | Skiing |
| `ENUM_137` | Squash |
| `ENUM_133` | Snorkeling |
| `ENUM_134` | Solarium |
| `ENUM_143` | Steam room |
| `ENUM_153` | Bathroom |
| `ENUM_154` | TV and multimedia |
| `ENUM_155` | Coffee/tea facilities |
| `ENUM_156` | View (from property/room) |
| `ENUM_157` | Balcony/Terrace |
| `ENUM_158` | Kitchen or kitchenette |
| `ENUM_159` | Living room |
| `ENUM_160` | Lobby or reception |
| `ENUM_161` | Lounge or bar |
| `ENUM_164` | Spa and wellness centre/facili |
| `ENUM_165` | Fitness centre/facilities |
| `ENUM_167` | Food and drinks |
| `ENUM_172` | Other |
| `ENUM_173` | Photo of the whole room |
| `ENUM_177` | Business facilities |
| `ENUM_178` | Banquet/Function facilities |
| `ENUM_179` | Decorative detail |
| `ENUM_182` | Seating area |
| `ENUM_183` | Floor plan |
| `ENUM_184` | Dining area |
| `ENUM_185` | Beach |
| `ENUM_186` | Aqua park |
| `ENUM_187` | Tennis court |
| `ENUM_188` | Windsurfing |
| `ENUM_189` | Canoeing |
| `ENUM_190` | Hiking |
| `ENUM_191` | Cycling |
| `ENUM_192` | Diving |
| `ENUM_193` | Kids's club |
| `ENUM_194` | Evening entertainment |
| `ENUM_197` | Logo/Certificate/Sign |
| `ENUM_198` | Animals |
| `ENUM_199` | Bedroom |
| `ENUM_204` | Communal kitchen |
| `ENUM_205` | Autumn |
| `ENUM_240` | On site |
| `ENUM_241` | Meeting/conference room |
| `ENUM_242` | Food |
| `ENUM_245` | Text overlay |
| `ENUM_246` | Pets |
| `ENUM_247` | Guests |
| `ENUM_248` | City view |
| `ENUM_249` | Garden view |
| `ENUM_250` | Lake view |
| `ENUM_251` | Landmark view |
| `ENUM_252` | Mountain view |
| `ENUM_253` | Pool view |
| `ENUM_254` | River view |
| `ENUM_255` | Sea view |
| `ENUM_256` | Street view |
| `ENUM_257` | Area and facilities |
| `ENUM_258` | Supermarket/grocery shop |
| `ENUM_259` | Shopping Area |
| `ENUM_260` | Swimming pool |
| `ENUM_261` | Sports |
| `ENUM_262` | Entertainment |
| `ENUM_263` | Meals |
| `ENUM_264` | Breakfast |
| `ENUM_265` | Continental breakfast |
| `ENUM_266` | Buffet breakfast |
| `ENUM_267` | Asian breakfast |
| `ENUM_268` | Italian breakfast |
| `ENUM_269` | English/Irish breakfast |
| `ENUM_270` | American breakfast |
| `ENUM_271` | Lunch |
| `ENUM_272` | Dinner |
| `ENUM_273` | Drinks |
| `ENUM_274` | Alcoholic drinks |
| `ENUM_275` | Non alcoholic drinks |
| `ENUM_276` | Seasons |
| `ENUM_277` | Time of day |
| `ENUM_278` | Location |
| `ENUM_279` | Sunrise |
| `ENUM_280` | Sunset |
| `ENUM_281` | children |
| `ENUM_282` | young children |
| `ENUM_283` | older children |
| `ENUM_284` | group of guests |
| `ENUM_285` | cot |
| `ENUM_286` | bunk bed |
| `ENUM_287` | Certificate/Award |
| `ENUM_288` | ADAM |
| `ENUM_289` | Open Air Bath |
| `ENUM_290` | Public Bath |
| `ENUM_291` | Family |

## Example

```
1
```

