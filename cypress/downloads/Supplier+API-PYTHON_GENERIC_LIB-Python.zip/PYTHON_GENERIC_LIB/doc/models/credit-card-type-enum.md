
# Credit Card Type Enum

## Enumeration

`CreditCardTypeEnum`

## Fields

| Name |
|  --- |
| `TRANSMIT` |
| `POST` |

## Example

```
TRANSMIT
```

