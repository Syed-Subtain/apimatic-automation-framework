
# License Requirements Data Object Detail

## Structure

`LicenseRequirementsDataObjectDetail`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `name` | `string` | Optional | name of the property |
| `level` | `string` | Optional | Level of the property for the name above |
| `variants` | [`List of LicenseVariants`](../../doc/models/license-variants.md) | Optional | - |
| `active` | `string` | Optional | active/inactive indicator |
| `id` | `string` | Optional | ID of the requirement. |

## Example (as JSON)

```json
{
  "name": null,
  "level": null,
  "variants": null,
  "active": null,
  "id": null
}
```

