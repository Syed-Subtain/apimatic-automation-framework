
# Asynchronous Push Message Type Enum

## Enumeration

`AsynchronousPushMessageTypeEnum`

## Fields

| Name | Description |
|  --- | --- |
| `BP_VALIDATION` | Validation type - will be sent after validation is done. |

## Example

```
BP_VALIDATION
```

