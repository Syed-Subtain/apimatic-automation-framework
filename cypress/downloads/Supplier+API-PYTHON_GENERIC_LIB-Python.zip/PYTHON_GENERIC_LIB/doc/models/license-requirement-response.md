
# License Requirement Response

## Structure

`LicenseRequirementResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `message` | `string` | Required | text info message |
| `error_message` | `List of string` | Required | List of error messages |
| `is_error` | `bool` | Required | Is error (default = false) |
| `code` | `string` | Required | Code of message |
| `data` | [`List of LicenseReqData`](../../doc/models/license-req-data.md) | Required | License Requirements Data |

## Example (as JSON)

```json
{
  "message": "message0",
  "errorMessage": [
    "errorMessage2",
    "errorMessage3",
    "errorMessage4"
  ],
  "is_error": false,
  "code": "code8",
  "data": [
    {
      "productId": null,
      "licenseRequirementResponse": null
    },
    {
      "productId": null,
      "licenseRequirementResponse": null
    }
  ]
}
```

