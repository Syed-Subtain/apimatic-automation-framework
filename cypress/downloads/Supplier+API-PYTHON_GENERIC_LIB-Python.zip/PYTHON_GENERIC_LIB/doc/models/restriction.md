
# Restriction

## Structure

`Restriction`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `begin_date` | `date` | Required | Beginning date of date range for which restriction is applied. Date should be in format "yyyy-MM-dd" |
| `end_date` | `date` | Required | End date of date range for which restriction is applied. Date should be in format "yyyy-MM-dd" |
| `check_in` | [`CheckIn`](../../doc/models/check-in.md) | Required | - |
| `check_out` | [`CheckOut`](../../doc/models/check-out.md) | Required | - |

## Example (as JSON)

```json
{
  "beginDate": null,
  "endDate": null,
  "checkIn": {
    "monday": false,
    "tuesday": false,
    "wednesday": false,
    "thursday": false,
    "friday": false,
    "saturday": true,
    "sunday": true
  },
  "checkOut": {
    "monday": false,
    "tuesday": false,
    "wednesday": false,
    "thursday": false,
    "friday": false,
    "saturday": true,
    "sunday": true
  }
}
```

