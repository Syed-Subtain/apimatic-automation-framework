
# Type Enum

Cancellation policy type. [FULLY_REFUNDABLE,NON_REFUNDABLE,MANUAL]

## Enumeration

`TypeEnum`

## Fields

| Name |
|  --- |
| `FULLY_REFUNDABLE` |
| `NON_REFUNDABLE` |
| `MANUAL` |

## Example

```
FULLY_REFUNDABLE
```

