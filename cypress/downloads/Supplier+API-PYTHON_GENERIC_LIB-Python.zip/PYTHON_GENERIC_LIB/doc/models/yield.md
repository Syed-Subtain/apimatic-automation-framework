
# Yield

## Structure

`Yield`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `begin_date` | `date` | Required | From date. Date should be in format "yyyy-MM-dd" |
| `end_date` | `date` | Required | To date. Date should be in format "yyyy-MM-dd" |
| `amount` | `float` | Required | Yield amount |
| `modifier` | [`YieldModifierEnum`](../../doc/models/yield-modifier-enum.md) | Required | - |
| `weekend_param` | [`WeekendParamEnum`](../../doc/models/weekend-param-enum.md) | Optional | - |
| `param` | `int` | Optional | Parameter. It can verify depending on what YMR was set. More details about params you can see in the description above. |

## Example (as JSON)

```json
{
  "beginDate": null,
  "endDate": null,
  "amount": null,
  "modifier": "INCREASE_PERCENT"
}
```

