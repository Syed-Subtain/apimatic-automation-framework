
# Key Collection

## Structure

`KeyCollection`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `mtype` | `string` | Required | required string where accepted strings = {"primary"} |
| `check_in_method` | [`KeyCollectionCheckinmethodEnum`](../../doc/models/key-collection-checkinmethod-enum.md) | Required | - |
| `additional_info` | [`KeyCollectionadditionalinformation`](../../doc/models/key-collectionadditionalinformation.md) | Required | - |

## Example (as JSON)

```json
{
  "type": "primary",
  "checkInMethod": "doorman",
  "additionalInfo": {
    "instruction": {
      "how": "how example",
      "when": "when example"
    }
  }
}
```

