
# License Data

## Structure

`LicenseData`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `content_data` | [`List of LicenseDataContent`](../../doc/models/license-data-content.md) | Required | - |
| `variant_id` | `string` | Required | Variant ID |

## Example (as JSON)

```json
{
  "contentData": [
    {
      "name": null,
      "value": null
    },
    {
      "name": null,
      "value": null
    },
    {
      "name": null,
      "value": null
    }
  ],
  "variantId": "variantId0"
}
```

