
# Request to Book Test Request

## Structure

`RequestToBookTestRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `data` | [`FunctionsRequestToBookTest`](../../doc/models/functions-request-to-book-test.md) | Required | - |

## Example (as JSON)

```json
{
  "data": {
    "action": "RESERVATION_REQUEST_VOIDED",
    "productId": 1235124634
  }
}
```

