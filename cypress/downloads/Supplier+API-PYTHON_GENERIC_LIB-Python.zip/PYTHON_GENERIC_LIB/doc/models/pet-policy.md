
# Pet Policy

## Structure

`PetPolicy`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `allowed_pets` | [`AllowedPetsTypeEnum`](../../doc/models/allowed-pets-type-enum.md) | Required | - |
| `charge_pets` | `string` | Optional | Charge parking. Example: “Free”, “$ 100”. |

## Example (as JSON)

```json
{
  "allowedPets": "Allowed",
  "chargePets": "Free"
}
```

