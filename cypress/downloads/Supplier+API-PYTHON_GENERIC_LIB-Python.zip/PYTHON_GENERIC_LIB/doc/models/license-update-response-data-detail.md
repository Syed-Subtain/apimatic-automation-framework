
# License Update Response Data Detail

## Structure

`LicenseUpdateResponseDataDetail`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `meta` | [`List of LicenseRequirementMeta`](../../doc/models/license-requirement-meta.md) | Optional | - |
| `data` | [`List of LicenseResponseIndicatorData`](../../doc/models/license-response-indicator-data.md) | Optional | - |
| `warnings` | `List of string` | Optional | List of warning messages |
| `errors` | `List of string` | Optional | List of error messages |

## Example (as JSON)

```json
{
  "meta": null,
  "data": null,
  "warnings": null,
  "errors": null
}
```

