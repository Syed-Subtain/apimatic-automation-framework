
# Yield Modifier Enum

## Enumeration

`YieldModifierEnum`

## Fields

| Name |
|  --- |
| `INCREASE_PERCENT` |
| `DECREASE_PERCENT` |
| `INCREASE_AMOUNT` |
| `DECREASE_AMOUNT` |

## Example

```
INCREASE_PERCENT
```

