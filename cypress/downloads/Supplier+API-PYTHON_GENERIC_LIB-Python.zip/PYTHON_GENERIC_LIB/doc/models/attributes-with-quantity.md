
# Attributes With Quantity

List of allowed attribute codes and mapping on different channels you can also find on this URL https://developerstesting.channelconnector.com/channel-attributes/

## Structure

`AttributesWithQuantity`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `attribute_id` | [`AmenityTypesEnum`](../../doc/models/amenity-types-enum.md) | Required | - |
| `quantity` | `int` | Required | Will be set to 1 by default |

## Example (as JSON)

```json
{
  "attributeId": "HAC312",
  "quantity": 1
}
```

