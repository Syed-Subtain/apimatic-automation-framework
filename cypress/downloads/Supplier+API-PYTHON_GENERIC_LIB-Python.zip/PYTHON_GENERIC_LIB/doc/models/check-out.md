
# Check Out

## Structure

`CheckOut`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `monday` | `bool` | Required | Determines if check out could be made on monday |
| `tuesday` | `bool` | Required | Determines if check out could be made on tuesday |
| `wednesday` | `bool` | Required | Determines if check out could be made on wednesday |
| `thursday` | `bool` | Required | Determines if check out could be made on thursday |
| `friday` | `bool` | Required | Determines if check out could be made on friday |
| `saturday` | `bool` | Required | Determines if check out could be made on saturday |
| `sunday` | `bool` | Required | Determines if check out could be made on sunday |

## Example (as JSON)

```json
{
  "monday": false,
  "tuesday": false,
  "wednesday": false,
  "thursday": false,
  "friday": false,
  "saturday": true,
  "sunday": true
}
```

