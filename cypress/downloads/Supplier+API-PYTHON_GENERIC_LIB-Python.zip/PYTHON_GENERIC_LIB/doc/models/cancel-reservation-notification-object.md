
# Cancel Reservation Notification Object

## Structure

`CancelReservationNotificationObject`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `reservation_id` | `string` | Required | Id of the reservation in BookingPal |
| `product_id` | `string` | Required | Id of the product in BookingPal |
| `supplier_id` | `int` | Required | Id of the property manager |
| `agent_name` | `string` | Optional | DEPRECATED. Use channelName instead. Agent name/Channel name |
| `channel_name` | `string` | Required | Agent name/Channel name |
| `confirmation_id` | `string` | Required | Channel confirmation code |
| `unique_key` | `string` | Required | Unique code to identify that the request is from BookingPal. This value is unique for every PMS (and it will be different in different environments). |
| `new_state` | `string` | Required | It will always be "Cancelled" in this request |
| `customer_name` | `string` | Required | Guest full name (in format firstName lastName) |
| `from_date` | `date` | Required | Reservation date from. Date is in format "yyyy-MM-dd" |
| `to_date` | `date` | Required | Reservation date to. Date is in format "yyyy-MM-dd" |
| `adult` | `int` | Required | Number of adults |
| `child` | `int` | Required | Number of children |
| `email` | `string` | Required | Guest email |
| `phone` | `string` | Optional | Guest phone |
| `notes` | `string` | Optional | Guest notes |
| `credit_card_type` | `string` | Optional | Credit card type |
| `total` | `float` | Required | Best available rate (This is the total value that guests will pay, including rate, fees, taxes, and all commissions. ) |

## Example (as JSON)

```json
{
  "reservationId": "107",
  "productId": "1234816374",
  "supplierId": 3731837,
  "channelName": "TestAndrew",
  "confirmationId": "dasdasd",
  "uniqueKey": null,
  "newState": null,
  "customerName": "John Smith",
  "fromDate": null,
  "toDate": null,
  "adult": 2,
  "child": 0,
  "email": "andrewtesttest222@gmail.com",
  "total": null
}
```

