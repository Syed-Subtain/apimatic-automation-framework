
# License Get Response Data

## Structure

`LicenseGetResponseData`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `product_id` | `string` | Optional | name of the property |
| `level` | `string` | Optional | Level of the property for the name above |
| `license_information_response` | [`List of LicenseInfoResponse`](../../doc/models/license-info-response.md) | Optional | - |

## Example (as JSON)

```json
{
  "productId": null,
  "level": null,
  "licenseInformationResponse": null
}
```

