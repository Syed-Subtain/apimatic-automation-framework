
# Located Parking Type Enum

## Enumeration

`LocatedParkingTypeEnum`

## Fields

| Name |
|  --- |
| `ONSITE` |
| `NEARBY` |

## Example

```
OnSite
```

