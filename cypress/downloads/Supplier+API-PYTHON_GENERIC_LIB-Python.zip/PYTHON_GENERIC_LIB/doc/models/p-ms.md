
# P Ms

Property Manager model

## Structure

`PMs`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Required | ID of the property manager |
| `name` | `string` | Required | Name of the property manager’s company |
| `extra_name` | `string` | Required | Contact person |
| `email_address` | `string` | Required | Email of the property manager |

## Example (as JSON)

```json
{
  "id": 61690133,
  "name": "Test name",
  "extraName": "Test fullname",
  "emailAddress": "test001@gmail.com"
}
```

