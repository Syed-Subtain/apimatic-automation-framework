
# Image Push Notification

## Structure

`ImagePushNotification`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `success` | `bool` | Required | Processing Image success status |
| `mtype` | [`TypeEnum`](../../doc/models/type-enum.md) | Required | image type |
| `url` | `string` | Required | image URL |
| `version` | `string` | Required | Versoin for processing image |

## Example (as JSON)

```json
{
  "success": null,
  "type": "IMPORT",
  "url": null,
  "version": null
}
```

