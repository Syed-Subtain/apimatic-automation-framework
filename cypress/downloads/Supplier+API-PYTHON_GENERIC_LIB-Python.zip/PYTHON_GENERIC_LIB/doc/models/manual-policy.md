
# Manual Policy

## Structure

`ManualPolicy`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `mtype` | [`ManualPolicyTypeEnum`](../../doc/models/manual-policy-type-enum.md) | Required | - |
| `manual_policies` | [`List of ManualPolicies`](../../doc/models/manual-policies.md) | Required | Model |

## Example (as JSON)

```json
{
  "type": "FLAT",
  "manualPolicies": [
    {
      "chargeValue": 20,
      "beforeDays": 34,
      "cancellationFee": 1
    },
    {
      "chargeValue": 12,
      "beforeDays": 45,
      "cancellationFee": 2
    }
  ]
}
```

