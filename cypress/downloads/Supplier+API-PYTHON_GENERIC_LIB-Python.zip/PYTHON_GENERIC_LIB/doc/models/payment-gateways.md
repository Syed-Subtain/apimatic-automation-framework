
# Payment Gateways

## Structure

`PaymentGateways`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `payment_gateways_type` | [`PaymentGatewaysTypeEnum`](../../doc/models/payment-gateways-type-enum.md) | Required | - |
| `user` | `string` | Optional | Value necessary for accessing payment gateway, values are different per payment gateway: PAYPAL - Client ID AUTHORIZE_NET - User ID BRIDGE_PAY - Username PAY_BOX - Site number DIBS - Login O_GONE - User ID DOC_DATA - ID PAY_GATE - ID  Note: This value will not be returned in response. |
| `secret` | `string` | Optional | Value necessary for accessing payment gateway, values are different per payment gateway: PAYPAL - Secret AUTHORIZE_NET - Transaction Key BRIDGE_PAY - Password  PAY_BOX - Rank number DIBS - Password O_GONE - Password  DOC_DATA - Password PAY_GATE - Password  Note: This value will not be returned in response. |
| `additional_field_1` | `string` | Optional | Additional value necessary for accessing some payment gateways, values are different per payment gateway: BRIDGE_PAY - Merchant Number PAY_BOX - An identifier DIBS - Merchant ID O_GONE - PSP ID  Note: This value will not be returned in response. |
| `additional_field_2` | `string` | Optional | Additional value necessary for accessing some payment gateways, values are different per payment gateway: BRIDGE_PAY - Merchant Number PAY_BOX - An identifier DIBS - Merchant ID O_GONE - PSP ID  Note: This value will not be returned in response. |

## Example (as JSON)

```json
{
  "paymentGatewaysType": "AUTHORIZE_NET",
  "user": "test",
  "secret": "test",
  "additionalField1": "",
  "additionalField2": ""
}
```

