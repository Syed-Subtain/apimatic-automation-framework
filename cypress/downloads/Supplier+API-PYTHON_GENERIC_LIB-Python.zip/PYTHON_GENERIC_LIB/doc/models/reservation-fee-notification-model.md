
# Reservation Fee Notification Model

Model used for fees in reservation push notification

## Structure

`ReservationFeeNotificationModel`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `string` | Optional | Fee altID (alt ID which PMS sent over API) |
| `name` | `string` | Required | Fee name |
| `value` | `float` | Required | Fee value |

## Example (as JSON)

```json
{
  "id": "937-4",
  "name": "Cleaning Fee",
  "value": 110
}
```

