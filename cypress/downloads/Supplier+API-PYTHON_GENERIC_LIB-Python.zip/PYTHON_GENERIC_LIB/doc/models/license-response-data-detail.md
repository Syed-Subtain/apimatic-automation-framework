
# License Response Data Detail

## Structure

`LicenseResponseDataDetail`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `variant_id` | `string` | Optional | Variant ID |
| `content_data` | [`List of LicenseResponseContentData`](../../doc/models/license-response-content-data.md) | Optional | - |

## Example (as JSON)

```json
{
  "variantId": null,
  "contentData": null
}
```

