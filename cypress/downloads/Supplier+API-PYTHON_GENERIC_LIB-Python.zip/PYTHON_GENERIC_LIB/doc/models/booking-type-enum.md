
# Booking Type Enum

Channel booking Type

## Enumeration

`BookingTypeEnum`

## Fields

| Name |
|  --- |
| `INSTANT` |
| `REQUESTTOBOOK` |
| `BOTH` |

## Example

```
Instant
```

