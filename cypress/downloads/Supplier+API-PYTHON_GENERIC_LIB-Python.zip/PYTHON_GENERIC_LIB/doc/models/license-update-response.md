
# License Update Response

## Structure

`LicenseUpdateResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `message` | `string` | Optional | text info message |
| `error_message` | `List of string` | Optional | List of error messages |
| `is_error` | `bool` | Optional | Is error (default = false) |
| `code` | `string` | Optional | Code of message |
| `data` | [`List of LicenseUpdateResponseData`](../../doc/models/license-update-response-data.md) | Optional | License Update Response Data |

## Example (as JSON)

```json
{
  "message": null,
  "errorMessage": null,
  "is_error": null,
  "code": null,
  "data": null
}
```

