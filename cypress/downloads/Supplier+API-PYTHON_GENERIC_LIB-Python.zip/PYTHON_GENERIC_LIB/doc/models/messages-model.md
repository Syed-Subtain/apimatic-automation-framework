
# Messages Model

List of messages Model

## Structure

`MessagesModel`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `messages` | [`List of MessageModel`](../../doc/models/message-model.md) | Required | List of models |

## Example (as JSON)

```json
{
  "messages": [
    {
      "id": 68233,
      "message": "Test message",
      "createdAt": "2019-11-25T12:32:39.000+0000",
      "user": "PROPERTY_MANAGER",
      "channelMessageId": "2221139318748986368"
    }
  ]
}
```

