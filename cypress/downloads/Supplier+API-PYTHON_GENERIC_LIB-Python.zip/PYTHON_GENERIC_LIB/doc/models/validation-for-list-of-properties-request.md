
# Validation for List of Properties Request

## Structure

`ValidationForListOfPropertiesRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `data` | [`ValidationOfPropertyIDsList`](../../doc/models/validation-of-property-i-ds-list.md) | Required | - |

## Example (as JSON)

```json
{
  "data": {
    "productIds": [
      1235124634,
      1235124636
    ]
  }
}
```

