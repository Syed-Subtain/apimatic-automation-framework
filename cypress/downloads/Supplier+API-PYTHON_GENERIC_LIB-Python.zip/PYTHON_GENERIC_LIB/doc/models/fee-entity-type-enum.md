
# Fee Entity Type Enum

## Enumeration

`FeeEntityTypeEnum`

## Fields

| Name |
|  --- |
| `MANDATORY` |
| `OPTIONAL` |
| `MANDATORY_PAL` |

## Example

```
MANDATORY
```

