
# Time Cost Parking Enum

## Enumeration

`TimeCostParkingEnum`

## Fields

| Name |
|  --- |
| `PERHOUR` |
| `PERWEEK` |
| `PERSTAY` |
| `PERDAY` |

## Example

```
PerHour
```

