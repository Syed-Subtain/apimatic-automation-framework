
# LOS Rate

Model for LOS (Length of stay) rates

## Structure

`LOSRate`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `check_in_date` | `date` | Required | Check-in Date. Date should be in format "yyyy-MM-dd" |
| `max_guests` | `int` | Required | Max guests for check in date |
| `los_value` | `List of float` | Required | List rates value per day. First value is for reservation for 1 day. Secoon. If you do not support booking for some specific number of days, set value 0 for that element in array.nd value is for reservation for 2 days, and so on. If you do not support booking for some specific number of days, set value 0 for that element in array. |
| `currency` | `string` | Optional | Currency for rates. It will be visiable only in GET response. You should not set this field in request since we will use product currency for every rate. |

## Example (as JSON)

```json
{
  "checkInDate": "2016-03-13",
  "maxGuests": 104,
  "losValue": [
    218.12
  ],
  "currency": null
}
```

