
# Payment Policy Type Enum

Full or Split payment. In case of Split payment - it will be 2 payments. [SPLIT,FULL]

## Enumeration

`PaymentPolicyTypeEnum`

## Fields

| Name | Description |
|  --- | --- |
| `SPLIT` | Split payment policy |
| `FULL` | Full payment policy |

## Example

```
SPLIT
```

