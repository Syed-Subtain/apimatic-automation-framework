
# Split Payment

## Structure

`SplitPayment`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `deposit_type` | [`DepositTypeEnum`](../../doc/models/deposit-type-enum.md) | Required | First payment deposit type. |
| `value` | `float` | Required | First payment value |
| `second_payment_days` | `int` | Required | Number of days before check-in when second payment is required. |

## Example (as JSON)

```json
{
  "depositType": "FLAT",
  "value": 4,
  "secondPaymentDays": 30
}
```

