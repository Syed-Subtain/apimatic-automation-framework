
# Fee Tax Mandatory Setting

## Structure

`FeeTaxMandatorySetting`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `product_id` | `int` | Required | Product id |
| `is_fee_mandatory` | `bool` | Required | Fee is mandatory |
| `is_tax_mandatory` | `bool` | Required | Tax is mandatory |

## Example (as JSON)

```json
{
  "productId": 1235124634,
  "isFeeMandatory": false,
  "isTaxMandatory": false
}
```

