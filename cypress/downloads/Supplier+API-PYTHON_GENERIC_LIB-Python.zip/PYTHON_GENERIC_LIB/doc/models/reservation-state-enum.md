
# Reservation State Enum

Possible Reservation states

## Enumeration

`ReservationStateEnum`

## Fields

| Name | Description |
|  --- | --- |
| `CANCELLED` | Reservation was cancelled |
| `CONFIRMED` | Reservation processed successfully to the PMS |
| `FULLYPAID` | Reservation processed successfully to the PMS (Channel is MOR) |
| `PROVISIONAL` | Reservation currently in progress |
| `EXCEPTION` | Previously confirmed or fully paid reservation that the HMC no longer has matching closed dates for |
| `FAILED` | Reservation was not successfully processed to the PMS or PMS did not provide confirmation |

## Example

```
Cancelled
```

