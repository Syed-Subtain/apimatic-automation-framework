
# Payment Type Enum

## Enumeration

`PaymentTypeEnum`

## Fields

| Name |
|  --- |
| `CREDIT_CARD` |
| `MAIL_CHECK` |
| `BOOKING_PAL_MOR` |

## Example

```
CREDIT_CARD
```

