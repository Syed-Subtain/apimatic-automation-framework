
# State Enum

Channel State

## Enumeration

`StateEnum`

## Fields

| Name |
|  --- |
| `NOT_VISIBLE` |
| `VISIBLE` |
| `COMING_SOON` |

## Example

```
NOT_VISIBLE
```

