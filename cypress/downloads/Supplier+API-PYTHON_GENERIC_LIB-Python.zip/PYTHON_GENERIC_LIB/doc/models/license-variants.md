
# License Variants

## Structure

`LicenseVariants`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `string` | Optional | ID of the variant |
| `name` | `string` | Optional | name of the variant |
| `content` | [`List of LicenseVariantsContent`](../../doc/models/license-variants-content.md) | Optional | - |

## Example (as JSON)

```json
{
  "id": null,
  "name": null,
  "content": null
}
```

