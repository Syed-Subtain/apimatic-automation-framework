
# Rate

## Structure

`Rate`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `begin_date` | `date` | Required | Beginning date of date range for which rate is applied. Date should be in format "yyyy-MM-dd" |
| `end_date` | `date` | Required | End date of date range for which rate is applied. Date should be in format "yyyy-MM-dd" |
| `amount` | `float` | Required | Value of rate, needs to be higher than 0, otherwise it will not be imported |

## Example (as JSON)

```json
{
  "beginDate": "2016-03-13",
  "endDate": "2016-03-13",
  "amount": 56.78
}
```

