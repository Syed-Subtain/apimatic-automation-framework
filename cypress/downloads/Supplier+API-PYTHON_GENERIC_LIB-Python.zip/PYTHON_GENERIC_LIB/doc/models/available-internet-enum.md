
# Available Internet Enum

## Enumeration

`AvailableInternetEnum`

## Fields

| Name |
|  --- |
| `ALLAREAS` |
| `BUSINESSCENTER` |
| `SOMEROOMS` |

## Example

```
AllAreas
```

