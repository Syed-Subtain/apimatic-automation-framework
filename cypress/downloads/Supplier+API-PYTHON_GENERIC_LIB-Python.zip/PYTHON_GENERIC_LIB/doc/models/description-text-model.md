
# Description Text Model

Model for any kind of description text in Property object

## Structure

`DescriptionTextModel`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `texts` | [`List of Text`](../../doc/models/text.md) | Required | Text value per languages |

## Example (as JSON)

```json
{
  "texts": [
    {
      "language": "EN",
      "value": "Main description on EN!"
    },
    {
      "language": "ES",
      "value": "Main description on ES!"
    }
  ]
}
```

