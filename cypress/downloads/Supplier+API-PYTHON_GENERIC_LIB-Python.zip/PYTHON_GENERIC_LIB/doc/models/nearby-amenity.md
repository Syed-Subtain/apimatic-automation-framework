
# Nearby Amenity

## Structure

`NearbyAmenity`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `attribute_id` | [`NearbyAmenitiesEnum`](../../doc/models/nearby-amenities-enum.md) | Required | List of allowed Nearby Amenities codes |
| `distance` | `int` | Optional | Will be set to 0 by default |

## Example (as JSON)

```json
{
  "attributeId": "ACC203",
  "distance": 3
}
```

