
# License Response Content Data

## Structure

`LicenseResponseContentData`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `name` | `string` | Optional | name of the license |
| `value` | `string` | Optional | value of the license |

## Example (as JSON)

```json
{
  "name": null,
  "value": null
}
```

