
# License Req Data

## Structure

`LicenseReqData`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `product_id` | `string` | Optional | Product ID |
| `license_requirement_response` | [`List of LicenseRequirementResponseObject`](../../doc/models/license-requirement-response-object.md) | Optional | License Requirement Response Object |

## Example (as JSON)

```json
{
  "productId": null,
  "licenseRequirementResponse": null
}
```

