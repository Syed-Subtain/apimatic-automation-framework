
# Reservation Tax Notification Model

Model used for taxes in reservation push notification

## Structure

`ReservationTaxNotificationModel`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `string` | Optional | Tax altID (alt ID which PMS sent over API) |
| `name` | `string` | Required | Tax name |
| `value` | `float` | Required | Tax value |

## Example (as JSON)

```json
{
  "id": "22",
  "name": "State of Florida-Lake County State Tax",
  "value": 5
}
```

