
# Company Address

## Structure

`CompanyAddress`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `country` | `string` | Required | Country of PM. Require 2 letter ISO code |
| `state` | `string` | Required | State (Region) of PM. Required for US properties. |
| `street_address` | `string` | Required | Street address of PM. |
| `city` | `string` | Required | City of PM |
| `zip` | `string` | Required | Zip code (postal code) of PM. |

## Example (as JSON)

```json
{
  "country": "US",
  "state": "Test State",
  "streetAddress": "Test Street",
  "city": "Test City",
  "zip": "13245"
}
```

