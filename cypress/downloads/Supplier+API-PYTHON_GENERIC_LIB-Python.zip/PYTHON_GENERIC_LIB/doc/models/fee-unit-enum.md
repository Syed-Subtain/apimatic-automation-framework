
# Fee Unit Enum

## Enumeration

`FeeUnitEnum`

## Fields

| Name |
|  --- |
| `PER_STAY` |
| `PER_DAY` |
| `PER_PERSON` |
| `PER_DAY_PER_PERSON` |
| `PER_DAY_PER_PERSON_EXTRA` |

## Example

```
PER_STAY
```

