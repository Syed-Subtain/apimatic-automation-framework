
# LOS Rates Response

## Structure

`LOSRatesResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `message` | `string` | Required | text info message |
| `error_message` | `List of string` | Required | List of error messages |
| `is_error` | `bool` | Required | Is error (default = false) |
| `code` | `string` | Required | Code of message |
| `data` | `string` | Optional | List of models |

## Example (as JSON)

```json
{
  "message": "",
  "errorMessage": [],
  "is_error": false,
  "code": "",
  "data": "[{\"productId\":1235124634,\"losRates\":[{\"checkInDate\":\"2020-05-21T00:00:00.000+0000\",\"currency\":\"RSD\",\"maxGuests\":4,\"losValue\":[111,112,123,250,300,350,400,450,500,550,600,650,700,750,800,850,900,950,550,510,570,520,500,510,590,580,560,540,0,0]},{\"checkInDate\":\"2020-06-20T00:00:00.000+0000\",\"currency\":\"RSD\",\"maxGuests\":3,\"losValue\":[100,150,200,250,300,0,0,450,500,550,600,650,700,750,800,850,900,950,550,510,570,520,500,510,590,121,122,123,0,0]}]}]"
}
```

