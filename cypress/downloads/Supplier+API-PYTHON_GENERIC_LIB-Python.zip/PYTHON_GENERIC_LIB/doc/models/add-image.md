
# Add Image

Object for adding images

## Structure

`AddImage`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `url` | `string` | Required | URL of the image. Please send normal URL, like https://example.com/image01.jpg, and do not use some GET parameters in URL, otherwise image might not be imported. |
| `tags` | [`List of ImageTagsEnum`](../../doc/models/image-tags-enum.md) | Optional | Image tag. Tags codes are given in Appendix. |

## Example (as JSON)

```json
{
  "url": "http://aff.bstatic.com/images/hotel/max500/110/11069098.jpg",
  "tags": [
    4,
    5,
    6
  ]
}
```

