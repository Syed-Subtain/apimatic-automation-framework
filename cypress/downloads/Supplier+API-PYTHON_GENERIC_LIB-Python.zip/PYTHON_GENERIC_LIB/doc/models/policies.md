
# Policies

## Structure

`Policies`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `payment_policy` | [`PaymentPolicy`](../../doc/models/payment-policy.md) | Required | - |
| `cancellation_policy` | [`CancellationPolicy`](../../doc/models/cancellation-policy.md) | Required | - |
| `fee_tax_mandatory` | [`FeeTaxMandatory`](../../doc/models/fee-tax-mandatory.md) | Required | - |
| `terms` | `string` | Required | Full URL to PM terms and conditions |
| `check_in_time` | `string` | Required | Time of Check in (HH:MM:SS) |
| `check_out_time` | `string` | Required | Time of Check out (HH:MM:SS) |
| `lead_time` | `int` | Required | Minimum number of days before check-in for which reservation is allowed to be booked. Allowed values are 0-7. |

## Example (as JSON)

```json
{
  "paymentPolicy": {
    "type": "SPLIT",
    "splitPayment": {
      "depositType": "FLAT",
      "value": 4,
      "secondPaymentDays": 30
    }
  },
  "cancellationPolicy": {
    "type": "MANUAL",
    "manualPolicy": {
      "type": "FLAT",
      "manualPolicies": [
        {
          "chargeValue": 20,
          "beforeDays": 34,
          "cancellationFee": 1
        },
        {
          "chargeValue": 12,
          "beforeDays": 45,
          "cancellationFee": 2
        }
      ]
    }
  },
  "feeTaxMandatory": {
    "isFeeMandatory": true,
    "isTaxMandatory": true
  },
  "terms": "www.test.com",
  "checkInTime": "36000",
  "checkOutTime": "57600",
  "leadTime": 2
}
```

