
# Product Image Push Notification

## Structure

`ProductImagePushNotification`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `name` | `string` | Required | name of the object |
| `product_id` | `string` | Required | product id |
| `alt_id` | `string` | Optional | product alternate id |
| `images` | [`List of ImagePushNotification`](../../doc/models/image-push-notification.md) | Required | - |

## Example (as JSON)

```json
{
  "name": null,
  "productId": null,
  "images": {
    "success": null,
    "type": "IMPORT",
    "url": null,
    "version": null
  }
}
```

