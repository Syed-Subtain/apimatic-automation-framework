
# Reservation Notification Object

## Structure

`ReservationNotificationObject`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `reservation_id` | `string` | Required | Id of the reservation in BookingPal |
| `product_id` | `string` | Required | Id of the product in BookingPal |
| `supplier_id` | `string` | Required | Id of the property manager |
| `agent_name` | `string` | Optional | DEPRECATED - use channelName Agent name/Channel name |
| `channel_name` | `string` | Required | Channel name |
| `confirmation_id` | `string` | Required | Channel confirmation code |
| `unique_key` | `string` | Required | Unique code to identify that the request is from BookingPal. This value is unique for every PMS (and it will be different in different environments). |
| `new_state` | [`ReservationStateEnum`](../../doc/models/reservation-state-enum.md) | Required | Possible Reservation states |
| `customer_name` | `string` | Required | Guest full name (in format firstName lastName) |
| `from_date` | `date` | Required | Reservation date from. Date is in format "yyyy-MM-dd" |
| `to_date` | `date` | Required | Reservation date to. Date is in format "yyyy-MM-dd" |
| `adult` | `int` | Required | number of adults |
| `child` | `int` | Required | number of children |
| `address` | `string` | Optional | Guest address |
| `city` | `string` | Optional | Guest city |
| `zip` | `string` | Optional | Guest zip code |
| `country` | `string` | Optional | Guest country |
| `state` | `string` | Optional | Guest state |
| `email` | `string` | Required | Guest email |
| `phone` | `string` | Optional | Guest phone |
| `notes` | `string` | Optional | Guest notes |
| `credit_card_type` | `string` | Optional | Credit card type |
| `credit_card_number` | `string` | Optional | Credit card number |
| `credit_card_expiration_month` | `string` | Optional | Credit card expiration month |
| `credit_card_expiration_year` | `string` | Optional | Credit card expiration yea |
| `credit_card_cid` | `string` | Optional | Credit card cid |
| `total` | `float` | Required | Best available rate (This is the total value that guests will pay, including rate, fees, taxes, and all commissions. ) |
| `fees` | [`List of ReservationFeeNotificationModel`](../../doc/models/reservation-fee-notification-model.md) | Required | List of models |
| `taxes` | [`List of ReservationTaxNotificationModel`](../../doc/models/reservation-tax-notification-model.md) | Required | List of models |
| `commission` | [`ReservationCommissionsNotificationModel`](../../doc/models/reservation-commissions-notification-model.md) | Required | - |
| `rate` | [`ReservationRateNotifcationModel`](../../doc/models/reservation-rate-notifcation-model.md) | Required | - |

## Example (as JSON)

```json
{
  "reservationId": "107",
  "productId": "1234816374",
  "supplierId": "3731837",
  "channelName": "Airbnb",
  "confirmationId": "dasdasd",
  "uniqueKey": null,
  "newState": "Cancelled",
  "customerName": "John Smith",
  "fromDate": null,
  "toDate": null,
  "adult": 2,
  "child": 0,
  "email": "andrewtesttest222@gmail.com",
  "total": null,
  "fees": {
    "id": "937-4",
    "name": "Cleaning Fee",
    "value": 110
  },
  "taxes": {
    "id": "22",
    "name": "State of Florida-Lake County State Tax",
    "value": 5
  },
  "commission": {
    "channelCommission": 10,
    "commission": 12
  },
  "rate": {
    "originalRackRate": 400,
    "netRate": 400,
    "newPublishedRackRate": 422
  }
}
```

