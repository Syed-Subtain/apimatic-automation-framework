
# License Requirement Response Object

## Structure

`LicenseRequirementResponseObject`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `data` | [`List of LicenseRequirementsDataObjectDetail`](../../doc/models/license-requirements-data-object-detail.md) | Optional | - |
| `meta` | [`List of LicenseRequirementMeta`](../../doc/models/license-requirement-meta.md) | Optional | - |
| `warnings` | `List of string` | Optional | List of warning messages |
| `errors` | `List of string` | Optional | List of error messages |

## Example (as JSON)

```json
{
  "data": null,
  "meta": null,
  "warnings": null,
  "errors": null
}
```

