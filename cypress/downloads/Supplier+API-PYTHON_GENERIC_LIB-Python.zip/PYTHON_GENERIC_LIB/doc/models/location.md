
# Location

## Structure

`Location`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `postal_code` | `string` | Required | Postal code of property (Zip code) |
| `country` | `string` | Required | Country of property. Require 2 letter ISO code |
| `region` | `string` | Required | State (Region) of PM. Required for US properties. |
| `city` | `string` | Required | City of property |
| `street` | `string` | Required | Street of property |
| `zip_code_9` | `string` | Required | Set only for US properties (format should be zip5-xxxx) |

## Example (as JSON)

```json
{
  "postalCode": "60606",
  "country": "US",
  "region": "Illinois",
  "city": "Chicago",
  "street": "210 North Wells Street",
  "zipCode9": "60606-1330"
}
```

