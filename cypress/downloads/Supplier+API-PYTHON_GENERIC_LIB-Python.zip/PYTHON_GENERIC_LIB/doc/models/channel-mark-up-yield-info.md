
# Channel Mark up Yield Info

## Structure

`ChannelMarkUpYieldInfo`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `begin_date` | `string` | Required | begin date |
| `end_date` | `string` | Required | end date |
| `amount` | `float` | Required | the amount |
| `modifier` | `string` | Required | modifier |
| `channel_abbreviation` | `string` | Required | channel abbreviation |

## Example (as JSON)

```json
{
  "beginDate": "beginDate6",
  "endDate": "endDate2",
  "amount": 56.78,
  "modifier": "modifier6",
  "channelAbbreviation": "channelAbbreviation6"
}
```

