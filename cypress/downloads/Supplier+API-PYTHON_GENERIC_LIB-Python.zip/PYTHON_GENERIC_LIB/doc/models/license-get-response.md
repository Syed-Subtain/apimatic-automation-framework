
# License Get Response

## Structure

`LicenseGetResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `message` | `string` | Optional | text info message |
| `error_message` | `List of string` | Optional | List of error messages |
| `is_error` | `bool` | Optional | Is error (default = false) |
| `code` | `string` | Optional | Code of message |
| `data` | [`List of LicenseGetResponseData`](../../doc/models/license-get-response-data.md) | Optional | License Information Data |

## Example (as JSON)

```json
{
  "message": null,
  "errorMessage": null,
  "is_error": null,
  "code": null,
  "data": null
}
```

