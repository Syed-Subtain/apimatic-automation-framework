
# Channel Configuration Detail

## Structure

`ChannelConfigurationDetail`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `name` | `string` | Optional | Channel name |
| `abbreviation` | `string` | Optional | Channel abbreviation |
| `logo` | `string` | Optional | Channel logo |
| `state` | [`StateEnum`](../../doc/models/state-enum.md) | Optional | Channel State |
| `support_validation` | `bool` | Optional | Channel support validation |
| `support_create` | `bool` | Optional | Channel support create |
| `support_connect` | `bool` | Optional | Channel support connect |
| `support_open_close` | `bool` | Optional | Channel support open close |
| `support_static_update` | `bool` | Optional | Channel support Static Update |
| `support_dynamic_update` | `bool` | Optional | Channel support Dynamic Update |
| `support_synchronization` | `bool` | Optional | Channel support Synchronization |
| `support_create_channel_account` | `bool` | Optional | Channel support Create Channel Account |
| `support_authorization` | `bool` | Optional | Channel support Authorization |
| `support_cancel_form_pm` | `bool` | Optional | Support cancel Reservation form Property Manager |
| `support_modification_from_pm` | `bool` | Optional | Support modification Reservation from Property Manager |
| `support_gather` | `bool` | Optional | Channel support Gather |
| `support_channel_cancellation_policy` | `bool` | Optional | Channel support Channel Cancellation Policy |
| `booking_type` | [`BookingTypeEnum`](../../doc/models/booking-type-enum.md) | Optional | Channel booking Type |
| `rates_and_availability_mapping` | [`RatesAndAvailabilityMappingEnum`](../../doc/models/rates-and-availability-mapping-enum.md) | Optional | Channel rates And Availability Mapping |
| `accepts_property_type` | [`AcceptsPropertyTypeEnum`](../../doc/models/accepts-property-type-enum.md) | Optional | Channel accepts Property Type |
| `native_property_type` | [`NativePropertyTypeEnum`](../../doc/models/native-property-type-enum.md) | Optional | Channel native Property Type |
| `minimum_properties` | `int` | Optional | Channel minimum Properties |

## Example (as JSON)

```json
{
  "name": null,
  "abbreviation": null,
  "logo": null,
  "state": null,
  "supportValidation": null,
  "supportCreate": null,
  "supportConnect": null,
  "supportOpenClose": null,
  "supportStaticUpdate": null,
  "supportDynamicUpdate": null,
  "supportSynchronization": null,
  "supportCreateChannelAccount": null,
  "supportAuthorization": null,
  "supportCancelFormPm": null,
  "supportModificationFromPm": null,
  "supportGather": null,
  "supportChannelCancellationPolicy": null,
  "bookingType": null,
  "ratesAndAvailabilityMapping": null,
  "acceptsPropertyType": null,
  "nativePropertyType": null,
  "minimumProperties": null
}
```

