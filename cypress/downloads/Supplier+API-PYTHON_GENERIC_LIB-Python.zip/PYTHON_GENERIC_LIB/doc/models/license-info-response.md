
# License Info Response

## Structure

`LicenseInfoResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `data` | [`List of LicenseResponseDataDetail`](../../doc/models/license-response-data-detail.md) | Optional | - |
| `meta` | [`List of LicenseRequirementMeta`](../../doc/models/license-requirement-meta.md) | Optional | - |
| `warnings` | `List of string` | Optional | List of warning messages |
| `errors` | `List of string` | Optional | List of error messages |

## Example (as JSON)

```json
{
  "data": null,
  "meta": null,
  "warnings": null,
  "errors": null
}
```

