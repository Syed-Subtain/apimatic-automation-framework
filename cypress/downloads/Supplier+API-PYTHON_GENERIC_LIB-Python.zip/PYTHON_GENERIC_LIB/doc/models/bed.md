
# Bed

## Structure

`Bed`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `bed_type` | `string` | Required | Bed code BedTypes are given in Appendix. |
| `count` | `int` | Required | Number of bed |

## Example (as JSON)

```json
{
  "bedType": "RMA113",
  "count": 1
}
```

