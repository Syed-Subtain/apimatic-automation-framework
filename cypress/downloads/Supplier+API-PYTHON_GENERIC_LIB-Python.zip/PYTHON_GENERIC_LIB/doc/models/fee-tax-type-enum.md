
# Fee Tax Type Enum

## Enumeration

`FeeTaxTypeEnum`

## Fields

| Name |
|  --- |
| `TAXABLE` |
| `NOT_TAXABLE` |

## Example

```
TAXABLE
```

