
# License Variants Content

## Structure

`LicenseVariantsContent`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `name` | `string` | Optional | name of the variant |
| `data_type` | `string` | Optional | data type of the variant |
| `required` | `string` | Optional | indicator if content is required |

## Example (as JSON)

```json
{
  "name": null,
  "dataType": null,
  "required": null
}
```

