
# Get Message List for Specific Thread Response

## Structure

`GetMessageListForSpecificThreadResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `message` | `string` | Required | Text info message |
| `error_message` | `List of string` | Required | List of error messages |
| `is_error` | `bool` | Required | Is error (default = false) |
| `code` | `string` | Required | Code of message |
| `data` | [`List of MessagesModel`](../../doc/models/messages-model.md) | Required | List of Models |

## Example (as JSON)

```json
{
  "message": "",
  "errorMessage": [],
  "is_error": false,
  "code": "",
  "data": [
    {
      "messages": [
        {
          "id": 12345,
          "message": "Test message",
          "createdAt": "2019-11-25T12:32:39.000+0000",
          "user": "PROPERTY_MANAGER",
          "channelMessageId": "2221139318748986368"
        }
      ]
    }
  ]
}
```

