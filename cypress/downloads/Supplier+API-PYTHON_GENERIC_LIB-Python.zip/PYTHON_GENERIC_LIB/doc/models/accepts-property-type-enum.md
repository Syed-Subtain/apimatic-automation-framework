
# Accepts Property Type Enum

Channel accepts Property Type

## Enumeration

`AcceptsPropertyTypeEnum`

## Fields

| Name |
|  --- |
| `HOMESANDAPARTMENTS` |
| `HOTELS` |
| `BOTH` |

## Example

```
HomesAndApartments
```

