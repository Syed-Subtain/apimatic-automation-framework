
# License Response Indicator Data

## Structure

`LicenseResponseIndicatorData`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `success` | `string` | Optional | success indicator |

## Example (as JSON)

```json
{
  "success": null
}
```

