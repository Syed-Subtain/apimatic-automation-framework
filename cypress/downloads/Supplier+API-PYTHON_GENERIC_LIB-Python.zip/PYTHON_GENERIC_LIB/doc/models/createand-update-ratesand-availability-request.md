
# Createand Update Ratesand Availability Request

## Structure

`CreateandUpdateRatesandAvailabilityRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `data` | [`RatesAvailability`](../../doc/models/rates-availability.md) | Required | Rates Availability model |

## Example (as JSON)

```json
{
  "data": {
    "productId": 184,
    "leadTime": null,
    "rates": null,
    "minStays": null,
    "maxStays": null,
    "restrictions": null,
    "availabilities": null,
    "availableCount": null
  }
}
```

