
# Fee Type Enum

## Enumeration

`FeeTypeEnum`

## Fields

| Name |
|  --- |
| `GENERAL` |
| `PET_FEE` |
| `DEPOSIT` |

## Example

```
GENERAL
```

