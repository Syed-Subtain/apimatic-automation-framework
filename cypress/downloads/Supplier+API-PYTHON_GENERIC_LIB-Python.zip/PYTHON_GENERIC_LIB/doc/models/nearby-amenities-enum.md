
# Nearby Amenities Enum

List of allowed Nearby Amenities codes

## Enumeration

`NearbyAmenitiesEnum`

## Fields

| Name | Description |
|  --- | --- |
| `ACC1` | Airport |
| `ACC203` | Ferry |
| `ACC65` | Shopping |
| `HAC199` | Railway |
| `RST5` | Beach |

## Example

```
ACC1
```

