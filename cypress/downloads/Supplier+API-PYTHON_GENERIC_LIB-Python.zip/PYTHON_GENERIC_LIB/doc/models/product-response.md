
# Product Response

Response for Get, Create or Update product API call

## Structure

`ProductResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `message` | `string` | Required | text info message |
| `error_message` | `List of string` | Required | List of error messages |
| `is_error` | `bool` | Required | Is error (default = false) |
| `code` | `string` | Required | Code of message |
| `data` | [`List of Property`](../../doc/models/property.md) | Required | List of models |

## Example (as JSON)

```json
{
  "message": null,
  "errorMessage": null,
  "is_error": null,
  "code": null,
  "data": {
    "name": null,
    "rooms": null,
    "bathrooms": null,
    "persons": null,
    "propertyType": "PCT101",
    "currency": null,
    "supportedLosRates": null
  }
}
```

