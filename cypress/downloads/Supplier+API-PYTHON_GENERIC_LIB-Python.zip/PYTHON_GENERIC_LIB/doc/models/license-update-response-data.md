
# License Update Response Data

## Structure

`LicenseUpdateResponseData`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `product_id` | `string` | Optional | product ID |
| `response` | [`List of LicenseUpdateResponseDataDetail`](../../doc/models/license-update-response-data-detail.md) | Optional | - |

## Example (as JSON)

```json
{
  "productId": null,
  "response": null
}
```

