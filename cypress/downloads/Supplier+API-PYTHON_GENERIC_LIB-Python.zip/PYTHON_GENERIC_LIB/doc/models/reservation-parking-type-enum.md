
# Reservation Parking Type Enum

## Enumeration

`ReservationParkingTypeEnum`

## Fields

| Name |
|  --- |
| `NORESERVATIONNEEDED` |
| `NOTPOSSIBLE` |
| `RESERVATIONNEEDED` |

## Example

```
NoReservationNeeded
```

