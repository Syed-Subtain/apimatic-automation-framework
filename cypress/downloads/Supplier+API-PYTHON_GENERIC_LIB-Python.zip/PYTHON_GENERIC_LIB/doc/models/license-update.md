
# License Update

## Structure

`LicenseUpdate`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `data` | [`List of LicenseData`](../../doc/models/license-data.md) | Required | - |

## Example (as JSON)

```json
{
  "data": [
    {
      "contentData": [
        {
          "name": null,
          "value": null
        },
        {
          "name": null,
          "value": null
        },
        {
          "name": null,
          "value": null
        }
      ],
      "variantId": "variantId5"
    },
    {
      "contentData": [
        {
          "name": null,
          "value": null
        }
      ],
      "variantId": "variantId6"
    }
  ]
}
```

