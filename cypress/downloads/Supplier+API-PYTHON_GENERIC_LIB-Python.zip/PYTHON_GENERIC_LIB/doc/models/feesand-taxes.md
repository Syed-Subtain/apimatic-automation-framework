
# Feesand Taxes

## Structure

`FeesandTaxes`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `product_id` | `int` | Required | ID of the product |
| `fees` | [`List of Fee`](../../doc/models/fee.md) | Optional | List of models |
| `taxes` | [`List of Taxes`](../../doc/models/taxes.md) | Optional | List of models |

## Example (as JSON)

```json
{
  "productId": 98,
  "fees": null,
  "taxes": null
}
```

