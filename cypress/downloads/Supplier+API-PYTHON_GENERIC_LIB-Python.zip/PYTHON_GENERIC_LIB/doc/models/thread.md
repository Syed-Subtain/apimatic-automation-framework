
# Thread

## Structure

`Thread`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Required | Thread ID |
| `last_message_sent_at` | `string` | Required | Time when last message was sent |
| `last_message_text` | `string` | Required | Last message text |
| `channel_thread_id` | `string` | Optional | Channel thread ID |
| `channel_name` | `string` | Required | Channel from where come reservation |
| `channel_abb` | [`ChannelABBEnum`](../../doc/models/channel-abb-enum.md) | Required | - |
| `guest_name` | `string` | Required | Name of guest |
| `guest_email_address` | `string` | Optional | Email of guest |
| `product_id` | `int` | Required | ID of product in BookingPal database |
| `reservation_id` | `int` | Optional | ID of reservation |
| `date_from` | `date` | Required | Start date of reservation. Date is in format "yyyy-MM-dd" |
| `date_to` | `date` | Required | End date of reservation. Date is in format "yyyy-MM-dd" |

## Example (as JSON)

```json
{
  "id": null,
  "lastMessageSentAt": null,
  "lastMessageText": null,
  "channelName": null,
  "channelABB": "BKG",
  "guestName": null,
  "productId": null,
  "dateFrom": null,
  "dateTo": null
}
```

