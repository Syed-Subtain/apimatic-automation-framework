
# Matching Scores Model

## Structure

`MatchingScoresModel`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `overall` | [`?MatchingScoreModel`](../../doc/models/matching-score-model.md) | Optional | - | getOverall(): ?MatchingScoreModel | setOverall(?MatchingScoreModel overall): void |
| `businessPartner` | [`?MatchingScoreModel`](../../doc/models/matching-score-model.md) | Optional | - | getBusinessPartner(): ?MatchingScoreModel | setBusinessPartner(?MatchingScoreModel businessPartner): void |
| `address` | [`?MatchingScoreModel`](../../doc/models/matching-score-model.md) | Optional | - | getAddress(): ?MatchingScoreModel | setAddress(?MatchingScoreModel address): void |

## Example (as JSON)

```json
{
  "overall": null,
  "businessPartner": null,
  "address": null
}
```

