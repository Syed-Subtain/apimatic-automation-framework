
# Data Matching Definition Create Model

## Structure

`DataMatchingDefinitionCreateModel`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `name` | `string` | Required | Human readable name.<br>**Constraints**: *Maximum Length*: `30` | getName(): string | setName(string name): void |
| `type` | [`string (MatchingTypeEnum)`](../../doc/models/matching-type-enum.md) | Required | - | getType(): string | setType(string type): void |
| `xmlDukeConfiguration` | `string` | Required | Duke XML matching configuration | getXmlDukeConfiguration(): string | setXmlDukeConfiguration(string xmlDukeConfiguration): void |
| `reportConfiguration` | [`?ReportConfigurationModel`](../../doc/models/report-configuration-model.md) | Optional | - | getReportConfiguration(): ?ReportConfigurationModel | setReportConfiguration(?ReportConfigurationModel reportConfiguration): void |
| `goldenRecordConfiguration` | [`?GoldenRecordConfigurationModel`](../../doc/models/golden-record-configuration-model.md) | Optional | - | getGoldenRecordConfiguration(): ?GoldenRecordConfigurationModel | setGoldenRecordConfiguration(?GoldenRecordConfigurationModel goldenRecordConfiguration): void |
| `workspace` | [`?WorkspaceModel`](../../doc/models/workspace-model.md) | Optional | - | getWorkspace(): ?WorkspaceModel | setWorkspace(?WorkspaceModel workspace): void |

## Example (as JSON)

```json
{
  "name": null,
  "type": "DEDUPLICATION",
  "xmlDukeConfiguration": null
}
```

