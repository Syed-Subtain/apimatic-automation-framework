
# Identity Link Create Model

## Structure

`IdentityLinkCreateModel`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `entries` | [`IdentityLinkEntryModel[]`](../../doc/models/identity-link-entry-model.md) | Required | **Constraints**: *Minimum Items*: `2`, *Maximum Items*: `2` | getEntries(): array | setEntries(array entries): void |

## Example (as JSON)

```json
{
  "entries": [
    {
      "storageId": "storageId1",
      "dataSourceId": "dataSourceId9",
      "businessPartnerId": "businessPartnerId1"
    }
  ]
}
```

