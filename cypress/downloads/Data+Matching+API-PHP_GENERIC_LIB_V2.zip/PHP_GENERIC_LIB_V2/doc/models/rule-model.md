
# Rule Model

## Structure

`RuleModel`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `type` | [`?string (RuleTypeEnum)`](../../doc/models/rule-type-enum.md) | Optional | - | getType(): ?string | setType(?string type): void |
| `jsonPath` | `?string` | Optional | - | getJsonPath(): ?string | setJsonPath(?string jsonPath): void |
| `valueType` | [`?string (ValueTypeEnum)`](../../doc/models/value-type-enum.md) | Optional | - | getValueType(): ?string | setValueType(?string valueType): void |
| `expectedValues` | `?(string[])` | Optional | - | getExpectedValues(): ?array | setExpectedValues(?array expectedValues): void |

## Example (as JSON)

```json
{
  "type": null,
  "jsonPath": null,
  "valueType": null,
  "expectedValues": null
}
```

