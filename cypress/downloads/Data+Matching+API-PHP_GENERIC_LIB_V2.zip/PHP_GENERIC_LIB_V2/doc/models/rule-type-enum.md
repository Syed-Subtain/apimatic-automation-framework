
# Rule Type Enum

## Enumeration

`RuleTypeEnum`

## Fields

| Name |
|  --- |
| `HAS_VALUE` |
| `HAS_NOT_VALUE` |
| `HAS_VALUE_IN` |
| `HAS_NOT_VALUE_IN` |
| `HAS_VALUE_LIKE` |
| `HAS_NOT_VALUE_LIKE` |
| `HAS_HIGHEST_VALUE` |
| `HAS_LOWEST_VALUE` |
| `IS_MARKED` |
| `IS_NOT_MARKED` |
| `IS_MOST_COMPLETE` |
| `HAS_HIGHEST_MATCH_SCORE` |

