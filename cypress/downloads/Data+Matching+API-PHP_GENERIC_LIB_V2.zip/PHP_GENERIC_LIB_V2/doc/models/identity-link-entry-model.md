
# Identity Link Entry Model

## Structure

`IdentityLinkEntryModel`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `storageId` | `string` | Required | - | getStorageId(): string | setStorageId(string storageId): void |
| `dataSourceId` | `string` | Required | - | getDataSourceId(): string | setDataSourceId(string dataSourceId): void |
| `businessPartnerId` | `string` | Required | - | getBusinessPartnerId(): string | setBusinessPartnerId(string businessPartnerId): void |

## Example (as JSON)

```json
{
  "storageId": "storageId6",
  "dataSourceId": "dataSourceId6",
  "businessPartnerId": "businessPartnerId6"
}
```

