
# Post Code Model

## Structure

`PostCodeModel`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `value` | `?string` | Optional | - | getValue(): ?string | setValue(?string value): void |
| `type` | [`?PostCodeTypeModel`](../../doc/models/post-code-type-model.md) | Optional | - | getType(): ?PostCodeTypeModel | setType(?PostCodeTypeModel type): void |

## Example (as JSON)

```json
{
  "value": null,
  "type": null
}
```

