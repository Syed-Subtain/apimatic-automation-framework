
# Business Partner Matching Profile Model

## Structure

`BusinessPartnerMatchingProfileModel`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `externalId` | `?string` | Optional | - | getExternalId(): ?string | setExternalId(?string externalId): void |
| `matchingProfile` | [`?MatchingProfileModel`](../../doc/models/matching-profile-model.md) | Optional | - | getMatchingProfile(): ?MatchingProfileModel | setMatchingProfile(?MatchingProfileModel matchingProfile): void |

## Example (as JSON)

```json
{
  "externalId": null,
  "matchingProfile": null
}
```

