
# Identifier Model

## Structure

`IdentifierModel`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `type` | [`?IdentifierTypeModel`](../../doc/models/identifier-type-model.md) | Optional | - | getType(): ?IdentifierTypeModel | setType(?IdentifierTypeModel type): void |
| `value` | `?string` | Optional | - | getValue(): ?string | setValue(?string value): void |
| `issuingBody` | `?string` | Optional | - | getIssuingBody(): ?string | setIssuingBody(?string issuingBody): void |

## Example (as JSON)

```json
{
  "type": null,
  "value": null,
  "issuingBody": null
}
```

