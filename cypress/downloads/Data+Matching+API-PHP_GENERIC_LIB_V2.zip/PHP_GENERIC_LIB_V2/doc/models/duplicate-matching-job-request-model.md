
# Duplicate Matching Job Request Model

## Structure

`DuplicateMatchingJobRequestModel`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `storageId` | `?string` | Optional | - | getStorageId(): ?string | setStorageId(?string storageId): void |
| `countries` | `?(string[])` | Optional | If set, only the records that belong to the countries identified by these short names are processed. By default all records of the storage (means from all countries) are processed (considering other filters). | getCountries(): ?array | setCountries(?array countries): void |
| `dataSourceIds` | `?(string[])` | Optional | If set, only the records that belong to the data sources identified by these IDs are processed. By default all records of the storage (means from all data sources) are processed (considering other filters). | getDataSourceIds(): ?array | setDataSourceIds(?array dataSourceIds): void |
| `dataMatchingDefinitionId` | `?string` | Optional | - | getDataMatchingDefinitionId(): ?string | setDataMatchingDefinitionId(?string dataMatchingDefinitionId): void |
| `decisionLogIds` | `?(string[])` | Optional | If set, feedback from listed Matching Decision Logs will be considered. | getDecisionLogIds(): ?array | setDecisionLogIds(?array decisionLogIds): void |
| `duplicateMatchingReportProperties` | [`?MatchingReportPropertiesModel`](../../doc/models/matching-report-properties-model.md) | Optional | - | getDuplicateMatchingReportProperties(): ?MatchingReportPropertiesModel | setDuplicateMatchingReportProperties(?MatchingReportPropertiesModel duplicateMatchingReportProperties): void |
| `duplicateMatchingDukeProperties` | [`?MatchingDukePropertiesModel`](../../doc/models/matching-duke-properties-model.md) | Optional | - | getDuplicateMatchingDukeProperties(): ?MatchingDukePropertiesModel | setDuplicateMatchingDukeProperties(?MatchingDukePropertiesModel duplicateMatchingDukeProperties): void |

## Example (as JSON)

```json
{
  "storageId": null,
  "countries": null,
  "dataSourceIds": null,
  "dataMatchingDefinitionId": null,
  "decisionLogIds": null,
  "duplicateMatchingReportProperties": null,
  "duplicateMatchingDukeProperties": null
}
```

