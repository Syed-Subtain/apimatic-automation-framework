
# Report Configuration Model

## Structure

`ReportConfigurationModel`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `header` | [`?(ColumnMappingModel[])`](../../doc/models/column-mapping-model.md) | Optional | - | getHeader(): ?array | setHeader(?array header): void |

## Example (as JSON)

```json
{
  "header": null
}
```

