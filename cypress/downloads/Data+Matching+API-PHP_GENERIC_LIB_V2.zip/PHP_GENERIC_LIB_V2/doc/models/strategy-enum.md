
# Strategy Enum

## Enumeration

`StrategyEnum`

## Fields

| Name |
|  --- |
| `SCHEDULE_NEXT_WHEN_FINISHED` |
| `SCHEDULE_NEXT_WHEN_FINISHED_OR_FAILED` |

