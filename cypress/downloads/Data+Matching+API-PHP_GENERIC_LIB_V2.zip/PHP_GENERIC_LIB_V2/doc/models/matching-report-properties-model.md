
# Matching Report Properties Model

## Structure

`MatchingReportPropertiesModel`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `reportType` | [`?string (MatchingReportTypeEnum)`](../../doc/models/matching-report-type-enum.md) | Optional | **Default**: `MatchingReportTypeEnum::EXCEL` | getReportType(): ?string | setReportType(?string reportType): void |
| `includeSingles` | `?bool` | Optional | **Default**: `true` | getIncludeSingles(): ?bool | setIncludeSingles(?bool includeSingles): void |
| `goldenRecords` | `?bool` | Optional | **Default**: `true` | getGoldenRecords(): ?bool | setGoldenRecords(?bool goldenRecords): void |

## Example (as JSON)

```json
{
  "reportType": null,
  "includeSingles": null,
  "goldenRecords": null
}
```

