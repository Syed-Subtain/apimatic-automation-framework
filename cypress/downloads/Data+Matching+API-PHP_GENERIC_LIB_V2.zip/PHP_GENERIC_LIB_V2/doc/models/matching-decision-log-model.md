
# Matching Decision Log Model

## Structure

`MatchingDecisionLogModel`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `id` | `?string` | Optional | - | getId(): ?string | setId(?string id): void |
| `createdAt` | `?string` | Optional | - | getCreatedAt(): ?string | setCreatedAt(?string createdAt): void |
| `name` | `?string` | Optional | - | getName(): ?string | setName(?string name): void |
| `organization` | `?string` | Optional | - | getOrganization(): ?string | setOrganization(?string organization): void |

## Example (as JSON)

```json
{
  "id": null,
  "createdAt": null,
  "name": null,
  "organization": null
}
```

