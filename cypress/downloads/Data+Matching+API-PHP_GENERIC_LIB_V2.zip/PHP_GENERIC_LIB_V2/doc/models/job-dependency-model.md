
# Job Dependency Model

## Structure

`JobDependencyModel`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `id` | `?string` | Optional | - | getId(): ?string | setId(?string id): void |
| `strategy` | [`?string (StrategyEnum)`](../../doc/models/strategy-enum.md) | Optional | **Default**: `StrategyEnum::SCHEDULE_NEXT_WHEN_FINISHED` | getStrategy(): ?string | setStrategy(?string strategy): void |

## Example (as JSON)

```json
{
  "id": null,
  "strategy": null
}
```

