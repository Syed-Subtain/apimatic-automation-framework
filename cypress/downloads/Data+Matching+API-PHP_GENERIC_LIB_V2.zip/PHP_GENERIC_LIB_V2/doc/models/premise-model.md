
# Premise Model

## Structure

`PremiseModel`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `value` | `?string` | Optional | - | getValue(): ?string | setValue(?string value): void |
| `shortName` | `?string` | Optional | - | getShortName(): ?string | setShortName(?string shortName): void |
| `number` | `?string` | Optional | - | getNumber(): ?string | setNumber(?string number): void |
| `type` | [`?PremiseTypeModel`](../../doc/models/premise-type-model.md) | Optional | - | getType(): ?PremiseTypeModel | setType(?PremiseTypeModel type): void |

## Example (as JSON)

```json
{
  "value": null,
  "shortName": null,
  "number": null,
  "type": null
}
```

