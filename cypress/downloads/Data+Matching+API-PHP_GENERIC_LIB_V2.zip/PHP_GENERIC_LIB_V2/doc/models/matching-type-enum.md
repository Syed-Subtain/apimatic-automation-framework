
# Matching Type Enum

## Enumeration

`MatchingTypeEnum`

## Fields

| Name |
|  --- |
| `DEDUPLICATION` |
| `LINKAGE` |

## Example

```
DEDUPLICATION
```

