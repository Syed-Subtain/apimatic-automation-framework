
# Label Model

## Structure

`LabelModel`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `key` | `?string` | Optional | **Constraints**: *Maximum Length*: `63` | getKey(): ?string | setKey(?string key): void |
| `value` | `?string` | Optional | **Constraints**: *Maximum Length*: `63` | getValue(): ?string | setValue(?string value): void |

## Example (as JSON)

```json
{
  "key": null,
  "value": null
}
```

