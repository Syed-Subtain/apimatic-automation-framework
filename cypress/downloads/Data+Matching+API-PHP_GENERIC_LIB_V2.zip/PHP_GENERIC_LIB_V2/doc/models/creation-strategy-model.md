
# Creation Strategy Model

## Structure

`CreationStrategyModel`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `type` | [`string (CreationTypeEnum)`](../../doc/models/creation-type-enum.md) | Required | Defines the way how an attributes should be selected to be added to the golden record. | getType(): string | setType(string type): void |
| `protectedAttributes` | `?(string[])` | Optional | List of attribute of base record that should be kept (e.g. ID, account group, ...) | getProtectedAttributes(): ?array | setProtectedAttributes(?array protectedAttributes): void |
| `recordExclusionRules` | [`?(RuleModel[])`](../../doc/models/rule-model.md) | Optional | List of rules to exclude certain records from golden record creation (e.g. has a deletion flag) | getRecordExclusionRules(): ?array | setRecordExclusionRules(?array recordExclusionRules): void |
| `attributeEnhancementRules` | [`?(EnhancementRuleModel[])`](../../doc/models/enhancement-rule-model.md) | Optional | List of rules to define if and how a certain attribute should be included or removed from the golden record | getAttributeEnhancementRules(): ?array | setAttributeEnhancementRules(?array attributeEnhancementRules): void |

## Example (as JSON)

```json
{
  "type": "JOIN_DISTINCT",
  "protectedAttributes": null,
  "recordExclusionRules": null,
  "attributeEnhancementRules": null
}
```

