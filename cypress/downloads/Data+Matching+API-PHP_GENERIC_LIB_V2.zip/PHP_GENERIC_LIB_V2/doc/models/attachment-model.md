
# Attachment Model

## Structure

`AttachmentModel`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `name` | `?string` | Optional | - | getName(): ?string | setName(?string name): void |
| `type` | `?string` | Optional | - | getType(): ?string | setType(?string type): void |
| `url` | `?string` | Optional | - | getUrl(): ?string | setUrl(?string url): void |
| `tags` | `?(string[])` | Optional | - | getTags(): ?array | setTags(?array tags): void |

## Example (as JSON)

```json
{
  "name": null,
  "type": null,
  "url": null,
  "tags": null
}
```

