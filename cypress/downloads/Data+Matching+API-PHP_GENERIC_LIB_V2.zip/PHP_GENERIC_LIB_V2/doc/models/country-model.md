
# Country Model

Country consisting of the country name and country code (ISO 3166-1 alpha-2).

## Structure

`CountryModel`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `shortName` | `?string` | Optional | Country code (ISO 3166-1 alpha-2). | getShortName(): ?string | setShortName(?string shortName): void |
| `value` | `?string` | Optional | Country name (ISO 3166-1 alpha-2) | getValue(): ?string | setValue(?string value): void |

## Example (as JSON)

```json
{
  "shortName": null,
  "value": null
}
```

