
# Linkage Matching Report Type Enum

## Enumeration

`LinkageMatchingReportTypeEnum`

## Fields

| Name |
|  --- |
| `EXCEL` |
| `JOB_RESULTS` |

