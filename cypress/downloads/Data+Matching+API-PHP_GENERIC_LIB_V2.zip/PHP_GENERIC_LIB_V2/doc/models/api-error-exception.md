
# Api Error Exception

## Structure

`ApiErrorException`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `status` | `?int` | Optional | - | getStatus(): ?int | setStatus(?int status): void |
| `path` | `?string` | Optional | - | getPath(): ?string | setPath(?string path): void |
| `timestamp` | `?string` | Optional | - | getTimestamp(): ?string | setTimestamp(?string timestamp): void |
| `error` | `?string` | Optional | - | getError(): ?string | setError(?string error): void |
| `message` | `?string` | Optional | - | getMessage(): ?string | setMessage(?string message): void |

## Example (as JSON)

```json
{
  "status": null,
  "path": null,
  "timestamp": null,
  "error": null,
  "message": null
}
```

