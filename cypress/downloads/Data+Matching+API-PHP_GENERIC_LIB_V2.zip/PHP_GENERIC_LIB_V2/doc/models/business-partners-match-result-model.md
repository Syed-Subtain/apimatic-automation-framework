
# Business Partners Match Result Model

## Structure

`BusinessPartnersMatchResultModel`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `matchingProfiles` | [`?(BusinessPartnerMatchingProfileModel[])`](../../doc/models/business-partner-matching-profile-model.md) | Optional | - | getMatchingProfiles(): ?array | setMatchingProfiles(?array matchingProfiles): void |

## Example (as JSON)

```json
{
  "matchingProfiles": null
}
```

