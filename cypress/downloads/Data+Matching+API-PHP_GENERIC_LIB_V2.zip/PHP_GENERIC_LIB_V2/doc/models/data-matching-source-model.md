
# Data Matching Source Model

## Structure

`DataMatchingSourceModel`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `storageId` | `string` | Required | The ID of the storage that should used for matching. | getStorageId(): string | setStorageId(string storageId): void |
| `dataSourceIds` | `?(string[])` | Optional | Optional list of DataSource IDs of the storage (identified by the storageId) that should used for matching. | getDataSourceIds(): ?array | setDataSourceIds(?array dataSourceIds): void |

## Example (as JSON)

```json
{
  "storageId": "storageId6",
  "dataSourceIds": null
}
```

