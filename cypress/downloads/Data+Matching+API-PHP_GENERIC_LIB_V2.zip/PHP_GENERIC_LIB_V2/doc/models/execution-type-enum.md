
# Execution Type Enum

Defines options on how an attribute should be handled. SET means the already existing one is overwritten, ENRICH means that the new value is only added to the golden record in case it does not have any value yet and REMOVE will just delete the existing value from the golden record.

## Enumeration

`ExecutionTypeEnum`

## Fields

| Name |
|  --- |
| `SET` |
| `ENRICH` |
| `REMOVE` |

