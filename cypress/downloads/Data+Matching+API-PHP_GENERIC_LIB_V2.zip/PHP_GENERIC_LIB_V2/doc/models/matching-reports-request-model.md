
# Matching Reports Request Model

## Structure

`MatchingReportsRequestModel`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `matchingJobId` | `?string` | Optional | - | getMatchingJobId(): ?string | setMatchingJobId(?string matchingJobId): void |
| `reportsConfiguration` | [`?MatchingReportsConfigurationModel`](../../doc/models/matching-reports-configuration-model.md) | Optional | - | getReportsConfiguration(): ?MatchingReportsConfigurationModel | setReportsConfiguration(?MatchingReportsConfigurationModel reportsConfiguration): void |

## Example (as JSON)

```json
{
  "matchingJobId": null,
  "reportsConfiguration": null
}
```

