
# Address Model

## Structure

`AddressModel`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `externalId` | `?string` | Optional | - | getExternalId(): ?string | setExternalId(?string externalId): void |
| `country` | [`?CountryModel`](../../doc/models/country-model.md) | Optional | Country consisting of the country name and country code (ISO 3166-1 alpha-2). | getCountry(): ?CountryModel | setCountry(?CountryModel country): void |
| `administrativeAreas` | [`?(AdministrativeAreaModel[])`](../../doc/models/administrative-area-model.md) | Optional | - | getAdministrativeAreas(): ?array | setAdministrativeAreas(?array administrativeAreas): void |
| `postCode` | [`?PostCodeModel`](../../doc/models/post-code-model.md) | Optional | - | getPostCode(): ?PostCodeModel | setPostCode(?PostCodeModel postCode): void |
| `localities` | [`?(LocalityModel[])`](../../doc/models/locality-model.md) | Optional | - | getLocalities(): ?array | setLocalities(?array localities): void |
| `thoroughfares` | [`?(ThoroughfareModel[])`](../../doc/models/thoroughfare-model.md) | Optional | - | getThoroughfares(): ?array | setThoroughfares(?array thoroughfares): void |
| `premises` | [`?(PremiseModel[])`](../../doc/models/premise-model.md) | Optional | - | getPremises(): ?array | setPremises(?array premises): void |
| `postalDeliveryPoint` | [`?PostalDeliveryPointModel`](../../doc/models/postal-delivery-point-model.md) | Optional | - | getPostalDeliveryPoint(): ?PostalDeliveryPointModel | setPostalDeliveryPoint(?PostalDeliveryPointModel postalDeliveryPoint): void |

## Example (as JSON)

```json
{
  "externalId": null,
  "country": null,
  "administrativeAreas": null,
  "postCode": null,
  "localities": null,
  "thoroughfares": null,
  "premises": null,
  "postalDeliveryPoint": null
}
```

