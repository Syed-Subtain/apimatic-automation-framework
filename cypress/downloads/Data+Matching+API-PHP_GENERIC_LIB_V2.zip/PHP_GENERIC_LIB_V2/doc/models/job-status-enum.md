
# Job Status Enum

Curation Job execution status.

## Enumeration

`JobStatusEnum`

## Fields

| Name |
|  --- |
| `UNKNOWN` |
| `CREATED` |
| `PERSISTED` |
| `SCHEDULED` |
| `WAITING` |
| `COULDNT_START` |
| `RUNNING` |
| `FINISHED` |
| `DIED` |
| `CANCELED` |
| `FAILED` |

## Example

```
RUNNING
```

