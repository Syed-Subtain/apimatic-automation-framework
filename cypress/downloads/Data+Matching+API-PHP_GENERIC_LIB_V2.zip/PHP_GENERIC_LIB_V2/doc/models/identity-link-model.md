
# Identity Link Model

## Structure

`IdentityLinkModel`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `id` | `?string` | Optional | - | getId(): ?string | setId(?string id): void |
| `decisionLogId` | `?string` | Optional | - | getDecisionLogId(): ?string | setDecisionLogId(?string decisionLogId): void |
| `createdAt` | `?string` | Optional | - | getCreatedAt(): ?string | setCreatedAt(?string createdAt): void |
| `createdBy` | `?string` | Optional | - | getCreatedBy(): ?string | setCreatedBy(?string createdBy): void |
| `linkStatus` | `?string` | Optional | - | getLinkStatus(): ?string | setLinkStatus(?string linkStatus): void |
| `linkKind` | `?string` | Optional | - | getLinkKind(): ?string | setLinkKind(?string linkKind): void |
| `entityA` | [`?IdentityLinkEntryModel`](../../doc/models/identity-link-entry-model.md) | Optional | - | getEntityA(): ?IdentityLinkEntryModel | setEntityA(?IdentityLinkEntryModel entityA): void |
| `entityB` | [`?IdentityLinkEntryModel`](../../doc/models/identity-link-entry-model.md) | Optional | - | getEntityB(): ?IdentityLinkEntryModel | setEntityB(?IdentityLinkEntryModel entityB): void |

## Example (as JSON)

```json
{
  "id": null,
  "decisionLogId": null,
  "createdAt": null,
  "createdBy": null,
  "linkStatus": null,
  "linkKind": null,
  "entityA": null,
  "entityB": null
}
```

