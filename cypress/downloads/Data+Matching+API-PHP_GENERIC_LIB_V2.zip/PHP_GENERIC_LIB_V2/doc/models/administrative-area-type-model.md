
# Administrative Area Type Model

## Structure

`AdministrativeAreaTypeModel`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `name` | `?string` | Optional | - | getName(): ?string | setName(?string name): void |
| `url` | `?string` | Optional | - | getUrl(): ?string | setUrl(?string url): void |
| `technicalKey` | `?string` | Optional | - | getTechnicalKey(): ?string | setTechnicalKey(?string technicalKey): void |

## Example (as JSON)

```json
{
  "name": null,
  "url": null,
  "technicalKey": null
}
```

