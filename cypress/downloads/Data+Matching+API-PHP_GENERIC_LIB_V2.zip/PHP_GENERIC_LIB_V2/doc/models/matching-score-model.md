
# Matching Score Model

## Structure

`MatchingScoreModel`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `classification` | [`?MatchingClassificationModel`](../../doc/models/matching-classification-model.md) | Optional | - | getClassification(): ?MatchingClassificationModel | setClassification(?MatchingClassificationModel classification): void |
| `value` | `?float` | Optional | - | getValue(): ?float | setValue(?float value): void |
| `explanation` | `?string` | Optional | - | getExplanation(): ?string | setExplanation(?string explanation): void |

## Example (as JSON)

```json
{
  "classification": null,
  "value": null,
  "explanation": null
}
```

