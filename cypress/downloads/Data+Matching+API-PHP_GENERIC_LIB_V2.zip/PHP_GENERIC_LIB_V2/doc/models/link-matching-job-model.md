
# Link Matching Job Model

## Structure

`LinkMatchingJobModel`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `id` | `?string` | Optional | - | getId(): ?string | setId(?string id): void |
| `patternSources` | [`?(DataMatchingSourceModel[])`](../../doc/models/data-matching-source-model.md) | Optional | **Constraints**: *Minimum Items*: `1` | getPatternSources(): ?array | setPatternSources(?array patternSources): void |
| `matchSources` | [`?(DataMatchingSourceModel[])`](../../doc/models/data-matching-source-model.md) | Optional | **Constraints**: *Minimum Items*: `1` | getMatchSources(): ?array | setMatchSources(?array matchSources): void |
| `countryShortNames` | `?(string[])` | Optional | - | getCountryShortNames(): ?array | setCountryShortNames(?array countryShortNames): void |
| `dataMatchingDefinitionId` | `?string` | Optional | - | getDataMatchingDefinitionId(): ?string | setDataMatchingDefinitionId(?string dataMatchingDefinitionId): void |
| `decisionLogIds` | `?(string[])` | Optional | - | getDecisionLogIds(): ?array | setDecisionLogIds(?array decisionLogIds): void |
| `createdAt` | `?string` | Optional | - | getCreatedAt(): ?string | setCreatedAt(?string createdAt): void |
| `createdBy` | `?string` | Optional | User that started the job. | getCreatedBy(): ?string | setCreatedBy(?string createdBy): void |
| `status` | [`?string (JobStatusEnum)`](../../doc/models/job-status-enum.md) | Optional | Curation Job execution status. | getStatus(): ?string | setStatus(?string status): void |
| `progress` | `?int` | Optional | - | getProgress(): ?int | setProgress(?int progress): void |

## Example (as JSON)

```json
{
  "id": null,
  "patternSources": null,
  "matchSources": null,
  "countryShortNames": null,
  "dataMatchingDefinitionId": null,
  "decisionLogIds": null,
  "createdAt": null,
  "createdBy": null,
  "status": null,
  "progress": null
}
```

