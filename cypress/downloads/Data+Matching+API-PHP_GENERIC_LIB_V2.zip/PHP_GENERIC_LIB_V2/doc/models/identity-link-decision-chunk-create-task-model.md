
# Identity Link Decision Chunk Create Task Model

## Structure

`IdentityLinkDecisionChunkCreateTaskModel`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `correlationId` | `?string` | Optional | ID which uniquely chains a set of request()s and or task(s) | getCorrelationId(): ?string | setCorrelationId(?string correlationId): void |
| `userId` | `?string` | Optional | Unique ID of a user | getUserId(): ?string | setUserId(?string userId): void |
| `request` | [`?IdentityLinkDecisionCreateWorkerRequestModel`](../../doc/models/identity-link-decision-create-worker-request-model.md) | Optional | - | getRequest(): ?IdentityLinkDecisionCreateWorkerRequestModel | setRequest(?IdentityLinkDecisionCreateWorkerRequestModel request): void |
| `replyQueue` | `?string` | Optional | Technical descriptor of reply queue where workers should put back the result | getReplyQueue(): ?string | setReplyQueue(?string replyQueue): void |

## Example (as JSON)

```json
{
  "correlationId": null,
  "userId": null,
  "request": null,
  "replyQueue": null
}
```

