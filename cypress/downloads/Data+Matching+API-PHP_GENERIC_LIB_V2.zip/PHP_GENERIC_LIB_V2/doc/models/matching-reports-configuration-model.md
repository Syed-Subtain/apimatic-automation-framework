
# Matching Reports Configuration Model

## Structure

`MatchingReportsConfigurationModel`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `duplicateMatching` | [`?DuplicateMatchingReportConfigurationModel`](../../doc/models/duplicate-matching-report-configuration-model.md) | Optional | Generates a data matching report that doesn't include artificial golden records on top of each matching group. Optionally IncludeSingles feature can be set to true. | getDuplicateMatching(): ?DuplicateMatchingReportConfigurationModel | setDuplicateMatching(?DuplicateMatchingReportConfigurationModel duplicateMatching): void |
| `duplicateConsolidation` | [`?DuplicateConsolidationReportConfigurationModel`](../../doc/models/duplicate-consolidation-report-configuration-model.md) | Optional | Generates a data matching report that includes artificial golden records on top of each matching group. Optionally IncludeSingles feature can be set to true. | getDuplicateConsolidation(): ?DuplicateConsolidationReportConfigurationModel | setDuplicateConsolidation(?DuplicateConsolidationReportConfigurationModel duplicateConsolidation): void |
| `linkage` | [`?LinkageReportConfigurationModel`](../../doc/models/linkage-report-configuration-model.md) | Optional | Generates a linkage report. Optionally IncludeSingles feature can be set to true. | getLinkage(): ?LinkageReportConfigurationModel | setLinkage(?LinkageReportConfigurationModel linkage): void |

## Example (as JSON)

```json
{
  "duplicateMatching": null,
  "duplicateConsolidation": null,
  "linkage": null
}
```

