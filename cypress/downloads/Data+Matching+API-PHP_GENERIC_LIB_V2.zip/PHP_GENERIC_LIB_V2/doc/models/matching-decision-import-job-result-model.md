
# Matching Decision Import Job Result Model

## Structure

`MatchingDecisionImportJobResultModel`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `statistics` | [`?MatchingDecisionImportJobStatisticsModel`](../../doc/models/matching-decision-import-job-statistics-model.md) | Optional | - | getStatistics(): ?MatchingDecisionImportJobStatisticsModel | setStatistics(?MatchingDecisionImportJobStatisticsModel statistics): void |

## Example (as JSON)

```json
{
  "statistics": null
}
```

