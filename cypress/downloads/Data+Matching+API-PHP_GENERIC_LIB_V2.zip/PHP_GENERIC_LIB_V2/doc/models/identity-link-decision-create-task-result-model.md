
# Identity Link Decision Create Task Result Model

## Structure

`IdentityLinkDecisionCreateTaskResultModel`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `worker` | `?string` | Optional | Worker which generated the result | getWorker(): ?string | setWorker(?string worker): void |
| `status` | `?string` | Optional | status:<br><br>* `OK` - Task has been processed succesful<br>* `FAILED` - Task has been failed | getStatus(): ?string | setStatus(?string status): void |
| `message` | `?string` | Optional | Details task status | getMessage(): ?string | setMessage(?string message): void |
| `result` | [`?IdentityLinkDecisionCreateResultModel`](../../doc/models/identity-link-decision-create-result-model.md) | Optional | - | getResult(): ?IdentityLinkDecisionCreateResultModel | setResult(?IdentityLinkDecisionCreateResultModel result): void |

## Example (as JSON)

```json
{
  "worker": null,
  "status": null,
  "message": null,
  "result": null
}
```

