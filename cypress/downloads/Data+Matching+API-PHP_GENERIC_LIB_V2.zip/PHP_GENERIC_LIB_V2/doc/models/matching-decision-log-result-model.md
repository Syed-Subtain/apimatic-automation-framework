
# Matching Decision Log Result Model

## Structure

`MatchingDecisionLogResultModel`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `matchingDecisionLog` | [`?MatchingDecisionLogModel`](../../doc/models/matching-decision-log-model.md) | Optional | - | getMatchingDecisionLog(): ?MatchingDecisionLogModel | setMatchingDecisionLog(?MatchingDecisionLogModel matchingDecisionLog): void |
| `status` | `?string` | Optional | status:<br><br>* `OK` - Decision log has been fetched successfully<br>* `NOT_FOUND` - Decision log does not exist | getStatus(): ?string | setStatus(?string status): void |
| `message` | `?string` | Optional | - | getMessage(): ?string | setMessage(?string message): void |

## Example (as JSON)

```json
{
  "matchingDecisionLog": null,
  "status": null,
  "message": null
}
```

