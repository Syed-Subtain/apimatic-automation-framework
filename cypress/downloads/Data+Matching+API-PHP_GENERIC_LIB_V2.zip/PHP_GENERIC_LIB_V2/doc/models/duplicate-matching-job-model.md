
# Duplicate Matching Job Model

## Structure

`DuplicateMatchingJobModel`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `id` | `?string` | Optional | - | getId(): ?string | setId(?string id): void |
| `storageId` | `?string` | Optional | - | getStorageId(): ?string | setStorageId(?string storageId): void |
| `dataMatchingDefinitionId` | `?string` | Optional | - | getDataMatchingDefinitionId(): ?string | setDataMatchingDefinitionId(?string dataMatchingDefinitionId): void |
| `dataSourceIds` | `?(string[])` | Optional | - | getDataSourceIds(): ?array | setDataSourceIds(?array dataSourceIds): void |
| `decisionLogIds` | `?(string[])` | Optional | - | getDecisionLogIds(): ?array | setDecisionLogIds(?array decisionLogIds): void |
| `countryShortNames` | `?(string[])` | Optional | - | getCountryShortNames(): ?array | setCountryShortNames(?array countryShortNames): void |
| `createdAt` | `?string` | Optional | - | getCreatedAt(): ?string | setCreatedAt(?string createdAt): void |
| `createdBy` | `?string` | Optional | User that started the job. | getCreatedBy(): ?string | setCreatedBy(?string createdBy): void |
| `status` | [`?string (JobStatusEnum)`](../../doc/models/job-status-enum.md) | Optional | Curation Job execution status. | getStatus(): ?string | setStatus(?string status): void |
| `progress` | `?int` | Optional | - | getProgress(): ?int | setProgress(?int progress): void |

## Example (as JSON)

```json
{
  "id": null,
  "storageId": null,
  "dataMatchingDefinitionId": null,
  "dataSourceIds": null,
  "decisionLogIds": null,
  "countryShortNames": null,
  "createdAt": null,
  "createdBy": null,
  "status": null,
  "progress": null
}
```

