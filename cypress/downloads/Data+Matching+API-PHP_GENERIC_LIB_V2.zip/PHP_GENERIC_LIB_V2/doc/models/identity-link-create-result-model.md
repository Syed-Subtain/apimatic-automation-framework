
# Identity Link Create Result Model

## Structure

`IdentityLinkCreateResultModel`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `values` | [`?(IdentityLinkCreateStatusModel[])`](../../doc/models/identity-link-create-status-model.md) | Optional | - | getValues(): ?array | setValues(?array values): void |

## Example (as JSON)

```json
{
  "values": null
}
```

