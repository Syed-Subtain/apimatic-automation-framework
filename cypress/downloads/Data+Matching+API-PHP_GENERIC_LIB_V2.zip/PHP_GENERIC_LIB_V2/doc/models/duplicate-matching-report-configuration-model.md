
# Duplicate Matching Report Configuration Model

Generates a data matching report that doesn't include artificial golden records on top of each matching group. Optionally IncludeSingles feature can be set to true.

## Structure

`DuplicateMatchingReportConfigurationModel`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `build` | `?bool` | Optional | Enable to generate this report<br>**Default**: `false` | getBuild(): ?bool | setBuild(?bool build): void |
| `includeSingles` | `?bool` | Optional | **Default**: `false` | getIncludeSingles(): ?bool | setIncludeSingles(?bool includeSingles): void |

## Example (as JSON)

```json
{
  "build": null,
  "includeSingles": null
}
```

