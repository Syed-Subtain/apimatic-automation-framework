
# Decision Node Model

## Structure

`DecisionNodeModel`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `rule` | [`?RuleModel`](../../doc/models/rule-model.md) | Optional | - | getRule(): ?RuleModel | setRule(?RuleModel rule): void |
| `yesBranch` | [`?DecisionNodeModel`](../../doc/models/decision-node-model.md) | Optional | - | getYesBranch(): ?DecisionNodeModel | setYesBranch(?DecisionNodeModel yesBranch): void |
| `noBranch` | [`?DecisionNodeModel`](../../doc/models/decision-node-model.md) | Optional | - | getNoBranch(): ?DecisionNodeModel | setNoBranch(?DecisionNodeModel noBranch): void |

## Example (as JSON)

```json
{
  "rule": null,
  "yesBranch": null,
  "noBranch": null
}
```

