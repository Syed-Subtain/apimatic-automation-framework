
# Postal Delivery Point Model

## Structure

`PostalDeliveryPointModel`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `type` | [`?PostalDeliveryPointTypeModel`](../../doc/models/postal-delivery-point-type-model.md) | Optional | - | getType(): ?PostalDeliveryPointTypeModel | setType(?PostalDeliveryPointTypeModel type): void |
| `shortName` | `?string` | Optional | - | getShortName(): ?string | setShortName(?string shortName): void |
| `number` | `?string` | Optional | - | getNumber(): ?string | setNumber(?string number): void |
| `value` | `?string` | Optional | - | getValue(): ?string | setValue(?string value): void |

## Example (as JSON)

```json
{
  "type": null,
  "shortName": null,
  "number": null,
  "value": null
}
```

