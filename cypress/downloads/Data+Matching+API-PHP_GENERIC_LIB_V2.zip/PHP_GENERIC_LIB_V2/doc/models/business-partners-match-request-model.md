
# Business Partners Match Request Model

## Structure

`BusinessPartnersMatchRequestModel`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `candidates` | [`BusinessPartnerModel[]`](../../doc/models/business-partner-model.md) | Required | **Constraints**: *Minimum Items*: `1`, *Maximum Items*: `1000` | getCandidates(): array | setCandidates(array candidates): void |
| `pattern` | [`BusinessPartnerModel`](../../doc/models/business-partner-model.md) | Required | - | getPattern(): BusinessPartnerModel | setPattern(BusinessPartnerModel pattern): void |
| `dataMatchingDefinitionId` | `?string` | Optional | - | getDataMatchingDefinitionId(): ?string | setDataMatchingDefinitionId(?string dataMatchingDefinitionId): void |

## Example (as JSON)

```json
{
  "candidates": [
    {
      "id": null,
      "names": null,
      "legalForm": null,
      "identifiers": null,
      "address": null,
      "externalId": null,
      "dataSource": null,
      "record": null
    },
    {
      "id": null,
      "names": null,
      "legalForm": null,
      "identifiers": null,
      "address": null,
      "externalId": null,
      "dataSource": null,
      "record": null
    },
    {
      "id": null,
      "names": null,
      "legalForm": null,
      "identifiers": null,
      "address": null,
      "externalId": null,
      "dataSource": null,
      "record": null
    }
  ],
  "pattern": {
    "id": null,
    "names": null,
    "legalForm": null,
    "identifiers": null,
    "address": null,
    "externalId": null,
    "dataSource": null,
    "record": null
  },
  "dataMatchingDefinitionId": null
}
```

