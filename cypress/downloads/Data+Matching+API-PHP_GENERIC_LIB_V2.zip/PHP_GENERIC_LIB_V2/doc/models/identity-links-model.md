
# Identity Links Model

## Structure

`IdentityLinksModel`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `startAfter` | `?string` | Optional | - | getStartAfter(): ?string | setStartAfter(?string startAfter): void |
| `limit` | `?int` | Optional | - | getLimit(): ?int | setLimit(?int limit): void |
| `values` | [`?(IdentityLinkModel[])`](../../doc/models/identity-link-model.md) | Optional | - | getValues(): ?array | setValues(?array values): void |
| `nextStartAfter` | `?string` | Optional | Indicator for the next page. Used together with startAfter. | getNextStartAfter(): ?string | setNextStartAfter(?string nextStartAfter): void |

## Example (as JSON)

```json
{
  "startAfter": null,
  "limit": null,
  "values": null,
  "nextStartAfter": null
}
```

