
# Decision Strategy Model

## Structure

`DecisionStrategyModel`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `root` | [`?DecisionNodeModel`](../../doc/models/decision-node-model.md) | Optional | - | getRoot(): ?DecisionNodeModel | setRoot(?DecisionNodeModel root): void |

## Example (as JSON)

```json
{
  "root": null
}
```

