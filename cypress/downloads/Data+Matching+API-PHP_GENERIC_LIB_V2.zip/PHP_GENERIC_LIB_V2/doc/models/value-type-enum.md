
# Value Type Enum

## Enumeration

`ValueTypeEnum`

## Fields

| Name |
|  --- |
| `TEXT` |
| `DATE` |
| `NUMBER` |
| `FLOATING_POINT_NUMBER` |

