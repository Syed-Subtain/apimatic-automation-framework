
# Administrative Area Model

## Structure

`AdministrativeAreaModel`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `value` | `?string` | Optional | - | getValue(): ?string | setValue(?string value): void |
| `shortName` | `?string` | Optional | - | getShortName(): ?string | setShortName(?string shortName): void |
| `type` | [`?AdministrativeAreaTypeModel`](../../doc/models/administrative-area-type-model.md) | Optional | - | getType(): ?AdministrativeAreaTypeModel | setType(?AdministrativeAreaTypeModel type): void |

## Example (as JSON)

```json
{
  "value": null,
  "shortName": null,
  "type": null
}
```

