
# Data Matching Definition Page Model

## Structure

`DataMatchingDefinitionPageModel`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `page` | `?int` | Optional | - | getPage(): ?int | setPage(?int page): void |
| `pageSize` | `?int` | Optional | - | getPageSize(): ?int | setPageSize(?int pageSize): void |
| `numberOfPages` | `?int` | Optional | - | getNumberOfPages(): ?int | setNumberOfPages(?int numberOfPages): void |
| `total` | `?int` | Optional | - | getTotal(): ?int | setTotal(?int total): void |
| `values` | [`?(DataMatchingDefinitionModel[])`](../../doc/models/data-matching-definition-model.md) | Optional | - | getValues(): ?array | setValues(?array values): void |

## Example (as JSON)

```json
{
  "page": null,
  "pageSize": null,
  "numberOfPages": null,
  "total": null,
  "values": null
}
```

