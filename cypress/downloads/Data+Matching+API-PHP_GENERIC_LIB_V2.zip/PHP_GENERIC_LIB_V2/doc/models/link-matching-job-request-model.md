
# Link Matching Job Request Model

## Structure

`LinkMatchingJobRequestModel`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `patternSources` | [`?(DataMatchingSourceModel[])`](../../doc/models/data-matching-source-model.md) | Optional | The source, in form of a BusinessPartner storage (at least one but can be more), to get the pattern records for the matching.<br>**Constraints**: *Minimum Items*: `1` | getPatternSources(): ?array | setPatternSources(?array patternSources): void |
| `matchSources` | [`?(DataMatchingSourceModel[])`](../../doc/models/data-matching-source-model.md) | Optional | The source, in form of a BusinessPartner storage (at least one but can be more), to get the match records for the matching.<br>**Constraints**: *Minimum Items*: `1` | getMatchSources(): ?array | setMatchSources(?array matchSources): void |
| `countryShortNames` | `?(string[])` | Optional | If set, only the records that belong to the countries identified by these short names are processed. By default all records of the storage (means from all countries) are processed (considering other filters). | getCountryShortNames(): ?array | setCountryShortNames(?array countryShortNames): void |
| `dataMatchingDefinitionId` | `?string` | Optional | ID of the DataMatchingDefinition that should be used to perform the link matching. | getDataMatchingDefinitionId(): ?string | setDataMatchingDefinitionId(?string dataMatchingDefinitionId): void |
| `decisionLogIds` | `?(string[])` | Optional | If set, feedback from listed Matching Decision Logs will be considered. | getDecisionLogIds(): ?array | setDecisionLogIds(?array decisionLogIds): void |

## Example (as JSON)

```json
{
  "patternSources": null,
  "matchSources": null,
  "countryShortNames": null,
  "dataMatchingDefinitionId": null,
  "decisionLogIds": null
}
```

