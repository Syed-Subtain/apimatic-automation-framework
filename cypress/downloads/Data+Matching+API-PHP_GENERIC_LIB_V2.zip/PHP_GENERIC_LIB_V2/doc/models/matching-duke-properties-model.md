
# Matching Duke Properties Model

## Structure

`MatchingDukePropertiesModel`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `threads` | `?int` | Optional | **Default**: `1`<br>**Constraints**: `>= 1`, `<= 10` | getThreads(): ?int | setThreads(?int threads): void |
| `batchSize` | `?int` | Optional | **Default**: `40000`<br>**Constraints**: `>= 40000`, `<= 1000000` | getBatchSize(): ?int | setBatchSize(?int batchSize): void |
| `profiling` | `?bool` | Optional | **Default**: `false` | getProfiling(): ?bool | setProfiling(?bool profiling): void |

## Example (as JSON)

```json
{
  "threads": null,
  "batchSize": null,
  "profiling": null
}
```

