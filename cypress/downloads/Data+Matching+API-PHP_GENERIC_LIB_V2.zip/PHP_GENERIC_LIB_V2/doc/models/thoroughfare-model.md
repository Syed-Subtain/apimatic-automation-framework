
# Thoroughfare Model

## Structure

`ThoroughfareModel`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `type` | [`?ThoroughfareTypeModel`](../../doc/models/thoroughfare-type-model.md) | Optional | - | getType(): ?ThoroughfareTypeModel | setType(?ThoroughfareTypeModel type): void |
| `shortName` | `?string` | Optional | - | getShortName(): ?string | setShortName(?string shortName): void |
| `number` | `?string` | Optional | - | getNumber(): ?string | setNumber(?string number): void |
| `direction` | `?string` | Optional | - | getDirection(): ?string | setDirection(?string direction): void |
| `value` | `?string` | Optional | - | getValue(): ?string | setValue(?string value): void |

## Example (as JSON)

```json
{
  "type": null,
  "shortName": null,
  "number": null,
  "direction": null,
  "value": null
}
```

