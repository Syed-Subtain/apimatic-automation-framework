
# Matching Classification Model

## Structure

`MatchingClassificationModel`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `technicalKey` | `?string` | Optional | - | getTechnicalKey(): ?string | setTechnicalKey(?string technicalKey): void |
| `name` | `?string` | Optional | - | getName(): ?string | setName(?string name): void |

## Example (as JSON)

```json
{
  "technicalKey": null,
  "name": null
}
```

