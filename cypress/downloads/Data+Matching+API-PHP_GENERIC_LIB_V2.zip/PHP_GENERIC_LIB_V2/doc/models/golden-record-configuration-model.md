
# Golden Record Configuration Model

## Structure

`GoldenRecordConfigurationModel`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `decisionStrategy` | [`?DecisionStrategyModel`](../../doc/models/decision-strategy-model.md) | Optional | - | getDecisionStrategy(): ?DecisionStrategyModel | setDecisionStrategy(?DecisionStrategyModel decisionStrategy): void |
| `creationStrategy` | [`?CreationStrategyModel`](../../doc/models/creation-strategy-model.md) | Optional | - | getCreationStrategy(): ?CreationStrategyModel | setCreationStrategy(?CreationStrategyModel creationStrategy): void |

## Example (as JSON)

```json
{
  "decisionStrategy": null,
  "creationStrategy": null
}
```

