
# Matching Profile Model

## Structure

`MatchingProfileModel`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `matchingScores` | [`?MatchingScoresModel`](../../doc/models/matching-scores-model.md) | Optional | - | getMatchingScores(): ?MatchingScoresModel | setMatchingScores(?MatchingScoresModel matchingScores): void |

## Example (as JSON)

```json
{
  "matchingScores": null
}
```

