
# Matching Reports Model

## Structure

`MatchingReportsModel`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `id` | `?string` | Optional | ID of the job which generated the report | getId(): ?string | setId(?string id): void |
| `status` | `?string` | Optional | - | getStatus(): ?string | setStatus(?string status): void |
| `statusMessage` | `?string` | Optional | - | getStatusMessage(): ?string | setStatusMessage(?string statusMessage): void |
| `createdAt` | `?string` | Optional | - | getCreatedAt(): ?string | setCreatedAt(?string createdAt): void |
| `finishedAt` | `?string` | Optional | - | getFinishedAt(): ?string | setFinishedAt(?string finishedAt): void |
| `user` | `?string` | Optional | - | getUser(): ?string | setUser(?string user): void |
| `attachments` | [`?(AttachmentModel[])`](../../doc/models/attachment-model.md) | Optional | - | getAttachments(): ?array | setAttachments(?array attachments): void |
| `progress` | `?int` | Optional | - | getProgress(): ?int | setProgress(?int progress): void |
| `reportsConfiguration` | [`?MatchingReportsConfigurationModel`](../../doc/models/matching-reports-configuration-model.md) | Optional | - | getReportsConfiguration(): ?MatchingReportsConfigurationModel | setReportsConfiguration(?MatchingReportsConfigurationModel reportsConfiguration): void |

## Example (as JSON)

```json
{
  "id": null,
  "status": null,
  "statusMessage": null,
  "createdAt": null,
  "finishedAt": null,
  "user": null,
  "attachments": null,
  "progress": null,
  "reportsConfiguration": null
}
```

