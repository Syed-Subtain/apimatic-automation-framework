
# Name Model

## Structure

`NameModel`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `details` | `?string` | Optional | - | getDetails(): ?string | setDetails(?string details): void |
| `language` | `?string` | Optional | - | getLanguage(): ?string | setLanguage(?string language): void |
| `shortName` | `?string` | Optional | - | getShortName(): ?string | setShortName(?string shortName): void |
| `type` | [`?NameTypeModel`](../../doc/models/name-type-model.md) | Optional | - | getType(): ?NameTypeModel | setType(?NameTypeModel type): void |
| `value` | `?string` | Optional | - | getValue(): ?string | setValue(?string value): void |

## Example (as JSON)

```json
{
  "details": null,
  "language": null,
  "shortName": null,
  "type": null,
  "value": null
}
```

