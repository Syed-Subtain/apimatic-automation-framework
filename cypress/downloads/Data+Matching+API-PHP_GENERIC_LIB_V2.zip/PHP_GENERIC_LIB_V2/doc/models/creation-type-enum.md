
# Creation Type Enum

Defines the way how an attributes should be selected to be added to the golden record.

## Enumeration

`CreationTypeEnum`

## Fields

| Name |
|  --- |
| `CONSTANT` |
| `MAJORITY` |
| `JOIN_DISTINCT` |

