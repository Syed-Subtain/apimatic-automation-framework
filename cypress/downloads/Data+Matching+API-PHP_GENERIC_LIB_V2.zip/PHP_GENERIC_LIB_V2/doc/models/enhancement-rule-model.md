
# Enhancement Rule Model

Defines the way how the attributes of the golden record are chosen.

## Structure

`EnhancementRuleModel`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `attributes` | `string[]` | Required | List of attribute affected by this rule of enhancement<br>**Constraints**: *Minimum Items*: `1` | getAttributes(): array | setAttributes(array attributes): void |
| `constraintChain` | [`?ConstraintChainModel`](../../doc/models/constraint-chain-model.md) | Optional | - | getConstraintChain(): ?ConstraintChainModel | setConstraintChain(?ConstraintChainModel constraintChain): void |
| `creationType` | [`?string (CreationTypeEnum)`](../../doc/models/creation-type-enum.md) | Optional | Defines the way how an attributes should be selected to be added to the golden record. | getCreationType(): ?string | setCreationType(?string creationType): void |
| `creationConstant` | `?string` | Optional | - | getCreationConstant(): ?string | setCreationConstant(?string creationConstant): void |
| `executionType` | [`string (ExecutionTypeEnum)`](../../doc/models/execution-type-enum.md) | Required | Defines options on how an attribute should be handled. SET means the already existing one is overwritten, ENRICH means that the new value is only added to the golden record in case it does not have any value yet and REMOVE will just delete the existing value from the golden record. | getExecutionType(): string | setExecutionType(string executionType): void |
| `fallbackExecutionType` | [`?string (ExecutionTypeEnum)`](../../doc/models/execution-type-enum.md) | Optional | Defines options on how an attribute should be handled. SET means the already existing one is overwritten, ENRICH means that the new value is only added to the golden record in case it does not have any value yet and REMOVE will just delete the existing value from the golden record. | getFallbackExecutionType(): ?string | setFallbackExecutionType(?string fallbackExecutionType): void |

## Example (as JSON)

```json
{
  "attributes": [
    "attributes1"
  ],
  "constraintChain": null,
  "creationType": null,
  "creationConstant": null,
  "executionType": "REMOVE",
  "fallbackExecutionType": null
}
```

