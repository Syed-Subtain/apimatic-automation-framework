
# Identity Link Decision Create Failure Log Model

## Structure

`IdentityLinkDecisionCreateFailureLogModel`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `id` | `?string` | Optional | - | getId(): ?string | setId(?string id): void |
| `identityLink` | [`?IdentityLinkEntryModel`](../../doc/models/identity-link-entry-model.md) | Optional | - | getIdentityLink(): ?IdentityLinkEntryModel | setIdentityLink(?IdentityLinkEntryModel identityLink): void |
| `message` | `?string` | Optional | - | getMessage(): ?string | setMessage(?string message): void |

## Example (as JSON)

```json
{
  "id": null,
  "identityLink": null,
  "message": null
}
```

