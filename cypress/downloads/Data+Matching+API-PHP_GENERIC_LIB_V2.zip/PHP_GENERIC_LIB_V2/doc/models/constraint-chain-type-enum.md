
# Constraint Chain Type Enum

## Enumeration

`ConstraintChainTypeEnum`

## Fields

| Name |
|  --- |
| `AND_` |
| `OR_` |

