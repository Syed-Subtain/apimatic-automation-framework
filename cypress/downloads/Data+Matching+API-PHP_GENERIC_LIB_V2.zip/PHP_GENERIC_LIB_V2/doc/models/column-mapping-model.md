
# Column Mapping Model

## Structure

`ColumnMappingModel`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `attributeJsonPath` | `?string` | Optional | - | getAttributeJsonPath(): ?string | setAttributeJsonPath(?string attributeJsonPath): void |
| `columnName` | `?string` | Optional | - | getColumnName(): ?string | setColumnName(?string columnName): void |

## Example (as JSON)

```json
{
  "attributeJsonPath": null,
  "columnName": null
}
```

