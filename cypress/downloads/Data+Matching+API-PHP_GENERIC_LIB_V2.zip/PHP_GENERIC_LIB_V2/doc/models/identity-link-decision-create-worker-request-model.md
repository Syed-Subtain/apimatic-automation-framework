
# Identity Link Decision Create Worker Request Model

## Structure

`IdentityLinkDecisionCreateWorkerRequestModel`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `links` | [`IdentityLinkCreateModel[]`](../../doc/models/identity-link-create-model.md) | Required | **Constraints**: *Minimum Items*: `1`, *Maximum Items*: `1000` | getLinks(): array | setLinks(array links): void |
| `decisionLogId` | `?string` | Optional | - | getDecisionLogId(): ?string | setDecisionLogId(?string decisionLogId): void |

## Example (as JSON)

```json
{
  "links": [
    {
      "entries": [
        {
          "storageId": "storageId7",
          "dataSourceId": "dataSourceId5",
          "businessPartnerId": "businessPartnerId5"
        }
      ]
    },
    {
      "entries": [
        {
          "storageId": "storageId8",
          "dataSourceId": "dataSourceId6",
          "businessPartnerId": "businessPartnerId6"
        },
        {
          "storageId": "storageId9",
          "dataSourceId": "dataSourceId7",
          "businessPartnerId": "businessPartnerId7"
        }
      ]
    },
    {
      "entries": [
        {
          "storageId": "storageId9",
          "dataSourceId": "dataSourceId7",
          "businessPartnerId": "businessPartnerId7"
        },
        {
          "storageId": "storageId0",
          "dataSourceId": "dataSourceId8",
          "businessPartnerId": "businessPartnerId8"
        },
        {
          "storageId": "storageId1",
          "dataSourceId": "dataSourceId9",
          "businessPartnerId": "businessPartnerId9"
        }
      ]
    }
  ],
  "decisionLogId": null
}
```

