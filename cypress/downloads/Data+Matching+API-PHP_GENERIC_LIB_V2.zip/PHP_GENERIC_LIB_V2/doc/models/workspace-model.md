
# Workspace Model

## Structure

`WorkspaceModel`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `id` | `?string` | Optional | - | getId(): ?string | setId(?string id): void |

## Example (as JSON)

```json
{
  "id": null
}
```

