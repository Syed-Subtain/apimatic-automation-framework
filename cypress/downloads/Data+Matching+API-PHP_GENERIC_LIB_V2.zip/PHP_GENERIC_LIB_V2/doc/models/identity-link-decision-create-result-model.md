
# Identity Link Decision Create Result Model

## Structure

`IdentityLinkDecisionCreateResultModel`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `numberOfProcessed` | `?int` | Optional | - | getNumberOfProcessed(): ?int | setNumberOfProcessed(?int numberOfProcessed): void |
| `numberOfCreated` | `?int` | Optional | - | getNumberOfCreated(): ?int | setNumberOfCreated(?int numberOfCreated): void |
| `numberOfFailed` | `?int` | Optional | - | getNumberOfFailed(): ?int | setNumberOfFailed(?int numberOfFailed): void |
| `failures` | [`?(IdentityLinkDecisionCreateFailureLogModel[])`](../../doc/models/identity-link-decision-create-failure-log-model.md) | Optional | - | getFailures(): ?array | setFailures(?array failures): void |

## Example (as JSON)

```json
{
  "numberOfProcessed": null,
  "numberOfCreated": null,
  "numberOfFailed": null,
  "failures": null
}
```

