
# Linkage Matching Report Properties Model

## Structure

`LinkageMatchingReportPropertiesModel`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `reportType` | [`?string (LinkageMatchingReportTypeEnum)`](../../doc/models/linkage-matching-report-type-enum.md) | Optional | **Default**: `LinkageMatchingReportTypeEnum::EXCEL` | getReportType(): ?string | setReportType(?string reportType): void |

## Example (as JSON)

```json
{
  "reportType": null
}
```

