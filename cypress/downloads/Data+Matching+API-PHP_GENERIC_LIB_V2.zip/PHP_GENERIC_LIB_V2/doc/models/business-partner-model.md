
# Business Partner Model

## Structure

`BusinessPartnerModel`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `id` | `?string` | Optional | - | getId(): ?string | setId(?string id): void |
| `names` | [`?(NameModel[])`](../../doc/models/name-model.md) | Optional | - | getNames(): ?array | setNames(?array names): void |
| `legalForm` | [`?LegalFormModel`](../../doc/models/legal-form-model.md) | Optional | - | getLegalForm(): ?LegalFormModel | setLegalForm(?LegalFormModel legalForm): void |
| `identifiers` | [`?(IdentifierModel[])`](../../doc/models/identifier-model.md) | Optional | - | getIdentifiers(): ?array | setIdentifiers(?array identifiers): void |
| `address` | [`?AddressModel`](../../doc/models/address-model.md) | Optional | - | getAddress(): ?AddressModel | setAddress(?AddressModel address): void |
| `externalId` | `?string` | Optional | ID the record has in the external system where the record originates from. | getExternalId(): ?string | setExternalId(?string externalId): void |
| `dataSource` | `?string` | Optional | Name of the associated external system where the record originates from. | getDataSource(): ?string | setDataSource(?string dataSource): void |
| `record` | `?string` | Optional | Stringified JSON of an individual business partner record. | getRecord(): ?string | setRecord(?string record): void |

## Example (as JSON)

```json
{
  "id": null,
  "names": null,
  "legalForm": null,
  "identifiers": null,
  "address": null,
  "externalId": null,
  "dataSource": null,
  "record": null
}
```

