
# Locality Model

## Structure

`LocalityModel`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `type` | [`?LocalityTypeModel`](../../doc/models/locality-type-model.md) | Optional | - | getType(): ?LocalityTypeModel | setType(?LocalityTypeModel type): void |
| `shortName` | `?string` | Optional | - | getShortName(): ?string | setShortName(?string shortName): void |
| `value` | `?string` | Optional | - | getValue(): ?string | setValue(?string value): void |

## Example (as JSON)

```json
{
  "type": null,
  "shortName": null,
  "value": null
}
```

