
# Constraint Chain Model

## Structure

`ConstraintChainModel`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `constraints` | [`?(RuleModel[])`](../../doc/models/rule-model.md) | Optional | List of attribute affected by this rule of enhancement | getConstraints(): ?array | setConstraints(?array constraints): void |
| `allRecordsShouldMatch` | `?bool` | Optional | - | getAllRecordsShouldMatch(): ?bool | setAllRecordsShouldMatch(?bool allRecordsShouldMatch): void |
| `constraintChainType` | [`?string (ConstraintChainTypeEnum)`](../../doc/models/constraint-chain-type-enum.md) | Optional | - | getConstraintChainType(): ?string | setConstraintChainType(?string constraintChainType): void |

## Example (as JSON)

```json
{
  "constraints": null,
  "allRecordsShouldMatch": null,
  "constraintChainType": null
}
```

