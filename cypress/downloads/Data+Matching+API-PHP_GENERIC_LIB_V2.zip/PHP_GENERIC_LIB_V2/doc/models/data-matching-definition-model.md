
# Data Matching Definition Model

## Structure

`DataMatchingDefinitionModel`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `id` | `?string` | Optional | - | getId(): ?string | setId(?string id): void |
| `name` | `?string` | Optional | Human readable name.<br>**Constraints**: *Maximum Length*: `30` | getName(): ?string | setName(?string name): void |
| `creatorUsername` | `?string` | Optional | - | getCreatorUsername(): ?string | setCreatorUsername(?string creatorUsername): void |
| `creatorOrganization` | `?string` | Optional | - | getCreatorOrganization(): ?string | setCreatorOrganization(?string creatorOrganization): void |
| `createdAt` | `?string` | Optional | - | getCreatedAt(): ?string | setCreatedAt(?string createdAt): void |
| `lastModifiedAt` | `?string` | Optional | - | getLastModifiedAt(): ?string | setLastModifiedAt(?string lastModifiedAt): void |
| `type` | [`?string (MatchingTypeEnum)`](../../doc/models/matching-type-enum.md) | Optional | - | getType(): ?string | setType(?string type): void |
| `xmlDukeConfiguration` | `?string` | Optional | Duke XML matching configuration | getXmlDukeConfiguration(): ?string | setXmlDukeConfiguration(?string xmlDukeConfiguration): void |
| `reportConfiguration` | [`?ReportConfigurationModel`](../../doc/models/report-configuration-model.md) | Optional | - | getReportConfiguration(): ?ReportConfigurationModel | setReportConfiguration(?ReportConfigurationModel reportConfiguration): void |
| `goldenRecordConfiguration` | [`?GoldenRecordConfigurationModel`](../../doc/models/golden-record-configuration-model.md) | Optional | - | getGoldenRecordConfiguration(): ?GoldenRecordConfigurationModel | setGoldenRecordConfiguration(?GoldenRecordConfigurationModel goldenRecordConfiguration): void |
| `workspace` | [`?WorkspaceModel`](../../doc/models/workspace-model.md) | Optional | - | getWorkspace(): ?WorkspaceModel | setWorkspace(?WorkspaceModel workspace): void |

## Example (as JSON)

```json
{
  "id": null,
  "name": null,
  "creatorUsername": null,
  "creatorOrganization": null,
  "createdAt": null,
  "lastModifiedAt": null,
  "type": null,
  "xmlDukeConfiguration": null,
  "reportConfiguration": null,
  "goldenRecordConfiguration": null,
  "workspace": null
}
```

