
# Matching Decision Import Job Statistics Model

## Structure

`MatchingDecisionImportJobStatisticsModel`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `numberOfInserts` | `?int` | Optional | - | getNumberOfInserts(): ?int | setNumberOfInserts(?int numberOfInserts): void |
| `numberOfFailed` | `?int` | Optional | - | getNumberOfFailed(): ?int | setNumberOfFailed(?int numberOfFailed): void |

## Example (as JSON)

```json
{
  "numberOfInserts": null,
  "numberOfFailed": null
}
```

