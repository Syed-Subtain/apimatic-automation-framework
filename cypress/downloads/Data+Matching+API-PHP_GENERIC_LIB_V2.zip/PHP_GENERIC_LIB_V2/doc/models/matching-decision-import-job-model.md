
# Matching Decision Import Job Model

## Structure

`MatchingDecisionImportJobModel`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `id` | `?string` | Optional | - | getId(): ?string | setId(?string id): void |
| `domain` | `?string` | Optional | - | getDomain(): ?string | setDomain(?string domain): void |
| `createdBy` | `?string` | Optional | - | getCreatedBy(): ?string | setCreatedBy(?string createdBy): void |
| `createdAt` | `?string` | Optional | - | getCreatedAt(): ?string | setCreatedAt(?string createdAt): void |
| `modifiedAt` | `?string` | Optional | - | getModifiedAt(): ?string | setModifiedAt(?string modifiedAt): void |
| `progress` | `?int` | Optional | - | getProgress(): ?int | setProgress(?int progress): void |
| `status` | `?string` | Optional | - | getStatus(): ?string | setStatus(?string status): void |
| `statusMessage` | `?string` | Optional | - | getStatusMessage(): ?string | setStatusMessage(?string statusMessage): void |
| `decisionLogId` | `?string` | Optional | - | getDecisionLogId(): ?string | setDecisionLogId(?string decisionLogId): void |
| `result` | [`?MatchingDecisionImportJobResultModel`](../../doc/models/matching-decision-import-job-result-model.md) | Optional | - | getResult(): ?MatchingDecisionImportJobResultModel | setResult(?MatchingDecisionImportJobResultModel result): void |

## Example (as JSON)

```json
{
  "id": null,
  "domain": null,
  "createdBy": null,
  "createdAt": null,
  "modifiedAt": null,
  "progress": null,
  "status": null,
  "statusMessage": null,
  "decisionLogId": null,
  "result": null
}
```

