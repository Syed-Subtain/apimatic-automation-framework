
# Name Type Model

## Structure

`NameTypeModel`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `url` | `?string` | Optional | - | getUrl(): ?string | setUrl(?string url): void |
| `name` | `?string` | Optional | - | getName(): ?string | setName(?string name): void |
| `technicalKey` | `?string` | Optional | - | getTechnicalKey(): ?string | setTechnicalKey(?string technicalKey): void |

## Example (as JSON)

```json
{
  "url": null,
  "name": null,
  "technicalKey": null
}
```

