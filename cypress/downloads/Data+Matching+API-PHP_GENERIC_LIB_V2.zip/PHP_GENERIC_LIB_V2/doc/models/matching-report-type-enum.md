
# Matching Report Type Enum

## Enumeration

`MatchingReportTypeEnum`

## Fields

| Name |
|  --- |
| `EXCEL` |
| `CSV` |
| `JOB_RESULTS` |

