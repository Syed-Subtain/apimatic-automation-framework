# Data Matching

```php
$dataMatchingController = $client->getDataMatchingController();
```

## Class Name

`DataMatchingController`

## Methods

* [Read a Page of Existing Data Matching Definitions](../../doc/controllers/data-matching.md#read-a-page-of-existing-data-matching-definitions)
* [Delete a Data Matching Definition](../../doc/controllers/data-matching.md#delete-a-data-matching-definition)
* [Update a Data Matching Definition](../../doc/controllers/data-matching.md#update-a-data-matching-definition)
* [Create a New Data Matching Definition](../../doc/controllers/data-matching.md#create-a-new-data-matching-definition)
* [Read an Existing Data Matching Definition](../../doc/controllers/data-matching.md#read-an-existing-data-matching-definition)


# Read a Page of Existing Data Matching Definitions

Read a page of existing DataMatchingDefinitions

```php
function readAPageOfExistingDataMatchingDefinitions(array $options): ?DataMatchingDefinitionPageModel
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `page` | `?int` | Query, Optional | Number of the page that will be retrieved.<br>**Default**: `0`<br>**Constraints**: `>= 0` |
| `pageSize` | `?int` | Query, Optional | Number of items to be returned on the page.<br>**Default**: `20`<br>**Constraints**: `>= 1` |
| `matchingType` | [`?string (MatchingTypeEnum)`](../../doc/models/matching-type-enum.md) | Query, Optional | Type of the matching configuration. |
| `workspaceId` | `?string` | Query, Optional | ID of the workspace |

## Response Type

[`?DataMatchingDefinitionPageModel`](../../doc/models/data-matching-definition-page-model.md)

## Example Usage

```php
$collect = [];

$page = 0;
$collect['page'] = $page;

$pageSize = 20;
$collect['pageSize'] = $pageSize;

$matchingType = Models\MatchingTypeEnum::DEDUPLICATION;
$collect['matchingType'] = $matchingType;

$result = $dataMatchingController->readAPageOfExistingDataMatchingDefinitions($collect);
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | The sent request is malformed. | [`ApiErrorException`](../../doc/models/api-error-exception.md) |
| 403 | Permission denied. | [`ApiErrorException`](../../doc/models/api-error-exception.md) |


# Delete a Data Matching Definition

Delete a DataMatchingDefinition

```php
function deleteADataMatchingDefinition(string $id): void
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `string` | Template, Required | id |

## Response Type

`void`

## Example Usage

```php
$id = 'id0';
$dataMatchingController->deleteADataMatchingDefinition($id);
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | The sent request is malformed. | [`ApiErrorException`](../../doc/models/api-error-exception.md) |
| 403 | Permission denied. | [`ApiErrorException`](../../doc/models/api-error-exception.md) |


# Update a Data Matching Definition

Update a DataMatchingDefinition

```php
function updateADataMatchingDefinition(array $options): ?DataMatchingDefinitionModel
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `string` | Template, Required | id |
| `body` | [`DataMatchingDefinitionUpdateModel`](../../doc/models/data-matching-definition-update-model.md) | Body, Required | - |

## Response Type

[`?DataMatchingDefinitionModel`](../../doc/models/data-matching-definition-model.md)

## Example Usage

```php
$collect = [];

$id = 'id0';
$collect['id'] = $id;

$body_name = 'name6';
$body_type = Models\MatchingTypeEnum::DEDUPLICATION;
$body_xmlDukeConfiguration = 'xmlDukeConfiguration6';
$body = new Models\DataMatchingDefinitionUpdateModel(
    $body_name,
    $body_type,
    $body_xmlDukeConfiguration
);
$collect['body'] = $body;

$result = $dataMatchingController->updateADataMatchingDefinition($collect);
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | The sent request is malformed. | [`ApiErrorException`](../../doc/models/api-error-exception.md) |
| 403 | Permission denied. | [`ApiErrorException`](../../doc/models/api-error-exception.md) |


# Create a New Data Matching Definition

Create a new DataMatchingDefinition

```php
function createANewDataMatchingDefinition(DataMatchingDefinitionCreateModel $body): ?DataMatchingDefinitionModel
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`DataMatchingDefinitionCreateModel`](../../doc/models/data-matching-definition-create-model.md) | Body, Required | - |

## Response Type

[`?DataMatchingDefinitionModel`](../../doc/models/data-matching-definition-model.md)

## Example Usage

```php
$body_name = 'name6';
$body_type = Models\MatchingTypeEnum::DEDUPLICATION;
$body_xmlDukeConfiguration = 'xmlDukeConfiguration6';
$body = new Models\DataMatchingDefinitionCreateModel(
    $body_name,
    $body_type,
    $body_xmlDukeConfiguration
);
$result = $dataMatchingController->createANewDataMatchingDefinition($body);
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | The sent request is malformed. | [`ApiErrorException`](../../doc/models/api-error-exception.md) |


# Read an Existing Data Matching Definition

Read an existing DataMatchingDefinition

```php
function readAnExistingDataMatchingDefinition(string $id): ?DataMatchingDefinitionModel
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `string` | Template, Required | id |

## Response Type

[`?DataMatchingDefinitionModel`](../../doc/models/data-matching-definition-model.md)

## Example Usage

```php
$id = 'id0';
$result = $dataMatchingController->readAnExistingDataMatchingDefinition($id);
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | The sent request is malformed. | [`ApiErrorException`](../../doc/models/api-error-exception.md) |
| 403 | Permission denied. | [`ApiErrorException`](../../doc/models/api-error-exception.md) |

