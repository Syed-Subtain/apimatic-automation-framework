# Duplicate Matching

```php
$duplicateMatchingController = $client->getDuplicateMatchingController();
```

## Class Name

`DuplicateMatchingController`

## Methods

* [Start Deduplication Job](../../doc/controllers/duplicate-matching.md#start-deduplication-job)
* [Poll Deduplication Job Status](../../doc/controllers/duplicate-matching.md#poll-deduplication-job-status)


# Start Deduplication Job

Start deduplication job

```php
function startDeduplicationJob(DuplicateMatchingJobRequestModel $body): ?DuplicateMatchingJobModel
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`DuplicateMatchingJobRequestModel`](../../doc/models/duplicate-matching-job-request-model.md) | Body, Required | - |

## Response Type

[`?DuplicateMatchingJobModel`](../../doc/models/duplicate-matching-job-model.md)

## Example Usage

```php
$body = new Models\DuplicateMatchingJobRequestModel;
$result = $duplicateMatchingController->startDeduplicationJob($body);
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | `ApiException` |
| 403 | Forbidden | `ApiException` |


# Poll Deduplication Job Status

Poll deduplication job status

```php
function pollDeduplicationJobStatus(string $id): ?DuplicateMatchingJobModel
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `string` | Template, Required | ID of the deduplication job |

## Response Type

[`?DuplicateMatchingJobModel`](../../doc/models/duplicate-matching-job-model.md)

## Example Usage

```php
$id = 'id0';
$result = $duplicateMatchingController->pollDeduplicationJobStatus($id);
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | `ApiException` |
| 403 | Forbidden | `ApiException` |

