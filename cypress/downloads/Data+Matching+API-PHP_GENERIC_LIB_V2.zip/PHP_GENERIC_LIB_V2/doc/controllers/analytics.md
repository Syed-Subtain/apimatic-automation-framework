# Analytics

Everything about Analytics

```php
$analyticsController = $client->getAnalyticsController();
```

## Class Name

`AnalyticsController`

## Methods

* [Poll Matching Reports](../../doc/controllers/analytics.md#poll-matching-reports)
* [Build Matching Reports](../../doc/controllers/analytics.md#build-matching-reports)


# Poll Matching Reports

Poll Matching Reports

```php
function pollMatchingReports(string $id): ?MatchingReportsModel
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `string` | Template, Required | ID of the matching report |

## Response Type

[`?MatchingReportsModel`](../../doc/models/matching-reports-model.md)

## Example Usage

```php
$id = 'id0';
$result = $analyticsController->pollMatchingReports($id);
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | `ApiException` |
| 403 | Forbidden | `ApiException` |
| 404 | Not Found | `ApiException` |


# Build Matching Reports

Requests the building of data matching reports

```php
function buildMatchingReports(MatchingReportsRequestModel $body): ?MatchingReportsModel
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`MatchingReportsRequestModel`](../../doc/models/matching-reports-request-model.md) | Body, Required | cmd |

## Response Type

[`?MatchingReportsModel`](../../doc/models/matching-reports-model.md)

## Example Usage

```php
$body = new Models\MatchingReportsRequestModel;
$result = $analyticsController->buildMatchingReports($body);
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | `ApiException` |
| 403 | Forbidden | `ApiException` |
| 404 | Not Found | `ApiException` |

