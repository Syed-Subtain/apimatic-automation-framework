# User Feedback

```php
$userFeedbackController = $client->getUserFeedbackController();
```

## Class Name

`UserFeedbackController`

## Methods

* [Read User Feedbacks](../../doc/controllers/user-feedback.md#read-user-feedbacks)
* [Read User Feedback by ID](../../doc/controllers/user-feedback.md#read-user-feedback-by-id)
* [Create Identity Link](../../doc/controllers/user-feedback.md#create-identity-link)
* [Start Matching Decision Import Job](../../doc/controllers/user-feedback.md#start-matching-decision-import-job)
* [Delete User Feedback](../../doc/controllers/user-feedback.md#delete-user-feedback)
* [Poll Matching Decision Import Job Status](../../doc/controllers/user-feedback.md#poll-matching-decision-import-job-status)
* [Userfeedbacks Clear by Id POST](../../doc/controllers/user-feedback.md#userfeedbacks-clear-by-id-post)
* [Create User Feedback](../../doc/controllers/user-feedback.md#create-user-feedback)
* [Read Identity Links](../../doc/controllers/user-feedback.md#read-identity-links)


# Read User Feedbacks

Read available Matching Decision Logs across your organization.

```php
function readUserFeedbacks(array $options): ?MatchingDecisionLogsModel
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `startAfter` | `?string` | Query, Optional | Indicator for the next page. Used together with nextStartAfter from the result. |
| `limit` | `?int` | Query, Optional | Number of items to be returned<br>**Default**: `20`<br>**Constraints**: `>= 1` |

## Response Type

[`?MatchingDecisionLogsModel`](../../doc/models/matching-decision-logs-model.md)

## Example Usage

```php
$collect = [];

$limit = 20;
$collect['limit'] = $limit;

$result = $userFeedbackController->readUserFeedbacks($collect);
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | `ApiException` |
| 403 | Forbidden | `ApiException` |
| 404 | Not Found | `ApiException` |


# Read User Feedback by ID

Read Matching Decision Logs details provided by ID.

```php
function readUserFeedbackByID(string $id): ?MatchingDecisionLogResultModel
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `string` | Template, Required | - |

## Response Type

[`?MatchingDecisionLogResultModel`](../../doc/models/matching-decision-log-result-model.md)

## Example Usage

```php
$id = 'id0';
$result = $userFeedbackController->readUserFeedbackByID($id);
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | `ApiException` |
| 403 | Forbidden | `ApiException` |
| 404 | Not Found | `ApiException` |


# Create Identity Link

Add Identity Links to the Matching Decision Log identified by ID.

```php
function createIdentityLink(array $options): ?IdentityLinkCreateResultModel
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `string` | Template, Required | - |
| `body` | [`IdentityLinkCreateRequestModel`](../../doc/models/identity-link-create-request-model.md) | Body, Required | - |

## Response Type

[`?IdentityLinkCreateResultModel`](../../doc/models/identity-link-create-result-model.md)

## Example Usage

```php
$collect = [];

$id = 'id0';
$collect['id'] = $id;

$body_links = [];

$body_links_0_entries = [];

$body_links_0_entries_0_storageId = 'storageId3';
$body_links_0_entries_0_dataSourceId = 'dataSourceId1';
$body_links_0_entries_0_businessPartnerId = 'businessPartnerId1';
$body_links_0_entries[0] = new Models\IdentityLinkEntryModel(
    $body_links_0_entries_0_storageId,
    $body_links_0_entries_0_dataSourceId,
    $body_links_0_entries_0_businessPartnerId
);

$body_links_0_entries_1_storageId = 'storageId4';
$body_links_0_entries_1_dataSourceId = 'dataSourceId2';
$body_links_0_entries_1_businessPartnerId = 'businessPartnerId2';
$body_links_0_entries[1] = new Models\IdentityLinkEntryModel(
    $body_links_0_entries_1_storageId,
    $body_links_0_entries_1_dataSourceId,
    $body_links_0_entries_1_businessPartnerId
);

$body_links[0] = new Models\IdentityLinkCreateModel(
    $body_links_0_entries
);

$body = new Models\IdentityLinkCreateRequestModel(
    $body_links
);
$collect['body'] = $body;

$result = $userFeedbackController->createIdentityLink($collect);
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | `ApiException` |
| 403 | Forbidden | `ApiException` |


# Start Matching Decision Import Job

To start importing an Identity Linkage Decision import file, use the following request.

```
POST https://api.corporate-data-league.ch/data-matching/rest/jobs/matchingdecisionjobs
  ?file=@{YOUR FILE}
  ?decisionLogId={YOUR MatchingDecisionLog ID}
```

With using output file from duplication or linkage job.

The response is shown below. Use the returned `id` to [poll](#/rest/api-endpoints/identity-linkage/poll-matching-decision-import-job-status) the import job status.

```
{
    "id" : "{YOUR JOB ID}"
    ...
}
```

This import leads to the following link in the MatchingDecisionLog.

```
{
   "id" : "{AUTO GENERATED}",
   "decisionLogId" : "b7d528eace273a10aeb00825f48b5b18",
   "entities" : [{
       "storageId": "b7d528eace273a10aeb00825f48b5b18",
       "dataSourceId": "5f9fc1b97e1e490001fcfc9e",
       "businessPartnerId": "5e60dfdbd5fa2d000166ab4a"
     },
     {
       "storageId": "b7d528eace273a10aeb00825f48b5b18",
       "dataSourceId": "5f9fc1b97e1e490001fcfc9e",
       "businessPartnerId": "5e60dfdbd5fa2d000166ab4b"
     }]
 }
```

```php
function startMatchingDecisionImportJob(array $options): ?MatchingDecisionImportJobModel
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `file` | `FileWrapper` | Form, Required | XLSX or CSV file to be uploaded (SOAP currently only supports CSV) |
| `decisionLogId` | `string` | Form, Required | Target MatchingDecisionLog ID for this import |
| `batchSize` | `?int` | Form, Optional | Defines the number of records that are processed at once.<br>**Constraints**: `>= 250`, `<= 1000` |

## Response Type

[`?MatchingDecisionImportJobModel`](../../doc/models/matching-decision-import-job-model.md)

## Example Usage

```php
$collect = [];

$file = 'dummy_file';
$collect['file'] = $file;

$decisionLogId = 'decisionLogId6';
$collect['decisionLogId'] = $decisionLogId;

$result = $userFeedbackController->startMatchingDecisionImportJob($collect);
```


# Delete User Feedback

Delete the Matching Decision Log identified by ID. Warning: action cannot be reverted!

```php
function deleteUserFeedback(string $id): void
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `string` | Template, Required | - |

## Response Type

`void`

## Example Usage

```php
$id = 'id0';
$userFeedbackController->deleteUserFeedback($id);
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | The sent request is malformed. | [`ApiErrorException`](../../doc/models/api-error-exception.md) |
| 403 | Permission denied. | [`ApiErrorException`](../../doc/models/api-error-exception.md) |


# Poll Matching Decision Import Job Status

Poll Matching Decision Import Job status

```php
function pollMatchingDecisionImportJobStatus(string $id): ?MatchingDecisionImportJobModel
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `string` | Template, Required | ID of the Matching Decision Import Job |

## Response Type

[`?MatchingDecisionImportJobModel`](../../doc/models/matching-decision-import-job-model.md)

## Example Usage

```php
$id = 'id0';
$result = $userFeedbackController->pollMatchingDecisionImportJobStatus($id);
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | `ApiException` |
| 403 | Forbidden | `ApiException` |


# Userfeedbacks Clear by Id POST

Remove all links from the Matching Decision Log identified by ID. Warning: action cannot be reverted!

```php
function userfeedbacksClearByIdPOST(string $id): void
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `string` | Template, Required | - |

## Response Type

`void`

## Example Usage

```php
$id = 'id0';
$userFeedbackController->userfeedbacksClearByIdPOST($id);
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | `ApiException` |
| 403 | Forbidden | `ApiException` |
| 404 | Not Found | `ApiException` |


# Create User Feedback

Create Matching Decision Log where decisions will be stored.

```php
function createUserFeedback(MatchingDecisionLogCreateRequestModel $body): ?MatchingDecisionLogModel
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`MatchingDecisionLogCreateRequestModel`](../../doc/models/matching-decision-log-create-request-model.md) | Body, Required | - |

## Response Type

[`?MatchingDecisionLogModel`](../../doc/models/matching-decision-log-model.md)

## Example Usage

```php
$body = new Models\MatchingDecisionLogCreateRequestModel;
$result = $userFeedbackController->createUserFeedback($body);
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | `ApiException` |
| 403 | Forbidden | `ApiException` |


# Read Identity Links

Read Identity Links from the Matching Decision Log identified by ID.

```php
function readIdentityLinks(array $options): ?IdentityLinksModel
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `decisionLogId` | `string` | Query, Required | - |
| `startAfter` | `?string` | Query, Optional | Indicator for the next page. Used together with nextStartAfter from the result. |
| `limit` | `?int` | Query, Optional | Number of items to be returned<br>**Default**: `20`<br>**Constraints**: `>= 1` |
| `storageId` | `?string` | Query, Optional | - |
| `dataSourceId` | `?string` | Query, Optional | - |
| `businessPartnerId` | `?string` | Query, Optional | - |

## Response Type

[`?IdentityLinksModel`](../../doc/models/identity-links-model.md)

## Example Usage

```php
$collect = [];

$decisionLogId = 'decisionLogId6';
$collect['decisionLogId'] = $decisionLogId;

$limit = 20;
$collect['limit'] = $limit;

$result = $userFeedbackController->readIdentityLinks($collect);
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | `ApiException` |
| 403 | Forbidden | `ApiException` |
| 404 | Not Found | `ApiException` |

