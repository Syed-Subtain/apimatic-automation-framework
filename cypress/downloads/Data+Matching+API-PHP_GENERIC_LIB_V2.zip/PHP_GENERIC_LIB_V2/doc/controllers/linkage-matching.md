# Linkage Matching

```php
$linkageMatchingController = $client->getLinkageMatchingController();
```

## Class Name

`LinkageMatchingController`

## Methods

* [Start Linkage Job](../../doc/controllers/linkage-matching.md#start-linkage-job)
* [Poll Linkage Job Status](../../doc/controllers/linkage-matching.md#poll-linkage-job-status)


# Start Linkage Job

Start linkage job

```php
function startLinkageJob(LinkMatchingJobRequestModel $body): ?LinkMatchingJobModel
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`LinkMatchingJobRequestModel`](../../doc/models/link-matching-job-request-model.md) | Body, Required | - |

## Response Type

[`?LinkMatchingJobModel`](../../doc/models/link-matching-job-model.md)

## Example Usage

```php
$body = new Models\LinkMatchingJobRequestModel;
$result = $linkageMatchingController->startLinkageJob($body);
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | `ApiException` |
| 403 | Forbidden | `ApiException` |


# Poll Linkage Job Status

Poll linkage job status

```php
function pollLinkageJobStatus(string $id): ?LinkMatchingJobModel
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `string` | Template, Required | ID of the linkage job |

## Response Type

[`?LinkMatchingJobModel`](../../doc/models/link-matching-job-model.md)

## Example Usage

```php
$id = 'id0';
$result = $linkageMatchingController->pollLinkageJobStatus($id);
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | `ApiException` |
| 403 | Forbidden | `ApiException` |

