<?php
/*
 * Calculator
 *
 * This file was automatically generated for Label by APIMATIC v3.0 ( https://www.apimatic.io ).
 */

namespace CalculatorLib\Tests;

use CalculatorLib\Exceptions\ApiException;
use CalculatorLib\Exceptions;
use CalculatorLib\ApiHelper;
use CalculatorLib\Models;
use PHPUnit\Framework\TestCase;

class UserFeedbackControllerTest extends TestCase
{
    /**
     * @var \CalculatorLib\Controllers\UserFeedbackController Controller instance
     */
    protected static $controller;

    /**
     * @var HttpCallBackCatcher Callback
     */
    protected static $httpResponse;

    /**
     * Setup test class
     */
    public static function setUpBeforeClass(): void
    {
        self::$httpResponse = new HttpCallBackCatcher();
        self::$controller = ClientFactory::create(self::$httpResponse)->getUserFeedbackController();
    }


    /**
     * Read available Matching Decision Logs across your organization.
     */
    public function testTestReadUserFeedbacks1()
    {
        // Parameters for the API call
        $input = array();
        $input['startAfter'] = null;
        $input['limit'] = 20;

        // Set callback and perform API call
        $result = null;
        try {
            $result = self::$controller->readUserFeedbacks($input);
        } catch (ApiException $e) {
        }

        // Test response code
        $this->assertEquals(
            201,
            self::$httpResponse->getResponse()->getStatusCode(),
            "Status is not 201"
        );
    }

    /**
     * Read available Matching Decision Logs across your organization.
     */
    public function testTestReadUserFeedbacks()
    {
        // Parameters for the API call
        $input = array();
        $input['startAfter'] = null;
        $input['limit'] = 20;

        // Set callback and perform API call
        $result = null;
        try {
            $result = self::$controller->readUserFeedbacks($input);
        } catch (ApiException $e) {
        }

        // Test response code
        $this->assertEquals(
            200,
            self::$httpResponse->getResponse()->getStatusCode(),
            "Status is not 200"
        );

        // Test headers
        $headers = [];
        $headers['Content-Type'] = 'application/json' ;
        
        $this->assertTrue(
            TestHelper::areHeadersProperSubsetOf($headers, self::$httpResponse->getResponse()->getHeaders(), true),
            "Headers do not match"
        );
    }
}
