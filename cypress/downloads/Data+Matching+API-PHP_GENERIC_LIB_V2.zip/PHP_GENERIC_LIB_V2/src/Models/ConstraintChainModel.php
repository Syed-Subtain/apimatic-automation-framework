<?php

declare(strict_types=1);

/*
 * Calculator
 *
 * This file was automatically generated for Label by APIMATIC v3.0 ( https://www.apimatic.io ).
 */

namespace CalculatorLib\Models;

use stdClass;

class ConstraintChainModel implements \JsonSerializable
{
    /**
     * @var RuleModel[]|null
     */
    private $constraints;

    /**
     * @var bool|null
     */
    private $allRecordsShouldMatch;

    /**
     * @var string|null
     */
    private $constraintChainType;

    /**
     * Returns Constraints.
     * List of attribute affected by this rule of enhancement
     *
     * @return RuleModel[]|null
     */
    public function getConstraints(): ?array
    {
        return $this->constraints;
    }

    /**
     * Sets Constraints.
     * List of attribute affected by this rule of enhancement
     *
     * @maps constraints
     *
     * @param RuleModel[]|null $constraints
     */
    public function setConstraints(?array $constraints): void
    {
        $this->constraints = $constraints;
    }

    /**
     * Returns All Records Should Match.
     */
    public function getAllRecordsShouldMatch(): ?bool
    {
        return $this->allRecordsShouldMatch;
    }

    /**
     * Sets All Records Should Match.
     *
     * @maps allRecordsShouldMatch
     */
    public function setAllRecordsShouldMatch(?bool $allRecordsShouldMatch): void
    {
        $this->allRecordsShouldMatch = $allRecordsShouldMatch;
    }

    /**
     * Returns Constraint Chain Type.
     */
    public function getConstraintChainType(): ?string
    {
        return $this->constraintChainType;
    }

    /**
     * Sets Constraint Chain Type.
     *
     * @maps constraintChainType
     * @factory \CalculatorLib\Models\ConstraintChainTypeEnum::checkValue
     */
    public function setConstraintChainType(?string $constraintChainType): void
    {
        $this->constraintChainType = $constraintChainType;
    }

    private $additionalProperties = [];

    /**
     * Add an additional property to this model.
     *
     * @param string $name Name of property
     * @param mixed $value Value of property
     */
    public function addAdditionalProperty(string $name, $value)
    {
        $this->additionalProperties[$name] = $value;
    }

    /**
     * Encode this object to JSON
     *
     * @param bool $asArrayWhenEmpty Whether to serialize this model as an array whenever no fields
     *        are set. (default: false)
     *
     * @return array|stdClass
     */
    #[\ReturnTypeWillChange] // @phan-suppress-current-line PhanUndeclaredClassAttribute for (php < 8.1)
    public function jsonSerialize(bool $asArrayWhenEmpty = false)
    {
        $json = [];
        if (isset($this->constraints)) {
            $json['constraints']           = $this->constraints;
        }
        if (isset($this->allRecordsShouldMatch)) {
            $json['allRecordsShouldMatch'] = $this->allRecordsShouldMatch;
        }
        if (isset($this->constraintChainType)) {
            $json['constraintChainType']   = ConstraintChainTypeEnum::checkValue($this->constraintChainType);
        }
        $json = array_merge($json, $this->additionalProperties);

        return (!$asArrayWhenEmpty && empty($json)) ? new stdClass() : $json;
    }
}
