<?php

declare(strict_types=1);

/*
 * Calculator
 *
 * This file was automatically generated for Label by APIMATIC v3.0 ( https://www.apimatic.io ).
 */

namespace CalculatorLib\Models;

use stdClass;

class BusinessPartnersMatchRequestModel implements \JsonSerializable
{
    /**
     * @var BusinessPartnerModel[]
     */
    private $candidates;

    /**
     * @var BusinessPartnerModel
     */
    private $pattern;

    /**
     * @var string|null
     */
    private $dataMatchingDefinitionId;

    /**
     * @param BusinessPartnerModel[] $candidates
     * @param BusinessPartnerModel $pattern
     */
    public function __construct(array $candidates, BusinessPartnerModel $pattern)
    {
        $this->candidates = $candidates;
        $this->pattern = $pattern;
    }

    /**
     * Returns Candidates.
     *
     * @return BusinessPartnerModel[]
     */
    public function getCandidates(): array
    {
        return $this->candidates;
    }

    /**
     * Sets Candidates.
     *
     * @required
     * @maps candidates
     *
     * @param BusinessPartnerModel[] $candidates
     */
    public function setCandidates(array $candidates): void
    {
        $this->candidates = $candidates;
    }

    /**
     * Returns Pattern.
     */
    public function getPattern(): BusinessPartnerModel
    {
        return $this->pattern;
    }

    /**
     * Sets Pattern.
     *
     * @required
     * @maps pattern
     */
    public function setPattern(BusinessPartnerModel $pattern): void
    {
        $this->pattern = $pattern;
    }

    /**
     * Returns Data Matching Definition Id.
     */
    public function getDataMatchingDefinitionId(): ?string
    {
        return $this->dataMatchingDefinitionId;
    }

    /**
     * Sets Data Matching Definition Id.
     *
     * @maps dataMatchingDefinitionId
     */
    public function setDataMatchingDefinitionId(?string $dataMatchingDefinitionId): void
    {
        $this->dataMatchingDefinitionId = $dataMatchingDefinitionId;
    }

    private $additionalProperties = [];

    /**
     * Add an additional property to this model.
     *
     * @param string $name Name of property
     * @param mixed $value Value of property
     */
    public function addAdditionalProperty(string $name, $value)
    {
        $this->additionalProperties[$name] = $value;
    }

    /**
     * Encode this object to JSON
     *
     * @param bool $asArrayWhenEmpty Whether to serialize this model as an array whenever no fields
     *        are set. (default: false)
     *
     * @return array|stdClass
     */
    #[\ReturnTypeWillChange] // @phan-suppress-current-line PhanUndeclaredClassAttribute for (php < 8.1)
    public function jsonSerialize(bool $asArrayWhenEmpty = false)
    {
        $json = [];
        $json['candidates']                   = $this->candidates;
        $json['pattern']                      = $this->pattern;
        if (isset($this->dataMatchingDefinitionId)) {
            $json['dataMatchingDefinitionId'] = $this->dataMatchingDefinitionId;
        }
        $json = array_merge($json, $this->additionalProperties);

        return (!$asArrayWhenEmpty && empty($json)) ? new stdClass() : $json;
    }
}
