<?php

declare(strict_types=1);

/*
 * Calculator
 *
 * This file was automatically generated for Label by APIMATIC v3.0 ( https://www.apimatic.io ).
 */

namespace CalculatorLib\Models;

use stdClass;

class AddressModel implements \JsonSerializable
{
    /**
     * @var string|null
     */
    private $externalId;

    /**
     * @var CountryModel|null
     */
    private $country;

    /**
     * @var AdministrativeAreaModel[]|null
     */
    private $administrativeAreas;

    /**
     * @var PostCodeModel|null
     */
    private $postCode;

    /**
     * @var LocalityModel[]|null
     */
    private $localities;

    /**
     * @var ThoroughfareModel[]|null
     */
    private $thoroughfares;

    /**
     * @var PremiseModel[]|null
     */
    private $premises;

    /**
     * @var PostalDeliveryPointModel|null
     */
    private $postalDeliveryPoint;

    /**
     * Returns External Id.
     */
    public function getExternalId(): ?string
    {
        return $this->externalId;
    }

    /**
     * Sets External Id.
     *
     * @maps externalId
     */
    public function setExternalId(?string $externalId): void
    {
        $this->externalId = $externalId;
    }

    /**
     * Returns Country.
     * Country consisting of the country name and country code (ISO 3166-1 alpha-2).
     */
    public function getCountry(): ?CountryModel
    {
        return $this->country;
    }

    /**
     * Sets Country.
     * Country consisting of the country name and country code (ISO 3166-1 alpha-2).
     *
     * @maps country
     */
    public function setCountry(?CountryModel $country): void
    {
        $this->country = $country;
    }

    /**
     * Returns Administrative Areas.
     *
     * @return AdministrativeAreaModel[]|null
     */
    public function getAdministrativeAreas(): ?array
    {
        return $this->administrativeAreas;
    }

    /**
     * Sets Administrative Areas.
     *
     * @maps administrativeAreas
     *
     * @param AdministrativeAreaModel[]|null $administrativeAreas
     */
    public function setAdministrativeAreas(?array $administrativeAreas): void
    {
        $this->administrativeAreas = $administrativeAreas;
    }

    /**
     * Returns Post Code.
     */
    public function getPostCode(): ?PostCodeModel
    {
        return $this->postCode;
    }

    /**
     * Sets Post Code.
     *
     * @maps postCode
     */
    public function setPostCode(?PostCodeModel $postCode): void
    {
        $this->postCode = $postCode;
    }

    /**
     * Returns Localities.
     *
     * @return LocalityModel[]|null
     */
    public function getLocalities(): ?array
    {
        return $this->localities;
    }

    /**
     * Sets Localities.
     *
     * @maps localities
     *
     * @param LocalityModel[]|null $localities
     */
    public function setLocalities(?array $localities): void
    {
        $this->localities = $localities;
    }

    /**
     * Returns Thoroughfares.
     *
     * @return ThoroughfareModel[]|null
     */
    public function getThoroughfares(): ?array
    {
        return $this->thoroughfares;
    }

    /**
     * Sets Thoroughfares.
     *
     * @maps thoroughfares
     *
     * @param ThoroughfareModel[]|null $thoroughfares
     */
    public function setThoroughfares(?array $thoroughfares): void
    {
        $this->thoroughfares = $thoroughfares;
    }

    /**
     * Returns Premises.
     *
     * @return PremiseModel[]|null
     */
    public function getPremises(): ?array
    {
        return $this->premises;
    }

    /**
     * Sets Premises.
     *
     * @maps premises
     *
     * @param PremiseModel[]|null $premises
     */
    public function setPremises(?array $premises): void
    {
        $this->premises = $premises;
    }

    /**
     * Returns Postal Delivery Point.
     */
    public function getPostalDeliveryPoint(): ?PostalDeliveryPointModel
    {
        return $this->postalDeliveryPoint;
    }

    /**
     * Sets Postal Delivery Point.
     *
     * @maps postalDeliveryPoint
     */
    public function setPostalDeliveryPoint(?PostalDeliveryPointModel $postalDeliveryPoint): void
    {
        $this->postalDeliveryPoint = $postalDeliveryPoint;
    }

    private $additionalProperties = [];

    /**
     * Add an additional property to this model.
     *
     * @param string $name Name of property
     * @param mixed $value Value of property
     */
    public function addAdditionalProperty(string $name, $value)
    {
        $this->additionalProperties[$name] = $value;
    }

    /**
     * Encode this object to JSON
     *
     * @param bool $asArrayWhenEmpty Whether to serialize this model as an array whenever no fields
     *        are set. (default: false)
     *
     * @return array|stdClass
     */
    #[\ReturnTypeWillChange] // @phan-suppress-current-line PhanUndeclaredClassAttribute for (php < 8.1)
    public function jsonSerialize(bool $asArrayWhenEmpty = false)
    {
        $json = [];
        if (isset($this->externalId)) {
            $json['externalId']          = $this->externalId;
        }
        if (isset($this->country)) {
            $json['country']             = $this->country;
        }
        if (isset($this->administrativeAreas)) {
            $json['administrativeAreas'] = $this->administrativeAreas;
        }
        if (isset($this->postCode)) {
            $json['postCode']            = $this->postCode;
        }
        if (isset($this->localities)) {
            $json['localities']          = $this->localities;
        }
        if (isset($this->thoroughfares)) {
            $json['thoroughfares']       = $this->thoroughfares;
        }
        if (isset($this->premises)) {
            $json['premises']            = $this->premises;
        }
        if (isset($this->postalDeliveryPoint)) {
            $json['postalDeliveryPoint'] = $this->postalDeliveryPoint;
        }
        $json = array_merge($json, $this->additionalProperties);

        return (!$asArrayWhenEmpty && empty($json)) ? new stdClass() : $json;
    }
}
