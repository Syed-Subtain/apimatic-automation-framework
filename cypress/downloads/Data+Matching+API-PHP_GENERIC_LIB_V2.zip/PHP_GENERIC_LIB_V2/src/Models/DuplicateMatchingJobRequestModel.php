<?php

declare(strict_types=1);

/*
 * Calculator
 *
 * This file was automatically generated for Label by APIMATIC v3.0 ( https://www.apimatic.io ).
 */

namespace CalculatorLib\Models;

use stdClass;

class DuplicateMatchingJobRequestModel implements \JsonSerializable
{
    /**
     * @var string|null
     */
    private $storageId;

    /**
     * @var string[]|null
     */
    private $countries;

    /**
     * @var string[]|null
     */
    private $dataSourceIds;

    /**
     * @var string|null
     */
    private $dataMatchingDefinitionId;

    /**
     * @var string[]|null
     */
    private $decisionLogIds;

    /**
     * @var MatchingReportPropertiesModel|null
     */
    private $duplicateMatchingReportProperties;

    /**
     * @var MatchingDukePropertiesModel|null
     */
    private $duplicateMatchingDukeProperties;

    /**
     * Returns Storage Id.
     */
    public function getStorageId(): ?string
    {
        return $this->storageId;
    }

    /**
     * Sets Storage Id.
     *
     * @maps storageId
     */
    public function setStorageId(?string $storageId): void
    {
        $this->storageId = $storageId;
    }

    /**
     * Returns Countries.
     * If set, only the records that belong to the countries identified by these short names are processed.
     * By default all records of the storage (means from all countries) are processed (considering other
     * filters).
     *
     * @return string[]|null
     */
    public function getCountries(): ?array
    {
        return $this->countries;
    }

    /**
     * Sets Countries.
     * If set, only the records that belong to the countries identified by these short names are processed.
     * By default all records of the storage (means from all countries) are processed (considering other
     * filters).
     *
     * @maps countries
     *
     * @param string[]|null $countries
     */
    public function setCountries(?array $countries): void
    {
        $this->countries = $countries;
    }

    /**
     * Returns Data Source Ids.
     * If set, only the records that belong to the data sources identified by these IDs are processed. By
     * default all records of the storage (means from all data sources) are processed (considering other
     * filters).
     *
     * @return string[]|null
     */
    public function getDataSourceIds(): ?array
    {
        return $this->dataSourceIds;
    }

    /**
     * Sets Data Source Ids.
     * If set, only the records that belong to the data sources identified by these IDs are processed. By
     * default all records of the storage (means from all data sources) are processed (considering other
     * filters).
     *
     * @maps dataSourceIds
     *
     * @param string[]|null $dataSourceIds
     */
    public function setDataSourceIds(?array $dataSourceIds): void
    {
        $this->dataSourceIds = $dataSourceIds;
    }

    /**
     * Returns Data Matching Definition Id.
     */
    public function getDataMatchingDefinitionId(): ?string
    {
        return $this->dataMatchingDefinitionId;
    }

    /**
     * Sets Data Matching Definition Id.
     *
     * @maps dataMatchingDefinitionId
     */
    public function setDataMatchingDefinitionId(?string $dataMatchingDefinitionId): void
    {
        $this->dataMatchingDefinitionId = $dataMatchingDefinitionId;
    }

    /**
     * Returns Decision Log Ids.
     * If set, feedback from listed Matching Decision Logs will be considered.
     *
     * @return string[]|null
     */
    public function getDecisionLogIds(): ?array
    {
        return $this->decisionLogIds;
    }

    /**
     * Sets Decision Log Ids.
     * If set, feedback from listed Matching Decision Logs will be considered.
     *
     * @maps decisionLogIds
     *
     * @param string[]|null $decisionLogIds
     */
    public function setDecisionLogIds(?array $decisionLogIds): void
    {
        $this->decisionLogIds = $decisionLogIds;
    }

    /**
     * Returns Duplicate Matching Report Properties.
     */
    public function getDuplicateMatchingReportProperties(): ?MatchingReportPropertiesModel
    {
        return $this->duplicateMatchingReportProperties;
    }

    /**
     * Sets Duplicate Matching Report Properties.
     *
     * @maps duplicateMatchingReportProperties
     */
    public function setDuplicateMatchingReportProperties(
        ?MatchingReportPropertiesModel $duplicateMatchingReportProperties
    ): void {
        $this->duplicateMatchingReportProperties = $duplicateMatchingReportProperties;
    }

    /**
     * Returns Duplicate Matching Duke Properties.
     */
    public function getDuplicateMatchingDukeProperties(): ?MatchingDukePropertiesModel
    {
        return $this->duplicateMatchingDukeProperties;
    }

    /**
     * Sets Duplicate Matching Duke Properties.
     *
     * @maps duplicateMatchingDukeProperties
     */
    public function setDuplicateMatchingDukeProperties(
        ?MatchingDukePropertiesModel $duplicateMatchingDukeProperties
    ): void {
        $this->duplicateMatchingDukeProperties = $duplicateMatchingDukeProperties;
    }

    private $additionalProperties = [];

    /**
     * Add an additional property to this model.
     *
     * @param string $name Name of property
     * @param mixed $value Value of property
     */
    public function addAdditionalProperty(string $name, $value)
    {
        $this->additionalProperties[$name] = $value;
    }

    /**
     * Encode this object to JSON
     *
     * @param bool $asArrayWhenEmpty Whether to serialize this model as an array whenever no fields
     *        are set. (default: false)
     *
     * @return array|stdClass
     */
    #[\ReturnTypeWillChange] // @phan-suppress-current-line PhanUndeclaredClassAttribute for (php < 8.1)
    public function jsonSerialize(bool $asArrayWhenEmpty = false)
    {
        $json = [];
        if (isset($this->storageId)) {
            $json['storageId']                         = $this->storageId;
        }
        if (isset($this->countries)) {
            $json['countries']                         = $this->countries;
        }
        if (isset($this->dataSourceIds)) {
            $json['dataSourceIds']                     = $this->dataSourceIds;
        }
        if (isset($this->dataMatchingDefinitionId)) {
            $json['dataMatchingDefinitionId']          = $this->dataMatchingDefinitionId;
        }
        if (isset($this->decisionLogIds)) {
            $json['decisionLogIds']                    = $this->decisionLogIds;
        }
        if (isset($this->duplicateMatchingReportProperties)) {
            $json['duplicateMatchingReportProperties'] = $this->duplicateMatchingReportProperties;
        }
        if (isset($this->duplicateMatchingDukeProperties)) {
            $json['duplicateMatchingDukeProperties']   = $this->duplicateMatchingDukeProperties;
        }
        $json = array_merge($json, $this->additionalProperties);

        return (!$asArrayWhenEmpty && empty($json)) ? new stdClass() : $json;
    }
}
