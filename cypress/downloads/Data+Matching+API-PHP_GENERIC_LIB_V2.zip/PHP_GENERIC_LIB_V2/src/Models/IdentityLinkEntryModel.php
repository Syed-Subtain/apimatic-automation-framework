<?php

declare(strict_types=1);

/*
 * Calculator
 *
 * This file was automatically generated for Label by APIMATIC v3.0 ( https://www.apimatic.io ).
 */

namespace CalculatorLib\Models;

use stdClass;

class IdentityLinkEntryModel implements \JsonSerializable
{
    /**
     * @var string
     */
    private $storageId;

    /**
     * @var string
     */
    private $dataSourceId;

    /**
     * @var string
     */
    private $businessPartnerId;

    /**
     * @param string $storageId
     * @param string $dataSourceId
     * @param string $businessPartnerId
     */
    public function __construct(string $storageId, string $dataSourceId, string $businessPartnerId)
    {
        $this->storageId = $storageId;
        $this->dataSourceId = $dataSourceId;
        $this->businessPartnerId = $businessPartnerId;
    }

    /**
     * Returns Storage Id.
     */
    public function getStorageId(): string
    {
        return $this->storageId;
    }

    /**
     * Sets Storage Id.
     *
     * @required
     * @maps storageId
     */
    public function setStorageId(string $storageId): void
    {
        $this->storageId = $storageId;
    }

    /**
     * Returns Data Source Id.
     */
    public function getDataSourceId(): string
    {
        return $this->dataSourceId;
    }

    /**
     * Sets Data Source Id.
     *
     * @required
     * @maps dataSourceId
     */
    public function setDataSourceId(string $dataSourceId): void
    {
        $this->dataSourceId = $dataSourceId;
    }

    /**
     * Returns Business Partner Id.
     */
    public function getBusinessPartnerId(): string
    {
        return $this->businessPartnerId;
    }

    /**
     * Sets Business Partner Id.
     *
     * @required
     * @maps businessPartnerId
     */
    public function setBusinessPartnerId(string $businessPartnerId): void
    {
        $this->businessPartnerId = $businessPartnerId;
    }

    private $additionalProperties = [];

    /**
     * Add an additional property to this model.
     *
     * @param string $name Name of property
     * @param mixed $value Value of property
     */
    public function addAdditionalProperty(string $name, $value)
    {
        $this->additionalProperties[$name] = $value;
    }

    /**
     * Encode this object to JSON
     *
     * @param bool $asArrayWhenEmpty Whether to serialize this model as an array whenever no fields
     *        are set. (default: false)
     *
     * @return array|stdClass
     */
    #[\ReturnTypeWillChange] // @phan-suppress-current-line PhanUndeclaredClassAttribute for (php < 8.1)
    public function jsonSerialize(bool $asArrayWhenEmpty = false)
    {
        $json = [];
        $json['storageId']         = $this->storageId;
        $json['dataSourceId']      = $this->dataSourceId;
        $json['businessPartnerId'] = $this->businessPartnerId;
        $json = array_merge($json, $this->additionalProperties);

        return (!$asArrayWhenEmpty && empty($json)) ? new stdClass() : $json;
    }
}
