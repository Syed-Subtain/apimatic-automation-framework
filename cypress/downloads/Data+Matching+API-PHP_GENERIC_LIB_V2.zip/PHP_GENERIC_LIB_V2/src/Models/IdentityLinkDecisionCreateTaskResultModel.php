<?php

declare(strict_types=1);

/*
 * Calculator
 *
 * This file was automatically generated for Label by APIMATIC v3.0 ( https://www.apimatic.io ).
 */

namespace CalculatorLib\Models;

use stdClass;

class IdentityLinkDecisionCreateTaskResultModel implements \JsonSerializable
{
    /**
     * @var string|null
     */
    private $worker;

    /**
     * @var string|null
     */
    private $status;

    /**
     * @var string|null
     */
    private $message;

    /**
     * @var IdentityLinkDecisionCreateResultModel|null
     */
    private $result;

    /**
     * Returns Worker.
     * Worker which generated the result
     */
    public function getWorker(): ?string
    {
        return $this->worker;
    }

    /**
     * Sets Worker.
     * Worker which generated the result
     *
     * @maps worker
     */
    public function setWorker(?string $worker): void
    {
        $this->worker = $worker;
    }

    /**
     * Returns Status.
     * status:
     * * `OK` - Task has been processed succesful
     * * `FAILED` - Task has been failed
     */
    public function getStatus(): ?string
    {
        return $this->status;
    }

    /**
     * Sets Status.
     * status:
     * * `OK` - Task has been processed succesful
     * * `FAILED` - Task has been failed
     *
     * @maps status
     */
    public function setStatus(?string $status): void
    {
        $this->status = $status;
    }

    /**
     * Returns Message.
     * Details task status
     */
    public function getMessage(): ?string
    {
        return $this->message;
    }

    /**
     * Sets Message.
     * Details task status
     *
     * @maps message
     */
    public function setMessage(?string $message): void
    {
        $this->message = $message;
    }

    /**
     * Returns Result.
     */
    public function getResult(): ?IdentityLinkDecisionCreateResultModel
    {
        return $this->result;
    }

    /**
     * Sets Result.
     *
     * @maps result
     */
    public function setResult(?IdentityLinkDecisionCreateResultModel $result): void
    {
        $this->result = $result;
    }

    private $additionalProperties = [];

    /**
     * Add an additional property to this model.
     *
     * @param string $name Name of property
     * @param mixed $value Value of property
     */
    public function addAdditionalProperty(string $name, $value)
    {
        $this->additionalProperties[$name] = $value;
    }

    /**
     * Encode this object to JSON
     *
     * @param bool $asArrayWhenEmpty Whether to serialize this model as an array whenever no fields
     *        are set. (default: false)
     *
     * @return array|stdClass
     */
    #[\ReturnTypeWillChange] // @phan-suppress-current-line PhanUndeclaredClassAttribute for (php < 8.1)
    public function jsonSerialize(bool $asArrayWhenEmpty = false)
    {
        $json = [];
        if (isset($this->worker)) {
            $json['worker']  = $this->worker;
        }
        if (isset($this->status)) {
            $json['status']  = $this->status;
        }
        if (isset($this->message)) {
            $json['message'] = $this->message;
        }
        if (isset($this->result)) {
            $json['result']  = $this->result;
        }
        $json = array_merge($json, $this->additionalProperties);

        return (!$asArrayWhenEmpty && empty($json)) ? new stdClass() : $json;
    }
}
