<?php

declare(strict_types=1);

/*
 * Calculator
 *
 * This file was automatically generated for Label by APIMATIC v3.0 ( https://www.apimatic.io ).
 */

namespace CalculatorLib\Models;

use stdClass;

class DataMatchingDefinitionModel implements \JsonSerializable
{
    /**
     * @var string|null
     */
    private $id;

    /**
     * @var string|null
     */
    private $name;

    /**
     * @var string|null
     */
    private $creatorUsername;

    /**
     * @var string|null
     */
    private $creatorOrganization;

    /**
     * @var string|null
     */
    private $createdAt;

    /**
     * @var string|null
     */
    private $lastModifiedAt;

    /**
     * @var string|null
     */
    private $type;

    /**
     * @var string|null
     */
    private $xmlDukeConfiguration;

    /**
     * @var ReportConfigurationModel|null
     */
    private $reportConfiguration;

    /**
     * @var GoldenRecordConfigurationModel|null
     */
    private $goldenRecordConfiguration;

    /**
     * @var WorkspaceModel|null
     */
    private $workspace;

    /**
     * Returns Id.
     */
    public function getId(): ?string
    {
        return $this->id;
    }

    /**
     * Sets Id.
     *
     * @maps id
     */
    public function setId(?string $id): void
    {
        $this->id = $id;
    }

    /**
     * Returns Name.
     * Human readable name.
     */
    public function getName(): ?string
    {
        return $this->name;
    }

    /**
     * Sets Name.
     * Human readable name.
     *
     * @maps name
     */
    public function setName(?string $name): void
    {
        $this->name = $name;
    }

    /**
     * Returns Creator Username.
     */
    public function getCreatorUsername(): ?string
    {
        return $this->creatorUsername;
    }

    /**
     * Sets Creator Username.
     *
     * @maps creatorUsername
     */
    public function setCreatorUsername(?string $creatorUsername): void
    {
        $this->creatorUsername = $creatorUsername;
    }

    /**
     * Returns Creator Organization.
     */
    public function getCreatorOrganization(): ?string
    {
        return $this->creatorOrganization;
    }

    /**
     * Sets Creator Organization.
     *
     * @maps creatorOrganization
     */
    public function setCreatorOrganization(?string $creatorOrganization): void
    {
        $this->creatorOrganization = $creatorOrganization;
    }

    /**
     * Returns Created At.
     */
    public function getCreatedAt(): ?string
    {
        return $this->createdAt;
    }

    /**
     * Sets Created At.
     *
     * @maps createdAt
     */
    public function setCreatedAt(?string $createdAt): void
    {
        $this->createdAt = $createdAt;
    }

    /**
     * Returns Last Modified At.
     */
    public function getLastModifiedAt(): ?string
    {
        return $this->lastModifiedAt;
    }

    /**
     * Sets Last Modified At.
     *
     * @maps lastModifiedAt
     */
    public function setLastModifiedAt(?string $lastModifiedAt): void
    {
        $this->lastModifiedAt = $lastModifiedAt;
    }

    /**
     * Returns Type.
     */
    public function getType(): ?string
    {
        return $this->type;
    }

    /**
     * Sets Type.
     *
     * @maps type
     * @factory \CalculatorLib\Models\MatchingTypeEnum::checkValue
     */
    public function setType(?string $type): void
    {
        $this->type = $type;
    }

    /**
     * Returns Xml Duke Configuration.
     * Duke XML matching configuration
     */
    public function getXmlDukeConfiguration(): ?string
    {
        return $this->xmlDukeConfiguration;
    }

    /**
     * Sets Xml Duke Configuration.
     * Duke XML matching configuration
     *
     * @maps xmlDukeConfiguration
     */
    public function setXmlDukeConfiguration(?string $xmlDukeConfiguration): void
    {
        $this->xmlDukeConfiguration = $xmlDukeConfiguration;
    }

    /**
     * Returns Report Configuration.
     */
    public function getReportConfiguration(): ?ReportConfigurationModel
    {
        return $this->reportConfiguration;
    }

    /**
     * Sets Report Configuration.
     *
     * @maps reportConfiguration
     */
    public function setReportConfiguration(?ReportConfigurationModel $reportConfiguration): void
    {
        $this->reportConfiguration = $reportConfiguration;
    }

    /**
     * Returns Golden Record Configuration.
     */
    public function getGoldenRecordConfiguration(): ?GoldenRecordConfigurationModel
    {
        return $this->goldenRecordConfiguration;
    }

    /**
     * Sets Golden Record Configuration.
     *
     * @maps goldenRecordConfiguration
     */
    public function setGoldenRecordConfiguration(?GoldenRecordConfigurationModel $goldenRecordConfiguration): void
    {
        $this->goldenRecordConfiguration = $goldenRecordConfiguration;
    }

    /**
     * Returns Workspace.
     */
    public function getWorkspace(): ?WorkspaceModel
    {
        return $this->workspace;
    }

    /**
     * Sets Workspace.
     *
     * @maps workspace
     */
    public function setWorkspace(?WorkspaceModel $workspace): void
    {
        $this->workspace = $workspace;
    }

    private $additionalProperties = [];

    /**
     * Add an additional property to this model.
     *
     * @param string $name Name of property
     * @param mixed $value Value of property
     */
    public function addAdditionalProperty(string $name, $value)
    {
        $this->additionalProperties[$name] = $value;
    }

    /**
     * Encode this object to JSON
     *
     * @param bool $asArrayWhenEmpty Whether to serialize this model as an array whenever no fields
     *        are set. (default: false)
     *
     * @return array|stdClass
     */
    #[\ReturnTypeWillChange] // @phan-suppress-current-line PhanUndeclaredClassAttribute for (php < 8.1)
    public function jsonSerialize(bool $asArrayWhenEmpty = false)
    {
        $json = [];
        if (isset($this->id)) {
            $json['id']                        = $this->id;
        }
        if (isset($this->name)) {
            $json['name']                      = $this->name;
        }
        if (isset($this->creatorUsername)) {
            $json['creatorUsername']           = $this->creatorUsername;
        }
        if (isset($this->creatorOrganization)) {
            $json['creatorOrganization']       = $this->creatorOrganization;
        }
        if (isset($this->createdAt)) {
            $json['createdAt']                 = $this->createdAt;
        }
        if (isset($this->lastModifiedAt)) {
            $json['lastModifiedAt']            = $this->lastModifiedAt;
        }
        if (isset($this->type)) {
            $json['type']                      = MatchingTypeEnum::checkValue($this->type);
        }
        if (isset($this->xmlDukeConfiguration)) {
            $json['xmlDukeConfiguration']      = $this->xmlDukeConfiguration;
        }
        if (isset($this->reportConfiguration)) {
            $json['reportConfiguration']       = $this->reportConfiguration;
        }
        if (isset($this->goldenRecordConfiguration)) {
            $json['goldenRecordConfiguration'] = $this->goldenRecordConfiguration;
        }
        if (isset($this->workspace)) {
            $json['workspace']                 = $this->workspace;
        }
        $json = array_merge($json, $this->additionalProperties);

        return (!$asArrayWhenEmpty && empty($json)) ? new stdClass() : $json;
    }
}
