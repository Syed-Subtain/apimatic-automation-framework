<?php

declare(strict_types=1);

/*
 * Calculator
 *
 * This file was automatically generated for Label by APIMATIC v3.0 ( https://www.apimatic.io ).
 */

namespace CalculatorLib\Models;

use CalculatorLib\ApiHelper;
use Exception;
use stdClass;

class RuleTypeEnum
{
    public const HAS_VALUE = 'HAS_VALUE';

    public const HAS_NOT_VALUE = 'HAS_NOT_VALUE';

    public const HAS_VALUE_IN = 'HAS_VALUE_IN';

    public const HAS_NOT_VALUE_IN = 'HAS_NOT_VALUE_IN';

    public const HAS_VALUE_LIKE = 'HAS_VALUE_LIKE';

    public const HAS_NOT_VALUE_LIKE = 'HAS_NOT_VALUE_LIKE';

    public const HAS_HIGHEST_VALUE = 'HAS_HIGHEST_VALUE';

    public const HAS_LOWEST_VALUE = 'HAS_LOWEST_VALUE';

    public const IS_MARKED = 'IS_MARKED';

    public const IS_NOT_MARKED = 'IS_NOT_MARKED';

    public const IS_MOST_COMPLETE = 'IS_MOST_COMPLETE';

    public const HAS_HIGHEST_MATCH_SCORE = 'HAS_HIGHEST_MATCH_SCORE';

    private const _ALL_VALUES = [
        self::HAS_VALUE,
        self::HAS_NOT_VALUE,
        self::HAS_VALUE_IN,
        self::HAS_NOT_VALUE_IN,
        self::HAS_VALUE_LIKE,
        self::HAS_NOT_VALUE_LIKE,
        self::HAS_HIGHEST_VALUE,
        self::HAS_LOWEST_VALUE,
        self::IS_MARKED,
        self::IS_NOT_MARKED,
        self::IS_MOST_COMPLETE,
        self::HAS_HIGHEST_MATCH_SCORE,
    ];

    /**
     * Ensures that all the given values are present in this Enum.
     *
     * @param array|stdClass|null|string $value Value or a list/map of values to be checked
     *
     * @return array|null|string Input value(s), if all are a part of this Enum
     *
     * @throws Exception Throws exception if any given value is not in this Enum
     */
    public static function checkValue($value)
    {
        $value = json_decode(json_encode($value), true); // converts stdClass into array
        ApiHelper::checkValueInEnum($value, self::class, self::_ALL_VALUES);
        return $value;
    }
}
