<?php

declare(strict_types=1);

/*
 * Calculator
 *
 * This file was automatically generated for Label by APIMATIC v3.0 ( https://www.apimatic.io ).
 */

namespace CalculatorLib\Models;

use stdClass;

class BusinessPartnerModel implements \JsonSerializable
{
    /**
     * @var string|null
     */
    private $id;

    /**
     * @var NameModel[]|null
     */
    private $names;

    /**
     * @var LegalFormModel|null
     */
    private $legalForm;

    /**
     * @var IdentifierModel[]|null
     */
    private $identifiers;

    /**
     * @var AddressModel|null
     */
    private $address;

    /**
     * @var string|null
     */
    private $externalId;

    /**
     * @var string|null
     */
    private $dataSource;

    /**
     * @var string|null
     */
    private $record;

    /**
     * Returns Id.
     */
    public function getId(): ?string
    {
        return $this->id;
    }

    /**
     * Sets Id.
     *
     * @maps id
     */
    public function setId(?string $id): void
    {
        $this->id = $id;
    }

    /**
     * Returns Names.
     *
     * @return NameModel[]|null
     */
    public function getNames(): ?array
    {
        return $this->names;
    }

    /**
     * Sets Names.
     *
     * @maps names
     *
     * @param NameModel[]|null $names
     */
    public function setNames(?array $names): void
    {
        $this->names = $names;
    }

    /**
     * Returns Legal Form.
     */
    public function getLegalForm(): ?LegalFormModel
    {
        return $this->legalForm;
    }

    /**
     * Sets Legal Form.
     *
     * @maps legalForm
     */
    public function setLegalForm(?LegalFormModel $legalForm): void
    {
        $this->legalForm = $legalForm;
    }

    /**
     * Returns Identifiers.
     *
     * @return IdentifierModel[]|null
     */
    public function getIdentifiers(): ?array
    {
        return $this->identifiers;
    }

    /**
     * Sets Identifiers.
     *
     * @maps identifiers
     *
     * @param IdentifierModel[]|null $identifiers
     */
    public function setIdentifiers(?array $identifiers): void
    {
        $this->identifiers = $identifiers;
    }

    /**
     * Returns Address.
     */
    public function getAddress(): ?AddressModel
    {
        return $this->address;
    }

    /**
     * Sets Address.
     *
     * @maps address
     */
    public function setAddress(?AddressModel $address): void
    {
        $this->address = $address;
    }

    /**
     * Returns External Id.
     * ID the record has in the external system where the record originates from.
     */
    public function getExternalId(): ?string
    {
        return $this->externalId;
    }

    /**
     * Sets External Id.
     * ID the record has in the external system where the record originates from.
     *
     * @maps externalId
     */
    public function setExternalId(?string $externalId): void
    {
        $this->externalId = $externalId;
    }

    /**
     * Returns Data Source.
     * Name of the associated external system where the record originates from.
     */
    public function getDataSource(): ?string
    {
        return $this->dataSource;
    }

    /**
     * Sets Data Source.
     * Name of the associated external system where the record originates from.
     *
     * @maps dataSource
     */
    public function setDataSource(?string $dataSource): void
    {
        $this->dataSource = $dataSource;
    }

    /**
     * Returns Record.
     * Stringified JSON of an individual business partner record.
     */
    public function getRecord(): ?string
    {
        return $this->record;
    }

    /**
     * Sets Record.
     * Stringified JSON of an individual business partner record.
     *
     * @maps record
     */
    public function setRecord(?string $record): void
    {
        $this->record = $record;
    }

    private $additionalProperties = [];

    /**
     * Add an additional property to this model.
     *
     * @param string $name Name of property
     * @param mixed $value Value of property
     */
    public function addAdditionalProperty(string $name, $value)
    {
        $this->additionalProperties[$name] = $value;
    }

    /**
     * Encode this object to JSON
     *
     * @param bool $asArrayWhenEmpty Whether to serialize this model as an array whenever no fields
     *        are set. (default: false)
     *
     * @return array|stdClass
     */
    #[\ReturnTypeWillChange] // @phan-suppress-current-line PhanUndeclaredClassAttribute for (php < 8.1)
    public function jsonSerialize(bool $asArrayWhenEmpty = false)
    {
        $json = [];
        if (isset($this->id)) {
            $json['id']          = $this->id;
        }
        if (isset($this->names)) {
            $json['names']       = $this->names;
        }
        if (isset($this->legalForm)) {
            $json['legalForm']   = $this->legalForm;
        }
        if (isset($this->identifiers)) {
            $json['identifiers'] = $this->identifiers;
        }
        if (isset($this->address)) {
            $json['address']     = $this->address;
        }
        if (isset($this->externalId)) {
            $json['externalId']  = $this->externalId;
        }
        if (isset($this->dataSource)) {
            $json['dataSource']  = $this->dataSource;
        }
        if (isset($this->record)) {
            $json['record']      = $this->record;
        }
        $json = array_merge($json, $this->additionalProperties);

        return (!$asArrayWhenEmpty && empty($json)) ? new stdClass() : $json;
    }
}
