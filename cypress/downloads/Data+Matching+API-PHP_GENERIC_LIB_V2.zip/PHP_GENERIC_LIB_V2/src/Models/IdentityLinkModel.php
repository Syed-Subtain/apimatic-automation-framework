<?php

declare(strict_types=1);

/*
 * Calculator
 *
 * This file was automatically generated for Label by APIMATIC v3.0 ( https://www.apimatic.io ).
 */

namespace CalculatorLib\Models;

use stdClass;

class IdentityLinkModel implements \JsonSerializable
{
    /**
     * @var string|null
     */
    private $id;

    /**
     * @var string|null
     */
    private $decisionLogId;

    /**
     * @var string|null
     */
    private $createdAt;

    /**
     * @var string|null
     */
    private $createdBy;

    /**
     * @var string|null
     */
    private $linkStatus;

    /**
     * @var string|null
     */
    private $linkKind;

    /**
     * @var IdentityLinkEntryModel|null
     */
    private $entityA;

    /**
     * @var IdentityLinkEntryModel|null
     */
    private $entityB;

    /**
     * Returns Id.
     */
    public function getId(): ?string
    {
        return $this->id;
    }

    /**
     * Sets Id.
     *
     * @maps id
     */
    public function setId(?string $id): void
    {
        $this->id = $id;
    }

    /**
     * Returns Decision Log Id.
     */
    public function getDecisionLogId(): ?string
    {
        return $this->decisionLogId;
    }

    /**
     * Sets Decision Log Id.
     *
     * @maps decisionLogId
     */
    public function setDecisionLogId(?string $decisionLogId): void
    {
        $this->decisionLogId = $decisionLogId;
    }

    /**
     * Returns Created At.
     */
    public function getCreatedAt(): ?string
    {
        return $this->createdAt;
    }

    /**
     * Sets Created At.
     *
     * @maps createdAt
     */
    public function setCreatedAt(?string $createdAt): void
    {
        $this->createdAt = $createdAt;
    }

    /**
     * Returns Created By.
     */
    public function getCreatedBy(): ?string
    {
        return $this->createdBy;
    }

    /**
     * Sets Created By.
     *
     * @maps createdBy
     */
    public function setCreatedBy(?string $createdBy): void
    {
        $this->createdBy = $createdBy;
    }

    /**
     * Returns Link Status.
     */
    public function getLinkStatus(): ?string
    {
        return $this->linkStatus;
    }

    /**
     * Sets Link Status.
     *
     * @maps linkStatus
     */
    public function setLinkStatus(?string $linkStatus): void
    {
        $this->linkStatus = $linkStatus;
    }

    /**
     * Returns Link Kind.
     */
    public function getLinkKind(): ?string
    {
        return $this->linkKind;
    }

    /**
     * Sets Link Kind.
     *
     * @maps linkKind
     */
    public function setLinkKind(?string $linkKind): void
    {
        $this->linkKind = $linkKind;
    }

    /**
     * Returns Entity A.
     */
    public function getEntityA(): ?IdentityLinkEntryModel
    {
        return $this->entityA;
    }

    /**
     * Sets Entity A.
     *
     * @maps entityA
     */
    public function setEntityA(?IdentityLinkEntryModel $entityA): void
    {
        $this->entityA = $entityA;
    }

    /**
     * Returns Entity B.
     */
    public function getEntityB(): ?IdentityLinkEntryModel
    {
        return $this->entityB;
    }

    /**
     * Sets Entity B.
     *
     * @maps entityB
     */
    public function setEntityB(?IdentityLinkEntryModel $entityB): void
    {
        $this->entityB = $entityB;
    }

    private $additionalProperties = [];

    /**
     * Add an additional property to this model.
     *
     * @param string $name Name of property
     * @param mixed $value Value of property
     */
    public function addAdditionalProperty(string $name, $value)
    {
        $this->additionalProperties[$name] = $value;
    }

    /**
     * Encode this object to JSON
     *
     * @param bool $asArrayWhenEmpty Whether to serialize this model as an array whenever no fields
     *        are set. (default: false)
     *
     * @return array|stdClass
     */
    #[\ReturnTypeWillChange] // @phan-suppress-current-line PhanUndeclaredClassAttribute for (php < 8.1)
    public function jsonSerialize(bool $asArrayWhenEmpty = false)
    {
        $json = [];
        if (isset($this->id)) {
            $json['id']            = $this->id;
        }
        if (isset($this->decisionLogId)) {
            $json['decisionLogId'] = $this->decisionLogId;
        }
        if (isset($this->createdAt)) {
            $json['createdAt']     = $this->createdAt;
        }
        if (isset($this->createdBy)) {
            $json['createdBy']     = $this->createdBy;
        }
        if (isset($this->linkStatus)) {
            $json['linkStatus']    = $this->linkStatus;
        }
        if (isset($this->linkKind)) {
            $json['linkKind']      = $this->linkKind;
        }
        if (isset($this->entityA)) {
            $json['entityA']       = $this->entityA;
        }
        if (isset($this->entityB)) {
            $json['entityB']       = $this->entityB;
        }
        $json = array_merge($json, $this->additionalProperties);

        return (!$asArrayWhenEmpty && empty($json)) ? new stdClass() : $json;
    }
}
