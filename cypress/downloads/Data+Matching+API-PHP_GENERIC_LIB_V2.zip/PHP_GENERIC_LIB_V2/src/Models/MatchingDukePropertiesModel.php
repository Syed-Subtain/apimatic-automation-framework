<?php

declare(strict_types=1);

/*
 * Calculator
 *
 * This file was automatically generated for Label by APIMATIC v3.0 ( https://www.apimatic.io ).
 */

namespace CalculatorLib\Models;

use stdClass;

class MatchingDukePropertiesModel implements \JsonSerializable
{
    /**
     * @var int|null
     */
    private $threads = 1;

    /**
     * @var int|null
     */
    private $batchSize = 40000;

    /**
     * @var bool|null
     */
    private $profiling = false;

    /**
     * Returns Threads.
     */
    public function getThreads(): ?int
    {
        return $this->threads;
    }

    /**
     * Sets Threads.
     *
     * @maps threads
     */
    public function setThreads(?int $threads): void
    {
        $this->threads = $threads;
    }

    /**
     * Returns Batch Size.
     */
    public function getBatchSize(): ?int
    {
        return $this->batchSize;
    }

    /**
     * Sets Batch Size.
     *
     * @maps batchSize
     */
    public function setBatchSize(?int $batchSize): void
    {
        $this->batchSize = $batchSize;
    }

    /**
     * Returns Profiling.
     */
    public function getProfiling(): ?bool
    {
        return $this->profiling;
    }

    /**
     * Sets Profiling.
     *
     * @maps profiling
     */
    public function setProfiling(?bool $profiling): void
    {
        $this->profiling = $profiling;
    }

    private $additionalProperties = [];

    /**
     * Add an additional property to this model.
     *
     * @param string $name Name of property
     * @param mixed $value Value of property
     */
    public function addAdditionalProperty(string $name, $value)
    {
        $this->additionalProperties[$name] = $value;
    }

    /**
     * Encode this object to JSON
     *
     * @param bool $asArrayWhenEmpty Whether to serialize this model as an array whenever no fields
     *        are set. (default: false)
     *
     * @return array|stdClass
     */
    #[\ReturnTypeWillChange] // @phan-suppress-current-line PhanUndeclaredClassAttribute for (php < 8.1)
    public function jsonSerialize(bool $asArrayWhenEmpty = false)
    {
        $json = [];
        if (isset($this->threads)) {
            $json['threads']   = $this->threads;
        }
        if (isset($this->batchSize)) {
            $json['batchSize'] = $this->batchSize;
        }
        if (isset($this->profiling)) {
            $json['profiling'] = $this->profiling;
        }
        $json = array_merge($json, $this->additionalProperties);

        return (!$asArrayWhenEmpty && empty($json)) ? new stdClass() : $json;
    }
}
