<?php

declare(strict_types=1);

/*
 * Calculator
 *
 * This file was automatically generated for Label by APIMATIC v3.0 ( https://www.apimatic.io ).
 */

namespace CalculatorLib\Models;

use stdClass;

class MatchingDecisionImportJobModel implements \JsonSerializable
{
    /**
     * @var string|null
     */
    private $id;

    /**
     * @var string|null
     */
    private $domain;

    /**
     * @var string|null
     */
    private $createdBy;

    /**
     * @var string|null
     */
    private $createdAt;

    /**
     * @var string|null
     */
    private $modifiedAt;

    /**
     * @var int|null
     */
    private $progress;

    /**
     * @var string|null
     */
    private $status;

    /**
     * @var string|null
     */
    private $statusMessage;

    /**
     * @var string|null
     */
    private $decisionLogId;

    /**
     * @var MatchingDecisionImportJobResultModel|null
     */
    private $result;

    /**
     * Returns Id.
     */
    public function getId(): ?string
    {
        return $this->id;
    }

    /**
     * Sets Id.
     *
     * @maps id
     */
    public function setId(?string $id): void
    {
        $this->id = $id;
    }

    /**
     * Returns Domain.
     */
    public function getDomain(): ?string
    {
        return $this->domain;
    }

    /**
     * Sets Domain.
     *
     * @maps domain
     */
    public function setDomain(?string $domain): void
    {
        $this->domain = $domain;
    }

    /**
     * Returns Created By.
     */
    public function getCreatedBy(): ?string
    {
        return $this->createdBy;
    }

    /**
     * Sets Created By.
     *
     * @maps createdBy
     */
    public function setCreatedBy(?string $createdBy): void
    {
        $this->createdBy = $createdBy;
    }

    /**
     * Returns Created At.
     */
    public function getCreatedAt(): ?string
    {
        return $this->createdAt;
    }

    /**
     * Sets Created At.
     *
     * @maps createdAt
     */
    public function setCreatedAt(?string $createdAt): void
    {
        $this->createdAt = $createdAt;
    }

    /**
     * Returns Modified At.
     */
    public function getModifiedAt(): ?string
    {
        return $this->modifiedAt;
    }

    /**
     * Sets Modified At.
     *
     * @maps modifiedAt
     */
    public function setModifiedAt(?string $modifiedAt): void
    {
        $this->modifiedAt = $modifiedAt;
    }

    /**
     * Returns Progress.
     */
    public function getProgress(): ?int
    {
        return $this->progress;
    }

    /**
     * Sets Progress.
     *
     * @maps progress
     */
    public function setProgress(?int $progress): void
    {
        $this->progress = $progress;
    }

    /**
     * Returns Status.
     */
    public function getStatus(): ?string
    {
        return $this->status;
    }

    /**
     * Sets Status.
     *
     * @maps status
     */
    public function setStatus(?string $status): void
    {
        $this->status = $status;
    }

    /**
     * Returns Status Message.
     */
    public function getStatusMessage(): ?string
    {
        return $this->statusMessage;
    }

    /**
     * Sets Status Message.
     *
     * @maps statusMessage
     */
    public function setStatusMessage(?string $statusMessage): void
    {
        $this->statusMessage = $statusMessage;
    }

    /**
     * Returns Decision Log Id.
     */
    public function getDecisionLogId(): ?string
    {
        return $this->decisionLogId;
    }

    /**
     * Sets Decision Log Id.
     *
     * @maps decisionLogId
     */
    public function setDecisionLogId(?string $decisionLogId): void
    {
        $this->decisionLogId = $decisionLogId;
    }

    /**
     * Returns Result.
     */
    public function getResult(): ?MatchingDecisionImportJobResultModel
    {
        return $this->result;
    }

    /**
     * Sets Result.
     *
     * @maps result
     */
    public function setResult(?MatchingDecisionImportJobResultModel $result): void
    {
        $this->result = $result;
    }

    private $additionalProperties = [];

    /**
     * Add an additional property to this model.
     *
     * @param string $name Name of property
     * @param mixed $value Value of property
     */
    public function addAdditionalProperty(string $name, $value)
    {
        $this->additionalProperties[$name] = $value;
    }

    /**
     * Encode this object to JSON
     *
     * @param bool $asArrayWhenEmpty Whether to serialize this model as an array whenever no fields
     *        are set. (default: false)
     *
     * @return array|stdClass
     */
    #[\ReturnTypeWillChange] // @phan-suppress-current-line PhanUndeclaredClassAttribute for (php < 8.1)
    public function jsonSerialize(bool $asArrayWhenEmpty = false)
    {
        $json = [];
        if (isset($this->id)) {
            $json['id']            = $this->id;
        }
        if (isset($this->domain)) {
            $json['domain']        = $this->domain;
        }
        if (isset($this->createdBy)) {
            $json['createdBy']     = $this->createdBy;
        }
        if (isset($this->createdAt)) {
            $json['createdAt']     = $this->createdAt;
        }
        if (isset($this->modifiedAt)) {
            $json['modifiedAt']    = $this->modifiedAt;
        }
        if (isset($this->progress)) {
            $json['progress']      = $this->progress;
        }
        if (isset($this->status)) {
            $json['status']        = $this->status;
        }
        if (isset($this->statusMessage)) {
            $json['statusMessage'] = $this->statusMessage;
        }
        if (isset($this->decisionLogId)) {
            $json['decisionLogId'] = $this->decisionLogId;
        }
        if (isset($this->result)) {
            $json['result']        = $this->result;
        }
        $json = array_merge($json, $this->additionalProperties);

        return (!$asArrayWhenEmpty && empty($json)) ? new stdClass() : $json;
    }
}
