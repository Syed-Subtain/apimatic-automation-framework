<?php

declare(strict_types=1);

/*
 * Calculator
 *
 * This file was automatically generated for Label by APIMATIC v3.0 ( https://www.apimatic.io ).
 */

namespace CalculatorLib\Models;

use stdClass;

class DecisionNodeModel implements \JsonSerializable
{
    /**
     * @var RuleModel|null
     */
    private $rule;

    /**
     * @var DecisionNodeModel|null
     */
    private $yesBranch;

    /**
     * @var DecisionNodeModel|null
     */
    private $noBranch;

    /**
     * Returns Rule.
     */
    public function getRule(): ?RuleModel
    {
        return $this->rule;
    }

    /**
     * Sets Rule.
     *
     * @maps rule
     */
    public function setRule(?RuleModel $rule): void
    {
        $this->rule = $rule;
    }

    /**
     * Returns Yes Branch.
     */
    public function getYesBranch(): ?DecisionNodeModel
    {
        return $this->yesBranch;
    }

    /**
     * Sets Yes Branch.
     *
     * @maps yesBranch
     */
    public function setYesBranch(?DecisionNodeModel $yesBranch): void
    {
        $this->yesBranch = $yesBranch;
    }

    /**
     * Returns No Branch.
     */
    public function getNoBranch(): ?DecisionNodeModel
    {
        return $this->noBranch;
    }

    /**
     * Sets No Branch.
     *
     * @maps noBranch
     */
    public function setNoBranch(?DecisionNodeModel $noBranch): void
    {
        $this->noBranch = $noBranch;
    }

    private $additionalProperties = [];

    /**
     * Add an additional property to this model.
     *
     * @param string $name Name of property
     * @param mixed $value Value of property
     */
    public function addAdditionalProperty(string $name, $value)
    {
        $this->additionalProperties[$name] = $value;
    }

    /**
     * Encode this object to JSON
     *
     * @param bool $asArrayWhenEmpty Whether to serialize this model as an array whenever no fields
     *        are set. (default: false)
     *
     * @return array|stdClass
     */
    #[\ReturnTypeWillChange] // @phan-suppress-current-line PhanUndeclaredClassAttribute for (php < 8.1)
    public function jsonSerialize(bool $asArrayWhenEmpty = false)
    {
        $json = [];
        if (isset($this->rule)) {
            $json['rule']      = $this->rule;
        }
        if (isset($this->yesBranch)) {
            $json['yesBranch'] = $this->yesBranch;
        }
        if (isset($this->noBranch)) {
            $json['noBranch']  = $this->noBranch;
        }
        $json = array_merge($json, $this->additionalProperties);

        return (!$asArrayWhenEmpty && empty($json)) ? new stdClass() : $json;
    }
}
