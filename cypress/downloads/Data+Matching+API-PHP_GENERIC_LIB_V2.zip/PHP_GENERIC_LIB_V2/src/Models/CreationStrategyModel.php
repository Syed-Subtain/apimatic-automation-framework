<?php

declare(strict_types=1);

/*
 * Calculator
 *
 * This file was automatically generated for Label by APIMATIC v3.0 ( https://www.apimatic.io ).
 */

namespace CalculatorLib\Models;

use stdClass;

class CreationStrategyModel implements \JsonSerializable
{
    /**
     * @var string
     */
    private $type;

    /**
     * @var string[]|null
     */
    private $protectedAttributes;

    /**
     * @var RuleModel[]|null
     */
    private $recordExclusionRules;

    /**
     * @var EnhancementRuleModel[]|null
     */
    private $attributeEnhancementRules;

    /**
     * @param string $type
     */
    public function __construct(string $type)
    {
        $this->type = $type;
    }

    /**
     * Returns Type.
     * Defines the way how an attributes should be selected to be added to the golden record.
     */
    public function getType(): string
    {
        return $this->type;
    }

    /**
     * Sets Type.
     * Defines the way how an attributes should be selected to be added to the golden record.
     *
     * @required
     * @maps type
     * @factory \CalculatorLib\Models\CreationTypeEnum::checkValue
     */
    public function setType(string $type): void
    {
        $this->type = $type;
    }

    /**
     * Returns Protected Attributes.
     * List of attribute of base record that should be kept (e.g. ID, account group, ...)
     *
     * @return string[]|null
     */
    public function getProtectedAttributes(): ?array
    {
        return $this->protectedAttributes;
    }

    /**
     * Sets Protected Attributes.
     * List of attribute of base record that should be kept (e.g. ID, account group, ...)
     *
     * @maps protectedAttributes
     *
     * @param string[]|null $protectedAttributes
     */
    public function setProtectedAttributes(?array $protectedAttributes): void
    {
        $this->protectedAttributes = $protectedAttributes;
    }

    /**
     * Returns Record Exclusion Rules.
     * List of rules to exclude certain records from golden record creation (e.g. has a deletion flag)
     *
     * @return RuleModel[]|null
     */
    public function getRecordExclusionRules(): ?array
    {
        return $this->recordExclusionRules;
    }

    /**
     * Sets Record Exclusion Rules.
     * List of rules to exclude certain records from golden record creation (e.g. has a deletion flag)
     *
     * @maps recordExclusionRules
     *
     * @param RuleModel[]|null $recordExclusionRules
     */
    public function setRecordExclusionRules(?array $recordExclusionRules): void
    {
        $this->recordExclusionRules = $recordExclusionRules;
    }

    /**
     * Returns Attribute Enhancement Rules.
     * List of rules to define if and how a certain attribute should be included or removed from the golden
     * record
     *
     * @return EnhancementRuleModel[]|null
     */
    public function getAttributeEnhancementRules(): ?array
    {
        return $this->attributeEnhancementRules;
    }

    /**
     * Sets Attribute Enhancement Rules.
     * List of rules to define if and how a certain attribute should be included or removed from the golden
     * record
     *
     * @maps attributeEnhancementRules
     *
     * @param EnhancementRuleModel[]|null $attributeEnhancementRules
     */
    public function setAttributeEnhancementRules(?array $attributeEnhancementRules): void
    {
        $this->attributeEnhancementRules = $attributeEnhancementRules;
    }

    private $additionalProperties = [];

    /**
     * Add an additional property to this model.
     *
     * @param string $name Name of property
     * @param mixed $value Value of property
     */
    public function addAdditionalProperty(string $name, $value)
    {
        $this->additionalProperties[$name] = $value;
    }

    /**
     * Encode this object to JSON
     *
     * @param bool $asArrayWhenEmpty Whether to serialize this model as an array whenever no fields
     *        are set. (default: false)
     *
     * @return array|stdClass
     */
    #[\ReturnTypeWillChange] // @phan-suppress-current-line PhanUndeclaredClassAttribute for (php < 8.1)
    public function jsonSerialize(bool $asArrayWhenEmpty = false)
    {
        $json = [];
        $json['type']                          = CreationTypeEnum::checkValue($this->type);
        if (isset($this->protectedAttributes)) {
            $json['protectedAttributes']       = $this->protectedAttributes;
        }
        if (isset($this->recordExclusionRules)) {
            $json['recordExclusionRules']      = $this->recordExclusionRules;
        }
        if (isset($this->attributeEnhancementRules)) {
            $json['attributeEnhancementRules'] = $this->attributeEnhancementRules;
        }
        $json = array_merge($json, $this->additionalProperties);

        return (!$asArrayWhenEmpty && empty($json)) ? new stdClass() : $json;
    }
}
