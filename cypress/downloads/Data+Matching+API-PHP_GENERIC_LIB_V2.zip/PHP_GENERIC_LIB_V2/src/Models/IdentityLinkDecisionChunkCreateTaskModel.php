<?php

declare(strict_types=1);

/*
 * Calculator
 *
 * This file was automatically generated for Label by APIMATIC v3.0 ( https://www.apimatic.io ).
 */

namespace CalculatorLib\Models;

use stdClass;

class IdentityLinkDecisionChunkCreateTaskModel implements \JsonSerializable
{
    /**
     * @var string|null
     */
    private $correlationId;

    /**
     * @var string|null
     */
    private $userId;

    /**
     * @var IdentityLinkDecisionCreateWorkerRequestModel|null
     */
    private $request;

    /**
     * @var string|null
     */
    private $replyQueue;

    /**
     * Returns Correlation Id.
     * ID which uniquely chains a set of request()s and or task(s)
     */
    public function getCorrelationId(): ?string
    {
        return $this->correlationId;
    }

    /**
     * Sets Correlation Id.
     * ID which uniquely chains a set of request()s and or task(s)
     *
     * @maps correlationId
     */
    public function setCorrelationId(?string $correlationId): void
    {
        $this->correlationId = $correlationId;
    }

    /**
     * Returns User Id.
     * Unique ID of a user
     */
    public function getUserId(): ?string
    {
        return $this->userId;
    }

    /**
     * Sets User Id.
     * Unique ID of a user
     *
     * @maps userId
     */
    public function setUserId(?string $userId): void
    {
        $this->userId = $userId;
    }

    /**
     * Returns Request.
     */
    public function getRequest(): ?IdentityLinkDecisionCreateWorkerRequestModel
    {
        return $this->request;
    }

    /**
     * Sets Request.
     *
     * @maps request
     */
    public function setRequest(?IdentityLinkDecisionCreateWorkerRequestModel $request): void
    {
        $this->request = $request;
    }

    /**
     * Returns Reply Queue.
     * Technical descriptor of reply queue where workers should put back the result
     */
    public function getReplyQueue(): ?string
    {
        return $this->replyQueue;
    }

    /**
     * Sets Reply Queue.
     * Technical descriptor of reply queue where workers should put back the result
     *
     * @maps replyQueue
     */
    public function setReplyQueue(?string $replyQueue): void
    {
        $this->replyQueue = $replyQueue;
    }

    private $additionalProperties = [];

    /**
     * Add an additional property to this model.
     *
     * @param string $name Name of property
     * @param mixed $value Value of property
     */
    public function addAdditionalProperty(string $name, $value)
    {
        $this->additionalProperties[$name] = $value;
    }

    /**
     * Encode this object to JSON
     *
     * @param bool $asArrayWhenEmpty Whether to serialize this model as an array whenever no fields
     *        are set. (default: false)
     *
     * @return array|stdClass
     */
    #[\ReturnTypeWillChange] // @phan-suppress-current-line PhanUndeclaredClassAttribute for (php < 8.1)
    public function jsonSerialize(bool $asArrayWhenEmpty = false)
    {
        $json = [];
        if (isset($this->correlationId)) {
            $json['correlationId'] = $this->correlationId;
        }
        if (isset($this->userId)) {
            $json['userId']        = $this->userId;
        }
        if (isset($this->request)) {
            $json['request']       = $this->request;
        }
        if (isset($this->replyQueue)) {
            $json['replyQueue']    = $this->replyQueue;
        }
        $json = array_merge($json, $this->additionalProperties);

        return (!$asArrayWhenEmpty && empty($json)) ? new stdClass() : $json;
    }
}
