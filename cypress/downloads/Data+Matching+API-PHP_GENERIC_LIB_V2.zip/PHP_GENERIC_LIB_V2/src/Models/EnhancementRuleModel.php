<?php

declare(strict_types=1);

/*
 * Calculator
 *
 * This file was automatically generated for Label by APIMATIC v3.0 ( https://www.apimatic.io ).
 */

namespace CalculatorLib\Models;

use stdClass;

/**
 * Defines the way how the attributes of the golden record are chosen.
 */
class EnhancementRuleModel implements \JsonSerializable
{
    /**
     * @var string[]
     */
    private $attributes;

    /**
     * @var ConstraintChainModel|null
     */
    private $constraintChain;

    /**
     * @var string|null
     */
    private $creationType;

    /**
     * @var string|null
     */
    private $creationConstant;

    /**
     * @var string
     */
    private $executionType;

    /**
     * @var string|null
     */
    private $fallbackExecutionType;

    /**
     * @param string[] $attributes
     * @param string $executionType
     */
    public function __construct(array $attributes, string $executionType)
    {
        $this->attributes = $attributes;
        $this->executionType = $executionType;
    }

    /**
     * Returns Attributes.
     * List of attribute affected by this rule of enhancement
     *
     * @return string[]
     */
    public function getAttributes(): array
    {
        return $this->attributes;
    }

    /**
     * Sets Attributes.
     * List of attribute affected by this rule of enhancement
     *
     * @required
     * @maps attributes
     *
     * @param string[] $attributes
     */
    public function setAttributes(array $attributes): void
    {
        $this->attributes = $attributes;
    }

    /**
     * Returns Constraint Chain.
     */
    public function getConstraintChain(): ?ConstraintChainModel
    {
        return $this->constraintChain;
    }

    /**
     * Sets Constraint Chain.
     *
     * @maps constraintChain
     */
    public function setConstraintChain(?ConstraintChainModel $constraintChain): void
    {
        $this->constraintChain = $constraintChain;
    }

    /**
     * Returns Creation Type.
     * Defines the way how an attributes should be selected to be added to the golden record.
     */
    public function getCreationType(): ?string
    {
        return $this->creationType;
    }

    /**
     * Sets Creation Type.
     * Defines the way how an attributes should be selected to be added to the golden record.
     *
     * @maps creationType
     * @factory \CalculatorLib\Models\CreationTypeEnum::checkValue
     */
    public function setCreationType(?string $creationType): void
    {
        $this->creationType = $creationType;
    }

    /**
     * Returns Creation Constant.
     */
    public function getCreationConstant(): ?string
    {
        return $this->creationConstant;
    }

    /**
     * Sets Creation Constant.
     *
     * @maps creationConstant
     */
    public function setCreationConstant(?string $creationConstant): void
    {
        $this->creationConstant = $creationConstant;
    }

    /**
     * Returns Execution Type.
     * Defines options on how an attribute should be handled. SET means the already existing one is
     * overwritten, ENRICH means that the new value is only added to the golden record in case it does not
     * have any value yet and REMOVE will just delete the existing value from the golden record.
     */
    public function getExecutionType(): string
    {
        return $this->executionType;
    }

    /**
     * Sets Execution Type.
     * Defines options on how an attribute should be handled. SET means the already existing one is
     * overwritten, ENRICH means that the new value is only added to the golden record in case it does not
     * have any value yet and REMOVE will just delete the existing value from the golden record.
     *
     * @required
     * @maps executionType
     * @factory \CalculatorLib\Models\ExecutionTypeEnum::checkValue
     */
    public function setExecutionType(string $executionType): void
    {
        $this->executionType = $executionType;
    }

    /**
     * Returns Fallback Execution Type.
     * Defines options on how an attribute should be handled. SET means the already existing one is
     * overwritten, ENRICH means that the new value is only added to the golden record in case it does not
     * have any value yet and REMOVE will just delete the existing value from the golden record.
     */
    public function getFallbackExecutionType(): ?string
    {
        return $this->fallbackExecutionType;
    }

    /**
     * Sets Fallback Execution Type.
     * Defines options on how an attribute should be handled. SET means the already existing one is
     * overwritten, ENRICH means that the new value is only added to the golden record in case it does not
     * have any value yet and REMOVE will just delete the existing value from the golden record.
     *
     * @maps fallbackExecutionType
     * @factory \CalculatorLib\Models\ExecutionTypeEnum::checkValue
     */
    public function setFallbackExecutionType(?string $fallbackExecutionType): void
    {
        $this->fallbackExecutionType = $fallbackExecutionType;
    }

    private $additionalProperties = [];

    /**
     * Add an additional property to this model.
     *
     * @param string $name Name of property
     * @param mixed $value Value of property
     */
    public function addAdditionalProperty(string $name, $value)
    {
        $this->additionalProperties[$name] = $value;
    }

    /**
     * Encode this object to JSON
     *
     * @param bool $asArrayWhenEmpty Whether to serialize this model as an array whenever no fields
     *        are set. (default: false)
     *
     * @return array|stdClass
     */
    #[\ReturnTypeWillChange] // @phan-suppress-current-line PhanUndeclaredClassAttribute for (php < 8.1)
    public function jsonSerialize(bool $asArrayWhenEmpty = false)
    {
        $json = [];
        $json['attributes']                = $this->attributes;
        if (isset($this->constraintChain)) {
            $json['constraintChain']       = $this->constraintChain;
        }
        if (isset($this->creationType)) {
            $json['creationType']          = CreationTypeEnum::checkValue($this->creationType);
        }
        if (isset($this->creationConstant)) {
            $json['creationConstant']      = $this->creationConstant;
        }
        $json['executionType']             = ExecutionTypeEnum::checkValue($this->executionType);
        if (isset($this->fallbackExecutionType)) {
            $json['fallbackExecutionType'] = ExecutionTypeEnum::checkValue($this->fallbackExecutionType);
        }
        $json = array_merge($json, $this->additionalProperties);

        return (!$asArrayWhenEmpty && empty($json)) ? new stdClass() : $json;
    }
}
