<?php

declare(strict_types=1);

/*
 * Calculator
 *
 * This file was automatically generated for Label by APIMATIC v3.0 ( https://www.apimatic.io ).
 */

namespace CalculatorLib\Models;

use stdClass;

class IdentityLinksModel implements \JsonSerializable
{
    /**
     * @var string|null
     */
    private $startAfter;

    /**
     * @var int|null
     */
    private $limit;

    /**
     * @var IdentityLinkModel[]|null
     */
    private $values;

    /**
     * @var string|null
     */
    private $nextStartAfter;

    /**
     * Returns Start After.
     */
    public function getStartAfter(): ?string
    {
        return $this->startAfter;
    }

    /**
     * Sets Start After.
     *
     * @maps startAfter
     */
    public function setStartAfter(?string $startAfter): void
    {
        $this->startAfter = $startAfter;
    }

    /**
     * Returns Limit.
     */
    public function getLimit(): ?int
    {
        return $this->limit;
    }

    /**
     * Sets Limit.
     *
     * @maps limit
     */
    public function setLimit(?int $limit): void
    {
        $this->limit = $limit;
    }

    /**
     * Returns Values.
     *
     * @return IdentityLinkModel[]|null
     */
    public function getValues(): ?array
    {
        return $this->values;
    }

    /**
     * Sets Values.
     *
     * @maps values
     *
     * @param IdentityLinkModel[]|null $values
     */
    public function setValues(?array $values): void
    {
        $this->values = $values;
    }

    /**
     * Returns Next Start After.
     * Indicator for the next page. Used together with startAfter.
     */
    public function getNextStartAfter(): ?string
    {
        return $this->nextStartAfter;
    }

    /**
     * Sets Next Start After.
     * Indicator for the next page. Used together with startAfter.
     *
     * @maps nextStartAfter
     */
    public function setNextStartAfter(?string $nextStartAfter): void
    {
        $this->nextStartAfter = $nextStartAfter;
    }

    private $additionalProperties = [];

    /**
     * Add an additional property to this model.
     *
     * @param string $name Name of property
     * @param mixed $value Value of property
     */
    public function addAdditionalProperty(string $name, $value)
    {
        $this->additionalProperties[$name] = $value;
    }

    /**
     * Encode this object to JSON
     *
     * @param bool $asArrayWhenEmpty Whether to serialize this model as an array whenever no fields
     *        are set. (default: false)
     *
     * @return array|stdClass
     */
    #[\ReturnTypeWillChange] // @phan-suppress-current-line PhanUndeclaredClassAttribute for (php < 8.1)
    public function jsonSerialize(bool $asArrayWhenEmpty = false)
    {
        $json = [];
        if (isset($this->startAfter)) {
            $json['startAfter']     = $this->startAfter;
        }
        if (isset($this->limit)) {
            $json['limit']          = $this->limit;
        }
        if (isset($this->values)) {
            $json['values']         = $this->values;
        }
        if (isset($this->nextStartAfter)) {
            $json['nextStartAfter'] = $this->nextStartAfter;
        }
        $json = array_merge($json, $this->additionalProperties);

        return (!$asArrayWhenEmpty && empty($json)) ? new stdClass() : $json;
    }
}
