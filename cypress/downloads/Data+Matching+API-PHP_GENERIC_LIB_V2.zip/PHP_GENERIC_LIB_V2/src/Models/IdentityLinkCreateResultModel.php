<?php

declare(strict_types=1);

/*
 * Calculator
 *
 * This file was automatically generated for Label by APIMATIC v3.0 ( https://www.apimatic.io ).
 */

namespace CalculatorLib\Models;

use stdClass;

class IdentityLinkCreateResultModel implements \JsonSerializable
{
    /**
     * @var IdentityLinkCreateStatusModel[]|null
     */
    private $values;

    /**
     * Returns Values.
     *
     * @return IdentityLinkCreateStatusModel[]|null
     */
    public function getValues(): ?array
    {
        return $this->values;
    }

    /**
     * Sets Values.
     *
     * @maps values
     *
     * @param IdentityLinkCreateStatusModel[]|null $values
     */
    public function setValues(?array $values): void
    {
        $this->values = $values;
    }

    private $additionalProperties = [];

    /**
     * Add an additional property to this model.
     *
     * @param string $name Name of property
     * @param mixed $value Value of property
     */
    public function addAdditionalProperty(string $name, $value)
    {
        $this->additionalProperties[$name] = $value;
    }

    /**
     * Encode this object to JSON
     *
     * @param bool $asArrayWhenEmpty Whether to serialize this model as an array whenever no fields
     *        are set. (default: false)
     *
     * @return array|stdClass
     */
    #[\ReturnTypeWillChange] // @phan-suppress-current-line PhanUndeclaredClassAttribute for (php < 8.1)
    public function jsonSerialize(bool $asArrayWhenEmpty = false)
    {
        $json = [];
        if (isset($this->values)) {
            $json['values'] = $this->values;
        }
        $json = array_merge($json, $this->additionalProperties);

        return (!$asArrayWhenEmpty && empty($json)) ? new stdClass() : $json;
    }
}
