<?php

declare(strict_types=1);

/*
 * Calculator
 *
 * This file was automatically generated for Label by APIMATIC v3.0 ( https://www.apimatic.io ).
 */

namespace CalculatorLib\Models;

use stdClass;

class ColumnMappingModel implements \JsonSerializable
{
    /**
     * @var string|null
     */
    private $attributeJsonPath;

    /**
     * @var string|null
     */
    private $columnName;

    /**
     * Returns Attribute Json Path.
     */
    public function getAttributeJsonPath(): ?string
    {
        return $this->attributeJsonPath;
    }

    /**
     * Sets Attribute Json Path.
     *
     * @maps attributeJsonPath
     */
    public function setAttributeJsonPath(?string $attributeJsonPath): void
    {
        $this->attributeJsonPath = $attributeJsonPath;
    }

    /**
     * Returns Column Name.
     */
    public function getColumnName(): ?string
    {
        return $this->columnName;
    }

    /**
     * Sets Column Name.
     *
     * @maps columnName
     */
    public function setColumnName(?string $columnName): void
    {
        $this->columnName = $columnName;
    }

    private $additionalProperties = [];

    /**
     * Add an additional property to this model.
     *
     * @param string $name Name of property
     * @param mixed $value Value of property
     */
    public function addAdditionalProperty(string $name, $value)
    {
        $this->additionalProperties[$name] = $value;
    }

    /**
     * Encode this object to JSON
     *
     * @param bool $asArrayWhenEmpty Whether to serialize this model as an array whenever no fields
     *        are set. (default: false)
     *
     * @return array|stdClass
     */
    #[\ReturnTypeWillChange] // @phan-suppress-current-line PhanUndeclaredClassAttribute for (php < 8.1)
    public function jsonSerialize(bool $asArrayWhenEmpty = false)
    {
        $json = [];
        if (isset($this->attributeJsonPath)) {
            $json['attributeJsonPath'] = $this->attributeJsonPath;
        }
        if (isset($this->columnName)) {
            $json['columnName']        = $this->columnName;
        }
        $json = array_merge($json, $this->additionalProperties);

        return (!$asArrayWhenEmpty && empty($json)) ? new stdClass() : $json;
    }
}
