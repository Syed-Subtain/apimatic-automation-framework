<?php

declare(strict_types=1);

/*
 * Calculator
 *
 * This file was automatically generated for Label by APIMATIC v3.0 ( https://www.apimatic.io ).
 */

namespace CalculatorLib\Models;

use stdClass;

class MatchingDecisionLogResultModel implements \JsonSerializable
{
    /**
     * @var MatchingDecisionLogModel|null
     */
    private $matchingDecisionLog;

    /**
     * @var string|null
     */
    private $status;

    /**
     * @var string|null
     */
    private $message;

    /**
     * Returns Matching Decision Log.
     */
    public function getMatchingDecisionLog(): ?MatchingDecisionLogModel
    {
        return $this->matchingDecisionLog;
    }

    /**
     * Sets Matching Decision Log.
     *
     * @maps matchingDecisionLog
     */
    public function setMatchingDecisionLog(?MatchingDecisionLogModel $matchingDecisionLog): void
    {
        $this->matchingDecisionLog = $matchingDecisionLog;
    }

    /**
     * Returns Status.
     * status:
     * * `OK` - Decision log has been fetched successfully
     * * `NOT_FOUND` - Decision log does not exist
     */
    public function getStatus(): ?string
    {
        return $this->status;
    }

    /**
     * Sets Status.
     * status:
     * * `OK` - Decision log has been fetched successfully
     * * `NOT_FOUND` - Decision log does not exist
     *
     * @maps status
     */
    public function setStatus(?string $status): void
    {
        $this->status = $status;
    }

    /**
     * Returns Message.
     */
    public function getMessage(): ?string
    {
        return $this->message;
    }

    /**
     * Sets Message.
     *
     * @maps message
     */
    public function setMessage(?string $message): void
    {
        $this->message = $message;
    }

    private $additionalProperties = [];

    /**
     * Add an additional property to this model.
     *
     * @param string $name Name of property
     * @param mixed $value Value of property
     */
    public function addAdditionalProperty(string $name, $value)
    {
        $this->additionalProperties[$name] = $value;
    }

    /**
     * Encode this object to JSON
     *
     * @param bool $asArrayWhenEmpty Whether to serialize this model as an array whenever no fields
     *        are set. (default: false)
     *
     * @return array|stdClass
     */
    #[\ReturnTypeWillChange] // @phan-suppress-current-line PhanUndeclaredClassAttribute for (php < 8.1)
    public function jsonSerialize(bool $asArrayWhenEmpty = false)
    {
        $json = [];
        if (isset($this->matchingDecisionLog)) {
            $json['matchingDecisionLog'] = $this->matchingDecisionLog;
        }
        if (isset($this->status)) {
            $json['status']              = $this->status;
        }
        if (isset($this->message)) {
            $json['message']             = $this->message;
        }
        $json = array_merge($json, $this->additionalProperties);

        return (!$asArrayWhenEmpty && empty($json)) ? new stdClass() : $json;
    }
}
