<?php

declare(strict_types=1);

/*
 * Calculator
 *
 * This file was automatically generated for Label by APIMATIC v3.0 ( https://www.apimatic.io ).
 */

namespace CalculatorLib\Models;

use stdClass;

class MatchingScoreModel implements \JsonSerializable
{
    /**
     * @var MatchingClassificationModel|null
     */
    private $classification;

    /**
     * @var float|null
     */
    private $value;

    /**
     * @var string|null
     */
    private $explanation;

    /**
     * Returns Classification.
     */
    public function getClassification(): ?MatchingClassificationModel
    {
        return $this->classification;
    }

    /**
     * Sets Classification.
     *
     * @maps classification
     */
    public function setClassification(?MatchingClassificationModel $classification): void
    {
        $this->classification = $classification;
    }

    /**
     * Returns Value.
     */
    public function getValue(): ?float
    {
        return $this->value;
    }

    /**
     * Sets Value.
     *
     * @maps value
     */
    public function setValue(?float $value): void
    {
        $this->value = $value;
    }

    /**
     * Returns Explanation.
     */
    public function getExplanation(): ?string
    {
        return $this->explanation;
    }

    /**
     * Sets Explanation.
     *
     * @maps explanation
     */
    public function setExplanation(?string $explanation): void
    {
        $this->explanation = $explanation;
    }

    private $additionalProperties = [];

    /**
     * Add an additional property to this model.
     *
     * @param string $name Name of property
     * @param mixed $value Value of property
     */
    public function addAdditionalProperty(string $name, $value)
    {
        $this->additionalProperties[$name] = $value;
    }

    /**
     * Encode this object to JSON
     *
     * @param bool $asArrayWhenEmpty Whether to serialize this model as an array whenever no fields
     *        are set. (default: false)
     *
     * @return array|stdClass
     */
    #[\ReturnTypeWillChange] // @phan-suppress-current-line PhanUndeclaredClassAttribute for (php < 8.1)
    public function jsonSerialize(bool $asArrayWhenEmpty = false)
    {
        $json = [];
        if (isset($this->classification)) {
            $json['classification'] = $this->classification;
        }
        if (isset($this->value)) {
            $json['value']          = $this->value;
        }
        if (isset($this->explanation)) {
            $json['explanation']    = $this->explanation;
        }
        $json = array_merge($json, $this->additionalProperties);

        return (!$asArrayWhenEmpty && empty($json)) ? new stdClass() : $json;
    }
}
