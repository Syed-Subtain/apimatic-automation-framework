<?php

declare(strict_types=1);

/*
 * Calculator
 *
 * This file was automatically generated for Label by APIMATIC v3.0 ( https://www.apimatic.io ).
 */

namespace CalculatorLib\Models;

use stdClass;

class DataMatchingDefinitionCreateModel implements \JsonSerializable
{
    /**
     * @var string
     */
    private $name;

    /**
     * @var string
     */
    private $type;

    /**
     * @var string
     */
    private $xmlDukeConfiguration;

    /**
     * @var ReportConfigurationModel|null
     */
    private $reportConfiguration;

    /**
     * @var GoldenRecordConfigurationModel|null
     */
    private $goldenRecordConfiguration;

    /**
     * @var WorkspaceModel|null
     */
    private $workspace;

    /**
     * @param string $name
     * @param string $type
     * @param string $xmlDukeConfiguration
     */
    public function __construct(string $name, string $type, string $xmlDukeConfiguration)
    {
        $this->name = $name;
        $this->type = $type;
        $this->xmlDukeConfiguration = $xmlDukeConfiguration;
    }

    /**
     * Returns Name.
     * Human readable name.
     */
    public function getName(): string
    {
        return $this->name;
    }

    /**
     * Sets Name.
     * Human readable name.
     *
     * @required
     * @maps name
     */
    public function setName(string $name): void
    {
        $this->name = $name;
    }

    /**
     * Returns Type.
     */
    public function getType(): string
    {
        return $this->type;
    }

    /**
     * Sets Type.
     *
     * @required
     * @maps type
     * @factory \CalculatorLib\Models\MatchingTypeEnum::checkValue
     */
    public function setType(string $type): void
    {
        $this->type = $type;
    }

    /**
     * Returns Xml Duke Configuration.
     * Duke XML matching configuration
     */
    public function getXmlDukeConfiguration(): string
    {
        return $this->xmlDukeConfiguration;
    }

    /**
     * Sets Xml Duke Configuration.
     * Duke XML matching configuration
     *
     * @required
     * @maps xmlDukeConfiguration
     */
    public function setXmlDukeConfiguration(string $xmlDukeConfiguration): void
    {
        $this->xmlDukeConfiguration = $xmlDukeConfiguration;
    }

    /**
     * Returns Report Configuration.
     */
    public function getReportConfiguration(): ?ReportConfigurationModel
    {
        return $this->reportConfiguration;
    }

    /**
     * Sets Report Configuration.
     *
     * @maps reportConfiguration
     */
    public function setReportConfiguration(?ReportConfigurationModel $reportConfiguration): void
    {
        $this->reportConfiguration = $reportConfiguration;
    }

    /**
     * Returns Golden Record Configuration.
     */
    public function getGoldenRecordConfiguration(): ?GoldenRecordConfigurationModel
    {
        return $this->goldenRecordConfiguration;
    }

    /**
     * Sets Golden Record Configuration.
     *
     * @maps goldenRecordConfiguration
     */
    public function setGoldenRecordConfiguration(?GoldenRecordConfigurationModel $goldenRecordConfiguration): void
    {
        $this->goldenRecordConfiguration = $goldenRecordConfiguration;
    }

    /**
     * Returns Workspace.
     */
    public function getWorkspace(): ?WorkspaceModel
    {
        return $this->workspace;
    }

    /**
     * Sets Workspace.
     *
     * @maps workspace
     */
    public function setWorkspace(?WorkspaceModel $workspace): void
    {
        $this->workspace = $workspace;
    }

    private $additionalProperties = [];

    /**
     * Add an additional property to this model.
     *
     * @param string $name Name of property
     * @param mixed $value Value of property
     */
    public function addAdditionalProperty(string $name, $value)
    {
        $this->additionalProperties[$name] = $value;
    }

    /**
     * Encode this object to JSON
     *
     * @param bool $asArrayWhenEmpty Whether to serialize this model as an array whenever no fields
     *        are set. (default: false)
     *
     * @return array|stdClass
     */
    #[\ReturnTypeWillChange] // @phan-suppress-current-line PhanUndeclaredClassAttribute for (php < 8.1)
    public function jsonSerialize(bool $asArrayWhenEmpty = false)
    {
        $json = [];
        $json['name']                          = $this->name;
        $json['type']                          = MatchingTypeEnum::checkValue($this->type);
        $json['xmlDukeConfiguration']          = $this->xmlDukeConfiguration;
        if (isset($this->reportConfiguration)) {
            $json['reportConfiguration']       = $this->reportConfiguration;
        }
        if (isset($this->goldenRecordConfiguration)) {
            $json['goldenRecordConfiguration'] = $this->goldenRecordConfiguration;
        }
        if (isset($this->workspace)) {
            $json['workspace']                 = $this->workspace;
        }
        $json = array_merge($json, $this->additionalProperties);

        return (!$asArrayWhenEmpty && empty($json)) ? new stdClass() : $json;
    }
}
