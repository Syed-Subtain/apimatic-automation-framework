<?php

declare(strict_types=1);

/*
 * Calculator
 *
 * This file was automatically generated for Label by APIMATIC v3.0 ( https://www.apimatic.io ).
 */

namespace CalculatorLib\Models;

use stdClass;

class MatchingReportsModel implements \JsonSerializable
{
    /**
     * @var string|null
     */
    private $id;

    /**
     * @var string|null
     */
    private $status;

    /**
     * @var string|null
     */
    private $statusMessage;

    /**
     * @var string|null
     */
    private $createdAt;

    /**
     * @var string|null
     */
    private $finishedAt;

    /**
     * @var string|null
     */
    private $user;

    /**
     * @var AttachmentModel[]|null
     */
    private $attachments;

    /**
     * @var int|null
     */
    private $progress;

    /**
     * @var MatchingReportsConfigurationModel|null
     */
    private $reportsConfiguration;

    /**
     * Returns Id.
     * ID of the job which generated the report
     */
    public function getId(): ?string
    {
        return $this->id;
    }

    /**
     * Sets Id.
     * ID of the job which generated the report
     *
     * @maps id
     */
    public function setId(?string $id): void
    {
        $this->id = $id;
    }

    /**
     * Returns Status.
     */
    public function getStatus(): ?string
    {
        return $this->status;
    }

    /**
     * Sets Status.
     *
     * @maps status
     */
    public function setStatus(?string $status): void
    {
        $this->status = $status;
    }

    /**
     * Returns Status Message.
     */
    public function getStatusMessage(): ?string
    {
        return $this->statusMessage;
    }

    /**
     * Sets Status Message.
     *
     * @maps statusMessage
     */
    public function setStatusMessage(?string $statusMessage): void
    {
        $this->statusMessage = $statusMessage;
    }

    /**
     * Returns Created At.
     */
    public function getCreatedAt(): ?string
    {
        return $this->createdAt;
    }

    /**
     * Sets Created At.
     *
     * @maps createdAt
     */
    public function setCreatedAt(?string $createdAt): void
    {
        $this->createdAt = $createdAt;
    }

    /**
     * Returns Finished At.
     */
    public function getFinishedAt(): ?string
    {
        return $this->finishedAt;
    }

    /**
     * Sets Finished At.
     *
     * @maps finishedAt
     */
    public function setFinishedAt(?string $finishedAt): void
    {
        $this->finishedAt = $finishedAt;
    }

    /**
     * Returns User.
     */
    public function getUser(): ?string
    {
        return $this->user;
    }

    /**
     * Sets User.
     *
     * @maps user
     */
    public function setUser(?string $user): void
    {
        $this->user = $user;
    }

    /**
     * Returns Attachments.
     *
     * @return AttachmentModel[]|null
     */
    public function getAttachments(): ?array
    {
        return $this->attachments;
    }

    /**
     * Sets Attachments.
     *
     * @maps attachments
     *
     * @param AttachmentModel[]|null $attachments
     */
    public function setAttachments(?array $attachments): void
    {
        $this->attachments = $attachments;
    }

    /**
     * Returns Progress.
     */
    public function getProgress(): ?int
    {
        return $this->progress;
    }

    /**
     * Sets Progress.
     *
     * @maps progress
     */
    public function setProgress(?int $progress): void
    {
        $this->progress = $progress;
    }

    /**
     * Returns Reports Configuration.
     */
    public function getReportsConfiguration(): ?MatchingReportsConfigurationModel
    {
        return $this->reportsConfiguration;
    }

    /**
     * Sets Reports Configuration.
     *
     * @maps reportsConfiguration
     */
    public function setReportsConfiguration(?MatchingReportsConfigurationModel $reportsConfiguration): void
    {
        $this->reportsConfiguration = $reportsConfiguration;
    }

    private $additionalProperties = [];

    /**
     * Add an additional property to this model.
     *
     * @param string $name Name of property
     * @param mixed $value Value of property
     */
    public function addAdditionalProperty(string $name, $value)
    {
        $this->additionalProperties[$name] = $value;
    }

    /**
     * Encode this object to JSON
     *
     * @param bool $asArrayWhenEmpty Whether to serialize this model as an array whenever no fields
     *        are set. (default: false)
     *
     * @return array|stdClass
     */
    #[\ReturnTypeWillChange] // @phan-suppress-current-line PhanUndeclaredClassAttribute for (php < 8.1)
    public function jsonSerialize(bool $asArrayWhenEmpty = false)
    {
        $json = [];
        if (isset($this->id)) {
            $json['id']                   = $this->id;
        }
        if (isset($this->status)) {
            $json['status']               = $this->status;
        }
        if (isset($this->statusMessage)) {
            $json['statusMessage']        = $this->statusMessage;
        }
        if (isset($this->createdAt)) {
            $json['createdAt']            = $this->createdAt;
        }
        if (isset($this->finishedAt)) {
            $json['finishedAt']           = $this->finishedAt;
        }
        if (isset($this->user)) {
            $json['user']                 = $this->user;
        }
        if (isset($this->attachments)) {
            $json['attachments']          = $this->attachments;
        }
        if (isset($this->progress)) {
            $json['progress']             = $this->progress;
        }
        if (isset($this->reportsConfiguration)) {
            $json['reportsConfiguration'] = $this->reportsConfiguration;
        }
        $json = array_merge($json, $this->additionalProperties);

        return (!$asArrayWhenEmpty && empty($json)) ? new stdClass() : $json;
    }
}
