<?php

declare(strict_types=1);

/*
 * Calculator
 *
 * This file was automatically generated for Label by APIMATIC v3.0 ( https://www.apimatic.io ).
 */

namespace CalculatorLib\Models;

use stdClass;

class DataMatchingDefinitionPageModel implements \JsonSerializable
{
    /**
     * @var int|null
     */
    private $page;

    /**
     * @var int|null
     */
    private $pageSize;

    /**
     * @var int|null
     */
    private $numberOfPages;

    /**
     * @var int|null
     */
    private $total;

    /**
     * @var DataMatchingDefinitionModel[]|null
     */
    private $values;

    /**
     * Returns Page.
     */
    public function getPage(): ?int
    {
        return $this->page;
    }

    /**
     * Sets Page.
     *
     * @maps page
     */
    public function setPage(?int $page): void
    {
        $this->page = $page;
    }

    /**
     * Returns Page Size.
     */
    public function getPageSize(): ?int
    {
        return $this->pageSize;
    }

    /**
     * Sets Page Size.
     *
     * @maps pageSize
     */
    public function setPageSize(?int $pageSize): void
    {
        $this->pageSize = $pageSize;
    }

    /**
     * Returns Number of Pages.
     */
    public function getNumberOfPages(): ?int
    {
        return $this->numberOfPages;
    }

    /**
     * Sets Number of Pages.
     *
     * @maps numberOfPages
     */
    public function setNumberOfPages(?int $numberOfPages): void
    {
        $this->numberOfPages = $numberOfPages;
    }

    /**
     * Returns Total.
     */
    public function getTotal(): ?int
    {
        return $this->total;
    }

    /**
     * Sets Total.
     *
     * @maps total
     */
    public function setTotal(?int $total): void
    {
        $this->total = $total;
    }

    /**
     * Returns Values.
     *
     * @return DataMatchingDefinitionModel[]|null
     */
    public function getValues(): ?array
    {
        return $this->values;
    }

    /**
     * Sets Values.
     *
     * @maps values
     *
     * @param DataMatchingDefinitionModel[]|null $values
     */
    public function setValues(?array $values): void
    {
        $this->values = $values;
    }

    private $additionalProperties = [];

    /**
     * Add an additional property to this model.
     *
     * @param string $name Name of property
     * @param mixed $value Value of property
     */
    public function addAdditionalProperty(string $name, $value)
    {
        $this->additionalProperties[$name] = $value;
    }

    /**
     * Encode this object to JSON
     *
     * @param bool $asArrayWhenEmpty Whether to serialize this model as an array whenever no fields
     *        are set. (default: false)
     *
     * @return array|stdClass
     */
    #[\ReturnTypeWillChange] // @phan-suppress-current-line PhanUndeclaredClassAttribute for (php < 8.1)
    public function jsonSerialize(bool $asArrayWhenEmpty = false)
    {
        $json = [];
        if (isset($this->page)) {
            $json['page']          = $this->page;
        }
        if (isset($this->pageSize)) {
            $json['pageSize']      = $this->pageSize;
        }
        if (isset($this->numberOfPages)) {
            $json['numberOfPages'] = $this->numberOfPages;
        }
        if (isset($this->total)) {
            $json['total']         = $this->total;
        }
        if (isset($this->values)) {
            $json['values']        = $this->values;
        }
        $json = array_merge($json, $this->additionalProperties);

        return (!$asArrayWhenEmpty && empty($json)) ? new stdClass() : $json;
    }
}
