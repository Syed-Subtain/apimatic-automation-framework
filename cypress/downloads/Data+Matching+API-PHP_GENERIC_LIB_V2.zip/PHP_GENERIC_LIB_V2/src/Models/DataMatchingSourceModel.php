<?php

declare(strict_types=1);

/*
 * Calculator
 *
 * This file was automatically generated for Label by APIMATIC v3.0 ( https://www.apimatic.io ).
 */

namespace CalculatorLib\Models;

use stdClass;

class DataMatchingSourceModel implements \JsonSerializable
{
    /**
     * @var string
     */
    private $storageId;

    /**
     * @var string[]|null
     */
    private $dataSourceIds;

    /**
     * @param string $storageId
     */
    public function __construct(string $storageId)
    {
        $this->storageId = $storageId;
    }

    /**
     * Returns Storage Id.
     * The ID of the storage that should used for matching.
     */
    public function getStorageId(): string
    {
        return $this->storageId;
    }

    /**
     * Sets Storage Id.
     * The ID of the storage that should used for matching.
     *
     * @required
     * @maps storageId
     */
    public function setStorageId(string $storageId): void
    {
        $this->storageId = $storageId;
    }

    /**
     * Returns Data Source Ids.
     * Optional list of DataSource IDs of the storage (identified by the storageId) that should used for
     * matching.
     *
     * @return string[]|null
     */
    public function getDataSourceIds(): ?array
    {
        return $this->dataSourceIds;
    }

    /**
     * Sets Data Source Ids.
     * Optional list of DataSource IDs of the storage (identified by the storageId) that should used for
     * matching.
     *
     * @maps dataSourceIds
     *
     * @param string[]|null $dataSourceIds
     */
    public function setDataSourceIds(?array $dataSourceIds): void
    {
        $this->dataSourceIds = $dataSourceIds;
    }

    private $additionalProperties = [];

    /**
     * Add an additional property to this model.
     *
     * @param string $name Name of property
     * @param mixed $value Value of property
     */
    public function addAdditionalProperty(string $name, $value)
    {
        $this->additionalProperties[$name] = $value;
    }

    /**
     * Encode this object to JSON
     *
     * @param bool $asArrayWhenEmpty Whether to serialize this model as an array whenever no fields
     *        are set. (default: false)
     *
     * @return array|stdClass
     */
    #[\ReturnTypeWillChange] // @phan-suppress-current-line PhanUndeclaredClassAttribute for (php < 8.1)
    public function jsonSerialize(bool $asArrayWhenEmpty = false)
    {
        $json = [];
        $json['storageId']         = $this->storageId;
        if (isset($this->dataSourceIds)) {
            $json['dataSourceIds'] = $this->dataSourceIds;
        }
        $json = array_merge($json, $this->additionalProperties);

        return (!$asArrayWhenEmpty && empty($json)) ? new stdClass() : $json;
    }
}
