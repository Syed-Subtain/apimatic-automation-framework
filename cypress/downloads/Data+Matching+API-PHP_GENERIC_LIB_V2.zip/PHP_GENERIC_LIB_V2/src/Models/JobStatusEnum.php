<?php

declare(strict_types=1);

/*
 * Calculator
 *
 * This file was automatically generated for Label by APIMATIC v3.0 ( https://www.apimatic.io ).
 */

namespace CalculatorLib\Models;

use CalculatorLib\ApiHelper;
use Exception;
use stdClass;

/**
 * Curation Job execution status.
 */
class JobStatusEnum
{
    public const UNKNOWN = 'UNKNOWN';

    public const CREATED = 'CREATED';

    public const PERSISTED = 'PERSISTED';

    public const SCHEDULED = 'SCHEDULED';

    public const WAITING = 'WAITING';

    public const COULDNT_START = 'COULDNT_START';

    public const RUNNING = 'RUNNING';

    public const FINISHED = 'FINISHED';

    public const DIED = 'DIED';

    public const CANCELED = 'CANCELED';

    public const FAILED = 'FAILED';

    private const _ALL_VALUES = [
        self::UNKNOWN,
        self::CREATED,
        self::PERSISTED,
        self::SCHEDULED,
        self::WAITING,
        self::COULDNT_START,
        self::RUNNING,
        self::FINISHED,
        self::DIED,
        self::CANCELED,
        self::FAILED,
    ];

    /**
     * Ensures that all the given values are present in this Enum.
     *
     * @param array|stdClass|null|string $value Value or a list/map of values to be checked
     *
     * @return array|null|string Input value(s), if all are a part of this Enum
     *
     * @throws Exception Throws exception if any given value is not in this Enum
     */
    public static function checkValue($value)
    {
        $value = json_decode(json_encode($value), true); // converts stdClass into array
        ApiHelper::checkValueInEnum($value, self::class, self::_ALL_VALUES);
        return $value;
    }
}
