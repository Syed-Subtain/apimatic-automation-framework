<?php

declare(strict_types=1);

/*
 * Calculator
 *
 * This file was automatically generated for Label by APIMATIC v3.0 ( https://www.apimatic.io ).
 */

namespace CalculatorLib\Models;

use stdClass;

class IdentifierModel implements \JsonSerializable
{
    /**
     * @var IdentifierTypeModel|null
     */
    private $type;

    /**
     * @var string|null
     */
    private $value;

    /**
     * @var string|null
     */
    private $issuingBody;

    /**
     * Returns Type.
     */
    public function getType(): ?IdentifierTypeModel
    {
        return $this->type;
    }

    /**
     * Sets Type.
     *
     * @maps type
     */
    public function setType(?IdentifierTypeModel $type): void
    {
        $this->type = $type;
    }

    /**
     * Returns Value.
     */
    public function getValue(): ?string
    {
        return $this->value;
    }

    /**
     * Sets Value.
     *
     * @maps value
     */
    public function setValue(?string $value): void
    {
        $this->value = $value;
    }

    /**
     * Returns Issuing Body.
     */
    public function getIssuingBody(): ?string
    {
        return $this->issuingBody;
    }

    /**
     * Sets Issuing Body.
     *
     * @maps issuingBody
     */
    public function setIssuingBody(?string $issuingBody): void
    {
        $this->issuingBody = $issuingBody;
    }

    private $additionalProperties = [];

    /**
     * Add an additional property to this model.
     *
     * @param string $name Name of property
     * @param mixed $value Value of property
     */
    public function addAdditionalProperty(string $name, $value)
    {
        $this->additionalProperties[$name] = $value;
    }

    /**
     * Encode this object to JSON
     *
     * @param bool $asArrayWhenEmpty Whether to serialize this model as an array whenever no fields
     *        are set. (default: false)
     *
     * @return array|stdClass
     */
    #[\ReturnTypeWillChange] // @phan-suppress-current-line PhanUndeclaredClassAttribute for (php < 8.1)
    public function jsonSerialize(bool $asArrayWhenEmpty = false)
    {
        $json = [];
        if (isset($this->type)) {
            $json['type']        = $this->type;
        }
        if (isset($this->value)) {
            $json['value']       = $this->value;
        }
        if (isset($this->issuingBody)) {
            $json['issuingBody'] = $this->issuingBody;
        }
        $json = array_merge($json, $this->additionalProperties);

        return (!$asArrayWhenEmpty && empty($json)) ? new stdClass() : $json;
    }
}
