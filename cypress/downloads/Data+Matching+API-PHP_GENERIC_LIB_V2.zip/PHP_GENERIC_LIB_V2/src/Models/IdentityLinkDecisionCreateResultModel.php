<?php

declare(strict_types=1);

/*
 * Calculator
 *
 * This file was automatically generated for Label by APIMATIC v3.0 ( https://www.apimatic.io ).
 */

namespace CalculatorLib\Models;

use stdClass;

class IdentityLinkDecisionCreateResultModel implements \JsonSerializable
{
    /**
     * @var int|null
     */
    private $numberOfProcessed;

    /**
     * @var int|null
     */
    private $numberOfCreated;

    /**
     * @var int|null
     */
    private $numberOfFailed;

    /**
     * @var IdentityLinkDecisionCreateFailureLogModel[]|null
     */
    private $failures;

    /**
     * Returns Number of Processed.
     */
    public function getNumberOfProcessed(): ?int
    {
        return $this->numberOfProcessed;
    }

    /**
     * Sets Number of Processed.
     *
     * @maps numberOfProcessed
     */
    public function setNumberOfProcessed(?int $numberOfProcessed): void
    {
        $this->numberOfProcessed = $numberOfProcessed;
    }

    /**
     * Returns Number of Created.
     */
    public function getNumberOfCreated(): ?int
    {
        return $this->numberOfCreated;
    }

    /**
     * Sets Number of Created.
     *
     * @maps numberOfCreated
     */
    public function setNumberOfCreated(?int $numberOfCreated): void
    {
        $this->numberOfCreated = $numberOfCreated;
    }

    /**
     * Returns Number of Failed.
     */
    public function getNumberOfFailed(): ?int
    {
        return $this->numberOfFailed;
    }

    /**
     * Sets Number of Failed.
     *
     * @maps numberOfFailed
     */
    public function setNumberOfFailed(?int $numberOfFailed): void
    {
        $this->numberOfFailed = $numberOfFailed;
    }

    /**
     * Returns Failures.
     *
     * @return IdentityLinkDecisionCreateFailureLogModel[]|null
     */
    public function getFailures(): ?array
    {
        return $this->failures;
    }

    /**
     * Sets Failures.
     *
     * @maps failures
     *
     * @param IdentityLinkDecisionCreateFailureLogModel[]|null $failures
     */
    public function setFailures(?array $failures): void
    {
        $this->failures = $failures;
    }

    private $additionalProperties = [];

    /**
     * Add an additional property to this model.
     *
     * @param string $name Name of property
     * @param mixed $value Value of property
     */
    public function addAdditionalProperty(string $name, $value)
    {
        $this->additionalProperties[$name] = $value;
    }

    /**
     * Encode this object to JSON
     *
     * @param bool $asArrayWhenEmpty Whether to serialize this model as an array whenever no fields
     *        are set. (default: false)
     *
     * @return array|stdClass
     */
    #[\ReturnTypeWillChange] // @phan-suppress-current-line PhanUndeclaredClassAttribute for (php < 8.1)
    public function jsonSerialize(bool $asArrayWhenEmpty = false)
    {
        $json = [];
        if (isset($this->numberOfProcessed)) {
            $json['numberOfProcessed'] = $this->numberOfProcessed;
        }
        if (isset($this->numberOfCreated)) {
            $json['numberOfCreated']   = $this->numberOfCreated;
        }
        if (isset($this->numberOfFailed)) {
            $json['numberOfFailed']    = $this->numberOfFailed;
        }
        if (isset($this->failures)) {
            $json['failures']          = $this->failures;
        }
        $json = array_merge($json, $this->additionalProperties);

        return (!$asArrayWhenEmpty && empty($json)) ? new stdClass() : $json;
    }
}
