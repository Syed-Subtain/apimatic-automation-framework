<?php

declare(strict_types=1);

/*
 * Calculator
 *
 * This file was automatically generated for Label by APIMATIC v3.0 ( https://www.apimatic.io ).
 */

namespace CalculatorLib\Models;

use stdClass;

/**
 * Generates a data matching report that doesn't include artificial golden records on top of each
 * matching group. Optionally IncludeSingles feature can be set to true.
 */
class DuplicateMatchingReportConfigurationModel implements \JsonSerializable
{
    /**
     * @var bool|null
     */
    private $build = false;

    /**
     * @var bool|null
     */
    private $includeSingles = false;

    /**
     * Returns Build.
     * Enable to generate this report
     */
    public function getBuild(): ?bool
    {
        return $this->build;
    }

    /**
     * Sets Build.
     * Enable to generate this report
     *
     * @maps build
     */
    public function setBuild(?bool $build): void
    {
        $this->build = $build;
    }

    /**
     * Returns Include Singles.
     */
    public function getIncludeSingles(): ?bool
    {
        return $this->includeSingles;
    }

    /**
     * Sets Include Singles.
     *
     * @maps includeSingles
     */
    public function setIncludeSingles(?bool $includeSingles): void
    {
        $this->includeSingles = $includeSingles;
    }

    private $additionalProperties = [];

    /**
     * Add an additional property to this model.
     *
     * @param string $name Name of property
     * @param mixed $value Value of property
     */
    public function addAdditionalProperty(string $name, $value)
    {
        $this->additionalProperties[$name] = $value;
    }

    /**
     * Encode this object to JSON
     *
     * @param bool $asArrayWhenEmpty Whether to serialize this model as an array whenever no fields
     *        are set. (default: false)
     *
     * @return array|stdClass
     */
    #[\ReturnTypeWillChange] // @phan-suppress-current-line PhanUndeclaredClassAttribute for (php < 8.1)
    public function jsonSerialize(bool $asArrayWhenEmpty = false)
    {
        $json = [];
        if (isset($this->build)) {
            $json['build']          = $this->build;
        }
        if (isset($this->includeSingles)) {
            $json['includeSingles'] = $this->includeSingles;
        }
        $json = array_merge($json, $this->additionalProperties);

        return (!$asArrayWhenEmpty && empty($json)) ? new stdClass() : $json;
    }
}
