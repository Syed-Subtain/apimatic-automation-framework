<?php

declare(strict_types=1);

/*
 * Calculator
 *
 * This file was automatically generated for Label by APIMATIC v3.0 ( https://www.apimatic.io ).
 */

namespace CalculatorLib\Models;

use stdClass;

class MatchingReportsRequestModel implements \JsonSerializable
{
    /**
     * @var string|null
     */
    private $matchingJobId;

    /**
     * @var MatchingReportsConfigurationModel|null
     */
    private $reportsConfiguration;

    /**
     * Returns Matching Job Id.
     */
    public function getMatchingJobId(): ?string
    {
        return $this->matchingJobId;
    }

    /**
     * Sets Matching Job Id.
     *
     * @maps matchingJobId
     */
    public function setMatchingJobId(?string $matchingJobId): void
    {
        $this->matchingJobId = $matchingJobId;
    }

    /**
     * Returns Reports Configuration.
     */
    public function getReportsConfiguration(): ?MatchingReportsConfigurationModel
    {
        return $this->reportsConfiguration;
    }

    /**
     * Sets Reports Configuration.
     *
     * @maps reportsConfiguration
     */
    public function setReportsConfiguration(?MatchingReportsConfigurationModel $reportsConfiguration): void
    {
        $this->reportsConfiguration = $reportsConfiguration;
    }

    private $additionalProperties = [];

    /**
     * Add an additional property to this model.
     *
     * @param string $name Name of property
     * @param mixed $value Value of property
     */
    public function addAdditionalProperty(string $name, $value)
    {
        $this->additionalProperties[$name] = $value;
    }

    /**
     * Encode this object to JSON
     *
     * @param bool $asArrayWhenEmpty Whether to serialize this model as an array whenever no fields
     *        are set. (default: false)
     *
     * @return array|stdClass
     */
    #[\ReturnTypeWillChange] // @phan-suppress-current-line PhanUndeclaredClassAttribute for (php < 8.1)
    public function jsonSerialize(bool $asArrayWhenEmpty = false)
    {
        $json = [];
        if (isset($this->matchingJobId)) {
            $json['matchingJobId']        = $this->matchingJobId;
        }
        if (isset($this->reportsConfiguration)) {
            $json['reportsConfiguration'] = $this->reportsConfiguration;
        }
        $json = array_merge($json, $this->additionalProperties);

        return (!$asArrayWhenEmpty && empty($json)) ? new stdClass() : $json;
    }
}
