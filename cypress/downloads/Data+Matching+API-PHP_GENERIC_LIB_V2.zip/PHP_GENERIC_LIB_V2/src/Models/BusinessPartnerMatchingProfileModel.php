<?php

declare(strict_types=1);

/*
 * Calculator
 *
 * This file was automatically generated for Label by APIMATIC v3.0 ( https://www.apimatic.io ).
 */

namespace CalculatorLib\Models;

use stdClass;

class BusinessPartnerMatchingProfileModel implements \JsonSerializable
{
    /**
     * @var string|null
     */
    private $externalId;

    /**
     * @var MatchingProfileModel|null
     */
    private $matchingProfile;

    /**
     * Returns External Id.
     */
    public function getExternalId(): ?string
    {
        return $this->externalId;
    }

    /**
     * Sets External Id.
     *
     * @maps externalId
     */
    public function setExternalId(?string $externalId): void
    {
        $this->externalId = $externalId;
    }

    /**
     * Returns Matching Profile.
     */
    public function getMatchingProfile(): ?MatchingProfileModel
    {
        return $this->matchingProfile;
    }

    /**
     * Sets Matching Profile.
     *
     * @maps matchingProfile
     */
    public function setMatchingProfile(?MatchingProfileModel $matchingProfile): void
    {
        $this->matchingProfile = $matchingProfile;
    }

    private $additionalProperties = [];

    /**
     * Add an additional property to this model.
     *
     * @param string $name Name of property
     * @param mixed $value Value of property
     */
    public function addAdditionalProperty(string $name, $value)
    {
        $this->additionalProperties[$name] = $value;
    }

    /**
     * Encode this object to JSON
     *
     * @param bool $asArrayWhenEmpty Whether to serialize this model as an array whenever no fields
     *        are set. (default: false)
     *
     * @return array|stdClass
     */
    #[\ReturnTypeWillChange] // @phan-suppress-current-line PhanUndeclaredClassAttribute for (php < 8.1)
    public function jsonSerialize(bool $asArrayWhenEmpty = false)
    {
        $json = [];
        if (isset($this->externalId)) {
            $json['externalId']      = $this->externalId;
        }
        if (isset($this->matchingProfile)) {
            $json['matchingProfile'] = $this->matchingProfile;
        }
        $json = array_merge($json, $this->additionalProperties);

        return (!$asArrayWhenEmpty && empty($json)) ? new stdClass() : $json;
    }
}
