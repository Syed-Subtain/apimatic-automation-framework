<?php

declare(strict_types=1);

/*
 * Calculator
 *
 * This file was automatically generated for Label by APIMATIC v3.0 ( https://www.apimatic.io ).
 */

namespace CalculatorLib\Models;

use stdClass;

class LinkMatchingJobRequestModel implements \JsonSerializable
{
    /**
     * @var DataMatchingSourceModel[]|null
     */
    private $patternSources;

    /**
     * @var DataMatchingSourceModel[]|null
     */
    private $matchSources;

    /**
     * @var string[]|null
     */
    private $countryShortNames;

    /**
     * @var string|null
     */
    private $dataMatchingDefinitionId;

    /**
     * @var string[]|null
     */
    private $decisionLogIds;

    /**
     * Returns Pattern Sources.
     * The source, in form of a BusinessPartner storage (at least one but can be more), to get the pattern
     * records for the matching.
     *
     * @return DataMatchingSourceModel[]|null
     */
    public function getPatternSources(): ?array
    {
        return $this->patternSources;
    }

    /**
     * Sets Pattern Sources.
     * The source, in form of a BusinessPartner storage (at least one but can be more), to get the pattern
     * records for the matching.
     *
     * @maps patternSources
     *
     * @param DataMatchingSourceModel[]|null $patternSources
     */
    public function setPatternSources(?array $patternSources): void
    {
        $this->patternSources = $patternSources;
    }

    /**
     * Returns Match Sources.
     * The source, in form of a BusinessPartner storage (at least one but can be more), to get the match
     * records for the matching.
     *
     * @return DataMatchingSourceModel[]|null
     */
    public function getMatchSources(): ?array
    {
        return $this->matchSources;
    }

    /**
     * Sets Match Sources.
     * The source, in form of a BusinessPartner storage (at least one but can be more), to get the match
     * records for the matching.
     *
     * @maps matchSources
     *
     * @param DataMatchingSourceModel[]|null $matchSources
     */
    public function setMatchSources(?array $matchSources): void
    {
        $this->matchSources = $matchSources;
    }

    /**
     * Returns Country Short Names.
     * If set, only the records that belong to the countries identified by these short names are processed.
     * By default all records of the storage (means from all countries) are processed (considering other
     * filters).
     *
     * @return string[]|null
     */
    public function getCountryShortNames(): ?array
    {
        return $this->countryShortNames;
    }

    /**
     * Sets Country Short Names.
     * If set, only the records that belong to the countries identified by these short names are processed.
     * By default all records of the storage (means from all countries) are processed (considering other
     * filters).
     *
     * @maps countryShortNames
     *
     * @param string[]|null $countryShortNames
     */
    public function setCountryShortNames(?array $countryShortNames): void
    {
        $this->countryShortNames = $countryShortNames;
    }

    /**
     * Returns Data Matching Definition Id.
     * ID of the DataMatchingDefinition that should be used to perform the link matching.
     */
    public function getDataMatchingDefinitionId(): ?string
    {
        return $this->dataMatchingDefinitionId;
    }

    /**
     * Sets Data Matching Definition Id.
     * ID of the DataMatchingDefinition that should be used to perform the link matching.
     *
     * @maps dataMatchingDefinitionId
     */
    public function setDataMatchingDefinitionId(?string $dataMatchingDefinitionId): void
    {
        $this->dataMatchingDefinitionId = $dataMatchingDefinitionId;
    }

    /**
     * Returns Decision Log Ids.
     * If set, feedback from listed Matching Decision Logs will be considered.
     *
     * @return string[]|null
     */
    public function getDecisionLogIds(): ?array
    {
        return $this->decisionLogIds;
    }

    /**
     * Sets Decision Log Ids.
     * If set, feedback from listed Matching Decision Logs will be considered.
     *
     * @maps decisionLogIds
     *
     * @param string[]|null $decisionLogIds
     */
    public function setDecisionLogIds(?array $decisionLogIds): void
    {
        $this->decisionLogIds = $decisionLogIds;
    }

    private $additionalProperties = [];

    /**
     * Add an additional property to this model.
     *
     * @param string $name Name of property
     * @param mixed $value Value of property
     */
    public function addAdditionalProperty(string $name, $value)
    {
        $this->additionalProperties[$name] = $value;
    }

    /**
     * Encode this object to JSON
     *
     * @param bool $asArrayWhenEmpty Whether to serialize this model as an array whenever no fields
     *        are set. (default: false)
     *
     * @return array|stdClass
     */
    #[\ReturnTypeWillChange] // @phan-suppress-current-line PhanUndeclaredClassAttribute for (php < 8.1)
    public function jsonSerialize(bool $asArrayWhenEmpty = false)
    {
        $json = [];
        if (isset($this->patternSources)) {
            $json['patternSources']           = $this->patternSources;
        }
        if (isset($this->matchSources)) {
            $json['matchSources']             = $this->matchSources;
        }
        if (isset($this->countryShortNames)) {
            $json['countryShortNames']        = $this->countryShortNames;
        }
        if (isset($this->dataMatchingDefinitionId)) {
            $json['dataMatchingDefinitionId'] = $this->dataMatchingDefinitionId;
        }
        if (isset($this->decisionLogIds)) {
            $json['decisionLogIds']           = $this->decisionLogIds;
        }
        $json = array_merge($json, $this->additionalProperties);

        return (!$asArrayWhenEmpty && empty($json)) ? new stdClass() : $json;
    }
}
