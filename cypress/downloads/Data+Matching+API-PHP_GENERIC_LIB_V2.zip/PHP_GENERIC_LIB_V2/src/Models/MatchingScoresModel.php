<?php

declare(strict_types=1);

/*
 * Calculator
 *
 * This file was automatically generated for Label by APIMATIC v3.0 ( https://www.apimatic.io ).
 */

namespace CalculatorLib\Models;

use stdClass;

class MatchingScoresModel implements \JsonSerializable
{
    /**
     * @var MatchingScoreModel|null
     */
    private $overall;

    /**
     * @var MatchingScoreModel|null
     */
    private $businessPartner;

    /**
     * @var MatchingScoreModel|null
     */
    private $address;

    /**
     * Returns Overall.
     */
    public function getOverall(): ?MatchingScoreModel
    {
        return $this->overall;
    }

    /**
     * Sets Overall.
     *
     * @maps overall
     */
    public function setOverall(?MatchingScoreModel $overall): void
    {
        $this->overall = $overall;
    }

    /**
     * Returns Business Partner.
     */
    public function getBusinessPartner(): ?MatchingScoreModel
    {
        return $this->businessPartner;
    }

    /**
     * Sets Business Partner.
     *
     * @maps businessPartner
     */
    public function setBusinessPartner(?MatchingScoreModel $businessPartner): void
    {
        $this->businessPartner = $businessPartner;
    }

    /**
     * Returns Address.
     */
    public function getAddress(): ?MatchingScoreModel
    {
        return $this->address;
    }

    /**
     * Sets Address.
     *
     * @maps address
     */
    public function setAddress(?MatchingScoreModel $address): void
    {
        $this->address = $address;
    }

    private $additionalProperties = [];

    /**
     * Add an additional property to this model.
     *
     * @param string $name Name of property
     * @param mixed $value Value of property
     */
    public function addAdditionalProperty(string $name, $value)
    {
        $this->additionalProperties[$name] = $value;
    }

    /**
     * Encode this object to JSON
     *
     * @param bool $asArrayWhenEmpty Whether to serialize this model as an array whenever no fields
     *        are set. (default: false)
     *
     * @return array|stdClass
     */
    #[\ReturnTypeWillChange] // @phan-suppress-current-line PhanUndeclaredClassAttribute for (php < 8.1)
    public function jsonSerialize(bool $asArrayWhenEmpty = false)
    {
        $json = [];
        if (isset($this->overall)) {
            $json['overall']         = $this->overall;
        }
        if (isset($this->businessPartner)) {
            $json['businessPartner'] = $this->businessPartner;
        }
        if (isset($this->address)) {
            $json['address']         = $this->address;
        }
        $json = array_merge($json, $this->additionalProperties);

        return (!$asArrayWhenEmpty && empty($json)) ? new stdClass() : $json;
    }
}
