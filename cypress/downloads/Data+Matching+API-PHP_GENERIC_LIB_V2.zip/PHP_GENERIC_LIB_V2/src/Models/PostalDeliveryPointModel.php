<?php

declare(strict_types=1);

/*
 * Calculator
 *
 * This file was automatically generated for Label by APIMATIC v3.0 ( https://www.apimatic.io ).
 */

namespace CalculatorLib\Models;

use stdClass;

class PostalDeliveryPointModel implements \JsonSerializable
{
    /**
     * @var PostalDeliveryPointTypeModel|null
     */
    private $type;

    /**
     * @var string|null
     */
    private $shortName;

    /**
     * @var string|null
     */
    private $number;

    /**
     * @var string|null
     */
    private $value;

    /**
     * Returns Type.
     */
    public function getType(): ?PostalDeliveryPointTypeModel
    {
        return $this->type;
    }

    /**
     * Sets Type.
     *
     * @maps type
     */
    public function setType(?PostalDeliveryPointTypeModel $type): void
    {
        $this->type = $type;
    }

    /**
     * Returns Short Name.
     */
    public function getShortName(): ?string
    {
        return $this->shortName;
    }

    /**
     * Sets Short Name.
     *
     * @maps shortName
     */
    public function setShortName(?string $shortName): void
    {
        $this->shortName = $shortName;
    }

    /**
     * Returns Number.
     */
    public function getNumber(): ?string
    {
        return $this->number;
    }

    /**
     * Sets Number.
     *
     * @maps number
     */
    public function setNumber(?string $number): void
    {
        $this->number = $number;
    }

    /**
     * Returns Value.
     */
    public function getValue(): ?string
    {
        return $this->value;
    }

    /**
     * Sets Value.
     *
     * @maps value
     */
    public function setValue(?string $value): void
    {
        $this->value = $value;
    }

    private $additionalProperties = [];

    /**
     * Add an additional property to this model.
     *
     * @param string $name Name of property
     * @param mixed $value Value of property
     */
    public function addAdditionalProperty(string $name, $value)
    {
        $this->additionalProperties[$name] = $value;
    }

    /**
     * Encode this object to JSON
     *
     * @param bool $asArrayWhenEmpty Whether to serialize this model as an array whenever no fields
     *        are set. (default: false)
     *
     * @return array|stdClass
     */
    #[\ReturnTypeWillChange] // @phan-suppress-current-line PhanUndeclaredClassAttribute for (php < 8.1)
    public function jsonSerialize(bool $asArrayWhenEmpty = false)
    {
        $json = [];
        if (isset($this->type)) {
            $json['type']      = $this->type;
        }
        if (isset($this->shortName)) {
            $json['shortName'] = $this->shortName;
        }
        if (isset($this->number)) {
            $json['number']    = $this->number;
        }
        if (isset($this->value)) {
            $json['value']     = $this->value;
        }
        $json = array_merge($json, $this->additionalProperties);

        return (!$asArrayWhenEmpty && empty($json)) ? new stdClass() : $json;
    }
}
