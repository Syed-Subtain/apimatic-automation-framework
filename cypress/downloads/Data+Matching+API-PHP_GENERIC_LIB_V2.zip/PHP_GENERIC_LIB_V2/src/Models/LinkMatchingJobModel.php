<?php

declare(strict_types=1);

/*
 * Calculator
 *
 * This file was automatically generated for Label by APIMATIC v3.0 ( https://www.apimatic.io ).
 */

namespace CalculatorLib\Models;

use stdClass;

class LinkMatchingJobModel implements \JsonSerializable
{
    /**
     * @var string|null
     */
    private $id;

    /**
     * @var DataMatchingSourceModel[]|null
     */
    private $patternSources;

    /**
     * @var DataMatchingSourceModel[]|null
     */
    private $matchSources;

    /**
     * @var string[]|null
     */
    private $countryShortNames;

    /**
     * @var string|null
     */
    private $dataMatchingDefinitionId;

    /**
     * @var string[]|null
     */
    private $decisionLogIds;

    /**
     * @var string|null
     */
    private $createdAt;

    /**
     * @var string|null
     */
    private $createdBy;

    /**
     * @var string|null
     */
    private $status;

    /**
     * @var int|null
     */
    private $progress;

    /**
     * Returns Id.
     */
    public function getId(): ?string
    {
        return $this->id;
    }

    /**
     * Sets Id.
     *
     * @maps id
     */
    public function setId(?string $id): void
    {
        $this->id = $id;
    }

    /**
     * Returns Pattern Sources.
     *
     * @return DataMatchingSourceModel[]|null
     */
    public function getPatternSources(): ?array
    {
        return $this->patternSources;
    }

    /**
     * Sets Pattern Sources.
     *
     * @maps patternSources
     *
     * @param DataMatchingSourceModel[]|null $patternSources
     */
    public function setPatternSources(?array $patternSources): void
    {
        $this->patternSources = $patternSources;
    }

    /**
     * Returns Match Sources.
     *
     * @return DataMatchingSourceModel[]|null
     */
    public function getMatchSources(): ?array
    {
        return $this->matchSources;
    }

    /**
     * Sets Match Sources.
     *
     * @maps matchSources
     *
     * @param DataMatchingSourceModel[]|null $matchSources
     */
    public function setMatchSources(?array $matchSources): void
    {
        $this->matchSources = $matchSources;
    }

    /**
     * Returns Country Short Names.
     *
     * @return string[]|null
     */
    public function getCountryShortNames(): ?array
    {
        return $this->countryShortNames;
    }

    /**
     * Sets Country Short Names.
     *
     * @maps countryShortNames
     *
     * @param string[]|null $countryShortNames
     */
    public function setCountryShortNames(?array $countryShortNames): void
    {
        $this->countryShortNames = $countryShortNames;
    }

    /**
     * Returns Data Matching Definition Id.
     */
    public function getDataMatchingDefinitionId(): ?string
    {
        return $this->dataMatchingDefinitionId;
    }

    /**
     * Sets Data Matching Definition Id.
     *
     * @maps dataMatchingDefinitionId
     */
    public function setDataMatchingDefinitionId(?string $dataMatchingDefinitionId): void
    {
        $this->dataMatchingDefinitionId = $dataMatchingDefinitionId;
    }

    /**
     * Returns Decision Log Ids.
     *
     * @return string[]|null
     */
    public function getDecisionLogIds(): ?array
    {
        return $this->decisionLogIds;
    }

    /**
     * Sets Decision Log Ids.
     *
     * @maps decisionLogIds
     *
     * @param string[]|null $decisionLogIds
     */
    public function setDecisionLogIds(?array $decisionLogIds): void
    {
        $this->decisionLogIds = $decisionLogIds;
    }

    /**
     * Returns Created At.
     */
    public function getCreatedAt(): ?string
    {
        return $this->createdAt;
    }

    /**
     * Sets Created At.
     *
     * @maps createdAt
     */
    public function setCreatedAt(?string $createdAt): void
    {
        $this->createdAt = $createdAt;
    }

    /**
     * Returns Created By.
     * User that started the job.
     */
    public function getCreatedBy(): ?string
    {
        return $this->createdBy;
    }

    /**
     * Sets Created By.
     * User that started the job.
     *
     * @maps createdBy
     */
    public function setCreatedBy(?string $createdBy): void
    {
        $this->createdBy = $createdBy;
    }

    /**
     * Returns Status.
     * Curation Job execution status.
     */
    public function getStatus(): ?string
    {
        return $this->status;
    }

    /**
     * Sets Status.
     * Curation Job execution status.
     *
     * @maps status
     * @factory \CalculatorLib\Models\JobStatusEnum::checkValue
     */
    public function setStatus(?string $status): void
    {
        $this->status = $status;
    }

    /**
     * Returns Progress.
     */
    public function getProgress(): ?int
    {
        return $this->progress;
    }

    /**
     * Sets Progress.
     *
     * @maps progress
     */
    public function setProgress(?int $progress): void
    {
        $this->progress = $progress;
    }

    private $additionalProperties = [];

    /**
     * Add an additional property to this model.
     *
     * @param string $name Name of property
     * @param mixed $value Value of property
     */
    public function addAdditionalProperty(string $name, $value)
    {
        $this->additionalProperties[$name] = $value;
    }

    /**
     * Encode this object to JSON
     *
     * @param bool $asArrayWhenEmpty Whether to serialize this model as an array whenever no fields
     *        are set. (default: false)
     *
     * @return array|stdClass
     */
    #[\ReturnTypeWillChange] // @phan-suppress-current-line PhanUndeclaredClassAttribute for (php < 8.1)
    public function jsonSerialize(bool $asArrayWhenEmpty = false)
    {
        $json = [];
        if (isset($this->id)) {
            $json['id']                       = $this->id;
        }
        if (isset($this->patternSources)) {
            $json['patternSources']           = $this->patternSources;
        }
        if (isset($this->matchSources)) {
            $json['matchSources']             = $this->matchSources;
        }
        if (isset($this->countryShortNames)) {
            $json['countryShortNames']        = $this->countryShortNames;
        }
        if (isset($this->dataMatchingDefinitionId)) {
            $json['dataMatchingDefinitionId'] = $this->dataMatchingDefinitionId;
        }
        if (isset($this->decisionLogIds)) {
            $json['decisionLogIds']           = $this->decisionLogIds;
        }
        if (isset($this->createdAt)) {
            $json['createdAt']                = $this->createdAt;
        }
        if (isset($this->createdBy)) {
            $json['createdBy']                = $this->createdBy;
        }
        if (isset($this->status)) {
            $json['status']                   = JobStatusEnum::checkValue($this->status);
        }
        if (isset($this->progress)) {
            $json['progress']                 = $this->progress;
        }
        $json = array_merge($json, $this->additionalProperties);

        return (!$asArrayWhenEmpty && empty($json)) ? new stdClass() : $json;
    }
}
