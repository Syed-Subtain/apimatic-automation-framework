<?php

declare(strict_types=1);

/*
 * Calculator
 *
 * This file was automatically generated for Label by APIMATIC v3.0 ( https://www.apimatic.io ).
 */

namespace CalculatorLib\Controllers;

use CalculatorLib\Exceptions\ApiException;
use CalculatorLib\ConfigurationInterface;
use CalculatorLib\ApiHelper;
use CalculatorLib\Models;
use CalculatorLib\Utils\FileWrapper;
use CalculatorLib\Http\HttpRequest;
use CalculatorLib\Http\HttpResponse;
use CalculatorLib\Http\HttpMethod;
use CalculatorLib\Http\HttpContext;
use CalculatorLib\Http\HttpCallBack;

class UserFeedbackController extends BaseController
{
    public function __construct(ConfigurationInterface $config, array $authManagers, ?HttpCallBack $httpCallBack)
    {
        parent::__construct($config, $authManagers, $httpCallBack);
    }

    /**
     * Read available Matching Decision Logs across your organization.
     *
     * @param array $options Array with all options for search
     *
     * @return Models\MatchingDecisionLogsModel|null Response from the API call
     *
     * @throws ApiException Thrown if API call fails
     */
    public function readUserFeedbacks(array $options): ?Models\MatchingDecisionLogsModel
    {
        //prepare query string for API call
        $_queryUrl = $this->config->getBaseUri() . '/userfeedbacks';

        //process query parameters
        ApiHelper::appendUrlWithQueryParameters($_queryUrl, [
            'startAfter' => $this->val($options, 'startAfter'),
            'limit'      => $this->val($options, 'limit', 20),
        ]);

        //prepare headers
        $_headers = [
            'user-agent'    => self::$userAgent,
            'Accept'        => 'application/json'
        ];

        $_httpRequest = new HttpRequest(HttpMethod::GET, $_headers, $_queryUrl);

        // Apply authorization to request
        $this->getAuthManager('global')->apply($_httpRequest);

        //call on-before Http callback
        if ($this->getHttpCallBack() != null) {
            $this->getHttpCallBack()->callOnBeforeRequest($_httpRequest);
        }

        // and invoke the API call request to fetch the response
        try {
            $response = self::$request->get($_httpRequest->getQueryUrl(), $_httpRequest->getHeaders());
        } catch (\Unirest\Exception $ex) {
            throw new ApiException($ex->getMessage(), $_httpRequest);
        }


        $_httpResponse = new HttpResponse($response->code, $response->headers, $response->raw_body);
        $_httpContext = new HttpContext($_httpRequest, $_httpResponse);

        //call on-after Http callback
        if ($this->getHttpCallBack() != null) {
            $this->getHttpCallBack()->callOnAfterRequest($_httpContext);
        }

        //Error handling using HTTP status codes
        //return null on 404
        if ($response->code == 404) {
            return null;
        }
        if ($response->code == 401) {
            throw new ApiException('Unauthorized', $_httpRequest, $_httpResponse);
        }

        if ($response->code == 403) {
            throw new ApiException('Forbidden', $_httpRequest, $_httpResponse);
        }

        //handle errors defined at the API level
        $this->validateResponse($_httpResponse, $_httpRequest);
        return ApiHelper::mapClass($_httpRequest, $_httpResponse, $response->body, 'MatchingDecisionLogsModel');
    }

    /**
     * Read Matching Decision Logs details provided by ID.
     *
     * @param string $id
     *
     * @return Models\MatchingDecisionLogResultModel|null Response from the API call
     *
     * @throws ApiException Thrown if API call fails
     */
    public function readUserFeedbackByID(string $id): ?Models\MatchingDecisionLogResultModel
    {
        //check that all required arguments are provided
        if (!isset($id)) {
            throw new \InvalidArgumentException("One or more required arguments were NULL.");
        }

        //prepare query string for API call
        $_queryUrl = $this->config->getBaseUri() . '/userfeedbacks/{id}';

        //process template parameters
        $_queryUrl = ApiHelper::appendUrlWithTemplateParameters($_queryUrl, [
            'id' => $id,
        ]);

        //prepare headers
        $_headers = [
            'user-agent'    => self::$userAgent,
            'Accept'        => 'application/json'
        ];

        $_httpRequest = new HttpRequest(HttpMethod::GET, $_headers, $_queryUrl);

        // Apply authorization to request
        $this->getAuthManager('global')->apply($_httpRequest);

        //call on-before Http callback
        if ($this->getHttpCallBack() != null) {
            $this->getHttpCallBack()->callOnBeforeRequest($_httpRequest);
        }

        // and invoke the API call request to fetch the response
        try {
            $response = self::$request->get($_httpRequest->getQueryUrl(), $_httpRequest->getHeaders());
        } catch (\Unirest\Exception $ex) {
            throw new ApiException($ex->getMessage(), $_httpRequest);
        }


        $_httpResponse = new HttpResponse($response->code, $response->headers, $response->raw_body);
        $_httpContext = new HttpContext($_httpRequest, $_httpResponse);

        //call on-after Http callback
        if ($this->getHttpCallBack() != null) {
            $this->getHttpCallBack()->callOnAfterRequest($_httpContext);
        }

        //Error handling using HTTP status codes
        //return null on 404
        if ($response->code == 404) {
            return null;
        }
        if ($response->code == 401) {
            throw new ApiException('Unauthorized', $_httpRequest, $_httpResponse);
        }

        if ($response->code == 403) {
            throw new ApiException('Forbidden', $_httpRequest, $_httpResponse);
        }

        //handle errors defined at the API level
        $this->validateResponse($_httpResponse, $_httpRequest);
        return ApiHelper::mapClass($_httpRequest, $_httpResponse, $response->body, 'MatchingDecisionLogResultModel');
    }

    /**
     * Add Identity Links to the Matching Decision Log identified by ID.
     *
     * @param array $options Array with all options for search
     *
     * @return Models\IdentityLinkCreateResultModel|null Response from the API call
     *
     * @throws ApiException Thrown if API call fails
     */
    public function createIdentityLink(array $options): ?Models\IdentityLinkCreateResultModel
    {
        //check that all required arguments are provided
        if (!isset($options['id'], $options['body'])) {
            throw new \InvalidArgumentException("One or more required arguments were NULL.");
        }

        //prepare query string for API call
        $_queryUrl = $this->config->getBaseUri() . '/userfeedbacks/{id}';

        //process template parameters
        $_queryUrl = ApiHelper::appendUrlWithTemplateParameters($_queryUrl, [
            'id'           => $this->val($options, 'id'),
        ]);

        //prepare headers
        $_headers = [
            'user-agent'    => self::$userAgent,
            'Accept'        => 'application/json',
            'Content-Type'    => 'application/json'
        ];

        //json encode body
        $_bodyJson = ApiHelper::serialize($this->val($options, 'body'));

        $_httpRequest = new HttpRequest(HttpMethod::POST, $_headers, $_queryUrl);

        // Apply authorization to request
        $this->getAuthManager('global')->apply($_httpRequest);

        //call on-before Http callback
        if ($this->getHttpCallBack() != null) {
            $this->getHttpCallBack()->callOnBeforeRequest($_httpRequest);
        }

        // and invoke the API call request to fetch the response
        try {
            $response = self::$request->post($_httpRequest->getQueryUrl(), $_httpRequest->getHeaders(), $_bodyJson);
        } catch (\Unirest\Exception $ex) {
            throw new ApiException($ex->getMessage(), $_httpRequest);
        }


        $_httpResponse = new HttpResponse($response->code, $response->headers, $response->raw_body);
        $_httpContext = new HttpContext($_httpRequest, $_httpResponse);

        //call on-after Http callback
        if ($this->getHttpCallBack() != null) {
            $this->getHttpCallBack()->callOnAfterRequest($_httpContext);
        }

        //Error handling using HTTP status codes
        //return null on 404
        if ($response->code == 404) {
            return null;
        }
        if ($response->code == 401) {
            throw new ApiException('Unauthorized', $_httpRequest, $_httpResponse);
        }

        if ($response->code == 403) {
            throw new ApiException('Forbidden', $_httpRequest, $_httpResponse);
        }

        //handle errors defined at the API level
        $this->validateResponse($_httpResponse, $_httpRequest);
        return ApiHelper::mapClass($_httpRequest, $_httpResponse, $response->body, 'IdentityLinkCreateResultModel');
    }

    /**
     * To start importing an Identity Linkage Decision import file, use the following request.
     *
     * ```
     * POST https://api.corporate-data-league.ch/data-matching/rest/jobs/matchingdecisionjobs
     * ?file=@{YOUR FILE}
     * ?decisionLogId={YOUR MatchingDecisionLog ID}
     * ```
     *
     * With using output file from duplication or linkage job.
     *
     * The response is shown below. Use the returned `id` to [poll](#/rest/api-endpoints/identity-
     * linkage/poll-matching-decision-import-job-status) the import job status.
     *
     * ```
     * {
     * "id" : "{YOUR JOB ID}"
     * ...
     * }
     * ```
     *
     * This import leads to the following link in the MatchingDecisionLog.
     *
     * ```
     * {
     * "id" : "{AUTO GENERATED}",
     * "decisionLogId" : "b7d528eace273a10aeb00825f48b5b18",
     * "entities" : [{
     * "storageId": "b7d528eace273a10aeb00825f48b5b18",
     * "dataSourceId": "5f9fc1b97e1e490001fcfc9e",
     * "businessPartnerId": "5e60dfdbd5fa2d000166ab4a"
     * },
     * {
     * "storageId": "b7d528eace273a10aeb00825f48b5b18",
     * "dataSourceId": "5f9fc1b97e1e490001fcfc9e",
     * "businessPartnerId": "5e60dfdbd5fa2d000166ab4b"
     * }]
     * }
     * ```
     *
     *
     * @param array $options Array with all options for search
     *
     * @return Models\MatchingDecisionImportJobModel|null Response from the API call
     *
     * @throws ApiException Thrown if API call fails
     */
    public function startMatchingDecisionImportJob(array $options): ?Models\MatchingDecisionImportJobModel
    {
        //check that all required arguments are provided
        if (!isset($options['file'], $options['decisionLogId'])) {
            throw new \InvalidArgumentException("One or more required arguments were NULL.");
        }

        //prepare query string for API call
        $_queryUrl = $this->config->getBaseUri() . '/matchingdecisionjobs';

        //prepare headers
        $_headers = [
            'user-agent'    => self::$userAgent,
            'Accept'        => 'application/json'
        ];

        //prepare parameters
        $_parameters = [
            'file'          => $this->val($options, 'file')->createCurlFileInstance('application/octet-stream'),
            'decisionLogId' => $this->val($options, 'decisionLogId'),
            'batchSize'     => $this->val($options, 'batchSize')
        ];

        $_httpRequest = new HttpRequest(HttpMethod::POST, $_headers, $_queryUrl, $_parameters);

        // Apply authorization to request
        $this->getAuthManager('global')->apply($_httpRequest);

        //call on-before Http callback
        if ($this->getHttpCallBack() != null) {
            $this->getHttpCallBack()->callOnBeforeRequest($_httpRequest);
        }

        // and invoke the API call request to fetch the response
        try {
            $response = self::$request->post(
                $_httpRequest->getQueryUrl(),
                $_httpRequest->getHeaders(),
                \Unirest\Request::buildHTTPCurlQuery($_parameters)
            );
        } catch (\Unirest\Exception $ex) {
            throw new ApiException($ex->getMessage(), $_httpRequest);
        }


        $_httpResponse = new HttpResponse($response->code, $response->headers, $response->raw_body);
        $_httpContext = new HttpContext($_httpRequest, $_httpResponse);

        //call on-after Http callback
        if ($this->getHttpCallBack() != null) {
            $this->getHttpCallBack()->callOnAfterRequest($_httpContext);
        }

        //return null on 404
        if ($response->code == 404) {
            return null;
        }
        //handle errors defined at the API level
        $this->validateResponse($_httpResponse, $_httpRequest);
        return ApiHelper::mapClass($_httpRequest, $_httpResponse, $response->body, 'MatchingDecisionImportJobModel');
    }

    /**
     * Delete the Matching Decision Log identified by ID. Warning: action cannot be reverted!
     *
     * @param string $id
     *
     * @return void Response from the API call
     *
     * @throws ApiException Thrown if API call fails
     */
    public function deleteUserFeedback(string $id): void
    {
        //check that all required arguments are provided
        if (!isset($id)) {
            throw new \InvalidArgumentException("One or more required arguments were NULL.");
        }

        //prepare query string for API call
        $_queryUrl = $this->config->getBaseUri() . '/userfeedbacks/{id}';

        //process template parameters
        $_queryUrl = ApiHelper::appendUrlWithTemplateParameters($_queryUrl, [
            'id' => $id,
        ]);

        //prepare headers
        $_headers = [
            'user-agent'    => self::$userAgent
        ];

        $_httpRequest = new HttpRequest(HttpMethod::DELETE, $_headers, $_queryUrl);

        // Apply authorization to request
        $this->getAuthManager('global')->apply($_httpRequest);

        //call on-before Http callback
        if ($this->getHttpCallBack() != null) {
            $this->getHttpCallBack()->callOnBeforeRequest($_httpRequest);
        }

        // and invoke the API call request to fetch the response
        try {
            $response = self::$request->delete($_httpRequest->getQueryUrl(), $_httpRequest->getHeaders());
        } catch (\Unirest\Exception $ex) {
            throw new ApiException($ex->getMessage(), $_httpRequest);
        }


        $_httpResponse = new HttpResponse($response->code, $response->headers, $response->raw_body);
        $_httpContext = new HttpContext($_httpRequest, $_httpResponse);

        //call on-after Http callback
        if ($this->getHttpCallBack() != null) {
            $this->getHttpCallBack()->callOnAfterRequest($_httpContext);
        }

        //Error handling using HTTP status codes
        if ($response->code == 400) {
            throw $this->createExceptionFromJson(
                '\\CalculatorLib\\Exceptions\\ApiErrorException',
                'The sent request is malformed.',
                $_httpRequest,
                $_httpResponse
            );
        }

        if ($response->code == 403) {
            throw $this->createExceptionFromJson(
                '\\CalculatorLib\\Exceptions\\ApiErrorException',
                'Permission denied.',
                $_httpRequest,
                $_httpResponse
            );
        }

        //handle errors defined at the API level
        $this->validateResponse($_httpResponse, $_httpRequest);
    }

    /**
     * Poll Matching Decision Import Job status
     *
     * @param string $id ID of the Matching Decision Import Job
     *
     * @return Models\MatchingDecisionImportJobModel|null Response from the API call
     *
     * @throws ApiException Thrown if API call fails
     */
    public function pollMatchingDecisionImportJobStatus(string $id): ?Models\MatchingDecisionImportJobModel
    {
        //check that all required arguments are provided
        if (!isset($id)) {
            throw new \InvalidArgumentException("One or more required arguments were NULL.");
        }

        //prepare query string for API call
        $_queryUrl = $this->config->getBaseUri() . '/matchingdecisionjobs/{id}';

        //process template parameters
        $_queryUrl = ApiHelper::appendUrlWithTemplateParameters($_queryUrl, [
            'id' => $id,
        ]);

        //prepare headers
        $_headers = [
            'user-agent'    => self::$userAgent,
            'Accept'        => 'application/json'
        ];

        $_httpRequest = new HttpRequest(HttpMethod::GET, $_headers, $_queryUrl);

        // Apply authorization to request
        $this->getAuthManager('global')->apply($_httpRequest);

        //call on-before Http callback
        if ($this->getHttpCallBack() != null) {
            $this->getHttpCallBack()->callOnBeforeRequest($_httpRequest);
        }

        // and invoke the API call request to fetch the response
        try {
            $response = self::$request->get($_httpRequest->getQueryUrl(), $_httpRequest->getHeaders());
        } catch (\Unirest\Exception $ex) {
            throw new ApiException($ex->getMessage(), $_httpRequest);
        }


        $_httpResponse = new HttpResponse($response->code, $response->headers, $response->raw_body);
        $_httpContext = new HttpContext($_httpRequest, $_httpResponse);

        //call on-after Http callback
        if ($this->getHttpCallBack() != null) {
            $this->getHttpCallBack()->callOnAfterRequest($_httpContext);
        }

        //Error handling using HTTP status codes
        //return null on 404
        if ($response->code == 404) {
            return null;
        }
        if ($response->code == 401) {
            throw new ApiException('Unauthorized', $_httpRequest, $_httpResponse);
        }

        if ($response->code == 403) {
            throw new ApiException('Forbidden', $_httpRequest, $_httpResponse);
        }

        //handle errors defined at the API level
        $this->validateResponse($_httpResponse, $_httpRequest);
        return ApiHelper::mapClass($_httpRequest, $_httpResponse, $response->body, 'MatchingDecisionImportJobModel');
    }

    /**
     * Remove all links from the Matching Decision Log identified by ID. Warning: action cannot be reverted!
     *
     * @param string $id
     *
     * @return void Response from the API call
     *
     * @throws ApiException Thrown if API call fails
     */
    public function userfeedbacksClearByIdPOST(string $id): void
    {
        //check that all required arguments are provided
        if (!isset($id)) {
            throw new \InvalidArgumentException("One or more required arguments were NULL.");
        }

        //prepare query string for API call
        $_queryUrl = $this->config->getBaseUri() . '/userfeedbacks/{id}/clear';

        //process template parameters
        $_queryUrl = ApiHelper::appendUrlWithTemplateParameters($_queryUrl, [
            'id' => $id,
        ]);

        //prepare headers
        $_headers = [
            'user-agent'    => self::$userAgent
        ];

        $_httpRequest = new HttpRequest(HttpMethod::POST, $_headers, $_queryUrl);

        // Apply authorization to request
        $this->getAuthManager('global')->apply($_httpRequest);

        //call on-before Http callback
        if ($this->getHttpCallBack() != null) {
            $this->getHttpCallBack()->callOnBeforeRequest($_httpRequest);
        }

        // and invoke the API call request to fetch the response
        try {
            $response = self::$request->post($_httpRequest->getQueryUrl(), $_httpRequest->getHeaders());
        } catch (\Unirest\Exception $ex) {
            throw new ApiException($ex->getMessage(), $_httpRequest);
        }


        $_httpResponse = new HttpResponse($response->code, $response->headers, $response->raw_body);
        $_httpContext = new HttpContext($_httpRequest, $_httpResponse);

        //call on-after Http callback
        if ($this->getHttpCallBack() != null) {
            $this->getHttpCallBack()->callOnAfterRequest($_httpContext);
        }

        //Error handling using HTTP status codes
        if ($response->code == 401) {
            throw new ApiException('Unauthorized', $_httpRequest, $_httpResponse);
        }

        if ($response->code == 403) {
            throw new ApiException('Forbidden', $_httpRequest, $_httpResponse);
        }

        if ($response->code == 404) {
            throw new ApiException('Not Found', $_httpRequest, $_httpResponse);
        }

        //handle errors defined at the API level
        $this->validateResponse($_httpResponse, $_httpRequest);
    }

    /**
     * Create Matching Decision Log where decisions will be stored.
     *
     * @param Models\MatchingDecisionLogCreateRequestModel $body
     *
     * @return Models\MatchingDecisionLogModel|null Response from the API call
     *
     * @throws ApiException Thrown if API call fails
     */
    public function createUserFeedback(
        Models\MatchingDecisionLogCreateRequestModel $body
    ): ?Models\MatchingDecisionLogModel {
        //check that all required arguments are provided
        if (!isset($body)) {
            throw new \InvalidArgumentException("One or more required arguments were NULL.");
        }

        //prepare query string for API call
        $_queryUrl = $this->config->getBaseUri() . '/userfeedbacks';

        //prepare headers
        $_headers = [
            'user-agent'    => self::$userAgent,
            'Accept'        => 'application/json',
            'Content-Type'    => 'application/json'
        ];

        //json encode body
        $_bodyJson = ApiHelper::serialize($body);

        $_httpRequest = new HttpRequest(HttpMethod::POST, $_headers, $_queryUrl);

        // Apply authorization to request
        $this->getAuthManager('global')->apply($_httpRequest);

        //call on-before Http callback
        if ($this->getHttpCallBack() != null) {
            $this->getHttpCallBack()->callOnBeforeRequest($_httpRequest);
        }

        // and invoke the API call request to fetch the response
        try {
            $response = self::$request->post($_httpRequest->getQueryUrl(), $_httpRequest->getHeaders(), $_bodyJson);
        } catch (\Unirest\Exception $ex) {
            throw new ApiException($ex->getMessage(), $_httpRequest);
        }


        $_httpResponse = new HttpResponse($response->code, $response->headers, $response->raw_body);
        $_httpContext = new HttpContext($_httpRequest, $_httpResponse);

        //call on-after Http callback
        if ($this->getHttpCallBack() != null) {
            $this->getHttpCallBack()->callOnAfterRequest($_httpContext);
        }

        //Error handling using HTTP status codes
        //return null on 404
        if ($response->code == 404) {
            return null;
        }
        if ($response->code == 401) {
            throw new ApiException('Unauthorized', $_httpRequest, $_httpResponse);
        }

        if ($response->code == 403) {
            throw new ApiException('Forbidden', $_httpRequest, $_httpResponse);
        }

        //handle errors defined at the API level
        $this->validateResponse($_httpResponse, $_httpRequest);
        return ApiHelper::mapClass($_httpRequest, $_httpResponse, $response->body, 'MatchingDecisionLogModel');
    }

    /**
     * Read Identity Links from the Matching Decision Log identified by ID.
     *
     * @param array $options Array with all options for search
     *
     * @return Models\IdentityLinksModel|null Response from the API call
     *
     * @throws ApiException Thrown if API call fails
     */
    public function readIdentityLinks(array $options): ?Models\IdentityLinksModel
    {
        //check that all required arguments are provided
        if (!isset($options['decisionLogId'])) {
            throw new \InvalidArgumentException("One or more required arguments were NULL.");
        }

        //prepare query string for API call
        $_queryUrl = $this->config->getBaseUri() . '/userfeedbacks/identitylinks';

        //process query parameters
        ApiHelper::appendUrlWithQueryParameters($_queryUrl, [
            'decisionLogId'     => $this->val($options, 'decisionLogId'),
            'startAfter'        => $this->val($options, 'startAfter'),
            'limit'             => $this->val($options, 'limit', 20),
            'storageId'         => $this->val($options, 'storageId'),
            'dataSourceId'      => $this->val($options, 'dataSourceId'),
            'businessPartnerId' => $this->val($options, 'businessPartnerId'),
        ]);

        //prepare headers
        $_headers = [
            'user-agent'      => self::$userAgent,
            'Accept'          => 'application/json'
        ];

        $_httpRequest = new HttpRequest(HttpMethod::GET, $_headers, $_queryUrl);

        // Apply authorization to request
        $this->getAuthManager('global')->apply($_httpRequest);

        //call on-before Http callback
        if ($this->getHttpCallBack() != null) {
            $this->getHttpCallBack()->callOnBeforeRequest($_httpRequest);
        }

        // and invoke the API call request to fetch the response
        try {
            $response = self::$request->get($_httpRequest->getQueryUrl(), $_httpRequest->getHeaders());
        } catch (\Unirest\Exception $ex) {
            throw new ApiException($ex->getMessage(), $_httpRequest);
        }


        $_httpResponse = new HttpResponse($response->code, $response->headers, $response->raw_body);
        $_httpContext = new HttpContext($_httpRequest, $_httpResponse);

        //call on-after Http callback
        if ($this->getHttpCallBack() != null) {
            $this->getHttpCallBack()->callOnAfterRequest($_httpContext);
        }

        //Error handling using HTTP status codes
        //return null on 404
        if ($response->code == 404) {
            return null;
        }
        if ($response->code == 401) {
            throw new ApiException('Unauthorized', $_httpRequest, $_httpResponse);
        }

        if ($response->code == 403) {
            throw new ApiException('Forbidden', $_httpRequest, $_httpResponse);
        }

        //handle errors defined at the API level
        $this->validateResponse($_httpResponse, $_httpRequest);
        return ApiHelper::mapClass($_httpRequest, $_httpResponse, $response->body, 'IdentityLinksModel');
    }

    /**
     * Array access utility method
     * @param  array          $arr         Array of values to read from
     * @param  string         $key         Key to get the value from the array
     * @param  mixed|null     $default     Default value to use if the key was not found
     * @return mixed
     */
    private function val(array $arr, string $key, $default = null)
    {
        if (isset($arr[$key])) {
            return is_bool($arr[$key]) ? var_export($arr[$key], true) : $arr[$key];
        }
        return $default;
    }
}
