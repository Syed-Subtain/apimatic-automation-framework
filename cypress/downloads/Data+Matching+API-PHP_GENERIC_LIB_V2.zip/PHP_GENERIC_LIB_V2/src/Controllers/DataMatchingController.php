<?php

declare(strict_types=1);

/*
 * Calculator
 *
 * This file was automatically generated for Label by APIMATIC v3.0 ( https://www.apimatic.io ).
 */

namespace CalculatorLib\Controllers;

use CalculatorLib\Exceptions\ApiException;
use CalculatorLib\ConfigurationInterface;
use CalculatorLib\ApiHelper;
use CalculatorLib\Models;
use CalculatorLib\Http\HttpRequest;
use CalculatorLib\Http\HttpResponse;
use CalculatorLib\Http\HttpMethod;
use CalculatorLib\Http\HttpContext;
use CalculatorLib\Http\HttpCallBack;

class DataMatchingController extends BaseController
{
    public function __construct(ConfigurationInterface $config, array $authManagers, ?HttpCallBack $httpCallBack)
    {
        parent::__construct($config, $authManagers, $httpCallBack);
    }

    /**
     * Read a page of existing DataMatchingDefinitions
     *
     * @param array $options Array with all options for search
     *
     * @return Models\DataMatchingDefinitionPageModel|null Response from the API call
     *
     * @throws ApiException Thrown if API call fails
     */
    public function readAPageOfExistingDataMatchingDefinitions(array $options): ?Models\DataMatchingDefinitionPageModel
    {
        //prepare query string for API call
        $_queryUrl = $this->config->getBaseUri() . '/datamatchingdefinitions';

        //process query parameters
        ApiHelper::appendUrlWithQueryParameters($_queryUrl, [
            'page'         => $this->val($options, 'page', 0),
            'pageSize'     => $this->val($options, 'pageSize', 20),
            'matchingType' => Models\MatchingTypeEnum::checkValue($this->val($options, 'matchingType')),
            'workspaceId'  => $this->val($options, 'workspaceId'),
        ]);

        //prepare headers
        $_headers = [
            'user-agent'    => self::$userAgent,
            'Accept'        => 'application/json'
        ];

        $_httpRequest = new HttpRequest(HttpMethod::GET, $_headers, $_queryUrl);

        // Apply authorization to request
        $this->getAuthManager('global')->apply($_httpRequest);

        //call on-before Http callback
        if ($this->getHttpCallBack() != null) {
            $this->getHttpCallBack()->callOnBeforeRequest($_httpRequest);
        }

        // and invoke the API call request to fetch the response
        try {
            $response = self::$request->get($_httpRequest->getQueryUrl(), $_httpRequest->getHeaders());
        } catch (\Unirest\Exception $ex) {
            throw new ApiException($ex->getMessage(), $_httpRequest);
        }


        $_httpResponse = new HttpResponse($response->code, $response->headers, $response->raw_body);
        $_httpContext = new HttpContext($_httpRequest, $_httpResponse);

        //call on-after Http callback
        if ($this->getHttpCallBack() != null) {
            $this->getHttpCallBack()->callOnAfterRequest($_httpContext);
        }

        //Error handling using HTTP status codes
        //return null on 404
        if ($response->code == 404) {
            return null;
        }
        if ($response->code == 400) {
            throw $this->createExceptionFromJson(
                '\\CalculatorLib\\Exceptions\\ApiErrorException',
                'The sent request is malformed.',
                $_httpRequest,
                $_httpResponse
            );
        }

        if ($response->code == 403) {
            throw $this->createExceptionFromJson(
                '\\CalculatorLib\\Exceptions\\ApiErrorException',
                'Permission denied.',
                $_httpRequest,
                $_httpResponse
            );
        }

        //handle errors defined at the API level
        $this->validateResponse($_httpResponse, $_httpRequest);
        return ApiHelper::mapClass($_httpRequest, $_httpResponse, $response->body, 'DataMatchingDefinitionPageModel');
    }

    /**
     * Delete a DataMatchingDefinition
     *
     * @param string $id id
     *
     * @return void Response from the API call
     *
     * @throws ApiException Thrown if API call fails
     */
    public function deleteADataMatchingDefinition(string $id): void
    {
        //check that all required arguments are provided
        if (!isset($id)) {
            throw new \InvalidArgumentException("One or more required arguments were NULL.");
        }

        //prepare query string for API call
        $_queryUrl = $this->config->getBaseUri() . '/datamatchingdefinitions/{id}';

        //process template parameters
        $_queryUrl = ApiHelper::appendUrlWithTemplateParameters($_queryUrl, [
            'id' => $id,
        ]);

        //prepare headers
        $_headers = [
            'user-agent'    => self::$userAgent
        ];

        $_httpRequest = new HttpRequest(HttpMethod::DELETE, $_headers, $_queryUrl);

        // Apply authorization to request
        $this->getAuthManager('global')->apply($_httpRequest);

        //call on-before Http callback
        if ($this->getHttpCallBack() != null) {
            $this->getHttpCallBack()->callOnBeforeRequest($_httpRequest);
        }

        // and invoke the API call request to fetch the response
        try {
            $response = self::$request->delete($_httpRequest->getQueryUrl(), $_httpRequest->getHeaders());
        } catch (\Unirest\Exception $ex) {
            throw new ApiException($ex->getMessage(), $_httpRequest);
        }


        $_httpResponse = new HttpResponse($response->code, $response->headers, $response->raw_body);
        $_httpContext = new HttpContext($_httpRequest, $_httpResponse);

        //call on-after Http callback
        if ($this->getHttpCallBack() != null) {
            $this->getHttpCallBack()->callOnAfterRequest($_httpContext);
        }

        //Error handling using HTTP status codes
        if ($response->code == 400) {
            throw $this->createExceptionFromJson(
                '\\CalculatorLib\\Exceptions\\ApiErrorException',
                'The sent request is malformed.',
                $_httpRequest,
                $_httpResponse
            );
        }

        if ($response->code == 403) {
            throw $this->createExceptionFromJson(
                '\\CalculatorLib\\Exceptions\\ApiErrorException',
                'Permission denied.',
                $_httpRequest,
                $_httpResponse
            );
        }

        //handle errors defined at the API level
        $this->validateResponse($_httpResponse, $_httpRequest);
    }

    /**
     * Update a DataMatchingDefinition
     *
     * @param array $options Array with all options for search
     *
     * @return Models\DataMatchingDefinitionModel|null Response from the API call
     *
     * @throws ApiException Thrown if API call fails
     */
    public function updateADataMatchingDefinition(array $options): ?Models\DataMatchingDefinitionModel
    {
        //check that all required arguments are provided
        if (!isset($options['id'], $options['body'])) {
            throw new \InvalidArgumentException("One or more required arguments were NULL.");
        }

        //prepare query string for API call
        $_queryUrl = $this->config->getBaseUri() . '/datamatchingdefinitions/{id}';

        //process template parameters
        $_queryUrl = ApiHelper::appendUrlWithTemplateParameters($_queryUrl, [
            'id'           => $this->val($options, 'id'),
        ]);

        //prepare headers
        $_headers = [
            'user-agent'    => self::$userAgent,
            'Accept'        => 'application/json',
            'Content-Type'    => 'application/json'
        ];

        //json encode body
        $_bodyJson = ApiHelper::serialize($this->val($options, 'body'));

        $_httpRequest = new HttpRequest(HttpMethod::PUT, $_headers, $_queryUrl);

        // Apply authorization to request
        $this->getAuthManager('global')->apply($_httpRequest);

        //call on-before Http callback
        if ($this->getHttpCallBack() != null) {
            $this->getHttpCallBack()->callOnBeforeRequest($_httpRequest);
        }

        // and invoke the API call request to fetch the response
        try {
            $response = self::$request->put($_httpRequest->getQueryUrl(), $_httpRequest->getHeaders(), $_bodyJson);
        } catch (\Unirest\Exception $ex) {
            throw new ApiException($ex->getMessage(), $_httpRequest);
        }


        $_httpResponse = new HttpResponse($response->code, $response->headers, $response->raw_body);
        $_httpContext = new HttpContext($_httpRequest, $_httpResponse);

        //call on-after Http callback
        if ($this->getHttpCallBack() != null) {
            $this->getHttpCallBack()->callOnAfterRequest($_httpContext);
        }

        //Error handling using HTTP status codes
        //return null on 404
        if ($response->code == 404) {
            return null;
        }
        if ($response->code == 400) {
            throw $this->createExceptionFromJson(
                '\\CalculatorLib\\Exceptions\\ApiErrorException',
                'The sent request is malformed.',
                $_httpRequest,
                $_httpResponse
            );
        }

        if ($response->code == 403) {
            throw $this->createExceptionFromJson(
                '\\CalculatorLib\\Exceptions\\ApiErrorException',
                'Permission denied.',
                $_httpRequest,
                $_httpResponse
            );
        }

        //handle errors defined at the API level
        $this->validateResponse($_httpResponse, $_httpRequest);
        return ApiHelper::mapClass($_httpRequest, $_httpResponse, $response->body, 'DataMatchingDefinitionModel');
    }

    /**
     * Create a new DataMatchingDefinition
     *
     * @param Models\DataMatchingDefinitionCreateModel $body
     *
     * @return Models\DataMatchingDefinitionModel|null Response from the API call
     *
     * @throws ApiException Thrown if API call fails
     */
    public function createANewDataMatchingDefinition(
        Models\DataMatchingDefinitionCreateModel $body
    ): ?Models\DataMatchingDefinitionModel {
        //check that all required arguments are provided
        if (!isset($body)) {
            throw new \InvalidArgumentException("One or more required arguments were NULL.");
        }

        //prepare query string for API call
        $_queryUrl = $this->config->getBaseUri() . '/datamatchingdefinitions';

        //prepare headers
        $_headers = [
            'user-agent'    => self::$userAgent,
            'Accept'        => 'application/json',
            'Content-Type'    => 'application/json'
        ];

        //json encode body
        $_bodyJson = ApiHelper::serialize($body);

        $_httpRequest = new HttpRequest(HttpMethod::POST, $_headers, $_queryUrl);

        // Apply authorization to request
        $this->getAuthManager('global')->apply($_httpRequest);

        //call on-before Http callback
        if ($this->getHttpCallBack() != null) {
            $this->getHttpCallBack()->callOnBeforeRequest($_httpRequest);
        }

        // and invoke the API call request to fetch the response
        try {
            $response = self::$request->post($_httpRequest->getQueryUrl(), $_httpRequest->getHeaders(), $_bodyJson);
        } catch (\Unirest\Exception $ex) {
            throw new ApiException($ex->getMessage(), $_httpRequest);
        }


        $_httpResponse = new HttpResponse($response->code, $response->headers, $response->raw_body);
        $_httpContext = new HttpContext($_httpRequest, $_httpResponse);

        //call on-after Http callback
        if ($this->getHttpCallBack() != null) {
            $this->getHttpCallBack()->callOnAfterRequest($_httpContext);
        }

        //Error handling using HTTP status codes
        //return null on 404
        if ($response->code == 404) {
            return null;
        }
        if ($response->code == 400) {
            throw $this->createExceptionFromJson(
                '\\CalculatorLib\\Exceptions\\ApiErrorException',
                'The sent request is malformed.',
                $_httpRequest,
                $_httpResponse
            );
        }

        //handle errors defined at the API level
        $this->validateResponse($_httpResponse, $_httpRequest);
        return ApiHelper::mapClass($_httpRequest, $_httpResponse, $response->body, 'DataMatchingDefinitionModel');
    }

    /**
     * Read an existing DataMatchingDefinition
     *
     * @param string $id id
     *
     * @return Models\DataMatchingDefinitionModel|null Response from the API call
     *
     * @throws ApiException Thrown if API call fails
     */
    public function readAnExistingDataMatchingDefinition(string $id): ?Models\DataMatchingDefinitionModel
    {
        //check that all required arguments are provided
        if (!isset($id)) {
            throw new \InvalidArgumentException("One or more required arguments were NULL.");
        }

        //prepare query string for API call
        $_queryUrl = $this->config->getBaseUri() . '/datamatchingdefinitions/{id}';

        //process template parameters
        $_queryUrl = ApiHelper::appendUrlWithTemplateParameters($_queryUrl, [
            'id' => $id,
        ]);

        //prepare headers
        $_headers = [
            'user-agent'    => self::$userAgent,
            'Accept'        => 'application/json'
        ];

        $_httpRequest = new HttpRequest(HttpMethod::GET, $_headers, $_queryUrl);

        // Apply authorization to request
        $this->getAuthManager('global')->apply($_httpRequest);

        //call on-before Http callback
        if ($this->getHttpCallBack() != null) {
            $this->getHttpCallBack()->callOnBeforeRequest($_httpRequest);
        }

        // and invoke the API call request to fetch the response
        try {
            $response = self::$request->get($_httpRequest->getQueryUrl(), $_httpRequest->getHeaders());
        } catch (\Unirest\Exception $ex) {
            throw new ApiException($ex->getMessage(), $_httpRequest);
        }


        $_httpResponse = new HttpResponse($response->code, $response->headers, $response->raw_body);
        $_httpContext = new HttpContext($_httpRequest, $_httpResponse);

        //call on-after Http callback
        if ($this->getHttpCallBack() != null) {
            $this->getHttpCallBack()->callOnAfterRequest($_httpContext);
        }

        //Error handling using HTTP status codes
        //return null on 404
        if ($response->code == 404) {
            return null;
        }
        if ($response->code == 400) {
            throw $this->createExceptionFromJson(
                '\\CalculatorLib\\Exceptions\\ApiErrorException',
                'The sent request is malformed.',
                $_httpRequest,
                $_httpResponse
            );
        }

        if ($response->code == 403) {
            throw $this->createExceptionFromJson(
                '\\CalculatorLib\\Exceptions\\ApiErrorException',
                'Permission denied.',
                $_httpRequest,
                $_httpResponse
            );
        }

        //handle errors defined at the API level
        $this->validateResponse($_httpResponse, $_httpRequest);
        return ApiHelper::mapClass($_httpRequest, $_httpResponse, $response->body, 'DataMatchingDefinitionModel');
    }

    /**
     * Array access utility method
     * @param  array          $arr         Array of values to read from
     * @param  string         $key         Key to get the value from the array
     * @param  mixed|null     $default     Default value to use if the key was not found
     * @return mixed
     */
    private function val(array $arr, string $key, $default = null)
    {
        if (isset($arr[$key])) {
            return is_bool($arr[$key]) ? var_export($arr[$key], true) : $arr[$key];
        }
        return $default;
    }
}
