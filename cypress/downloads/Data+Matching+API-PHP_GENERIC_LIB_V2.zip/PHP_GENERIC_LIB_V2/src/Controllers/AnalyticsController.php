<?php

declare(strict_types=1);

/*
 * Calculator
 *
 * This file was automatically generated for Label by APIMATIC v3.0 ( https://www.apimatic.io ).
 */

namespace CalculatorLib\Controllers;

use CalculatorLib\Exceptions\ApiException;
use CalculatorLib\ConfigurationInterface;
use CalculatorLib\ApiHelper;
use CalculatorLib\Models;
use CalculatorLib\Http\HttpRequest;
use CalculatorLib\Http\HttpResponse;
use CalculatorLib\Http\HttpMethod;
use CalculatorLib\Http\HttpContext;
use CalculatorLib\Http\HttpCallBack;

class AnalyticsController extends BaseController
{
    public function __construct(ConfigurationInterface $config, array $authManagers, ?HttpCallBack $httpCallBack)
    {
        parent::__construct($config, $authManagers, $httpCallBack);
    }

    /**
     * Poll Matching Reports
     *
     * @param string $id ID of the matching report
     *
     * @return Models\MatchingReportsModel|null Response from the API call
     *
     * @throws ApiException Thrown if API call fails
     */
    public function pollMatchingReports(string $id): ?Models\MatchingReportsModel
    {
        //check that all required arguments are provided
        if (!isset($id)) {
            throw new \InvalidArgumentException("One or more required arguments were NULL.");
        }

        //prepare query string for API call
        $_queryUrl = $this->config->getBaseUri() . '/matchingreports/{id}';

        //process template parameters
        $_queryUrl = ApiHelper::appendUrlWithTemplateParameters($_queryUrl, [
            'id' => $id,
        ]);

        //prepare headers
        $_headers = [
            'user-agent'    => self::$userAgent,
            'Accept'        => 'application/json'
        ];

        $_httpRequest = new HttpRequest(HttpMethod::GET, $_headers, $_queryUrl);

        // Apply authorization to request
        $this->getAuthManager('global')->apply($_httpRequest);

        //call on-before Http callback
        if ($this->getHttpCallBack() != null) {
            $this->getHttpCallBack()->callOnBeforeRequest($_httpRequest);
        }

        // and invoke the API call request to fetch the response
        try {
            $response = self::$request->get($_httpRequest->getQueryUrl(), $_httpRequest->getHeaders());
        } catch (\Unirest\Exception $ex) {
            throw new ApiException($ex->getMessage(), $_httpRequest);
        }


        $_httpResponse = new HttpResponse($response->code, $response->headers, $response->raw_body);
        $_httpContext = new HttpContext($_httpRequest, $_httpResponse);

        //call on-after Http callback
        if ($this->getHttpCallBack() != null) {
            $this->getHttpCallBack()->callOnAfterRequest($_httpContext);
        }

        //Error handling using HTTP status codes
        //return null on 404
        if ($response->code == 404) {
            return null;
        }
        if ($response->code == 401) {
            throw new ApiException('Unauthorized', $_httpRequest, $_httpResponse);
        }

        if ($response->code == 403) {
            throw new ApiException('Forbidden', $_httpRequest, $_httpResponse);
        }

        //handle errors defined at the API level
        $this->validateResponse($_httpResponse, $_httpRequest);
        return ApiHelper::mapClass($_httpRequest, $_httpResponse, $response->body, 'MatchingReportsModel');
    }

    /**
     * Requests the building of data matching reports
     *
     *
     * @param Models\MatchingReportsRequestModel $body cmd
     *
     * @return Models\MatchingReportsModel|null Response from the API call
     *
     * @throws ApiException Thrown if API call fails
     */
    public function buildMatchingReports(Models\MatchingReportsRequestModel $body): ?Models\MatchingReportsModel
    {
        //check that all required arguments are provided
        if (!isset($body)) {
            throw new \InvalidArgumentException("One or more required arguments were NULL.");
        }

        //prepare query string for API call
        $_queryUrl = $this->config->getBaseUri() . '/matchingreports';

        //prepare headers
        $_headers = [
            'user-agent'    => self::$userAgent,
            'Accept'        => 'application/json',
            'Content-Type'    => 'application/json'
        ];

        //json encode body
        $_bodyJson = ApiHelper::serialize($body);

        $_httpRequest = new HttpRequest(HttpMethod::POST, $_headers, $_queryUrl);

        // Apply authorization to request
        $this->getAuthManager('global')->apply($_httpRequest);

        //call on-before Http callback
        if ($this->getHttpCallBack() != null) {
            $this->getHttpCallBack()->callOnBeforeRequest($_httpRequest);
        }

        // and invoke the API call request to fetch the response
        try {
            $response = self::$request->post($_httpRequest->getQueryUrl(), $_httpRequest->getHeaders(), $_bodyJson);
        } catch (\Unirest\Exception $ex) {
            throw new ApiException($ex->getMessage(), $_httpRequest);
        }


        $_httpResponse = new HttpResponse($response->code, $response->headers, $response->raw_body);
        $_httpContext = new HttpContext($_httpRequest, $_httpResponse);

        //call on-after Http callback
        if ($this->getHttpCallBack() != null) {
            $this->getHttpCallBack()->callOnAfterRequest($_httpContext);
        }

        //Error handling using HTTP status codes
        //return null on 404
        if ($response->code == 404) {
            return null;
        }
        if ($response->code == 401) {
            throw new ApiException('Unauthorized', $_httpRequest, $_httpResponse);
        }

        if ($response->code == 403) {
            throw new ApiException('Forbidden', $_httpRequest, $_httpResponse);
        }

        //handle errors defined at the API level
        $this->validateResponse($_httpResponse, $_httpRequest);
        return ApiHelper::mapClass($_httpRequest, $_httpResponse, $response->body, 'MatchingReportsModel');
    }
}
