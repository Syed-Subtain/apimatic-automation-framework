<?php

declare(strict_types=1);

/*
 * Calculator
 *
 * This file was automatically generated for Label by APIMATIC v3.0 ( https://www.apimatic.io ).
 */

namespace CalculatorLib;

use CalculatorLib\Controllers;

/**
 * Calculator client class
 */
class CalculatorClient implements ConfigurationInterface
{
    private $dataMatching;
    private $userFeedback;
    private $duplicateMatching;
    private $linkageMatching;
    private $analytics;

    private $timeout = ConfigurationDefaults::TIMEOUT;
    private $enableRetries = ConfigurationDefaults::ENABLE_RETRIES;
    private $numberOfRetries = ConfigurationDefaults::NUMBER_OF_RETRIES;
    private $retryInterval = ConfigurationDefaults::RETRY_INTERVAL;
    private $backOffFactor = ConfigurationDefaults::BACK_OFF_FACTOR;
    private $maximumRetryWaitTime = ConfigurationDefaults::MAXIMUM_RETRY_WAIT_TIME;
    private $retryOnTimeout = ConfigurationDefaults::RETRY_ON_TIMEOUT;
    private $httpStatusCodesToRetry = ConfigurationDefaults::HTTP_STATUS_CODES_TO_RETRY;
    private $httpMethodsToRetry = ConfigurationDefaults::HTTP_METHODS_TO_RETRY;
    private $environment = ConfigurationDefaults::ENVIRONMENT;
    private $basicAuthUserName = ConfigurationDefaults::BASIC_AUTH_USER_NAME;
    private $basicAuthPassword = ConfigurationDefaults::BASIC_AUTH_PASSWORD;
    private $basicAuthManager;
    private $authManagers = [];
    private $httpCallback;

    public function __construct(array $configOptions = null)
    {
        if (isset($configOptions['timeout'])) {
            $this->timeout = $configOptions['timeout'];
        }
        if (isset($configOptions['enableRetries'])) {
            $this->enableRetries = $configOptions['enableRetries'];
        }
        if (isset($configOptions['numberOfRetries'])) {
            $this->numberOfRetries = $configOptions['numberOfRetries'];
        }
        if (isset($configOptions['retryInterval'])) {
            $this->retryInterval = $configOptions['retryInterval'];
        }
        if (isset($configOptions['backOffFactor'])) {
            $this->backOffFactor = $configOptions['backOffFactor'];
        }
        if (isset($configOptions['maximumRetryWaitTime'])) {
            $this->maximumRetryWaitTime = $configOptions['maximumRetryWaitTime'];
        }
        if (isset($configOptions['retryOnTimeout'])) {
            $this->retryOnTimeout = $configOptions['retryOnTimeout'];
        }
        if (isset($configOptions['httpStatusCodesToRetry'])) {
            $this->httpStatusCodesToRetry = $configOptions['httpStatusCodesToRetry'];
        }
        if (isset($configOptions['httpMethodsToRetry'])) {
            $this->httpMethodsToRetry = $configOptions['httpMethodsToRetry'];
        }
        if (isset($configOptions['environment'])) {
            $this->environment = $configOptions['environment'];
        }
        if (isset($configOptions['basicAuthUserName'])) {
            $this->basicAuthUserName = $configOptions['basicAuthUserName'];
        }
        if (isset($configOptions['basicAuthPassword'])) {
            $this->basicAuthPassword = $configOptions['basicAuthPassword'];
        }
        if (isset($configOptions['httpCallback'])) {
            $this->httpCallback = $configOptions['httpCallback'];
        }

        $this->basicAuthManager = new BasicAuthManager($this->basicAuthUserName, $this->basicAuthPassword);
        $this->authManagers['global'] = $this->basicAuthManager;
    }

    /**
     * Get the client configuration as an associative array
     */
    public function getConfiguration(): array
    {
        $configMap = [];

        if (isset($this->timeout)) {
            $configMap['timeout'] = $this->timeout;
        }
        if (isset($this->enableRetries)) {
            $configMap['enableRetries'] = $this->enableRetries;
        }
        if (isset($this->numberOfRetries)) {
            $configMap['numberOfRetries'] = $this->numberOfRetries;
        }
        if (isset($this->retryInterval)) {
            $configMap['retryInterval'] = $this->retryInterval;
        }
        if (isset($this->backOffFactor)) {
            $configMap['backOffFactor'] = $this->backOffFactor;
        }
        if (isset($this->maximumRetryWaitTime)) {
            $configMap['maximumRetryWaitTime'] = $this->maximumRetryWaitTime;
        }
        if (isset($this->retryOnTimeout)) {
            $configMap['retryOnTimeout'] = $this->retryOnTimeout;
        }
        if (isset($this->httpStatusCodesToRetry)) {
            $configMap['httpStatusCodesToRetry'] = $this->httpStatusCodesToRetry;
        }
        if (isset($this->httpMethodsToRetry)) {
            $configMap['httpMethodsToRetry'] = $this->httpMethodsToRetry;
        }
        if (isset($this->environment)) {
            $configMap['environment'] = $this->environment;
        }
        if ($this->basicAuthManager->getBasicAuthUserName() !== null) {
            $configMap['basicAuthUserName'] = $this->basicAuthManager->getBasicAuthUserName();
        }
        if ($this->basicAuthManager->getBasicAuthPassword() !== null) {
            $configMap['basicAuthPassword'] = $this->basicAuthManager->getBasicAuthPassword();
        }
        if (isset($this->httpCallback)) {
            $configMap['httpCallback'] = $this->httpCallback;
        }

        return $configMap;
    }

    /**
     * Clone this client and override given configuration options
     */
    public function withConfiguration(array $configOptions): self
    {
        return new self(\array_merge($this->getConfiguration(), $configOptions));
    }

    public function getTimeout(): int
    {
        return $this->timeout;
    }

    public function shouldEnableRetries(): bool
    {
        return $this->enableRetries;
    }

    public function getNumberOfRetries(): int
    {
        return $this->numberOfRetries;
    }

    public function getRetryInterval(): float
    {
        return $this->retryInterval;
    }

    public function getBackOffFactor(): float
    {
        return $this->backOffFactor;
    }

    public function getMaximumRetryWaitTime(): int
    {
        return $this->maximumRetryWaitTime;
    }

    public function shouldRetryOnTimeout(): bool
    {
        return $this->retryOnTimeout;
    }

    public function getHttpStatusCodesToRetry(): array
    {
        return $this->httpStatusCodesToRetry;
    }

    public function getHttpMethodsToRetry(): array
    {
        return $this->httpMethodsToRetry;
    }

    public function getEnvironment(): string
    {
        return $this->environment;
    }

    public function getBasicAuthCredentials(): ?BasicAuthCredentials
    {
        return $this->basicAuthManager;
    }

    /**
     * Get the base uri for a given server in the current environment
     *
     * @param  string $server Server name
     *
     * @return string         Base URI
     */
    public function getBaseUri(string $server = Server::DEFAULT_): string
    {
        return static::ENVIRONMENT_MAP[$this->environment][$server];
    }

    /**
     * Returns Data Matching Controller
     */
    public function getDataMatchingController(): Controllers\DataMatchingController
    {
        if ($this->dataMatching == null) {
            $this->dataMatching = new Controllers\DataMatchingController(
                $this,
                $this->authManagers,
                $this->httpCallback
            );
        }
        return $this->dataMatching;
    }

    /**
     * Returns User Feedback Controller
     */
    public function getUserFeedbackController(): Controllers\UserFeedbackController
    {
        if ($this->userFeedback == null) {
            $this->userFeedback = new Controllers\UserFeedbackController(
                $this,
                $this->authManagers,
                $this->httpCallback
            );
        }
        return $this->userFeedback;
    }

    /**
     * Returns Duplicate Matching Controller
     */
    public function getDuplicateMatchingController(): Controllers\DuplicateMatchingController
    {
        if ($this->duplicateMatching == null) {
            $this->duplicateMatching = new Controllers\DuplicateMatchingController(
                $this,
                $this->authManagers,
                $this->httpCallback
            );
        }
        return $this->duplicateMatching;
    }

    /**
     * Returns Linkage Matching Controller
     */
    public function getLinkageMatchingController(): Controllers\LinkageMatchingController
    {
        if ($this->linkageMatching == null) {
            $this->linkageMatching = new Controllers\LinkageMatchingController(
                $this,
                $this->authManagers,
                $this->httpCallback
            );
        }
        return $this->linkageMatching;
    }

    /**
     * Returns Analytics Controller
     */
    public function getAnalyticsController(): Controllers\AnalyticsController
    {
        if ($this->analytics == null) {
            $this->analytics = new Controllers\AnalyticsController(
                $this,
                $this->authManagers,
                $this->httpCallback
            );
        }
        return $this->analytics;
    }

    /**
     * A map of all baseurls used in different environments and servers
     *
     * @var array
     */
    private const ENVIRONMENT_MAP = [
        Environment::PRODUCTION => [
            Server::DEFAULT_ => 'https://api.corporate-data-league.ch/data-matching/rest',
        ],
    ];
}
