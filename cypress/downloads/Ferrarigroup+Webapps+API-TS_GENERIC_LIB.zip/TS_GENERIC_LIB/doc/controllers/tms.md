# Tms

```ts
const tmsController = new TmsController(client);
```

## Class Name

`TmsController`

## Methods

* [TMS Shipments Collection](../../doc/controllers/tms.md#tms-shipments-collection)
* [TMS Shipments](../../doc/controllers/tms.md#tms-shipments)
* [TMS Shipments 1](../../doc/controllers/tms.md#tms-shipments-1)
* [TMS Shipments 2](../../doc/controllers/tms.md#tms-shipments-2)
* [TMS Device Entity](../../doc/controllers/tms.md#tms-device-entity)
* [TMS Device](../../doc/controllers/tms.md#tms-device)
* [TMS Device Collection](../../doc/controllers/tms.md#tms-device-collection)
* [TMS Device 1](../../doc/controllers/tms.md#tms-device-1)
* [TMS Device 2](../../doc/controllers/tms.md#tms-device-2)
* [TMS Shipments Entity](../../doc/controllers/tms.md#tms-shipments-entity)
* [TMS Crew Entity](../../doc/controllers/tms.md#tms-crew-entity)
* [TMS Parcel Entity](../../doc/controllers/tms.md#tms-parcel-entity)
* [TMS Parcel](../../doc/controllers/tms.md#tms-parcel)
* [TMS Parcel Collection](../../doc/controllers/tms.md#tms-parcel-collection)
* [TMS Parcel 1](../../doc/controllers/tms.md#tms-parcel-1)
* [TMS Parcel 2](../../doc/controllers/tms.md#tms-parcel-2)
* [TMS Attachment Upload](../../doc/controllers/tms.md#tms-attachment-upload)
* [TMS Attachment Upload Public](../../doc/controllers/tms.md#tms-attachment-upload-public)
* [TMS Login Info](../../doc/controllers/tms.md#tms-login-info)
* [TMS Attachment Entity](../../doc/controllers/tms.md#tms-attachment-entity)
* [TMS Attachment Collection](../../doc/controllers/tms.md#tms-attachment-collection)
* [TMS Attachment](../../doc/controllers/tms.md#tms-attachment)
* [TMS Attachment 1](../../doc/controllers/tms.md#tms-attachment-1)
* [TMS Attachment 2](../../doc/controllers/tms.md#tms-attachment-2)
* [TMS Scan Parcel List](../../doc/controllers/tms.md#tms-scan-parcel-list)
* [TMS Scan In](../../doc/controllers/tms.md#tms-scan-in)
* [TMS Warehouse Collection](../../doc/controllers/tms.md#tms-warehouse-collection)
* [TMS Warehouse Entity](../../doc/controllers/tms.md#tms-warehouse-entity)
* [TMS Warehouse](../../doc/controllers/tms.md#tms-warehouse)
* [TMS Warehouse 1](../../doc/controllers/tms.md#tms-warehouse-1)
* [TMS Manifest Create](../../doc/controllers/tms.md#tms-manifest-create)
* [TMS Track Action](../../doc/controllers/tms.md#tms-track-action)
* [TMS Tracking Place](../../doc/controllers/tms.md#tms-tracking-place)
* [TMS Return Status](../../doc/controllers/tms.md#tms-return-status)
* [TMS Get Addresses](../../doc/controllers/tms.md#tms-get-addresses)
* [TMS Get Countires](../../doc/controllers/tms.md#tms-get-countires)
* [TMS Add Address](../../doc/controllers/tms.md#tms-add-address)
* [TMS Shipment Add](../../doc/controllers/tms.md#tms-shipment-add)
* [TMS Geolocation](../../doc/controllers/tms.md#tms-geolocation)


# TMS Shipments Collection

```ts
async tMSShipmentsCollection(
  environment?: string,
  orderNum?: string,
  serviceType?: string,
  crewId?: string,
  manifest?: string,
  manifestTms?: string,
  status?: string,
  timeLastUpdate?: string,
  timeSchedulePickup?: string,
  timeScheduleDelivery?: string,
  timeActualPickup?: string,
  timeActualDelivery?: string,
  bookingRef?: string,
  seal?: string,
  house?: string,
  mawb?: string,
  requestOptions?: RequestOptions
): Promise<ApiResponse<string>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `environment` | `string \| undefined` | Query, Optional | - |
| `orderNum` | `string \| undefined` | Query, Optional | - |
| `serviceType` | `string \| undefined` | Query, Optional | - |
| `crewId` | `string \| undefined` | Query, Optional | - |
| `manifest` | `string \| undefined` | Query, Optional | - |
| `manifestTms` | `string \| undefined` | Query, Optional | - |
| `status` | `string \| undefined` | Query, Optional | - |
| `timeLastUpdate` | `string \| undefined` | Query, Optional | - |
| `timeSchedulePickup` | `string \| undefined` | Query, Optional | - |
| `timeScheduleDelivery` | `string \| undefined` | Query, Optional | - |
| `timeActualPickup` | `string \| undefined` | Query, Optional | - |
| `timeActualDelivery` | `string \| undefined` | Query, Optional | - |
| `bookingRef` | `string \| undefined` | Query, Optional | - |
| `seal` | `string \| undefined` | Query, Optional | - |
| `house` | `string \| undefined` | Query, Optional | - |
| `mawb` | `string \| undefined` | Query, Optional | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

`string`

## Example Usage

```ts
try {
  const { result, ...httpResponse } = await tmsController.tMSShipmentsCollection();
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch(error) {
  if (error instanceof ApiError) {
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```

## Example Response

```
"{\n   \"_links\": {\n       \"self\": {\n           \"href\": \"/tms/shipment\"\n       },\n       \"first\": {\n           \"href\": \"/tms/shipment?page={page}\"\n       },\n       \"prev\": {\n           \"href\": \"/tms/shipment?page={page}\"\n       },\n       \"next\": {\n           \"href\": \"/tms/shipment?page={page}\"\n       },\n       \"last\": {\n           \"href\": \"/tms/shipment?page={page}\"\n       }\n   }\n   \"_embedded\": {\n       \"shipment\": [\n           {\n               \"_links\": {\n                   \"self\": {\n                       \"href\": \"/tms/shipment[/:shipment_id]\"\n                   }\n               }\n              \"order_num\": \"\",\n              \"type\": \"\",\n              \"service_type\": \"\",\n              \"priority\": \"\",\n              \"customer_name\": \"\",\n              \"customer_address\": \"\",\n              \"customer_zip\": \"\",\n              \"customer_city\": \"\",\n              \"customer_prov\": \"\",\n              \"customer_country\": \"\",\n              \"customer_phone\": \"\",\n              \"customer_contact\": \"\",\n              \"customer_passport_id\": \"\",\n              \"pickup_name\": \"\",\n              \"pickup_address\": \"\",\n              \"pickup_zip\": \"\",\n              \"pickup_district\": \"\",\n              \"pickup_city\": \"\",\n              \"pickup_prov\": \"\",\n              \"pickup_country\": \"\",\n              \"pickup_phone\": \"\",\n              \"pickup_contact\": \"\",\n              \"pickup_passport_id\": \"\",\n              \"delivery_name\": \"\",\n              \"delivery_address\": \"\",\n              \"delivery_zip\": \"\",\n              \"delivery_district\": \"\",\n              \"delivery_city\": \"\",\n              \"delivery_prov\": \"\",\n              \"delivery_country\": \"\",\n              \"delivery_phone\": \"\",\n              \"delivery_contact\": \"\",\n              \"delivery_passport_id\": \"\",\n              \"remarks\": \"\",\n              \"internal_remarks\": \"\",\n              \"control_remarks\": \"\",\n              \"exp_parcel_num\": \"\",\n              \"act_parcel_num\": \"\",\n              \"status\": \"\",\n              \"time_last_update\": \"\",\n              \"time_schedule_pickup\": \"\",\n              \"time_schedule_pickup_t\": \"\",\n              \"time_schedule_delivery\": \"\",\n              \"time_schedule_delivery_t\": \"\",\n              \"time_actual_pickup\": \"\",\n              \"time_actual_delivery\": \"\",\n              \"actual_contact_name\": \"\",\n              \"actual_id\": \"\",\n              \"customer_ref\": \"\",\n              \"house\": \"\",\n              \"mawb\": \"\",\n              \"manifest\": \"\",\n              \"crew_id\": \"\",\n              \"warehouse_id\": \"\",\n              \"reason\": \"\",\n              \"customer_request\": \"\",\n              \"signature\": \"\",\n              \"pickable\": \"\",\n              \"deliverable\": \"\",\n              \"is_synchro\": \"\",\n              \"synchro_date\": \"\",\n              \"delivery_reason\": \"\",\n              \"delivery_customer_request\": \"\",\n              \"delivery_remarks\": \"\",\n              \"delivery_signature\": \"\",\n              \"cash_on_delivery\": \"\",\n              \"incoterm\": \"\",\n              \"cites\": \"\",\n              \"atacarnet\": \"\",\n              \"kimberly\": \"\",\n              \"environment\": \"\",\n              \"update_weight\": \"\",\n              \"dest_airport\": \"\",\n              \"id_area_pickup\": \"\",\n              \"id_area_delivery\": \"\",\n              \"order_tags\": \"\",\n              \"booking_ref\": \"\",\n              \"pod_exported\": \"\",\n              \"pickup_exported\": \"\",\n              \"seal\": \"\",\n              \"cash_on_delivery_cur\": \"\",\n              \"wrh_hold\": \"\",\n              \"prerefno\": \"\",\n              \"consolidation_id\": \"\",\n              \"tracking_export\": \"\",\n              \"exported\": \"\",\n              \"pickup_guard_ref\": \"\",\n              \"delivery_guard_ref\": \"\",\n              \"pr_exported\": \"\",\n              \"fm3000_pod_exported\": \"\",\n              \"fm3000_pk_exported\": \"\",\n              \"airexp_parcel_update\": \"\",\n              \"as400_exp\": \"\",\n              \"contact\": \"\",\n              \"contact2\": \"\",\n              \"attn\": \"\",\n              \"attn2\": \"\",\n              \"manifest_tms\": \"\",\n              \"truckp\": \"\",\n              \"truckd\": \"\",\n              \"time_scan_in\": \"\",\n              \"deliveries\": \"\",\n              \"delivery_phone2\": \"\"\n           }\n       ]\n   }\n}"
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | `ApiError` |
| 403 | Forbidden | `ApiError` |
| 404 | Not Found | `ApiError` |
| 422 | Unprocessable entity | `ApiError` |


# TMS Shipments

```ts
async tMSShipments(
  pARAMS: TmsShipmentPost,
  requestOptions?: RequestOptions
): Promise<ApiResponse<string>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `pARAMS` | [`TmsShipmentPost`](../../doc/models/tms-shipment-post.md) | Body, Required | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

`string`

## Example Usage

```ts
const pARAMS: TmsShipmentPost = {
  orderNum: 'HKGAE087622, \n210324374',
  type: 'P',
  serviceType: 'IMPORT-AIRFREIGHT',
  priority: 10,
  customerName: 'customer_name6',
  customerAddress: 'customer_address2',
  customerZip: 'customer_zip6',
  customerCity: 'customer_city8',
  customerProv: 'customer_prov6',
  customerCountry: 'customer_country4',
  customerPhone: 'customer_phone8',
  customerContact: 'customer_contact2',
  customerPassportId: 'customer_passport_id6',
  pickupName: 'pickup_name6',
  pickupAddress: 'pickup_address0',
  pickupZip: 'pickup_zip6',
  pickupDistrict: 'pickup_district4',
  pickupCity: 'pickup_city0',
  pickupProv: 'pickup_prov4',
  pickupCountry: 'pickup_country0',
  pickupPhone: 'pickup_phone4',
  pickupContact: 'pickup_contact8',
  pickupPassportId: 'pickup_passport_id8',
  deliveryName: 'delivery_name8',
  deliveryAddress: 'delivery_address0',
  deliveryZip: 'delivery_zip6',
  deliveryDistrict: 'delivery_district4',
  deliveryCity: 'delivery_city2',
  deliveryProv: 'delivery_prov0',
  deliveryCountry: 'delivery_country6',
  deliveryPhone: 'delivery_phone4',
  deliveryContact: 'delivery_contact6',
  deliveryPassportId: 'delivery_passport_id4',
  remarks: 'remarks0',
  internalRemarks: 'internal_remarks6',
  controlRemarks: 'control_remarks6',
  expParcelNum: 'exp_parcel_num4',
  actParcelNum: 'act_parcel_num8',
  status: 'TBP',
  timeLastUpdate: '2020-03-26 17:35:20',
  timeSchedulePickup: '2022-02-18 00:00:00',
  timeSchedulePickupT: '11:00,\nASAP',
  timeScheduleDelivery: '2022-02-18 00:00:00',
  timeScheduleDeliveryT: '10:00,\nASAP',
  timeActualPickup: '2022-02-01 16:56:23',
  timeActualDelivery: '2022-02-01 16:56:23',
  actualContactName: 'actual_contact_name6',
  actualId: 'actual_id4',
  customerRef: 'customer_ref8',
  house: 'house8',
  mawb: 'mawb2',
  manifest: 'manifest2',
  crewId: 30,
  warehouseId: 'warehouse_id2',
  reason: 'reason0',
  customerRequest: 'customer_request2',
  signature: 'signature2',
  pickable: 'Y',
  deliverable: 'Y',
  isSynchro: 'is_synchro8',
  synchroDate: 'synchro_date0',
  deliveryReason: 'delivery_reason2',
  deliveryCustomerRequest: 'delivery_customer_request8',
  deliveryRemarks: 'delivery_remarks4',
  deliverySignature: 'delivery_signature6',
  cashOnDelivery: 152,
  incoterm: 'incoterm8',
  cites: 'cites8',
  atacarnet: 'atacarnet8',
  kimberly: 'kimberly2',
  environment: 1,
  updateWeight: 'update_weight2',
  destAirport: 'dest_airport2',
  idAreaPickup: 'id_area_pickup8',
  idAreaDelivery: 'id_area_delivery6',
  orderTags: 'order_tags4',
  bookingRef: 'booking_ref2',
  podExported: 'pod_exported6',
  pickupExported: 'pickup_exported8',
  seal: 'seal6',
  cashOnDeliveryCur: 'cash_on_delivery_cur0',
  wrhHold: 1,
  prerefno: 'prerefno8',
  consolidationId: 'consolidation_id2',
  trackingExport: 'tracking_export8',
  exported: 'exported0',
  pickupGuardRef: 'pickup_guard_ref2',
  deliveryGuardRef: 'delivery_guard_ref4',
  prExported: 'pr_exported6',
  fm3000PodExported: 'fm3000_pod_exported0',
  fm3000PkExported: 'fm3000_pk_exported2',
  airexpParcelUpdate: 'airexp_parcel_update2',
  as400Exp: 'as400_exp8',
  contact: 'contact8',
  contact2: 'contact24',
  attn: 'attn4',
  attn2: 'attn22',
  manifestTms: 'manifest_tms0',
  truckp: 'truckp6',
  truckd: 'truckd0',
  timeScanIn: 'time_scan_in6',
  deliveries: 'deliveries4',
  deliveryPhone2: 'delivery_phone28',
  declaredValue: 'declared_value0',
  insuredValue: 'insured_value6',
  hideshp: 'hideshp2',
  hidecne: 'hidecne0',
  hidesrv: 'hidesrv8',
  timeTruckOut: 'time_truck_out6',
  deviceTruckOut: 'device_truck_out2',
  returnStatus: 'return_status4',
  timestampReturnStatus: 'timestamp_return_status0',
  reasonReturnStatus: 'reason_return_status0',
  expReturnStatus: 'exp_return_status2',
  deliverySmsAlert: 'delivery_sms_alert8',
  deliveryEmailAlert: 'delivery_email_alert4',
  flowTag: 'flow_tag6',
  validationDatetime: 'validation_datetime2',
  smsDeliveryCodeSent: 'sms_delivery_code_sent8',
  deliveryBarcodeScan: 'delivery_barcode_scan4',
};

try {
  const { result, ...httpResponse } = await tmsController.tMSShipments(pARAMS);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch(error) {
  if (error instanceof ApiError) {
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```

## Example Response

```
"{\n   \"order_num\": \"\",\n   \"type\": \"\",\n   \"service_type\": \"\",\n   \"priority\": \"\",\n   \"customer_name\": \"\",\n   \"customer_address\": \"\",\n   \"customer_zip\": \"\",\n   \"customer_city\": \"\",\n   \"customer_prov\": \"\",\n   \"customer_country\": \"\",\n   \"customer_phone\": \"\",\n   \"customer_contact\": \"\",\n   \"customer_passport_id\": \"\",\n   \"pickup_name\": \"\",\n   \"pickup_address\": \"\",\n   \"pickup_zip\": \"\",\n   \"pickup_district\": \"\",\n   \"pickup_city\": \"\",\n   \"pickup_prov\": \"\",\n   \"pickup_country\": \"\",\n   \"pickup_phone\": \"\",\n   \"pickup_contact\": \"\",\n   \"pickup_passport_id\": \"\",\n   \"delivery_name\": \"\",\n   \"delivery_address\": \"\",\n   \"delivery_zip\": \"\",\n   \"delivery_district\": \"\",\n   \"delivery_city\": \"\",\n   \"delivery_prov\": \"\",\n   \"delivery_country\": \"\",\n   \"delivery_phone\": \"\",\n   \"delivery_contact\": \"\",\n   \"delivery_passport_id\": \"\",\n   \"remarks\": \"\",\n   \"internal_remarks\": \"\",\n   \"control_remarks\": \"\",\n   \"exp_parcel_num\": \"\",\n   \"act_parcel_num\": \"\",\n   \"status\": \"\",\n   \"time_last_update\": \"\",\n   \"time_schedule_pickup\": \"\",\n   \"time_schedule_pickup_t\": \"\",\n   \"time_schedule_delivery\": \"\",\n   \"time_schedule_delivery_t\": \"\",\n   \"time_actual_pickup\": \"\",\n   \"time_actual_delivery\": \"\",\n   \"actual_contact_name\": \"\",\n   \"actual_id\": \"\",\n   \"customer_ref\": \"\",\n   \"house\": \"\",\n   \"manifest\": \"\",\n   \"crew_id\": \"\",\n   \"warehouse_id\": \"\",\n   \"reason\": \"\",\n   \"customer_request\": \"\",\n   \"signature\": \"\",\n   \"pickable\": \"\",\n   \"deliverable\": \"\",\n   \"is_synchro\": \"\",\n   \"synchro_date\": \"\",\n   \"delivery_reason\": \"\",\n   \"delivery_customer_request\": \"\",\n   \"delivery_remarks\": \"\",\n   \"delivery_signature\": \"\",\n   \"cash_on_delivery\": \"\",\n   \"incoterm\": \"\",\n   \"cites\": \"\",\n   \"atacarnet\": \"\",\n   \"kimberly\": \"\",\n   \"environment\": \"\",\n   \"update_weight\": \"\",\n   \"dest_airport\": \"\",\n   \"id_area_pickup\": \"\",\n   \"id_area_delivery\": \"\",\n   \"order_tags\": \"\",\n   \"booking_ref\": \"\",\n   \"pod_exported\": \"\",\n   \"pickup_exported\": \"\",\n   \"seal\": \"\",\n   \"cash_on_delivery_cur\": \"\",\n   \"wrh_hold\": \"\",\n   \"prerefno\": \"\",\n   \"consolidation_id\": \"\",\n   \"tracking_export\": \"\",\n   \"exported\": \"\",\n   \"pickup_guard_ref\": \"\",\n   \"delivery_guard_ref\": \"\",\n   \"pr_exported\": \"\",\n   \"fm3000_pod_exported\": \"\",\n   \"fm3000_pk_exported\": \"\",\n   \"airexp_parcel_update\": \"\",\n   \"as400_exp\": \"\",\n   \"contact\": \"\",\n   \"contact2\": \"\",\n   \"attn\": \"\",\n   \"attn2\": \"\",\n   \"manifest_tms\": \"\",\n   \"truckp\": \"\",\n   \"truckd\": \"\",\n   \"time_scan_in\": \"\",\n   \"deliveries\": \"\",\n   \"delivery_phone2\": \"\",\n   \"declared_value\": \"\",\n   \"insured_value\": \"\",\n   \"hideshp\": \"\",\n   \"hidecne\": \"\",\n   \"hidesrv\": \"\",\n   \"time_truck_out\": \"\",\n   \"device_truck_out\": \"\",\n   \"return_status\": \"\",\n   \"timestamp_return_status\": \"\",\n   \"reason_return_status\": \"\",\n   \"exp_return_status\": \"\",\n   \"delivery_sms_alert\": \"\",\n   \"delivery_email_alert\": \"\",\n   \"flow_tag\": \"\",\n   \"validation_datetime\": \"\",\n   \"sms_delivery_code_sent\": \"\",\n   \"delivery_barcode_scan\": \"\",\n   \"delivery_barcode_scan\": \"\"\n}"
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | `ApiError` |
| 403 | Forbidden | `ApiError` |
| 404 | Not Found | `ApiError` |
| 422 | Unprocessable entity | `ApiError` |


# TMS Shipments 1

```ts
async tMSShipments1(
  params: TmsShipmentPost,
  id: string,
  requestOptions?: RequestOptions
): Promise<ApiResponse<string>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `params` | [`TmsShipmentPost`](../../doc/models/tms-shipment-post.md) | Body, Required | - |
| `id` | `string` | Template, Required | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

`string`

## Example Usage

```ts
const params: TmsShipmentPost = {
  orderNum: 'HKGAE087622, \n210324374',
  type: 'P',
  serviceType: 'IMPORT-AIRFREIGHT',
  priority: 10,
  customerName: 'customer_name6',
  customerAddress: 'customer_address2',
  customerZip: 'customer_zip6',
  customerCity: 'customer_city8',
  customerProv: 'customer_prov6',
  customerCountry: 'customer_country4',
  customerPhone: 'customer_phone8',
  customerContact: 'customer_contact2',
  customerPassportId: 'customer_passport_id6',
  pickupName: 'pickup_name6',
  pickupAddress: 'pickup_address0',
  pickupZip: 'pickup_zip6',
  pickupDistrict: 'pickup_district4',
  pickupCity: 'pickup_city0',
  pickupProv: 'pickup_prov4',
  pickupCountry: 'pickup_country0',
  pickupPhone: 'pickup_phone4',
  pickupContact: 'pickup_contact8',
  pickupPassportId: 'pickup_passport_id8',
  deliveryName: 'delivery_name8',
  deliveryAddress: 'delivery_address0',
  deliveryZip: 'delivery_zip6',
  deliveryDistrict: 'delivery_district4',
  deliveryCity: 'delivery_city2',
  deliveryProv: 'delivery_prov0',
  deliveryCountry: 'delivery_country6',
  deliveryPhone: 'delivery_phone6',
  deliveryContact: 'delivery_contact6',
  deliveryPassportId: 'delivery_passport_id4',
  remarks: 'remarks0',
  internalRemarks: 'internal_remarks6',
  controlRemarks: 'control_remarks6',
  expParcelNum: 'exp_parcel_num4',
  actParcelNum: 'act_parcel_num2',
  status: 'TBP',
  timeLastUpdate: '2020-03-26 17:35:20',
  timeSchedulePickup: '2022-02-18 00:00:00',
  timeSchedulePickupT: '11:00,\nASAP',
  timeScheduleDelivery: '2022-02-18 00:00:00',
  timeScheduleDeliveryT: '10:00,\nASAP',
  timeActualPickup: '2022-02-01 16:56:23',
  timeActualDelivery: '2022-02-01 16:56:23',
  actualContactName: 'actual_contact_name6',
  actualId: 'actual_id4',
  customerRef: 'customer_ref8',
  house: 'house8',
  mawb: 'mawb2',
  manifest: 'manifest2',
  crewId: 0,
  warehouseId: 'warehouse_id2',
  reason: 'reason0',
  customerRequest: 'customer_request8',
  signature: 'signature2',
  pickable: 'Y',
  deliverable: 'Y',
  isSynchro: 'is_synchro8',
  synchroDate: 'synchro_date0',
  deliveryReason: 'delivery_reason2',
  deliveryCustomerRequest: 'delivery_customer_request8',
  deliveryRemarks: 'delivery_remarks4',
  deliverySignature: 'delivery_signature6',
  cashOnDelivery: 122,
  incoterm: 'incoterm8',
  cites: 'cites8',
  atacarnet: 'atacarnet8',
  kimberly: 'kimberly8',
  environment: 1,
  updateWeight: 'update_weight2',
  destAirport: 'dest_airport8',
  idAreaPickup: 'id_area_pickup8',
  idAreaDelivery: 'id_area_delivery6',
  orderTags: 'order_tags4',
  bookingRef: 'booking_ref2',
  podExported: 'pod_exported6',
  pickupExported: 'pickup_exported8',
  seal: 'seal6',
  cashOnDeliveryCur: 'cash_on_delivery_cur0',
  wrhHold: 1,
  prerefno: 'prerefno2',
  consolidationId: 'consolidation_id2',
  trackingExport: 'tracking_export8',
  exported: 'exported0',
  pickupGuardRef: 'pickup_guard_ref2',
  deliveryGuardRef: 'delivery_guard_ref6',
  prExported: 'pr_exported6',
  fm3000PodExported: 'fm3000_pod_exported0',
  fm3000PkExported: 'fm3000_pk_exported2',
  airexpParcelUpdate: 'airexp_parcel_update8',
  as400Exp: 'as400_exp8',
  contact: 'contact8',
  contact2: 'contact24',
  attn: 'attn4',
  attn2: 'attn22',
  manifestTms: 'manifest_tms0',
  truckp: 'truckp6',
  truckd: 'truckd0',
  timeScanIn: 'time_scan_in6',
  deliveries: 'deliveries6',
  deliveryPhone2: 'delivery_phone28',
  declaredValue: 'declared_value0',
  insuredValue: 'insured_value6',
  hideshp: 'hideshp8',
  hidecne: 'hidecne0',
  hidesrv: 'hidesrv2',
  timeTruckOut: 'time_truck_out6',
  deviceTruckOut: 'device_truck_out2',
  returnStatus: 'return_status4',
  timestampReturnStatus: 'timestamp_return_status0',
  reasonReturnStatus: 'reason_return_status0',
  expReturnStatus: 'exp_return_status2',
  deliverySmsAlert: 'delivery_sms_alert8',
  deliveryEmailAlert: 'delivery_email_alert6',
  flowTag: 'flow_tag6',
  validationDatetime: 'validation_datetime2',
  smsDeliveryCodeSent: 'sms_delivery_code_sent8',
  deliveryBarcodeScan: 'delivery_barcode_scan4',
};

const id = 'id0';
try {
  const { result, ...httpResponse } = await tmsController.tMSShipments1(params, id);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch(error) {
  if (error instanceof ApiError) {
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | `ApiError` |
| 403 | Forbidden | `ApiError` |
| 404 | Not Found | `ApiError` |
| 422 | Unprocessable entity | `ApiError` |


# TMS Shipments 2

```ts
async tMSShipments2(
  id: string,
  requestOptions?: RequestOptions
): Promise<ApiResponse<string>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `string` | Template, Required | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

`string`

## Example Usage

```ts
const id = 'id0';
try {
  const { result, ...httpResponse } = await tmsController.tMSShipments2(id);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch(error) {
  if (error instanceof ApiError) {
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | `ApiError` |
| 403 | Forbidden | `ApiError` |
| 404 | Not Found | `ApiError` |
| 422 | Unprocessable entity | `ApiError` |


# TMS Device Entity

```ts
async tMSDeviceEntity(
  id: string,
  requestOptions?: RequestOptions
): Promise<ApiResponse<string>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `string` | Template, Required | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

`string`

## Example Usage

```ts
const id = '1';
try {
  const { result, ...httpResponse } = await tmsController.tMSDeviceEntity(id);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch(error) {
  if (error instanceof ApiError) {
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```

## Example Response

```
"{\n   \"_links\": {\n       \"self\": {\n           \"href\": \"/tms/device[/:device_id]\"\n       }\n   }\n   \"environment\": \"\",\n   \"phonenumber\": \"\",\n   \"number\": \"\",\n   \"serial_nr\": \"\",\n   \"latitude\": \"\",\n   \"longitude\": \"\",\n   \"time_geolocation\": \"\",\n   \"active\": \"\",\n   \"needsync\": \"\",\n   \"push_token\": \"\",\n   \"database_token\": \"\"\n}"
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | `ApiError` |
| 403 | Forbidden | `ApiError` |
| 404 | Not Found | `ApiError` |
| 422 | Unprocessable entity | `ApiError` |


# TMS Device

```ts
async tMSDevice(
  requestOptions?: RequestOptions
): Promise<ApiResponse<string>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

`string`

## Example Usage

```ts
try {
  const { result, ...httpResponse } = await tmsController.tMSDevice();
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch(error) {
  if (error instanceof ApiError) {
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```

## Example Response

```
"{\n   \"_links\": {\n       \"self\": {\n           \"href\": \"/tms/device[/:device_id]\"\n       }\n   }\n   \"environment\": \"\",\n   \"phonenumber\": \"\",\n   \"number\": \"\",\n   \"serial_nr\": \"\",\n   \"latitude\": \"\",\n   \"longitude\": \"\",\n   \"time_geolocation\": \"\",\n   \"active\": \"\",\n   \"needsync\": \"\",\n   \"push_token\": \"\",\n   \"database_token\": \"\"\n}"
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | `ApiError` |
| 403 | Forbidden | `ApiError` |
| 404 | Not Found | `ApiError` |
| 422 | Unprocessable entity | `ApiError` |


# TMS Device Collection

```ts
async tMSDeviceCollection(
  environment?: string,
  number?: string,
  active?: string,
  needsync?: string,
  requestOptions?: RequestOptions
): Promise<ApiResponse<string>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `environment` | `string \| undefined` | Query, Optional | - |
| `number` | `string \| undefined` | Query, Optional | - |
| `active` | `string \| undefined` | Query, Optional | - |
| `needsync` | `string \| undefined` | Query, Optional | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

`string`

## Example Usage

```ts
const environment = '1';
const number = 'A0021';
const active = '1';
const needsync = '1';
try {
  const { result, ...httpResponse } = await tmsController.tMSDeviceCollection(environment, number, active, needsync);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch(error) {
  if (error instanceof ApiError) {
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```

## Example Response

```
"{\n   \"_links\": {\n       \"self\": {\n           \"href\": \"/tms/device\"\n       },\n       \"first\": {\n           \"href\": \"/tms/device?page={page}\"\n       },\n       \"prev\": {\n           \"href\": \"/tms/device?page={page}\"\n       },\n       \"next\": {\n           \"href\": \"/tms/device?page={page}\"\n       },\n       \"last\": {\n           \"href\": \"/tms/device?page={page}\"\n       }\n   }\n   \"_embedded\": {\n       \"device\": [\n           {\n               \"_links\": {\n                   \"self\": {\n                       \"href\": \"/tms/device[/:device_id]\"\n                   }\n               }\n              \"environment\": \"\",\n              \"phonenumber\": \"\",\n              \"number\": \"\",\n              \"serial_nr\": \"\",\n              \"latitude\": \"\",\n              \"longitude\": \"\",\n              \"time_geolocation\": \"\",\n              \"active\": \"\",\n              \"needsync\": \"\",\n              \"push_token\": \"\",\n              \"database_token\": \"\"\n           }\n       ]\n   }\n}"
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | `ApiError` |
| 403 | Forbidden | `ApiError` |
| 404 | Not Found | `ApiError` |
| 422 | Unprocessable entity | `ApiError` |


# TMS Device 1

```ts
async tMSDevice1(
  params: TMSDevice,
  id: string,
  requestOptions?: RequestOptions
): Promise<ApiResponse<string>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `params` | [`TMSDevice`](../../doc/models/tms-device.md) | Body, Required | - |
| `id` | `string` | Template, Required | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

`string`

## Example Usage

```ts
const params: TMSDevice = {
  environment: '1',
  phonenumber: 'phonenumber2',
  number: 'number8',
  needsync: '1',
  pushToken: 'push_token0',
  databaseToken: 'database_token4',
};

const id = '1';
try {
  const { result, ...httpResponse } = await tmsController.tMSDevice1(params, id);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch(error) {
  if (error instanceof ApiError) {
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```

## Example Response

```
"{\n   \"_links\": {\n       \"self\": {\n           \"href\": \"/tms/device[/:device_id]\"\n       }\n   }\n   \"environment\": \"\",\n   \"phonenumber\": \"\",\n   \"number\": \"\",\n   \"serial_nr\": \"\",\n   \"latitude\": \"\",\n   \"longitude\": \"\",\n   \"time_geolocation\": \"\",\n   \"active\": \"\",\n   \"needsync\": \"\",\n   \"push_token\": \"\",\n   \"database_token\": \"\"\n}"
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | `ApiError` |
| 403 | Forbidden | `ApiError` |
| 404 | Not Found | `ApiError` |
| 422 | Unprocessable entity | `ApiError` |


# TMS Device 2

```ts
async tMSDevice2(
  id: string,
  requestOptions?: RequestOptions
): Promise<ApiResponse<string>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `string` | Template, Required | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

`string`

## Example Usage

```ts
const id = '1';
try {
  const { result, ...httpResponse } = await tmsController.tMSDevice2(id);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch(error) {
  if (error instanceof ApiError) {
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | `ApiError` |
| 403 | Forbidden | `ApiError` |
| 404 | Not Found | `ApiError` |
| 422 | Unprocessable entity | `ApiError` |


# TMS Shipments Entity

```ts
async tMSShipmentsEntity(
  id: string,
  requestOptions?: RequestOptions
): Promise<ApiResponse<string>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `string` | Template, Required | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

`string`

## Example Usage

```ts
const id = '1';
try {
  const { result, ...httpResponse } = await tmsController.tMSShipmentsEntity(id);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch(error) {
  if (error instanceof ApiError) {
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```

## Example Response

```
"{\n   \"_links\": {\n       \"self\": {\n           \"href\": \"/tms/shipment\"\n       },\n       \"first\": {\n           \"href\": \"/tms/shipment?page={page}\"\n       },\n       \"prev\": {\n           \"href\": \"/tms/shipment?page={page}\"\n       },\n       \"next\": {\n           \"href\": \"/tms/shipment?page={page}\"\n       },\n       \"last\": {\n           \"href\": \"/tms/shipment?page={page}\"\n       }\n   }\n   \"_embedded\": {\n       \"shipment\": [\n           {\n               \"_links\": {\n                   \"self\": {\n                       \"href\": \"/tms/shipment[/:shipment_id]\"\n                   }\n               }\n              \"order_num\": \"\",\n              \"type\": \"\",\n              \"service_type\": \"\",\n              \"priority\": \"\",\n              \"customer_name\": \"\",\n              \"customer_address\": \"\",\n              \"customer_zip\": \"\",\n              \"customer_city\": \"\",\n              \"customer_prov\": \"\",\n              \"customer_country\": \"\",\n              \"customer_phone\": \"\",\n              \"customer_contact\": \"\",\n              \"customer_passport_id\": \"\",\n              \"pickup_name\": \"\",\n              \"pickup_address\": \"\",\n              \"pickup_zip\": \"\",\n              \"pickup_district\": \"\",\n              \"pickup_city\": \"\",\n              \"pickup_prov\": \"\",\n              \"pickup_country\": \"\",\n              \"pickup_phone\": \"\",\n              \"pickup_contact\": \"\",\n              \"pickup_passport_id\": \"\",\n              \"delivery_name\": \"\",\n              \"delivery_address\": \"\",\n              \"delivery_zip\": \"\",\n              \"delivery_district\": \"\",\n              \"delivery_city\": \"\",\n              \"delivery_prov\": \"\",\n              \"delivery_country\": \"\",\n              \"delivery_phone\": \"\",\n              \"delivery_contact\": \"\",\n              \"delivery_passport_id\": \"\",\n              \"remarks\": \"\",\n              \"internal_remarks\": \"\",\n              \"control_remarks\": \"\",\n              \"exp_parcel_num\": \"\",\n              \"act_parcel_num\": \"\",\n              \"status\": \"\",\n              \"time_last_update\": \"\",\n              \"time_schedule_pickup\": \"\",\n              \"time_schedule_pickup_t\": \"\",\n              \"time_schedule_delivery\": \"\",\n              \"time_schedule_delivery_t\": \"\",\n              \"time_actual_pickup\": \"\",\n              \"time_actual_delivery\": \"\",\n              \"actual_contact_name\": \"\",\n              \"actual_id\": \"\",\n              \"customer_ref\": \"\",\n              \"house\": \"\",\n              \"mawb\": \"\",\n              \"manifest\": \"\",\n              \"crew_id\": \"\",\n              \"warehouse_id\": \"\",\n              \"reason\": \"\",\n              \"customer_request\": \"\",\n              \"signature\": \"\",\n              \"pickable\": \"\",\n              \"deliverable\": \"\",\n              \"is_synchro\": \"\",\n              \"synchro_date\": \"\",\n              \"delivery_reason\": \"\",\n              \"delivery_customer_request\": \"\",\n              \"delivery_remarks\": \"\",\n              \"delivery_signature\": \"\",\n              \"cash_on_delivery\": \"\",\n              \"incoterm\": \"\",\n              \"cites\": \"\",\n              \"atacarnet\": \"\",\n              \"kimberly\": \"\",\n              \"environment\": \"\",\n              \"update_weight\": \"\",\n              \"dest_airport\": \"\",\n              \"id_area_pickup\": \"\",\n              \"id_area_delivery\": \"\",\n              \"order_tags\": \"\",\n              \"booking_ref\": \"\",\n              \"pod_exported\": \"\",\n              \"pickup_exported\": \"\",\n              \"seal\": \"\",\n              \"cash_on_delivery_cur\": \"\",\n              \"wrh_hold\": \"\",\n              \"prerefno\": \"\",\n              \"consolidation_id\": \"\",\n              \"tracking_export\": \"\",\n              \"exported\": \"\",\n              \"pickup_guard_ref\": \"\",\n              \"delivery_guard_ref\": \"\",\n              \"pr_exported\": \"\",\n              \"fm3000_pod_exported\": \"\",\n              \"fm3000_pk_exported\": \"\",\n              \"airexp_parcel_update\": \"\",\n              \"as400_exp\": \"\",\n              \"contact\": \"\",\n              \"contact2\": \"\",\n              \"attn\": \"\",\n              \"attn2\": \"\",\n              \"manifest_tms\": \"\",\n              \"truckp\": \"\",\n              \"truckd\": \"\",\n              \"time_scan_in\": \"\",\n              \"deliveries\": \"\",\n              \"delivery_phone2\": \"\"\n           }\n       ]\n   }\n}"
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | `ApiError` |
| 403 | Forbidden | `ApiError` |
| 404 | Not Found | `ApiError` |
| 422 | Unprocessable entity | `ApiError` |


# TMS Crew Entity

```ts
async tMSCrewEntity(
  id: string,
  requestOptions?: RequestOptions
): Promise<ApiResponse<string>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `string` | Template, Required | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

`string`

## Example Usage

```ts
const id = '1';
try {
  const { result, ...httpResponse } = await tmsController.tMSCrewEntity(id);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch(error) {
  if (error instanceof ApiError) {
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```

## Example Response

```
"{\n   \"_links\": {\n       \"self\": {\n           \"href\": \"/tms/crew[/:crew_id]\"\n       }\n   }\n   \"environment\": \"\",\n   \"valid_day\": \"\",\n   \"notes\": \"\",\n   \"truck_id\": \"\",\n   \"device_id\": \"\",\n   \"device2_id\": \"\"\n}"
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | `ApiError` |
| 403 | Forbidden | `ApiError` |
| 404 | Not Found | `ApiError` |
| 422 | Unprocessable entity | `ApiError` |


# TMS Parcel Entity

```ts
async tMSParcelEntity(
  id: string,
  requestOptions?: RequestOptions
): Promise<ApiResponse<string>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `string` | Template, Required | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

`string`

## Example Usage

```ts
const id = '1';
try {
  const { result, ...httpResponse } = await tmsController.tMSParcelEntity(id);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch(error) {
  if (error instanceof ApiError) {
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```

## Example Response

```
"{\n   \"_links\": {\n       \"self\": {\n           \"href\": \"/tms/parcel[/:parcel_id]\"\n       }\n   }\n   \"parcel_num\": \"\",\n   \"order_num\": \"\",\n   \"box_num\": \"\",\n   \"gross_weight\": \"\",\n   \"mark\": \"\",\n   \"item_num\": \"\",\n   \"seal\": \"\",\n   \"dim1\": \"\",\n   \"dim2\": \"\",\n   \"dim3\": \"\",\n   \"label\": \"\",\n   \"seal2\": \"\",\n   \"seal3\": \"\",\n   \"dlv_scan\": \"\",\n   \"pk_scan\": \"\",\n   \"environment\": \"\",\n   \"mark_orig\": \"\"\n}"
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | `ApiError` |
| 403 | Forbidden | `ApiError` |
| 404 | Not Found | `ApiError` |
| 422 | Unprocessable entity | `ApiError` |


# TMS Parcel

```ts
async tMSParcel(
  id: string,
  requestOptions?: RequestOptions
): Promise<ApiResponse<string>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `string` | Template, Required | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

`string`

## Example Usage

```ts
const id = '1';
try {
  const { result, ...httpResponse } = await tmsController.tMSParcel(id);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch(error) {
  if (error instanceof ApiError) {
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | `ApiError` |
| 403 | Forbidden | `ApiError` |
| 404 | Not Found | `ApiError` |
| 422 | Unprocessable entity | `ApiError` |


# TMS Parcel Collection

```ts
async tMSParcelCollection(
  environment?: string,
  orderNum?: string,
  mark?: string,
  seal3?: string,
  seal2?: string,
  seal?: string,
  markOrig?: string,
  requestOptions?: RequestOptions
): Promise<ApiResponse<string>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `environment` | `string \| undefined` | Query, Optional | - |
| `orderNum` | `string \| undefined` | Query, Optional | - |
| `mark` | `string \| undefined` | Query, Optional | - |
| `seal3` | `string \| undefined` | Query, Optional | - |
| `seal2` | `string \| undefined` | Query, Optional | - |
| `seal` | `string \| undefined` | Query, Optional | - |
| `markOrig` | `string \| undefined` | Query, Optional | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

`string`

## Example Usage

```ts
const environment = '1';
try {
  const { result, ...httpResponse } = await tmsController.tMSParcelCollection(environment);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch(error) {
  if (error instanceof ApiError) {
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```

## Example Response

```
"{\n   \"_links\": {\n       \"self\": {\n           \"href\": \"/tms/parcel\"\n       },\n       \"first\": {\n           \"href\": \"/tms/parcel?page={page}\"\n       },\n       \"prev\": {\n           \"href\": \"/tms/parcel?page={page}\"\n       },\n       \"next\": {\n           \"href\": \"/tms/parcel?page={page}\"\n       },\n       \"last\": {\n           \"href\": \"/tms/parcel?page={page}\"\n       }\n   }\n   \"_embedded\": {\n       \"parcel\": [\n           {\n               \"_links\": {\n                   \"self\": {\n                       \"href\": \"/tms/parcel[/:parcel_id]\"\n                   }\n               }\n              \"parcel_num\": \"\",\n              \"order_num\": \"\",\n              \"box_num\": \"\",\n              \"gross_weight\": \"\",\n              \"mark\": \"\",\n              \"item_num\": \"\",\n              \"seal\": \"\",\n              \"dim1\": \"\",\n              \"dim2\": \"\",\n              \"dim3\": \"\",\n              \"label\": \"\",\n              \"seal2\": \"\",\n              \"seal3\": \"\",\n              \"dlv_scan\": \"\",\n              \"pk_scan\": \"\",\n              \"environment\": \"\",\n              \"mark_orig\": \"\"\n           }\n       ]\n   }\n}"
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | `ApiError` |
| 403 | Forbidden | `ApiError` |
| 404 | Not Found | `ApiError` |
| 422 | Unprocessable entity | `ApiError` |


# TMS Parcel 1

```ts
async tMSParcel1(
  id: string,
  params: TMSParcel,
  requestOptions?: RequestOptions
): Promise<ApiResponse<string>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `string` | Template, Required | - |
| `params` | [`TMSParcel`](../../doc/models/tms-parcel.md) | Body, Required | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

`string`

## Example Usage

```ts
const id = 'id0';
const params: TMSParcel = {
  parcelNum: 'parcel_num8',
  orderNum: 'order_num6',
  boxNum: 'box_num6',
  grossWeight: 'gross_weight0',
  mark: 'mark0',
  itemNum: 'item_num8',
  seal: 'seal6',
  dim1: 'dim12',
  dim2: 'dim24',
  dim3: 'dim38',
  label: 'label4',
  seal2: 'seal26',
  seal3: 'seal30',
  dlvScan: 'dlv_scan8',
  pkScan: 'pk_scan8',
  environment: 'environment0',
  markOrig: 'mark_orig0',
};

try {
  const { result, ...httpResponse } = await tmsController.tMSParcel1(id, params);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch(error) {
  if (error instanceof ApiError) {
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```

## Example Response

```
"{\n   \"_links\": {\n       \"self\": {\n           \"href\": \"/tms/parcel\"\n       },\n       \"first\": {\n           \"href\": \"/tms/parcel?page={page}\"\n       },\n       \"prev\": {\n           \"href\": \"/tms/parcel?page={page}\"\n       },\n       \"next\": {\n           \"href\": \"/tms/parcel?page={page}\"\n       },\n       \"last\": {\n           \"href\": \"/tms/parcel?page={page}\"\n       }\n   }\n   \"_embedded\": {\n       \"parcel\": [\n           {\n               \"_links\": {\n                   \"self\": {\n                       \"href\": \"/tms/parcel[/:parcel_id]\"\n                   }\n               }\n              \"parcel_num\": \"\",\n              \"order_num\": \"\",\n              \"box_num\": \"\",\n              \"gross_weight\": \"\",\n              \"mark\": \"\",\n              \"item_num\": \"\",\n              \"seal\": \"\",\n              \"dim1\": \"\",\n              \"dim2\": \"\",\n              \"dim3\": \"\",\n              \"label\": \"\",\n              \"seal2\": \"\",\n              \"seal3\": \"\",\n              \"dlv_scan\": \"\",\n              \"pk_scan\": \"\",\n              \"environment\": \"\",\n              \"mark_orig\": \"\"\n           }\n       ]\n   }\n}"
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | `ApiError` |
| 403 | Forbidden | `ApiError` |
| 404 | Not Found | `ApiError` |
| 422 | Unprocessable entity | `ApiError` |


# TMS Parcel 2

```ts
async tMSParcel2(
  requestOptions?: RequestOptions
): Promise<ApiResponse<string>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

`string`

## Example Usage

```ts
try {
  const { result, ...httpResponse } = await tmsController.tMSParcel2();
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch(error) {
  if (error instanceof ApiError) {
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```

## Example Response

```
"{\n   \"_links\": {\n       \"self\": {\n           \"href\": \"/tms/parcel[/:parcel_id]\"\n       }\n   }\n   \"parcel_num\": \"\",\n   \"order_num\": \"\",\n   \"box_num\": \"\",\n   \"gross_weight\": \"\",\n   \"mark\": \"\",\n   \"item_num\": \"\",\n   \"seal\": \"\",\n   \"dim1\": \"\",\n   \"dim2\": \"\",\n   \"dim3\": \"\",\n   \"label\": \"\",\n   \"seal2\": \"\",\n   \"seal3\": \"\",\n   \"dlv_scan\": \"\",\n   \"pk_scan\": \"\",\n   \"environment\": \"\",\n   \"mark_orig\": \"\"\n}"
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | `ApiError` |
| 403 | Forbidden | `ApiError` |
| 404 | Not Found | `ApiError` |
| 422 | Unprocessable entity | `ApiError` |


# TMS Attachment Upload

```ts
async tMSAttachmentUpload(
  filename: string,
  base64: string,
  requestOptions?: RequestOptions
): Promise<ApiResponse<string>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `filename` | `string` | Query, Required | - |
| `base64` | `string` | Query, Required | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

`string`

## Example Usage

```ts
const filename = 'filename2';
const base64 = 'base642';
try {
  const { result, ...httpResponse } = await tmsController.tMSAttachmentUpload(filename, base64);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch(error) {
  if (error instanceof ApiError) {
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```

## Example Response

```
"{\n    \"token\": \"a94a8fe5ccb19ba61c4c0873d391e987982fbbd3623442e48f6ad\"\n}"
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | `ApiError` |
| 403 | Forbidden | `ApiError` |
| 404 | Not Found | `ApiError` |
| 422 | Unprocessable entity | `ApiError` |


# TMS Attachment Upload Public

```ts
async tMSAttachmentUploadPublic(
  filename: string,
  tokenFile: string,
  requestOptions?: RequestOptions
): Promise<ApiResponse<string>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `filename` | `string` | Query, Required | - |
| `tokenFile` | `string` | Query, Required | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

`string`

## Example Usage

```ts
const filename = 'filename2';
const tokenFile = 'token_file2';
try {
  const { result, ...httpResponse } = await tmsController.tMSAttachmentUploadPublic(filename, tokenFile);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch(error) {
  if (error instanceof ApiError) {
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```

## Example Response

```
"{\n    \"attachment_id\": 20199,\n    \"nome_file\": \"test.jpg\"\n}"
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | `ApiError` |
| 403 | Forbidden | `ApiError` |
| 404 | Not Found | `ApiError` |
| 422 | Unprocessable entity | `ApiError` |


# TMS Login Info

```ts
async tMSLoginInfo(
  device: string,
  requestOptions?: RequestOptions
): Promise<ApiResponse<string>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `device` | `string` | Query, Required | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

`string`

## Example Usage

```ts
const device = 'device6';
try {
  const { result, ...httpResponse } = await tmsController.tMSLoginInfo(device);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch(error) {
  if (error instanceof ApiError) {
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```

## Example Response

```
"{\n    \"staff_id\": \"marco-tms.test\",\n    \"environment\": \"1\",\n    \"guard_id\": \"TMS-id-82\",\n    \"device_id\": 1,\n    \"database_token\": \"Ferrari2019!1\",\n    \"settings\": [\n        {\n            \"addesses\": \"1\"\n        },\n        {\n            \"branch_visible\": \"0\"\n        },\n        {\n            \"bulk_seal_pickup\": \"0\"\n        },\n        {\n            \"buono_presa\": \"0\"\n        },\n        {\n            \"confirm_all_pickup\": \"1\"\n        },\n        {\n            \"confirm_manifest\": \"0\"\n        },\n        {\n            \"copyright_signature\": \"1\"\n        },\n        {\n            \"crew_managment\": \"0\"\n        },\n        {\n            \"delivery_contact\": \"1\"\n        },\n        {\n            \"delivery_copyright\": \"By signing this document, I hereby confirm the parcels are received in good condition and without any visible sign of tampering.\"\n        },\n        {\n            \"hawb_in_list\": \"0\"\n        },\n        {\n            \"head_print\": \"Ferrari Logistics (ASIA) Ltd\"\n        },\n        {\n            \"home\": \"view/home.html\"\n        },\n        {\n            \"home_ferrari\": \"0\"\n        },\n        {\n            \"keypress\": \"0\"\n        },\n        {\n            \"language\": \"en\"\n        },\n        {\n            \"mandatory_passport_id\": \"1\"\n        },\n        {\n            \"mandatory_signature\": \"1\"\n        },\n        {\n            \"manifest_marks\": \"1\"\n        },\n        {\n            \"manifest_operation\": \"1\"\n        },\n        {\n            \"manifest_select_ship\": \"1\"\n        },\n        {\n            \"manifest_simple\": \"0\"\n        },\n        {\n            \"mark_pickup_list\": \"0\"\n        },\n        {\n            \"mawb_hawb_print_label\": \"1\"\n        },\n        {\n            \"order_list\": \"1\"\n        },\n        {\n            \"pickup_copyright\": \"By signing this document, I hereby confirm the information indicated in this document is accurate. I also accept and acknowledge the General Conditions of Ferrari Group/Agents for International Carriage as published on the web site  www.ferrarigroup.net\"\n        },\n        {\n            \"pickup_manifest_seal_insert\": \"0\"\n        },\n        {\n            \"pickup_parcels_data\": \"0\"\n        },\n        {\n            \"poste_visible\": \"0\"\n        },\n        {\n            \"prefix_order\": \"0\"\n        },\n        {\n            \"print_bookink_ref_pickup\": \"0\"\n        },\n        {\n            \"print_confirm_order\": \"1\"\n        },\n        {\n            \"print_label\": \"1\"\n        },\n        {\n            \"rolex_functionality\": \"0\"\n        },\n        {\n            \"row1\": \"Hong Kong\"\n        },\n        {\n            \"scan_in_auto\": \"0\"\n        },\n        {\n            \"scan_in_new\": \"1\"\n        },\n        {\n            \"shared_signature\": \"1\"\n        },\n        {\n            \"signature\": \"1\"\n        },\n        {\n            \"signature_pickup\": \"1\"\n        },\n        {\n            \"simsun\": \"1\"\n        },\n        {\n            \"syncro_kcc_address\": \"1\"\n        },\n        {\n            \"syncro_tms\": \"1\"\n        },\n        {\n            \"syncro_tracking_place\": \"0\"\n        },\n        {\n            \"tms\": \"Hong kong\"\n        },\n        {\n            \"tracking_events\": \"0\"\n        },\n        {\n            \"tracking_events_daily_delete\": \"0\"\n        },\n        {\n            \"tracking_events_prov\": \"0\"\n        },\n        {\n            \"tracking_places\": \"0\"\n        },\n        {\n            \"truck_utilities\": \"1\"\n        },\n        {\n            \"wso_addresses\": \"TMS\"\n        }\n    ]\n}"
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | `ApiError` |
| 403 | Forbidden | `ApiError` |
| 404 | Not Found | `ApiError` |
| 422 | Unprocessable entity | `ApiError` |


# TMS Attachment Entity

```ts
async tMSAttachmentEntity(
  id: string,
  requestOptions?: RequestOptions
): Promise<ApiResponse<string>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `string` | Template, Required | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

`string`

## Example Usage

```ts
const id = 'id0';
try {
  const { result, ...httpResponse } = await tmsController.tMSAttachmentEntity(id);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch(error) {
  if (error instanceof ApiError) {
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```

## Example Response

```
"{\n   \"_links\": {\n       \"self\": {\n           \"href\": \"/tms/attachment[/:attachment_id]\"\n       }\n   }\n   \"order_num\": \"\",\n   \"type\": \"\",\n   \"file_id\": \"\",\n   \"timestamp\": \"\",\n   \"environment\": \"\"\n}"
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | `ApiError` |
| 403 | Forbidden | `ApiError` |
| 404 | Not Found | `ApiError` |
| 422 | Unprocessable entity | `ApiError` |


# TMS Attachment Collection

```ts
async tMSAttachmentCollection(
  orderNum?: string,
  environment?: string,
  fileId?: string,
  type?: string,
  requestOptions?: RequestOptions
): Promise<ApiResponse<string>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `orderNum` | `string \| undefined` | Query, Optional | - |
| `environment` | `string \| undefined` | Query, Optional | - |
| `fileId` | `string \| undefined` | Query, Optional | - |
| `type` | `string \| undefined` | Query, Optional | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

`string`

## Example Usage

```ts
try {
  const { result, ...httpResponse } = await tmsController.tMSAttachmentCollection();
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch(error) {
  if (error instanceof ApiError) {
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```

## Example Response

```
"{\n   \"_links\": {\n       \"self\": {\n           \"href\": \"/tms/attachment\"\n       },\n       \"first\": {\n           \"href\": \"/tms/attachment?page={page}\"\n       },\n       \"prev\": {\n           \"href\": \"/tms/attachment?page={page}\"\n       },\n       \"next\": {\n           \"href\": \"/tms/attachment?page={page}\"\n       },\n       \"last\": {\n           \"href\": \"/tms/attachment?page={page}\"\n       }\n   }\n   \"_embedded\": {\n       \"attachment\": [\n           {\n               \"_links\": {\n                   \"self\": {\n                       \"href\": \"/tms/attachment[/:attachment_id]\"\n                   }\n               }\n              \"order_num\": \"\",\n              \"type\": \"\",\n              \"file_id\": \"\",\n              \"timestamp\": \"\",\n              \"environment\": \"\"\n           }\n       ]\n   }\n}"
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | `ApiError` |
| 403 | Forbidden | `ApiError` |
| 404 | Not Found | `ApiError` |
| 422 | Unprocessable entity | `ApiError` |


# TMS Attachment

```ts
async tMSAttachment(
  id: string,
  params: TMSAttachment,
  requestOptions?: RequestOptions
): Promise<ApiResponse<string>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `string` | Template, Required | - |
| `params` | [`TMSAttachment`](../../doc/models/tms-attachment.md) | Body, Required | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

`string`

## Example Usage

```ts
const id = 'id0';
const params: TMSAttachment = {
  orderNum: 'order_num6',
  type: 'type6',
  fileId: 'file_id0',
  timestamp: 'timestamp2',
  environment: 'environment0',
};

try {
  const { result, ...httpResponse } = await tmsController.tMSAttachment(id, params);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch(error) {
  if (error instanceof ApiError) {
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```

## Example Response

```
"{\n   \"_links\": {\n       \"self\": {\n           \"href\": \"/tms/attachment\"\n       },\n       \"first\": {\n           \"href\": \"/tms/attachment?page={page}\"\n       },\n       \"prev\": {\n           \"href\": \"/tms/attachment?page={page}\"\n       },\n       \"next\": {\n           \"href\": \"/tms/attachment?page={page}\"\n       },\n       \"last\": {\n           \"href\": \"/tms/attachment?page={page}\"\n       }\n   }\n   \"_embedded\": {\n       \"attachment\": [\n           {\n               \"_links\": {\n                   \"self\": {\n                       \"href\": \"/tms/attachment[/:attachment_id]\"\n                   }\n               }\n              \"order_num\": \"\",\n              \"type\": \"\",\n              \"file_id\": \"\",\n              \"timestamp\": \"\",\n              \"environment\": \"\"\n           }\n       ]\n   }\n}"
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | `ApiError` |
| 403 | Forbidden | `ApiError` |
| 404 | Not Found | `ApiError` |
| 422 | Unprocessable entity | `ApiError` |


# TMS Attachment 1

```ts
async tMSAttachment1(
  id: string,
  requestOptions?: RequestOptions
): Promise<ApiResponse<string>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `string` | Template, Required | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

`string`

## Example Usage

```ts
const id = 'id0';
try {
  const { result, ...httpResponse } = await tmsController.tMSAttachment1(id);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch(error) {
  if (error instanceof ApiError) {
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | `ApiError` |
| 403 | Forbidden | `ApiError` |
| 404 | Not Found | `ApiError` |
| 422 | Unprocessable entity | `ApiError` |


# TMS Attachment 2

```ts
async tMSAttachment2(
  params: TMSAttachment,
  requestOptions?: RequestOptions
): Promise<ApiResponse<string>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `params` | [`TMSAttachment`](../../doc/models/tms-attachment.md) | Body, Required | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

`string`

## Example Usage

```ts
const params: TMSAttachment = {
  orderNum: 'order_num6',
  type: 'type6',
  fileId: 'file_id0',
  timestamp: 'timestamp2',
  environment: 'environment0',
};

try {
  const { result, ...httpResponse } = await tmsController.tMSAttachment2(params);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch(error) {
  if (error instanceof ApiError) {
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```

## Example Response

```
"{\n   \"_links\": {\n       \"self\": {\n           \"href\": \"/tms/attachment[/:attachment_id]\"\n       }\n   }\n   \"order_num\": \"\",\n   \"type\": \"\",\n   \"file_id\": \"\",\n   \"timestamp\": \"\",\n   \"environment\": \"\"\n}"
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | `ApiError` |
| 403 | Forbidden | `ApiError` |
| 404 | Not Found | `ApiError` |
| 422 | Unprocessable entity | `ApiError` |


# TMS Scan Parcel List

```ts
async tMSScanParcelList(
  id: string,
  requestOptions?: RequestOptions
): Promise<ApiResponse<string>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `string` | Body, Required | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

`string`

## Example Usage

```ts
const id = '19GV210E91H001';
try {
  const { result, ...httpResponse } = await tmsController.tMSScanParcelList(id);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch(error) {
  if (error instanceof ApiError) {
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```

## Example Response

```
"{\n    \"0\": {\n        \"order_num\": \"19GV210E91H\",\n        \"type\": \"D\",\n        \"delivery_remarks\": \"\",\n        \"seal\": \"921443\",\n        \"service_type\": \"\",\n        \"prerefno\": \"\",\n        \"mawb\": \"72405808342\",\n        \"house\": \"19PA110D62Q\",\n        \"parcels\": [\n            {\n                \"id\": 9948831,\n                \"parcel_num\": \"19GV210E91H001\",\n                \"order_num\": \"19GV210E91H\",\n                \"box_num\": 1,\n                \"gross_weight\": 0,\n                \"mark\": \"\",\n                \"item_num\": 1,\n                \"seal\": \"\",\n                \"dim1\": 0,\n                \"dim2\": 0,\n                \"dim3\": 0,\n                \"label\": \"\",\n                \"seal2\": \"\",\n                \"seal3\": \"\",\n                \"ext_seal\": \"\",\n                \"dlv_scan\": 0,\n                \"pk_scan\": 0,\n                \"environment\": 7,\n                \"mark_orig\": \"\"\n            },\n            {\n                \"id\": 9948832,\n                \"parcel_num\": \"19GV210E91H002\",\n                \"order_num\": \"19GV210E91H\",\n                \"box_num\": 1,\n                \"gross_weight\": 0,\n                \"mark\": \"\",\n                \"item_num\": 1,\n                \"seal\": \"\",\n                \"dim1\": 0,\n                \"dim2\": 0,\n                \"dim3\": 0,\n                \"label\": \"\",\n                \"seal2\": \"\",\n                \"seal3\": \"\",\n                \"ext_seal\": \"\",\n                \"dlv_scan\": 0,\n                \"pk_scan\": 0,\n                \"environment\": 7,\n                \"mark_orig\": \"\"\n            },\n            {\n                \"id\": 9948833,\n                \"parcel_num\": \"19GV210E91H003\",\n                \"order_num\": \"19GV210E91H\",\n                \"box_num\": 1,\n                \"gross_weight\": 0,\n                \"mark\": \"\",\n                \"item_num\": 1,\n                \"seal\": \"\",\n                \"dim1\": 0,\n                \"dim2\": 0,\n                \"dim3\": 0,\n                \"label\": \"\",\n                \"seal2\": \"\",\n                \"seal3\": \"\",\n                \"ext_seal\": \"\",\n                \"dlv_scan\": 0,\n                \"pk_scan\": 0,\n                \"environment\": 7,\n                \"mark_orig\": \"\"\n            }\n        ]\n    }\n}"
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | `ApiError` |
| 403 | Forbidden | `ApiError` |
| 404 | Not Found | `ApiError` |
| 422 | Unprocessable entity | `ApiError` |


# TMS Scan In

```ts
async tMSScanIn(
  params: TMsScanIn,
  requestOptions?: RequestOptions
): Promise<ApiResponse<void>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `params` | [`TMsScanIn`](../../doc/models/t-ms-scan-in.md) | Body, Required | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

`void`

## Example Usage

```ts
const params: TMsScanIn = {
  orderNum: '19GV210E91H',
  device: 'G0011',
  timeActualScan: '2022-04-21 12:11:07',
};

try {
  const { result, ...httpResponse } = await tmsController.tMSScanIn(params);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch(error) {
  if (error instanceof ApiError) {
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | `ApiError` |
| 403 | Forbidden | `ApiError` |
| 404 | Not Found | `ApiError` |
| 422 | Unprocessable entity | `ApiError` |


# TMS Warehouse Collection

```ts
async tMSWarehouseCollection(
  environment?: string,
  code?: string,
  active?: number,
  requestOptions?: RequestOptions
): Promise<ApiResponse<string>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `environment` | `string \| undefined` | Query, Optional | - |
| `code` | `string \| undefined` | Query, Optional | - |
| `active` | `number \| undefined` | Query, Optional | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

`string`

## Example Usage

```ts
const active = 1;
try {
  const { result, ...httpResponse } = await tmsController.tMSWarehouseCollection(None, None, active);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch(error) {
  if (error instanceof ApiError) {
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```

## Example Response

```
"{\n    \"_links\": {\n        \"self\": {\n            \"href\": \"https://fundoni.webapps2-backend.test.ferrarigroup.net/tms/warehouse?page=1\"\n        },\n        \"first\": {\n            \"href\": \"https://fundoni.webapps2-backend.test.ferrarigroup.net/tms/warehouse\"\n        },\n        \"last\": {\n            \"href\": \"https://fundoni.webapps2-backend.test.ferrarigroup.net/tms/warehouse?page=2\"\n        },\n        \"next\": {\n            \"href\": \"https://fundoni.webapps2-backend.test.ferrarigroup.net/tms/warehouse?page=2\"\n        }\n    },\n    \"_embedded\": {\n        \"warehouse\": [\n            {\n                \"id\": 1,\n                \"code\": \"HKG\",\n                \"description\": \"Hong Kong Warehouse\",\n                \"environment\": 1,\n                \"active\": 1,\n                \"_links\": {\n                    \"self\": {\n                        \"href\": \"https://fundoni.webapps2-backend.test.ferrarigroup.net/tms/warehouse/1\"\n                    }\n                }\n            },\n            {\n                \"id\": 2,\n                \"code\": \"BV1\",\n                \"description\": \"Buffer vehicle 1 KCC\",\n                \"environment\": 1,\n                \"active\": 1,\n                \"_links\": {\n                    \"self\": {\n                        \"href\": \"https://fundoni.webapps2-backend.test.ferrarigroup.net/tms/warehouse/2\"\n                    }\n                }\n            },\n            {\n                \"id\": 3,\n                \"code\": \"BV2\",\n                \"description\": \"Buffer vehicle 2 KCC\",\n                \"environment\": 1,\n                \"active\": 1,\n                \"_links\": {\n                    \"self\": {\n                        \"href\": \"https://fundoni.webapps2-backend.test.ferrarigroup.net/tms/warehouse/3\"\n                    }\n                }\n            },\n            {\n                \"id\": 4,\n                \"code\": \"BV3\",\n                \"description\": \"Buffer vehicle 3 KCC\",\n                \"environment\": 1,\n                \"active\": 1,\n                \"_links\": {\n                    \"self\": {\n                        \"href\": \"https://fundoni.webapps2-backend.test.ferrarigroup.net/tms/warehouse/4\"\n                    }\n                }\n            },\n            {\n                \"id\": 6,\n                \"code\": \"BOF1\",\n                \"description\": \"CENTRAL OFFICE\",\n                \"environment\": 1,\n                \"active\": 1,\n                \"_links\": {\n                    \"self\": {\n                        \"href\": \"https://fundoni.webapps2-backend.test.ferrarigroup.net/tms/warehouse/6\"\n                    }\n                }\n            },\n            {\n                \"id\": 7,\n                \"code\": \"BOF2\",\n                \"description\": \"HUNGHOM OFFICE\",\n                \"environment\": 1,\n                \"active\": 1,\n                \"_links\": {\n                    \"self\": {\n                        \"href\": \"https://fundoni.webapps2-backend.test.ferrarigroup.net/tms/warehouse/7\"\n                    }\n                }\n            },\n            {\n                \"id\": 43,\n                \"code\": \"test2\",\n                \"description\": \"warehouse di test 2\",\n                \"environment\": 1,\n                \"active\": 1,\n                \"_links\": {\n                    \"self\": {\n                        \"href\": \"https://fundoni.webapps2-backend.test.ferrarigroup.net/tms/warehouse/43\"\n                    }\n                }\n            },\n            {\n                \"id\": 44,\n                \"code\": \"01\",\n                \"description\": \"test\",\n                \"environment\": 9,\n                \"active\": 1,\n                \"_links\": {\n                    \"self\": {\n                        \"href\": \"https://fundoni.webapps2-backend.test.ferrarigroup.net/tms/warehouse/44\"\n                    }\n                }\n            },\n            {\n                \"id\": 45,\n                \"code\": \"01\",\n                \"description\": \"test\",\n                \"environment\": 8,\n                \"active\": 1,\n                \"_links\": {\n                    \"self\": {\n                        \"href\": \"https://fundoni.webapps2-backend.test.ferrarigroup.net/tms/warehouse/45\"\n                    }\n                }\n            },\n            {\n                \"id\": 46,\n                \"code\": \"02\",\n                \"description\": \"test2\",\n                \"environment\": 8,\n                \"active\": 1,\n                \"_links\": {\n                    \"self\": {\n                        \"href\": \"https://fundoni.webapps2-backend.test.ferrarigroup.net/tms/warehouse/46\"\n                    }\n                }\n            },\n            {\n                \"id\": 47,\n                \"code\": \"TEST ARI\",\n                \"description\": \"TEST ARI\",\n                \"environment\": 14,\n                \"active\": 1,\n                \"_links\": {\n                    \"self\": {\n                        \"href\": \"https://fundoni.webapps2-backend.test.ferrarigroup.net/tms/warehouse/47\"\n                    }\n                }\n            },\n            {\n                \"id\": 48,\n                \"code\": \"T\",\n                \"description\": \"Buffer truck\",\n                \"environment\": 8,\n                \"active\": 1,\n                \"_links\": {\n                    \"self\": {\n                        \"href\": \"https://fundoni.webapps2-backend.test.ferrarigroup.net/tms/warehouse/48\"\n                    }\n                }\n            },\n            {\n                \"id\": 49,\n                \"code\": \"S-2\",\n                \"description\": \"Shanghai downtown 608\",\n                \"environment\": 8,\n                \"active\": 1,\n                \"_links\": {\n                    \"self\": {\n                        \"href\": \"https://fundoni.webapps2-backend.test.ferrarigroup.net/tms/warehouse/49\"\n                    }\n                }\n            },\n            {\n                \"id\": 50,\n                \"code\": \"RCCL1\",\n                \"description\": \"线路一\",\n                \"environment\": 8,\n                \"active\": 1,\n                \"_links\": {\n                    \"self\": {\n                        \"href\": \"https://fundoni.webapps2-backend.test.ferrarigroup.net/tms/warehouse/50\"\n                    }\n                }\n            },\n            {\n                \"id\": 51,\n                \"code\": \"RCCL2\",\n                \"description\": \"线路二\",\n                \"environment\": 8,\n                \"active\": 1,\n                \"_links\": {\n                    \"self\": {\n                        \"href\": \"https://fundoni.webapps2-backend.test.ferrarigroup.net/tms/warehouse/51\"\n                    }\n                }\n            },\n            {\n                \"id\": 52,\n                \"code\": \"RCCL3\",\n                \"description\": \"线路三\",\n                \"environment\": 8,\n                \"active\": 1,\n                \"_links\": {\n                    \"self\": {\n                        \"href\": \"https://fundoni.webapps2-backend.test.ferrarigroup.net/tms/warehouse/52\"\n                    }\n                }\n            },\n            {\n                \"id\": 53,\n                \"code\": \"CN_01\",\n                \"description\": \"Test Warehouse\",\n                \"environment\": 8,\n                \"active\": 1,\n                \"_links\": {\n                    \"self\": {\n                        \"href\": \"https://fundoni.webapps2-backend.test.ferrarigroup.net/tms/warehouse/53\"\n                    }\n                }\n            },\n            {\n                \"id\": 54,\n                \"code\": \"GVATEST\",\n                \"description\": \"Test GVA\",\n                \"environment\": 7,\n                \"active\": 1,\n                \"_links\": {\n                    \"self\": {\n                        \"href\": \"https://fundoni.webapps2-backend.test.ferrarigroup.net/tms/warehouse/54\"\n                    }\n                }\n            },\n            {\n                \"id\": 55,\n                \"code\": \"VAULT\",\n                \"description\": \"unit 6\",\n                \"environment\": 1,\n                \"active\": 1,\n                \"_links\": {\n                    \"self\": {\n                        \"href\": \"https://fundoni.webapps2-backend.test.ferrarigroup.net/tms/warehouse/55\"\n                    }\n                }\n            },\n            {\n                \"id\": 56,\n                \"code\": \"VAULT 2\",\n                \"description\": \"UNIT 3\",\n                \"environment\": 1,\n                \"active\": 1,\n                \"_links\": {\n                    \"self\": {\n                        \"href\": \"https://fundoni.webapps2-backend.test.ferrarigroup.net/tms/warehouse/56\"\n                    }\n                }\n            },\n            {\n                \"id\": 57,\n                \"code\": \"SHOW(1)\",\n                \"description\": \"UNIT 3 (SHOW)\",\n                \"environment\": 1,\n                \"active\": 1,\n                \"_links\": {\n                    \"self\": {\n                        \"href\": \"https://fundoni.webapps2-backend.test.ferrarigroup.net/tms/warehouse/57\"\n                    }\n                }\n            },\n            {\n                \"id\": 58,\n                \"code\": \"SHOW(2)\",\n                \"description\": \"UNIT 6(SHOW)\",\n                \"environment\": 1,\n                \"active\": 1,\n                \"_links\": {\n                    \"self\": {\n                        \"href\": \"https://fundoni.webapps2-backend.test.ferrarigroup.net/tms/warehouse/58\"\n                    }\n                }\n            },\n            {\n                \"id\": 59,\n                \"code\": \"D\",\n                \"description\": \"SDE safe room\",\n                \"environment\": 8,\n                \"active\": 1,\n                \"_links\": {\n                    \"self\": {\n                        \"href\": \"https://fundoni.webapps2-backend.test.ferrarigroup.net/tms/warehouse/59\"\n                    }\n                }\n            },\n            {\n                \"id\": 60,\n                \"code\": \"S\",\n                \"description\": \"Shanghai downtown 708\",\n                \"environment\": 8,\n                \"active\": 1,\n                \"_links\": {\n                    \"self\": {\n                        \"href\": \"https://fundoni.webapps2-backend.test.ferrarigroup.net/tms/warehouse/60\"\n                    }\n                }\n            },\n            {\n                \"id\": 61,\n                \"code\": \"W\",\n                \"description\": \"Shanghai ALC\",\n                \"environment\": 8,\n                \"active\": 1,\n                \"_links\": {\n                    \"self\": {\n                        \"href\": \"https://fundoni.webapps2-backend.test.ferrarigroup.net/tms/warehouse/61\"\n                    }\n                }\n            }\n        ]\n    },\n    \"page_count\": 2,\n    \"page_size\": 25,\n    \"total_items\": 36,\n    \"page\": 1\n}"
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | `ApiError` |
| 403 | Forbidden | `ApiError` |
| 404 | Not Found | `ApiError` |
| 422 | Unprocessable entity | `ApiError` |


# TMS Warehouse Entity

```ts
async tMSWarehouseEntity(
  id: string,
  requestOptions?: RequestOptions
): Promise<ApiResponse<string>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `string` | Template, Required | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

`string`

## Example Usage

```ts
const id = 'id0';
try {
  const { result, ...httpResponse } = await tmsController.tMSWarehouseEntity(id);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch(error) {
  if (error instanceof ApiError) {
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```

## Example Response

```
"{\n    \"id\": 1,\n    \"code\": \"HKG\",\n    \"description\": \"Hong Kong Warehouse\",\n    \"environment\": 1,\n    \"active\": 1,\n    \"_links\": {\n        \"self\": {\n            \"href\": \"https://fundoni.webapps2-backend.test.ferrarigroup.net/tms/warehouse/1\"\n        }\n    }\n}"
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | `ApiError` |
| 403 | Forbidden | `ApiError` |
| 404 | Not Found | `ApiError` |
| 422 | Unprocessable entity | `ApiError` |


# TMS Warehouse

```ts
async tMSWarehouse(
  id: string,
  requestOptions?: RequestOptions
): Promise<ApiResponse<string>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `string` | Template, Required | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

`string`

## Example Usage

```ts
const id = 'id0';
try {
  const { result, ...httpResponse } = await tmsController.tMSWarehouse(id);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch(error) {
  if (error instanceof ApiError) {
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | `ApiError` |
| 403 | Forbidden | `ApiError` |
| 404 | Not Found | `ApiError` |
| 422 | Unprocessable entity | `ApiError` |


# TMS Warehouse 1

```ts
async tMSWarehouse1(
  id: string,
  params: TMSWarehouse,
  requestOptions?: RequestOptions
): Promise<ApiResponse<string>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `string` | Template, Required | - |
| `params` | [`TMSWarehouse`](../../doc/models/tms-warehouse.md) | Body, Required | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

`string`

## Example Usage

```ts
const id = 'id0';
const params: TMSWarehouse = {
  code: 'HKG',
  description: 'Hong Kong Warehouse test',
  environment: '1',
  active: '1',
};

try {
  const { result, ...httpResponse } = await tmsController.tMSWarehouse1(id, params);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch(error) {
  if (error instanceof ApiError) {
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```

## Example Response

```
"{\n    \"id\": 1,\n    \"code\": \"HKG\",\n    \"description\": \"Hong Kong Warehouse test\",\n    \"environment\": 1,\n    \"active\": 1,\n    \"_links\": {\n        \"self\": {\n            \"href\": \"https://fundoni.webapps2-backend.test.ferrarigroup.net/tms/warehouse/1\"\n        }\n    }\n}"
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | `ApiError` |
| 403 | Forbidden | `ApiError` |
| 404 | Not Found | `ApiError` |
| 422 | Unprocessable entity | `ApiError` |


# TMS Manifest Create

```ts
async tMSManifestCreate(
  requestOptions?: RequestOptions
): Promise<ApiResponse<string>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

`string`

## Example Usage

```ts
try {
  const { result, ...httpResponse } = await tmsController.tMSManifestCreate();
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch(error) {
  if (error instanceof ApiError) {
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```

## Example Response

```
"{\n    \"manifest_number\": \"TMSM1202255568242\"\n}"
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | `ApiError` |
| 403 | Forbidden | `ApiError` |
| 404 | Not Found | `ApiError` |
| 422 | Unprocessable entity | `ApiError` |


# TMS Track Action

```ts
async tMSTrackAction(
  requestOptions?: RequestOptions
): Promise<ApiResponse<string>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

`string`

## Example Usage

```ts
try {
  const { result, ...httpResponse } = await tmsController.tMSTrackAction();
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch(error) {
  if (error instanceof ApiError) {
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```

## Example Response

```
"{\n   \"action\": \"\",\n   \"object_id\": \"\",\n   \"place\": \"\",\n   \"latitude\": \"\",\n   \"longitude\": \"\",\n   \"user_id\": \"\",\n   \"timestamp\": \"\",\n   \"ferrari_branch\": \"\",\n   \"device\": \"\",\n   \"environment\": \"\",\n   \"tag\": \"\",\n   \"name\": \"\",\n   \"remarks\": \"\",\n   \"seal\": \"\",\n   \"manifest_id\": \"\",\n   \"attachments\": \"\"\n}"
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | `ApiError` |
| 403 | Forbidden | `ApiError` |
| 404 | Not Found | `ApiError` |
| 422 | Unprocessable entity | `ApiError` |


# TMS Tracking Place

```ts
async tMSTrackingPlace(
  placeId?: string,
  tag?: string,
  ferrariBranch?: string,
  placeCity?: string,
  placeState?: string,
  partnerBranch?: string,
  requestOptions?: RequestOptions
): Promise<ApiResponse<string>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `placeId` | `string \| undefined` | Query, Optional | - |
| `tag` | `string \| undefined` | Query, Optional | - |
| `ferrariBranch` | `string \| undefined` | Query, Optional | - |
| `placeCity` | `string \| undefined` | Query, Optional | - |
| `placeState` | `string \| undefined` | Query, Optional | - |
| `partnerBranch` | `string \| undefined` | Query, Optional | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

`string`

## Example Usage

```ts
try {
  const { result, ...httpResponse } = await tmsController.tMSTrackingPlace();
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch(error) {
  if (error instanceof ApiError) {
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```

## Example Response

```
"{\n   \"_links\": {\n       \"self\": {\n           \"href\": \"/tms/tracking-place\"\n       },\n       \"first\": {\n           \"href\": \"/tms/tracking-place?page={page}\"\n       },\n       \"prev\": {\n           \"href\": \"/tms/tracking-place?page={page}\"\n       },\n       \"next\": {\n           \"href\": \"/tms/tracking-place?page={page}\"\n       },\n       \"last\": {\n           \"href\": \"/tms/tracking-place?page={page}\"\n       }\n   }\n   \"_embedded\": {\n       \"tracking_place\": [\n           {\n               \"_links\": {\n                   \"self\": {\n                       \"href\": \"/tms/tracking-place[/:tracking_place_id]\"\n                   }\n               }\n              \"place_id\": \"\",\n              \"place_name\": \"\",\n              \"place_address\": \"\",\n              \"place_city\": \"\",\n              \"place_state\": \"\",\n              \"place_country\": \"\",\n              \"ferrari_branch\": \"\",\n              \"partner_branch\": \"\",\n              \"tag\": \"\"\n           }\n       ]\n   }\n}"
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | `ApiError` |
| 403 | Forbidden | `ApiError` |
| 404 | Not Found | `ApiError` |
| 422 | Unprocessable entity | `ApiError` |


# TMS Return Status

```ts
async tMSReturnStatus(
  code?: string,
  flowTag?: string,
  type?: string,
  requestOptions?: RequestOptions
): Promise<ApiResponse<string>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `code` | `string \| undefined` | Query, Optional | - |
| `flowTag` | `string \| undefined` | Query, Optional | - |
| `type` | `string \| undefined` | Query, Optional | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

`string`

## Example Usage

```ts
try {
  const { result, ...httpResponse } = await tmsController.tMSReturnStatus();
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch(error) {
  if (error instanceof ApiError) {
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```

## Example Response

```
"{\n   \"_links\": {\n       \"self\": {\n           \"href\": \"/return-status\"\n       },\n       \"first\": {\n           \"href\": \"/return-status?page={page}\"\n       },\n       \"prev\": {\n           \"href\": \"/return-status?page={page}\"\n       },\n       \"next\": {\n           \"href\": \"/return-status?page={page}\"\n       },\n       \"last\": {\n           \"href\": \"/return-status?page={page}\"\n       }\n   }\n   \"_embedded\": {\n       \"return_status\": [\n           {\n               \"_links\": {\n                   \"self\": {\n                       \"href\": \"/return-status[/:return_status_id]\"\n                   }\n               }\n              \"code\": \"\",\n              \"description\": \"\",\n              \"flow_tag\": \"\",\n              \"type\": \"\",\n              \"id\": \"\"\n           }\n       ]\n   }\n}"
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | `ApiError` |
| 403 | Forbidden | `ApiError` |
| 404 | Not Found | `ApiError` |
| 422 | Unprocessable entity | `ApiError` |


# TMS Get Addresses

```ts
async tMSGetAddresses(
  requestOptions?: RequestOptions
): Promise<ApiResponse<string>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

`string`

## Example Usage

```ts
try {
  const { result, ...httpResponse } = await tmsController.tMSGetAddresses();
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch(error) {
  if (error instanceof ApiError) {
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```

## Example Response

```
"{\n    \"0\": {\n        \"id\": \"227613\",\n        \"companyname\": \"\",\n        \"address\": \"\",\n        \"city\": \"COMPANS\",\n        \"district\": \"\",\n        \"postalcode\": \"77290\",\n        \"statepro\": \"\",\n        \"country\": \"FR\",\n        \"phone\": \"\",\n        \"email\": \"\",\n        \"contact\": \"\",\n        \"code\": \"C009178303\"\n    },\n    \"1\": {\n        \"id\": \"227027\",\n        \"companyname\": \"\",\n        \"address\": \"\",\n        \"city\": \"\",\n        \"district\": \"\",\n        \"postalcode\": \"\",\n        \"statepro\": \"\",\n        \"country\": \"\",\n        \"phone\": \"\",\n        \"email\": \"\",\n        \"contact\": \"\",\n        \"code\": \"d41d8cd98f00b204e9800998ecf8427e\"\n    }\n}"
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | `ApiError` |
| 403 | Forbidden | `ApiError` |
| 404 | Not Found | `ApiError` |
| 422 | Unprocessable entity | `ApiError` |


# TMS Get Countires

```ts
async tMSGetCountires(
  requestOptions?: RequestOptions
): Promise<ApiResponse<string>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

`string`

## Example Usage

```ts
try {
  const { result, ...httpResponse } = await tmsController.tMSGetCountires();
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch(error) {
  if (error instanceof ApiError) {
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```

## Example Response

```
"{\n    \"0\": {\n        \"id\": \"1\",\n        \"F2\": \"AD\",\n        \"F1\": \"Andorra\"\n    },\n    \"1\": {\n        \"id\": \"2\",\n        \"F2\": \"AE\",\n        \"F1\": \"United Arab Emirates\"\n    },\n    \"2\": {\n        \"id\": \"3\",\n        \"F2\": \"AF\",\n        \"F1\": \"Afghanistan\"\n    },\n    \"3\": {\n        \"id\": \"4\",\n        \"F2\": \"AG\",\n        \"F1\": \"Antigua and Barbuda\"\n    }\n}"
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | `ApiError` |
| 403 | Forbidden | `ApiError` |
| 404 | Not Found | `ApiError` |
| 422 | Unprocessable entity | `ApiError` |


# TMS Add Address

```ts
async tMSAddAddress(
  params: TMSAddress,
  requestOptions?: RequestOptions
): Promise<ApiResponse<Status>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `params` | [`TMSAddress`](../../doc/models/tms-address.md) | Body, Required | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

[`Status`](../../doc/models/status.md)

## Example Usage

```ts
const params: TMSAddress = {
  code: 'F123456',
  companyname: 'companyname8',
  address: 'address0',
  city: 'city6',
  country: 'IT',
};

try {
  const { result, ...httpResponse } = await tmsController.tMSAddAddress(params);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch(error) {
  if (error instanceof ApiError) {
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | `ApiError` |
| 403 | Forbidden | `ApiError` |
| 404 | Not Found | `ApiError` |
| 422 | Unprocessable entity | `ApiError` |


# TMS Shipment Add

```ts
async tMSShipmentAdd(
  params: AddShipmentBody,
  requestOptions?: RequestOptions
): Promise<ApiResponse<string>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `params` | [`AddShipmentBody`](../../doc/models/add-shipment-body.md) | Body, Required | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

`string`

## Example Usage

```ts
const paramsShipment: AddShipmentShipdata = {
  shipperCode: 'shipper-code6',
  consigneeCode: 'consignee-code2',
  orderNum: 'order_num0',
  timeActualPickup: 'time_actual_pickup6',
};

const paramsParcels: AddShipmentParceldata = {
  seal: 'seal8',
};

const params: AddShipmentBody = {
  shipment: paramsShipment,
  parcels: paramsParcels,
  guard: 'guard8',
  truck: 'truck4',
  crewId: 'crew_id6',
};

try {
  const { result, ...httpResponse } = await tmsController.tMSShipmentAdd(params);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch(error) {
  if (error instanceof ApiError) {
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | `ApiError` |
| 403 | Forbidden | `ApiError` |
| 404 | Not Found | `ApiError` |
| 422 | Unprocessable entity | `ApiError` |


# TMS Geolocation

```ts
async tMSGeolocation(
  params: Geolocation,
  requestOptions?: RequestOptions
): Promise<ApiResponse<void>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `params` | [`Geolocation`](../../doc/models/geolocation.md) | Body, Required | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

`void`

## Example Usage

```ts
const params: Geolocation = {
  longitude: 'longitude8',
  latitude: 'latitude2',
  device: 'device0',
};

try {
  const { result, ...httpResponse } = await tmsController.tMSGeolocation(params);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch(error) {
  if (error instanceof ApiError) {
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | `ApiError` |
| 403 | Forbidden | `ApiError` |
| 404 | Not Found | `ApiError` |
| 422 | Unprocessable entity | `ApiError` |

