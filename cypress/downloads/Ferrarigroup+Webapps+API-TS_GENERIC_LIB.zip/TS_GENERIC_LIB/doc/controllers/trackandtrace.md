# Trackandtrace

```ts
const trackandtraceController = new TrackandtraceController(client);
```

## Class Name

`TrackandtraceController`


# Shipment Status

Get the status of a given shipment ID

```ts
async shipmentStatus(
  id: string,
  requestOptions?: RequestOptions
): Promise<ApiResponse<ShipmentStatusReturn>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `string` | Query, Required | Tracking ID of the shipment |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

[`ShipmentStatusReturn`](../../doc/models/shipment-status-return.md)

## Example Usage

```ts
const id = '/tracking/shipment-status?id=20NXXXXXXXX';
try {
  const { result, ...httpResponse } = await trackandtraceController.shipmentStatus(id);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch(error) {
  if (error instanceof ApiError) {
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```

## Example Response *(as JSON)*

```json
{
  "shipment_id": "20NEXXXXXXX",
  "status_list": [
    {
      "date": "2020-08-05 12:00",
      "status_info": "Delivered To Name and Surname",
      "tracking": " ",
      "office_in_charge": "Neuchatel"
    },
    {
      "date": "2020-08-05",
      "status_info": "Processing By Ferrari",
      "tracking": "20NEXXXXXXX ",
      "office_in_charge": "Monaco"
    },
    {
      "date": "2020-08-04",
      "status_info": "Processing By Ferrari",
      "tracking": "20NEXXXXXXX ",
      "office_in_charge": "Alessandria"
    },
    {
      "date": "2020-08-03",
      "status_info": "Shipped",
      "tracking": "20NEXXXXXXX ",
      "office_in_charge": ""
    },
    {
      "date": "2020-07-31",
      "status_info": "Processing By Ferrari",
      "tracking": "20NEXXXXXXX ",
      "office_in_charge": "Neuchatel"
    }
  ]
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 403 | You are not allowed to view this shipment | `ApiError` |
| 404 | Shipment not found | `ApiError` |

