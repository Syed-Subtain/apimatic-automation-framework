# Authorization

```ts
const authorizationController = new AuthorizationController(client);
```

## Class Name

`AuthorizationController`


# Authorization

```ts
async authorization(
  grantType: string,
  username: string,
  password: string,
  authorization: string,
  requestOptions?: RequestOptions
): Promise<ApiResponse<string>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `grantType` | `string` | Query, Required | - |
| `username` | `string` | Query, Required | - |
| `password` | `string` | Query, Required | - |
| `authorization` | `string` | Header, Required | basic auth app |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

`string`

## Example Usage

```ts
const grantType = 'password';
const username = 'username';
const password = 'password';
const authorization = 'Basic ZXdtc2FwcDowZHVmT3VPeSR0V3g=';
try {
  const { result, ...httpResponse } = await authorizationController.authorization(grantType, username, password, authorization);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch(error) {
  if (error instanceof ApiError) {
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```

## Example Response

```
"{\n    \"access_token\": \"b8895ea855e65b64e179c6dfb26a50792803a27f\",\n    \"expires_in\": 3600,\n    \"token_type\": \"Bearer\",\n    \"scope\": \"\",\n    \"refresh_token\": \"f3df703dae98c5e76eee79d38156e636b12f1c97\"\n}"
```

