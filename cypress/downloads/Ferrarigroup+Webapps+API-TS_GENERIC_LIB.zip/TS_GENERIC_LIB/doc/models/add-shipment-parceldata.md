
# Add Shipment Parceldata

## Structure

`AddShipmentParceldata`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `seal` | `string` | Required | sigillo inserito |
| `weight` | `string \| undefined` | Optional | peso collo |

## Example (as JSON)

```json
{
  "seal": "seal2",
  "weight": null
}
```

