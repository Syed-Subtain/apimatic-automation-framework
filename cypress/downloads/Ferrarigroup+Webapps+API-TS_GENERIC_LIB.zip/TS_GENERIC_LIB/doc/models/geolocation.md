
# Geolocation

## Structure

`Geolocation`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `longitude` | `string` | Required | - |
| `latitude` | `string` | Required | - |
| `device` | `string` | Required | - |

## Example (as JSON)

```json
{
  "longitude": "longitude4",
  "latitude": "latitude6",
  "device": "device6"
}
```

