
# TMS Warehouse

## Structure

`TMSWarehouse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `code` | `string` | Required | warehouse code |
| `description` | `string` | Required | Warehouse description |
| `environment` | `string` | Required | TMS environemnt |
| `active` | `string` | Required | status warehouse 1 active 0 not active |

## Example (as JSON)

```json
{
  "code": "HKG",
  "description": "Hong Kong Warehouse test",
  "environment": "1",
  "active": "1"
}
```

