
# TMS Parcel

## Structure

`TMSParcel`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `parcelNum` | `string` | Required | - |
| `orderNum` | `string` | Required | - |
| `boxNum` | `string` | Required | - |
| `grossWeight` | `string` | Required | - |
| `mark` | `string` | Required | - |
| `itemNum` | `string` | Required | - |
| `seal` | `string` | Required | - |
| `dim1` | `string` | Required | - |
| `dim2` | `string` | Required | - |
| `dim3` | `string` | Required | - |
| `label` | `string` | Required | - |
| `seal2` | `string` | Required | - |
| `seal3` | `string` | Required | - |
| `dlvScan` | `string` | Required | - |
| `pkScan` | `string` | Required | - |
| `environment` | `string` | Required | - |
| `markOrig` | `string` | Required | - |

## Example (as JSON)

```json
{
  "parcel_num": "parcel_num4",
  "order_num": "order_num2",
  "box_num": "box_num8",
  "gross_weight": "gross_weight4",
  "mark": "mark4",
  "item_num": "item_num2",
  "seal": "seal2",
  "dim1": "dim18",
  "dim2": "dim28",
  "dim3": "dim34",
  "label": "label0",
  "seal2": "seal28",
  "seal3": "seal34",
  "dlv_scan": "dlv_scan6",
  "pk_scan": "pk_scan4",
  "environment": "environment6",
  "mark_orig": "mark_orig4"
}
```

