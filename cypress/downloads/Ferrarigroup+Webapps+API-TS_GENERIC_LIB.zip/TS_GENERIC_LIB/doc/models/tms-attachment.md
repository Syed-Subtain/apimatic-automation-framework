
# TMS Attachment

## Structure

`TMSAttachment`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `orderNum` | `string` | Required | - |
| `type` | `string` | Required | - |
| `fileId` | `string` | Required | - |
| `timestamp` | `string` | Required | - |
| `environment` | `string` | Required | - |

## Example (as JSON)

```json
{
  "order_num": "order_num2",
  "type": "type0",
  "file_id": "file_id6",
  "timestamp": "timestamp2",
  "environment": "environment6"
}
```

