
# TMS Track Action

## Structure

`TMSTrackAction`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `action` | `string` | Required | codice operazione |
| `objectId` | `string` | Required | valore da inserire |
| `place` | `string` | Required | codice azione se previsto |
| `latitude` | `string` | Required | coordinata operazione |
| `longitude` | `string` | Required | coordinata operazione |
| `userId` | `string` | Required | codice operatore che fa l'azione |
| `timestamp` | `string` | Required | timestamp orario operazione device |
| `device` | `string` | Required | codice dispositivo |
| `name` | `string \| null` | Required | - |
| `remarks` | `string \| null` | Required | - |
| `environment` | `string` | Required | environment operazione |
| `tag` | `string` | Required | tag operazione svolta |
| `seal` | `string \| null` | Required | - |
| `attachments` | `string \| null` | Required | id allegato |
| `manifestId` | `string` | Required | codice manifest |

## Example (as JSON)

```json
{
  "action": "PS",
  "object_id": "123456789",
  "place": null,
  "latitude": "40.8356714",
  "longitude": "-74.4410216",
  "user_id": null,
  "timestamp": "1654791804433",
  "device": "CC123",
  "name": null,
  "remarks": null,
  "environment": "20",
  "tag": "POSTE",
  "seal": null,
  "attachments": null,
  "manifest_id": "Ferr00000000"
}
```

