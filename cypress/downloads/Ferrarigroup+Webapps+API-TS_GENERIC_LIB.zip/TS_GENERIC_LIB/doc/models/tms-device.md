
# TMS Device

## Structure

`TMSDevice`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `environment` | `string` | Required | - |
| `phonenumber` | `string` | Required | - |
| `number` | `string` | Required | - |
| `serialNr` | `string \| undefined` | Optional | - |
| `latitude` | `string \| undefined` | Optional | - |
| `longitude` | `string \| undefined` | Optional | - |
| `timeGeolocation` | `string \| undefined` | Optional | - |
| `active` | `string \| undefined` | Optional | - |
| `needsync` | `string` | Required | - |
| `pushToken` | `string` | Required | - |
| `databaseToken` | `string` | Required | - |

## Example (as JSON)

```json
{
  "environment": "1",
  "phonenumber": null,
  "number": null,
  "needsync": "1",
  "push_token": null,
  "database_token": null
}
```

