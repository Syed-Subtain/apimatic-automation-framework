
# Status

description of the status change event

## Structure

`Status`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `date` | `string` | Required | date of event (could have time information as well) |
| `statusInfo` | `string` | Required | description of the status<br>**Constraints**: *Maximum Length*: `30` |
| `tracking` | `string \| undefined` | Optional | tracking information linked to the status (i.e carrier number)<br>**Constraints**: *Maximum Length*: `20` |
| `officeInCharge` | `string \| undefined` | Optional | Ferrari office in charge of the event<br>**Constraints**: *Maximum Length*: `20` |

## Example (as JSON)

```json
{
  "date": "2020-08-05 12:00 or 2020-08-05",
  "status_info": "processing by Ferrari"
}
```

