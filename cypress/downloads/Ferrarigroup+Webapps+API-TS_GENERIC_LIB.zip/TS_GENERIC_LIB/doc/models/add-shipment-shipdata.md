
# Add Shipment Shipdata

## Structure

`AddShipmentShipdata`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `shipperCode` | `string` | Required | id indirizzo shipper |
| `consigneeCode` | `string` | Required | id indirizzo shipper |
| `orderNum` | `string` | Required | - |
| `seal` | `string \| undefined` | Optional | - |
| `timeActualPickup` | `string` | Required | timestamp operazione |
| `remarks` | `string \| undefined` | Optional | - |
| `reference` | `string \| undefined` | Optional | - |

## Example (as JSON)

```json
{
  "shipper-code": "shipper-code8",
  "consignee-code": "consignee-code4",
  "order_num": "order_num2",
  "seal": null,
  "time_actual_pickup": "time_actual_pickup8",
  "remarks": null,
  "reference": null
}
```

