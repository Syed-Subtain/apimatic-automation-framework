
# TMS Address

## Structure

`TMSAddress`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `code` | `string` | Required | - |
| `companyname` | `string` | Required | - |
| `address` | `string` | Required | - |
| `city` | `string` | Required | - |
| `district` | `string \| undefined` | Optional | - |
| `postalcode` | `string \| undefined` | Optional | - |
| `statepro` | `string \| undefined` | Optional | - |
| `country` | `string` | Required | - |
| `phone` | `string \| undefined` | Optional | - |
| `email` | `string \| undefined` | Optional | - |
| `contact` | `string \| undefined` | Optional | - |
| `wso` | `string \| undefined` | Optional | - |

## Example (as JSON)

```json
{
  "code": "F123456",
  "companyname": null,
  "address": null,
  "city": null,
  "country": "IT"
}
```

