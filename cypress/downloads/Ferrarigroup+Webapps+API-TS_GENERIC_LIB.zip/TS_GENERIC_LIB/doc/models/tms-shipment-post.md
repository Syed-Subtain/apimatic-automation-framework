
# Tms Shipment Post

## Structure

`TmsShipmentPost`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `orderNum` | `string` | Required | - |
| `type` | `string` | Required | Tipo spedizione P = pickup D =delivery C = Completa<br>**Constraints**: *Minimum Length*: `1` |
| `serviceType` | `string` | Required | **Constraints**: *Maximum Length*: `45` |
| `priority` | `number` | Required | priorità per ordinamento lista ePod |
| `customerName` | `string` | Required | - |
| `customerAddress` | `string` | Required | - |
| `customerZip` | `string` | Required | - |
| `customerCity` | `string` | Required | - |
| `customerProv` | `string` | Required | - |
| `customerCountry` | `string` | Required | - |
| `customerPhone` | `string` | Required | - |
| `customerContact` | `string` | Required | - |
| `customerPassportId` | `string` | Required | - |
| `pickupName` | `string` | Required | - |
| `pickupAddress` | `string` | Required | - |
| `pickupZip` | `string` | Required | - |
| `pickupDistrict` | `string` | Required | - |
| `pickupCity` | `string` | Required | - |
| `pickupProv` | `string` | Required | - |
| `pickupCountry` | `string` | Required | - |
| `pickupPhone` | `string` | Required | - |
| `pickupContact` | `string` | Required | - |
| `pickupPassportId` | `string` | Required | - |
| `deliveryName` | `string` | Required | - |
| `deliveryAddress` | `string` | Required | - |
| `deliveryZip` | `string` | Required | - |
| `deliveryDistrict` | `string` | Required | - |
| `deliveryCity` | `string` | Required | - |
| `deliveryProv` | `string` | Required | - |
| `deliveryCountry` | `string` | Required | - |
| `deliveryPhone` | `string` | Required | - |
| `deliveryContact` | `string` | Required | destinatario della consegna, viene aggiornato dall'ePod<br>**Constraints**: *Maximum Length*: `45` |
| `deliveryPassportId` | `string` | Required | documento del destinatario della consegna, viene aggiornato dall'ePod<br>**Constraints**: *Maximum Length*: `45` |
| `remarks` | `string` | Required | note del pickup, possono essere modificate dall'ePod<br>**Constraints**: *Maximum Length*: `1024` |
| `internalRemarks` | `string` | Required | **Constraints**: *Maximum Length*: `1024` |
| `controlRemarks` | `string` | Required | **Constraints**: *Maximum Length*: `1024` |
| `expParcelNum` | `string` | Required | numero di collo previsti<br>**Constraints**: *Maximum Length*: `45` |
| `actParcelNum` | `string` | Required | numero di colli effettivi, aggiornato dall'ePod<br>**Constraints**: *Maximum Length*: `45` |
| `status` | `string` | Required | stato TBP = to be processed, P = processed, EXP = Exported<br>**Default**: `'TBP'` |
| `timeLastUpdate` | `string` | Required | datetime ultimo aggiornamento spedizione |
| `timeSchedulePickup` | `string` | Required | data di previsto pickup |
| `timeSchedulePickupT` | `string` | Required | ora prevista di pickup |
| `timeScheduleDelivery` | `string` | Required | data di prevista consegna |
| `timeScheduleDeliveryT` | `string` | Required | ora di prevista consegna |
| `timeActualPickup` | `string` | Required | Datetime effettivo di pickup, aggiornato dall'ePod |
| `timeActualDelivery` | `string` | Required | - |
| `actualContactName` | `string` | Required | come delivery contact da aggiornare insieme |
| `actualId` | `string` | Required | - |
| `customerRef` | `string` | Required | riferimenti<br>**Constraints**: *Maximum Length*: `45` |
| `house` | `string` | Required | **Constraints**: *Maximum Length*: `45` |
| `mawb` | `string` | Required | **Constraints**: *Maximum Length*: `45` |
| `manifest` | `string` | Required | manifest generato dal backend<br>**Constraints**: *Maximum Length*: `45` |
| `crewId` | `number` | Required | id dell'equipaggio (crew) a cui è assegnata la spedizione |
| `warehouseId` | `string` | Required | id del magazzino |
| `reason` | `string` | Required | - |
| `customerRequest` | `string` | Required | - |
| `signature` | `string` | Required | i della signature di pickup |
| `pickable` | `string` | Required | valore inserito se il pickup va a buon fine<br>**Constraints**: *Maximum Length*: `1` |
| `deliverable` | `string` | Required | valore inserito se la delivery va a buon fine<br>**Constraints**: *Maximum Length*: `1` |
| `isSynchro` | `string` | Required | - |
| `synchroDate` | `string` | Required | - |
| `deliveryReason` | `string` | Required | - |
| `deliveryCustomerRequest` | `string` | Required | - |
| `deliveryRemarks` | `string` | Required | valore modificabile dall'epod<br>**Constraints**: *Maximum Length*: `1024` |
| `deliverySignature` | `string` | Required | id firma di delivery |
| `cashOnDelivery` | `number` | Required | valore contrassegno |
| `incoterm` | `string` | Required | - |
| `cites` | `string` | Required | - |
| `atacarnet` | `string` | Required | - |
| `kimberly` | `string` | Required | - |
| `environment` | `number` | Required | environment ufficio es HKG = 1 |
| `updateWeight` | `string` | Required | flag utilizzato per aggiornamento lato server |
| `destAirport` | `string` | Required | - |
| `idAreaPickup` | `string` | Required | - |
| `idAreaDelivery` | `string` | Required | - |
| `orderTags` | `string` | Required | - |
| `bookingRef` | `string` | Required | codice spedizione in altro sistema es shipping order<br>**Constraints**: *Maximum Length*: `54` |
| `podExported` | `string` | Required | - |
| `pickupExported` | `string` | Required | - |
| `seal` | `string` | Required | sigilli presenti a sistema dovrebbero essere presenti anche nei dati dei colli<br>**Constraints**: *Maximum Length*: `255` |
| `cashOnDeliveryCur` | `string` | Required | - |
| `wrhHold` | `number` | Required | se fermo in magazzino |
| `prerefno` | `string` | Required | - |
| `consolidationId` | `string` | Required | - |
| `trackingExport` | `string` | Required | - |
| `exported` | `string` | Required | - |
| `pickupGuardRef` | `string` | Required | guardia che ha effettuato il pickup |
| `deliveryGuardRef` | `string` | Required | guardia che ha effettuato la delivery |
| `prExported` | `string` | Required | - |
| `fm3000PodExported` | `string` | Required | - |
| `fm3000PkExported` | `string` | Required | - |
| `airexpParcelUpdate` | `string` | Required | - |
| `as400Exp` | `string` | Required | - |
| `contact` | `string` | Required | - |
| `contact2` | `string` | Required | - |
| `attn` | `string` | Required | - |
| `attn2` | `string` | Required | - |
| `manifestTms` | `string` | Required | - |
| `truckp` | `string` | Required | - |
| `truckd` | `string` | Required | - |
| `timeScanIn` | `string` | Required | - |
| `deliveries` | `string` | Required | - |
| `deliveryPhone2` | `string` | Required | - |
| `declaredValue` | `string` | Required | - |
| `insuredValue` | `string` | Required | - |
| `hideshp` | `string` | Required | - |
| `hidecne` | `string` | Required | - |
| `hidesrv` | `string` | Required | - |
| `timeTruckOut` | `string` | Required | - |
| `deviceTruckOut` | `string` | Required | - |
| `returnStatus` | `string` | Required | - |
| `timestampReturnStatus` | `string` | Required | - |
| `reasonReturnStatus` | `string` | Required | - |
| `expReturnStatus` | `string` | Required | - |
| `deliverySmsAlert` | `string` | Required | - |
| `deliveryEmailAlert` | `string` | Required | - |
| `flowTag` | `string` | Required | - |
| `validationDatetime` | `string` | Required | - |
| `smsDeliveryCodeSent` | `string` | Required | - |
| `deliveryBarcodeScan` | `string` | Required | - |

## Example (as JSON)

```json
{
  "order_num": "HKGAE087622, \n210324374",
  "type": "P",
  "service_type": "IMPORT-AIRFREIGHT",
  "priority": 10,
  "customer_name": null,
  "customer_address": null,
  "customer_zip": null,
  "customer_city": null,
  "customer_prov": null,
  "customer_country": null,
  "customer_phone": null,
  "customer_contact": null,
  "customer_passport_id": null,
  "pickup_name": null,
  "pickup_address": null,
  "pickup_zip": null,
  "pickup_district": null,
  "pickup_city": null,
  "pickup_prov": null,
  "pickup_country": null,
  "pickup_phone": null,
  "pickup_contact": null,
  "pickup_passport_id": null,
  "delivery_name": null,
  "delivery_address": null,
  "delivery_zip": null,
  "delivery_district": null,
  "delivery_city": null,
  "delivery_prov": null,
  "delivery_country": null,
  "delivery_phone": null,
  "delivery_contact": null,
  "delivery_passport_id": null,
  "remarks": null,
  "internal_remarks": null,
  "control_remarks": null,
  "exp_parcel_num": null,
  "act_parcel_num": null,
  "status": "TBP",
  "time_last_update": "2020-03-26 17:35:20",
  "time_schedule_pickup": "2022-02-18 00:00:00",
  "time_schedule_pickup_t": "11:00,\nASAP",
  "time_schedule_delivery": "2022-02-18 00:00:00",
  "time_schedule_delivery_t": "10:00,\nASAP",
  "time_actual_pickup": "2022-02-01 16:56:23",
  "time_actual_delivery": "2022-02-01 16:56:23",
  "actual_contact_name": null,
  "actual_id": null,
  "customer_ref": null,
  "house": null,
  "mawb": null,
  "manifest": null,
  "crew_id": null,
  "warehouse_id": null,
  "reason": null,
  "customer_request": null,
  "signature": null,
  "pickable": "Y",
  "deliverable": "Y",
  "is_synchro": null,
  "synchro_date": null,
  "delivery_reason": null,
  "delivery_customer_request": null,
  "delivery_remarks": null,
  "delivery_signature": null,
  "cash_on_delivery": null,
  "incoterm": null,
  "cites": null,
  "atacarnet": null,
  "kimberly": null,
  "environment": 1,
  "update_weight": null,
  "dest_airport": null,
  "id_area_pickup": null,
  "id_area_delivery": null,
  "order_tags": null,
  "booking_ref": null,
  "pod_exported": null,
  "pickup_exported": null,
  "seal": null,
  "cash_on_delivery_cur": null,
  "wrh_hold": 1,
  "prerefno": null,
  "consolidation_id": null,
  "tracking_export": null,
  "exported": null,
  "pickup_guard_ref": null,
  "delivery_guard_ref": null,
  "pr_exported": null,
  "fm3000_pod_exported": null,
  "fm3000_pk_exported": null,
  "airexp_parcel_update": null,
  "as400_exp": null,
  "contact": null,
  "contact2": null,
  "attn": null,
  "attn2": null,
  "manifest_tms": null,
  "truckp": null,
  "truckd": null,
  "time_scan_in": null,
  "deliveries": null,
  "delivery_phone2": null,
  "declared_value": null,
  "insured_value": null,
  "hideshp": null,
  "hidecne": null,
  "hidesrv": null,
  "time_truck_out": null,
  "device_truck_out": null,
  "return_status": null,
  "timestamp_return_status": null,
  "reason_return_status": null,
  "exp_return_status": null,
  "delivery_sms_alert": null,
  "delivery_email_alert": null,
  "flow_tag": null,
  "validation_datetime": null,
  "sms_delivery_code_sent": null,
  "delivery_barcode_scan": null
}
```

