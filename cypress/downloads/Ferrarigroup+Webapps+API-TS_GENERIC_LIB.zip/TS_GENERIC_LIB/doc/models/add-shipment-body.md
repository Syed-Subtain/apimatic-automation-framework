
# Add Shipment Body

## Structure

`AddShipmentBody`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `shipment` | [`AddShipmentShipdata`](../../doc/models/add-shipment-shipdata.md) | Required | - |
| `parcels` | [`AddShipmentParceldata`](../../doc/models/add-shipment-parceldata.md) | Required | - |
| `guard` | `string` | Required | staff_if o se non valorizzato guard_id restituiti dalla login info |
| `truck` | `string` | Required | descrizione truck equipaggio restituito dalla login-info |
| `crewId` | `string` | Required | id dell'equipaggio |

## Example (as JSON)

```json
{
  "shipment": {
    "shipper-code": "shipper-code0",
    "consignee-code": "consignee-code6",
    "order_num": "order_num4",
    "seal": null,
    "time_actual_pickup": "time_actual_pickup0",
    "remarks": null,
    "reference": null
  },
  "parcels": {
    "seal": "seal0",
    "weight": null
  },
  "guard": "guard4",
  "truck": "truck8",
  "crew_id": "crew_id0"
}
```

