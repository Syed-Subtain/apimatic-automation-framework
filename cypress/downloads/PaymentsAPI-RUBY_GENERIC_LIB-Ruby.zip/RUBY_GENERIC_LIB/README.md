# Getting Started with PaymentsAPI

## Getting Started

### Introduction

API for sending and managing payments

### Building

The generated code depends on a few Ruby gems. The references to these gems are added in the gemspec file. The easiest way to resolve the dependencies, build the gem and install it is through Rake:

1. Install Rake if not already installed: `gem install rake`
2. Install Bundler if not already installed: `gem install bundler`
3. From terminal/cmd navigate to the root directory of the SDK.
4. Invoke: `rake install`

Alternatively, you can build and install the gem manually:

1. From terminal/cmd navigate to the root directory of the SDK.
2. Run the build command: `gem build payments.gemspec`
3. Run the install command: `gem install payments-1.0.2-beta.1.gem`

![Installing Gem](https://apidocs.io/illustration/ruby?workspaceFolder=Payments&gemVer=1.0.2-beta.1&gemName=payments&step=buildSDK)

### Installation

The following section explains how to use the payments ruby gem in a new Rails project using RubyMine&trade;. The basic workflow presented here is also applicable if you prefer using a different editor or IDE.

#### 1. Starting a new project

Close any existing projects in RubyMine&trade; by selecting `File -> Close Project`. Next, click on `Create New Project` to create a new project from scratch.

![Create a new project in RubyMine - Step 1](https://apidocs.io/illustration/ruby?workspaceFolder=Payments&step=createNewProject0)

Next, provide `TestApp` as the project name, choose `Rails Application` as the project type, and click `OK`.

![Create a new Rails Application in RubyMine - Step 2](https://apidocs.io/illustration/ruby?workspaceFolder=Payments&step=createNewProject1)

In the next dialog make sure that the correct Ruby SDK is being used (minimum 2.0.0) and click `OK`.

![Create a new Rails Application in RubyMine - Step 3](https://apidocs.io/illustration/ruby?workspaceFolder=Payments&step=createNewProject2)

#### 2. Add reference of the gem

In order to use the Tester gem in the new project we must add a gem reference. Locate the `Gemfile` in the Project Explorer window under the `TestApp` project node. The file contains references to all gems being used in the project. Here, add the reference to the library gem by adding the following line: `gem 'payments', '1.0.2-beta.1'`

![Add new reference to the Gemfile](https://apidocs.io/illustration/ruby?workspaceFolder=Payments&gemVer=1.0.2-beta.1&gemName=payments&step=addReference)

#### 3. Adding a new Rails Controller

Once the `TestApp` project is created, a folder named `controllers` will be visible in the *Project Explorer* under the following path: `TestApp > app > controllers`. Right click on this folder and select `New -> Run Rails Generator...`.

![Run Rails Generator on Controllers Folder](https://apidocs.io/illustration/ruby?workspaceFolder=Payments&gemVer=1.0.2-beta.1&gemName=payments&step=addCode0)

Selecting the said option will popup a small window where the generator names are displayed. Here, select the `controller` template.

![Create a new Controller](https://apidocs.io/illustration/ruby?workspaceFolder=Payments&step=addCode1)

Next, a popup window will ask you for a Controller name and included Actions. For controller name provide `Hello` and include an action named `Index` and click `OK`.

![Add a new Controller](https://apidocs.io/illustration/ruby?workspaceFolder=Payments&gemVer=1.0.2-beta.1&gemName=payments&step=addCode2)

A new controller class named `HelloController` will be created in a file named `hello_controller.rb` containing a method named `Index`. In this method, add code for initialization and a sample for its usage.

![Initialize the library](https://apidocs.io/illustration/ruby?workspaceFolder=Payments&gemName=payments&step=addCode3)

### Initialize the API Client

The following parameters are configurable for the API Client:

| Parameter | Type | Description |
|  --- | --- | --- |
| `bank_id` | `String` | Bank ID (ABA/Routing Number)<br>*Default*: `'123456789'` |
| `x_api_key` | `String` | API Key<br>*Default*: `'XXXCHANGETOAPIKEYXXX'` |
| `base_uri` | `String` | Domain Name<br>*Default*: `'api.example.local'` |
| `base_path` | `String` | URL Base Path<br>*Default*: `'v1'` |
| `environment` | Environment | The API environment. <br> **Default: `Environment.DEFAULT`** |
| `timeout` | `Float` | The value to use for connection timeout. <br> **Default: 60** |
| `max_retries` | `Integer` | The number of times to retry an endpoint call if it fails. <br> **Default: 0** |
| `retry_interval` | `Float` | Pause in seconds between retries. <br> **Default: 1** |
| `backoff_factor` | `Float` | The amount to multiply each successive retry's interval amount by in order to provide backoff. <br> **Default: 1** |

The API client can be initialized as follows:

```ruby
client = Payments::Client.new(
  bank_id: '123456789',
  x_api_key: 'XXXCHANGETOAPIKEYXXX',
  environment: Environment::DEFAULT,
  base_uri: 'api.example.local',
  base_path: 'v1',
)
```

### Authorization

This API uses `Custom Header Signature`.

### API Errors

Here is the list of errors that the API might throw.

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Error in Request | [`RequestErrorException`](#request-error) |
| 403 | Forbidden | [`AccessDeniedErrorException`](#access-denied-error) |
| 500 | System Error | [`SystemErrorException`](#system-error) |

## Client Class Documentation

### PaymentsAPI Client

The gateway for the SDK. This class acts as a factory for the Controllers and also holds the configuration of the SDK.

### Controllers

| Name | Description |
|  --- | --- |
| payments | Gets PaymentsController |

## API Reference

### List of APIs

* [Payments](#payments)

### Payments

#### Overview

Payments

##### Get instance

An instance of the `PaymentsController` class can be accessed from the API Client.

```
payments_controller = client.payments
```

#### Approve Payment

Approves a Payment to be sent

```ruby
def approve_payment(payment_id)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `payment_id` | `Integer` | Template, Required | ID of payment to approve |

##### Server

`Server::DEFAULT`

##### Response Type

`void`

##### Example Usage

```ruby
payment_id = 123456

result = payments_controller.approve_payment(payment_id)
```

#### Cancel Payment

Attempts to cancel a Payment. Does not automatically cancel the linked Quote.

```ruby
def cancel_payment(payment_id)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `payment_id` | `Integer` | Template, Required | ID of payment to cancel |

##### Server

`Server::DEFAULT`

##### Response Type

`void`

##### Example Usage

```ruby
payment_id = 123456

result = payments_controller.cancel_payment(payment_id)
```

#### Cancel Quote

Attempts to cancel a Quote

```ruby
def cancel_quote(quote_id)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `quote_id` | `Integer` | Template, Required | ID of quote to refresh |

##### Server

`Server::DEFAULT`

##### Response Type

`void`

##### Example Usage

```ruby
quote_id = 123456

result = payments_controller.cancel_quote(quote_id)
```

#### Create Payment

Creates a new Payment

```ruby
def create_payment(payment)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `payment` | [`PaymentData`](#payment-data) | Body, Required | Create Payment Body Data |

##### Server

`Server::DEFAULT`

##### Response Type

[`Payment`](#payment)

##### Example Usage

```ruby
payment = PaymentData.new
payment.quote_id = 123456
payment.originator = Originator.new
payment.originator.name = 'Jake Johnson'
payment.originator.address = Address.new
payment.originator.address.address1 = '555 South North Lane'
payment.originator.address.address2 = 'Floor 5'
payment.originator.address.city = 'Springfield'
payment.originator.address.state = 'VA'
payment.originator.address.postal_code = '47060'
payment.originator.address.country = 'US'
payment.originator_bank_account = BankAccount.new
payment.originator_bank_account.account_number = 'DE89370400440532013000'
payment.originator_bank_account.bank = Bank.new
payment.originator_bank_account.bank.routing_code = 'string'
payment.originator_bank_account.bank.swift_code = 'AGCAAM22'
payment.originator_bank_account.bank.name = 'Bank of America'
payment.originator_bank_account.bank.address = Address.new
payment.originator_bank_account.bank.address.address1 = '555 South North Lane'
payment.originator_bank_account.bank.address.address2 = 'Floor 5'
payment.originator_bank_account.bank.address.city = 'Springfield'
payment.originator_bank_account.bank.address.state = 'VA'
payment.originator_bank_account.bank.address.postal_code = '47060'
payment.originator_bank_account.bank.address.country = 'US'
payment.beneficiary = Beneficiary.new
payment.beneficiary.email = 'beneficiary@example.com'
payment.beneficiary.phone_number = '111-111-1111'
payment.beneficiary.name = 'Jake Johnson'
payment.beneficiary.address = Address.new
payment.beneficiary.address.address1 = '555 South North Lane'
payment.beneficiary.address.address2 = 'Floor 5'
payment.beneficiary.address.city = 'Springfield'
payment.beneficiary.address.state = 'VA'
payment.beneficiary.address.postal_code = '47060'
payment.beneficiary.address.country = 'US'
payment.beneficiary_bank_account = BankAccount.new
payment.beneficiary_bank_account.account_number = 'DE89370400440532013000'
payment.beneficiary_bank_account.bank = Bank.new
payment.beneficiary_bank_account.bank.routing_code = 'string'
payment.beneficiary_bank_account.bank.swift_code = 'AGCAAM22'
payment.beneficiary_bank_account.bank.name = 'Bank of America'
payment.beneficiary_bank_account.bank.address = Address.new
payment.beneficiary_bank_account.bank.address.address1 = '555 South North Lane'
payment.beneficiary_bank_account.bank.address.address2 = 'Floor 5'
payment.beneficiary_bank_account.bank.address.city = 'Springfield'
payment.beneficiary_bank_account.bank.address.state = 'VA'
payment.beneficiary_bank_account.bank.address.postal_code = '47060'
payment.beneficiary_bank_account.bank.address.country = 'US'
payment.intermediary_bank_account = BankAccount.new
payment.intermediary_bank_account.account_number = 'DE89370400440532013000'
payment.intermediary_bank_account.bank = Bank.new
payment.intermediary_bank_account.bank.routing_code = 'string'
payment.intermediary_bank_account.bank.swift_code = 'AGCAAM22'
payment.intermediary_bank_account.bank.name = 'Bank of America'
payment.intermediary_bank_account.bank.address = Address.new
payment.intermediary_bank_account.bank.address.address1 = '555 South North Lane'
payment.intermediary_bank_account.bank.address.address2 = 'Floor 5'
payment.intermediary_bank_account.bank.address.city = 'Springfield'
payment.intermediary_bank_account.bank.address.state = 'VA'
payment.intermediary_bank_account.bank.address.postal_code = '47060'
payment.intermediary_bank_account.bank.address.country = 'US'
payment.details = PaymentDetails.new
payment.details.payment_reference = '1234567890'
payment.details.purpose_of_payment = 'Purchase of Goods'
payment.details.memo = 'Invoice 12345678'

result = payments_controller.create_payment(payment)
```

##### Example Response *(as JSON)*

```json
{
  "id": 987654,
  "quoteId": 123456,
  "originator": {
    "name": "Jake Johnson",
    "address": {
      "address1": "555 South North Lane",
      "address2": "Floor 5",
      "city": "Springfield",
      "state": "VA",
      "postalCode": "47060",
      "country": "US"
    }
  },
  "originatorBankAccount": {
    "accountNumber": "DE89370400440532013000",
    "bank": {
      "name": "Bank of America",
      "address": {
        "address1": "555 South North Lane",
        "address2": "Floor 5",
        "city": "Springfield",
        "state": "VA",
        "postalCode": "47060",
        "country": "US"
      },
      "routingCode": "string",
      "swiftCode": "AGCAAM22"
    }
  },
  "beneficiary": {
    "name": "Jake Johnson",
    "address": {
      "address1": "555 South North Lane",
      "address2": "Floor 5",
      "city": "Springfield",
      "state": "VA",
      "postalCode": "47060",
      "country": "US"
    },
    "email": "beneficiary@example.com",
    "phoneNumber": "111-111-1111"
  },
  "beneficiaryBankAccount": {
    "accountNumber": "DE89370400440532013000",
    "bank": {
      "name": "Bank of America",
      "address": {
        "address1": "555 South North Lane",
        "address2": "Floor 5",
        "city": "Springfield",
        "state": "VA",
        "postalCode": "47060",
        "country": "US"
      },
      "routingCode": "string",
      "swiftCode": "AGCAAM22"
    }
  },
  "intermediaryBankAccount": {
    "accountNumber": "DE89370400440532013000",
    "bank": {
      "name": "Bank of America",
      "address": {
        "address1": "555 South North Lane",
        "address2": "Floor 5",
        "city": "Springfield",
        "state": "VA",
        "postalCode": "47060",
        "country": "US"
      },
      "routingCode": "string",
      "swiftCode": "AGCAAM22"
    }
  },
  "details": {
    "purposeOfPayment": "Purchase of Goods",
    "memo": "Invoice 12345678",
    "paymentReference": "1234567890"
  },
  "status": {
    "approved": false,
    "sent": false
  }
}
```

#### Create Quote

Create new Quote

```ruby
def create_quote(quote)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `quote` | [`QuoteData`](#quote-data) | Body, Required | Quote data |

##### Server

`Server::DEFAULT`

##### Response Type

[`Quote`](#quote)

##### Example Usage

```ruby
quote = QuoteData.new
quote.beneficiary_amount = 12345.67
quote.beneficiary_currency = 'EUR'

result = payments_controller.create_quote(quote)
```

##### Example Response *(as JSON)*

```json
{
  "id": 0,
  "beneficiaryAmount": 12345.67,
  "beneficiaryCurrency": "EUR",
  "originatorAmount": 76543.21,
  "originatorAmountIsFixed": true,
  "exchangeRate": 1.2345,
  "locked": false,
  "revision": 1
}
```

#### Get Quote Cancel Info

```ruby
def get_quote_cancel_info(quote_id)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `quote_id` | `Integer` | Template, Required | Quote ID |

##### Response Type

[`QuoteCancelInfo`](#quote-cancel-info)

##### Example Usage

```ruby
quote_id = 123456

result = payments_controller.get_quote_cancel_info(quote_id)
```

#### Lock Quote

Lock the rate for a given Quote

```ruby
def lock_quote(quote_id)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `quote_id` | `Integer` | Template, Required | ID of quote to lock |

##### Server

`Server::DEFAULT`

##### Response Type

[`Quote`](#quote)

##### Example Usage

```ruby
quote_id = 123456

result = payments_controller.lock_quote(quote_id)
```

##### Example Response *(as JSON)*

```json
{
  "id": 0,
  "beneficiaryAmount": 12345.67,
  "beneficiaryCurrency": "EUR",
  "originatorAmount": 76543.21,
  "originatorAmountIsFixed": true,
  "exchangeRate": 1.2345,
  "valueDate": "2021-03-01",
  "locked": false,
  "revision": 1
}
```

#### Refresh Quote

Refresh the rates for an existing Quote

```ruby
def refresh_quote(quote_id)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `quote_id` | `Integer` | Template, Required | ID of quote to refresh |

##### Server

`Server::DEFAULT`

##### Response Type

[`Quote`](#quote)

##### Example Usage

```ruby
quote_id = 123456

result = payments_controller.refresh_quote(quote_id)
```

##### Example Response *(as JSON)*

```json
{
  "id": 0,
  "beneficiaryAmount": 12345.67,
  "beneficiaryCurrency": "EUR",
  "originatorAmount": 76543.21,
  "originatorAmountIsFixed": true,
  "exchangeRate": 1.2345,
  "valueDate": "2021-03-01",
  "locked": false,
  "revision": 1
}
```

#### Update Payment

Update the data for a Payment before it is approved or sent

```ruby
def update_payment(payment_id,
                   payment)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `payment_id` | `Integer` | Template, Required | ID of payment to update |
| `payment` | [`PaymentData`](#payment-data) | Body, Required | Update Payment Body Data |

##### Server

`Server::DEFAULT`

##### Response Type

[`Payment`](#payment)

##### Example Usage

```ruby
payment_id = 123456
payment = PaymentData.new
payment.quote_id = 123456
payment.originator = Originator.new
payment.originator.name = 'Jake Johnson'
payment.originator.address = Address.new
payment.originator.address.address1 = '555 South North Lane'
payment.originator.address.address2 = 'Floor 5'
payment.originator.address.city = 'Springfield'
payment.originator.address.state = 'VA'
payment.originator.address.postal_code = '47060'
payment.originator.address.country = 'US'
payment.originator_bank_account = BankAccount.new
payment.originator_bank_account.account_number = 'DE89370400440532013000'
payment.originator_bank_account.bank = Bank.new
payment.originator_bank_account.bank.routing_code = 'string'
payment.originator_bank_account.bank.swift_code = 'AGCAAM22'
payment.originator_bank_account.bank.name = 'Bank of America'
payment.originator_bank_account.bank.address = Address.new
payment.originator_bank_account.bank.address.address1 = '555 South North Lane'
payment.originator_bank_account.bank.address.address2 = 'Floor 5'
payment.originator_bank_account.bank.address.city = 'Springfield'
payment.originator_bank_account.bank.address.state = 'VA'
payment.originator_bank_account.bank.address.postal_code = '47060'
payment.originator_bank_account.bank.address.country = 'US'
payment.beneficiary = Beneficiary.new
payment.beneficiary.email = 'beneficiary@example.com'
payment.beneficiary.phone_number = '111-111-1111'
payment.beneficiary.name = 'Jake Johnson'
payment.beneficiary.address = Address.new
payment.beneficiary.address.address1 = '555 South North Lane'
payment.beneficiary.address.address2 = 'Floor 5'
payment.beneficiary.address.city = 'Springfield'
payment.beneficiary.address.state = 'VA'
payment.beneficiary.address.postal_code = '47060'
payment.beneficiary.address.country = 'US'
payment.beneficiary_bank_account = BankAccount.new
payment.beneficiary_bank_account.account_number = 'DE89370400440532013000'
payment.beneficiary_bank_account.bank = Bank.new
payment.beneficiary_bank_account.bank.routing_code = 'string'
payment.beneficiary_bank_account.bank.swift_code = 'AGCAAM22'
payment.beneficiary_bank_account.bank.name = 'Bank of America'
payment.beneficiary_bank_account.bank.address = Address.new
payment.beneficiary_bank_account.bank.address.address1 = '555 South North Lane'
payment.beneficiary_bank_account.bank.address.address2 = 'Floor 5'
payment.beneficiary_bank_account.bank.address.city = 'Springfield'
payment.beneficiary_bank_account.bank.address.state = 'VA'
payment.beneficiary_bank_account.bank.address.postal_code = '47060'
payment.beneficiary_bank_account.bank.address.country = 'US'
payment.intermediary_bank_account = BankAccount.new
payment.intermediary_bank_account.account_number = 'DE89370400440532013000'
payment.intermediary_bank_account.bank = Bank.new
payment.intermediary_bank_account.bank.routing_code = 'string'
payment.intermediary_bank_account.bank.swift_code = 'AGCAAM22'
payment.intermediary_bank_account.bank.name = 'Bank of America'
payment.intermediary_bank_account.bank.address = Address.new
payment.intermediary_bank_account.bank.address.address1 = '555 South North Lane'
payment.intermediary_bank_account.bank.address.address2 = 'Floor 5'
payment.intermediary_bank_account.bank.address.city = 'Springfield'
payment.intermediary_bank_account.bank.address.state = 'VA'
payment.intermediary_bank_account.bank.address.postal_code = '47060'
payment.intermediary_bank_account.bank.address.country = 'US'
payment.details = PaymentDetails.new
payment.details.payment_reference = '1234567890'
payment.details.purpose_of_payment = 'Purchase of Goods'
payment.details.memo = 'Invoice 12345678'

result = payments_controller.update_payment(payment_id, payment)
```

##### Example Response *(as JSON)*

```json
{
  "id": 987654,
  "quoteId": 123456,
  "originator": {
    "name": "Jake Johnson",
    "address": {
      "address1": "555 South North Lane",
      "address2": "Floor 5",
      "city": "Springfield",
      "state": "VA",
      "postalCode": "47060",
      "country": "US"
    }
  },
  "originatorBankAccount": {
    "accountNumber": "DE89370400440532013000",
    "bank": {
      "name": "Bank of America",
      "address": {
        "address1": "555 South North Lane",
        "address2": "Floor 5",
        "city": "Springfield",
        "state": "VA",
        "postalCode": "47060",
        "country": "US"
      },
      "routingCode": "string",
      "swiftCode": "AGCAAM22"
    }
  },
  "beneficiary": {
    "name": "Jake Johnson",
    "address": {
      "address1": "555 South North Lane",
      "address2": "Floor 5",
      "city": "Springfield",
      "state": "VA",
      "postalCode": "47060",
      "country": "US"
    },
    "email": "beneficiary@example.com",
    "phoneNumber": "111-111-1111"
  },
  "beneficiaryBankAccount": {
    "accountNumber": "DE89370400440532013000",
    "bank": {
      "name": "Bank of America",
      "address": {
        "address1": "555 South North Lane",
        "address2": "Floor 5",
        "city": "Springfield",
        "state": "VA",
        "postalCode": "47060",
        "country": "US"
      },
      "routingCode": "string",
      "swiftCode": "AGCAAM22"
    }
  },
  "intermediaryBankAccount": {
    "accountNumber": "DE89370400440532013000",
    "bank": {
      "name": "Bank of America",
      "address": {
        "address1": "555 South North Lane",
        "address2": "Floor 5",
        "city": "Springfield",
        "state": "VA",
        "postalCode": "47060",
        "country": "US"
      },
      "routingCode": "string",
      "swiftCode": "AGCAAM22"
    }
  },
  "details": {
    "purposeOfPayment": "Purchase of Goods",
    "memo": "Invoice 12345678",
    "paymentReference": "1234567890"
  },
  "status": {
    "approved": false,
    "sent": false
  }
}
```

#### Validate Iban

Validates an IBAN and returns the bank account information

```ruby
def validate_iban(iban)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `iban` | `String` | Query, Required | Currency that is required by the client, sell foreign currency in exchange for local currency<br>**Constraints**: *Minimum Length*: `10`, *Maximum Length*: `35` |

##### Server

`Server::DEFAULT`

##### Response Type

[`BankAccount`](#bank-account)

##### Example Usage

```ruby
iban = 'DE89370400440532013000'

result = payments_controller.validate_iban(iban)
```

##### Example Response *(as JSON)*

```json
{
  "accountNumber": "DE89370400440532013000",
  "bank": {
    "name": "Bank of America",
    "address": {
      "address1": "555 South North Lane",
      "address2": "Floor 5",
      "city": "Springfield",
      "state": "VA",
      "postalCode": "47060",
      "country": "US"
    },
    "routingCode": "string",
    "swiftCode": "AGCAAM22"
  }
}
```

## Model Reference

### Structures

* [Address](#address)
* [Bank](#bank)
* [Bank Account](#bank-account)
* [Beneficiary](#beneficiary)
* [Entity](#entity)
* [Originator](#originator)
* [Payment](#payment)
* [Payment Data](#payment-data)
* [Payment Details](#payment-details)
* [Payment Status](#payment-status)
* [Quote](#quote)
* [Quote Cancel Info](#quote-cancel-info)
* [Quote Data](#quote-data)
* [Quote Details](#quote-details)

#### Address

Address Information

##### Class Name

`Address`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `address_1` | `String` | Required | Address Line 1<br>**Constraints**: *Maximum Length*: `35` |
| `address_2` | `String` | Optional | Address Line 2<br>**Constraints**: *Maximum Length*: `35` |
| `address_3` | `String` | Optional | Address Line 3. Note - Only address3 or (city, state, postalCode) is allowed. Please contact support to configure your account for your desired address formatting.<br>**Constraints**: *Maximum Length*: `35` |
| `city` | `String` | Optional | City<br>**Constraints**: *Maximum Length*: `35` |
| `state` | `String` | Optional | State / Province<br>**Constraints**: *Maximum Length*: `60` |
| `postal_code` | `String` | Optional | Postal Code<br>**Constraints**: *Maximum Length*: `12` |
| `country` | `String` | Required | Country (ISO 3166-1 Alpha-2 Code)<br>**Constraints**: *Minimum Length*: `2`, *Maximum Length*: `2`, *Pattern*: `^[A-Z]{2}$` |

##### Example (as JSON)

```json
{
  "address1": "555 South North Lane",
  "address2": "Floor 5",
  "city": "Springfield",
  "state": "VA",
  "postalCode": "47060",
  "country": "US"
}
```

#### Bank

Bank Information Object

##### Class Name

`Bank`

##### Inherits From

[`Entity`](#entity)

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `routing_code` | `String` | Optional | Country Specific Routing Code (e.g. IFSC code for India). When using for USD wires, please only provide SWIFT code OR routing code (not both)<br>**Constraints**: *Maximum Length*: `35` |
| `swift_code` | `String` | Optional | SWIFT BIC. Required for international wires<br>**Constraints**: *Minimum Length*: `8`, *Maximum Length*: `11`, *Pattern*: `^[A-Za-z0-9]{4}[A-Za-z]{2}[A-Za-z0-9]{2}([A-Za-z0-9]{3})?$` |

##### Example (as JSON)

```json
{
  "name": "Bank of America",
  "address": {
    "address1": "555 South North Lane",
    "address2": "Floor 5",
    "city": "Springfield",
    "state": "VA",
    "postalCode": "47060",
    "country": "US"
  },
  "swiftCode": "AGCAAM22"
}
```

#### Bank Account

Bank Account Information Object.**NOTE** - originatorBankAccount bank data should not be provided when creating a new Payment. This information is retrieved from the database based on the provided bank ID.**NOTE** - bank object is required for all BankAccount objects except originatorBankAccount

##### Class Name

`BankAccount`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `account_number` | `String` | Optional | Bank Account Number / IBAN. Required for Beneficiary Bank. Optional for Intermediary Bank.<br>**Constraints**: *Maximum Length*: `35` |
| `bank` | [`Bank`](#bank) | Optional | Bank Information Object - Required for all banks except Originator |

##### Example (as JSON)

```json
{
  "accountNumber": "DE89370400440532013000",
  "bank": {
    "name": "Bank of America",
    "address": {
      "address1": "555 South North Lane",
      "address2": "Floor 5",
      "city": "Springfield",
      "state": "VA",
      "postalCode": "47060",
      "country": "US"
    },
    "routingCode": "123456789",
    "swiftCode": "AGCAAM22"
  }
}
```

#### Beneficiary

Beneficiary Information Object

##### Class Name

`Beneficiary`

##### Inherits From

[`Entity`](#entity)

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `email` | `String` | Optional | Beneficiary Email Address<br>**Constraints**: *Maximum Length*: `80` |
| `phone_number` | `String` | Optional | Beneficiary Phone Number<br>**Constraints**: *Maximum Length*: `35` |
| `type` | [`EntityTypeEnum`](#entity-type) | Optional | Type - individual or company |

##### Example (as JSON)

```json
{
  "name": "Jake Johnson",
  "address": {
    "address1": "555 South North Lane",
    "address2": "Floor 5",
    "city": "Springfield",
    "state": "VA",
    "postalCode": "47060",
    "country": "US"
  },
  "email": "beneficiary@example.com",
  "phoneNumber": "111-111-1111",
  "type": "individual"
}
```

#### Entity

Entity Information Object - base type for Beneficiary, Originator, and Bank

##### Class Name

`Entity`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `name` | `String` | Required | Entity Name<br>**Constraints**: *Maximum Length*: `80` |
| `address` | [`Address`](#address) | Required | Address Information |

##### Example (as JSON)

```json
{
  "name": "Jake Johnson",
  "address": {
    "address1": "555 South North Lane",
    "address2": "Floor 5",
    "city": "Springfield",
    "state": "VA",
    "postalCode": "47060",
    "country": "US"
  }
}
```

#### Originator

Originator Object

##### Class Name

`Originator`

##### Inherits From

[`Entity`](#entity)

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `type` | [`EntityTypeEnum`](#entity-type) | Optional | Type - individual or company |

##### Example (as JSON)

```json
{
  "name": "Jake Johnson",
  "address": {
    "address1": "555 South North Lane",
    "address2": "Floor 5",
    "city": "Springfield",
    "state": "VA",
    "postalCode": "47060",
    "country": "US"
  },
  "type": "individual"
}
```

#### Payment

Payment Model

##### Class Name

`Payment`

##### Inherits From

[`PaymentData`](#payment-data)

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `Integer` | Required, Constant | Payment ID |
| `status` | [`PaymentStatus`](#payment-status) | Required, Constant | Payment Status |

##### Example (as JSON)

```json
{
  "id": 987654,
  "quoteId": 123456,
  "originator": {
    "name": "Jake Johnson",
    "address": {
      "address1": "555 South North Lane",
      "address2": "Floor 5",
      "city": "Springfield",
      "state": "VA",
      "postalCode": "47060",
      "country": "US"
    }
  },
  "originatorBankAccount": {
    "accountNumber": "DE89370400440532013000",
    "bank": {
      "name": "Bank of America",
      "address": {
        "address1": "555 South North Lane",
        "address2": "Floor 5",
        "city": "Springfield",
        "state": "VA",
        "postalCode": "47060",
        "country": "US"
      },
      "routingCode": "string",
      "swiftCode": "AGCAAM22"
    }
  },
  "beneficiary": {
    "name": "Jake Johnson",
    "address": {
      "address1": "555 South North Lane",
      "address2": "Floor 5",
      "city": "Springfield",
      "state": "VA",
      "postalCode": "47060",
      "country": "US"
    },
    "email": "beneficiary@example.com",
    "phoneNumber": "111-111-1111"
  },
  "beneficiaryBankAccount": {
    "accountNumber": "DE89370400440532013000",
    "bank": {
      "name": "Bank of America",
      "address": {
        "address1": "555 South North Lane",
        "address2": "Floor 5",
        "city": "Springfield",
        "state": "VA",
        "postalCode": "47060",
        "country": "US"
      },
      "routingCode": "string",
      "swiftCode": "AGCAAM22"
    }
  },
  "intermediaryBankAccount": {
    "accountNumber": "DE89370400440532013000",
    "bank": {
      "name": "Bank of America",
      "address": {
        "address1": "555 South North Lane",
        "address2": "Floor 5",
        "city": "Springfield",
        "state": "VA",
        "postalCode": "47060",
        "country": "US"
      },
      "routingCode": "string",
      "swiftCode": "AGCAAM22"
    }
  },
  "details": {
    "purposeOfPayment": "Purchase of Goods",
    "memo": "Invoice 12345678",
    "paymentReference": "1234567890"
  },
  "status": {
    "approved": false,
    "sent": false
  }
}
```

#### Payment Data

Payment Data Information Object

##### Class Name

`PaymentData`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `quote_id` | `Integer` | Required | Quote ID |
| `originator` | [`Originator`](#originator) | Required | Originator Information Object |
| `originator_bank_account` | [`BankAccount`](#bank-account) | Optional | Originator Bank Account. Note - originatorBankAccount.accountNumber is the only required field. Name and address information is retrieved from the database |
| `beneficiary` | [`Beneficiary`](#beneficiary) | Required | Beneficiary Information Object |
| `beneficiary_bank_account` | [`BankAccount`](#bank-account) | Optional | Beneficiary Bank Account Object |
| `intermediary_bank_account` | [`BankAccount`](#bank-account) | Optional | Intermediary Bank Account Object |
| `details` | [`PaymentDetails`](#payment-details) | Required | Payment Information Data |

##### Example (as JSON)

```json
{
  "quoteId": 123456,
  "originator": {
    "name": "Jake Johnson",
    "address": {
      "address1": "555 South North Lane",
      "address2": "Floor 5",
      "city": "Springfield",
      "state": "VA",
      "postalCode": "47060",
      "country": "US"
    }
  },
  "originatorBankAccount": {
    "accountNumber": "DE89370400440532013000",
    "bank": {
      "name": "Bank of America",
      "address": {
        "address1": "555 South North Lane",
        "address2": "Floor 5",
        "city": "Springfield",
        "state": "VA",
        "postalCode": "47060",
        "country": "US"
      },
      "routingCode": "string",
      "swiftCode": "AGCAAM22"
    }
  },
  "beneficiary": {
    "name": "Jake Johnson",
    "address": {
      "address1": "555 South North Lane",
      "address2": "Floor 5",
      "city": "Springfield",
      "state": "VA",
      "postalCode": "47060",
      "country": "US"
    },
    "email": "beneficiary@example.com",
    "phoneNumber": "111-111-1111"
  },
  "beneficiaryBankAccount": {
    "accountNumber": "DE89370400440532013000",
    "bank": {
      "name": "Bank of America",
      "address": {
        "address1": "555 South North Lane",
        "address2": "Floor 5",
        "city": "Springfield",
        "state": "VA",
        "postalCode": "47060",
        "country": "US"
      },
      "routingCode": "string",
      "swiftCode": "AGCAAM22"
    }
  },
  "intermediaryBankAccount": {
    "accountNumber": "DE89370400440532013000",
    "bank": {
      "name": "Bank of America",
      "address": {
        "address1": "555 South North Lane",
        "address2": "Floor 5",
        "city": "Springfield",
        "state": "VA",
        "postalCode": "47060",
        "country": "US"
      },
      "routingCode": "string",
      "swiftCode": "AGCAAM22"
    }
  },
  "details": {
    "purposeOfPayment": "Purchase of Goods",
    "memo": "Invoice 12345678",
    "paymentReference": "1234567890"
  }
}
```

#### Payment Details

Payment Information Data

##### Class Name

`PaymentDetails`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `payment_reference` | `String` | Optional | Payment Reference Information<br>**Constraints**: *Maximum Length*: `140` |
| `purpose_of_payment` | `String` | Required | Purpose of payment<br>**Constraints**: *Maximum Length*: `140` |
| `reg_e` | `Boolean` | Optional | Set to true if this is a Reg E Payment |
| `memo` | `String` | Optional | Deprecated - DO NOT USE<br>**Constraints**: *Maximum Length*: `140` |

##### Example (as JSON)

```json
{
  "paymentReference": "1234567890",
  "purposeOfPayment": "Other"
}
```

#### Payment Status

Payment Information Data

##### Class Name

`PaymentStatus`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `approved` | `Boolean` | Required, Constant | Set to true once the payment has been approved |
| `sent` | `Boolean` | Required, Constant | Set to true once the payment has been sent |

##### Example (as JSON)

```json
{
  "approved": false,
  "sent": false
}
```

#### Quote

Quote Information Object

##### Class Name

`Quote`

##### Inherits From

[`QuoteData`](#quote-data)

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `Integer` | Required, Constant | Quote ID |
| `originator_amount_is_fixed` | `Boolean` | Required, Constant | If true, then the originator amount is fixed to the provided value. If false, then the beneficiary amount is fixed to the provided value. This field is automatically set based on whether the originator or beneficary amount was provided. |
| `exchange_rate` | `Float` | Required, Constant | The exchange rate for the quote |
| `value_date` | `Date` | Optional, Constant | Value Date - full-date notation as defined by RFC 3339, section 5.6 |
| `locked` | `Boolean` | Required, Constant | Set to true if the quote rate is locked |
| `revision` | `Integer` | Required, Constant | Quote revision number. This is automatically incremented each time the quote is refreshed or updated, and starts from 1 |

##### Example (as JSON)

```json
{
  "id": 0,
  "beneficiaryAmount": 12345.67,
  "beneficiaryCurrency": "EUR",
  "originatorAmount": 76543.21,
  "originatorAmountIsFixed": true,
  "exchangeRate": 1.2345,
  "valueDate": "2021-03-01",
  "locked": false,
  "revision": 1
}
```

#### Quote Cancel Info

Cancellation information for a quote prior to being cancelled

##### Class Name

`QuoteCancelInfo`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `quote_id` | `Integer` | Required, Constant | Quote ID |
| `chargeback_amount` | `Float` | Optional, Constant | Chargeback amount if quote is cancelled. Currently always returns null |
| `message` | `String` | Required, Constant | Message regarding the cancellation information |
| `expiration` | `DateTime` | Optional, Constant | Expiration time this cancellation information object is valid until. Currently always returns null |

##### Example (as JSON)

```json
{
  "quoteId": 123456,
  "message": "Unable to cancel a quote attached to a sent payment."
}
```

#### Quote Data

Quote Information Object for quote requests

##### Class Name

`QuoteData`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `beneficiary_amount` | `Float` | Optional | Amount to send in beneficiary currency. Not required if originatorAmount is provided. |
| `beneficiary_currency` | `String` | Required | Beneficiary currency code in ISO 4217 format<br>**Constraints**: *Minimum Length*: `3`, *Maximum Length*: `3`, *Pattern*: `^[A-Z]{3}$` |
| `originator_amount` | `Float` | Optional | Amount to send in originator currency. Not required if beneficiaryAmount is provided |
| `details` | [`QuoteDetails`](#quote-details) | Optional | Quote details |

##### Example (as JSON)

```json
{
  "beneficiaryAmount": 12345.67,
  "beneficiaryCurrency": "EUR"
}
```

#### Quote Details

Quote Details for quote requests

##### Class Name

`QuoteDetails`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `country` | `String` | Required | Country (ISO 3166-1 Alpha-2 Code) for beneficiary bank<br>**Constraints**: *Minimum Length*: `2`, *Maximum Length*: `2`, *Pattern*: `^[A-Z]{2}$` |
| `originator` | [`Originator`](#originator) | Required | Originator Information |
| `beneficiary` | [`Beneficiary`](#beneficiary) | Required | Beneficiary Information |

##### Example (as JSON)

```json
{
  "country": "US",
  "originator": {
    "name": "Jake Johnson",
    "address": {
      "address1": "555 South North Lane",
      "address2": "Floor 5",
      "city": "Springfield",
      "state": "VA",
      "postalCode": "47060",
      "country": "US"
    },
    "type": "individual"
  },
  "beneficiary": {
    "name": "Jake Johnson",
    "address": {
      "address1": "555 South North Lane",
      "address2": "Floor 5",
      "city": "Springfield",
      "state": "VA",
      "postalCode": "47060",
      "country": "US"
    },
    "email": "beneficiary@example.com",
    "phoneNumber": "111-111-1111",
    "type": "individual"
  }
}
```

### Enumerations

* [Entity Type](#entity-type)

#### Entity Type

Available Entity Types

##### Class Name

`EntityTypeEnum`

##### Fields

| Name | Description |
|  --- | --- |
| `INDIVIDUAL` | Individual |
| `COMPANY` | Company |

### Exceptions

* [Access Denied Error](#access-denied-error)
* [Request Error](#request-error)
* [System Error](#system-error)

#### Access Denied Error

Error for Access Denied Exceptions

##### Class Name

`AccessDeniedErrorException`

##### Fields

|  |
| 

##### Example (as JSON)

```json
{}
```

#### Request Error

Format for 400 Errors

##### Class Name

`RequestErrorException`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `message` | `String` | Optional | Message indicating the source of the error in the request |

##### Example (as JSON)

```json
{
  "message": "Error occured while performing field validation"
}
```

#### System Error

##### Class Name

`SystemErrorException`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `message` | `String` | Optional | Message indicating the source of the error in the request |

##### Example (as JSON)

```json
{
  "message": "Error occured while performing field validation"
}
```

## Utility Classes Documentation

### ApiHelper Class

API utility class.

### Methods

| Name | Return Type | Description |
|  --- | --- | --- |
| json_deserialize | Hash | Deserializes a JSON string to a Ruby Hash. |
| rfc3339 | DateTime | Safely converts a string into an RFC3339 DateTime object. |

## Common Code Documentation

### HttpResponse

Http response received.

#### Properties

| Name | Type | Description |
|  --- | --- | --- |
| status_code | Integer | The status code returned by the server. |
| reason_phrase | String | The reason phrase returned by the server. |
| headers | Hash | Response headers. |
| raw_body | String | Response body. |
| request | HttpRequest | The request that resulted in this response. |

### HttpRequest

Represents a single Http Request.

#### Properties

| Name | Type | Tag | Description |
|  --- | --- | --- | --- |
| http_method | HttpMethodEnum |  | The HTTP method of the request. |
| query_url | String |  | The endpoint URL for the API request. |
| headers | Hash | Optional | Request headers. |
| parameters | Hash | Optional | Request body. |

