
# Validate Address Responsev 21

## Structure

`ValidateAddressResponsev21`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `AddressIsValidated` | `boolean` | Required | True if address is valid.  False otherwise. | boolean getAddressIsValidated() | setAddressIsValidated(boolean addressIsValidated) |
| `ValidationMessages` | [`List<AddressValidationInformation>`](/doc/models/address-validation-information.md) | Required | Informative Messages regarding Address Validation. | List<AddressValidationInformation> getValidationMessages() | setValidationMessages(List<AddressValidationInformation> validationMessages) |
| `ValidatedAddress` | [`Addressv21`](/doc/models/addressv-21.md) | Required | - | Addressv21 getValidatedAddress() | setValidatedAddress(Addressv21 validatedAddress) |
| `Error` | [`RequestError`](/doc/models/request-error.md) | Required | This information can be used to determine if an error has occurred when a request was processed. | RequestError getError() | setError(RequestError error) |

## Example (as JSON)

```json
{
  "addressIsValidated": false,
  "validationMessages": [
    {
      "code": "code6",
      "message": "message8"
    },
    {
      "code": "code7",
      "message": "message9"
    }
  ],
  "validatedAddress": {
    "address1": "address12",
    "address2": null,
    "city": "city6",
    "countryCode": "countryCode0",
    "stateOrProvidence": "stateOrProvidence0",
    "postalCode": "postalCode4",
    "isResidential": null,
    "attentionOf": null,
    "companyName": null,
    "email": null,
    "phoneNumber": null
  },
  "error": {
    "details": null,
    "hasError": false
  }
}
```

