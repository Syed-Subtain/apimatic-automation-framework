
# Image Rotation Enum

Image Rotation Like 90,180,270

## Enumeration

`ImageRotationEnum`

## Fields

| Name |
|  --- |
| `RotateNoneFlipNone` |
| `Rotate180FlipXY` |
| `Rotate90FlipNone` |
| `Rotate270FlipXY` |
| `Rotate180FlipNone` |
| `RotateNoneFlipXY` |
| `Rotate270FlipNone` |
| `Rotate90FlipXY` |
| `RotateNoneFlipX` |
| `Rotate180FlipY` |
| `Rotate90FlipX` |
| `Rotate270FlipY` |
| `Rotate180FlipX` |
| `RotateNoneFlipY` |
| `Rotate270FlipX` |
| `Rotate90FlipY` |

