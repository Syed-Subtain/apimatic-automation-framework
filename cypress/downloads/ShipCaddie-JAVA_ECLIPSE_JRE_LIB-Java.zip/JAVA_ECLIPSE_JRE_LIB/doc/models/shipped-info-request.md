
# Shipped Info Request

## Structure

`ShippedInfoRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `IncludeFromAddress` | `Boolean` | Optional | Include the from address information in result. Default false | Boolean getIncludeFromAddress() | setIncludeFromAddress(Boolean includeFromAddress) |
| `IncludeToAddress` | `Boolean` | Optional | Include the to address information in the result. Default false | Boolean getIncludeToAddress() | setIncludeToAddress(Boolean includeToAddress) |
| `IncludeCarrierInfo` | `Boolean` | Optional | Include the carrier information in the result. Default false | Boolean getIncludeCarrierInfo() | setIncludeCarrierInfo(Boolean includeCarrierInfo) |
| `IncludeShipmentOptions` | `Boolean` | Optional | Include the shipment options information in the result. Default false | Boolean getIncludeShipmentOptions() | setIncludeShipmentOptions(Boolean includeShipmentOptions) |
| `IncludeParcelInfo` | `Boolean` | Optional | Include the parcel information in the result. Default false | Boolean getIncludeParcelInfo() | setIncludeParcelInfo(Boolean includeParcelInfo) |
| `IncludeParcelOptions` | `Boolean` | Optional | Include the parcel options information in the result. Default false | Boolean getIncludeParcelOptions() | setIncludeParcelOptions(Boolean includeParcelOptions) |
| `IncludeParcelItems` | `Boolean` | Optional | Include the parcel items information in the result. Default false | Boolean getIncludeParcelItems() | setIncludeParcelItems(Boolean includeParcelItems) |
| `AccessToken` | `String` | Required | Required.<br>An authorization token is necessary to call this method.<br><remarks><br>The token can be obtained by calling the GetToken or RefreshToken methods.<br></remarks> | String getAccessToken() | setAccessToken(String accessToken) |
| `AsClientId` | `Integer` | Optional | Optional.<br>When empty or null, this field is ignored.<br>When set, actions will be taken for the client specified by the id. | Integer getAsClientId() | setAsClientId(Integer asClientId) |
| `ShipmentID` | `Integer` | Optional | Id of an existing shipment. | Integer getShipmentID() | setShipmentID(Integer shipmentID) |

## Example (as JSON)

```json
{
  "includeFromAddress": null,
  "includeToAddress": null,
  "includeCarrierInfo": null,
  "includeShipmentOptions": null,
  "includeParcelInfo": null,
  "includeParcelOptions": null,
  "includeParcelItems": null,
  "accessToken": "accessToken2",
  "asClientId": null,
  "shipmentID": null
}
```

