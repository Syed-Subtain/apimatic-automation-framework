
# Ship From Address

## Structure

`ShipFromAddress`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `CompanyName` | `String` | Optional | Optional Company Name.<br>This field is required by some Carriers. | String getCompanyName() | setCompanyName(String companyName) |
| `Email` | `String` | Optional | Optional Sender's email address.<br>This field is required by some Carriers. | String getEmail() | setEmail(String email) |
| `PhoneNumber` | `String` | Optional | Optional Sender's phone number.<br>This field is required by some Carriers. | String getPhoneNumber() | setPhoneNumber(String phoneNumber) |
| `Address1` | `String` | Optional | Street Address of Sender. | String getAddress1() | setAddress1(String address1) |
| `Address2` | `String` | Optional | Optional additional Street Address. | String getAddress2() | setAddress2(String address2) |
| `City` | `String` | Optional | City | String getCity() | setCity(String city) |
| `StateOrProvince` | `String` | Optional | State | String getStateOrProvince() | setStateOrProvince(String stateOrProvince) |
| `PostalCode` | `String` | Optional | Zip Code | String getPostalCode() | setPostalCode(String postalCode) |
| `CountryCode` | `String` | Optional | Code which indicates to which<br>country the parcels will be sent from.<br>Obtained from GetContryCodes. | String getCountryCode() | setCountryCode(String countryCode) |

## Example (as JSON)

```json
{
  "companyName": null,
  "email": null,
  "phoneNumber": null,
  "address1": null,
  "address2": null,
  "city": null,
  "stateOrProvince": null,
  "postalCode": null,
  "countryCode": null
}
```

