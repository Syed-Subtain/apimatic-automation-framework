
# Shipped Info Response

## Structure

`ShippedInfoResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `ShipmentId` | `Integer` | Optional | Id used to identify shipment. | Integer getShipmentId() | setShipmentId(Integer shipmentId) |
| `DateShipped` | `LocalDateTime` | Optional | Specifies the date of shipment. | LocalDateTime getDateShipped() | setDateShipped(LocalDateTime dateShipped) |
| `FromAddress` | [`ShipFromAddress`](/doc/models/ship-from-address.md) | Optional | - | ShipFromAddress getFromAddress() | setFromAddress(ShipFromAddress fromAddress) |
| `ToAddress` | [`ShipToAddress`](/doc/models/ship-to-address.md) | Optional | - | ShipToAddress getToAddress() | setToAddress(ShipToAddress toAddress) |
| `ShipmentOptions` | [`ShippingOptions`](/doc/models/shipping-options.md) | Optional | Billing and Custom Declaration Options for Shipping. | ShippingOptions getShipmentOptions() | setShipmentOptions(ShippingOptions shipmentOptions) |
| `Carrier` | [`ShippedInfoCarrier`](/doc/models/shipped-info-carrier.md) | Optional | - | ShippedInfoCarrier getCarrier() | setCarrier(ShippedInfoCarrier carrier) |
| `ParcelInfo` | [`List<ShippedInfoParcel>`](/doc/models/shipped-info-parcel.md) | Optional | The information about the packages in the shipment. | List<ShippedInfoParcel> getParcelInfo() | setParcelInfo(List<ShippedInfoParcel> parcelInfo) |
| `Error` | [`RequestError`](/doc/models/request-error.md) | Required | This information can be used to determine if an error has occurred when a request was processed. | RequestError getError() | setError(RequestError error) |

## Example (as JSON)

```json
{
  "shipmentId": null,
  "dateShipped": null,
  "fromAddress": null,
  "toAddress": null,
  "shipmentOptions": null,
  "carrier": null,
  "parcelInfo": null,
  "error": {
    "details": null,
    "hasError": false
  }
}
```

