
# Verify Package Length Girth Limit Requestv 21

## Structure

`VerifyPackageLengthGirthLimitRequestv21`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `AccessToken` | `String` | Optional | Required.<br>An authorization token is necessary to call this method.<br><remarks><br>The token can be obtained by calling the GetToken or RefreshToken methods.<br></remarks> | String getAccessToken() | setAccessToken(String accessToken) |
| `Request` | [`PackageLengthGirthModelV21`](/doc/models/package-length-girth-model-v21.md) | Optional | - | PackageLengthGirthModelV21 getRequest() | setRequest(PackageLengthGirthModelV21 request) |

## Example (as JSON)

```json
{
  "accessToken": "<YOUR ACCESS TOKEN>",
  "request": {
    "carrierServiceLevelId": 12,
    "packageList": [
      {
        "length": 6.0,
        "width": 8.0,
        "height": 12.0
      },
      {
        "length": 6.0,
        "width": 8.0,
        "height": 12.0
      }
    ]
  }
}
```

