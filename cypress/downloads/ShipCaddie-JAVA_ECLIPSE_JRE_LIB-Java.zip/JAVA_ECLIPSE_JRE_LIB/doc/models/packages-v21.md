
# Packages V21

## Structure

`PackagesV21`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Length` | `Double` | Optional | Required - Length | Double getLength() | setLength(Double length) |
| `Width` | `Double` | Optional | Required - Width | Double getWidth() | setWidth(Double width) |
| `Height` | `Double` | Optional | Required - Height | Double getHeight() | setHeight(Double height) |

## Example (as JSON)

```json
{
  "length": null,
  "width": null,
  "height": null
}
```

