
# Validate Shipment Address Request

Validate Shipment Address Request Model

## Structure

`ValidateShipmentAddressRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `AccessToken` | `String` | Optional | Access Token | String getAccessToken() | setAccessToken(String accessToken) |
| `AsClientId` | `Integer` | Optional | Client Id used in place of Client Id of signed in user. | Integer getAsClientId() | setAsClientId(Integer asClientId) |
| `ShipmentAddressToValidate` | [`AddressValidationRequestModel`](/doc/models/address-validation-request-model.md) | Optional | Address Validation request model | AddressValidationRequestModel getShipmentAddressToValidate() | setShipmentAddressToValidate(AddressValidationRequestModel shipmentAddressToValidate) |

## Example (as JSON)

```json
{
  "accessToken": "<YOUR ACCESS TOKEN>",
  "asClientId": 14,
  "shipmentAddressToValidate": {
    "carrierId": 4,
    "carrierContractId": 2324,
    "addresses": [
      {
        "address1": "2600 Executive Parkway",
        "address2": "Suite 160",
        "provinceCode": "UT",
        "city": "Lehi",
        "countryCode": "US",
        "postalCode": "84043",
        "addressTypeId": "Commercial",
        "companyName": "iDrive Logistics",
        "countryId": 0,
        "addressStatus": false
      }
    ]
  }
}
```

