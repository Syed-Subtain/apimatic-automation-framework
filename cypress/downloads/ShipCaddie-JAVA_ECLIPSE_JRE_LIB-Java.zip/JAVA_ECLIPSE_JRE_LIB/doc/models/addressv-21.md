
# Addressv 21

## Structure

`Addressv21`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Address1` | `String` | Required | Required | String getAddress1() | setAddress1(String address1) |
| `Address2` | `String` | Optional | Optional | String getAddress2() | setAddress2(String address2) |
| `City` | `String` | Required | Required | String getCity() | setCity(String city) |
| `CountryCode` | `String` | Required | Required | String getCountryCode() | setCountryCode(String countryCode) |
| `StateOrProvidence` | `String` | Required | Required - StateOrProvidence | String getStateOrProvidence() | setStateOrProvidence(String stateOrProvidence) |
| `PostalCode` | `String` | Required | Required - PostalCode | String getPostalCode() | setPostalCode(String postalCode) |
| `IsResidential` | `Boolean` | Optional | Optional - Is Residencial flag | Boolean getIsResidential() | setIsResidential(Boolean isResidential) |
| `AttentionOf` | `String` | Optional | Optional - Attention of,<br>some Carriers will require this parameter to be set | String getAttentionOf() | setAttentionOf(String attentionOf) |
| `CompanyName` | `String` | Optional | Optional - Company Name,<br>some Carriers will require this parameter to be set | String getCompanyName() | setCompanyName(String companyName) |
| `Email` | `String` | Optional | Optional - Email, some Carriers will require this parameter to be set | String getEmail() | setEmail(String email) |
| `PhoneNumber` | `String` | Optional | Optional - Phone Number,<br>some Carriers will require this parameter to be set | String getPhoneNumber() | setPhoneNumber(String phoneNumber) |

## Example (as JSON)

```json
{
  "address1": "address12",
  "address2": null,
  "city": "city0",
  "countryCode": "countryCode4",
  "stateOrProvidence": "stateOrProvidence4",
  "postalCode": "postalCode8",
  "isResidential": null,
  "attentionOf": null,
  "companyName": null,
  "email": null,
  "phoneNumber": null
}
```

