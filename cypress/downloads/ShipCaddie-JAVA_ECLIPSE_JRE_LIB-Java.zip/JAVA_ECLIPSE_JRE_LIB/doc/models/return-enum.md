
# Return Enum

Indicates if this is a return parcel.
and if so what type of return should be used.

## Enumeration

`ReturnEnum`

## Fields

| Name |
|  --- |
| `NOTAPPLICABLE` |
| `RETURNLABEL` |
| `RETURNLABELSHIP` |
| `RETURNLABELONUSE` |

