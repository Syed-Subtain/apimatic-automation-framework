
# Scan Form Model Request

## Structure

`ScanFormModelRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `CarrierClientContractId` | `Integer` | Optional | - | Integer getCarrierClientContractId() | setCarrierClientContractId(Integer carrierClientContractId) |
| `ShipmentClientAddressId` | `Integer` | Optional | - | Integer getShipmentClientAddressId() | setShipmentClientAddressId(Integer shipmentClientAddressId) |
| `ShipDate` | `LocalDateTime` | Optional | - | LocalDateTime getShipDate() | setShipDate(LocalDateTime shipDate) |
| `KeyList` | [`List<KeyValues>`](/doc/models/key-values.md) | Optional | - | List<KeyValues> getKeyList() | setKeyList(List<KeyValues> keyList) |
| `RecentScanFormId` | `Integer` | Optional | - | Integer getRecentScanFormId() | setRecentScanFormId(Integer recentScanFormId) |

## Example (as JSON)

```json
{
  "carrierClientContractId": null,
  "shipmentClientAddressId": null,
  "shipDate": null,
  "keyList": null,
  "recentScanFormId": null
}
```

