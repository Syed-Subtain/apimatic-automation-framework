
# Shipped Info Carrier

## Structure

`ShippedInfoCarrier`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `CarrierClientContractId` | `Integer` | Optional | Indicates which Carrier was used. | Integer getCarrierClientContractId() | setCarrierClientContractId(Integer carrierClientContractId) |
| `CarrierName` | `String` | Optional | The name of the carrier used for the shipment. | String getCarrierName() | setCarrierName(String carrierName) |
| `CarrierServiceLevelId` | `Integer` | Optional | Indicates which Carrier Service Level was used. | Integer getCarrierServiceLevelId() | setCarrierServiceLevelId(Integer carrierServiceLevelId) |
| `CarrierServiceLevelName` | `String` | Optional | The name of the service level used. | String getCarrierServiceLevelName() | setCarrierServiceLevelName(String carrierServiceLevelName) |

## Example (as JSON)

```json
{
  "carrierClientContractId": null,
  "carrierName": null,
  "carrierServiceLevelId": null,
  "carrierServiceLevelName": null
}
```

