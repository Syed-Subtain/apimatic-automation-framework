
# Security Token Request

A refresh token can be used to obtain a new security token.

## Structure

`SecurityTokenRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `RefreshToken` | `String` | Required | Required.<br>Use the Refresh Token to obtain a new security token after the Access Token has expired. | String getRefreshToken() | setRefreshToken(String refreshToken) |

## Example (as JSON)

```json
{
  "refreshToken": "<YOUR REFRESH TOKEN>"
}
```

