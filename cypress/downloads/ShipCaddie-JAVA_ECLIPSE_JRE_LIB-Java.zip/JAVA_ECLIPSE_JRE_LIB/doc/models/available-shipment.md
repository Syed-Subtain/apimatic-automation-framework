
# Available Shipment

## Structure

`AvailableShipment`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `CarrierClientContractId` | `Integer` | Optional | - | Integer getCarrierClientContractId() | setCarrierClientContractId(Integer carrierClientContractId) |
| `ShipmentId` | `Integer` | Optional | - | Integer getShipmentId() | setShipmentId(Integer shipmentId) |
| `PackageId` | `Integer` | Optional | - | Integer getPackageId() | setPackageId(Integer packageId) |
| `ShipmentClientAddressId` | `Integer` | Optional | - | Integer getShipmentClientAddressId() | setShipmentClientAddressId(Integer shipmentClientAddressId) |
| `DateShipped` | `LocalDateTime` | Optional | - | LocalDateTime getDateShipped() | setDateShipped(LocalDateTime dateShipped) |
| `FromShippingSiteName` | `String` | Optional | - | String getFromShippingSiteName() | setFromShippingSiteName(String fromShippingSiteName) |
| `ToAddressLine1` | `String` | Optional | - | String getToAddressLine1() | setToAddressLine1(String toAddressLine1) |
| `ToAddressLine2` | `String` | Optional | - | String getToAddressLine2() | setToAddressLine2(String toAddressLine2) |
| `ToPostalCode` | `String` | Optional | - | String getToPostalCode() | setToPostalCode(String toPostalCode) |
| `ToProvince` | `String` | Optional | - | String getToProvince() | setToProvince(String toProvince) |
| `ToCity` | `String` | Optional | - | String getToCity() | setToCity(String toCity) |
| `AccountAlias` | `String` | Optional | - | String getAccountAlias() | setAccountAlias(String accountAlias) |
| `LabelKey` | `String` | Optional | - | String getLabelKey() | setLabelKey(String labelKey) |
| `TrackingNumber` | `String` | Optional | - | String getTrackingNumber() | setTrackingNumber(String trackingNumber) |

## Example (as JSON)

```json
{
  "carrierClientContractId": null,
  "shipmentId": null,
  "packageId": null,
  "shipmentClientAddressId": null,
  "dateShipped": null,
  "fromShippingSiteName": null,
  "toAddressLine1": null,
  "toAddressLine2": null,
  "toPostalCode": null,
  "toProvince": null,
  "toCity": null,
  "accountAlias": null,
  "labelKey": null,
  "trackingNumber": null
}
```

