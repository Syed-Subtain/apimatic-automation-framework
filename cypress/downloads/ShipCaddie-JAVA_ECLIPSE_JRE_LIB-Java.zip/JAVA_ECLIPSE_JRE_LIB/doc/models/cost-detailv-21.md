
# Cost Detailv 21

Specific break down of cost.

## Structure

`CostDetailv21`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Name` | `String` | Optional | Name of a specific Charge. | String getName() | setName(String name) |
| `Amount` | `Double` | Optional | Cost in United States Currency. | Double getAmount() | setAmount(Double amount) |
| `AmountDisplay` | `Double` | Optional | Total Charge Amount Display | Double getAmountDisplay() | setAmountDisplay(Double amountDisplay) |

## Example (as JSON)

```json
{
  "name": null,
  "amount": null,
  "amountDisplay": null
}
```

