
# Void Label Responsev 21

## Structure

`VoidLabelResponsev21`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `TrackingNumber` | `String` | Optional | Tracking Number of voided Label | String getTrackingNumber() | setTrackingNumber(String trackingNumber) |
| `Error` | [`RequestError`](/doc/models/request-error.md) | Optional | This information can be used to determine if an error has occurred when a request was processed. | RequestError getError() | setError(RequestError error) |

## Example (as JSON)

```json
{
  "trackingNumber": null,
  "error": null
}
```

