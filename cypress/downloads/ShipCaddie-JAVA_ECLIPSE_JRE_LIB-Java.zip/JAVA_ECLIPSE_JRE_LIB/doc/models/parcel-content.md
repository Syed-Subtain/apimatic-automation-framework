
# Parcel Content

Itemized packaging content used by customs.

## Structure

`ParcelContent`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Sku` | `String` | Optional | Product identifier. | String getSku() | setSku(String sku) |
| `Name` | `String` | Required | Descriptive item name. | String getName() | setName(String name) |
| `Description` | `String` | Optional | Optional item description. | String getDescription() | setDescription(String description) |
| `Quantity` | `int` | Required | Number of items. | int getQuantity() | setQuantity(int quantity) |
| `Price` | `double` | Required | Price of item. | double getPrice() | setPrice(double price) |
| `WeightInPounds` | `double` | Required | Weight of the item. | double getWeightInPounds() | setWeightInPounds(double weightInPounds) |
| `HarmonizeCode` | `String` | Optional | Optional Harmonize code | String getHarmonizeCode() | setHarmonizeCode(String harmonizeCode) |
| `OriginCountry` | `String` | Required | Country where product was made. | String getOriginCountry() | setOriginCountry(String originCountry) |

## Example (as JSON)

```json
{
  "sku": null,
  "name": "name0",
  "description": null,
  "quantity": 68,
  "price": 207.52,
  "weightInPounds": 168.18,
  "harmonizeCode": null,
  "originCountry": "originCountry4"
}
```

