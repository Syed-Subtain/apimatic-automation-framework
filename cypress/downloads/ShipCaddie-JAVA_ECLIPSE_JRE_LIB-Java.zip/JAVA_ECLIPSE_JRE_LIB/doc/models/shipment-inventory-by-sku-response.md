
# Shipment Inventory by Sku Response

## Structure

`ShipmentInventoryBySkuResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Sku` | `String` | Optional | - | String getSku() | setSku(String sku) |
| `Name` | `String` | Optional | - | String getName() | setName(String name) |
| `Qty` | `Integer` | Optional | - | Integer getQty() | setQty(Integer qty) |
| `DateShipped` | `LocalDateTime` | Optional | - | LocalDateTime getDateShipped() | setDateShipped(LocalDateTime dateShipped) |
| `OrderReferenceNumber` | `String` | Optional | - | String getOrderReferenceNumber() | setOrderReferenceNumber(String orderReferenceNumber) |
| `ShipmentNumber` | `String` | Optional | - | String getShipmentNumber() | setShipmentNumber(String shipmentNumber) |

## Example (as JSON)

```json
{
  "sku": null,
  "name": null,
  "qty": null,
  "dateShipped": null,
  "orderReferenceNumber": null,
  "shipmentNumber": null
}
```

