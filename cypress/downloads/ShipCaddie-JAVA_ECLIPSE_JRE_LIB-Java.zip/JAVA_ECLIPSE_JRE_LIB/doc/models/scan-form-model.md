
# Scan Form Model

## Structure

`ScanFormModel`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Id` | `Integer` | Optional | - | Integer getId() | setId(Integer id) |
| `ScanFormId` | `String` | Optional | - | String getScanFormId() | setScanFormId(String scanFormId) |
| `BatchId` | `String` | Optional | - | String getBatchId() | setBatchId(String batchId) |
| `ClientId` | `Integer` | Optional | - | Integer getClientId() | setClientId(Integer clientId) |
| `ShipmentClientAddressId` | `Integer` | Optional | - | Integer getShipmentClientAddressId() | setShipmentClientAddressId(Integer shipmentClientAddressId) |
| `ShipDate` | `LocalDateTime` | Optional | - | LocalDateTime getShipDate() | setShipDate(LocalDateTime shipDate) |
| `ScanFormDataType` | [`ScanFormDataTypeEnum`](/doc/models/scan-form-data-type-enum.md) | Optional | - | ScanFormDataTypeEnum getScanFormDataType() | setScanFormDataType(ScanFormDataTypeEnum scanFormDataType) |
| `CarrierClientContractId` | `Integer` | Optional | - | Integer getCarrierClientContractId() | setCarrierClientContractId(Integer carrierClientContractId) |
| `CarrierClientContractName` | `String` | Optional | - | String getCarrierClientContractName() | setCarrierClientContractName(String carrierClientContractName) |
| `ShipmentClientAddressLine1` | `String` | Optional | - | String getShipmentClientAddressLine1() | setShipmentClientAddressLine1(String shipmentClientAddressLine1) |
| `ShipmentClientAddressLine2` | `String` | Optional | - | String getShipmentClientAddressLine2() | setShipmentClientAddressLine2(String shipmentClientAddressLine2) |
| `ShipmentClientAddressProvince` | `String` | Optional | - | String getShipmentClientAddressProvince() | setShipmentClientAddressProvince(String shipmentClientAddressProvince) |
| `ShipmentClientAddressCity` | `String` | Optional | - | String getShipmentClientAddressCity() | setShipmentClientAddressCity(String shipmentClientAddressCity) |
| `ShipmentClientAddressPostalCode` | `String` | Optional | - | String getShipmentClientAddressPostalCode() | setShipmentClientAddressPostalCode(String shipmentClientAddressPostalCode) |
| `ShippingSiteName` | `String` | Optional | - | String getShippingSiteName() | setShippingSiteName(String shippingSiteName) |
| `DateCreated` | `LocalDateTime` | Optional | - | LocalDateTime getDateCreated() | setDateCreated(LocalDateTime dateCreated) |
| `PrintJobs` | [`List<PrintJob>`](/doc/models/print-job.md) | Optional | - | List<PrintJob> getPrintJobs() | setPrintJobs(List<PrintJob> printJobs) |
| `ExcludedItems` | `Map<String, String>` | Optional | This is the list of items that are ignored or already manifested by easypost. | Map<String, String> getExcludedItems() | setExcludedItems(Map<String, String> excludedItems) |

## Example (as JSON)

```json
{
  "id": null,
  "scanFormId": null,
  "batchId": null,
  "clientId": null,
  "shipmentClientAddressId": null,
  "shipDate": null,
  "scanFormDataType": null,
  "carrierClientContractId": null,
  "carrierClientContractName": null,
  "shipmentClientAddressLine1": null,
  "shipmentClientAddressLine2": null,
  "shipmentClientAddressProvince": null,
  "shipmentClientAddressCity": null,
  "shipmentClientAddressPostalCode": null,
  "shippingSiteName": null,
  "dateCreated": null,
  "printJobs": null,
  "excludedItems": null
}
```

