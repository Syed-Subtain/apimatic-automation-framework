
# Cost Detail

Specific break down of cost.

## Structure

`CostDetail`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Name` | `String` | Required | Name of a specific Charge. | String getName() | setName(String name) |
| `Amount` | `double` | Required | Cost in United States Currency. | double getAmount() | setAmount(double amount) |
| `AmountDisplay` | `Double` | Optional | Total Charge Amount Display | Double getAmountDisplay() | setAmountDisplay(Double amountDisplay) |

## Example (as JSON)

```json
{
  "name": "name0",
  "amount": 56.78,
  "AmountDisplay": null
}
```

