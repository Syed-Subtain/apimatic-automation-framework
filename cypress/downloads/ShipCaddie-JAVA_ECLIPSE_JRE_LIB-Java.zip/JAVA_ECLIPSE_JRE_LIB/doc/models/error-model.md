
# Error Model

Model for the errors

## Structure

`ErrorModel`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `ErrorCode` | `String` | Optional | Error Code | String getErrorCode() | setErrorCode(String errorCode) |
| `ErrorDescription` | `String` | Optional | Description of the error | String getErrorDescription() | setErrorDescription(String errorDescription) |

## Example (as JSON)

```json
{
  "errorCode": null,
  "errorDescription": null
}
```

