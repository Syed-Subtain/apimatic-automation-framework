
# Parsed Address

Parsed Addresses

## Structure

`ParsedAddress`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `RequestedAddress` | [`AddressesModel`](/doc/models/addresses-model.md) | Optional | Common model for Requested and Suggested Addresses | AddressesModel getRequestedAddress() | setRequestedAddress(AddressesModel requestedAddress) |
| `SuggestedAddresses` | [`List<AddressesModel>`](/doc/models/addresses-model.md) | Optional | List of suggested addresses provided by the carrier | List<AddressesModel> getSuggestedAddresses() | setSuggestedAddresses(List<AddressesModel> suggestedAddresses) |
| `AddressStatus` | [`AddressStatusEnum`](/doc/models/address-status-enum.md) | Optional | Status of the address passed | AddressStatusEnum getAddressStatus() | setAddressStatus(AddressStatusEnum addressStatus) |
| `VerifiedFrom` | `Integer` | Optional | To get from where It is verified | Integer getVerifiedFrom() | setVerifiedFrom(Integer verifiedFrom) |

## Example (as JSON)

```json
{
  "requestedAddress": null,
  "suggestedAddresses": null,
  "addressStatus": null,
  "verifiedFrom": null
}
```

