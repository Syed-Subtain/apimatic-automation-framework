
# Regenerate Requestv 21

## Structure

`RegenerateRequestv21`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `AccessToken` | `String` | Optional | Required.<br>An authorization token is necessary to call this method.<br><remarks><br>The token can be obtained by calling the GetToken or RefreshToken methods.<br></remarks> | String getAccessToken() | setAccessToken(String accessToken) |
| `IsRegenerate` | `Boolean` | Optional | - | Boolean getIsRegenerate() | setIsRegenerate(Boolean isRegenerate) |
| `ScanFormRequest` | [`ScanFormModelRequest`](/doc/models/scan-form-model-request.md) | Optional | - | ScanFormModelRequest getScanFormRequest() | setScanFormRequest(ScanFormModelRequest scanFormRequest) |
| `AsClientId` | `Integer` | Optional | Optional.<br>When empty or null, this field is ignored.<br>When set, actions will be taken for the client specified by the id. | Integer getAsClientId() | setAsClientId(Integer asClientId) |

## Example (as JSON)

```json
{
  "accessToken": "<YOUR ACCESS TOKEN>",
  "isRegenerate": false,
  "scanFormRequest": {
    "carrierClientContractId": 2526,
    "shipmentClientAddressId": 747,
    "shipDate": "2017-11-29T00:00:00",
    "keyList": [
      {
        "labelKey": "shp_810c212e2dcf4863a1bd8495f9a54d81",
        "trackingNumber": "9400136895239112753275",
        "packageId": 366974
      }
    ],
    "recentScanFormId": 0
  }
}
```

