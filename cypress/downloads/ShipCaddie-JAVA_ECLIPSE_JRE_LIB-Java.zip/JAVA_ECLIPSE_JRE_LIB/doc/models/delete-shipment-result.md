
# Delete Shipment Result

Results of a Delete Shipment request.

## Structure

`DeleteShipmentResult`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `ShipmentId` | `Integer` | Optional | ID uniquely identifying the shipment that was requested to be deleted. | Integer getShipmentId() | setShipmentId(Integer shipmentId) |
| `IsDeleted` | `Boolean` | Optional | Set to true if the shipment was deleted successfully. | Boolean getIsDeleted() | setIsDeleted(Boolean isDeleted) |
| `Error` | [`RequestError`](/doc/models/request-error.md) | Optional | This information can be used to determine if an error has occurred when a request was processed. | RequestError getError() | setError(RequestError error) |

## Example (as JSON)

```json
{
  "shipmentId": null,
  "isDeleted": null,
  "error": null
}
```

