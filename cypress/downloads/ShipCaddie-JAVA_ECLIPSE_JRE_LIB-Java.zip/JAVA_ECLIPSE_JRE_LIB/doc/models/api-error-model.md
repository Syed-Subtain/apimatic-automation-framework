
# Api Error Model

The error model that is used throughout all the api's

## Structure

`ApiErrorModel`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Error` | `String` | Optional | The code that identifies the error. | String getError() | setError(String error) |
| `DeveloperMessage` | `String` | Optional | The message that should go back to the developer. | String getDeveloperMessage() | setDeveloperMessage(String developerMessage) |
| `UserMessage` | `String` | Optional | The message if any that should go back to the user. | String getUserMessage() | setUserMessage(String userMessage) |
| `Misc` | `Object` | Optional | Other misc objects that need to be passed to controller for return with other methods | Object getMisc() | setMisc(Object misc) |

## Example (as JSON)

```json
{
  "error": null,
  "developerMessage": null,
  "userMessage": null,
  "misc": null
}
```

