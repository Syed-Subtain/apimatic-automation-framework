
# Shipment Information Response

## Structure

`ShipmentInformationResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `ShipmentId` | `Integer` | Optional | Id used to identify shipment. | Integer getShipmentId() | setShipmentId(Integer shipmentId) |
| `Error` | [`RequestError`](/doc/models/request-error.md) | Required | This information can be used to determine if an error has occurred when a request was processed. | RequestError getError() | setError(RequestError error) |
| `Shipment` | [`ShipmentInformation`](/doc/models/shipment-information.md) | Optional | All necessary shipping information | ShipmentInformation getShipment() | setShipment(ShipmentInformation shipment) |

## Example (as JSON)

```json
{
  "shipmentId": null,
  "error": {
    "details": null,
    "hasError": false
  },
  "shipment": null
}
```

