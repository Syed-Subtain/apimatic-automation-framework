
# Package Length Girth Model V21

## Structure

`PackageLengthGirthModelV21`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `CarrierServiceLevelId` | `Integer` | Optional | Required - CarrierServiceLevelId | Integer getCarrierServiceLevelId() | setCarrierServiceLevelId(Integer carrierServiceLevelId) |
| `PackageList` | [`List<PackagesV21>`](/doc/models/packages-v21.md) | Optional | List of Packages | List<PackagesV21> getPackageList() | setPackageList(List<PackagesV21> packageList) |

## Example (as JSON)

```json
{
  "carrierServiceLevelId": null,
  "packageList": null
}
```

