
# Update Email Notification Responsev 21

## Structure

`UpdateEmailNotificationResponsev21`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `SuccessfullyUpdatedEmailNotification` | `boolean` | Required | True if update has completed successfully.<br>False otherwise. | boolean getSuccessfullyUpdatedEmailNotification() | setSuccessfullyUpdatedEmailNotification(boolean successfullyUpdatedEmailNotification) |
| `Error` | [`RequestError`](/doc/models/request-error.md) | Required | This information can be used to determine if an error has occurred when a request was processed. | RequestError getError() | setError(RequestError error) |

## Example (as JSON)

```json
{
  "successfullyUpdatedEmailNotification": false,
  "error": {
    "details": null,
    "hasError": false
  }
}
```

