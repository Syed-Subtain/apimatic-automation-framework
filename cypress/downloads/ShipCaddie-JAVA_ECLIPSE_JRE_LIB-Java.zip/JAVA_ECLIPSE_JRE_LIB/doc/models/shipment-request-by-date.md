
# Shipment Request by Date

## Structure

`ShipmentRequestByDate`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `AccessToken` | `String` | Required | Required.<br>An authorization token is necessary to call this method.<br><remarks><br>The token can be obtained by calling the GetToken or RefreshToken methods.<br></remarks> | String getAccessToken() | setAccessToken(String accessToken) |
| `AsClientId` | `Integer` | Optional | Optional.<br>When empty or null, this field is ignored.<br>When set, actions will be taken for the client specified by the id. | Integer getAsClientId() | setAsClientId(Integer asClientId) |
| `StartDate` | `LocalDateTime` | Optional | StartDate. | LocalDateTime getStartDate() | setStartDate(LocalDateTime startDate) |
| `EndDate` | `LocalDateTime` | Optional | EndDate. | LocalDateTime getEndDate() | setEndDate(LocalDateTime endDate) |

## Example (as JSON)

```json
{
  "accessToken": "<YOUR ACCESS TOKEN>",
  "asClientId": 12,
  "startDate": "2020-12-23T23:54:10.2804606+00:00",
  "endDate": "2020-12-23T23:54:10.2804606+00:00"
}
```

