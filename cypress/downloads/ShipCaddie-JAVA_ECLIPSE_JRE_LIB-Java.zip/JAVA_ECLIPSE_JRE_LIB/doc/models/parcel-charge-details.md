
# Parcel Charge Details

Break down of charges per parcel.

## Structure

`ParcelChargeDetails`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `ParcelID` | `String` | Optional | A unique ID used to match<br>parcels with cost details. | String getParcelID() | setParcelID(String parcelID) |
| `CostDetails` | [`List<CostDetailv21>`](/doc/models/cost-detailv-21.md) | Optional | Detailed shipping charges. | List<CostDetailv21> getCostDetails() | setCostDetails(List<CostDetailv21> costDetails) |

## Example (as JSON)

```json
{
  "parcelID": null,
  "costDetails": null
}
```

