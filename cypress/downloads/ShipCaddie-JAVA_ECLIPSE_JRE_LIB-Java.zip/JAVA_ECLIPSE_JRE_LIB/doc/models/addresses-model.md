
# Addresses Model

Common model for Requested and Suggested Addresses

## Structure

`AddressesModel`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Address1` | `String` | Optional | Address Line1 of the address | String getAddress1() | setAddress1(String address1) |
| `Address2` | `String` | Optional | Address Line2 of the address | String getAddress2() | setAddress2(String address2) |
| `AddressTypeId` | [`AddressTypeId1Enum`](/doc/models/address-type-id-1-enum.md) | Optional | Id of the address type | AddressTypeId1Enum getAddressTypeId() | setAddressTypeId(AddressTypeId1Enum addressTypeId) |
| `City` | `String` | Optional | City | String getCity() | setCity(String city) |
| `CompanyName` | `String` | Optional | Name of the Company / Organisation | String getCompanyName() | setCompanyName(String companyName) |
| `CountryCode` | `String` | Optional | Code of the country provided in address | String getCountryCode() | setCountryCode(String countryCode) |
| `CountryId` | `Integer` | Optional | Id of the country specified. | Integer getCountryId() | setCountryId(Integer countryId) |
| `Countryname` | `String` | Optional | Name of the country with which address relates | String getCountryname() | setCountryname(String countryname) |
| `PostalCode` | `String` | Optional | Postal Code | String getPostalCode() | setPostalCode(String postalCode) |
| `Province` | `String` | Optional | Province / State | String getProvince() | setProvince(String province) |
| `ProvinceCode` | `String` | Optional | Code the Province | String getProvinceCode() | setProvinceCode(String provinceCode) |
| `RowKeyHash` | `String` | Optional | Row Key Hash | String getRowKeyHash() | setRowKeyHash(String rowKeyHash) |
| `IsSelected` | `Boolean` | Optional | Is Selected | Boolean getIsSelected() | setIsSelected(Boolean isSelected) |

## Example (as JSON)

```json
{
  "address1": null,
  "address2": null,
  "addressTypeId": null,
  "city": null,
  "companyName": null,
  "countryCode": null,
  "countryId": null,
  "countryname": null,
  "postalCode": null,
  "province": null,
  "provinceCode": null,
  "rowKeyHash": null,
  "isSelected": null
}
```

