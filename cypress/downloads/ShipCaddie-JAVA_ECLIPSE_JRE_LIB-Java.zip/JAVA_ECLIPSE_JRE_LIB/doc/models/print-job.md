
# Print Job

## Structure

`PrintJob`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `PrintTemplateType` | `String` | Optional | - | String getPrintTemplateType() | setPrintTemplateType(String printTemplateType) |
| `DataBlocks` | [`List<DataBlock>`](/doc/models/data-block.md) | Optional | - | List<DataBlock> getDataBlocks() | setDataBlocks(List<DataBlock> dataBlocks) |

## Example (as JSON)

```json
{
  "printTemplateType": null,
  "dataBlocks": null
}
```

