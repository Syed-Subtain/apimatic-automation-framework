
# Country Code Data

Country information necessary to construct addresses.

## Structure

`CountryCodeData`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `CountryId` | `int` | Required | Unique ID used to identify a country. | int getCountryId() | setCountryId(int countryId) |
| `CountryName` | `String` | Required | Friendly Country name. | String getCountryName() | setCountryName(String countryName) |
| `Alpha2CountryCode` | `String` | Required | Standardized Country Codes. | String getAlpha2CountryCode() | setAlpha2CountryCode(String alpha2CountryCode) |

## Example (as JSON)

```json
{
  "countryId": 8,
  "countryName": "countryName6",
  "alpha2CountryCode": "alpha2CountryCode6"
}
```

