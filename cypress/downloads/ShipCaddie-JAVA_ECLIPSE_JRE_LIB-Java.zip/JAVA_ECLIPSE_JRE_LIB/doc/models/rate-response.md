
# Rate Response

## Structure

`RateResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `ProcessingTimeInSeconds` | `double` | Required | - | double getProcessingTimeInSeconds() | setProcessingTimeInSeconds(double processingTimeInSeconds) |
| `CarrierName` | `String` | Optional | - | String getCarrierName() | setCarrierName(String carrierName) |
| `CarrierClientContractId` | `Integer` | Optional | - | Integer getCarrierClientContractId() | setCarrierClientContractId(Integer carrierClientContractId) |
| `Data` | [`List<ShippingCostsPerCarrier>`](/doc/models/shipping-costs-per-carrier.md) | Optional | - | List<ShippingCostsPerCarrier> getData() | setData(List<ShippingCostsPerCarrier> data) |
| `Error` | [`RequestError`](/doc/models/request-error.md) | Required | This information can be used to determine if an error has occurred when a request was processed. | RequestError getError() | setError(RequestError error) |

## Example (as JSON)

```json
{
  "processingTimeInSeconds": 50.3,
  "carrierName": null,
  "carrierClientContractId": null,
  "data": null,
  "error": {
    "details": null,
    "hasError": false
  }
}
```

