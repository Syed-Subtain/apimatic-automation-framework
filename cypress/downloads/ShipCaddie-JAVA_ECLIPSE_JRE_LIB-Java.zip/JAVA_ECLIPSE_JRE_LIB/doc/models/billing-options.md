
# Billing Options

Specifies how the shipping costs will be paid.

## Structure

`BillingOptions`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `ShippingPaidBy` | [`ShippingPaidByEnum`](/doc/models/shipping-paid-by-enum.md) | Required | Indicates who will pay for the shipping Costs. | ShippingPaidByEnum getShippingPaidBy() | setShippingPaidBy(ShippingPaidByEnum shippingPaidBy) |
| `AccountNumber` | `String` | Optional | Optional Account Number.<br>This is the account number of the person or group which will pay the shipping charges. | String getAccountNumber() | setAccountNumber(String accountNumber) |
| `PostalCode` | `String` | Optional | Optional Postal Code<br>This is the postal code of the person or group which will pay the shipping charges. | String getPostalCode() | setPostalCode(String postalCode) |
| `CountryAlpha2Code` | `String` | Optional | Optional Country<br>This is the country of the person or group which will pay the shipping charges. | String getCountryAlpha2Code() | setCountryAlpha2Code(String countryAlpha2Code) |
| `DutiesPaidBy` | [`DutiesPaidByEnum`](/doc/models/duties-paid-by-enum.md) | Required | Indicates who will pay for any applicable duties. | DutiesPaidByEnum getDutiesPaidBy() | setDutiesPaidBy(DutiesPaidByEnum dutiesPaidBy) |

## Example (as JSON)

```json
{
  "shippingPaidBy": "PAID_BY_RECIPIENT",
  "accountNumber": null,
  "postalCode": null,
  "country_Alpha2Code": null,
  "dutiesPaidBy": "PAID_BY_RECIPIENT"
}
```

