
# Address Validation Request Model

Address Validation request model

## Structure

`AddressValidationRequestModel`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `CarrierId` | `Integer` | Optional | The Id of the carrier | Integer getCarrierId() | setCarrierId(Integer carrierId) |
| `CarrierContractId` | `Integer` | Optional | Identifies the Carrier Client Contract on Shipcaddie | Integer getCarrierContractId() | setCarrierContractId(Integer carrierContractId) |
| `Addresses` | [`List<AddressValidationModel>`](/doc/models/address-validation-model.md) | Optional | List of address validation models | List<AddressValidationModel> getAddresses() | setAddresses(List<AddressValidationModel> addresses) |

## Example (as JSON)

```json
{
  "carrierId": null,
  "carrierContractId": null,
  "addresses": null
}
```

