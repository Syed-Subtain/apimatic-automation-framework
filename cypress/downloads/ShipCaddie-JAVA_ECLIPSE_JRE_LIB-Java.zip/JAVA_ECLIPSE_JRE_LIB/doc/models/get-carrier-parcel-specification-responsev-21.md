
# Get Carrier Parcel Specification Responsev 21

## Structure

`GetCarrierParcelSpecificationResponsev21`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `ParcelDetails` | [`List<PackagingDetail>`](/doc/models/packaging-detail.md) | Optional | Specifications for parcels handled by carrier. | List<PackagingDetail> getParcelDetails() | setParcelDetails(List<PackagingDetail> parcelDetails) |
| `Error` | [`RequestError`](/doc/models/request-error.md) | Optional | This information can be used to determine if an error has occurred when a request was processed. | RequestError getError() | setError(RequestError error) |

## Example (as JSON)

```json
{
  "parcelDetails": null,
  "error": null
}
```

