
# Shipping Costs Per Carrier

## Structure

`ShippingCostsPerCarrier`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `ServiceLevelName` | `String` | Optional | - | String getServiceLevelName() | setServiceLevelName(String serviceLevelName) |
| `ServiceLevelID` | `Integer` | Optional | - | Integer getServiceLevelID() | setServiceLevelID(Integer serviceLevelID) |
| `ParcelChargeDetails` | [`List<ParcelCharges>`](/doc/models/parcel-charges.md) | Optional | Shipping charges relating to individual parcels. | List<ParcelCharges> getParcelChargeDetails() | setParcelChargeDetails(List<ParcelCharges> parcelChargeDetails) |
| `ShippingChargeDetails` | [`List<CostDetail>`](/doc/models/cost-detail.md) | Optional | Shipping charges relating to a shipment as a whole. | List<CostDetail> getShippingChargeDetails() | setShippingChargeDetails(List<CostDetail> shippingChargeDetails) |
| `TransitDaysMin` | `Integer` | Optional | The Days in transit as defined by the carrier for the service level chosen.<br>The number may or may not include non-business days. | Integer getTransitDaysMin() | setTransitDaysMin(Integer transitDaysMin) |
| `TransitDaysMax` | `Integer` | Optional | The Days in transit as defined by the carrier for the service level chosen.<br>The number may or may not include non-business days. | Integer getTransitDaysMax() | setTransitDaysMax(Integer transitDaysMax) |
| `TotalChargeAmount` | `Double` | Optional | - | Double getTotalChargeAmount() | setTotalChargeAmount(Double totalChargeAmount) |
| `TotalChargeAmount3pl` | `Double` | Optional | The total charge of this shipment.<br>This is the sum of all accessorialCharges.chargeAmount3pl fields in all packages | Double getTotalChargeAmount3pl() | setTotalChargeAmount3pl(Double totalChargeAmount3pl) |
| `DeliveryDateTime` | `String` | Optional | - | String getDeliveryDateTime() | setDeliveryDateTime(String deliveryDateTime) |
| `IsDeliveryGuaranteed` | `Boolean` | Optional | - | Boolean getIsDeliveryGuaranteed() | setIsDeliveryGuaranteed(Boolean isDeliveryGuaranteed) |
| `ZoneName` | `String` | Optional | - | String getZoneName() | setZoneName(String zoneName) |
| `TotalChargeAmountDisplay` | `Double` | Optional | Gets or Sets ZoneName | Double getTotalChargeAmountDisplay() | setTotalChargeAmountDisplay(Double totalChargeAmountDisplay) |

## Example (as JSON)

```json
{
  "serviceLevelName": null,
  "serviceLevelID": null,
  "parcelChargeDetails": null,
  "shippingChargeDetails": null,
  "transitDaysMin": null,
  "transitDaysMax": null,
  "totalChargeAmount": null,
  "totalChargeAmount3pl": null,
  "deliveryDateTime": null,
  "isDeliveryGuaranteed": null,
  "zoneName": null,
  "TotalChargeAmountDisplay": null
}
```

