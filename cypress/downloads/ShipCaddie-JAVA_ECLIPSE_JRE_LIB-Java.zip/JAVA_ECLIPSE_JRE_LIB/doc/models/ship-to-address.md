
# Ship to Address

## Structure

`ShipToAddress`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `AttentionOf` | `String` | Optional | Attention of the person accepting the parcels.<br>This field is required by some Carriers. | String getAttentionOf() | setAttentionOf(String attentionOf) |
| `CompanyName` | `String` | Optional | Optional Company Name.<br>This field is required by some Carriers. | String getCompanyName() | setCompanyName(String companyName) |
| `Email` | `String` | Optional | This field is required by some Carriers. | String getEmail() | setEmail(String email) |
| `PhoneNumber` | `String` | Optional | This field is required by some Carriers. | String getPhoneNumber() | setPhoneNumber(String phoneNumber) |
| `Address1` | `String` | Optional | Street Address | String getAddress1() | setAddress1(String address1) |
| `Address2` | `String` | Optional | Optional additional Street Address. | String getAddress2() | setAddress2(String address2) |
| `IsResidential` | `Boolean` | Optional | Specifies if the address is a residential address. | Boolean getIsResidential() | setIsResidential(Boolean isResidential) |
| `City` | `String` | Optional | City to which the parcels will be sent. | String getCity() | setCity(String city) |
| `StateOrProvince` | `String` | Optional | Use Province or other appropriate value<br>for international addresses. | String getStateOrProvince() | setStateOrProvince(String stateOrProvince) |
| `PostalCode` | `String` | Optional | Zip Code if address in in the United States.<br>Postal Code if the address is international. | String getPostalCode() | setPostalCode(String postalCode) |
| `CountryCode` | `String` | Optional | Code which indicates to which<br>country the parcels will be sent.<br>Obtained from GetContryCodes. | String getCountryCode() | setCountryCode(String countryCode) |

## Example (as JSON)

```json
{
  "attentionOf": null,
  "companyName": null,
  "email": null,
  "phoneNumber": null,
  "address1": null,
  "address2": null,
  "isResidential": null,
  "city": null,
  "stateOrProvince": null,
  "postalCode": null,
  "countryCode": null
}
```

