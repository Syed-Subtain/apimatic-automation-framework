
# Get Carrier Balance Requestv 21

## Structure

`GetCarrierBalanceRequestv21`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `AccessToken` | `String` | Required | Required.<br>An authorization token is necessary to call this method.<br><remarks><br>The token can be obtained by calling the GetToken or RefreshToken methods.<br></remarks> | String getAccessToken() | setAccessToken(String accessToken) |
| `AsClientId` | `Integer` | Optional | Optional.<br>When empty or null, this field is ignored.<br>When set, actions will be taken for the client specified by the id. | Integer getAsClientId() | setAsClientId(Integer asClientId) |
| `CarrierClientContractId` | `int` | Required | Required.<br>Specific Carrier id. This id can be obtained by calling GetCarrierServiceInformation. | int getCarrierClientContractId() | setCarrierClientContractId(int carrierClientContractId) |

## Example (as JSON)

```json
{
  "accessToken": "<YOUR ACCESS TOKEN>",
  "asClientId": 12,
  "carrierClientContractId": 34
}
```

