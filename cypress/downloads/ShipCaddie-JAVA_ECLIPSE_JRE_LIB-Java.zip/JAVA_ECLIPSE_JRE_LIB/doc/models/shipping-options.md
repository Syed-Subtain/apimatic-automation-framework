
# Shipping Options

Billing and Custom Declaration Options for Shipping.

## Structure

`ShippingOptions`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `IsAPOFPODPOUSTerritory` | `boolean` | Required | Set this to true if shipping to:<br><br>* Army Post Office<br>* Fleet Post Office<br>* Diplomatic Post Office<br>* US Territories<br><br>Default value is false. | boolean getIsAPOFPODPOUSTerritory() | setIsAPOFPODPOUSTerritory(boolean isAPOFPODPOUSTerritory) |
| `IsInternationalShipment` | `boolean` | Required | Specifies if this shipment is an international shipment.<br><br>Default is false. | boolean getIsInternationalShipment() | setIsInternationalShipment(boolean isInternationalShipment) |
| `Billing` | [`BillingOptions`](/doc/models/billing-options.md) | Required | Specifies how the shipping costs will be paid. | BillingOptions getBilling() | setBilling(BillingOptions billing) |
| `ShipmentContentType` | [`ShipmentContentTypeEnum`](/doc/models/shipment-content-type-enum.md) | Optional | Indicates the type of content that is in the parcels.<br>Will be used for customs declarations if shipping internationally. | ShipmentContentTypeEnum getShipmentContentType() | setShipmentContentType(ShipmentContentTypeEnum shipmentContentType) |
| `CustomsCertify` | `Boolean` | Optional | TRUE means the customs information is certified to be correct and the CustomsSigner name is recommended<br><br>Default is null. | Boolean getCustomsCertify() | setCustomsCertify(Boolean customsCertify) |
| `CustomsSigner` | `String` | Optional | Name of person certifying that the customs information is correct.<br>This name prints on the customs form in place of a signature<br>if CustomsCertify is TRUE. Required if CustomsCertify is TRUE<br><br>Default is null. | String getCustomsSigner() | setCustomsSigner(String customsSigner) |
| `InternalTransactionNumber` | `String` | Optional | InternalTransactionNumber is required in case of international shipments and having customDeclarationValue &gt; 2500 | String getInternalTransactionNumber() | setInternalTransactionNumber(String internalTransactionNumber) |
| `ContentsExplanation` | `String` | Optional | If we have "CONTENT_TYPE_OTHER" as content type then<br>Then need to pass ContentsExplanation as value | String getContentsExplanation() | setContentsExplanation(String contentsExplanation) |

## Example (as JSON)

```json
{
  "isAPO_FPO_DPO_USTerritory": false,
  "isInternationalShipment": false,
  "billing": {
    "shippingPaidBy": "PAID_BY_RECIPIENT",
    "accountNumber": null,
    "postalCode": null,
    "country_Alpha2Code": null,
    "dutiesPaidBy": "PAID_BY_RECIPIENT"
  },
  "shipmentContentType": null,
  "customsCertify": null,
  "customsSigner": null,
  "internalTransactionNumber": null,
  "contentsExplanation": null
}
```

