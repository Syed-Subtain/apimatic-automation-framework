
# Request Error

This information can be used to determine if an error has occurred when a request was processed.

## Structure

`RequestError`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Details` | `List<String>` | Optional | Describes the error that occurred during the request. | List<String> getDetails() | setDetails(List<String> details) |
| `HasError` | `boolean` | Required | Set to true in the case that an error has occurred while processing the request.<br>Set to false otherwise. | boolean getHasError() | setHasError(boolean hasError) |

## Example (as JSON)

```json
{
  "details": null,
  "hasError": false
}
```

