
# Parcel Charges

Break down of charges per parcel.

## Structure

`ParcelCharges`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `ParcelID` | `UUID` | Required | A unique ID used to match<br>parcels with cost details. | UUID getParcelID() | setParcelID(UUID parcelID) |
| `CostDetails` | [`List<CostDetail>`](/doc/models/cost-detail.md) | Optional | Detailed shipping charges. | List<CostDetail> getCostDetails() | setCostDetails(List<CostDetail> costDetails) |
| `PackagingId` | `String` | Optional | - | String getPackagingId() | setPackagingId(String packagingId) |

## Example (as JSON)

```json
{
  "parcelID": "00001f04-0000-0000-0000-000000000000",
  "costDetails": null,
  "packagingId": null
}
```

