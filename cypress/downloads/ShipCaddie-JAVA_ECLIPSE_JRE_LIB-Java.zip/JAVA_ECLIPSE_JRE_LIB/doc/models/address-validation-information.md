
# Address Validation Information

Informative Messages regarding Address Validation.

## Structure

`AddressValidationInformation`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Code` | `String` | Required | Message Code. | String getCode() | setCode(String code) |
| `Message` | `String` | Required | Descriptive Message. | String getMessage() | setMessage(String message) |

## Example (as JSON)

```json
{
  "code": "code8",
  "message": "message0"
}
```

