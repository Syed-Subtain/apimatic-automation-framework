
# Address Validatation Response Model

Address Validation Response Model

## Structure

`AddressValidatationResponseModel`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Errors` | [`List<ErrorModel>`](/doc/models/error-model.md) | Optional | - | List<ErrorModel> getErrors() | setErrors(List<ErrorModel> errors) |
| `IsValidated` | `Boolean` | Optional | Flag indicates whether address is validated or not | Boolean getIsValidated() | setIsValidated(Boolean isValidated) |
| `ParsedAddresses` | [`List<ParsedAddress>`](/doc/models/parsed-address.md) | Optional | List of parsed address | List<ParsedAddress> getParsedAddresses() | setParsedAddresses(List<ParsedAddress> parsedAddresses) |
| `ReplyTimeStamp` | `LocalDateTime` | Optional | Reply time stamp | LocalDateTime getReplyTimeStamp() | setReplyTimeStamp(LocalDateTime replyTimeStamp) |
| `StatusCode` | `String` | Optional | Status code | String getStatusCode() | setStatusCode(String statusCode) |
| `StatusDescription` | `String` | Optional | Decsription for the status | String getStatusDescription() | setStatusDescription(String statusDescription) |

## Example (as JSON)

```json
{
  "errors": null,
  "isValidated": null,
  "parsedAddresses": null,
  "replyTimeStamp": null,
  "statusCode": null,
  "statusDescription": null
}
```

