
# Address Type Id Enum

Type of address
Values :
- NotDefined
- Residential
- Commercial
- NotVerified
- Invalid

## Enumeration

`AddressTypeIdEnum`

## Fields

| Name |
|  --- |
| `NotDefined` |
| `Residential` |
| `Commercial` |
| `NotVerified` |
| `Invalid` |
| `FailedAddress` |
| `UserVerified` |
| `Processing` |
| `Military` |
| `International` |
| `UsTerritory` |
| `PoBox` |

