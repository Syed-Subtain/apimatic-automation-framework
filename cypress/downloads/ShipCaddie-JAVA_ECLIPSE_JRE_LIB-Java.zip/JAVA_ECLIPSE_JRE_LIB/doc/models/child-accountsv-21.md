
# Child Accountsv 21

## Structure

`ChildAccountsv21`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `ClientId` | `Integer` | Optional | - | Integer getClientId() | setClientId(Integer clientId) |
| `Name` | `String` | Optional | - | String getName() | setName(String name) |
| `IsEnabled` | `Boolean` | Optional | - | Boolean getIsEnabled() | setIsEnabled(Boolean isEnabled) |

## Example (as JSON)

```json
{
  "clientId": null,
  "name": null,
  "isEnabled": null
}
```

