
# User Register Modelv 21

## Structure

`UserRegisterModelv21`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `SystemCountryId` | `Integer` | Optional | Country of Origin | Integer getSystemCountryId() | setSystemCountryId(Integer systemCountryId) |
| `NameFirst` | `String` | Optional | Required.<br>First Name<br>Max Length: 25 | String getNameFirst() | setNameFirst(String nameFirst) |
| `NameLast` | `String` | Optional | Required.<br>Last Name<br>Max Length: 35 | String getNameLast() | setNameLast(String nameLast) |
| `CompanyName` | `String` | Optional | Company Name<br>Max Length: 50 | String getCompanyName() | setCompanyName(String companyName) |
| `PhoneNumber` | `String` | Optional | Phone Number | String getPhoneNumber() | setPhoneNumber(String phoneNumber) |
| `UserName` | `String` | Optional | Required.<br>User name | String getUserName() | setUserName(String userName) |
| `Password` | `String` | Optional | Required.<br>Max Length: 100<br>Min Length: 8<br>Password | String getPassword() | setPassword(String password) |
| `PasswordVerify` | `String` | Optional | Confirm password | String getPasswordVerify() | setPasswordVerify(String passwordVerify) |
| `PromoCode` | `String` | Optional | Promo Code | String getPromoCode() | setPromoCode(String promoCode) |
| `SubscriptionTierId` | `Integer` | Optional | Subscription Tier | Integer getSubscriptionTierId() | setSubscriptionTierId(Integer subscriptionTierId) |
| `IAgree` | `String` | Optional | - | String getIAgree() | setIAgree(String iAgree) |

## Example (as JSON)

```json
{
  "systemCountryId": null,
  "nameFirst": null,
  "nameLast": null,
  "companyName": null,
  "phoneNumber": null,
  "userName": null,
  "password": null,
  "passwordVerify": null,
  "promoCode": null,
  "subscriptionTierId": null,
  "iAgree": null
}
```

