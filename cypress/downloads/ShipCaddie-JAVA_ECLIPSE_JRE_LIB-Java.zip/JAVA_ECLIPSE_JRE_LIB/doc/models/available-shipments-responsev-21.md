
# Available Shipments Responsev 21

## Structure

`AvailableShipmentsResponsev21`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Error` | [`RequestError`](/doc/models/request-error.md) | Optional | This information can be used to determine if an error has occurred when a request was processed. | RequestError getError() | setError(RequestError error) |
| `AvailableShipments` | [`List<AvailableShipment>`](/doc/models/available-shipment.md) | Optional | - | List<AvailableShipment> getAvailableShipments() | setAvailableShipments(List<AvailableShipment> availableShipments) |

## Example (as JSON)

```json
{
  "error": null,
  "availableShipments": null
}
```

