
# Data Block

## Structure

`DataBlock`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `DataSourceName` | `String` | Optional | - | String getDataSourceName() | setDataSourceName(String dataSourceName) |
| `Type` | `String` | Optional | - | String getType() | setType(String type) |
| `Data` | `String` | Optional | - | String getData() | setData(String data) |
| `DataURI` | `String` | Optional | - | String getDataURI() | setDataURI(String dataURI) |

## Example (as JSON)

```json
{
  "dataSourceName": null,
  "type": null,
  "data": null,
  "dataURI": null
}
```

