
# COD Options

Optional Cash on Demand

## Structure

`CODOptions`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `CodType` | [`CodTypeEnum`](/doc/models/cod-type-enum.md) | Optional | - | CodTypeEnum getCodType() | setCodType(CodTypeEnum codType) |
| `CodAmount` | `Double` | Optional | If COD is used,<br>specify the amount in<br>US Currency. | Double getCodAmount() | setCodAmount(Double codAmount) |

## Example (as JSON)

```json
{
  "codType": null,
  "codAmount": null
}
```

