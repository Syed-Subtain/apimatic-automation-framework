
# Carrier Information

## Structure

`CarrierInformation`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `CarrierClientContractId` | `int` | Required | This id is used to identify a carrier.<br>Various API methods require this id. | int getCarrierClientContractId() | setCarrierClientContractId(int carrierClientContractId) |
| `AffillateName` | `String` | Required | Affillate Name | String getAffillateName() | setAffillateName(String affillateName) |
| `CarrierName` | `String` | Required | Offical name of carrier. | String getCarrierName() | setCarrierName(String carrierName) |
| `NickName` | `String` | Required | Descriptive Name | String getNickName() | setNickName(String nickName) |
| `ServiceLevels` | [`List<ServiceLevelDetail>`](/doc/models/service-level-detail.md) | Required | Describes service details such as parcel weight limits. | List<ServiceLevelDetail> getServiceLevels() | setServiceLevels(List<ServiceLevelDetail> serviceLevels) |
| `Error` | [`RequestError`](/doc/models/request-error.md) | Optional | This information can be used to determine if an error has occurred when a request was processed. | RequestError getError() | setError(RequestError error) |

## Example (as JSON)

```json
{
  "carrierClientContractId": 190,
  "affillateName": "affillateName8",
  "carrierName": "carrierName2",
  "nickName": "nickName4",
  "serviceLevels": [
    {
      "carrierServiceLevelID": 34,
      "name": "name2",
      "parcelWeightLimit": 225.12,
      "isInternational": false
    },
    {
      "carrierServiceLevelID": 35,
      "name": "name3",
      "parcelWeightLimit": 225.13,
      "isInternational": true
    }
  ],
  "error": null
}
```

