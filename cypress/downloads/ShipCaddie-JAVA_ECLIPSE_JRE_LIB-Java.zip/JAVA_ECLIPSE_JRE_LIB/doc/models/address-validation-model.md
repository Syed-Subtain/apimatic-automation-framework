
# Address Validation Model

Model for the address validation

## Structure

`AddressValidationModel`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Address1` | `String` | Optional | Address Line 1 of the address | String getAddress1() | setAddress1(String address1) |
| `Address2` | `String` | Optional | Address Line 2 of the address | String getAddress2() | setAddress2(String address2) |
| `Province` | `String` | Optional | Province for the address | String getProvince() | setProvince(String province) |
| `ProvinceCode` | `String` | Optional | Code of the Province provided | String getProvinceCode() | setProvinceCode(String provinceCode) |
| `City` | `String` | Optional | City | String getCity() | setCity(String city) |
| `CountryCode` | `String` | Optional | The code of the country whose address is provided | String getCountryCode() | setCountryCode(String countryCode) |
| `PostalCode` | `String` | Optional | Postal code | String getPostalCode() | setPostalCode(String postalCode) |
| `Countryname` | `String` | Optional | Name of the country | String getCountryname() | setCountryname(String countryname) |
| `AddressTypeId` | [`AddressTypeIdEnum`](/doc/models/address-type-id-enum.md) | Optional | Type of address<br>Values :<br>- NotDefined<br>- Residential<br>- Commercial<br>- NotVerified<br>- Invalid | AddressTypeIdEnum getAddressTypeId() | setAddressTypeId(AddressTypeIdEnum addressTypeId) |
| `CompanyName` | `String` | Optional | Name of the organization/company | String getCompanyName() | setCompanyName(String companyName) |
| `CountryId` | `Integer` | Optional | Id of the country specified. | Integer getCountryId() | setCountryId(Integer countryId) |
| `AddressStatus` | `Boolean` | Optional | Status of the address | Boolean getAddressStatus() | setAddressStatus(Boolean addressStatus) |

## Example (as JSON)

```json
{
  "address1": null,
  "address2": null,
  "province": null,
  "provinceCode": null,
  "city": null,
  "countryCode": null,
  "postalCode": null,
  "countryname": null,
  "addressTypeId": null,
  "companyName": null,
  "countryId": null,
  "addressStatus": null
}
```

