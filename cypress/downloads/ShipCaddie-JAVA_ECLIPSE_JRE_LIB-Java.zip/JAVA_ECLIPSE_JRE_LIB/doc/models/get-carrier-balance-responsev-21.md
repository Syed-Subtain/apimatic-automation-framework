
# Get Carrier Balance Responsev 21

## Structure

`GetCarrierBalanceResponsev21`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Threshold` | `double` | Required | Account Threshold | double getThreshold() | setThreshold(double threshold) |
| `RechargeAmount` | `double` | Required | Account Recharge Amount | double getRechargeAmount() | setRechargeAmount(double rechargeAmount) |
| `Balance` | `double` | Required | Account Balance | double getBalance() | setBalance(double balance) |
| `Error` | [`RequestError`](/doc/models/request-error.md) | Optional | This information can be used to determine if an error has occurred when a request was processed. | RequestError getError() | setError(RequestError error) |

## Example (as JSON)

```json
{
  "threshold": 204.48,
  "rechargeAmount": 51.02,
  "balance": 26.24,
  "error": null
}
```

