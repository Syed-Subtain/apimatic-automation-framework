
# Shipping Cost Informationv 21

Cost details related to shipping.

## Structure

`ShippingCostInformationv21`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `ShipmentId` | `Integer` | Optional | Internal shipment identifier.<br>Read Only. | Integer getShipmentId() | setShipmentId(Integer shipmentId) |
| `OrderReferenceNumber` | `String` | Optional | Optional order reference tag that was set when adding a shipment or getting rates. | String getOrderReferenceNumber() | setOrderReferenceNumber(String orderReferenceNumber) |
| `ParcelChargeDetails` | [`List<ParcelChargeDetails>`](/doc/models/parcel-charge-details.md) | Optional | Shipping charges relating to individual parcels. | List<ParcelChargeDetails> getParcelChargeDetails() | setParcelChargeDetails(List<ParcelChargeDetails> parcelChargeDetails) |
| `ShippingChargeDetails` | [`List<CostDetailv21>`](/doc/models/cost-detailv-21.md) | Optional | Shipping charges relating to a shipment as a whole. | List<CostDetailv21> getShippingChargeDetails() | setShippingChargeDetails(List<CostDetailv21> shippingChargeDetails) |
| `TransitDaysMin` | `Integer` | Optional | The Days in transit as defined by the carrier for the service level chosen.<br>The number may or may not include non-business days. | Integer getTransitDaysMin() | setTransitDaysMin(Integer transitDaysMin) |
| `TransitDaysMax` | `Integer` | Optional | The Days in transit as defined by the carrier for the service level chosen.<br>The number may or may not include non-business days. | Integer getTransitDaysMax() | setTransitDaysMax(Integer transitDaysMax) |
| `TotalChargeAmount` | `Double` | Optional | - | Double getTotalChargeAmount() | setTotalChargeAmount(Double totalChargeAmount) |
| `TotalChargeAmount3pl` | `Double` | Optional | This is the sum of all accessorialCharges.chargeAmount3pl fields in all packages | Double getTotalChargeAmount3pl() | setTotalChargeAmount3pl(Double totalChargeAmount3pl) |
| `DeliveryDateTime` | `LocalDateTime` | Optional | - | LocalDateTime getDeliveryDateTime() | setDeliveryDateTime(LocalDateTime deliveryDateTime) |
| `IsDeliveryGuaranteed` | `Boolean` | Optional | - | Boolean getIsDeliveryGuaranteed() | setIsDeliveryGuaranteed(Boolean isDeliveryGuaranteed) |

## Example (as JSON)

```json
{
  "shipmentId": null,
  "orderReferenceNumber": null,
  "parcelChargeDetails": null,
  "shippingChargeDetails": null,
  "transitDaysMin": null,
  "transitDaysMax": null,
  "totalChargeAmount": null,
  "totalChargeAmount3pl": null,
  "deliveryDateTime": null,
  "isDeliveryGuaranteed": null
}
```

