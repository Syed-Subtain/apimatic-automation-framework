
# Update Email Notification Requestv 21

## Structure

`UpdateEmailNotificationRequestv21`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `AccessToken` | `String` | Required | Required.<br>An authorization token is necessary to call this method.<br><remarks><br>The token can be obtained by calling the GetToken or RefreshToken methods.<br></remarks> | String getAccessToken() | setAccessToken(String accessToken) |
| `AsClientId` | `Integer` | Optional | Optional.<br>When empty or null, this field is ignored.<br>When set, actions will be taken for the client specified by the id. | Integer getAsClientId() | setAsClientId(Integer asClientId) |
| `CarrierClientContractId` | `int` | Required | Required.<br>Turn email notifications on or off for the carrier specified by CarrierClientContractId. | int getCarrierClientContractId() | setCarrierClientContractId(int carrierClientContractId) |
| `NotifyByEmail` | `boolean` | Required | Required.<br>Set to true if you want to recieve email notifictions.  Set to false otherwise. | boolean getNotifyByEmail() | setNotifyByEmail(boolean notifyByEmail) |

## Example (as JSON)

```json
{
  "accessToken": "<YOUR ACCESS TOKEN>",
  "asClientId": 12,
  "carrierClientContractId": 19,
  "notifyByEmail": true
}
```

