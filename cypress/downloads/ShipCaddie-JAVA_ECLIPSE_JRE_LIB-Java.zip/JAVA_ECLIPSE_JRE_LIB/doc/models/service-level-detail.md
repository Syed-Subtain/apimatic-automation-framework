
# Service Level Detail

Details regarding shipping service methods and types.

## Structure

`ServiceLevelDetail`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `CarrierServiceLevelID` | `int` | Required | Service Level Identifier.  <br>This identifier is used in other methods such as Add Shipment. | int getCarrierServiceLevelID() | setCarrierServiceLevelID(int carrierServiceLevelID) |
| `Name` | `String` | Required | Descriptive Service Name | String getName() | setName(String name) |
| `ParcelWeightLimit` | `double` | Required | Maximum weight of a parcel for this service level.<br>Weight limit is in pounds - unless specified otherwise. | double getParcelWeightLimit() | setParcelWeightLimit(double parcelWeightLimit) |
| `IsInternational` | `boolean` | Required | When true, the service is meant for parcels sent out of the country. | boolean getIsInternational() | setIsInternational(boolean isInternational) |

## Example (as JSON)

```json
{
  "carrierServiceLevelID": 204,
  "name": "name0",
  "parcelWeightLimit": 58.9,
  "isInternational": false
}
```

