
# Key Values

## Structure

`KeyValues`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `LabelKey` | `String` | Optional | - | String getLabelKey() | setLabelKey(String labelKey) |
| `TrackingNumber` | `String` | Optional | - | String getTrackingNumber() | setTrackingNumber(String trackingNumber) |
| `PackageId` | `Integer` | Optional | - | Integer getPackageId() | setPackageId(Integer packageId) |

## Example (as JSON)

```json
{
  "labelKey": null,
  "trackingNumber": null,
  "packageId": null
}
```

