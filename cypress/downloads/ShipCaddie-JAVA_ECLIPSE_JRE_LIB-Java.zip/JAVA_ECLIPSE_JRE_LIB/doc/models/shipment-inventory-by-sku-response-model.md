
# Shipment Inventory by Sku Response Model

## Structure

`ShipmentInventoryBySkuResponseModel`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `ShipmentInventoryBySkuResponse` | [`List<ShipmentInventoryBySkuResponse>`](/doc/models/shipment-inventory-by-sku-response.md) | Optional | - | List<ShipmentInventoryBySkuResponse> getShipmentInventoryBySkuResponse() | setShipmentInventoryBySkuResponse(List<ShipmentInventoryBySkuResponse> shipmentInventoryBySkuResponse) |
| `Error` | [`RequestError`](/doc/models/request-error.md) | Optional | This information can be used to determine if an error has occurred when a request was processed. | RequestError getError() | setError(RequestError error) |

## Example (as JSON)

```json
{
  "shipmentInventoryBySku_Response": null,
  "error": null
}
```

