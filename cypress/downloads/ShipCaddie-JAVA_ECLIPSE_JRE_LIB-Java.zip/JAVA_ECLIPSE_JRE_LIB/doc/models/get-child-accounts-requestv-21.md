
# Get Child Accounts Requestv 21

## Structure

`GetChildAccountsRequestv21`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `AccessToken` | `String` | Optional | Required.<br>An authorization token is necessary to call this method.<br><remarks><br>The token can be obtained by calling the GetToken or RefreshToken methods.<br></remarks> | String getAccessToken() | setAccessToken(String accessToken) |

## Example (as JSON)

```json
{
  "accessToken": "<YOUR ACCESS TOKEN>"
}
```

