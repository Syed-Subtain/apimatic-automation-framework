
# Address Type Id 1 Enum

Id of the address type

## Enumeration

`AddressTypeId1Enum`

## Fields

| Name |
|  --- |
| `NotDefined` |
| `Residential` |
| `Commercial` |
| `NotVerified` |
| `Invalid` |
| `FailedAddress` |
| `UserVerified` |
| `Processing` |
| `Military` |
| `International` |
| `UsTerritory` |
| `PoBox` |

