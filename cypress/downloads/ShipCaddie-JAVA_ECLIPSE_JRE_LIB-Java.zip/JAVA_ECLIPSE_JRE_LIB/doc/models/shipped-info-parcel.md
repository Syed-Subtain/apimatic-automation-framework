
# Shipped Info Parcel

## Structure

`ShippedInfoParcel`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Cost` | `Double` | Optional | The cost of shipping the package | Double getCost() | setCost(Double cost) |
| `ReferenceField1` | `String` | Optional | Optional - Reference Field 1 | String getReferenceField1() | setReferenceField1(String referenceField1) |
| `ReferenceField2` | `String` | Optional | Optional - Reference Field 2 | String getReferenceField2() | setReferenceField2(String referenceField2) |
| `ReferenceField3` | `String` | Optional | Optional - Reference Field 3 | String getReferenceField3() | setReferenceField3(String referenceField3) |
| `WeightInPounds` | `Double` | Optional | Parcel Weight in Pounds. | Double getWeightInPounds() | setWeightInPounds(Double weightInPounds) |
| `LengthInInches` | `Double` | Optional | Length of one side of parcel in inches. | Double getLengthInInches() | setLengthInInches(Double lengthInInches) |
| `WidthInInches` | `Double` | Optional | Width of one side of parcel in inches. | Double getWidthInInches() | setWidthInInches(Double widthInInches) |
| `HeightInInches` | `Double` | Optional | Height of one side of parcel in inches. | Double getHeightInInches() | setHeightInInches(Double heightInInches) |
| `TrackingNumber` | `String` | Optional | The tracking number of the package. | String getTrackingNumber() | setTrackingNumber(String trackingNumber) |
| `Options` | [`ParcelOptions`](/doc/models/parcel-options.md) | Optional | Specifies additional parcel options such as COD and required Signatures. | ParcelOptions getOptions() | setOptions(ParcelOptions options) |
| `ParcelItems` | [`List<ParcelContent>`](/doc/models/parcel-content.md) | Optional | Type of parcel contents. | List<ParcelContent> getParcelItems() | setParcelItems(List<ParcelContent> parcelItems) |

## Example (as JSON)

```json
{
  "cost": null,
  "referenceField1": null,
  "referenceField2": null,
  "referenceField3": null,
  "weightInPounds": null,
  "lengthInInches": null,
  "widthInInches": null,
  "heightInInches": null,
  "trackingNumber": null,
  "options": null,
  "parcelItems": null
}
```

