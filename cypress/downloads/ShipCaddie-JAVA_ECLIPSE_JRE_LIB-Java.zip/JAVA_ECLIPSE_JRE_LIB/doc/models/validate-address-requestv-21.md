
# Validate Address Requestv 21

## Structure

`ValidateAddressRequestv21`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `AccessToken` | `String` | Required | Required.<br>An authorization token is necessary to call this method.<br><remarks><br>The token can be obtained by calling the GetToken or RefreshToken methods.<br></remarks> | String getAccessToken() | setAccessToken(String accessToken) |
| `AsClientId` | `Integer` | Optional | Optional.<br>When empty or null, this field is ignored.<br>When set, actions will be taken for the client specified by the id. | Integer getAsClientId() | setAsClientId(Integer asClientId) |
| `AddressToValidate` | [`Addressv21`](/doc/models/addressv-21.md) | Required | - | Addressv21 getAddressToValidate() | setAddressToValidate(Addressv21 addressToValidate) |

## Example (as JSON)

```json
{
  "accessToken": "<YOUR ACCESS TOKEN>",
  "asClientId": 14,
  "addressToValidate": {
    "address1": "2600 Executive Parkway",
    "address2": "Suite 160",
    "city": "Lehi",
    "countryCode": "US",
    "stateOrProvidence": "UT",
    "postalCode": "84043",
    "isResidential": false,
    "attentionOf": "Mr. Jones",
    "companyName": "iDrive Logistics",
    "email": "sales@idrivelogistics.com",
    "phoneNumber": "(888) 797-0929"
  }
}
```

