
# Shipment Information

All necessary shipping information

## Structure

`ShipmentInformation`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `OrderReferenceNumber` | `String` | Optional | Optional Reference number which can be used<br>to uniquely identify a shipment. | String getOrderReferenceNumber() | setOrderReferenceNumber(String orderReferenceNumber) |
| `DateShipped` | `LocalDateTime` | Required | Specifies the date of shipment. | LocalDateTime getDateShipped() | setDateShipped(LocalDateTime dateShipped) |
| `Options` | [`ShippingOptions`](/doc/models/shipping-options.md) | Optional | Billing and Custom Declaration Options for Shipping. | ShippingOptions getOptions() | setOptions(ShippingOptions options) |
| `CarrierClientContractId` | `int` | Required | Indicates which Carrier to use.<br>Obtained from GetCarrierServiceInformation. | int getCarrierClientContractId() | setCarrierClientContractId(int carrierClientContractId) |
| `CarrierServiceLevelId` | `int` | Required | Indicates which Carrier Service Level to use.<br>Obtained from GetCarrierServiceInformation. | int getCarrierServiceLevelId() | setCarrierServiceLevelId(int carrierServiceLevelId) |
| `AddressFrom` | [`ShipFromAddress`](/doc/models/ship-from-address.md) | Required | - | ShipFromAddress getAddressFrom() | setAddressFrom(ShipFromAddress addressFrom) |
| `AddressTo` | [`ShipToAddress`](/doc/models/ship-to-address.md) | Required | - | ShipToAddress getAddressTo() | setAddressTo(ShipToAddress addressTo) |
| `Parcels` | [`List<ParcelDetail>`](/doc/models/parcel-detail.md) | Required | Details of parcels to send. | List<ParcelDetail> getParcels() | setParcels(List<ParcelDetail> parcels) |

## Example (as JSON)

```json
{
  "orderReferenceNumber": null,
  "dateShipped": "2016-03-13T12:52:32.123Z",
  "options": null,
  "carrierClientContractId": 190,
  "carrierServiceLevelId": 224,
  "addressFrom": {
    "companyName": null,
    "email": null,
    "phoneNumber": null,
    "address1": null,
    "address2": null,
    "city": null,
    "stateOrProvince": null,
    "postalCode": null,
    "countryCode": null
  },
  "addressTo": {
    "attentionOf": null,
    "companyName": null,
    "email": null,
    "phoneNumber": null,
    "address1": null,
    "address2": null,
    "isResidential": null,
    "city": null,
    "stateOrProvince": null,
    "postalCode": null,
    "countryCode": null
  },
  "parcels": [
    {
      "referenceField1": null,
      "referenceField2": null,
      "referenceField3": null,
      "parcelID": null,
      "packagingId": null,
      "weightInPounds": 202.52,
      "lengthInInches": 9.24,
      "widthInInches": 82.84,
      "heightInInches": 210.62,
      "options": {
        "return": null,
        "insuranceAmount": null,
        "signature": null,
        "cod": null,
        "machinable": null,
        "holdForPickup": null
      },
      "parcelItems": null
    },
    {
      "referenceField1": null,
      "referenceField2": null,
      "referenceField3": null,
      "parcelID": null,
      "packagingId": null,
      "weightInPounds": 202.53,
      "lengthInInches": 9.25,
      "widthInInches": 82.83,
      "heightInInches": 210.63,
      "options": {
        "return": null,
        "insuranceAmount": null,
        "signature": null,
        "cod": null,
        "machinable": null,
        "holdForPickup": null
      },
      "parcelItems": null
    }
  ]
}
```

