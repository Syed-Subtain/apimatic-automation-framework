
# Security Token

A valid Token is necessary to get a response from an API method call.

## Structure

`SecurityToken`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `AccessToken` | `String` | Required | Use this authorization token when calling other API methods. | String getAccessToken() | setAccessToken(String accessToken) |
| `RefreshToken` | `String` | Required | Use the Refresh Token to obtain a new token after the Access Token has expired. | String getRefreshToken() | setRefreshToken(String refreshToken) |
| `RefreshTokenExpirationDate` | `LocalDateTime` | Required | After this time it will be neccessary to obtain a new token using a valid username and password by calling GetToken.<br>The time is expressed in Universal Time. (UTC) | LocalDateTime getRefreshTokenExpirationDate() | setRefreshTokenExpirationDate(LocalDateTime refreshTokenExpirationDate) |
| `AccessTokenExpirationDate` | `LocalDateTime` | Required | After this time a new token can be obtained by calling RefreshToken using a valid RefreshToken.<br>The time is expressed in Universal Time. (UTC) | LocalDateTime getAccessTokenExpirationDate() | setAccessTokenExpirationDate(LocalDateTime accessTokenExpirationDate) |
| `Error` | [`RequestError`](/doc/models/request-error.md) | Required | This information can be used to determine if an error has occurred when a request was processed. | RequestError getError() | setError(RequestError error) |

## Example (as JSON)

```json
{
  "accessToken": "accessToken2",
  "refreshToken": "refreshToken2",
  "refreshTokenExpirationDate": "2016-03-13T12:52:32.123Z",
  "accessTokenExpirationDate": "2016-03-13T12:52:32.123Z",
  "error": {
    "details": null,
    "hasError": false
  }
}
```

