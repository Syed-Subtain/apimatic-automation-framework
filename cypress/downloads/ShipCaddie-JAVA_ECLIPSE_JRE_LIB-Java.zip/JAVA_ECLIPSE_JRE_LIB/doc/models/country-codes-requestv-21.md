
# Country Codes Requestv 21

## Structure

`CountryCodesRequestv21`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `AccessToken` | `String` | Optional | Required.<br>An authorization token is necessary to call this method.<br><remarks><br>The token can be obtained by calling the GetToken or RefreshToken methods.<br></remarks> | String getAccessToken() | setAccessToken(String accessToken) |
| `AsClientId` | `Integer` | Optional | Optional.<br>When empty or null, this field is ignored.<br>When set, actions will be taken for the client specified by the id. | Integer getAsClientId() | setAsClientId(Integer asClientId) |

## Example (as JSON)

```json
{
  "accessToken": "<YOUR ACCESS TOKEN>",
  "asClientId": 14
}
```

