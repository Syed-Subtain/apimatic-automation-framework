
# Packaging Detail

Carrier Packaging Specifications

## Structure

`PackagingDetail`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `ParcelId` | `String` | Optional | This ID can be used when specifing a Parcel type. | String getParcelId() | setParcelId(String parcelId) |
| `Name` | `String` | Optional | Parcel Type | String getName() | setName(String name) |
| `Description` | `String` | Optional | Parcel Description | String getDescription() | setDescription(String description) |
| `LengthInInches` | `Double` | Optional | Length of one side of parcel in inches. | Double getLengthInInches() | setLengthInInches(Double lengthInInches) |
| `WidthInInches` | `Double` | Optional | Width of one side of parcel in inches. | Double getWidthInInches() | setWidthInInches(Double widthInInches) |
| `HeightInInches` | `Double` | Optional | Height of one side of parcel in inches. | Double getHeightInInches() | setHeightInInches(Double heightInInches) |
| `WeightLimit` | `Double` | Optional | Carrier Weight limit for the parcel | Double getWeightLimit() | setWeightLimit(Double weightLimit) |
| `PackagingWeight` | `Double` | Optional | Container weight | Double getPackagingWeight() | setPackagingWeight(Double packagingWeight) |

## Example (as JSON)

```json
{
  "parcelId": null,
  "name": null,
  "description": null,
  "lengthInInches": null,
  "widthInInches": null,
  "heightInInches": null,
  "weightLimit": null,
  "packagingWeight": null
}
```

