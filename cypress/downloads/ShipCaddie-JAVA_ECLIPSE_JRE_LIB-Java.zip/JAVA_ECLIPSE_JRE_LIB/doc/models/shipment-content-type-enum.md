
# Shipment Content Type Enum

Indicates the type of content that is in the parcels.
Will be used for customs declarations if shipping internationally.

## Enumeration

`ShipmentContentTypeEnum`

## Fields

| Name |
|  --- |
| `NOTAPPLICABLE` |
| `CONTENTTYPESAMPLE` |
| `CONTENTTYPEDOCUMENTS` |
| `CONTENTTYPEGIFT` |
| `CONTENTTYPEMERCHANDISE` |
| `CONTENTTYPERETURNEDGOODS` |
| `CONTENTTYPEOTHER` |

