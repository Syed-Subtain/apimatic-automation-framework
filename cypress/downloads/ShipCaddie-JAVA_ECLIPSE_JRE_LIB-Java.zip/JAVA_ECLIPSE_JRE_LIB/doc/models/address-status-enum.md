
# Address Status Enum

Status of the address passed

## Enumeration

`AddressStatusEnum`

## Fields

| Name |
|  --- |
| `NotCorrected` |
| `Corrected` |

