
# Shipping Information

Shipment Information used to request a rate.

## Structure

`ShippingInformation`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `CarrierClientContractId` | `Integer` | Optional | Specifies the Carrier for which to check rates. | Integer getCarrierClientContractId() | setCarrierClientContractId(Integer carrierClientContractId) |
| `ServiceLevelId` | `Integer` | Optional | Specifies the ServiceLevel to check. | Integer getServiceLevelId() | setServiceLevelId(Integer serviceLevelId) |
| `DateShipped` | `LocalDateTime` | Optional | Specifies the date the packages will be shipped. | LocalDateTime getDateShipped() | setDateShipped(LocalDateTime dateShipped) |
| `Options` | [`CustomsOptions`](/doc/models/customs-options.md) | Optional | - | CustomsOptions getOptions() | setOptions(CustomsOptions options) |
| `AddressFrom` | [`ShipFromAddress`](/doc/models/ship-from-address.md) | Optional | - | ShipFromAddress getAddressFrom() | setAddressFrom(ShipFromAddress addressFrom) |
| `AddressTo` | [`ShipToAddress`](/doc/models/ship-to-address.md) | Optional | - | ShipToAddress getAddressTo() | setAddressTo(ShipToAddress addressTo) |
| `Parcels` | [`List<ParcelInformation>`](/doc/models/parcel-information.md) | Optional | Details of parcels to send. | List<ParcelInformation> getParcels() | setParcels(List<ParcelInformation> parcels) |

## Example (as JSON)

```json
{
  "carrierClientContractId": null,
  "serviceLevelId": null,
  "dateShipped": null,
  "options": null,
  "addressFrom": null,
  "addressTo": null,
  "parcels": null
}
```

