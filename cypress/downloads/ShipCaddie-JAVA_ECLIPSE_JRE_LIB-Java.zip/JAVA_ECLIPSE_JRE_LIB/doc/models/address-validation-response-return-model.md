
# Address Validation Response Return Model

The data for return dataset

## Structure

`AddressValidationResponseReturnModel`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Data` | [`AddressValidatationResponseModel`](/doc/models/address-validatation-response-model.md) | Optional | Address Validation Response Model | AddressValidatationResponseModel getData() | setData(AddressValidatationResponseModel data) |
| `Success` | `Boolean` | Optional | Flag to indicate success or failure | Boolean getSuccess() | setSuccess(Boolean success) |
| `Error` | [`ApiErrorModel`](/doc/models/api-error-model.md) | Optional | The error model that is used throughout all the api's | ApiErrorModel getError() | setError(ApiErrorModel error) |
| `V2Error` | [`RequestError`](/doc/models/request-error.md) | Optional | This information can be used to determine if an error has occurred when a request was processed. | RequestError getV2Error() | setV2Error(RequestError v2Error) |

## Example (as JSON)

```json
{
  "data": null,
  "success": null,
  "error": null,
  "v2Error": null
}
```

