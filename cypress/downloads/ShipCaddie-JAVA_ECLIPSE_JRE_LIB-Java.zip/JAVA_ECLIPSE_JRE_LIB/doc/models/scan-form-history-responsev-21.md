
# Scan Form History Responsev 21

## Structure

`ScanFormHistoryResponsev21`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Error` | [`RequestError`](/doc/models/request-error.md) | Optional | This information can be used to determine if an error has occurred when a request was processed. | RequestError getError() | setError(RequestError error) |
| `ScanFormList` | [`List<ScanFormModel>`](/doc/models/scan-form-model.md) | Optional | List of ScanForm Data | List<ScanFormModel> getScanFormList() | setScanFormList(List<ScanFormModel> scanFormList) |

## Example (as JSON)

```json
{
  "error": null,
  "scanFormList": null
}
```

