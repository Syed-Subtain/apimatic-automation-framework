
# Parcel Information

Details of parcels to send.

## Structure

`ParcelInformation`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `PackagingId` | `String` | Optional | - | String getPackagingId() | setPackagingId(String packagingId) |
| `WeightInPounds` | `Double` | Optional | Parcel Weight in Pounds.<br>If the weight is a fraction of a pound<br>still use pounds - not ounces. | Double getWeightInPounds() | setWeightInPounds(Double weightInPounds) |
| `LengthInInches` | `Double` | Optional | Length of one side of parcel in inches. | Double getLengthInInches() | setLengthInInches(Double lengthInInches) |
| `WidthInInches` | `Double` | Optional | Width of one side of parcel in inches. | Double getWidthInInches() | setWidthInInches(Double widthInInches) |
| `HeightInInches` | `Double` | Optional | Height of one side of parcel in inches. | Double getHeightInInches() | setHeightInInches(Double heightInInches) |
| `Options` | [`ParcelOptions`](/doc/models/parcel-options.md) | Optional | Specifies additional parcel options such as COD and required Signatures. | ParcelOptions getOptions() | setOptions(ParcelOptions options) |

## Example (as JSON)

```json
{
  "packagingId": null,
  "weightInPounds": null,
  "lengthInInches": null,
  "widthInInches": null,
  "heightInInches": null,
  "options": null
}
```

