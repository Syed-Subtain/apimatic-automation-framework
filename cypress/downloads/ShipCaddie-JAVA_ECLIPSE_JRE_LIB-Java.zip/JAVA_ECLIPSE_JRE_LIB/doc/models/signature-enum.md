
# Signature Enum

Indicates if a signature is required,
and if so what type of signature should be used.

## Enumeration

`SignatureEnum`

## Fields

| Name |
|  --- |
| `NOTAPPLICABLE` |
| `SIGNATUREADULT` |
| `SIGNATUREADULTRESTRICTED` |
| `SIGNATUREREQUIRED` |
| `SIGNATURENOREQUIRED` |
| `SIGNATUREDIRECT` |
| `SIGNATUREINDIRECT` |

