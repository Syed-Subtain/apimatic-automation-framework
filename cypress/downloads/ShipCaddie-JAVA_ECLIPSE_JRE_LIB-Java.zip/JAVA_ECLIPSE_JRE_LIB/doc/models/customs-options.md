
# Customs Options

## Structure

`CustomsOptions`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `IsAPOFPODPOUSTerritory` | `Boolean` | Optional | Set this to true if shipping to:<br><br>* Army Post Office<br>* Fleet Post Office<br>* Diplomatic Post Office<br>* US Territories<br><br>Default value is false. | Boolean getIsAPOFPODPOUSTerritory() | setIsAPOFPODPOUSTerritory(Boolean isAPOFPODPOUSTerritory) |
| `IsInternationalShipment` | `Boolean` | Optional | Specifies if this shipment is an international shipment.<br><br>Default is false. | Boolean getIsInternationalShipment() | setIsInternationalShipment(Boolean isInternationalShipment) |
| `ShipmentContentType` | [`ShipmentContentTypeEnum`](/doc/models/shipment-content-type-enum.md) | Optional | Indicates the type of content that is in the parcels.<br>Will be used for customs declarations if shipping internationally. | ShipmentContentTypeEnum getShipmentContentType() | setShipmentContentType(ShipmentContentTypeEnum shipmentContentType) |

## Example (as JSON)

```json
{
  "isAPO_FPO_DPO_USTerritory": null,
  "isInternationalShipment": null,
  "shipmentContentType": null
}
```

