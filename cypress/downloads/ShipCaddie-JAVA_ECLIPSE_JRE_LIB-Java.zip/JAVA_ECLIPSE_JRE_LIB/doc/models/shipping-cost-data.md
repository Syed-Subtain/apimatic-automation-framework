
# Shipping Cost Data

## Structure

`ShippingCostData`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `ShippingCost` | [`ShippingCostInformationv21`](/doc/models/shipping-cost-informationv-21.md) | Optional | Cost details related to shipping. | ShippingCostInformationv21 getShippingCost() | setShippingCost(ShippingCostInformationv21 shippingCost) |
| `Error` | [`RequestError`](/doc/models/request-error.md) | Optional | This information can be used to determine if an error has occurred when a request was processed. | RequestError getError() | setError(RequestError error) |

## Example (as JSON)

```json
{
  "shippingCost": null,
  "error": null
}
```

