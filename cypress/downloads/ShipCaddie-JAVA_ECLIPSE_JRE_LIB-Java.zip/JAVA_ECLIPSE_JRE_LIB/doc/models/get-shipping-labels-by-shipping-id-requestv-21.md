
# Get Shipping Labels by Shipping ID Requestv 21

## Structure

`GetShippingLabelsByShippingIDRequestv21`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `AccessToken` | `String` | Required | Required.<br>An authorization token is necessary to call this method.<br><remarks><br>The token can be obtained by calling the GetToken or RefreshToken methods.<br></remarks> | String getAccessToken() | setAccessToken(String accessToken) |
| `AsClientId` | `Integer` | Optional | Optional.<br>When empty or null, this field is ignored.<br>When set, actions will be taken for the client specified by the id. | Integer getAsClientId() | setAsClientId(Integer asClientId) |
| `ShipmentID` | `int` | Required | Shipment identifier. | int getShipmentID() | setShipmentID(int shipmentID) |
| `PrintFormat` | [`PrintFormatEnum`](/doc/models/print-format-enum.md) | Required | Format used for printing labels. | PrintFormatEnum getPrintFormat() | setPrintFormat(PrintFormatEnum printFormat) |
| `CertifyTestOverride` | [`CertifyTestOverrideEnum`](/doc/models/certify-test-override-enum.md) | Optional | CertifyTestOverride : Force a Label to overriding what is in the contract | CertifyTestOverrideEnum getCertifyTestOverride() | setCertifyTestOverride(CertifyTestOverrideEnum certifyTestOverride) |

## Example (as JSON)

```json
{
  "accessToken": "<YOUR ACCESS TOKEN>",
  "asClientId": 12,
  "shipmentID": 19,
  "printFormat": "PNG_4x6",
  "certifyTestOverride": "Contract"
}
```

