
# Parcel Detail

Details of parcels to send.

## Structure

`ParcelDetail`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `ReferenceField1` | `String` | Optional | Optional - Reference Field 1 | String getReferenceField1() | setReferenceField1(String referenceField1) |
| `ReferenceField2` | `String` | Optional | Optional - Reference Field 2 | String getReferenceField2() | setReferenceField2(String referenceField2) |
| `ReferenceField3` | `String` | Optional | Optional - Reference Field 3 | String getReferenceField3() | setReferenceField3(String referenceField3) |
| `ParcelID` | `String` | Optional | A unique ID used to match<br>parcels with cost details.<br>This will be set automatically<br>if a value is not supplied. | String getParcelID() | setParcelID(String parcelID) |
| `PackagingId` | `String` | Optional | - | String getPackagingId() | setPackagingId(String packagingId) |
| `WeightInPounds` | `double` | Required | Parcel Weight in Pounds.<br>If the weight is a fraction of a pound<br>still use pounds - not ounces. | double getWeightInPounds() | setWeightInPounds(double weightInPounds) |
| `LengthInInches` | `double` | Required | Length of one side of parcel in inches. | double getLengthInInches() | setLengthInInches(double lengthInInches) |
| `WidthInInches` | `double` | Required | Width of one side of parcel in inches. | double getWidthInInches() | setWidthInInches(double widthInInches) |
| `HeightInInches` | `double` | Required | Height of one side of parcel in inches. | double getHeightInInches() | setHeightInInches(double heightInInches) |
| `Options` | [`ParcelOptions`](/doc/models/parcel-options.md) | Required | Specifies additional parcel options such as COD and required Signatures. | ParcelOptions getOptions() | setOptions(ParcelOptions options) |
| `ParcelItems` | [`List<ParcelContent>`](/doc/models/parcel-content.md) | Optional | Type of parcel contents.<br>This is required for some destinations. | List<ParcelContent> getParcelItems() | setParcelItems(List<ParcelContent> parcelItems) |

## Example (as JSON)

```json
{
  "referenceField1": null,
  "referenceField2": null,
  "referenceField3": null,
  "parcelID": null,
  "packagingId": null,
  "weightInPounds": 168.18,
  "lengthInInches": 230.9,
  "widthInInches": 117.18,
  "heightInInches": 176.28,
  "options": {
    "return": null,
    "insuranceAmount": null,
    "signature": null,
    "cod": null,
    "machinable": null,
    "holdForPickup": null
  },
  "parcelItems": null
}
```

