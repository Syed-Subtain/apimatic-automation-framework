
# Credentials

Credentials are used to obtain a Security Token.

## Structure

`Credentials`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `UserName` | `String` | Required | Required.<br>Username as supplied by ShipCaddie. | String getUserName() | setUserName(String userName) |
| `Password` | `String` | Required | Required.<br>Associated password. | String getPassword() | setPassword(String password) |

## Example (as JSON)

```json
{
  "userName": "<Your UserName>",
  "password": "<Your Password>"
}
```

