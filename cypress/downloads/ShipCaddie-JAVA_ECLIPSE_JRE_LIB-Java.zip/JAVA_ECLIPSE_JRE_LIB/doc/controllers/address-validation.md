# Address Validation

```java
AddressValidationController addressValidationController = client.getAddressValidationController();
```

## Class Name

`AddressValidationController`


# Validate Address

Use this function to validate an address.

```java
CompletableFuture<ValidateAddressResponsev21> validateAddressAsync(
    final ValidateAddressRequestv21 input)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `input` | [`ValidateAddressRequestv21`](/doc/models/validate-address-requestv-21.md) | Body, Optional | - |

## Response Type

[`ValidateAddressResponsev21`](/doc/models/validate-address-responsev-21.md)

## Example Usage

```java
ValidateAddressRequestv21 input = new ValidateAddressRequestv21();
input.setAccessToken("<YOUR ACCESS TOKEN>");
input.setAddressToValidate(new Addressv21());
input.getAddressToValidate().setAddress1("2600 Executive Parkway");
input.getAddressToValidate().setCity("Lehi");
input.getAddressToValidate().setCountryCode("US");
input.getAddressToValidate().setStateOrProvidence("UT");
input.getAddressToValidate().setPostalCode("84043");
input.getAddressToValidate().setAddress2("Suite 160");
input.getAddressToValidate().setIsResidential(false);
input.getAddressToValidate().setAttentionOf("Mr. Jones");
input.getAddressToValidate().setCompanyName("iDrive Logistics");
input.getAddressToValidate().setEmail("sales@idrivelogistics.com");
input.getAddressToValidate().setPhoneNumber("(888) 797-0929");
input.setAsClientId(14);

addressValidationController.validateAddressAsync(input).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

## Example Response *(as JSON)*

```json
{
  "addressIsValidated": true,
  "validationMessages": [
    {
      "code": "Default Match",
      "message": "Street address (directional or suffix only) was corrected to validate the address. Please check this correction prior to using address."
    }
  ],
  "validatedAddress": {
    "address1": "2600 W Executive Pkwy Ste 160",
    "address2": "",
    "city": "LEHI",
    "countryCode": "US",
    "stateOrProvidence": "UT",
    "postalCode": "84043-3987",
    "isResidential": false,
    "attentionOf": "Mr. Jones",
    "companyName": "iDrive Logistics",
    "email": "sales@idrivelogistics.com",
    "phoneNumber": "8887970929"
  },
  "error": {
    "details": [],
    "hasError": false
  }
}
```

