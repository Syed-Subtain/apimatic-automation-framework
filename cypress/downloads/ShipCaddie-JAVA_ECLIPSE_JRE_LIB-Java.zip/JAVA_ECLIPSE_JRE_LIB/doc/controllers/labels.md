# Labels

```java
LabelsController labelsController = client.getLabelsController();
```

## Class Name

`LabelsController`

## Methods

* [Get Labels by Shipping ID With Cost](/doc/controllers/labels.md#get-labels-by-shipping-id-with-cost)
* [Void Label](/doc/controllers/labels.md#void-label)
* [Get Shipping Labels by Shipping ID](/doc/controllers/labels.md#get-shipping-labels-by-shipping-id)
* [Get Shipping Labels](/doc/controllers/labels.md#get-shipping-labels)
* [Get Label With Cost](/doc/controllers/labels.md#get-label-with-cost)


# Get Labels by Shipping ID With Cost

The labels are represented by a base 64 string.

```java
CompletableFuture<LabelInformationWithCost> getLabelsByShippingIDWithCostAsync(
    final GetShippingLabelsByShippingIDRequestv21 input)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `input` | [`GetShippingLabelsByShippingIDRequestv21`](/doc/models/get-shipping-labels-by-shipping-id-requestv-21.md) | Body, Optional | - |

## Response Type

[`LabelInformationWithCost`](/doc/models/label-information-with-cost.md)

## Example Usage

```java
GetShippingLabelsByShippingIDRequestv21 input = new GetShippingLabelsByShippingIDRequestv21();
input.setAccessToken("<YOUR ACCESS TOKEN>");
input.setShipmentID(19);
input.setPrintFormat(PrintFormatEnum.PNG_4X6);
input.setAsClientId(12);
input.setCertifyTestOverride(CertifyTestOverrideEnum.CONTRACT);

labelsController.getLabelsByShippingIDWithCostAsync(input).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```


# Void Label

In some conditions - such as already shipped parcels - the labels will not be voided.

```java
CompletableFuture<VoidLabelResponsev21> voidLabelAsync(
    final VoidLabelRequestv21 input)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `input` | [`VoidLabelRequestv21`](/doc/models/void-label-requestv-21.md) | Body, Optional | - |

## Response Type

[`VoidLabelResponsev21`](/doc/models/void-label-responsev-21.md)

## Example Usage

```java
VoidLabelRequestv21 input = new VoidLabelRequestv21();
input.setAccessToken("<YOUR ACCESS TOKEN>");
input.setLabelKey("329058_340709_shp_dfc02221ff5e4b78a45558ef474b6713");
input.setAsClientId(12);

labelsController.voidLabelAsync(input).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

## Example Response *(as JSON)*

```json
{
  "trackingNumber": "9405536895239111999004",
  "error": {
    "details": [],
    "hasError": false
  }
}
```


# Get Shipping Labels by Shipping ID

The labels are represented by a base 64 string.

```java
CompletableFuture<LabelInformation> getShippingLabelsByShippingIDAsync(
    final GetShippingLabelsByShippingIDRequestv21 input)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `input` | [`GetShippingLabelsByShippingIDRequestv21`](/doc/models/get-shipping-labels-by-shipping-id-requestv-21.md) | Body, Optional | - |

## Response Type

[`LabelInformation`](/doc/models/label-information.md)

## Example Usage

```java
GetShippingLabelsByShippingIDRequestv21 input = new GetShippingLabelsByShippingIDRequestv21();
input.setAccessToken("<YOUR ACCESS TOKEN>");
input.setShipmentID(19);
input.setPrintFormat(PrintFormatEnum.PNG_4X6);
input.setAsClientId(12);
input.setCertifyTestOverride(CertifyTestOverrideEnum.CONTRACT);

labelsController.getShippingLabelsByShippingIDAsync(input).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```


# Get Shipping Labels

The labels are represented by a base 64 string.

```java
CompletableFuture<LabelInformation> getShippingLabelsAsync(
    final GetShippingLabelsRequestv21 input)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `input` | [`GetShippingLabelsRequestv21`](/doc/models/get-shipping-labels-requestv-21.md) | Body, Optional | - |

## Response Type

[`LabelInformation`](/doc/models/label-information.md)

## Example Usage

```java
GetShippingLabelsRequestv21 input = new GetShippingLabelsRequestv21();
input.setAccessToken("<YOUR ACCESS TOKEN>");
input.setPrintFormat(PrintFormatEnum.PNG_4X6);
input.setAsClientId(12);
input.setShipment(new ShipmentInformation());
input.getShipment().setDateShipped(LocalDateTime.parse("2020-12-23T23:54:10.3117094Z", DateTimeFormatter.ISO_DATE_TIME));
input.getShipment().setCarrierClientContractId(2404);
input.getShipment().setCarrierServiceLevelId(1115);
input.getShipment().setAddressFrom(new ShipFromAddress());
input.getShipment().getAddressFrom().setCompanyName("iDrive Logistics");
input.getShipment().getAddressFrom().setEmail("sales@idrivelogistics.com");
input.getShipment().getAddressFrom().setPhoneNumber("(888) 797-0929");
input.getShipment().getAddressFrom().setAddress1("2600 Executive Pkwy #160");
input.getShipment().getAddressFrom().setAddress2("");
input.getShipment().getAddressFrom().setCity("Lehi");
input.getShipment().getAddressFrom().setStateOrProvince("UT");
input.getShipment().getAddressFrom().setPostalCode("84043");
input.getShipment().getAddressFrom().setCountryCode("US");
input.getShipment().setAddressTo(new ShipToAddress());
input.getShipment().getAddressTo().setAttentionOf("Mr. Jones");
input.getShipment().getAddressTo().setCompanyName("iDrive Logistics");
input.getShipment().getAddressTo().setEmail("sales@idrivelogistics.com");
input.getShipment().getAddressTo().setPhoneNumber("(888) 797-0929");
input.getShipment().getAddressTo().setAddress1("2605 Executive Pkwy #160");
input.getShipment().getAddressTo().setAddress2("");
input.getShipment().getAddressTo().setIsResidential(false);
input.getShipment().getAddressTo().setCity("Lehi");
input.getShipment().getAddressTo().setStateOrProvince("UT");
input.getShipment().getAddressTo().setPostalCode("84043");
input.getShipment().getAddressTo().setCountryCode("US");
input.getShipment().setParcels(new LinkedList<>());

ParcelDetail inputShipmentParcels0 = new ParcelDetail();
inputShipmentParcels0.setWeightInPounds(0.4);
inputShipmentParcels0.setLengthInInches(5);
inputShipmentParcels0.setWidthInInches(4);
inputShipmentParcels0.setHeightInInches(12);
inputShipmentParcels0.setOptions(new ParcelOptions());
inputShipmentParcels0.getOptions().setReturn(ReturnEnum.NOT_APPLICABLE);
inputShipmentParcels0.getOptions().setInsuranceAmount(0);
inputShipmentParcels0.getOptions().setSignature(SignatureEnum.NOT_APPLICABLE);
inputShipmentParcels0.getOptions().setCod(new CODOptions());
inputShipmentParcels0.getOptions().getCod().setCodType(CodTypeEnum.NOT_APPLICABLE);
inputShipmentParcels0.getOptions().getCod().setCodAmount(0);
inputShipmentParcels0.setReferenceField1("1");
inputShipmentParcels0.setReferenceField2("");
inputShipmentParcels0.setReferenceField3("");
inputShipmentParcels0.setParcelID("1");
inputShipmentParcels0.setPackagingId("");
inputShipmentParcels0.setParcelItems(new LinkedList<>());

ParcelContent inputShipmentParcels0ParcelItems0 = new ParcelContent();
inputShipmentParcels0ParcelItems0.setName("chocolate");
inputShipmentParcels0ParcelItems0.setQuantity(7);
inputShipmentParcels0ParcelItems0.setPrice(1.03);
inputShipmentParcels0ParcelItems0.setWeightInPounds(0.5);
inputShipmentParcels0ParcelItems0.setOriginCountry("US");
inputShipmentParcels0ParcelItems0.setSku("none");
inputShipmentParcels0ParcelItems0.setDescription("candy");
inputShipmentParcels0ParcelItems0.setHarmonizeCode("");
inputShipmentParcels0.getParcelItems().add(inputShipmentParcels0ParcelItems0);

input.getShipment().getParcels().add(inputShipmentParcels0);

input.getShipment().setOrderReferenceNumber("test order");
input.getShipment().setOptions(new ShippingOptions());
input.getShipment().getOptions().setIsAPOFPODPOUSTerritory(false);
input.getShipment().getOptions().setIsInternationalShipment(false);
input.getShipment().getOptions().setBilling(new BillingOptions());
input.getShipment().getOptions().getBilling().setShippingPaidBy(ShippingPaidByEnum.NOT_APPLICABLE);
input.getShipment().getOptions().getBilling().setDutiesPaidBy(DutiesPaidByEnum.NOT_APPLICABLE);
input.getShipment().getOptions().getBilling().setAccountNumber("");
input.getShipment().getOptions().getBilling().setPostalCode("");
input.getShipment().getOptions().getBilling().setCountryAlpha2Code("");
input.getShipment().getOptions().setShipmentContentType(ShipmentContentTypeEnum.CONTENT_TYPE_SAMPLE);
input.setCertifyTestOverride(CertifyTestOverrideEnum.CONTRACT);
input.setImageRotation(ImageRotationEnum.ROTATENONEFLIPNONE);

labelsController.getShippingLabelsAsync(input).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```


# Get Label With Cost

The labels are represented by a base 64 string.

```java
CompletableFuture<LabelInformationWithCost> getLabelWithCostAsync(
    final GetShippingLabelsRequestv21 input)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `input` | [`GetShippingLabelsRequestv21`](/doc/models/get-shipping-labels-requestv-21.md) | Body, Optional | - |

## Response Type

[`LabelInformationWithCost`](/doc/models/label-information-with-cost.md)

## Example Usage

```java
GetShippingLabelsRequestv21 input = new GetShippingLabelsRequestv21();
input.setAccessToken("<YOUR ACCESS TOKEN>");
input.setPrintFormat(PrintFormatEnum.PNG_4X6);
input.setAsClientId(12);
input.setShipment(new ShipmentInformation());
input.getShipment().setDateShipped(LocalDateTime.parse("2020-12-23T23:54:10.3117094Z", DateTimeFormatter.ISO_DATE_TIME));
input.getShipment().setCarrierClientContractId(2404);
input.getShipment().setCarrierServiceLevelId(1115);
input.getShipment().setAddressFrom(new ShipFromAddress());
input.getShipment().getAddressFrom().setCompanyName("iDrive Logistics");
input.getShipment().getAddressFrom().setEmail("sales@idrivelogistics.com");
input.getShipment().getAddressFrom().setPhoneNumber("(888) 797-0929");
input.getShipment().getAddressFrom().setAddress1("2600 Executive Pkwy #160");
input.getShipment().getAddressFrom().setAddress2("");
input.getShipment().getAddressFrom().setCity("Lehi");
input.getShipment().getAddressFrom().setStateOrProvince("UT");
input.getShipment().getAddressFrom().setPostalCode("84043");
input.getShipment().getAddressFrom().setCountryCode("US");
input.getShipment().setAddressTo(new ShipToAddress());
input.getShipment().getAddressTo().setAttentionOf("Mr. Jones");
input.getShipment().getAddressTo().setCompanyName("iDrive Logistics");
input.getShipment().getAddressTo().setEmail("sales@idrivelogistics.com");
input.getShipment().getAddressTo().setPhoneNumber("(888) 797-0929");
input.getShipment().getAddressTo().setAddress1("2605 Executive Pkwy #160");
input.getShipment().getAddressTo().setAddress2("");
input.getShipment().getAddressTo().setIsResidential(false);
input.getShipment().getAddressTo().setCity("Lehi");
input.getShipment().getAddressTo().setStateOrProvince("UT");
input.getShipment().getAddressTo().setPostalCode("84043");
input.getShipment().getAddressTo().setCountryCode("US");
input.getShipment().setParcels(new LinkedList<>());

ParcelDetail inputShipmentParcels0 = new ParcelDetail();
inputShipmentParcels0.setWeightInPounds(0.4);
inputShipmentParcels0.setLengthInInches(5);
inputShipmentParcels0.setWidthInInches(4);
inputShipmentParcels0.setHeightInInches(12);
inputShipmentParcels0.setOptions(new ParcelOptions());
inputShipmentParcels0.getOptions().setReturn(ReturnEnum.NOT_APPLICABLE);
inputShipmentParcels0.getOptions().setInsuranceAmount(0);
inputShipmentParcels0.getOptions().setSignature(SignatureEnum.NOT_APPLICABLE);
inputShipmentParcels0.getOptions().setCod(new CODOptions());
inputShipmentParcels0.getOptions().getCod().setCodType(CodTypeEnum.NOT_APPLICABLE);
inputShipmentParcels0.getOptions().getCod().setCodAmount(0);
inputShipmentParcels0.setReferenceField1("1");
inputShipmentParcels0.setReferenceField2("");
inputShipmentParcels0.setReferenceField3("");
inputShipmentParcels0.setParcelID("1");
inputShipmentParcels0.setPackagingId("");
inputShipmentParcels0.setParcelItems(new LinkedList<>());

ParcelContent inputShipmentParcels0ParcelItems0 = new ParcelContent();
inputShipmentParcels0ParcelItems0.setName("chocolate");
inputShipmentParcels0ParcelItems0.setQuantity(7);
inputShipmentParcels0ParcelItems0.setPrice(1.03);
inputShipmentParcels0ParcelItems0.setWeightInPounds(0.5);
inputShipmentParcels0ParcelItems0.setOriginCountry("US");
inputShipmentParcels0ParcelItems0.setSku("none");
inputShipmentParcels0ParcelItems0.setDescription("candy");
inputShipmentParcels0ParcelItems0.setHarmonizeCode("");
inputShipmentParcels0.getParcelItems().add(inputShipmentParcels0ParcelItems0);

input.getShipment().getParcels().add(inputShipmentParcels0);

input.getShipment().setOrderReferenceNumber("test order");
input.getShipment().setOptions(new ShippingOptions());
input.getShipment().getOptions().setIsAPOFPODPOUSTerritory(false);
input.getShipment().getOptions().setIsInternationalShipment(false);
input.getShipment().getOptions().setBilling(new BillingOptions());
input.getShipment().getOptions().getBilling().setShippingPaidBy(ShippingPaidByEnum.NOT_APPLICABLE);
input.getShipment().getOptions().getBilling().setDutiesPaidBy(DutiesPaidByEnum.NOT_APPLICABLE);
input.getShipment().getOptions().getBilling().setAccountNumber("");
input.getShipment().getOptions().getBilling().setPostalCode("");
input.getShipment().getOptions().getBilling().setCountryAlpha2Code("");
input.getShipment().getOptions().setShipmentContentType(ShipmentContentTypeEnum.CONTENT_TYPE_SAMPLE);
input.setCertifyTestOverride(CertifyTestOverrideEnum.CONTRACT);
input.setImageRotation(ImageRotationEnum.ROTATENONEFLIPNONE);

labelsController.getLabelWithCostAsync(input).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

