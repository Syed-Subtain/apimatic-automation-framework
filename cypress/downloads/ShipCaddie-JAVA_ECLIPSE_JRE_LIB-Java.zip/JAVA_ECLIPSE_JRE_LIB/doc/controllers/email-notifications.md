# Email Notifications

```java
EmailNotificationsController emailNotificationsController = client.getEmailNotificationsController();
```

## Class Name

`EmailNotificationsController`


# Update Email Notification

Email notifications can be turned on or off for each carrier.

```java
CompletableFuture<UpdateEmailNotificationResponsev21> updateEmailNotificationAsync(
    final UpdateEmailNotificationRequestv21 input)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `input` | [`UpdateEmailNotificationRequestv21`](/doc/models/update-email-notification-requestv-21.md) | Body, Optional | - |

## Response Type

[`UpdateEmailNotificationResponsev21`](/doc/models/update-email-notification-responsev-21.md)

## Example Usage

```java
UpdateEmailNotificationRequestv21 input = new UpdateEmailNotificationRequestv21();
input.setAccessToken("<YOUR ACCESS TOKEN>");
input.setCarrierClientContractId(19);
input.setNotifyByEmail(true);
input.setAsClientId(12);

emailNotificationsController.updateEmailNotificationAsync(input).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

## Example Response *(as JSON)*

```json
{
  "successfullyUpdatedEmailNotification": true,
  "error": {
    "details": [],
    "hasError": false
  }
}
```

