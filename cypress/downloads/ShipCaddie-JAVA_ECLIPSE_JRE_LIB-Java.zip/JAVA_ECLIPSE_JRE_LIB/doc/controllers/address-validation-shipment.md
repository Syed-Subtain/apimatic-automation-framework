# Address Validation Shipment

```java
AddressValidationShipmentController addressValidationShipmentController = client.getAddressValidationShipmentController();
```

## Class Name

`AddressValidationShipmentController`


# Validate Shipment Address

Use this function to validate an address.

```java
CompletableFuture<AddressValidationResponseReturnModel> validateShipmentAddressAsync(
    final ValidateShipmentAddressRequest input)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `input` | [`ValidateShipmentAddressRequest`](/doc/models/validate-shipment-address-request.md) | Body, Optional | - |

## Response Type

[`AddressValidationResponseReturnModel`](/doc/models/address-validation-response-return-model.md)

## Example Usage

```java
ValidateShipmentAddressRequest input = new ValidateShipmentAddressRequest();
input.setAccessToken("<YOUR ACCESS TOKEN>");
input.setAsClientId(14);
input.setShipmentAddressToValidate(new AddressValidationRequestModel());
input.getShipmentAddressToValidate().setCarrierId(4);
input.getShipmentAddressToValidate().setCarrierContractId(2324);
input.getShipmentAddressToValidate().setAddresses(new LinkedList<>());

AddressValidationModel inputShipmentAddressToValidateAddresses0 = new AddressValidationModel();
inputShipmentAddressToValidateAddresses0.setAddress1("2600 Executive Parkway");
inputShipmentAddressToValidateAddresses0.setAddress2("Suite 160");
inputShipmentAddressToValidateAddresses0.setProvinceCode("UT");
inputShipmentAddressToValidateAddresses0.setCity("Lehi");
inputShipmentAddressToValidateAddresses0.setCountryCode("US");
inputShipmentAddressToValidateAddresses0.setPostalCode("84043");
inputShipmentAddressToValidateAddresses0.setAddressTypeId(AddressTypeIdEnum.COMMERCIAL);
inputShipmentAddressToValidateAddresses0.setCompanyName("iDrive Logistics");
inputShipmentAddressToValidateAddresses0.setCountryId(0);
inputShipmentAddressToValidateAddresses0.setAddressStatus(false);
input.getShipmentAddressToValidate().getAddresses().add(inputShipmentAddressToValidateAddresses0);


addressValidationShipmentController.validateShipmentAddressAsync(input).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

