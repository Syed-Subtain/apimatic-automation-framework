# Shipments

```java
ShipmentsController shipmentsController = client.getShipmentsController();
```

## Class Name

`ShipmentsController`

## Methods

* [Update Shipment](/doc/controllers/shipments.md#update-shipment)
* [Delete Shipment by ID](/doc/controllers/shipments.md#delete-shipment-by-id)
* [Get Shipment Items by Sku](/doc/controllers/shipments.md#get-shipment-items-by-sku)
* [Add Shipment](/doc/controllers/shipments.md#add-shipment)
* [Get Shipment Information](/doc/controllers/shipments.md#get-shipment-information)
* [Get Shipped Info](/doc/controllers/shipments.md#get-shipped-info)


# Update Shipment

UpdateShipment:    Updates existing Shipment information

```java
CompletableFuture<ShippingCostData> updateShipmentAsync(
    final UpdateShipmentRequest input)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `input` | [`UpdateShipmentRequest`](/doc/models/update-shipment-request.md) | Body, Optional | - |

## Response Type

[`ShippingCostData`](/doc/models/shipping-cost-data.md)

## Example Usage

```java
UpdateShipmentRequest input = new UpdateShipmentRequest();
input.setAccessToken("<YOUR ACCESS TOKEN>");
input.setAsClientId(12);
input.setShipmentId(37);
input.setShipment(new ShipmentInformation());
input.getShipment().setDateShipped(LocalDateTime.parse("2020-12-23T23:54:10.3585858Z", DateTimeFormatter.ISO_DATE_TIME));
input.getShipment().setCarrierClientContractId(2404);
input.getShipment().setCarrierServiceLevelId(1115);
input.getShipment().setAddressFrom(new ShipFromAddress());
input.getShipment().getAddressFrom().setCompanyName("iDrive Logistics");
input.getShipment().getAddressFrom().setEmail("sales@idrivelogistics.com");
input.getShipment().getAddressFrom().setPhoneNumber("(888) 797-0929");
input.getShipment().getAddressFrom().setAddress1("2600 Executive Pkwy #160");
input.getShipment().getAddressFrom().setAddress2("");
input.getShipment().getAddressFrom().setCity("Lehi");
input.getShipment().getAddressFrom().setStateOrProvince("UT");
input.getShipment().getAddressFrom().setPostalCode("84043");
input.getShipment().getAddressFrom().setCountryCode("US");
input.getShipment().setAddressTo(new ShipToAddress());
input.getShipment().getAddressTo().setAttentionOf("Mr. Jones");
input.getShipment().getAddressTo().setCompanyName("iDrive Logistics");
input.getShipment().getAddressTo().setEmail("sales@idrivelogistics.com");
input.getShipment().getAddressTo().setPhoneNumber("(888) 797-0929");
input.getShipment().getAddressTo().setAddress1("2605 Executive Pkwy #160");
input.getShipment().getAddressTo().setAddress2("");
input.getShipment().getAddressTo().setIsResidential(false);
input.getShipment().getAddressTo().setCity("Lehi");
input.getShipment().getAddressTo().setStateOrProvince("UT");
input.getShipment().getAddressTo().setPostalCode("84043");
input.getShipment().getAddressTo().setCountryCode("US");
input.getShipment().setParcels(new LinkedList<>());

ParcelDetail inputShipmentParcels0 = new ParcelDetail();
inputShipmentParcels0.setWeightInPounds(0.4);
inputShipmentParcels0.setLengthInInches(5);
inputShipmentParcels0.setWidthInInches(4);
inputShipmentParcels0.setHeightInInches(12);
inputShipmentParcels0.setOptions(new ParcelOptions());
inputShipmentParcels0.getOptions().setReturn(ReturnEnum.NOT_APPLICABLE);
inputShipmentParcels0.getOptions().setInsuranceAmount(0);
inputShipmentParcels0.getOptions().setSignature(SignatureEnum.NOT_APPLICABLE);
inputShipmentParcels0.getOptions().setCod(new CODOptions());
inputShipmentParcels0.getOptions().getCod().setCodType(CodTypeEnum.NOT_APPLICABLE);
inputShipmentParcels0.getOptions().getCod().setCodAmount(0);
inputShipmentParcels0.setReferenceField1("1");
inputShipmentParcels0.setReferenceField2("");
inputShipmentParcels0.setReferenceField3("");
inputShipmentParcels0.setParcelID("1");
inputShipmentParcels0.setPackagingId("");
inputShipmentParcels0.setParcelItems(new LinkedList<>());

ParcelContent inputShipmentParcels0ParcelItems0 = new ParcelContent();
inputShipmentParcels0ParcelItems0.setName("chocolate");
inputShipmentParcels0ParcelItems0.setQuantity(7);
inputShipmentParcels0ParcelItems0.setPrice(1.03);
inputShipmentParcels0ParcelItems0.setWeightInPounds(0.5);
inputShipmentParcels0ParcelItems0.setOriginCountry("US");
inputShipmentParcels0ParcelItems0.setSku("none");
inputShipmentParcels0ParcelItems0.setDescription("candy");
inputShipmentParcels0ParcelItems0.setHarmonizeCode("");
inputShipmentParcels0.getParcelItems().add(inputShipmentParcels0ParcelItems0);

input.getShipment().getParcels().add(inputShipmentParcels0);

input.getShipment().setOrderReferenceNumber("test order");
input.getShipment().setOptions(new ShippingOptions());
input.getShipment().getOptions().setIsAPOFPODPOUSTerritory(false);
input.getShipment().getOptions().setIsInternationalShipment(false);
input.getShipment().getOptions().setBilling(new BillingOptions());
input.getShipment().getOptions().getBilling().setShippingPaidBy(ShippingPaidByEnum.NOT_APPLICABLE);
input.getShipment().getOptions().getBilling().setDutiesPaidBy(DutiesPaidByEnum.NOT_APPLICABLE);
input.getShipment().getOptions().getBilling().setAccountNumber("");
input.getShipment().getOptions().getBilling().setPostalCode("");
input.getShipment().getOptions().getBilling().setCountryAlpha2Code("");
input.getShipment().getOptions().setShipmentContentType(ShipmentContentTypeEnum.CONTENT_TYPE_SAMPLE);

shipmentsController.updateShipmentAsync(input).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

## Example Response *(as JSON)*

```json
{
  "shippingCost": {
    "shipmentId": 12,
    "orderReferenceNumber": "123",
    "parcelChargeDetails": [
      {
        "parcelID": "1",
        "costDetails": [
          {
            "name": "FREIGHT",
            "amount": 3.23,
            "amountDisplay": 0.0
          }
        ]
      }
    ],
    "shippingChargeDetails": [
      {
        "name": "Charge",
        "amount": 2.34,
        "amountDisplay": 0.0
      }
    ],
    "transitDaysMin": -1,
    "transitDaysMax": -1,
    "totalChargeAmount": -1.0,
    "isDeliveryGuaranteed": false
  },
  "error": {
    "details": [],
    "hasError": false
  }
}
```


# Delete Shipment by ID

```java
CompletableFuture<DeleteShipmentResult> deleteShipmentByIDAsync(
    final ShipmentRequestByID input)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `input` | [`ShipmentRequestByID`](/doc/models/shipment-request-by-id.md) | Body, Optional | - |

## Response Type

[`DeleteShipmentResult`](/doc/models/delete-shipment-result.md)

## Example Usage

```java
ShipmentRequestByID input = new ShipmentRequestByID();
input.setAccessToken("<YOUR ACCESS TOKEN>");
input.setAsClientId(12);
input.setShipmentID(37);

shipmentsController.deleteShipmentByIDAsync(input).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

## Example Response *(as JSON)*

```json
{
  "shipmentId": 23,
  "isDeleted": true,
  "error": {
    "details": [],
    "hasError": false
  }
}
```


# Get Shipment Items by Sku

This method can be used to get the shipments inventeries by sku within given date range.

```java
CompletableFuture<ShipmentInventoryBySkuResponseModel> getShipmentItemsBySkuAsync(
    final ShipmentRequestByDate input)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `input` | [`ShipmentRequestByDate`](/doc/models/shipment-request-by-date.md) | Body, Optional | - |

## Response Type

[`ShipmentInventoryBySkuResponseModel`](/doc/models/shipment-inventory-by-sku-response-model.md)

## Example Usage

```java
ShipmentRequestByDate input = new ShipmentRequestByDate();
input.setAccessToken("<YOUR ACCESS TOKEN>");
input.setAsClientId(12);
input.setStartDate(LocalDateTime.parse("2020-12-23T23:54:10.2804606+00:00", DateTimeFormatter.ISO_DATE_TIME));
input.setEndDate(LocalDateTime.parse("2020-12-23T23:54:10.2804606+00:00", DateTimeFormatter.ISO_DATE_TIME));

shipmentsController.getShipmentItemsBySkuAsync(input).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

## Example Response *(as JSON)*

```json
{
  "shipmentInventoryBySku_Response": [
    {
      "sku": "TestSku1",
      "name": "TestName",
      "qty": 2,
      "dateShipped": "0001-01-01T00:00:00"
    },
    {
      "sku": "TestSku2",
      "name": "TestName2",
      "qty": 5,
      "dateShipped": "0001-01-01T00:00:00"
    }
  ],
  "error": {
    "details": [],
    "hasError": false
  }
}
```


# Add Shipment

After successfully adding a shipment request,
use the Get Shipping Labels by ShippingID
to get the shipping label.

```java
CompletableFuture<ShippingCostData> addShipmentAsync(
    final AddShipmentRequest input)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `input` | [`AddShipmentRequest`](/doc/models/add-shipment-request.md) | Body, Optional | - |

## Response Type

[`ShippingCostData`](/doc/models/shipping-cost-data.md)

## Example Usage

```java
AddShipmentRequest input = new AddShipmentRequest();
input.setAccessToken("<YOUR ACCESS TOKEN>");
input.setAsClientId(12);
input.setShipment(new ShipmentInformation());
input.getShipment().setDateShipped(LocalDateTime.parse("2020-12-23T23:54:10.0929416Z", DateTimeFormatter.ISO_DATE_TIME));
input.getShipment().setCarrierClientContractId(2404);
input.getShipment().setCarrierServiceLevelId(1115);
input.getShipment().setAddressFrom(new ShipFromAddress());
input.getShipment().getAddressFrom().setCompanyName("iDrive Logistics");
input.getShipment().getAddressFrom().setEmail("sales@idrivelogistics.com");
input.getShipment().getAddressFrom().setPhoneNumber("(888) 797-0929");
input.getShipment().getAddressFrom().setAddress1("2600 Executive Pkwy #160");
input.getShipment().getAddressFrom().setAddress2("");
input.getShipment().getAddressFrom().setCity("Lehi");
input.getShipment().getAddressFrom().setStateOrProvince("UT");
input.getShipment().getAddressFrom().setPostalCode("84043");
input.getShipment().getAddressFrom().setCountryCode("US");
input.getShipment().setAddressTo(new ShipToAddress());
input.getShipment().getAddressTo().setAttentionOf("Mr. Jones");
input.getShipment().getAddressTo().setCompanyName("iDrive Logistics");
input.getShipment().getAddressTo().setEmail("sales@idrivelogistics.com");
input.getShipment().getAddressTo().setPhoneNumber("(888) 797-0929");
input.getShipment().getAddressTo().setAddress1("2605 Executive Pkwy #160");
input.getShipment().getAddressTo().setAddress2("");
input.getShipment().getAddressTo().setIsResidential(false);
input.getShipment().getAddressTo().setCity("Lehi");
input.getShipment().getAddressTo().setStateOrProvince("UT");
input.getShipment().getAddressTo().setPostalCode("84043");
input.getShipment().getAddressTo().setCountryCode("US");
input.getShipment().setParcels(new LinkedList<>());

ParcelDetail inputShipmentParcels0 = new ParcelDetail();
inputShipmentParcels0.setWeightInPounds(0.4);
inputShipmentParcels0.setLengthInInches(5);
inputShipmentParcels0.setWidthInInches(4);
inputShipmentParcels0.setHeightInInches(12);
inputShipmentParcels0.setOptions(new ParcelOptions());
inputShipmentParcels0.getOptions().setReturn(ReturnEnum.NOT_APPLICABLE);
inputShipmentParcels0.getOptions().setInsuranceAmount(0);
inputShipmentParcels0.getOptions().setSignature(SignatureEnum.NOT_APPLICABLE);
inputShipmentParcels0.getOptions().setCod(new CODOptions());
inputShipmentParcels0.getOptions().getCod().setCodType(CodTypeEnum.NOT_APPLICABLE);
inputShipmentParcels0.getOptions().getCod().setCodAmount(0);
inputShipmentParcels0.setReferenceField1("1");
inputShipmentParcels0.setReferenceField2("");
inputShipmentParcels0.setReferenceField3("");
inputShipmentParcels0.setParcelID("1");
inputShipmentParcels0.setPackagingId("");
inputShipmentParcels0.setParcelItems(new LinkedList<>());

ParcelContent inputShipmentParcels0ParcelItems0 = new ParcelContent();
inputShipmentParcels0ParcelItems0.setName("chocolate");
inputShipmentParcels0ParcelItems0.setQuantity(7);
inputShipmentParcels0ParcelItems0.setPrice(1.03);
inputShipmentParcels0ParcelItems0.setWeightInPounds(0.5);
inputShipmentParcels0ParcelItems0.setOriginCountry("US");
inputShipmentParcels0ParcelItems0.setSku("none");
inputShipmentParcels0ParcelItems0.setDescription("candy");
inputShipmentParcels0ParcelItems0.setHarmonizeCode("");
inputShipmentParcels0.getParcelItems().add(inputShipmentParcels0ParcelItems0);

input.getShipment().getParcels().add(inputShipmentParcels0);

input.getShipment().setOrderReferenceNumber("test order");
input.getShipment().setOptions(new ShippingOptions());
input.getShipment().getOptions().setIsAPOFPODPOUSTerritory(false);
input.getShipment().getOptions().setIsInternationalShipment(false);
input.getShipment().getOptions().setBilling(new BillingOptions());
input.getShipment().getOptions().getBilling().setShippingPaidBy(ShippingPaidByEnum.NOT_APPLICABLE);
input.getShipment().getOptions().getBilling().setDutiesPaidBy(DutiesPaidByEnum.NOT_APPLICABLE);
input.getShipment().getOptions().getBilling().setAccountNumber("");
input.getShipment().getOptions().getBilling().setPostalCode("");
input.getShipment().getOptions().getBilling().setCountryAlpha2Code("");
input.getShipment().getOptions().setShipmentContentType(ShipmentContentTypeEnum.CONTENT_TYPE_SAMPLE);

shipmentsController.addShipmentAsync(input).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

## Example Response *(as JSON)*

```json
{
  "shippingCost": {
    "shipmentId": 12,
    "orderReferenceNumber": "123",
    "parcelChargeDetails": [
      {
        "parcelID": "1",
        "costDetails": [
          {
            "name": "FREIGHT",
            "amount": 3.23,
            "amountDisplay": 0.0
          }
        ]
      }
    ],
    "shippingChargeDetails": [
      {
        "name": "Charge",
        "amount": 2.34,
        "amountDisplay": 0.0
      }
    ],
    "transitDaysMin": -1,
    "transitDaysMax": -1,
    "totalChargeAmount": -1.0,
    "isDeliveryGuaranteed": false
  },
  "error": {
    "details": [],
    "hasError": false
  }
}
```


# Get Shipment Information

This method can be used to get the information necessary to update a shipment.

```java
CompletableFuture<ShipmentInformationResponse> getShipmentInformationAsync(
    final ShipmentRequestByID input)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `input` | [`ShipmentRequestByID`](/doc/models/shipment-request-by-id.md) | Body, Optional | - |

## Response Type

[`ShipmentInformationResponse`](/doc/models/shipment-information-response.md)

## Example Usage

```java
ShipmentRequestByID input = new ShipmentRequestByID();
input.setAccessToken("<YOUR ACCESS TOKEN>");
input.setAsClientId(12);
input.setShipmentID(37);

shipmentsController.getShipmentInformationAsync(input).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

## Example Response *(as JSON)*

```json
{
  "shipmentId": 37,
  "error": {
    "details": [],
    "hasError": false
  },
  "shipment": {
    "orderReferenceNumber": "test order",
    "dateShipped": "2020-12-23T23:54:10.2804606Z",
    "options": {
      "isAPO_FPO_DPO_USTerritory": false,
      "isInternationalShipment": false,
      "billing": {
        "shippingPaidBy": "NOT_APPLICABLE",
        "accountNumber": "",
        "postalCode": "",
        "country_Alpha2Code": "",
        "dutiesPaidBy": "NOT_APPLICABLE"
      },
      "shipmentContentType": "CONTENT_TYPE_SAMPLE"
    },
    "carrierClientContractId": 2404,
    "carrierServiceLevelId": 1115,
    "addressFrom": {
      "companyName": "iDrive Logistics",
      "email": "sales@idrivelogistics.com",
      "phoneNumber": "(888) 797-0929",
      "address1": "2600 Executive Pkwy #160",
      "address2": "",
      "city": "Lehi",
      "stateOrProvince": "UT",
      "postalCode": "84043",
      "countryCode": "US"
    },
    "addressTo": {
      "attentionOf": "Mr. Jones",
      "companyName": "iDrive Logistics",
      "email": "sales@idrivelogistics.com",
      "phoneNumber": "(888) 797-0929",
      "address1": "2605 Executive Pkwy #160",
      "address2": "",
      "isResidential": false,
      "city": "Lehi",
      "stateOrProvince": "UT",
      "postalCode": "84043",
      "countryCode": "US"
    },
    "parcels": [
      {
        "referenceField1": "1",
        "referenceField2": "",
        "referenceField3": "",
        "parcelID": "1",
        "packagingId": "",
        "weightInPounds": 0.4,
        "lengthInInches": 5.0,
        "widthInInches": 4.0,
        "heightInInches": 12.0,
        "options": {
          "return": "NOT_APPLICABLE",
          "insuranceAmount": 0.0,
          "signature": "NOT_APPLICABLE",
          "cod": {
            "codType": "NOT_APPLICABLE",
            "codAmount": 0.0
          }
        },
        "parcelItems": [
          {
            "sku": "none",
            "name": "chocolate",
            "description": "candy",
            "quantity": 7,
            "price": 1.03,
            "weightInPounds": 0.5,
            "harmonizeCode": "",
            "originCountry": "US"
          }
        ]
      }
    ]
  }
}
```


# Get Shipped Info

This method can be used to get the information about a shipped shipment.

```java
CompletableFuture<ShippedInfoResponse> getShippedInfoAsync(
    final ShippedInfoRequest input)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `input` | [`ShippedInfoRequest`](/doc/models/shipped-info-request.md) | Body, Optional | - |

## Response Type

[`ShippedInfoResponse`](/doc/models/shipped-info-response.md)

## Example Usage

```java
shipmentsController.getShippedInfoAsync(null).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

## Example Response *(as JSON)*

```json
{
  "shipmentId": 37,
  "error": {
    "details": [],
    "hasError": false
  },
  "shipment": {
    "orderReferenceNumber": "test order",
    "dateShipped": "2020-12-23T23:54:10.2960842Z",
    "options": {
      "isAPO_FPO_DPO_USTerritory": false,
      "isInternationalShipment": false,
      "billing": {
        "shippingPaidBy": "NOT_APPLICABLE",
        "accountNumber": "",
        "postalCode": "",
        "country_Alpha2Code": "",
        "dutiesPaidBy": "NOT_APPLICABLE"
      },
      "shipmentContentType": "CONTENT_TYPE_SAMPLE"
    },
    "carrierClientContractId": 2404,
    "carrierServiceLevelId": 1115,
    "addressFrom": {
      "companyName": "iDrive Logistics",
      "email": "sales@idrivelogistics.com",
      "phoneNumber": "(888) 797-0929",
      "address1": "2600 Executive Pkwy #160",
      "address2": "",
      "city": "Lehi",
      "stateOrProvince": "UT",
      "postalCode": "84043",
      "countryCode": "US"
    },
    "addressTo": {
      "attentionOf": "Mr. Jones",
      "companyName": "iDrive Logistics",
      "email": "sales@idrivelogistics.com",
      "phoneNumber": "(888) 797-0929",
      "address1": "2605 Executive Pkwy #160",
      "address2": "",
      "isResidential": false,
      "city": "Lehi",
      "stateOrProvince": "UT",
      "postalCode": "84043",
      "countryCode": "US"
    },
    "parcels": [
      {
        "referenceField1": "1",
        "referenceField2": "",
        "referenceField3": "",
        "parcelID": "1",
        "packagingId": "",
        "weightInPounds": 0.4,
        "lengthInInches": 5.0,
        "widthInInches": 4.0,
        "heightInInches": 12.0,
        "options": {
          "return": "NOT_APPLICABLE",
          "insuranceAmount": 0.0,
          "signature": "NOT_APPLICABLE",
          "cod": {
            "codType": "NOT_APPLICABLE",
            "codAmount": 0.0
          }
        },
        "parcelItems": [
          {
            "sku": "none",
            "name": "chocolate",
            "description": "candy",
            "quantity": 7,
            "price": 1.03,
            "weightInPounds": 0.5,
            "harmonizeCode": "",
            "originCountry": "US"
          }
        ]
      }
    ]
  }
}
```

