# Manifest

```java
ManifestController manifestController = client.getManifestController();
```

## Class Name

`ManifestController`

## Methods

* [Manifest](/doc/controllers/manifest.md#manifest)
* [Generate](/doc/controllers/manifest.md#generate)
* [Regenerate](/doc/controllers/manifest.md#regenerate)
* [Scan Form History](/doc/controllers/manifest.md#scan-form-history)
* [Available Shipments](/doc/controllers/manifest.md#available-shipments)
* [Scan Form Generate](/doc/controllers/manifest.md#scan-form-generate)


# Manifest

Manifest:    Create end-of-day Manifest / Scan Form (USPS).

```java
CompletableFuture<ScanFormHistoryByIDResponsev21> manifestAsync(
    final ScanFormHistoryByIDRequestv21 input)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `input` | [`ScanFormHistoryByIDRequestv21`](/doc/models/scan-form-history-by-id-requestv-21.md) | Body, Optional | - |

## Response Type

[`ScanFormHistoryByIDResponsev21`](/doc/models/scan-form-history-by-id-responsev-21.md)

## Example Usage

```java
ScanFormHistoryByIDRequestv21 input = new ScanFormHistoryByIDRequestv21();
input.setAccessToken("<YOUR ACCESS TOKEN>");
input.setScanFormId(23);

manifestController.manifestAsync(input).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

## Example Response *(as JSON)*

```json
{
  "error": {
    "details": [],
    "hasError": false
  },
  "scanFormInformation": {
    "id": 12,
    "scanFormId": "ScanFormID",
    "batchId": "BatchID",
    "clientId": 12,
    "shipmentClientAddressId": 747,
    "shipDate": "2020-12-23T23:54:10.3273331+00:00",
    "scanFormDataType": "imagePng",
    "carrierClientContractId": 2526,
    "carrierClientContractName": "Test",
    "shipmentClientAddressLine1": "",
    "shipmentClientAddressLine2": "",
    "shipmentClientAddressProvince": "",
    "shipmentClientAddressCity": "",
    "shipmentClientAddressPostalCode": "",
    "shippingSiteName": "",
    "dateCreated": "2020-12-23T23:54:10.3273331+00:00",
    "printJobs": [
      {
        "printTemplateType": "Template Type",
        "dataBlocks": []
      }
    ],
    "excludedItems": {}
  }
}
```


# Generate

Generate:    Obtain a ScanForm

```java
CompletableFuture<GenerateResponsev21> generateAsync(
    final GenerateRequestv21 input)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `input` | [`GenerateRequestv21`](/doc/models/generate-requestv-21.md) | Body, Optional | - |

## Response Type

[`GenerateResponsev21`](/doc/models/generate-responsev-21.md)

## Example Usage

```java
GenerateRequestv21 input = new GenerateRequestv21();
input.setAccessToken("<YOUR ACCESS TOKEN>");
input.setScanFormRequest(new ScanFormModelRequest());
input.getScanFormRequest().setCarrierClientContractId(2526);
input.getScanFormRequest().setShipmentClientAddressId(747);
input.getScanFormRequest().setShipDate(LocalDateTime.parse("2017-11-29T00:00:00", DateTimeFormatter.ISO_DATE_TIME));
input.getScanFormRequest().setKeyList(new LinkedList<>());

KeyValues inputScanFormRequestKeyList0 = new KeyValues();
inputScanFormRequestKeyList0.setLabelKey("shp_810c212e2dcf4863a1bd8495f9a54d81");
inputScanFormRequestKeyList0.setTrackingNumber("9400136895239112753275");
inputScanFormRequestKeyList0.setPackageId(366974);
input.getScanFormRequest().getKeyList().add(inputScanFormRequestKeyList0);

input.getScanFormRequest().setRecentScanFormId(0);

manifestController.generateAsync(input).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

## Example Response *(as JSON)*

```json
{
  "error": {
    "details": [],
    "hasError": false
  },
  "scanFormInformation": {
    "id": 12,
    "scanFormId": "ScanFormID",
    "batchId": "BatchID",
    "clientId": 12,
    "shipmentClientAddressId": 747,
    "shipDate": "2020-12-23T23:54:10.1867682+00:00",
    "scanFormDataType": "imagePng",
    "carrierClientContractId": 2526,
    "carrierClientContractName": "Test",
    "shipmentClientAddressLine1": "",
    "shipmentClientAddressLine2": "",
    "shipmentClientAddressProvince": "",
    "shipmentClientAddressCity": "",
    "shipmentClientAddressPostalCode": "",
    "shippingSiteName": "",
    "dateCreated": "2020-12-23T23:54:10.1867682+00:00",
    "printJobs": [
      {
        "printTemplateType": "Template Type",
        "dataBlocks": []
      }
    ],
    "excludedItems": {}
  }
}
```


# Regenerate

Regenerate:    Obtain a ScanForm

```java
CompletableFuture<RegenerateResponsev21> regenerateAsync(
    final RegenerateRequestv21 input)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `input` | [`RegenerateRequestv21`](/doc/models/regenerate-requestv-21.md) | Body, Optional | - |

## Response Type

[`RegenerateResponsev21`](/doc/models/regenerate-responsev-21.md)

## Example Usage

```java
RegenerateRequestv21 input = new RegenerateRequestv21();
input.setAccessToken("<YOUR ACCESS TOKEN>");
input.setIsRegenerate(false);
input.setScanFormRequest(new ScanFormModelRequest());
input.getScanFormRequest().setCarrierClientContractId(2526);
input.getScanFormRequest().setShipmentClientAddressId(747);
input.getScanFormRequest().setShipDate(LocalDateTime.parse("2017-11-29T00:00:00", DateTimeFormatter.ISO_DATE_TIME));
input.getScanFormRequest().setKeyList(new LinkedList<>());

KeyValues inputScanFormRequestKeyList0 = new KeyValues();
inputScanFormRequestKeyList0.setLabelKey("shp_810c212e2dcf4863a1bd8495f9a54d81");
inputScanFormRequestKeyList0.setTrackingNumber("9400136895239112753275");
inputScanFormRequestKeyList0.setPackageId(366974);
input.getScanFormRequest().getKeyList().add(inputScanFormRequestKeyList0);

input.getScanFormRequest().setRecentScanFormId(0);

manifestController.regenerateAsync(input).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

## Example Response *(as JSON)*

```json
{
  "error": {
    "details": [],
    "hasError": false
  },
  "scanFormInformation": {
    "id": 12,
    "scanFormId": "ScanFormID",
    "batchId": "BatchID",
    "clientId": 12,
    "shipmentClientAddressId": 747,
    "shipDate": "2020-12-23T23:54:10.3273331+00:00",
    "scanFormDataType": "imagePng",
    "carrierClientContractId": 2526,
    "carrierClientContractName": "Test",
    "shipmentClientAddressLine1": "",
    "shipmentClientAddressLine2": "",
    "shipmentClientAddressProvince": "",
    "shipmentClientAddressCity": "",
    "shipmentClientAddressPostalCode": "",
    "shippingSiteName": "",
    "dateCreated": "2020-12-23T23:54:10.3273331+00:00",
    "printJobs": [
      {
        "printTemplateType": "Template Type",
        "dataBlocks": []
      }
    ],
    "excludedItems": {}
  }
}
```


# Scan Form History

ScanForm_History:         Get the end-of-day Manifests / Scan Forms (USPS)

```java
CompletableFuture<ScanFormHistoryResponsev21> scanFormHistoryAsync(
    final ScanFormHistoryRequestv21 input)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `input` | [`ScanFormHistoryRequestv21`](/doc/models/scan-form-history-requestv-21.md) | Body, Optional | - |

## Response Type

[`ScanFormHistoryResponsev21`](/doc/models/scan-form-history-responsev-21.md)

## Example Usage

```java
ScanFormHistoryRequestv21 input = new ScanFormHistoryRequestv21();
input.setAccessToken("<YOUR ACCESS TOKEN>");

manifestController.scanFormHistoryAsync(input).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

## Example Response *(as JSON)*

```json
{
  "error": {
    "details": [],
    "hasError": false
  },
  "scanFormList": [
    {
      "id": 12,
      "scanFormId": "ScanFormID",
      "batchId": "BatchID",
      "clientId": 12,
      "shipmentClientAddressId": 747,
      "shipDate": "2020-12-23T23:54:10.3585858+00:00",
      "scanFormDataType": "imagePng",
      "carrierClientContractId": 2526,
      "carrierClientContractName": "Test",
      "shipmentClientAddressLine1": "",
      "shipmentClientAddressLine2": "",
      "shipmentClientAddressProvince": "",
      "shipmentClientAddressCity": "",
      "shipmentClientAddressPostalCode": "",
      "shippingSiteName": "",
      "dateCreated": "2020-12-23T23:54:10.3585858+00:00",
      "printJobs": [
        {
          "printTemplateType": "Template Type",
          "dataBlocks": []
        }
      ],
      "excludedItems": {}
    }
  ]
}
```


# Available Shipments

AvailableShipments:    Gets Available Shipments

```java
CompletableFuture<AvailableShipmentsResponsev21> availableShipmentsAsync(
    final AvailableShipmentsRequestv21 input)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `input` | [`AvailableShipmentsRequestv21`](/doc/models/available-shipments-requestv-21.md) | Body, Optional | - |

## Response Type

[`AvailableShipmentsResponsev21`](/doc/models/available-shipments-responsev-21.md)

## Example Usage

```java
AvailableShipmentsRequestv21 input = new AvailableShipmentsRequestv21();
input.setAccessToken("<YOUR ACCESS TOKEN>");
input.setAsClientId(12);
input.setCarrierClientContractId(34);
input.setAddressId(23);
input.setShipDate(LocalDateTime.parse("2020-12-23T23:54:10.1554517+00:00", DateTimeFormatter.ISO_DATE_TIME));

manifestController.availableShipmentsAsync(input).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

## Example Response *(as JSON)*

```json
{
  "error": {
    "details": [],
    "hasError": false
  },
  "availableShipments": [
    {
      "carrierClientContractId": 14,
      "shipmentId": 23,
      "packageId": 45,
      "shipmentClientAddressId": 52,
      "dateShipped": "2020-12-23T23:54:10.1554517+00:00",
      "fromShippingSiteName": "Shipping Site Name",
      "toAddressLine1": "564 Drury Lane",
      "toAddressLine2": "",
      "toPostalCode": "95654",
      "toProvince": "CA",
      "toCity": "LA",
      "accountAlias": "",
      "labelKey": "fds32y4rddaf",
      "trackingNumber": "565489079094"
    }
  ]
}
```


# Scan Form Generate

ScanForm_Generate:         Get Manifests / Scan Forms (USPS)

```java
CompletableFuture<ScanFormGenerateResponsev21> scanFormGenerateAsync(
    final ScanFormGenerateRequestv21 input)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `input` | [`ScanFormGenerateRequestv21`](/doc/models/scan-form-generate-requestv-21.md) | Body, Optional | - |

## Response Type

[`ScanFormGenerateResponsev21`](/doc/models/scan-form-generate-responsev-21.md)

## Example Usage

```java
ScanFormGenerateRequestv21 input = new ScanFormGenerateRequestv21();
input.setAccessToken("<YOUR ACCESS TOKEN>");
input.setScanFormRequest(new ScanFormModelRequest());
input.getScanFormRequest().setCarrierClientContractId(2526);
input.getScanFormRequest().setShipmentClientAddressId(747);
input.getScanFormRequest().setShipDate(LocalDateTime.parse("2017-11-29T00:00:00", DateTimeFormatter.ISO_DATE_TIME));
input.getScanFormRequest().setKeyList(new LinkedList<>());

KeyValues inputScanFormRequestKeyList0 = new KeyValues();
inputScanFormRequestKeyList0.setLabelKey("shp_810c212e2dcf4863a1bd8495f9a54d81");
inputScanFormRequestKeyList0.setTrackingNumber("9400136895239112753275");
inputScanFormRequestKeyList0.setPackageId(366974);
input.getScanFormRequest().getKeyList().add(inputScanFormRequestKeyList0);

input.getScanFormRequest().setRecentScanFormId(0);

manifestController.scanFormGenerateAsync(input).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

## Example Response *(as JSON)*

```json
{
  "error": {
    "details": [],
    "hasError": false
  },
  "scanFormInformation": {
    "id": 12,
    "scanFormId": "ScanFormID",
    "batchId": "BatchID",
    "clientId": 12,
    "shipmentClientAddressId": 747,
    "shipDate": "2020-12-23T23:54:10.3585858+00:00",
    "scanFormDataType": "imagePng",
    "carrierClientContractId": 2526,
    "carrierClientContractName": "Test",
    "shipmentClientAddressLine1": "",
    "shipmentClientAddressLine2": "",
    "shipmentClientAddressProvince": "",
    "shipmentClientAddressCity": "",
    "shipmentClientAddressPostalCode": "",
    "shippingSiteName": "",
    "dateCreated": "2020-12-23T23:54:10.3585858+00:00",
    "printJobs": [
      {
        "printTemplateType": "Template Type",
        "dataBlocks": []
      }
    ],
    "excludedItems": {}
  }
}
```

