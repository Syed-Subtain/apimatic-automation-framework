# Registration

```java
RegistrationController registrationController = client.getRegistrationController();
```

## Class Name

`RegistrationController`


# Register Account

Allows a registration of a new account.

```java
CompletableFuture<RegisterAccountResponsev21> registerAccountAsync(
    final RegisterAccountLimitRequestv21 input)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `input` | [`RegisterAccountLimitRequestv21`](/doc/models/register-account-limit-requestv-21.md) | Body, Optional | - |

## Response Type

[`RegisterAccountResponsev21`](/doc/models/register-account-responsev-21.md)

## Example Usage

```java
RegisterAccountLimitRequestv21 input = new RegisterAccountLimitRequestv21();
input.setRegistrationInformation(new UserRegisterModelv21());
input.getRegistrationInformation().setSystemCountryId(840);
input.getRegistrationInformation().setNameFirst("Tom");
input.getRegistrationInformation().setNameLast("Thomson");
input.getRegistrationInformation().setCompanyName("Ace");
input.getRegistrationInformation().setPhoneNumber("123 456-7890");
input.getRegistrationInformation().setUserName("User Name");
input.getRegistrationInformation().setPassword("Password");
input.getRegistrationInformation().setPasswordVerify("Password");
input.getRegistrationInformation().setPromoCode("");
input.getRegistrationInformation().setSubscriptionTierId(1);
input.getRegistrationInformation().setIAgree("yes");

registrationController.registerAccountAsync(input).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

## Example Response *(as JSON)*

```json
{
  "error": {
    "details": [],
    "hasError": false
  },
  "success": true
}
```

