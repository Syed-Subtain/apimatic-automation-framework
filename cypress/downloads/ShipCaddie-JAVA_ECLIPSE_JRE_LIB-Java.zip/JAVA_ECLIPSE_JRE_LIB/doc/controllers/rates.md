# Rates

```java
RatesController ratesController = client.getRatesController();
```

## Class Name

`RatesController`

## Methods

* [Get Rates for All Carriers](/doc/controllers/rates.md#get-rates-for-all-carriers)
* [Get Rates](/doc/controllers/rates.md#get-rates)
* [Get Rates by Carrier](/doc/controllers/rates.md#get-rates-by-carrier)
* [Get Multiple Rates](/doc/controllers/rates.md#get-multiple-rates)


# Get Rates for All Carriers

Before creating a shipping label,
you can use this method to get a
break down of all shipping charges.
This allows you to determine
how much it would cost if you were to
actually send the parcels.

If the CarrierClientContractId is set to 0,
all carriers and service levels will be returned.

If the CarrierClientContractId is supplied but
the ServiceLevelId is set to 0 or not supplied,
only the specified carrier with all associated
service levels will be returned.

If the CarrierClientContractId is supplied and
the ServiceLevelId is also supplied,
only the specified carrier and service level
will be returned.

NOTE: HTTPS is Required to recieve a response.

```java
CompletableFuture<List<RateResponse>> getRatesForAllCarriersAsync(
    final RateRequest rateRequest)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `rateRequest` | [`RateRequest`](/doc/models/rate-request.md) | Body, Optional | Shipping and parcel information<br>neccessary to calculate rates. |

## Response Type

[`List<RateResponse>`](/doc/models/rate-response.md)

## Example Usage

```java
RateRequest rateRequest = new RateRequest();
rateRequest.setAccessToken("YOUR ACCESS TOKEN");
rateRequest.setShippingInfo(new ShippingInformation());
rateRequest.getShippingInfo().setCarrierClientContractId(2526);
rateRequest.getShippingInfo().setServiceLevelId(0);
rateRequest.getShippingInfo().setDateShipped(LocalDateTime.parse("2020-12-23T23:54:10.2649036Z", DateTimeFormatter.ISO_DATE_TIME));
rateRequest.getShippingInfo().setOptions(new CustomsOptions());
rateRequest.getShippingInfo().getOptions().setIsAPOFPODPOUSTerritory(false);
rateRequest.getShippingInfo().getOptions().setIsInternationalShipment(false);
rateRequest.getShippingInfo().getOptions().setShipmentContentType(ShipmentContentTypeEnum.CONTENT_TYPE_SAMPLE);
rateRequest.getShippingInfo().setAddressFrom(new ShipFromAddress());
rateRequest.getShippingInfo().getAddressFrom().setCompanyName("iDrive Logistics");
rateRequest.getShippingInfo().getAddressFrom().setEmail("sales@idrivelogistics.com");
rateRequest.getShippingInfo().getAddressFrom().setPhoneNumber("(888) 797-0929");
rateRequest.getShippingInfo().getAddressFrom().setAddress1("2600 Executive Pkwy #160");
rateRequest.getShippingInfo().getAddressFrom().setAddress2("");
rateRequest.getShippingInfo().getAddressFrom().setCity("Lehi");
rateRequest.getShippingInfo().getAddressFrom().setStateOrProvince("UT");
rateRequest.getShippingInfo().getAddressFrom().setPostalCode("84043");
rateRequest.getShippingInfo().getAddressFrom().setCountryCode("US");
rateRequest.getShippingInfo().setAddressTo(new ShipToAddress());
rateRequest.getShippingInfo().getAddressTo().setAttentionOf("Mr. Jones");
rateRequest.getShippingInfo().getAddressTo().setCompanyName("iDrive Logistics");
rateRequest.getShippingInfo().getAddressTo().setEmail("");
rateRequest.getShippingInfo().getAddressTo().setPhoneNumber("");
rateRequest.getShippingInfo().getAddressTo().setAddress1("2605 Executive Pkwy #160");
rateRequest.getShippingInfo().getAddressTo().setAddress2("");
rateRequest.getShippingInfo().getAddressTo().setIsResidential(false);
rateRequest.getShippingInfo().getAddressTo().setCity("Lehi");
rateRequest.getShippingInfo().getAddressTo().setStateOrProvince("UT");
rateRequest.getShippingInfo().getAddressTo().setPostalCode("84043");
rateRequest.getShippingInfo().getAddressTo().setCountryCode("US");
rateRequest.getShippingInfo().setParcels(new LinkedList<>());

ParcelInformation rateRequestShippingInfoParcels0 = new ParcelInformation();
rateRequestShippingInfoParcels0.setPackagingId("");
rateRequestShippingInfoParcels0.setWeightInPounds(0.4);
rateRequestShippingInfoParcels0.setLengthInInches(5);
rateRequestShippingInfoParcels0.setWidthInInches(4);
rateRequestShippingInfoParcels0.setHeightInInches(12);
rateRequestShippingInfoParcels0.setOptions(new ParcelOptions());
rateRequestShippingInfoParcels0.getOptions().setReturn(ReturnEnum.NOT_APPLICABLE);
rateRequestShippingInfoParcels0.getOptions().setInsuranceAmount(0);
rateRequestShippingInfoParcels0.getOptions().setSignature(SignatureEnum.NOT_APPLICABLE);
rateRequestShippingInfoParcels0.getOptions().setCod(new CODOptions());
rateRequestShippingInfoParcels0.getOptions().getCod().setCodType(CodTypeEnum.NOT_APPLICABLE);
rateRequestShippingInfoParcels0.getOptions().getCod().setCodAmount(0);
rateRequestShippingInfoParcels0.getOptions().setMachinable(true);
rateRequestShippingInfoParcels0.getOptions().setHoldForPickup(false);
rateRequest.getShippingInfo().getParcels().add(rateRequestShippingInfoParcels0);


ratesController.getRatesForAllCarriersAsync(rateRequest).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```


# Get Rates

Before creating a shipping label,
you can use this method to get a
break down of all shipping charges.
This allows you to determine
how much it would cost if you were to
actually send the parcels.

NOTE: HTTPS is Required to recieve a response.

```java
CompletableFuture<RateResponse> getRatesAsync(
    final RateRequest rateRequest)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `rateRequest` | [`RateRequest`](/doc/models/rate-request.md) | Body, Optional | Shipping and parcel information<br>neccessary to calculate rates. |

## Response Type

[`RateResponse`](/doc/models/rate-response.md)

## Example Usage

```java
RateRequest rateRequest = new RateRequest();
rateRequest.setAccessToken("YOUR ACCESS TOKEN");
rateRequest.setShippingInfo(new ShippingInformation());
rateRequest.getShippingInfo().setCarrierClientContractId(2526);
rateRequest.getShippingInfo().setServiceLevelId(0);
rateRequest.getShippingInfo().setDateShipped(LocalDateTime.parse("2020-12-23T23:54:10.2649036Z", DateTimeFormatter.ISO_DATE_TIME));
rateRequest.getShippingInfo().setOptions(new CustomsOptions());
rateRequest.getShippingInfo().getOptions().setIsAPOFPODPOUSTerritory(false);
rateRequest.getShippingInfo().getOptions().setIsInternationalShipment(false);
rateRequest.getShippingInfo().getOptions().setShipmentContentType(ShipmentContentTypeEnum.CONTENT_TYPE_SAMPLE);
rateRequest.getShippingInfo().setAddressFrom(new ShipFromAddress());
rateRequest.getShippingInfo().getAddressFrom().setCompanyName("iDrive Logistics");
rateRequest.getShippingInfo().getAddressFrom().setEmail("sales@idrivelogistics.com");
rateRequest.getShippingInfo().getAddressFrom().setPhoneNumber("(888) 797-0929");
rateRequest.getShippingInfo().getAddressFrom().setAddress1("2600 Executive Pkwy #160");
rateRequest.getShippingInfo().getAddressFrom().setAddress2("");
rateRequest.getShippingInfo().getAddressFrom().setCity("Lehi");
rateRequest.getShippingInfo().getAddressFrom().setStateOrProvince("UT");
rateRequest.getShippingInfo().getAddressFrom().setPostalCode("84043");
rateRequest.getShippingInfo().getAddressFrom().setCountryCode("US");
rateRequest.getShippingInfo().setAddressTo(new ShipToAddress());
rateRequest.getShippingInfo().getAddressTo().setAttentionOf("Mr. Jones");
rateRequest.getShippingInfo().getAddressTo().setCompanyName("iDrive Logistics");
rateRequest.getShippingInfo().getAddressTo().setEmail("");
rateRequest.getShippingInfo().getAddressTo().setPhoneNumber("");
rateRequest.getShippingInfo().getAddressTo().setAddress1("2605 Executive Pkwy #160");
rateRequest.getShippingInfo().getAddressTo().setAddress2("");
rateRequest.getShippingInfo().getAddressTo().setIsResidential(false);
rateRequest.getShippingInfo().getAddressTo().setCity("Lehi");
rateRequest.getShippingInfo().getAddressTo().setStateOrProvince("UT");
rateRequest.getShippingInfo().getAddressTo().setPostalCode("84043");
rateRequest.getShippingInfo().getAddressTo().setCountryCode("US");
rateRequest.getShippingInfo().setParcels(new LinkedList<>());

ParcelInformation rateRequestShippingInfoParcels0 = new ParcelInformation();
rateRequestShippingInfoParcels0.setPackagingId("");
rateRequestShippingInfoParcels0.setWeightInPounds(0.4);
rateRequestShippingInfoParcels0.setLengthInInches(5);
rateRequestShippingInfoParcels0.setWidthInInches(4);
rateRequestShippingInfoParcels0.setHeightInInches(12);
rateRequestShippingInfoParcels0.setOptions(new ParcelOptions());
rateRequestShippingInfoParcels0.getOptions().setReturn(ReturnEnum.NOT_APPLICABLE);
rateRequestShippingInfoParcels0.getOptions().setInsuranceAmount(0);
rateRequestShippingInfoParcels0.getOptions().setSignature(SignatureEnum.NOT_APPLICABLE);
rateRequestShippingInfoParcels0.getOptions().setCod(new CODOptions());
rateRequestShippingInfoParcels0.getOptions().getCod().setCodType(CodTypeEnum.NOT_APPLICABLE);
rateRequestShippingInfoParcels0.getOptions().getCod().setCodAmount(0);
rateRequestShippingInfoParcels0.getOptions().setMachinable(true);
rateRequestShippingInfoParcels0.getOptions().setHoldForPickup(false);
rateRequest.getShippingInfo().getParcels().add(rateRequestShippingInfoParcels0);


ratesController.getRatesAsync(rateRequest).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```


# Get Rates by Carrier

Before creating a shipping label,
you can use this method to get a
break down of all shipping charges.
This allows you to determine
how much it would cost if you were to
actually send the parcels.

NOTE: HTTPS is Required to recieve a response.

```java
CompletableFuture<RateResponse> getRatesByCarrierAsync(
    final RateRequest rateRequest)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `rateRequest` | [`RateRequest`](/doc/models/rate-request.md) | Body, Optional | Shipping and parcel information<br>neccessary to calculate rates. |

## Response Type

[`RateResponse`](/doc/models/rate-response.md)

## Example Usage

```java
RateRequest rateRequest = new RateRequest();
rateRequest.setAccessToken("YOUR ACCESS TOKEN");
rateRequest.setShippingInfo(new ShippingInformation());
rateRequest.getShippingInfo().setCarrierClientContractId(2526);
rateRequest.getShippingInfo().setServiceLevelId(0);
rateRequest.getShippingInfo().setDateShipped(LocalDateTime.parse("2020-12-23T23:54:10.2649036Z", DateTimeFormatter.ISO_DATE_TIME));
rateRequest.getShippingInfo().setOptions(new CustomsOptions());
rateRequest.getShippingInfo().getOptions().setIsAPOFPODPOUSTerritory(false);
rateRequest.getShippingInfo().getOptions().setIsInternationalShipment(false);
rateRequest.getShippingInfo().getOptions().setShipmentContentType(ShipmentContentTypeEnum.CONTENT_TYPE_SAMPLE);
rateRequest.getShippingInfo().setAddressFrom(new ShipFromAddress());
rateRequest.getShippingInfo().getAddressFrom().setCompanyName("iDrive Logistics");
rateRequest.getShippingInfo().getAddressFrom().setEmail("sales@idrivelogistics.com");
rateRequest.getShippingInfo().getAddressFrom().setPhoneNumber("(888) 797-0929");
rateRequest.getShippingInfo().getAddressFrom().setAddress1("2600 Executive Pkwy #160");
rateRequest.getShippingInfo().getAddressFrom().setAddress2("");
rateRequest.getShippingInfo().getAddressFrom().setCity("Lehi");
rateRequest.getShippingInfo().getAddressFrom().setStateOrProvince("UT");
rateRequest.getShippingInfo().getAddressFrom().setPostalCode("84043");
rateRequest.getShippingInfo().getAddressFrom().setCountryCode("US");
rateRequest.getShippingInfo().setAddressTo(new ShipToAddress());
rateRequest.getShippingInfo().getAddressTo().setAttentionOf("Mr. Jones");
rateRequest.getShippingInfo().getAddressTo().setCompanyName("iDrive Logistics");
rateRequest.getShippingInfo().getAddressTo().setEmail("");
rateRequest.getShippingInfo().getAddressTo().setPhoneNumber("");
rateRequest.getShippingInfo().getAddressTo().setAddress1("2605 Executive Pkwy #160");
rateRequest.getShippingInfo().getAddressTo().setAddress2("");
rateRequest.getShippingInfo().getAddressTo().setIsResidential(false);
rateRequest.getShippingInfo().getAddressTo().setCity("Lehi");
rateRequest.getShippingInfo().getAddressTo().setStateOrProvince("UT");
rateRequest.getShippingInfo().getAddressTo().setPostalCode("84043");
rateRequest.getShippingInfo().getAddressTo().setCountryCode("US");
rateRequest.getShippingInfo().setParcels(new LinkedList<>());

ParcelInformation rateRequestShippingInfoParcels0 = new ParcelInformation();
rateRequestShippingInfoParcels0.setPackagingId("");
rateRequestShippingInfoParcels0.setWeightInPounds(0.4);
rateRequestShippingInfoParcels0.setLengthInInches(5);
rateRequestShippingInfoParcels0.setWidthInInches(4);
rateRequestShippingInfoParcels0.setHeightInInches(12);
rateRequestShippingInfoParcels0.setOptions(new ParcelOptions());
rateRequestShippingInfoParcels0.getOptions().setReturn(ReturnEnum.NOT_APPLICABLE);
rateRequestShippingInfoParcels0.getOptions().setInsuranceAmount(0);
rateRequestShippingInfoParcels0.getOptions().setSignature(SignatureEnum.NOT_APPLICABLE);
rateRequestShippingInfoParcels0.getOptions().setCod(new CODOptions());
rateRequestShippingInfoParcels0.getOptions().getCod().setCodType(CodTypeEnum.NOT_APPLICABLE);
rateRequestShippingInfoParcels0.getOptions().getCod().setCodAmount(0);
rateRequestShippingInfoParcels0.getOptions().setMachinable(true);
rateRequestShippingInfoParcels0.getOptions().setHoldForPickup(false);
rateRequest.getShippingInfo().getParcels().add(rateRequestShippingInfoParcels0);


ratesController.getRatesByCarrierAsync(rateRequest).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```


# Get Multiple Rates

Before creating a shipping label,
you can use this method to get multiple
break downs of all shipping charges.
This allows you to determine
how much it would cost if you were to
actually send the parcels.

NOTE: HTTPS is Required to recieve a response.

```java
CompletableFuture<List<RateResponse>> getMultipleRatesAsync(
    final List<RateRequest> rateRequest)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `rateRequest` | [`List<RateRequest>`](/doc/models/rate-request.md) | Body, Optional | Shipping and parcel information<br>neccessary to calculate rates. |

## Response Type

[`List<RateResponse>`](/doc/models/rate-response.md)

## Example Usage

```java
List<RateRequest> rateRequest = new LinkedList<>();

RateRequest rateRequest0 = new RateRequest();
rateRequest0.setAccessToken("YOUR ACCESS TOKEN");
rateRequest0.setShippingInfo(new ShippingInformation());
rateRequest0.getShippingInfo().setCarrierClientContractId(2526);
rateRequest0.getShippingInfo().setServiceLevelId(0);
rateRequest0.getShippingInfo().setDateShipped(LocalDateTime.parse("2020-12-23T23:54:10.2649036Z", DateTimeFormatter.ISO_DATE_TIME));
rateRequest0.getShippingInfo().setOptions(new CustomsOptions());
rateRequest0.getShippingInfo().getOptions().setIsAPOFPODPOUSTerritory(false);
rateRequest0.getShippingInfo().getOptions().setIsInternationalShipment(false);
rateRequest0.getShippingInfo().getOptions().setShipmentContentType(ShipmentContentTypeEnum.CONTENT_TYPE_SAMPLE);
rateRequest0.getShippingInfo().setAddressFrom(new ShipFromAddress());
rateRequest0.getShippingInfo().getAddressFrom().setCompanyName("iDrive Logistics");
rateRequest0.getShippingInfo().getAddressFrom().setEmail("sales@idrivelogistics.com");
rateRequest0.getShippingInfo().getAddressFrom().setPhoneNumber("(888) 797-0929");
rateRequest0.getShippingInfo().getAddressFrom().setAddress1("2600 Executive Pkwy #160");
rateRequest0.getShippingInfo().getAddressFrom().setAddress2("");
rateRequest0.getShippingInfo().getAddressFrom().setCity("Lehi");
rateRequest0.getShippingInfo().getAddressFrom().setStateOrProvince("UT");
rateRequest0.getShippingInfo().getAddressFrom().setPostalCode("84043");
rateRequest0.getShippingInfo().getAddressFrom().setCountryCode("US");
rateRequest0.getShippingInfo().setAddressTo(new ShipToAddress());
rateRequest0.getShippingInfo().getAddressTo().setAttentionOf("Mr. Jones");
rateRequest0.getShippingInfo().getAddressTo().setCompanyName("iDrive Logistics");
rateRequest0.getShippingInfo().getAddressTo().setEmail("");
rateRequest0.getShippingInfo().getAddressTo().setPhoneNumber("");
rateRequest0.getShippingInfo().getAddressTo().setAddress1("2605 Executive Pkwy #160");
rateRequest0.getShippingInfo().getAddressTo().setAddress2("");
rateRequest0.getShippingInfo().getAddressTo().setIsResidential(false);
rateRequest0.getShippingInfo().getAddressTo().setCity("Lehi");
rateRequest0.getShippingInfo().getAddressTo().setStateOrProvince("UT");
rateRequest0.getShippingInfo().getAddressTo().setPostalCode("84043");
rateRequest0.getShippingInfo().getAddressTo().setCountryCode("US");
rateRequest0.getShippingInfo().setParcels(new LinkedList<>());

ParcelInformation rateRequest0ShippingInfoParcels0 = new ParcelInformation();
rateRequest0ShippingInfoParcels0.setPackagingId("");
rateRequest0ShippingInfoParcels0.setWeightInPounds(0.4);
rateRequest0ShippingInfoParcels0.setLengthInInches(5);
rateRequest0ShippingInfoParcels0.setWidthInInches(4);
rateRequest0ShippingInfoParcels0.setHeightInInches(12);
rateRequest0ShippingInfoParcels0.setOptions(new ParcelOptions());
rateRequest0ShippingInfoParcels0.getOptions().setReturn(ReturnEnum.NOT_APPLICABLE);
rateRequest0ShippingInfoParcels0.getOptions().setInsuranceAmount(0);
rateRequest0ShippingInfoParcels0.getOptions().setSignature(SignatureEnum.NOT_APPLICABLE);
rateRequest0ShippingInfoParcels0.getOptions().setCod(new CODOptions());
rateRequest0ShippingInfoParcels0.getOptions().getCod().setCodType(CodTypeEnum.NOT_APPLICABLE);
rateRequest0ShippingInfoParcels0.getOptions().getCod().setCodAmount(0);
rateRequest0ShippingInfoParcels0.getOptions().setMachinable(true);
rateRequest0ShippingInfoParcels0.getOptions().setHoldForPickup(false);
rateRequest0.getShippingInfo().getParcels().add(rateRequest0ShippingInfoParcels0);

rateRequest.add(rateRequest0);

RateRequest rateRequest1 = new RateRequest();
rateRequest1.setAccessToken("YOUR ACCESS TOKEN");
rateRequest1.setShippingInfo(new ShippingInformation());
rateRequest1.getShippingInfo().setCarrierClientContractId(2526);
rateRequest1.getShippingInfo().setServiceLevelId(0);
rateRequest1.getShippingInfo().setDateShipped(LocalDateTime.parse("2020-12-23T23:54:10.2649036Z", DateTimeFormatter.ISO_DATE_TIME));
rateRequest1.getShippingInfo().setOptions(new CustomsOptions());
rateRequest1.getShippingInfo().getOptions().setIsAPOFPODPOUSTerritory(false);
rateRequest1.getShippingInfo().getOptions().setIsInternationalShipment(false);
rateRequest1.getShippingInfo().getOptions().setShipmentContentType(ShipmentContentTypeEnum.CONTENT_TYPE_SAMPLE);
rateRequest1.getShippingInfo().setAddressFrom(new ShipFromAddress());
rateRequest1.getShippingInfo().getAddressFrom().setCompanyName("iDrive Logistics");
rateRequest1.getShippingInfo().getAddressFrom().setEmail("sales@idrivelogistics.com");
rateRequest1.getShippingInfo().getAddressFrom().setPhoneNumber("(888) 797-0929");
rateRequest1.getShippingInfo().getAddressFrom().setAddress1("2600 Executive Pkwy #160");
rateRequest1.getShippingInfo().getAddressFrom().setAddress2("");
rateRequest1.getShippingInfo().getAddressFrom().setCity("Lehi");
rateRequest1.getShippingInfo().getAddressFrom().setStateOrProvince("UT");
rateRequest1.getShippingInfo().getAddressFrom().setPostalCode("84043");
rateRequest1.getShippingInfo().getAddressFrom().setCountryCode("US");
rateRequest1.getShippingInfo().setAddressTo(new ShipToAddress());
rateRequest1.getShippingInfo().getAddressTo().setAttentionOf("Mr. Jones");
rateRequest1.getShippingInfo().getAddressTo().setCompanyName("iDrive Logistics");
rateRequest1.getShippingInfo().getAddressTo().setEmail("");
rateRequest1.getShippingInfo().getAddressTo().setPhoneNumber("");
rateRequest1.getShippingInfo().getAddressTo().setAddress1("2605 Executive Pkwy #160");
rateRequest1.getShippingInfo().getAddressTo().setAddress2("");
rateRequest1.getShippingInfo().getAddressTo().setIsResidential(false);
rateRequest1.getShippingInfo().getAddressTo().setCity("Lehi");
rateRequest1.getShippingInfo().getAddressTo().setStateOrProvince("UT");
rateRequest1.getShippingInfo().getAddressTo().setPostalCode("84043");
rateRequest1.getShippingInfo().getAddressTo().setCountryCode("US");
rateRequest1.getShippingInfo().setParcels(new LinkedList<>());

ParcelInformation rateRequest1ShippingInfoParcels0 = new ParcelInformation();
rateRequest1ShippingInfoParcels0.setPackagingId("");
rateRequest1ShippingInfoParcels0.setWeightInPounds(0.4);
rateRequest1ShippingInfoParcels0.setLengthInInches(5);
rateRequest1ShippingInfoParcels0.setWidthInInches(4);
rateRequest1ShippingInfoParcels0.setHeightInInches(12);
rateRequest1ShippingInfoParcels0.setOptions(new ParcelOptions());
rateRequest1ShippingInfoParcels0.getOptions().setReturn(ReturnEnum.NOT_APPLICABLE);
rateRequest1ShippingInfoParcels0.getOptions().setInsuranceAmount(0);
rateRequest1ShippingInfoParcels0.getOptions().setSignature(SignatureEnum.NOT_APPLICABLE);
rateRequest1ShippingInfoParcels0.getOptions().setCod(new CODOptions());
rateRequest1ShippingInfoParcels0.getOptions().getCod().setCodType(CodTypeEnum.NOT_APPLICABLE);
rateRequest1ShippingInfoParcels0.getOptions().getCod().setCodAmount(0);
rateRequest1ShippingInfoParcels0.getOptions().setMachinable(true);
rateRequest1ShippingInfoParcels0.getOptions().setHoldForPickup(false);
rateRequest1.getShippingInfo().getParcels().add(rateRequest1ShippingInfoParcels0);

rateRequest.add(rateRequest1);

RateRequest rateRequest2 = new RateRequest();
rateRequest2.setAccessToken("YOUR ACCESS TOKEN");
rateRequest2.setShippingInfo(new ShippingInformation());
rateRequest2.getShippingInfo().setCarrierClientContractId(2526);
rateRequest2.getShippingInfo().setServiceLevelId(0);
rateRequest2.getShippingInfo().setDateShipped(LocalDateTime.parse("2020-12-23T23:54:10.2649036Z", DateTimeFormatter.ISO_DATE_TIME));
rateRequest2.getShippingInfo().setOptions(new CustomsOptions());
rateRequest2.getShippingInfo().getOptions().setIsAPOFPODPOUSTerritory(false);
rateRequest2.getShippingInfo().getOptions().setIsInternationalShipment(false);
rateRequest2.getShippingInfo().getOptions().setShipmentContentType(ShipmentContentTypeEnum.CONTENT_TYPE_SAMPLE);
rateRequest2.getShippingInfo().setAddressFrom(new ShipFromAddress());
rateRequest2.getShippingInfo().getAddressFrom().setCompanyName("iDrive Logistics");
rateRequest2.getShippingInfo().getAddressFrom().setEmail("sales@idrivelogistics.com");
rateRequest2.getShippingInfo().getAddressFrom().setPhoneNumber("(888) 797-0929");
rateRequest2.getShippingInfo().getAddressFrom().setAddress1("2600 Executive Pkwy #160");
rateRequest2.getShippingInfo().getAddressFrom().setAddress2("");
rateRequest2.getShippingInfo().getAddressFrom().setCity("Lehi");
rateRequest2.getShippingInfo().getAddressFrom().setStateOrProvince("UT");
rateRequest2.getShippingInfo().getAddressFrom().setPostalCode("84043");
rateRequest2.getShippingInfo().getAddressFrom().setCountryCode("US");
rateRequest2.getShippingInfo().setAddressTo(new ShipToAddress());
rateRequest2.getShippingInfo().getAddressTo().setAttentionOf("Mr. Jones");
rateRequest2.getShippingInfo().getAddressTo().setCompanyName("iDrive Logistics");
rateRequest2.getShippingInfo().getAddressTo().setEmail("");
rateRequest2.getShippingInfo().getAddressTo().setPhoneNumber("");
rateRequest2.getShippingInfo().getAddressTo().setAddress1("2605 Executive Pkwy #160");
rateRequest2.getShippingInfo().getAddressTo().setAddress2("");
rateRequest2.getShippingInfo().getAddressTo().setIsResidential(false);
rateRequest2.getShippingInfo().getAddressTo().setCity("Lehi");
rateRequest2.getShippingInfo().getAddressTo().setStateOrProvince("UT");
rateRequest2.getShippingInfo().getAddressTo().setPostalCode("84043");
rateRequest2.getShippingInfo().getAddressTo().setCountryCode("US");
rateRequest2.getShippingInfo().setParcels(new LinkedList<>());

ParcelInformation rateRequest2ShippingInfoParcels0 = new ParcelInformation();
rateRequest2ShippingInfoParcels0.setPackagingId("");
rateRequest2ShippingInfoParcels0.setWeightInPounds(0.4);
rateRequest2ShippingInfoParcels0.setLengthInInches(5);
rateRequest2ShippingInfoParcels0.setWidthInInches(4);
rateRequest2ShippingInfoParcels0.setHeightInInches(12);
rateRequest2ShippingInfoParcels0.setOptions(new ParcelOptions());
rateRequest2ShippingInfoParcels0.getOptions().setReturn(ReturnEnum.NOT_APPLICABLE);
rateRequest2ShippingInfoParcels0.getOptions().setInsuranceAmount(0);
rateRequest2ShippingInfoParcels0.getOptions().setSignature(SignatureEnum.NOT_APPLICABLE);
rateRequest2ShippingInfoParcels0.getOptions().setCod(new CODOptions());
rateRequest2ShippingInfoParcels0.getOptions().getCod().setCodType(CodTypeEnum.NOT_APPLICABLE);
rateRequest2ShippingInfoParcels0.getOptions().getCod().setCodAmount(0);
rateRequest2ShippingInfoParcels0.getOptions().setMachinable(true);
rateRequest2ShippingInfoParcels0.getOptions().setHoldForPickup(false);
rateRequest2.getShippingInfo().getParcels().add(rateRequest2ShippingInfoParcels0);

rateRequest.add(rateRequest2);


ratesController.getMultipleRatesAsync(rateRequest).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

