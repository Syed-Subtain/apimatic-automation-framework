# Country Codes

```java
CountryCodesController countryCodesController = client.getCountryCodesController();
```

## Class Name

`CountryCodesController`


# Get Country Codes

Country information is needed for constructing addresses.

```java
CompletableFuture<CountryCodesResponsev21> getCountryCodesAsync(
    final CountryCodesRequestv21 input)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `input` | [`CountryCodesRequestv21`](/doc/models/country-codes-requestv-21.md) | Body, Optional | - |

## Response Type

[`CountryCodesResponsev21`](/doc/models/country-codes-responsev-21.md)

## Example Usage

```java
CountryCodesRequestv21 input = new CountryCodesRequestv21();
input.setAccessToken("<YOUR ACCESS TOKEN>");
input.setAsClientId(14);

countryCodesController.getCountryCodesAsync(input).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

## Example Response *(as JSON)*

```json
{
  "countryCodeList": [
    {
      "countryId": 10,
      "countryName": "Antarctica",
      "alpha2CountryCode": "AQ"
    },
    {
      "countryId": 840,
      "countryName": "United States",
      "alpha2CountryCode": "US"
    }
  ],
  "error": {
    "details": [],
    "hasError": false
  }
}
```

