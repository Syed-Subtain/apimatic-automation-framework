# Authentication

```java
AuthenticationController authenticationController = client.getAuthenticationController();
```

## Class Name

`AuthenticationController`

## Methods

* [Get Token](/doc/controllers/authentication.md#get-token)
* [Refresh Token](/doc/controllers/authentication.md#refresh-token)


# Get Token

Token contains an expiration date, TokenExpirationDate, that expires in 30 days. When the token expires, use 'RefreshToken' endpoint to obtain a new token.

```java
CompletableFuture<SecurityToken> getTokenAsync(
    final Credentials input)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `input` | [`Credentials`](/doc/models/credentials.md) | Body, Optional | - |

## Response Type

[`SecurityToken`](/doc/models/security-token.md)

## Example Usage

```java
Credentials input = new Credentials();
input.setUserName("<Your UserName>");
input.setPassword("<Your Password>");

authenticationController.getTokenAsync(input).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

## Example Response *(as JSON)*

```json
{
  "accessToken": "C_SkR2QvI25BljqKgVpt1d... (Truncated)",
  "refreshToken": "0e842ea7c4a046ceab8b5e3283321a08",
  "refreshTokenExpirationDate": "2020-12-23T23:54:10.3273331Z",
  "accessTokenExpirationDate": "2020-12-23T23:54:10.3273331Z",
  "error": {
    "details": [],
    "hasError": false
  }
}
```


# Refresh Token

This method must be called before the refresh token expiration date, TokenExpirationDate. Token expires in 30 days.

```java
CompletableFuture<SecurityToken> refreshTokenAsync(
    final SecurityTokenRequest input)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `input` | [`SecurityTokenRequest`](/doc/models/security-token-request.md) | Body, Optional | - |

## Response Type

[`SecurityToken`](/doc/models/security-token.md)

## Example Usage

```java
SecurityTokenRequest input = new SecurityTokenRequest();
input.setRefreshToken("<YOUR REFRESH TOKEN>");

authenticationController.refreshTokenAsync(input).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

## Example Response *(as JSON)*

```json
{
  "accessToken": "C_SkR2QvI25BljqKgVpt1d... (Truncated)",
  "refreshToken": "0e842ea7c4a046ceab8b5e3283321a08",
  "refreshTokenExpirationDate": "2020-12-23T23:54:10.3273331Z",
  "accessTokenExpirationDate": "2020-12-23T23:54:10.3273331Z",
  "error": {
    "details": [],
    "hasError": false
  }
}
```

