# Account Information

```java
AccountInformationController accountInformationController = client.getAccountInformationController();
```

## Class Name

`AccountInformationController`


# Get Carrier Balance

Includes:Threshold, Recharge Amount, and Balance.

```java
CompletableFuture<GetCarrierBalanceResponsev21> getCarrierBalanceAsync(
    final GetCarrierBalanceRequestv21 input)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `input` | [`GetCarrierBalanceRequestv21`](/doc/models/get-carrier-balance-requestv-21.md) | Body, Optional | - |

## Response Type

[`GetCarrierBalanceResponsev21`](/doc/models/get-carrier-balance-responsev-21.md)

## Example Usage

```java
GetCarrierBalanceRequestv21 input = new GetCarrierBalanceRequestv21();
input.setAccessToken("<YOUR ACCESS TOKEN>");
input.setCarrierClientContractId(34);
input.setAsClientId(12);

accountInformationController.getCarrierBalanceAsync(input).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

## Example Response *(as JSON)*

```json
{
  "threshold": 20.0,
  "rechargeAmount": 10.0,
  "balance": 23.45,
  "error": {
    "details": [],
    "hasError": false
  }
}
```

