# Rates Display

```java
RatesDisplayController ratesDisplayController = client.getRatesDisplayController();
```

## Class Name

`RatesDisplayController`


# Get Rates With Display

Before creating a shipping label,
you can use this method to get a
break down of all shipping charges.
This allows you to determine
how much it would cost if you were to
actually send the parcels.

NOTE: HTTPS is Required to recieve a response.

```java
CompletableFuture<RateResponse> getRatesWithDisplayAsync(
    final RateRequest rateRequest)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `rateRequest` | [`RateRequest`](/doc/models/rate-request.md) | Body, Optional | Shipping and parcel information<br>neccessary to calculate rates. |

## Response Type

[`RateResponse`](/doc/models/rate-response.md)

## Example Usage

```java
RateRequest rateRequest = new RateRequest();
rateRequest.setAccessToken("YOUR ACCESS TOKEN");
rateRequest.setShippingInfo(new ShippingInformation());
rateRequest.getShippingInfo().setCarrierClientContractId(2526);
rateRequest.getShippingInfo().setServiceLevelId(0);
rateRequest.getShippingInfo().setDateShipped(LocalDateTime.parse("2020-12-23T23:54:10.2649036Z", DateTimeFormatter.ISO_DATE_TIME));
rateRequest.getShippingInfo().setOptions(new CustomsOptions());
rateRequest.getShippingInfo().getOptions().setIsAPOFPODPOUSTerritory(false);
rateRequest.getShippingInfo().getOptions().setIsInternationalShipment(false);
rateRequest.getShippingInfo().getOptions().setShipmentContentType(ShipmentContentTypeEnum.CONTENT_TYPE_SAMPLE);
rateRequest.getShippingInfo().setAddressFrom(new ShipFromAddress());
rateRequest.getShippingInfo().getAddressFrom().setCompanyName("iDrive Logistics");
rateRequest.getShippingInfo().getAddressFrom().setEmail("sales@idrivelogistics.com");
rateRequest.getShippingInfo().getAddressFrom().setPhoneNumber("(888) 797-0929");
rateRequest.getShippingInfo().getAddressFrom().setAddress1("2600 Executive Pkwy #160");
rateRequest.getShippingInfo().getAddressFrom().setAddress2("");
rateRequest.getShippingInfo().getAddressFrom().setCity("Lehi");
rateRequest.getShippingInfo().getAddressFrom().setStateOrProvince("UT");
rateRequest.getShippingInfo().getAddressFrom().setPostalCode("84043");
rateRequest.getShippingInfo().getAddressFrom().setCountryCode("US");
rateRequest.getShippingInfo().setAddressTo(new ShipToAddress());
rateRequest.getShippingInfo().getAddressTo().setAttentionOf("Mr. Jones");
rateRequest.getShippingInfo().getAddressTo().setCompanyName("iDrive Logistics");
rateRequest.getShippingInfo().getAddressTo().setEmail("");
rateRequest.getShippingInfo().getAddressTo().setPhoneNumber("");
rateRequest.getShippingInfo().getAddressTo().setAddress1("2605 Executive Pkwy #160");
rateRequest.getShippingInfo().getAddressTo().setAddress2("");
rateRequest.getShippingInfo().getAddressTo().setIsResidential(false);
rateRequest.getShippingInfo().getAddressTo().setCity("Lehi");
rateRequest.getShippingInfo().getAddressTo().setStateOrProvince("UT");
rateRequest.getShippingInfo().getAddressTo().setPostalCode("84043");
rateRequest.getShippingInfo().getAddressTo().setCountryCode("US");
rateRequest.getShippingInfo().setParcels(new LinkedList<>());

ParcelInformation rateRequestShippingInfoParcels0 = new ParcelInformation();
rateRequestShippingInfoParcels0.setPackagingId("");
rateRequestShippingInfoParcels0.setWeightInPounds(0.4);
rateRequestShippingInfoParcels0.setLengthInInches(5);
rateRequestShippingInfoParcels0.setWidthInInches(4);
rateRequestShippingInfoParcels0.setHeightInInches(12);
rateRequestShippingInfoParcels0.setOptions(new ParcelOptions());
rateRequestShippingInfoParcels0.getOptions().setReturn(ReturnEnum.NOT_APPLICABLE);
rateRequestShippingInfoParcels0.getOptions().setInsuranceAmount(0);
rateRequestShippingInfoParcels0.getOptions().setSignature(SignatureEnum.NOT_APPLICABLE);
rateRequestShippingInfoParcels0.getOptions().setCod(new CODOptions());
rateRequestShippingInfoParcels0.getOptions().getCod().setCodType(CodTypeEnum.NOT_APPLICABLE);
rateRequestShippingInfoParcels0.getOptions().getCod().setCodAmount(0);
rateRequestShippingInfoParcels0.getOptions().setMachinable(true);
rateRequestShippingInfoParcels0.getOptions().setHoldForPickup(false);
rateRequest.getShippingInfo().getParcels().add(rateRequestShippingInfoParcels0);


ratesDisplayController.getRatesWithDisplayAsync(rateRequest).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

