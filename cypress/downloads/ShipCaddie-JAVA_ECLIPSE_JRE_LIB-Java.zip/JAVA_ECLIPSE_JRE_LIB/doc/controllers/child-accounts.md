# Child Accounts

```java
ChildAccountsController childAccountsController = client.getChildAccountsController();
```

## Class Name

`ChildAccountsController`


# Get Child Accounts

Obtain child accounts which are associated with this account.

```java
CompletableFuture<GetChildAccountsResponsev21> getChildAccountsAsync(
    final GetChildAccountsRequestv21 input)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `input` | [`GetChildAccountsRequestv21`](/doc/models/get-child-accounts-requestv-21.md) | Body, Optional | - |

## Response Type

[`GetChildAccountsResponsev21`](/doc/models/get-child-accounts-responsev-21.md)

## Example Usage

```java
GetChildAccountsRequestv21 input = new GetChildAccountsRequestv21();
input.setAccessToken("<YOUR ACCESS TOKEN>");

childAccountsController.getChildAccountsAsync(input).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

## Example Response *(as JSON)*

```json
{
  "error": {
    "details": [],
    "hasError": false
  },
  "childAccounts": [
    {
      "clientId": 343,
      "name": "Company A",
      "isEnabled": true
    },
    {
      "clientId": 233,
      "name": "Company B",
      "isEnabled": false
    }
  ]
}
```

