# Carrier Details

```java
CarrierDetailsController carrierDetailsController = client.getCarrierDetailsController();
```

## Class Name

`CarrierDetailsController`

## Methods

* [Get Carrier Service Information](/doc/controllers/carrier-details.md#get-carrier-service-information)
* [Verify Package Length Girth Limit](/doc/controllers/carrier-details.md#verify-package-length-girth-limit)
* [Get Carrier Parcel Specification](/doc/controllers/carrier-details.md#get-carrier-parcel-specification)


# Get Carrier Service Information

Multiple API methods require this information.

```java
CompletableFuture<GetCarrierServiceInformationResponsev21> getCarrierServiceInformationAsync(
    final GetCarrierServiceInformationRequestv21 input)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `input` | [`GetCarrierServiceInformationRequestv21`](/doc/models/get-carrier-service-information-requestv-21.md) | Body, Optional | - |

## Response Type

[`GetCarrierServiceInformationResponsev21`](/doc/models/get-carrier-service-information-responsev-21.md)

## Example Usage

```java
GetCarrierServiceInformationRequestv21 input = new GetCarrierServiceInformationRequestv21();
input.setAccessToken("<YOUR ACCESS TOKEN>");
input.setAsClientId(12);

carrierDetailsController.getCarrierServiceInformationAsync(input).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

## Example Response *(as JSON)*

```json
{
  "carrierServiceList": [
    {
      "carrierClientContractId": 123,
      "affillateName": "USPS",
      "carrierName": "USPS",
      "nickName": "United States Postal Service",
      "serviceLevels": [
        {
          "carrierServiceLevelID": 23,
          "name": "Priority Mail",
          "parcelWeightLimit": 70.0,
          "isInternational": false
        },
        {
          "carrierServiceLevelID": 34,
          "name": "Express Mail Int'l",
          "parcelWeightLimit": 70.0,
          "isInternational": true
        }
      ],
      "error": {
        "details": [],
        "hasError": false
      }
    }
  ],
  "error": {
    "details": [],
    "hasError": false
  }
}
```


# Verify Package Length Girth Limit

Verifies packages height, length, and width.

```java
CompletableFuture<VerifyPackageLengthGirthLimitResponsev21> verifyPackageLengthGirthLimitAsync(
    final VerifyPackageLengthGirthLimitRequestv21 input)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `input` | [`VerifyPackageLengthGirthLimitRequestv21`](/doc/models/verify-package-length-girth-limit-requestv-21.md) | Body, Optional | - |

## Response Type

[`VerifyPackageLengthGirthLimitResponsev21`](/doc/models/verify-package-length-girth-limit-responsev-21.md)

## Example Usage

```java
VerifyPackageLengthGirthLimitRequestv21 input = new VerifyPackageLengthGirthLimitRequestv21();
input.setAccessToken("<YOUR ACCESS TOKEN>");
input.setRequest(new PackageLengthGirthModelV21());
input.getRequest().setCarrierServiceLevelId(12);
input.getRequest().setPackageList(new LinkedList<>());

PackagesV21 inputRequestPackageList0 = new PackagesV21();
inputRequestPackageList0.setLength(6);
inputRequestPackageList0.setWidth(8);
inputRequestPackageList0.setHeight(12);
input.getRequest().getPackageList().add(inputRequestPackageList0);

PackagesV21 inputRequestPackageList1 = new PackagesV21();
inputRequestPackageList1.setLength(6);
inputRequestPackageList1.setWidth(8);
inputRequestPackageList1.setHeight(12);
input.getRequest().getPackageList().add(inputRequestPackageList1);


carrierDetailsController.verifyPackageLengthGirthLimitAsync(input).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

## Example Response *(as JSON)*

```json
{
  "error": {
    "details": [],
    "hasError": false
  },
  "valid": true
}
```


# Get Carrier Parcel Specification

Details include parcel weight limits and maximum dimensions.

```java
CompletableFuture<GetCarrierParcelSpecificationResponsev21> getCarrierParcelSpecificationAsync(
    final GetCarrierParcelSpecificationRequestv21 input)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `input` | [`GetCarrierParcelSpecificationRequestv21`](/doc/models/get-carrier-parcel-specification-requestv-21.md) | Body, Optional | - |

## Response Type

[`GetCarrierParcelSpecificationResponsev21`](/doc/models/get-carrier-parcel-specification-responsev-21.md)

## Example Usage

```java
GetCarrierParcelSpecificationRequestv21 input = new GetCarrierParcelSpecificationRequestv21();
input.setAccessToken("<YOUR ACCESS TOKEN>");
input.setCarrierClientContractId(24);
input.setAsClientId(12);

carrierDetailsController.getCarrierParcelSpecificationAsync(input).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

## Example Response *(as JSON)*

```json
{
  "parcelDetails": [
    {
      "parcelId": "102-0",
      "name": "Large Envelope or Flat",
      "description": "Large Envelope or Flat",
      "lengthInInches": 12.0,
      "widthInInches": 0.75,
      "heightInInches": 4.0,
      "weightLimit": 0.8,
      "packagingWeight": 0.0
    },
    {
      "parcelId": "115-0",
      "name": "Flat Rate Large Box",
      "description": "Large Flat Rate Box",
      "lengthInInches": 12.0,
      "widthInInches": 5.5,
      "heightInInches": 4.0,
      "weightLimit": 70.0,
      "packagingWeight": 0.0
    }
  ],
  "error": {
    "details": [],
    "hasError": false
  }
}
```

