
# Client Class Documentation

The following parameters are configurable for the API Client:

| Parameter | Type | Description |
|  --- | --- | --- |
| `environment` | Environment | The API environment. <br> **Default: `Environment.PRODUCTION`** |
| `httpClientConfig` | `ReadonlyHttpClientConfiguration` | Http Client Configuration instance.<br>* See available [builder methods here](/doc/http-client-configuration-builder.md). |
| `accessToken` | `String` | The OAuth 2.0 Access Token to use for API requests. |

The API client can be initialized as follows:

```java
ShipCaddieClient client = new ShipCaddieClient.Builder()
    .httpClientConfig(configBuilder -> configBuilder
            .timeout(0))
    .accessToken("AccessToken")
    .environment(Environment.PRODUCTION)
    .build();
```

## ShipCaddieClient Class

The gateway for the SDK. This class acts as a factory for the Controllers and also holds the configuration of the SDK.

### Controllers

| Name | Description | Return Type |
|  --- | --- | --- |
| `getShipmentsController()` | Provides access to Shipments controller. | `ShipmentsController` |
| `getManifestController()` | Provides access to Manifest controller. | `ManifestController` |
| `getAccountInformationController()` | Provides access to AccountInformation controller. | `AccountInformationController` |
| `getCarrierDetailsController()` | Provides access to CarrierDetails controller. | `CarrierDetailsController` |
| `getChildAccountsController()` | Provides access to ChildAccounts controller. | `ChildAccountsController` |
| `getCountryCodesController()` | Provides access to CountryCodes controller. | `CountryCodesController` |
| `getRatesController()` | Provides access to Rates controller. | `RatesController` |
| `getRatesDisplayController()` | Provides access to RatesDisplay controller. | `RatesDisplayController` |
| `getLabelsController()` | Provides access to Labels controller. | `LabelsController` |
| `getAuthenticationController()` | Provides access to Authentication controller. | `AuthenticationController` |
| `getRegistrationController()` | Provides access to Registration controller. | `RegistrationController` |
| `getEmailNotificationsController()` | Provides access to EmailNotifications controller. | `EmailNotificationsController` |
| `getAddressValidationController()` | Provides access to AddressValidation controller. | `AddressValidationController` |
| `getAddressValidationShipmentController()` | Provides access to AddressValidationShipment controller. | `AddressValidationShipmentController` |

### Methods

| Name | Description | Return Type |
|  --- | --- | --- |
| `shutdown()` | Shutdown the underlying HttpClient instance. | `void` |
| `getEnvironment()` | Current API environment. | `Environment` |
| `getHttpClient()` | The HTTP Client instance to use for making HTTP requests. | `HttpClient` |
| `getHttpClientConfig()` | Http Client Configuration instance. | `ReadonlyHttpClientConfiguration` |
| `getAccessTokenCredentials()` | The credentials to use with AccessToken. | `AccessTokenCredentials` |
| `getAccessToken()` | OAuth 2.0 Access Token. | `String` |
| `getBaseUri(Server server)` | Get base URI by current environment | `String` |
| `getBaseUri()` | Get base URI by current environment | `String` |

