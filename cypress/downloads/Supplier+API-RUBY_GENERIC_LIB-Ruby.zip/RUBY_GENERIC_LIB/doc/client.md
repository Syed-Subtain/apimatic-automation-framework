
# Client Class Documentation

The following parameters are configurable for the API Client:

| Parameter | Type | Description |
|  --- | --- | --- |
| `jwt` | `String` | Token which need to be passed in every request as GET parameter. You will get this token in authorization response. Token is valid 1 hour. |
| `push_server_url` | `String` | In some API call BookingPal will send POST request (push message) to the PMS for URL which you provide in API 'Push Notification'. You can test these calls to in this documentation, just you will need to set your URL here on specific API call, on Configure button in the right section of specific API function<br>*Default*: `'https://www.yourEndpoint.url'` |
| `environment` | Environment | The API environment. <br> **Default: `Environment.PRODUCTION`** |
| `connection` | `Faraday::Connection` | The Faraday connection object passed by the SDK user for making requests |
| `adapter` | `Faraday::Adapter` | The Faraday adapter object passed by the SDK user for performing http requests |
| `timeout` | `Float` | The value to use for connection timeout. <br> **Default: 60** |
| `max_retries` | `Integer` | The number of times to retry an endpoint call if it fails. <br> **Default: 0** |
| `retry_interval` | `Float` | Pause in seconds between retries. <br> **Default: 1** |
| `backoff_factor` | `Float` | The amount to multiply each successive retry's interval amount by in order to provide backoff. <br> **Default: 2** |
| `retry_statuses` | `Array` | A list of HTTP statuses to retry. <br> **Default: [408, 413, 429, 500, 502, 503, 504, 521, 522, 524]** |
| `retry_methods` | `Array` | A list of HTTP methods to retry. <br> **Default: %i[get put]** |

The API client can be initialized as follows:

```ruby
client = SupplierApi::Client.new(
  jwt: 'jwt',
  environment: Environment::PRODUCTION,
  push_server_url: 'https://www.yourEndpoint.url',
)
```

## Supplier API Client

The gateway for the SDK. This class acts as a factory for the Controllers and also holds the configuration of the SDK.

## Controllers

| Name | Description |
|  --- | --- |
| property_managers | Gets PropertyManagersController |
| authorization | Gets AuthorizationController |
| images | Gets ImagesController |
| rates_and_availability | Gets RatesAndAvailabilityController |
| fee_and_tax | Gets FeeAndTaxController |
| fee_and_tax_mandatory_at_the_property_level | Gets FeeAndTaxMandatoryAtThePropertyLevelController |
| yields | Gets YieldsController |
| testing_of_message_api_calls | Gets TestingOfMessageAPICallsController |
| messaging | Gets MessagingController |
| push_notification | Gets PushNotificationController |
| reservation_notifications | Gets ReservationNotificationsController |
| asynchronous_push_messages | Gets AsynchronousPushMessagesController |
| licenses | Gets LicensesController |
| product | Gets ProductController |
| validation | Gets ValidationController |
| request_to_book | Gets RequestToBookController |
| los_pricing | Gets LOSPricingController |
| configuration_in_supplier_api | Gets ConfigurationInSupplierAPIController |

