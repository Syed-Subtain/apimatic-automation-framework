# Testingofmessage AP Icalls

```ruby
testingofmessage_ap_icalls_controller = client.testingofmessage_ap_icalls
```

## Class Name

`TestingofmessageAPIcallsController`

## Methods

* [Get Test Message Threads](../../doc/controllers/testingofmessage-ap-icalls.md#get-test-message-threads)
* [Get Test Message List for Specific Thread](../../doc/controllers/testingofmessage-ap-icalls.md#get-test-message-list-for-specific-thread)
* [Post New Test Message for Specific Thread](../../doc/controllers/testingofmessage-ap-icalls.md#post-new-test-message-for-specific-thread)


# Get Test Message Threads

This function allows the logged in user to get all message threads or message threads with an unresponded message from guest for the whole PM. You need to use PM credentials. There is also paging as optional values. If you do not pass this value, we will return the first page and 10 threads per page.

Since API calls for messages depend on channel connections and these values will exist in BookingPal only if guests on channel create some message, these calls can work only on production. So for testing purposes we’ve  built an additional endpoint with the same API calls where you will be able to test these calls.

Note: To be able to test these calls, you need to have at least 1 property, since we will in response return you messages for 1 property from your PM.

```ruby
def get_test_message_threads(page,
                             limit,
                             thread_type)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `page` | `Integer` | Query, Required | - |
| `limit` | `Integer` | Query, Required | - |
| `thread_type` | `String` | Template, Required | Request all threads or only threads with unanswered message {new,all} |

## Response Type

[`GetMessageThreadsResponse`](../../doc/models/get-message-threads-response.md)

## Example Usage

```ruby
page = 2
limit = 5
thread_type = 'threadType6'

result = testing_of_message_api_calls_controller.get_test_message_threads(page, limit, thread_type)
```


# Get Test Message List for Specific Thread

Since API calls for messages depend on channel connections and these values will exist in BookingPal only if guests on channel create some message, these calls can work only on production. So for testing purposes, we’ve built an additional endpoint with the same API calls where you will be able to test these calls.

This function allows the logged-in user to get a list of all messages from passed thread Id. You need to use PM credentials

Note: To be able to test these calls, you need to have at least 1 property, since we will in response return you messages for 1 property from your PM.

```ruby
def get_test_message_list_for_specific_thread(thread_id)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `thread_id` | `String` | Template, Required | ID of thread |

## Response Type

[`GetMessageListForSpecificThreadResponse`](../../doc/models/get-message-list-for-specific-thread-response.md)

## Example Usage

```ruby
thread_id = '123'

result = testing_of_message_api_calls_controller.get_test_message_list_for_specific_thread(thread_id)
```

## Example Response *(as JSON)*

```json
{
  "message": "",
  "errorMessage": [],
  "is_error": false,
  "code": "",
  "data": [
    {
      "messages": [
        {
          "message": "Test message",
          "createdAt": "2019-11-25T12:32:39.000+0000",
          "user": "PROPERTY_MANAGER"
        }
      ]
    }
  ]
}
```


# Post New Test Message for Specific Thread

This function will allow PM to post new messages in already existing threads. Since this call is only for testing - we will not actually save these passed values.

Since API calls for messages depend on channel connections and these values will exist in BookingPal only if guests on channel create some message, these calls can work only on production. So for testing purposes, we’ve built an additional endpoint with the same API calls where you will be able to test these calls.

Note: To be able to test these calls, you need to have at least 1 property, since we will in response return to you messages for 1 property from your PM.

```ruby
def post_new_test_message_for_specific_thread(body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`PostNewMessageForSpecificThreadRequest`](../../doc/models/post-new-message-for-specific-thread-request.md) | Body, Required | - |

## Response Type

[`APIResponseWithoutData`](../../doc/models/api-response-without-data.md)

## Example Usage

```ruby
body = PostNewMessageForSpecificThreadRequest.new
body.data = MessageRequestFromSupplier.new
body.data.thread_id = 5656
body.data.message = 'new message'

result = testing_of_message_api_calls_controller.post_new_test_message_for_specific_thread(body)
```

## Example Response *(as JSON)*

```json
{
  "message": "Your request was received and put in queue",
  "errorMessage": [],
  "is_error": false,
  "code": ""
}
```

