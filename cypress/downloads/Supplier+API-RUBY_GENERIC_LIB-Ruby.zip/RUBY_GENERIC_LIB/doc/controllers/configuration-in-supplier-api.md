# Configuration in Supplier API

```ruby
configuration_in_supplier_api_controller = client.configuration_in_supplier_api
```

## Class Name

`ConfigurationInSupplierAPIController`


# Configuration in Supplier API

This function allows the logged in user to get an channels configuration.

```ruby
def configuration_in_supplier_api
```

## Response Type

[`ChannelConfigurationResponse`](../../doc/models/channel-configuration-response.md)

## Example Usage

```ruby
result = configuration_in_supplier_api_controller.configuration_in_supplier_api()
```

## Example Response *(as JSON)*

```json
{
  "message": "",
  "errorMessage": [],
  "code": "",
  "data": [
    {
      "name": "Booking.com",
      "abbreviation": "BKG",
      "logo": "https://s3.amazonaws.com/mybookingpal/pictures/raz/320331/320331/bookingWizard.png",
      "state": "VISIBLE",
      "supportValidation": true,
      "supportCreate": true,
      "supportConnect": true,
      "supportOpenClose": true,
      "supportStaticUpdate": true,
      "supportImageUpdate": true,
      "supportDynamicUpdate": true,
      "supportSynchronization": false,
      "supportCreateChannelAccount": true,
      "supportAuthorization": true,
      "supportGather": true,
      "supportChannelCancellationPolicy": true,
      "supportCancelFormPm": false,
      "supportModificationFromPm": false,
      "bookingType": "Instant",
      "ratesAndAvailabilityMapping": "MapToRatePlan",
      "acceptsPropertyType": "Both",
      "nativePropertyType": "Hotels",
      "minimumProperties": 0
    }
  ],
  "is_error": false
}
```

