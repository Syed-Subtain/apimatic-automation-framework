# Feeand Tax

```ruby
feeand_tax_controller = client.feeand_tax
```

## Class Name

`FeeandTaxController`

## Methods

* [Create Fee and Tax](../../doc/controllers/feeand-tax.md#create-fee-and-tax)
* [Get Fee and Tax List by Product Id](../../doc/controllers/feeand-tax.md#get-fee-and-tax-list-by-product-id)


# Create Fee and Tax

This function allows the logged in user to set fees (i.e. cleaning fee, damage waiver, extra bed, extra person etc.) and taxes for the specific product. Here, you always need to send all fees and taxes for one property. All fees or taxes which were in our system for that property and which are not in the new request will be deleted. Taxes in the BookingPal system will always have percent value.

If you want to delete all fees and/or taxes for one property (if you do not have fees and taxes in your system for one property) send an empty list of fees and.or taxes. In short when you use this request you need to always send us a full list of fees and taxes per property, since we will do a full update.

Note: Security deposits on Airbnb must be between 100 and 5000 USD. Any value smaller or larger will default to the largest accepted value. If currencies are not in USD, BookingPal will first convert the currency to USD before posting the security deposit on Airbnb.

```ruby
def create_fee_and_tax(body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`CreateFeesandTaxesRequest`](../../doc/models/create-feesand-taxes-request.md) | Body, Required | - |

## Response Type

[`FeeTaxResponse`](../../doc/models/fee-tax-response.md)

## Example Usage

```ruby
body = CreateFeesandTaxesRequest.new
body.data = FeesandTaxes.new
body.data.product_id = 192

result = fee_and_tax_controller.create_fee_and_tax(body)
```


# Get Fee and Tax List by Product Id

This function allows the logged in user to get a fee list for the specific product.

```ruby
def get_fee_and_tax_list_by_product_id(product_id)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `product_id` | `String` | Template, Required | ID of the property |

## Response Type

[`FeeTaxResponse`](../../doc/models/fee-tax-response.md)

## Example Usage

```ruby
product_id = '1235124634'

result = fee_and_tax_controller.get_fee_and_tax_list_by_product_id(product_id)
```

