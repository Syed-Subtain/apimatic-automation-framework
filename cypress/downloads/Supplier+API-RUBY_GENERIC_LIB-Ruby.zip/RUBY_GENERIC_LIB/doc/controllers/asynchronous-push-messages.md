# Asynchronous Push Messages

```ruby
asynchronous_push_messages_controller = client.asynchronous_push_messages
```

## Class Name

`AsynchronousPushMessagesController`

## Methods

* [Validation Push Asynchronous Message](../../doc/controllers/asynchronous-push-messages.md#validation-push-asynchronous-message)
* [Product Image Push Asynchronous Message](../../doc/controllers/asynchronous-push-messages.md#product-image-push-asynchronous-message)


# Validation Push Asynchronous Message

This is POST request - push notifications (webhooks) which BookingPal will send on PMS endpoint (which is set in push notification API, field - asyncPush) after something is executed in BP. This is necessary since some API calls like validation, onboarding, etc are done over queue in our system, so you will get an asynchronous response.

In these requests, we do not have expected responses from the PMS system. Since these are just notifications.

Important note: In this doc to be able to test this - you need to set a full URL on the Configure button in the right section.

:information_source: **Note** This endpoint does not require authentication.

```ruby
def validation_push_asynchronous_message(body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`ValidationAsynchronousPushMessageRequest`](../../doc/models/validation-asynchronous-push-message-request.md) | Body, Required | - |

## Server

`Server::PUSHSERVER`

## Response Type

`void`

## Example Usage

```ruby
body = ValidationAsynchronousPushMessageRequest.new
body.supplier_id = 636753
body.type = 'BP_VALIDATION'
body.validation = []


body.validation[0] = AsynchronousValidationModel.new
body.validation[0].product_id = 291358
body.validation[0].validation_errors = 'null'
body.validation[0].valid = true

body.validation[1] = AsynchronousValidationModel.new
body.validation[1].product_id = 291356
body.validation[1].validation_errors = 'noPrice;'
body.validation[1].valid = false


result = asynchronous_push_messages_controller.validation_push_asynchronous_message(body)
```


# Product Image Push Asynchronous Message

This is POST request - push notifications (webhooks) which BookingPal will send on PMS endpoint (which is set in push notification API, field - asyncPush) after something is executed in BP. This is necessary since some API calls like validation, onboarding, etc are done over queue in our system, so you will get an asynchronous response.

In these requests, we do not have expected responses from the PMS system. Since these are just notifications.

Important note: In this doc to be able to test this - you need to set a full URL on the Configure button in the right section.

:information_source: **Note** This endpoint does not require authentication.

```ruby
def product_image_push_asynchronous_message(body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`ProductImageAsynchronousPushMessageRequest`](../../doc/models/product-image-asynchronous-push-message-request.md) | Body, Required | - |

## Server

`Server::PUSHSERVER`

## Response Type

`void`

## Example Usage

```ruby
body = ProductImageAsynchronousPushMessageRequest.new
body.supplier_id = 61692827
body.type = 'PROCESSING_IMAGES'
body.processing_image = []


body.processing_image[0] = ProductImagePushNotification.new
body.processing_image[0].name = 'Riverwalk Inn Wizard'
body.processing_image[0].product_id = '1235138415'
body.processing_image[0].alt_id = '123'
body.processing_image[0].images = []


body.processing_image[0].images[0] = ImagePushNotification.new
body.processing_image[0].images[0].success = true
body.processing_image[0].images[0].type = TypeEnum::IMPORT
body.processing_image[0].images[0].url = 'https://www.staymarquis.com/uploads/homeaway/1570665600_odQZP_bedroom62.jpg'
body.processing_image[0].images[0].version = '2021-01-29T11:53:31.000+0000'



result = asynchronous_push_messages_controller.product_image_push_asynchronous_message(body)
```

