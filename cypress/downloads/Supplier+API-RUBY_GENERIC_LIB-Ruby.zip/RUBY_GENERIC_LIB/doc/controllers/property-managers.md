# Property Managers

```ruby
property_managers_controller = client.property_managers
```

## Class Name

`PropertyManagersController`

## Methods

* [PM List](../../doc/controllers/property-managers.md#pm-list)
* [Create New Property Manager](../../doc/controllers/property-managers.md#create-new-property-manager)
* [Get Property Manager Detail Data](../../doc/controllers/property-managers.md#get-property-manager-detail-data)
* [Update Property Manager Details](../../doc/controllers/property-managers.md#update-property-manager-details)


# PM List

This API call will return a list of property managers (PM) that have been created in the BookingPal platform that is associated with your PMS.
In all requests in this API section, you need to use your PMS credentials.

```ruby
def pm_list
```

## Response Type

[`GetPMsList`](../../doc/models/get-p-ms-list.md)

## Example Usage

```ruby
result = property_managers_controller.pm_list()
```

## Example Response *(as JSON)*

```json
{
  "message": "",
  "errorMessage": [],
  "is_error": false,
  "code": "",
  "data": [
    {
      "id": 61690133,
      "name": "Test name",
      "extraName": "Test fullname",
      "emailAddress": "test001@gmail.com"
    },
    {
      "id": 61690517,
      "name": "Test",
      "extraName": "Test",
      "emailAddress": "testa002@gmail.com"
    },
    {
      "id": 61690534,
      "name": "Test",
      "extraName": "Test",
      "emailAddress": "testa003@gmail.com"
    },
    {
      "id": 61691075,
      "name": "Test",
      "extraName": "Test",
      "emailAddress": "testa004@gmail.com"
    },
    {
      "id": 61691076,
      "name": "Test",
      "extraName": "Test",
      "emailAddress": "testa005@gmail.com"
    },
    {
      "id": 61691729,
      "name": "Test",
      "extraName": "Test",
      "emailAddress": "testa103@gmail.com"
    },
    {
      "id": 61691731,
      "name": "Update Name",
      "extraName": "Update Full Name",
      "emailAddress": "te@gmail.com"
    },
    {
      "id": 61691732,
      "name": "Update Name",
      "extraName": "Update Full Name",
      "emailAddress": "testa026@gmail.com"
    },
    {
      "id": 61691733,
      "name": "Test",
      "extraName": "Test",
      "emailAddress": "testa027@gmail.com"
    },
    {
      "id": 61691734,
      "name": "Test",
      "extraName": "Test",
      "emailAddress": "testa028@gmail.com"
    },
    {
      "id": 61691735,
      "name": "Test",
      "extraName": "Test",
      "emailAddress": "testa029@gmail.com"
    },
    {
      "id": 61691736,
      "name": "Update Name",
      "extraName": "Update Full Name",
      "emailAddress": "testa0031@gmail.com"
    },
    {
      "id": 61691737,
      "name": "Update Name",
      "extraName": "Update Full Name",
      "emailAddress": "testa0032@gmail.com"
    },
    {
      "id": 61691803,
      "name": "Update Name",
      "extraName": "Update Full Name",
      "emailAddress": "testa035@gmail.com"
    },
    {
      "id": 61691852,
      "name": "Test",
      "extraName": "Test",
      "emailAddress": "testa036@gmail.com"
    },
    {
      "id": 61691861,
      "name": "Auto-lyxpz company name",
      "extraName": "Auto-dzvjr full name",
      "emailAddress": "wnvuyqfya213@pqclbzs.rli"
    },
    {
      "id": 61691868,
      "name": "Update Name",
      "extraName": "Update Full Name",
      "emailAddress": "testa038@gmail.com"
    },
    {
      "id": 61691875,
      "name": "Test",
      "extraName": "Test",
      "emailAddress": "TestPM001@gmail.com"
    },
    {
      "id": 61691876,
      "name": "Test",
      "extraName": "Test",
      "emailAddress": "TestPM002@gmail.com"
    },
    {
      "id": 61691877,
      "name": "Test",
      "extraName": "Test",
      "emailAddress": "TestPM003@gmail.com"
    },
    {
      "id": 61691878,
      "name": "Test",
      "extraName": "Test",
      "emailAddress": "TestPM004@gmail.com"
    },
    {
      "id": 61691879,
      "name": "Test",
      "extraName": "Test",
      "emailAddress": "TestPM005@gmail.com"
    },
    {
      "id": 61691880,
      "name": "Test",
      "extraName": "Test",
      "emailAddress": "TestPM006@gmail.com"
    },
    {
      "id": 61691881,
      "name": "Test",
      "extraName": "Test",
      "emailAddress": "TestPM007@gmail.com"
    },
    {
      "id": 61691882,
      "name": "Test",
      "extraName": "Test",
      "emailAddress": "TestPM008@gmail.com"
    },
    {
      "id": 61691883,
      "name": "Test",
      "extraName": "Test",
      "emailAddress": "TestPM009@gmail.com"
    },
    {
      "id": 61691884,
      "name": "Test",
      "extraName": "Test",
      "emailAddress": "TestPM010@gmail.com"
    },
    {
      "id": 61691885,
      "name": "Test",
      "extraName": "Test",
      "emailAddress": "TestPM011@gmail.com"
    },
    {
      "id": 61691886,
      "name": "Test",
      "extraName": "Test",
      "emailAddress": "TestPM012@gmail.com"
    },
    {
      "id": 61691887,
      "name": "Test",
      "extraName": "Test",
      "emailAddress": "TestPM014@gmail.com"
    },
    {
      "id": 61691888,
      "name": "Test",
      "extraName": "Test",
      "emailAddress": "TestPM015@gmail.com"
    },
    {
      "id": 61691889,
      "name": "Test",
      "extraName": "Test",
      "emailAddress": "TestPM016@gmail.com"
    },
    {
      "id": 61691896,
      "name": "Test",
      "extraName": "Test",
      "emailAddress": "TestPM017@gmail.com"
    },
    {
      "id": 61691897,
      "name": "Test",
      "extraName": "Test",
      "emailAddress": "TestPM018@gmail.com"
    },
    {
      "id": 61691898,
      "name": "Test",
      "extraName": "Test",
      "emailAddress": "TestPM019@gmail.com"
    },
    {
      "id": 61691899,
      "name": "Test",
      "extraName": "Test",
      "emailAddress": "TestPM020@gmail.com"
    },
    {
      "id": 61691900,
      "name": "Test",
      "extraName": "Test",
      "emailAddress": "TestPM021@gmail.com"
    },
    {
      "id": 61691903,
      "name": "Test",
      "extraName": "Test",
      "emailAddress": "testa0141234@gmail.com"
    },
    {
      "id": 61691904,
      "name": "Test",
      "extraName": "Test",
      "emailAddress": "testa01412345@gmail.com"
    },
    {
      "id": 61691905,
      "name": "Test",
      "extraName": "Test",
      "emailAddress": "TestPM022@gmail.com"
    },
    {
      "id": 61691906,
      "name": "Test",
      "extraName": "Test",
      "emailAddress": "TestPM023@gmail.com"
    },
    {
      "id": 61691907,
      "name": "Test",
      "extraName": "Test",
      "emailAddress": "testa014123452@gmail.com"
    },
    {
      "id": 61691908,
      "name": "Test",
      "extraName": "Test",
      "emailAddress": "testa0141234521@gmail.com"
    },
    {
      "id": 61691909,
      "name": "Test",
      "extraName": "Test",
      "emailAddress": "TestPM024@gmail.com"
    },
    {
      "id": 61691910,
      "name": "Test",
      "extraName": "Test",
      "emailAddress": "TestPM025@gmail.com"
    },
    {
      "id": 61691911,
      "name": "Test",
      "extraName": "Test",
      "emailAddress": "TestPM026@gmail.com"
    },
    {
      "id": 61691979,
      "name": "Test",
      "extraName": "Test",
      "emailAddress": "TestPM028@gmail.com"
    },
    {
      "id": 61692003,
      "name": "Test",
      "extraName": "Test",
      "emailAddress": "TestPM030@gmail.com"
    },
    {
      "id": 61692065,
      "name": "Test",
      "extraName": "Test",
      "emailAddress": "TestPM031@gmail.com"
    },
    {
      "id": 61692066,
      "name": "Test",
      "extraName": "Test",
      "emailAddress": "TestPM032@gmail.com"
    },
    {
      "id": 61692067,
      "name": "Test",
      "extraName": "Test",
      "emailAddress": "TestPM033@gmail.com"
    },
    {
      "id": 61692068,
      "name": "Update Name",
      "extraName": "Update Full Name",
      "emailAddress": "TestPM034@gmail.com"
    },
    {
      "id": 61692418,
      "name": "Test",
      "extraName": "Test",
      "emailAddress": "TestPM01130@gmail.com"
    },
    {
      "id": 61692455,
      "name": "Test",
      "extraName": "Test",
      "emailAddress": "TestPM035@gmail.com"
    },
    {
      "id": 61692456,
      "name": "Test",
      "extraName": "Test",
      "emailAddress": "TestPM036@gmail.com"
    },
    {
      "id": 61692457,
      "name": "Test",
      "extraName": "Test",
      "emailAddress": "TestPM037@gmail.com"
    },
    {
      "id": 61692552,
      "name": "Update Name",
      "extraName": "Update Full Name",
      "emailAddress": "TestPM038@gmail.com"
    },
    {
      "id": 61692554,
      "name": "Test",
      "extraName": "Test",
      "emailAddress": "TestPM999MJ@gmail.com"
    },
    {
      "id": 61692695,
      "name": "Test",
      "extraName": "Test",
      "emailAddress": "testa133@gmail.com"
    },
    {
      "id": 61692769,
      "name": "Test",
      "extraName": "Test",
      "emailAddress": "TestPM050@gmail.com"
    },
    {
      "id": 61692782,
      "name": "Test",
      "extraName": "Test",
      "emailAddress": "TestPMCreateProduct@gmail.com"
    },
    {
      "id": 61692785,
      "name": "Test",
      "extraName": "Test",
      "emailAddress": "TestPM055@gmail.com"
    },
    {
      "id": 61692787,
      "name": "Test",
      "extraName": "Test",
      "emailAddress": "TestPM056@gmail.com"
    },
    {
      "id": 61692789,
      "name": "Test",
      "extraName": "Test",
      "emailAddress": "TestPM057@gmail.com"
    },
    {
      "id": 61692790,
      "name": "Test Wiz",
      "extraName": "Test Wiz",
      "emailAddress": "TestPM058@gmail.com"
    },
    {
      "id": 61692791,
      "name": "Test wiz1",
      "extraName": "Test wiz1",
      "emailAddress": "TestPM059@gmail.com"
    },
    {
      "id": 61692793,
      "name": "Test wiz1",
      "extraName": "Test wiz1",
      "emailAddress": "TestPM060@gmail.com"
    },
    {
      "id": 61692794,
      "name": "Test wiz1",
      "extraName": "Test wiz1",
      "emailAddress": "TestPM061@gmail.com"
    },
    {
      "id": 61692795,
      "name": "Test wiz",
      "extraName": "Test wiz",
      "emailAddress": "TestPM062@gmail.com"
    },
    {
      "id": 61692797,
      "name": "Wizard Demo",
      "extraName": "Wizard Demo",
      "emailAddress": "wizarddemo@gmail.com"
    },
    {
      "id": 61692799,
      "name": "Test PM",
      "extraName": "Test PM",
      "emailAddress": "apimaticTest@test.com"
    }
  ]
}
```


# Create New Property Manager

This API call will allow the PMS to pass all data to BookingPal that is required for registering a new PM (Property Manager). All fields are mandatory - PMS must pass this data in order for a PM account to be created. You need to use PMS credentials for this request.

```ruby
def create_new_property_manager(body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`CreateNewUpdatePropertyManagerRequest`](../../doc/models/create-new-update-property-manager-request.md) | Body, Required | - |

## Response Type

[`PropertyManagerDetailsResponse`](../../doc/models/property-manager-details-response.md)

## Example Usage

```ruby
body = CreateNewUpdatePropertyManagerRequest.new
body.data = Company.new
body.data.is_company = true
body.data.company_details = CompanyDetails.new
body.data.company_details.account_id = '132'
body.data.company_details.company_name = 'Test PM'
body.data.company_details.language = 'en'
body.data.company_details.full_name = 'Test PM'
body.data.company_details.company_address = CompanyAddress.new
body.data.company_details.company_address.country = 'US'
body.data.company_details.company_address.state = 'Test State'
body.data.company_details.company_address.street_address = 'Test Street'
body.data.company_details.company_address.city = 'Test City'
body.data.company_details.company_address.zip = '13245'
body.data.company_details.website = 'www.testsite.com'
body.data.company_details.email = 'apimaticPMemail@test.com'
body.data.company_details.phone = Phone.new
body.data.company_details.phone.country_code = '321'
body.data.company_details.phone.number = '132456'
body.data.company_details.password = 'password'
body.data.company_details.currency = 'USD'
body.data.policies = Policies.new
body.data.policies.payment_policy = PaymentPolicy.new
body.data.policies.payment_policy.type = PaymentPolicyTypeEnum::SPLIT
body.data.policies.payment_policy.split_payment = SplitPayment.new
body.data.policies.payment_policy.split_payment.deposit_type = DepositTypeEnum::FLAT
body.data.policies.payment_policy.split_payment.value = 98.84
body.data.policies.payment_policy.split_payment.second_payment_days = 30
body.data.policies.cancellation_policy = CancellationPolicy.new
body.data.policies.cancellation_policy.type = CancellationPolicyTypeEnum::MANUAL
body.data.policies.cancellation_policy.manual_policy = ManualPolicy.new
body.data.policies.cancellation_policy.manual_policy.type = ManualPolicyTypeEnum::FLAT
body.data.policies.cancellation_policy.manual_policy.manual_policies = []


body.data.policies.cancellation_policy.manual_policy.manual_policies[0] = ManualPolicies.new
body.data.policies.cancellation_policy.manual_policy.manual_policies[0].charge_value = 20
body.data.policies.cancellation_policy.manual_policy.manual_policies[0].before_days = 34
body.data.policies.cancellation_policy.manual_policy.manual_policies[0].cancellation_fee = 80.47

body.data.policies.cancellation_policy.manual_policy.manual_policies[1] = ManualPolicies.new
body.data.policies.cancellation_policy.manual_policy.manual_policies[1].charge_value = 12
body.data.policies.cancellation_policy.manual_policy.manual_policies[1].before_days = 45
body.data.policies.cancellation_policy.manual_policy.manual_policies[1].cancellation_fee = 80.48

body.data.policies.fee_tax_mandatory = FeeTaxMandatory.new
body.data.policies.fee_tax_mandatory.is_fee_mandatory = true
body.data.policies.fee_tax_mandatory.is_tax_mandatory = true
body.data.policies.terms = 'www.test.com'
body.data.policies.check_in_time = '36000'
body.data.policies.check_out_time = '57600'
body.data.policies.lead_time = 2
body.data.payment = Payment.new
body.data.payment.payment_type = PaymentTypeEnum::MAIL_CHECK
body.data.payment.credit_card = CreditCard.new
body.data.payment.credit_card.credit_card_type = CreditCardTypeEnum::POST
body.data.payment.credit_card.payment_gateways = PaymentGateways.new
body.data.payment.credit_card.payment_gateways.payment_gateways_type = PaymentGatewaysTypeEnum::AUTHORIZE_NET
body.data.payment.credit_card.payment_gateways.user = 'test'
body.data.payment.credit_card.payment_gateways.secret = 'test'
body.data.payment.credit_card.payment_gateways.additional_field1 = ''
body.data.payment.credit_card.payment_gateways.additional_field2 = ''
body.data.payment.credit_card.credit_card_list = [CreditCardListEnum::AMERICAN_EXPRESS, CreditCardListEnum::DINERS_CLUB]
body.data.owner_info = Text.new
body.data.owner_info.language = 'EN'
body.data.owner_info.value = 'ownerInfo on EN'
body.data.neighborhood_overview = Text.new
body.data.neighborhood_overview.language = 'EN'
body.data.neighborhood_overview.value = 'neighborhoodOverview on EN'

result = property_managers_controller.create_new_property_manager(body)
```

## Example Response *(as JSON)*

```json
{
  "message": "",
  "errorMessage": [],
  "is_error": false,
  "code": "",
  "data": [
    {
      "companyDetails": {
        "accountId": "132",
        "companyName": "Test PM",
        "language": "en",
        "fullName": "Test PM",
        "companyAddress": {
          "country": "US",
          "state": "Test State",
          "streetAddress": "Test Street",
          "city": "Test City",
          "zip": "13245"
        },
        "website": "www.testsite.com",
        "email": "apimaticPMemail@test.com",
        "phone": {
          "countryCode": "321",
          "number": "132456"
        },
        "password": "password",
        "currency": "USD"
      },
      "policies": {
        "paymentPolicy": {
          "type": "SPLIT",
          "splitPayment": {
            "depositType": "FLAT",
            "value": 4,
            "secondPaymentDays": 30
          }
        },
        "cancellationPolicy": {
          "type": "MANUAL",
          "manualPolicy": {
            "type": "FLAT",
            "manualPolicies": [
              {
                "chargeValue": 20,
                "beforeDays": 34,
                "cancellationFee": 1
              },
              {
                "chargeValue": 12,
                "beforeDays": 45,
                "cancellationFee": 2
              }
            ]
          }
        },
        "feeTaxMandatory": {
          "isFeeMandatory": true,
          "isTaxMandatory": true
        },
        "terms": "www.test.com",
        "checkInTime": "36000",
        "checkOutTime": "57600",
        "leadTime": 2
      },
      "payment": {
        "paymentType": "MAIL_CHECK",
        "creditCard": {
          "creditCardType": "POST",
          "creditCardList": [
            "AMERICAN_EXPRESS",
            "DINERS_CLUB",
            "DISCOVER",
            "MASTER_CARD",
            "VISA"
          ],
          "paymentGateways": {
            "paymentGatewaysType": "AUTHORIZE_NET"
          }
        }
      },
      "id": 61692801,
      "isCompany": true,
      "ownerInfo": {
        "language": "EN",
        "value": "ownerInfo on EN"
      },
      "neighborhoodOverview": {
        "language": "EN",
        "value": "neighborhoodOverview on EN"
      }
    }
  ]
}
```


# Get Property Manager Detail Data

This function will return a property manager’s details that belong to the current user. You need to use your PMS API credentials.

Request Body parameters are the same as for creating PM.

Response is the same as in creating a Property Manager function. Here you do not need to pass all root level fields, but if some are used - all fields inside are mandatory:

- in CompanyDetails Model you can pass any field, and none of them is mandatory
- in Policies Model - you can pass any field,  and none of them is mandatory
- if you do use PaymentPolicy - all fields inside are mandatory
- if you do use CancellationPolicy - all fields inside are mandatory
- if you use Payment Model - all fields inside are mandatory

```ruby
def get_property_manager_detail_data(content_type,
                                     id)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `content_type` | `String` | Header, Required | - |
| `id` | `String` | Template, Required | Property Manager ID |

## Response Type

[`PropertyManagerDetailsResponse`](../../doc/models/property-manager-details-response.md)

## Example Usage

```ruby
content_type = 'application/json'
id = '61692799'

result = property_managers_controller.get_property_manager_detail_data(content_type, id)
```

## Example Response *(as JSON)*

```json
{
  "message": "",
  "errorMessage": [],
  "is_error": false,
  "code": "",
  "data": [
    {
      "isCompany": false,
      "companyDetails": {
        "accountId": "132",
        "companyName": "Test PM",
        "language": "en",
        "fullName": "Test PM",
        "companyAddress": {
          "country": "US",
          "state": "Test State",
          "streetAddress": "Test Street",
          "city": "Test City",
          "zip": "13245"
        },
        "website": "www.testsite.com",
        "email": "apimaticTest@test.com",
        "phone": {
          "countryCode": "321",
          "number": "132456"
        },
        "currency": "USD"
      },
      "policies": {
        "paymentPolicy": {
          "type": "SPLIT",
          "splitPayment": {
            "depositType": "FLAT",
            "value": 4,
            "secondPaymentDays": 30
          }
        },
        "cancellationPolicy": {
          "type": "MANUAL",
          "manualPolicy": {
            "type": "FLAT",
            "manualPolicies": [
              {
                "chargeValue": 20,
                "beforeDays": 34,
                "cancellationFee": 1
              },
              {
                "chargeValue": 12,
                "beforeDays": 45,
                "cancellationFee": 2
              }
            ]
          }
        },
        "feeTaxMandatory": {
          "isFeeMandatory": true,
          "isTaxMandatory": true
        },
        "terms": "www.test.com",
        "checkInTime": "36000",
        "checkOutTime": "57600",
        "leadTime": 2
      },
      "payment": {
        "paymentType": "MAIL_CHECK",
        "creditCard": {
          "creditCardType": "POST",
          "creditCardList": [
            "AMERICAN_EXPRESS",
            "DINERS_CLUB",
            "DISCOVER",
            "MASTER_CARD",
            "VISA"
          ],
          "paymentGateways": {
            "paymentGatewaysType": "AUTHORIZE_NET"
          }
        }
      },
      "id": 61692799,
      "ownerInfo": {
        "language": "EN",
        "value": "ownerInfo on EN"
      },
      "neighborhoodOverview": {
        "language": "EN",
        "value": "neighborhoodOverview on EN"
      }
    }
  ]
}
```


# Update Property Manager Details

This function will update a property manager’s details. In case of an update you do not need to pass all information, but if you have values in one section - all fields inside are mandatory.

```ruby
def update_property_manager_details(id,
                                    body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `String` | Template, Required | Property Manager ID |
| `body` | [`CreateNewUpdatePropertyManagerRequest`](../../doc/models/create-new-update-property-manager-request.md) | Body, Required | - |

## Response Type

[`PropertyManagerDetailsResponse`](../../doc/models/property-manager-details-response.md)

## Example Usage

```ruby
id = '61692799'
body = CreateNewUpdatePropertyManagerRequest.new
body.data = Company.new
body.data.is_company = true
body.data.company_details = CompanyDetails.new
body.data.company_details.account_id = '132'
body.data.company_details.company_name = 'Update Name'
body.data.company_details.language = 'en'
body.data.company_details.full_name = 'Update Full Name'
body.data.company_details.company_address = CompanyAddress.new
body.data.company_details.company_address.country = 'US'
body.data.company_details.company_address.state = 'Update State'
body.data.company_details.company_address.street_address = 'Update Street'
body.data.company_details.company_address.city = 'Update City'
body.data.company_details.company_address.zip = '13245'
body.data.company_details.website = 'www.updatesite.com'
body.data.company_details.email = 'apimaticTest@test.com'
body.data.company_details.phone = Phone.new
body.data.company_details.phone.country_code = '321'
body.data.company_details.phone.number = '132456'
body.data.company_details.password = 'password'
body.data.company_details.currency = 'USD'
body.data.policies = Policies.new
body.data.policies.payment_policy = PaymentPolicy.new
body.data.policies.payment_policy.type = PaymentPolicyTypeEnum::SPLIT
body.data.policies.payment_policy.split_payment = SplitPayment.new
body.data.policies.payment_policy.split_payment.deposit_type = DepositTypeEnum::FLAT
body.data.policies.payment_policy.split_payment.value = 98.84
body.data.policies.payment_policy.split_payment.second_payment_days = 30
body.data.policies.cancellation_policy = CancellationPolicy.new
body.data.policies.cancellation_policy.type = CancellationPolicyTypeEnum::MANUAL
body.data.policies.cancellation_policy.manual_policy = ManualPolicy.new
body.data.policies.cancellation_policy.manual_policy.type = ManualPolicyTypeEnum::FLAT
body.data.policies.cancellation_policy.manual_policy.manual_policies = []


body.data.policies.cancellation_policy.manual_policy.manual_policies[0] = ManualPolicies.new
body.data.policies.cancellation_policy.manual_policy.manual_policies[0].charge_value = 20
body.data.policies.cancellation_policy.manual_policy.manual_policies[0].before_days = 34
body.data.policies.cancellation_policy.manual_policy.manual_policies[0].cancellation_fee = 80.47

body.data.policies.cancellation_policy.manual_policy.manual_policies[1] = ManualPolicies.new
body.data.policies.cancellation_policy.manual_policy.manual_policies[1].charge_value = 12
body.data.policies.cancellation_policy.manual_policy.manual_policies[1].before_days = 45
body.data.policies.cancellation_policy.manual_policy.manual_policies[1].cancellation_fee = 80.48

body.data.policies.fee_tax_mandatory = FeeTaxMandatory.new
body.data.policies.fee_tax_mandatory.is_fee_mandatory = true
body.data.policies.fee_tax_mandatory.is_tax_mandatory = true
body.data.policies.terms = 'www.test.com'
body.data.policies.check_in_time = '36000'
body.data.policies.check_out_time = '57600'
body.data.policies.lead_time = 2
body.data.payment = Payment.new
body.data.payment.payment_type = PaymentTypeEnum::MAIL_CHECK
body.data.payment.credit_card = CreditCard.new
body.data.payment.credit_card.credit_card_type = CreditCardTypeEnum::POST
body.data.payment.credit_card.payment_gateways = PaymentGateways.new
body.data.payment.credit_card.payment_gateways.payment_gateways_type = PaymentGatewaysTypeEnum::AUTHORIZE_NET
body.data.payment.credit_card.payment_gateways.user = 'test'
body.data.payment.credit_card.payment_gateways.secret = 'test'
body.data.payment.credit_card.payment_gateways.additional_field1 = ''
body.data.payment.credit_card.payment_gateways.additional_field2 = ''
body.data.payment.credit_card.credit_card_list = [CreditCardListEnum::AMERICAN_EXPRESS, CreditCardListEnum::DINERS_CLUB]
body.data.owner_info = Text.new
body.data.owner_info.language = 'EN'
body.data.owner_info.value = 'ownerInfo on EN'
body.data.neighborhood_overview = Text.new
body.data.neighborhood_overview.language = 'EN'
body.data.neighborhood_overview.value = 'neighborhoodOverview on EN'

result = property_managers_controller.update_property_manager_details(id, body)
```

## Example Response *(as JSON)*

```json
{
  "message": "",
  "errorMessage": [],
  "is_error": false,
  "code": "",
  "data": [
    {
      "companyDetails": {
        "accountId": "132",
        "companyName": "Update Name",
        "language": "en",
        "fullName": "Update Full Name",
        "companyAddress": {
          "country": "US",
          "state": "Update State",
          "streetAddress": "Update Street",
          "city": "Update City",
          "zip": "13245"
        },
        "website": "www.updatesite.com",
        "email": "apimaticTest@test.com",
        "phone": {
          "countryCode": "321",
          "number": "132456"
        },
        "currency": "USD"
      },
      "policies": {
        "paymentPolicy": {
          "type": "SPLIT",
          "splitPayment": {
            "depositType": "FLAT",
            "value": 4,
            "secondPaymentDays": 30
          }
        },
        "cancellationPolicy": {
          "type": "MANUAL",
          "manualPolicy": {
            "type": "FLAT",
            "manualPolicies": [
              {
                "chargeValue": 20,
                "beforeDays": 34,
                "cancellationFee": 1
              },
              {
                "chargeValue": 12,
                "beforeDays": 45,
                "cancellationFee": 2
              }
            ]
          }
        },
        "feeTaxMandatory": {
          "isFeeMandatory": true,
          "isTaxMandatory": true
        },
        "terms": "www.test.com",
        "checkInTime": "36000",
        "checkOutTime": "57600",
        "leadTime": 2
      },
      "payment": {
        "paymentType": "MAIL_CHECK",
        "creditCard": {
          "creditCardType": "POST",
          "creditCardList": [
            "AMERICAN_EXPRESS",
            "DINERS_CLUB",
            "DISCOVER",
            "MASTER_CARD",
            "VISA"
          ],
          "paymentGateways": {
            "paymentGatewaysType": "AUTHORIZE_NET"
          }
        }
      },
      "id": 61692799,
      "isCompany": true,
      "ownerInfo": {
        "language": "EN",
        "value": "ownerInfo on EN"
      },
      "neighborhoodOverview": {
        "language": "EN",
        "value": "neighborhoodOverview on EN"
      }
    }
  ]
}
```

