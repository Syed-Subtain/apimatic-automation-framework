# Validation

```ruby
validation_controller = client.validation
```

## Class Name

`ValidationController`

## Methods

* [Booking Pal Validation Job-List of Properties](../../doc/controllers/validation.md#booking-pal-validation-job-list-of-properties)
* [Booking Pal Validation Job-Full PM](../../doc/controllers/validation.md#booking-pal-validation-job-full-pm)


# Booking Pal Validation Job-List of Properties

This function will allow the PMS to call the BookingPal property validation job for a list of properties from request. These properties must belong to the current user and authorization token should be on PM level.
Also, we will run validation only for properties that are activated. If you deactivate property - we will not validate this property.

```ruby
def booking_pal_validation_job_list_of_properties(body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`ValidationForListOfPropertiesRequest`](../../doc/models/validation-for-list-of-properties-request.md) | Body, Required | - |

## Response Type

[`APIResponseWithoutData`](../../doc/models/api-response-without-data.md)

## Example Usage

```ruby
body = ValidationForListOfPropertiesRequest.new
body.data = ValidationOfPropertyIDsList.new
body.data.product_ids = [1235124634, 1235124636]

result = validation_controller.booking_pal_validation_job_list_of_properties(body)
```

## Example Response *(as JSON)*

```json
{
  "message": "Your request was received and put in queue",
  "errorMessage": [],
  "is_error": false,
  "code": ""
}
```


# Booking Pal Validation Job-Full PM

This function will allow the PMC to call the BookingPal property validation job for all properties identified which belong to the current user. Authorization token should be on PM level.
Also we will run validation only for properties which are activated. If you deactivate property - we will not validate this property.

After the request you will get a response indicating if messages were processed or not. If the request is good your request for the validator job will be put into a queue. Once the request is processed, BookingPal will send an async push message per property informing the user if a property is valid or not, and if it is not valid - with reasons why the validation failed. This message will be sent on the endpoint which was entered in section Push Notifications, field asyncPush.

Note: If the property is distributed already on some channel - this property will not be moved to an Incomplete state. Also if you have property on Incomplete state because of some reason, and you update this data which causes that property is on ‘Incomplete’ property will not be moved automatically to a valid state. Instead, you should run a Validation job manually for that property or wait for our automatic validation job which we are running once per day.

To make the property ready for Onboarding you should run validation first. if the property is valid - it will be ready for onboarding. Otherwise - the property will be in Incomplete state. Also, we will run validation only for properties that are activated. If you deactivate property - we will not validate this property.

```ruby
def booking_pal_validation_job_full_pm
```

## Response Type

[`APIResponseWithoutData`](../../doc/models/api-response-without-data.md)

## Example Usage

```ruby
result = validation_controller.booking_pal_validation_job_full_pm()
```

## Example Response *(as JSON)*

```json
{
  "message": "Your request was received and put in queue",
  "errorMessage": [],
  "is_error": false,
  "code": ""
}
```

