# Images

Every API call in this section should be with PM credentials.

This is a list of functions to work with property images. Important note is that upload or delete images will be done over an automatic cron job. So it will be done some time after your call, depending on the number of requests which are waiting before your request.
Important note: Please make sure to put full URL to image, and to not use some links which will forward our system to another link since images might not be imported.

```ruby
images_controller = client.images
```

## Class Name

`ImagesController`

## Methods

* [Get Image List by Product ID](../../doc/controllers/images.md#get-image-list-by-product-id)
* [Fullupdateimages](../../doc/controllers/images.md#fullupdateimages)
* [Addimage](../../doc/controllers/images.md#addimage)
* [Delete List of Images](../../doc/controllers/images.md#delete-list-of-images)
* [Delete All Images Per Property](../../doc/controllers/images.md#delete-all-images-per-property)


# Get Image List by Product ID

This function allows logged in user to get image list for the existing product

```ruby
def get_image_list_by_product_id(product_id)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `product_id` | `String` | Template, Required | ID of the property |

## Response Type

[`GetImageListByProductID`](../../doc/models/get-image-list-by-product-id.md)

## Example Usage

```ruby
product_id = '1235124634'

result = images_controller.get_image_list_by_product_id(product_id)
```

## Example Response *(as JSON)*

```json
{
  "message": "",
  "errorMessage": [],
  "is_error": false,
  "code": "",
  "data": [
    {
      "productId": 1235124634,
      "images": [
        {
          "url": "http://aff.bstatic.com/images/hotel/max500/110/11069098.jpg",
          "tags": [
            4,
            5,
            6
          ],
          "urlMbp": "https://s3.amazonaws.com/mybookingpal/pictures/n2ujn/n2ujn/1235124634/11069098.jpg",
          "sort": 1
        },
        {
          "url": "http://aff.bstatic.com/images/hotel/max500/110/11069099.jpg",
          "tags": [
            4,
            5,
            6
          ],
          "urlMbp": "https://s3.amazonaws.com/mybookingpal/pictures/n2ujn/n2ujn/1235124634/11069099.jpg",
          "sort": 2
        },
        {
          "url": "http://aff.bstatic.com/images/hotel/max500/110/11069100.jpg",
          "tags": [
            4,
            5,
            6
          ],
          "urlMbp": "https://s3.amazonaws.com/mybookingpal/pictures/n2ujn/n2ujn/1235124634/11069100.jpg",
          "sort": 3
        },
        {
          "url": "http://aff.bstatic.com/images/hotel/max500/110/11069101.jpg",
          "tags": [
            4,
            5,
            6
          ],
          "urlMbp": "https://s3.amazonaws.com/mybookingpal/pictures/n2ujn/n2ujn/1235124634/11069101.jpg",
          "sort": 4
        },
        {
          "url": "http://aff.bstatic.com/images/hotel/max500/110/11069102.jpg",
          "tags": [
            4,
            5,
            6
          ],
          "urlMbp": "https://s3.amazonaws.com/mybookingpal/pictures/n2ujn/n2ujn/1235124634/11069102.jpg",
          "sort": 5
        },
        {
          "url": "http://aff.bstatic.com/images/hotel/max500/110/11069103.jpg",
          "tags": [
            4,
            5,
            6
          ],
          "urlMbp": "https://s3.amazonaws.com/mybookingpal/pictures/n2ujn/n2ujn/1235124634/11069103.jpg",
          "sort": 6
        },
        {
          "url": "http://aff.bstatic.com/images/hotel/max500/110/11069104.jpg",
          "tags": [
            4,
            5,
            6
          ],
          "urlMbp": "https://s3.amazonaws.com/mybookingpal/pictures/n2ujn/n2ujn/1235124634/11069104.jpg",
          "sort": 7
        },
        {
          "url": "http://aff.bstatic.com/images/hotel/max500/110/11069105.jpg",
          "tags": [
            4,
            5,
            6
          ],
          "urlMbp": "https://s3.amazonaws.com/mybookingpal/pictures/n2ujn/n2ujn/1235124634/11069105.jpg",
          "sort": 8
        },
        {
          "url": "http://aff.bstatic.com/images/hotel/max500/110/11069106.jpg",
          "tags": [
            4,
            5,
            6
          ],
          "urlMbp": "https://s3.amazonaws.com/mybookingpal/pictures/n2ujn/n2ujn/1235124634/11069106.jpg",
          "sort": 9
        },
        {
          "url": "http://aff.bstatic.com/images/hotel/max500/110/11069107.jpg",
          "tags": [
            4,
            5,
            6
          ],
          "urlMbp": "https://s3.amazonaws.com/mybookingpal/pictures/n2ujn/n2ujn/1235124634/11069107.jpg",
          "sort": 10
        },
        {
          "url": "http://aff.bstatic.com/images/hotel/max500/110/11069108.jpg",
          "tags": [
            4,
            5,
            6
          ],
          "urlMbp": "https://s3.amazonaws.com/mybookingpal/pictures/n2ujn/n2ujn/1235124634/11069108.jpg",
          "sort": 11
        },
        {
          "url": "http://aff.bstatic.com/images/hotel/max500/110/11069109.jpg",
          "tags": [
            4,
            5,
            6
          ],
          "urlMbp": "https://s3.amazonaws.com/mybookingpal/pictures/n2ujn/n2ujn/1235124634/11069109.jpg",
          "sort": 12
        }
      ]
    }
  ]
}
```


# Fullupdateimages

This function allows the logged user to upload images for the existing product. Images will be sorted in order how they are sent in the request. The first image sent in request will be used as the “Main Image”. (Image re-ordering can also be done within the BookingPal platform manually by users). Images that were in the system, and that aren’t in the request, will be deleted. So the function will do a full update of images.

```ruby
def fullupdateimages(body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`FullupdateImagesRequest`](../../doc/models/fullupdate-images-request.md) | Body, Required | - |

## Response Type

[`APIResponseWithoutData`](../../doc/models/api-response-without-data.md)

## Example Usage

```ruby
body = FullupdateImagesRequest.new
body.data = ImagesURLForFullUpdate.new
body.data.product_id = 1234893572
body.data.images = []


body.data.images[0] = AddImage.new
body.data.images[0].url = 'http://aff.bstatic.com/images/hotel/max500/110/11069097.jpg'
body.data.images[0].tags = [ImageTagsEnum::ENUM_1, ImageTagsEnum::ENUM_2, ImageTagsEnum::ENUM_3]

body.data.images[1] = AddImage.new
body.data.images[1].url = 'http://aff.bstatic.com/images/hotel/max500/110/11069097.jpg'
body.data.images[1].tags = [ImageTagsEnum::ENUM_1, ImageTagsEnum::ENUM_2, ImageTagsEnum::ENUM_3]


result = images_controller.fullupdateimages(body)
```

## Example Response *(as JSON)*

```json
{
  "message": "Your request was received and put in queue",
  "errorMessage": [],
  "is_error": false,
  "code": ""
}
```


# Addimage

This function allows the logged in user to upload 1 image for the existing product. Every new image will be sorted to the end. The first image sent will be used as the “Main Image”. (Image re-ordering can also be done within the BookingPal platform manually by users)

```ruby
def addimage(body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`AddImageRequest`](../../doc/models/add-image-request.md) | Body, Required | - |

## Response Type

[`APIResponseWithoutData`](../../doc/models/api-response-without-data.md)

## Example Usage

```ruby
body = AddImageRequest.new
body.data = ImageURLForAdd.new
body.data.product_id = 1234879670
body.data.image = AddImage.new
body.data.image.url = 'http://www.pm-name.com/prop_img/1_2345_5_19.jpg'
body.data.image.tags = [ImageTagsEnum::ENUM_1, ImageTagsEnum::ENUM_2, ImageTagsEnum::ENUM_3]

result = images_controller.addimage(body)
```

## Example Response *(as JSON)*

```json
{
  "message": "Your request was received and put in queue",
  "errorMessage": [],
  "is_error": false,
  "code": ""
}
```


# Delete List of Images

This function allows the logged in user to delete image(s) from the existing product.

```ruby
def delete_list_of_images
```

## Response Type

[`APIResponseWithoutData`](../../doc/models/api-response-without-data.md)

## Example Usage

```ruby
result = images_controller.delete_list_of_images()
```

## Example Response *(as JSON)*

```json
{
  "message": "Images are sent for processing!",
  "errorMessage": [],
  "is_error": false,
  "code": ""
}
```


# Delete All Images Per Property

This function allows logged in user to delete images.

```ruby
def delete_all_images_per_property(content_type,
                                   product_id)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `content_type` | `String` | Header, Required | - |
| `product_id` | `String` | Template, Required | ID of property for which you want to delete all images |

## Response Type

[`APIResponseWithoutData`](../../doc/models/api-response-without-data.md)

## Example Usage

```ruby
content_type = 'application/json'
product_id = '1235124634'

result = images_controller.delete_all_images_per_property(content_type, product_id)
```

## Example Response *(as JSON)*

```json
{
  "message": "Your request was received and put in queue",
  "errorMessage": [],
  "is_error": false,
  "code": ""
}
```

