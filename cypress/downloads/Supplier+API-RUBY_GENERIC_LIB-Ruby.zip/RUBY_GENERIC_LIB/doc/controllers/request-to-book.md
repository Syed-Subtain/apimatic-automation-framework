# Request to Book

```ruby
request_to_book_controller = client.request_to_book
```

## Class Name

`RequestToBookController`

## Methods

* [Request to Book-Request](../../doc/controllers/request-to-book.md#request-to-book-request)
* [Request to Book-Answer From PMS](../../doc/controllers/request-to-book.md#request-to-book-answer-from-pms)
* [Request to Book-Test](../../doc/controllers/request-to-book.md#request-to-book-test)


# Request to Book-Request

This will be a request which we will send to PMS when we get a request to book from the channel.
So when BookingPal gets a new request to book request - we will push this POST request to the link which you set in BookingPal for your PMS (in Push Notification section if you set link "reservationLink" - notification will be sent on this link. Otherwise it will be set on link "requestToBook").

Important note: In this doc to be able to test this - you need to set a full URL on the Configure button in the right section.

:information_source: **Note** This endpoint does not require authentication.

```ruby
def request_to_book_request(body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`RequestToBookRequestModel`](../../doc/models/request-to-book-request-model.md) | Body, Required | - |

## Response Type

[`ReservationPushResponse`](../../doc/models/reservation-push-response.md)

## Example Usage

```ruby
body = RequestToBookRequestModel.new
body.rezcaster_notification_request = ReservationNotificationObject.new
body.rezcaster_notification_request.reservation_id = '107'
body.rezcaster_notification_request.product_id = '1234816374'
body.rezcaster_notification_request.supplier_id = '3731837'
body.rezcaster_notification_request.channel_name = 'Airbnb'
body.rezcaster_notification_request.confirmation_id = 'dasdasd'
body.rezcaster_notification_request.unique_key = 'uniqueKey4'
body.rezcaster_notification_request.new_state = ReservationStateEnum::CANCELLED
body.rezcaster_notification_request.customer_name = 'John Smith'
body.rezcaster_notification_request.from_date = Date.iso8601('2016-03-13')
body.rezcaster_notification_request.to_date = Date.iso8601('2016-03-13')
body.rezcaster_notification_request.adult = 2
body.rezcaster_notification_request.child = 0
body.rezcaster_notification_request.email = 'andrewtesttest222@gmail.com'
body.rezcaster_notification_request.total = 23.76
body.rezcaster_notification_request.fees = []


body.rezcaster_notification_request.fees[0] = ReservationFeeNotificationModel.new
body.rezcaster_notification_request.fees[0].id = '937-4'
body.rezcaster_notification_request.fees[0].name = 'Cleaning Fee'
body.rezcaster_notification_request.fees[0].value = 144.53

body.rezcaster_notification_request.fees[1] = ReservationFeeNotificationModel.new
body.rezcaster_notification_request.fees[1].id = '937-4'
body.rezcaster_notification_request.fees[1].name = 'Cleaning Fee'
body.rezcaster_notification_request.fees[1].value = 144.54

body.rezcaster_notification_request.taxes = []


body.rezcaster_notification_request.taxes[0] = ReservationTaxNotificationModel.new
body.rezcaster_notification_request.taxes[0].id = '22'
body.rezcaster_notification_request.taxes[0].name = 'State of Florida-Lake County State Tax'
body.rezcaster_notification_request.taxes[0].value = 134.53

body.rezcaster_notification_request.taxes[1] = ReservationTaxNotificationModel.new
body.rezcaster_notification_request.taxes[1].id = '22'
body.rezcaster_notification_request.taxes[1].name = 'State of Florida-Lake County State Tax'
body.rezcaster_notification_request.taxes[1].value = 134.54

body.rezcaster_notification_request.commission = ReservationCommissionsNotificationModel.new
body.rezcaster_notification_request.commission.channel_commission = 69.7
body.rezcaster_notification_request.commission.commission = 0.14
body.rezcaster_notification_request.rate = ReservationRateNotifcationModel.new
body.rezcaster_notification_request.rate.original_rack_rate = 16.12
body.rezcaster_notification_request.rate.net_rate = 47
body.rezcaster_notification_request.rate.new_published_rack_rate = 87.72
body.action = 'RESERVATION_REQUEST'
body.reservation_id = 252
body.expires_at = Date.iso8601('2016-03-13')

result = request_to_book_controller.request_to_book_request(body)
```

## Example Response *(as JSON)*

```json
{
  "altId": "45717",
  "is_error": false,
  "code": "",
  "message": "Request to book is accepted."
}
```


# Request to Book-Answer From PMS

This is an API call that you should use for accepting on avoiding requests to book.

```ruby
def request_to_book_answer_from_pms(body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`RequestToBookAnswerFromPMSRequest`](../../doc/models/request-to-book-answer-from-pms-request.md) | Body, Required | - |

## Response Type

[`APIResponseWithoutData`](../../doc/models/api-response-without-data.md)

## Example Usage

```ruby
body = RequestToBookAnswerFromPMSRequest.new
body.data = FunctionsRequestToBook.new
body.data.request_to_book_type = RequestToBookTypeEnum::DENY
body.data.request_to_book_decline_reason_type = RequestToBookDeclineReasonTypeEnum::DATES_NOT_AVAILABLE
body.data.decline_message_to_guest = 'these dates are not available any more. '
body.data.reservation_id = 1235124634

result = request_to_book_controller.request_to_book_answer_from_pms(body)
```

## Example Response *(as JSON)*

```json
{
  "message": "Request to book answer accepted",
  "errorMessage": [],
  "is_error": false,
  "code": ""
}
```


# Request to Book-Test

Since you can not get the request to book on our test environment (since this first needs to be created on the channel) We provide the possibility for PMS to test this request with some random filled data in our system. So when you call this API function - we will send you push notification for the request to book for a provided property ID.

```ruby
def request_to_book_test(body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`RequestToBookTestRequest`](../../doc/models/request-to-book-test-request.md) | Body, Required | - |

## Response Type

[`APIResponseWithoutData`](../../doc/models/api-response-without-data.md)

## Example Usage

```ruby
body = RequestToBookTestRequest.new
body.data = FunctionsRequestToBookTest.new
body.data.action = RequestToBookTestActionEnum::RESERVATION_REQUEST_VOIDED
body.data.product_id = 1235124634

result = request_to_book_controller.request_to_book_test(body)
```

## Example Response *(as JSON)*

```json
{
  "message": "Request to book test accepted",
  "errorMessage": [],
  "is_error": false,
  "code": "",
  "data": []
}
```

