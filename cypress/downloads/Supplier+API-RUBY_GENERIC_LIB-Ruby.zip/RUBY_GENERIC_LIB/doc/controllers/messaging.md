# Messaging

```ruby
messaging_controller = client.messaging
```

## Class Name

`MessagingController`

## Methods

* [Get Message Threads](../../doc/controllers/messaging.md#get-message-threads)
* [Post New Message for Specific Thread](../../doc/controllers/messaging.md#post-new-message-for-specific-thread)
* [Get Message List for Specific Thread](../../doc/controllers/messaging.md#get-message-list-for-specific-thread)


# Get Message Threads

This function allows the logged in user to get all message threads or message threads with unresponded message from guest for whole PM. You need to use PM credentials. There is also paging as optional values. If you do not pass this value, we will return first page and 10 threads per page. And in heading you will get a link for the next page.

```ruby
def get_message_threads(page,
                        limit,
                        thread_type)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `page` | `Integer` | Query, Required | Number of current page |
| `limit` | `Integer` | Query, Required | Limit of how many threads will be showed at one page |
| `thread_type` | `String` | Template, Required | Request all threads or only threads with  unanswered message {new,all} |

## Response Type

[`GetMessageThreadsResponse`](../../doc/models/get-message-threads-response.md)

## Example Usage

```ruby
page = 1
limit = 5
thread_type = 'all'

result = messaging_controller.get_message_threads(page, limit, thread_type)
```


# Post New Message for Specific Thread

This function will allow PM to post new messages in already existing threads.

```ruby
def post_new_message_for_specific_thread(body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`PostNewMessageForSpecificThreadRequest`](../../doc/models/post-new-message-for-specific-thread-request.md) | Body, Required | - |

## Response Type

[`APIResponseWithoutData`](../../doc/models/api-response-without-data.md)

## Example Usage

```ruby
body = PostNewMessageForSpecificThreadRequest.new
body.data = MessageRequestFromSupplier.new
body.data.thread_id = 5656
body.data.message = 'New message'

result = messaging_controller.post_new_message_for_specific_thread(body)
```

## Example Response *(as JSON)*

```json
{
  "message": "Your request was received and put in queue",
  "errorMessage": [],
  "is_error": false,
  "code": ""
}
```


# Get Message List for Specific Thread

This function allows the logged in user to get a list of all messages from passed thread Id. You need to use PM credentials.

```ruby
def get_message_list_for_specific_thread(thread_id)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `thread_id` | `String` | Template, Required | ID of the thread |

## Response Type

[`GetMessageListForSpecificThreadResponse`](../../doc/models/get-message-list-for-specific-thread-response.md)

## Example Usage

```ruby
thread_id = '123'

result = messaging_controller.get_message_list_for_specific_thread(thread_id)
```

## Example Response *(as JSON)*

```json
{
  "message": "",
  "errorMessage": [],
  "code": "",
  "data": [
    {
      "messages": [
        {
          "id": 68233,
          "message": "Message pmuNXJFzWQ",
          "createdAt": "2019-12-03T12:31:47.000+0000",
          "user": "GUEST",
          "channelMessageId": "2221139318748986368"
        },
        {
          "id": 68234,
          "message": "i would like to know soon so i can know whether to get another bnb or hotel",
          "createdAt": "2019-10-21T16:49:30.000+0000",
          "user": "GUEST",
          "channelMessageId": "2221139318748986369"
        },
        {
          "id": 68235,
          "message": "??",
          "createdAt": "2019-10-21T16:49:31.000+0000",
          "user": "GUEST",
          "channelMessageId": "2221139318748986370"
        },
        {
          "id": 68236,
          "message": "Hello, How does the chalet work? Will we be staying with other people? I see there are 5 apartments. So someone will be living above us below us? Thank you. ",
          "createdAt": "2019-10-21T16:49:31.000+0000",
          "user": "GUEST",
          "channelMessageId": "2221139318748986371"
        }
      ]
    }
  ],
  "is_error": false
}
```

