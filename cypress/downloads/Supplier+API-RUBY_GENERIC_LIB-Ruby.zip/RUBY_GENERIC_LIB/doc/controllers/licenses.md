# Licenses

```ruby
licenses_controller = client.licenses
```

## Class Name

`LicensesController`

## Methods

* [Put License Req](../../doc/controllers/licenses.md#put-license-req)
* [Get License Req](../../doc/controllers/licenses.md#get-license-req)
* [Bdc License Requirements](../../doc/controllers/licenses.md#bdc-license-requirements)


# Put License Req

This function allows system to send license information for a property, so channel can use it.

```ruby
def put_license_req(product_id,
                    body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `product_id` | `String` | Template, Required | Product ID |
| `body` | [`LicenseUpdate`](../../doc/models/license-update.md) | Body, Required | - |

## Response Type

[`LicenseUpdateResponse`](../../doc/models/license-update-response.md)

## Example Usage

```ruby
product_id = '61692799'
body = LicenseUpdate.new
body.data = []


body.data[0] = LicenseData.new
body.data[0].content_data = []


body.data[0].content_data[0] = LicenseDataContent.new

body.data[0].variant_id = 'variantId1'

body.data[1] = LicenseData.new
body.data[1].content_data = []


body.data[1].content_data[0] = LicenseDataContent.new

body.data[1].content_data[1] = LicenseDataContent.new

body.data[1].variant_id = 'variantId2'

body.data[2] = LicenseData.new
body.data[2].content_data = []


body.data[2].content_data[0] = LicenseDataContent.new

body.data[2].content_data[1] = LicenseDataContent.new

body.data[2].content_data[2] = LicenseDataContent.new

body.data[2].variant_id = 'variantId3'


result = licenses_controller.put_license_req(product_id, body)
```


# Get License Req

This function allows system to get licenses information for a property.

```ruby
def get_license_req(product_id)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `product_id` | `String` | Template, Required | Product ID |

## Response Type

[`LicenseGetResponse`](../../doc/models/license-get-response.md)

## Example Usage

```ruby
product_id = '61692799'

result = licenses_controller.get_license_req(product_id)
```


# Bdc License Requirements

This function will get the BDC License Requirements

```ruby
def bdc_license_requirements(product_id)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `product_id` | `String` | Template, Required | Product ID |

## Response Type

[`LicenseRequirementResponse`](../../doc/models/license-requirement-response.md)

## Example Usage

```ruby
product_id = '61692799'

result = licenses_controller.bdc_license_requirements(product_id)
```

