
# Get Message Threads Response

## Structure

`GetMessageThreadsResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `message` | `String` | Required | Text info message |
| `error_message` | `Array<String>` | Required | Text info message |
| `is_error` | `Boolean` | Required | Is error (default = false) |
| `code` | `String` | Required | Code of message |
| `data` | [`Array<ThreadsModel>`](../../doc/models/threads-model.md) | Required | List of Models |

## Example (as JSON)

```json
{
  "message": "",
  "errorMessage": [],
  "is_error": false,
  "code": "",
  "data": [
    {
      "threads": []
    }
  ]
}
```

