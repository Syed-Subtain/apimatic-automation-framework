
# Phone

## Structure

`Phone`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `country_code` | `String` | Required | Country code prefix in phone number. For example “+1”. |
| `number` | `String` | Required | Phone number |

## Example (as JSON)

```json
{
  "countryCode": "321",
  "number": "132456"
}
```

