
# Check In

## Structure

`CheckIn`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `monday` | `Boolean` | Required | Determines if check in could be made on monday |
| `tuesday` | `Boolean` | Required | Determines if check in could be made on tuesday |
| `wednesday` | `Boolean` | Required | Determines if check in could be made on wednesday |
| `thursday` | `Boolean` | Required | Determines if check in could be made on thursday |
| `friday` | `Boolean` | Required | Determines if check in could be made on friday |
| `saturday` | `Boolean` | Required | Determines if check in could be made on saturday |
| `sunday` | `Boolean` | Required | Determines if check in could be made on sunday |

## Example (as JSON)

```json
{
  "monday": false,
  "tuesday": false,
  "wednesday": false,
  "thursday": false,
  "friday": false,
  "saturday": true,
  "sunday": true
}
```

