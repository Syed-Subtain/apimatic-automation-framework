
# License Variants

## Structure

`LicenseVariants`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `String` | Optional | ID of the variant |
| `name` | `String` | Optional | name of the variant |
| `content` | [`Array<LicenseVariantsContent>`](../../doc/models/license-variants-content.md) | Optional | - |

## Example (as JSON)

```json
{
  "id": null,
  "name": null,
  "content": null
}
```

