
# Fee Tax Mandatory Setting

## Structure

`FeeTaxMandatorySetting`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `product_id` | `Integer` | Required | Product id |
| `is_fee_mandatory` | `Boolean` | Required | Fee is mandatory |
| `is_tax_mandatory` | `Boolean` | Required | Tax is mandatory |

## Example (as JSON)

```json
{
  "productId": 1235124634,
  "isFeeMandatory": false,
  "isTaxMandatory": false
}
```

