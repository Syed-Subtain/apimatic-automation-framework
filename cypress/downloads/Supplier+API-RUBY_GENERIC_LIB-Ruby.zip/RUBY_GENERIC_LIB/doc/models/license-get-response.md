
# License Get Response

## Structure

`LicenseGetResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `message` | `String` | Optional | text info message |
| `error_message` | `Array<String>` | Optional | List of error messages |
| `is_error` | `Boolean` | Optional | Is error (default = false) |
| `code` | `String` | Optional | Code of message |
| `data` | [`Array<LicenseGetResponseData>`](../../doc/models/license-get-response-data.md) | Optional | License Information Data |

## Example (as JSON)

```json
{
  "message": null,
  "errorMessage": null,
  "is_error": null,
  "code": null,
  "data": null
}
```

