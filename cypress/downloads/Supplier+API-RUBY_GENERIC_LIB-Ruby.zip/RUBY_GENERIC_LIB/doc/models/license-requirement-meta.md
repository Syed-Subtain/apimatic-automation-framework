
# License Requirement Meta

## Structure

`LicenseRequirementMeta`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ruid` | `String` | Optional | requirement unique id meta data |

## Example (as JSON)

```json
{
  "ruid": null
}
```

