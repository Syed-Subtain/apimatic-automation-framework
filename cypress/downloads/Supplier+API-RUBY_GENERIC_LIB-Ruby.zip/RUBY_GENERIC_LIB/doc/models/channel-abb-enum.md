
# Channel ABB Enum

## Enumeration

`ChannelABBEnum`

## Fields

| Name |
|  --- |
| `BKG` |
| `ABB` |
| `EXP` |
| `EXP_HC` |
| `HAC` |

## Example

```
BKG
```

