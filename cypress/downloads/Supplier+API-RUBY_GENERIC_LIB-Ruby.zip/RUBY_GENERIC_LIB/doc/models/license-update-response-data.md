
# License Update Response Data

## Structure

`LicenseUpdateResponseData`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `product_id` | `String` | Optional | product ID |
| `response` | [`Array<LicenseUpdateResponseDataDetail>`](../../doc/models/license-update-response-data-detail.md) | Optional | - |

## Example (as JSON)

```json
{
  "productId": null,
  "response": null
}
```

