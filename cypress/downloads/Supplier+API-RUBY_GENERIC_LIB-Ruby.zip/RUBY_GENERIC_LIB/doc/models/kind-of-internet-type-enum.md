
# Kind of Internet Type Enum

## Enumeration

`KindOfInternetTypeEnum`

## Fields

| Name |
|  --- |
| `WIFI` |
| `WIRED` |

## Example

```
WiFi
```

