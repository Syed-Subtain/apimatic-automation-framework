
# Manual Policies

## Structure

`ManualPolicies`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `charge_value` | `Integer` | Required | Percentage or flat value which will be charged in case of cancellation |
| `before_days` | `Integer` | Required | Days before check-in when cancellation policy will be charged |
| `cancellation_fee` | `Float` | Required | Cancellation transaction fee - additional fee on cancellation |

## Example (as JSON)

```json
{
  "chargeValue": 20,
  "beforeDays": 34,
  "cancellationFee": 1
}
```

