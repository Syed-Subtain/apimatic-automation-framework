
# Native Property Type Enum

Channel native Property Type

## Enumeration

`NativePropertyTypeEnum`

## Fields

| Name |
|  --- |
| `HOMESANDAPARTMENTS` |
| `HOTELS` |

## Example

```
HomesAndApartments
```

