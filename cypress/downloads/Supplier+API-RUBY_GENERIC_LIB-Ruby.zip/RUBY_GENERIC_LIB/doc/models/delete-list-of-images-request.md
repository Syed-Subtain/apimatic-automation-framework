
# Delete List of Images Request

## Structure

`DeleteListOfImagesRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `data` | [`ImageURLList`](../../doc/models/image-url-list.md) | Required | Model with list of URLs for one property |

## Example (as JSON)

```json
{
  "data": {
    "productId": 1235124634,
    "images": [
      {
        "url": "https://aff.bstatic.com/images/hotel/max500/110/11069102.jpg"
      }
    ]
  }
}
```

