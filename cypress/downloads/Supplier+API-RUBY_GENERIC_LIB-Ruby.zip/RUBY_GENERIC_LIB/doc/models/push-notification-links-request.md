
# Push Notification Links Request

## Structure

`PushNotificationLinksRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `data` | [`PushNotificationLinksModel`](../../doc/models/push-notification-links-model.md) | Required | Model for push notification links |

## Example (as JSON)

```json
{
  "data": {
    "bookLink": "https://newreservationnotification.link",
    "cancelLink": "https://cancelreservation.link",
    "asyncPush": "https://asyncpush.link",
    "requestToBook": "https://requestToBook.link",
    "useJson": true
  }
}
```

