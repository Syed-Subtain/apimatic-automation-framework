
# Set Fee and Tax Validation Setting Request

This is a request for setting or updating fee and tax validation setting per property

## Structure

`SetFeeAndTaxValidationSettingRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `data` | [`FeeTaxValidationSettings`](../../doc/models/fee-tax-validation-settings.md) | Required | - |

## Example (as JSON)

```json
{
  "data": {
    "validationSettings": [
      {
        "productId": 1235124634,
        "isFeeMandatory": false,
        "isTaxMandatory": false
      }
    ]
  }
}
```

