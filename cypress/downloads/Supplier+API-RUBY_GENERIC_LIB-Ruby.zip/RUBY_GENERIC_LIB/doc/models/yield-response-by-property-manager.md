
# Yield Response by Property Manager

## Structure

`YieldResponseByPropertyManager`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `message` | `String` | Required | text info message |
| `error_message` | `Array<String>` | Required | List of error messages |
| `is_error` | `Boolean` | Required | Is error (default = false) |
| `code` | `String` | Required | Code of message |
| `data` | [`ChannelMarkUpYield`](../../doc/models/channel-mark-up-yield.md) | Required | - |

## Example (as JSON)

```json
{
  "message": "message0",
  "errorMessage": [
    "errorMessage2",
    "errorMessage3",
    "errorMessage4"
  ],
  "is_error": false,
  "code": "code8",
  "data": {
    "channelMarkup": {
      "beginDate": "beginDate6",
      "endDate": "endDate2",
      "amount": 5.22,
      "modifier": "modifier6",
      "channelAbbreviation": "channelAbbreviation4"
    }
  }
}
```

