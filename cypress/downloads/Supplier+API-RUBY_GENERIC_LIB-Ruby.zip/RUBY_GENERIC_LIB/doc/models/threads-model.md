
# Threads Model

## Structure

`ThreadsModel`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `threads` | [`Array<Thread>`](../../doc/models/thread.md) | Required | List of models |

## Example (as JSON)

```json
{
  "threads": {
    "id": null,
    "lastMessageSentAt": null,
    "lastMessageText": null,
    "channelName": null,
    "channelABB": "BKG",
    "guestName": null,
    "productId": null,
    "dateFrom": null,
    "dateTo": null
  }
}
```

