
# Policy

## Structure

`Policy`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `internet_policy` | [`InternetPolicy`](../../doc/models/internet-policy.md) | Optional | - |
| `parking_policy` | [`ParkingPolicy`](../../doc/models/parking-policy.md) | Optional | - |
| `pet_policy` | [`PetPolicy`](../../doc/models/pet-policy.md) | Optional | - |
| `children_allowed` | `Boolean` | Required | Children policy |
| `smoking_allowed` | `Boolean` | Required | Smoking policy |

## Example (as JSON)

```json
{
  "internetPolicy": {
    "accessInternet": true,
    "kindOfInternet": "WiFi",
    "availableInternet": "AllAreas",
    "chargeInternet": "Free"
  },
  "parkingPolicy": {
    "accessParking": true,
    "locatedParking": "OnSite",
    "privateParking": true,
    "chargeParking": "$ 150",
    "timeCostParking": "PerStay",
    "necessaryReservationParking": "NotPossible"
  },
  "petPolicy": {
    "allowedPets": "Allowed",
    "chargePets": "Free"
  },
  "childrenAllowed": true,
  "smokingAllowed": false
}
```

