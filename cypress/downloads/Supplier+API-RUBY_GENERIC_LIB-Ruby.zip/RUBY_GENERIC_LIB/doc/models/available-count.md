
# Available Count

## Structure

`AvailableCount`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `begin_date` | `Date` | Required | Beginning date of date range for which count is applied. Date should be in format "yyyy-MM-dd" |
| `end_date` | `Date` | Required | End date of date range for which count  is applied. Date should be in format "yyyy-MM-dd" |
| `count` | `Integer` | Required | Number of available rooms |

## Example (as JSON)

```json
{
  "beginDate": "2016-03-13",
  "endDate": "2016-03-13",
  "count": 60
}
```

