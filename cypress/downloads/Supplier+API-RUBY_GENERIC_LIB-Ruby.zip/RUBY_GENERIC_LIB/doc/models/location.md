
# Location

## Structure

`Location`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `postal_code` | `String` | Required | Postal code of property (Zip code) |
| `country` | `String` | Required | Country of property. Require 2 letter ISO code |
| `region` | `String` | Required | State (Region) of PM. Required for US properties. |
| `city` | `String` | Required | City of property |
| `street` | `String` | Required | Street of property |
| `zip_code_9` | `String` | Required | Set only for US properties (format should be zip5-xxxx) |

## Example (as JSON)

```json
{
  "postalCode": "60606",
  "country": "US",
  "region": "Illinois",
  "city": "Chicago",
  "street": "210 North Wells Street",
  "zipCode9": "60606-1330"
}
```

