
# Yield

## Structure

`Yield`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `begin_date` | `Date` | Required | From date. Date should be in format "yyyy-MM-dd" |
| `end_date` | `Date` | Required | To date. Date should be in format "yyyy-MM-dd" |
| `amount` | `Float` | Required | Yield amount |
| `modifier` | [`YieldModifierEnum`](../../doc/models/yield-modifier-enum.md) | Required | - |
| `weekend_param` | [`WeekendParamEnum`](../../doc/models/weekend-param-enum.md) | Optional | - |
| `param` | `Integer` | Optional | Parameter. It can verify depending on what YMR was set. More details about params you can see in the description above. |

## Example (as JSON)

```json
{
  "beginDate": null,
  "endDate": null,
  "amount": null,
  "modifier": "INCREASE_PERCENT"
}
```

