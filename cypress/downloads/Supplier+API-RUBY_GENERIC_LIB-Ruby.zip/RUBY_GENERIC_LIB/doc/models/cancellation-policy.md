
# Cancellation Policy

## Structure

`CancellationPolicy`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `type` | [`CancellationPolicyTypeEnum`](../../doc/models/cancellation-policy-type-enum.md) | Required | - |
| `manual_policy` | [`ManualPolicy`](../../doc/models/manual-policy.md) | Required | - |

## Example (as JSON)

```json
{
  "type": "MANUAL",
  "manualPolicy": {
    "type": "FLAT",
    "manualPolicies": [
      {
        "chargeValue": 20,
        "beforeDays": 34,
        "cancellationFee": 1
      },
      {
        "chargeValue": 12,
        "beforeDays": 45,
        "cancellationFee": 2
      }
    ]
  }
}
```

