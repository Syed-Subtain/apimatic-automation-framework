
# Reservation Commissions Notification Model

## Structure

`ReservationCommissionsNotificationModel`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `channel_commission` | `Float` | Optional | Channel commission |
| `commission` | `Float` | Optional | BookingPal commission |

## Example (as JSON)

```json
{
  "channelCommission": 10,
  "commission": 12
}
```

