
# Reservation Tax Notification Model

Model used for taxes in reservation push notification

## Structure

`ReservationTaxNotificationModel`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `String` | Optional | Tax altID (alt ID which PMS sent over API) |
| `name` | `String` | Required | Tax name |
| `value` | `Float` | Required | Tax value |

## Example (as JSON)

```json
{
  "id": "22",
  "name": "State of Florida-Lake County State Tax",
  "value": 5
}
```

