
# Weekend Param Enum

## Enumeration

`WeekendParamEnum`

## Fields

| Name |
|  --- |
| `DAYS_OF_WEEKEND_SAT_SUN` |
| `DAYS_OF_WEEKEND_FRI_SAT` |
| `DAYS_OF_WEEKEND_FRI_SAT_SUN` |
| `DAYS_OF_WEEKEND_THU_FRI_SAT` |
| `DAYS_OF_WEEKEND_THU_FRI_SAT_SUN` |

## Example

```
DAYS_OF_WEEKEND_SAT_SUN
```

