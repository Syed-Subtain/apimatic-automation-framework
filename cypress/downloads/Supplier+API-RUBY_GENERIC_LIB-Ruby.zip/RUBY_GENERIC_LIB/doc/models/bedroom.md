
# Bedroom

## Structure

`Bedroom`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `beds` | [`Beds`](../../doc/models/beds.md) | Required | - |
| `type` | [`BedroomTypeEnum`](../../doc/models/bedroom-type-enum.md) | Required | - |
| `private_bathroom` | `Boolean` | Required | Room have private bathroom |

## Example (as JSON)

```json
{
  "beds": {
    "bed": [
      {
        "bedType": "RMA113",
        "count": 1
      },
      {
        "bedType": "RMA58",
        "count": 1
      }
    ]
  },
  "type": "Bedroom",
  "privateBathroom": false
}
```

