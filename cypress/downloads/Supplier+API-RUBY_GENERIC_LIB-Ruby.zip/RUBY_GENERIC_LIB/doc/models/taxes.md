
# Taxes

## Structure

`Taxes`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `name` | `String` | Required | Tax name |
| `type` | [`TaxisTypeEnum`](../../doc/models/taxis-type-enum.md) | Optional | - |
| `value` | `Float` | Required | Tax value |
| `alt_id` | `String` | Optional | Alternative Id of the tax (tax id in your system) |

## Example (as JSON)

```json
{
  "name": "Tax reTestAT",
  "type": "SalesTaxIncluded",
  "value": 55,
  "altId": "11"
}
```

