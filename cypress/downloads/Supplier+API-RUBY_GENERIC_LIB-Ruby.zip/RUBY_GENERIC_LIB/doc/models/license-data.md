
# License Data

## Structure

`LicenseData`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `content_data` | [`Array<LicenseDataContent>`](../../doc/models/license-data-content.md) | Required | - |
| `variant_id` | `String` | Required | Variant ID |

## Example (as JSON)

```json
{
  "contentData": [
    {
      "name": null,
      "value": null
    },
    {
      "name": null,
      "value": null
    },
    {
      "name": null,
      "value": null
    }
  ],
  "variantId": "variantId0"
}
```

