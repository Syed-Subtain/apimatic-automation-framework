
# Request to Book Cancel Request Model

Model for request to book cancel API request

## Structure

`RequestToBookCancelRequestModel`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `action` | `String` | Required | RESERVATION_REQUEST_VOIDED |
| `reservation_id` | `Integer` | Required | ID of reservation in BookingPal |

## Example (as JSON)

```json
{
  "action": "RESERVATION_REQUEST_VOIDED",
  "reservationId": 12345612345
}
```

