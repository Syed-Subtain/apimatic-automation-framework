
# Fee Tax Validation Settings

## Structure

`FeeTaxValidationSettings`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `validation_settings` | [`Array<FeeTaxMandatorySetting>`](../../doc/models/fee-tax-mandatory-setting.md) | Required | Model |

## Example (as JSON)

```json
{
  "validationSettings": [
    {
      "productId": 1235124634,
      "isFeeMandatory": false,
      "isTaxMandatory": false
    },
    {
      "productId": 1235124636,
      "isFeeMandatory": true,
      "isTaxMandatory": true
    },
    {
      "productId": 1235124637,
      "isFeeMandatory": true,
      "isTaxMandatory": true
    }
  ]
}
```

