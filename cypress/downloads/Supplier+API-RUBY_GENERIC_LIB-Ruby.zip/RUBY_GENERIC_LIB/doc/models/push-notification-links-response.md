
# Push Notification Links Response

## Structure

`PushNotificationLinksResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `message` | `String` | Required | text info message |
| `error_message` | `Array<String>` | Required | List of error messages |
| `is_error` | `Boolean` | Required | Is error (default = false) |
| `code` | `String` | Required | Code of message |
| `data` | [`Array<PushNotificationLinksModel>`](../../doc/models/push-notification-links-model.md) | Required | List of Models |

## Example (as JSON)

```json
{
  "message": "",
  "errorMessage": [],
  "is_error": false,
  "code": "",
  "data": [
    {
      "bookLink": "https://newreservationnotification.link",
      "cancelLink": "https://cancelreservation.link",
      "asyncPush": "https://asyncpush.link",
      "requestToBook": "https://requestToBook.link",
      "useJson": true
    }
  ]
}
```

