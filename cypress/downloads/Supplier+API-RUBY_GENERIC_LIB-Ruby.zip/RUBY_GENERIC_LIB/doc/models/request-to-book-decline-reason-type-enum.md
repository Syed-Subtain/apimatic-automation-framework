
# Request to Book Decline Reason Type Enum

## Enumeration

`RequestToBookDeclineReasonTypeEnum`

## Fields

| Name |
|  --- |
| `DATES_NOT_AVAILABLE` |
| `NOT_A_GOOD_FIT` |
| `WAITING_FOR_BETTER_RESERVATION` |
| `NOT_COMFORTABLE` |

## Example

```
DATES_NOT_AVAILABLE
```

