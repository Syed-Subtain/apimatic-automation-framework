
# Product Image Asynchronous Push Message Request

Request for product image notification messages which BookingPal push asynchronous (webhooks request)

## Structure

`ProductImageAsynchronousPushMessageRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `supplier_id` | `Integer` | Required | Id of supplier in BookingPal |
| `type` | `String` | Required | - |
| `processing_image` | [`Array<ProductImagePushNotification>`](../../doc/models/product-image-push-notification.md) | Required | Product Image Validation Model |

## Example (as JSON)

```json
{
  "supplierId": 61692827,
  "type": "PROCESSING_IMAGES",
  "processingImage": [
    {
      "productId": "1235138415",
      "name": "Riverwalk Inn Wizard",
      "altId": "123",
      "images": [
        {
          "success": true,
          "type": "IMPORT",
          "url": "https://www.staymarquis.com/uploads/homeaway/1570665600_odQZP_bedroom62.jpg",
          "version": "2021-01-29T11:53:31.000+0000"
        }
      ]
    }
  ]
}
```

