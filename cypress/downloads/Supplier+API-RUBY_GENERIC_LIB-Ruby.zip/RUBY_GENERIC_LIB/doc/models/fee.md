
# Fee

## Structure

`Fee`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `begin_date` | `Date` | Optional | Fee applies from Date. Date should be in format "yyyy-MM-dd" |
| `end_date` | `Date` | Optional | Fee applies to Date. Date should be in format "yyyy-MM-dd" |
| `entity_type` | [`FeeEntityTypeEnum`](../../doc/models/fee-entity-type-enum.md) | Required | - |
| `fee_type` | [`FeeTypeEnum`](../../doc/models/fee-type-enum.md) | Required | - |
| `option` | `Integer` | Optional | Number of guests when set extra person fee. Only values >0 are allowed. |
| `name` | `String` | Required | Fee name.  For example: Extra person, Cleaning fee, Parking etc. |
| `tax_type` | [`FeeTaxTypeEnum`](../../doc/models/fee-tax-type-enum.md) | Optional | - |
| `unit` | [`FeeUnitEnum`](../../doc/models/fee-unit-enum.md) | Required | - |
| `value` | `Float` | Required | Fee value |
| `value_type` | [`FeeValueTypeEnum`](../../doc/models/fee-value-type-enum.md) | Required | Value Type {FLAT, PERCENT} |
| `alt_id` | `String` | Optional | Alternative Id of the fee (fee id in your system) |

## Example (as JSON)

```json
{
  "entityType": "MANDATORY",
  "feeType": "GENERAL",
  "name": null,
  "unit": "PER_STAY",
  "value": null,
  "valueType": "FLAT"
}
```

