
# Space Unit Enum

## Enumeration

`SpaceUnitEnum`

## Fields

| Name |
|  --- |
| `SQ_M` |
| `SQ_FT` |

## Example

```
SQ_M
```

