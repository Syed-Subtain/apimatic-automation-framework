
# Payment Policy

## Structure

`PaymentPolicy`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `type` | [`PaymentPolicyTypeEnum`](../../doc/models/payment-policy-type-enum.md) | Required | Full or Split payment. In case of Split payment - it will be 2 payments. [SPLIT,FULL] |
| `split_payment` | [`SplitPayment`](../../doc/models/split-payment.md) | Required | - |

## Example (as JSON)

```json
{
  "type": "SPLIT",
  "splitPayment": {
    "depositType": "FLAT",
    "value": 4,
    "secondPaymentDays": 30
  }
}
```

