
# Authorization

Authorization (Login) response

## Structure

`Authorization`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `token` | `String` | Required | Generated token for authorization. It must be used in every request to API as param jwt. Token is valid for 1h |
| `message` | `String` | Required | Message |
| `is_error` | `Boolean` | Required | Is request success or not |
| `error_message` | `Array<String>` | Required | Error Message(s) in Array format |
| `code` | `String` | Optional | Response code |
| `organization_id` | `Integer` | Required | Organization id - PMS ID |
| `supplier_id` | `Integer` | Required | Supplier ID (Property Manager ID - or PMS ID - depend on account on which you are logged in) |
| `party_id` | `Integer` | Required | Deprecated field. It will be removed in version 3.3. Please use supplierId field instead |
| `name` | `String` | Required | Account name |
| `currency` | `String` | Required | Account currency |

## Example (as JSON)

```json
{
  "message": "",
  "errorMessage": [],
  "is_error": false,
  "code": "",
  "token": "a9eaf5b0-c433-450e-991d-8011fc4aa264",
  "partyId": 61692799,
  "organizationId": 61690131,
  "name": "Update Name",
  "currency": "USD",
  "supplierId": 61692799
}
```

