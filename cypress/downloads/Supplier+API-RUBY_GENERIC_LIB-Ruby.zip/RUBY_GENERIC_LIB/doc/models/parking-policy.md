
# Parking Policy

## Structure

`ParkingPolicy`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `access_parking` | `Boolean` | Required | Access parking into properties {true,false} |
| `located_parking` | [`LocatedParkingTypeEnum`](../../doc/models/located-parking-type-enum.md) | Optional | - |
| `private_parking` | `Boolean` | Optional | Parking is private or no. {true,false} |
| `charge_parking` | `String` | Optional | Charge parking. Example: “Free”, “$ 100”. |
| `time_cost_parking` | [`TimeCostParkingEnum`](../../doc/models/time-cost-parking-enum.md) | Optional | - |
| `necessary_reservation_parking` | [`ReservationParkingTypeEnum`](../../doc/models/reservation-parking-type-enum.md) | Optional | - |

## Example (as JSON)

```json
{
  "accessParking": true,
  "locatedParking": "OnSite",
  "privateParking": true,
  "chargeParking": "$ 150",
  "timeCostParking": "PerStay",
  "necessaryReservationParking": "NotPossible"
}
```

