
# License Response Content Data

## Structure

`LicenseResponseContentData`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `name` | `String` | Optional | name of the license |
| `value` | `String` | Optional | value of the license |

## Example (as JSON)

```json
{
  "name": null,
  "value": null
}
```

