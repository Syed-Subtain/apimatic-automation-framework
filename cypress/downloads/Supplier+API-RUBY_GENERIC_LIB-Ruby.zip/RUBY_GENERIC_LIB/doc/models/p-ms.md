
# P Ms

Property Manager model

## Structure

`PMs`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `Integer` | Required | ID of the property manager |
| `name` | `String` | Required | Name of the property manager’s company |
| `extra_name` | `String` | Required | Contact person |
| `email_address` | `String` | Required | Email of the property manager |

## Example (as JSON)

```json
{
  "id": 61690133,
  "name": "Test name",
  "extraName": "Test fullname",
  "emailAddress": "test001@gmail.com"
}
```

