
# Request to Book Type Enum

## Enumeration

`RequestToBookTypeEnum`

## Fields

| Name |
|  --- |
| `ACCEPT` |
| `DENY` |

## Example

```
ACCEPT
```

