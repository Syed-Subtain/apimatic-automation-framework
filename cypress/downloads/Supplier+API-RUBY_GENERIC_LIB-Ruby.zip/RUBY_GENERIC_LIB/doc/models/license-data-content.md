
# License Data Content

## Structure

`LicenseDataContent`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `name` | `String` | Optional | name of the license |
| `value` | `String` | Optional | data value of the license |

## Example (as JSON)

```json
{
  "name": null,
  "value": null
}
```

