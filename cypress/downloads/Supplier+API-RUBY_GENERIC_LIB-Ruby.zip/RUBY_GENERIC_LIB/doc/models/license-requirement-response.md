
# License Requirement Response

## Structure

`LicenseRequirementResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `message` | `String` | Required | text info message |
| `error_message` | `Array<String>` | Required | List of error messages |
| `is_error` | `Boolean` | Required | Is error (default = false) |
| `code` | `String` | Required | Code of message |
| `data` | [`Array<LicenseReqData>`](../../doc/models/license-req-data.md) | Required | License Requirements Data |

## Example (as JSON)

```json
{
  "message": "message0",
  "errorMessage": [
    "errorMessage2",
    "errorMessage3",
    "errorMessage4"
  ],
  "is_error": false,
  "code": "code8",
  "data": [
    {
      "productId": null,
      "licenseRequirementResponse": null
    },
    {
      "productId": null,
      "licenseRequirementResponse": null
    }
  ]
}
```

