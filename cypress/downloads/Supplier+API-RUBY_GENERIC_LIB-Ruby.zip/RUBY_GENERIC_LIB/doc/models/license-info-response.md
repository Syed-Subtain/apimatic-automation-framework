
# License Info Response

## Structure

`LicenseInfoResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `data` | [`Array<LicenseResponseDataDetail>`](../../doc/models/license-response-data-detail.md) | Optional | - |
| `meta` | [`Array<LicenseRequirementMeta>`](../../doc/models/license-requirement-meta.md) | Optional | - |
| `warnings` | `Array<String>` | Optional | List of warning messages |
| `errors` | `Array<String>` | Optional | List of error messages |

## Example (as JSON)

```json
{
  "data": null,
  "meta": null,
  "warnings": null,
  "errors": null
}
```

