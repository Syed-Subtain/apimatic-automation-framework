
# Message Model

Model for one message

## Structure

`MessageModel`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `Integer` | Optional | Id of message |
| `message` | `String` | Required | Message text |
| `created_at` | `String` | Required | Time when message created |
| `user` | [`UserEnum`](../../doc/models/user-enum.md) | Required | - |
| `channel_message_id` | `String` | Optional | Channel Message ID |

## Example (as JSON)

```json
{
  "id": 68233,
  "message": "Test message",
  "createdAt": "2019-11-25T12:32:39.000+0000",
  "user": "PROPERTY_MANAGER",
  "channelMessageId": "2221139318748986368"
}
```

