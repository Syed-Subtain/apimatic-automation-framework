
# Taxis Type Enum

## Enumeration

`TaxisTypeEnum`

## Fields

| Name |
|  --- |
| `SALESTAXINCLUDED` |
| `SALESTAXEXCLUDED` |

## Example

```
SalesTaxIncluded
```

