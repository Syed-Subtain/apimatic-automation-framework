
# Asynchronous Validation Model

Model for Validation messages

## Structure

`AsynchronousValidationModel`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `product_id` | `Integer` | Required | Id of product in BookingPal |
| `validation_errors` | `String` | Optional | Error message - explanation what are problems if validation failed. |
| `valid` | `Boolean` | Required | Is product valid |

## Example (as JSON)

```json
{
  "productId": 291356,
  "validationErrors": "noPrice;",
  "valid": false
}
```

