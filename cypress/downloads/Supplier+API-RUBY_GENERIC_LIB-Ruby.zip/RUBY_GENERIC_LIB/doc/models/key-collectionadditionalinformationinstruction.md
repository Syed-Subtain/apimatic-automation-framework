
# Key Collectionadditionalinformationinstruction

## Structure

`KeyCollectionadditionalinformationinstruction`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `how` | `String` | Required | how key should be collected |
| `mwhen` | `String` | Required | when key should be collected |

## Example (as JSON)

```json
{
  "how": "how example",
  "when": "when example"
}
```

