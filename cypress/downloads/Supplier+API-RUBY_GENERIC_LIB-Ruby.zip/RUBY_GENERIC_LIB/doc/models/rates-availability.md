
# Rates Availability

Rates Availability model

## Structure

`RatesAvailability`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `product_id` | `Integer` | Required | ID of the product |
| `lead_time` | `Integer` | Optional | Number of days before reservation in which reservation couldn’t be made. Allowed values are 0-7. If this value is set on property level - it will be used before than value on PM level. |
| `rates` | [`Array<Rate>`](../../doc/models/rate.md) | Optional | List of models |
| `min_stays` | [`Array<MinStayModel>`](../../doc/models/min-stay-model.md) | Optional | List of models |
| `max_stays` | [`Array<MaxStayModel>`](../../doc/models/max-stay-model.md) | Optional | List of models |
| `restrictions` | [`Array<Restriction>`](../../doc/models/restriction.md) | Optional | List of models |
| `availabilities` | [`Array<AvailabilityModel>`](../../doc/models/availability-model.md) | Optional | List of models |
| `available_count` | [`Array<AvailableCount>`](../../doc/models/available-count.md) | Optional | List of models (Only for MLT properties) |

## Example (as JSON)

```json
{
  "productId": 98,
  "leadTime": null,
  "rates": null,
  "minStays": null,
  "maxStays": null,
  "restrictions": null,
  "availabilities": null,
  "availableCount": null
}
```

