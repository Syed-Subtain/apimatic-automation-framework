
# Fee Tax Mandatory

## Structure

`FeeTaxMandatory`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `is_fee_mandatory` | `Boolean` | Required | Used in BookingPal validator. Info does property require any fee or not. Default value is TRUE. This setup can be overridden on property level with different API call, which is stronger. |
| `is_tax_mandatory` | `Boolean` | Required | Used in BookingPal validator. Info does property require any tax or not. Default value is TRUE. This setup can be overridden on property level with different API call, which is stronger. |

## Example (as JSON)

```json
{
  "isFeeMandatory": true,
  "isTaxMandatory": true
}
```

