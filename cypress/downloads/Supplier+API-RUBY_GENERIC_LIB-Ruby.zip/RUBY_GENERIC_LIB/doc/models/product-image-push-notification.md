
# Product Image Push Notification

## Structure

`ProductImagePushNotification`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `name` | `String` | Required | name of the object |
| `product_id` | `String` | Required | product id |
| `alt_id` | `String` | Optional | product alternate id |
| `images` | [`Array<ImagePushNotification>`](../../doc/models/image-push-notification.md) | Required | - |

## Example (as JSON)

```json
{
  "name": null,
  "productId": null,
  "images": {
    "success": null,
    "type": "IMPORT",
    "url": null,
    "version": null
  }
}
```

