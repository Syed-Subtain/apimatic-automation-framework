
# License Requirements Data Object Detail

## Structure

`LicenseRequirementsDataObjectDetail`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `name` | `String` | Optional | name of the property |
| `level` | `String` | Optional | Level of the property for the name above |
| `variants` | [`Array<LicenseVariants>`](../../doc/models/license-variants.md) | Optional | - |
| `active` | `String` | Optional | active/inactive indicator |
| `id` | `String` | Optional | ID of the requirement. |

## Example (as JSON)

```json
{
  "name": null,
  "level": null,
  "variants": null,
  "active": null,
  "id": null
}
```

