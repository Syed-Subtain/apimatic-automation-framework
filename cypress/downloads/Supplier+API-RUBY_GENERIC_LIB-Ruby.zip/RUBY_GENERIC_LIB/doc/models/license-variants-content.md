
# License Variants Content

## Structure

`LicenseVariantsContent`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `name` | `String` | Optional | name of the variant |
| `data_type` | `String` | Optional | data type of the variant |
| `required` | `String` | Optional | indicator if content is required |

## Example (as JSON)

```json
{
  "name": null,
  "dataType": null,
  "required": null
}
```

