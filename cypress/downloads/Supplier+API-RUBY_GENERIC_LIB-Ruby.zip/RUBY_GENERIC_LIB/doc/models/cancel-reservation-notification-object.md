
# Cancel Reservation Notification Object

## Structure

`CancelReservationNotificationObject`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `reservation_id` | `String` | Required | Id of the reservation in BookingPal |
| `product_id` | `String` | Required | Id of the product in BookingPal |
| `supplier_id` | `Integer` | Required | Id of the property manager |
| `agent_name` | `String` | Optional | DEPRECATED. Use channelName instead. Agent name/Channel name |
| `channel_name` | `String` | Required | Agent name/Channel name |
| `confirmation_id` | `String` | Required | Channel confirmation code |
| `unique_key` | `String` | Required | Unique code to identify that the request is from BookingPal. This value is unique for every PMS (and it will be different in different environments). |
| `new_state` | `String` | Required | It will always be "Cancelled" in this request |
| `customer_name` | `String` | Required | Guest full name (in format firstName lastName) |
| `from_date` | `Date` | Required | Reservation date from. Date is in format "yyyy-MM-dd" |
| `to_date` | `Date` | Required | Reservation date to. Date is in format "yyyy-MM-dd" |
| `adult` | `Integer` | Required | Number of adults |
| `child` | `Integer` | Required | Number of children |
| `email` | `String` | Required | Guest email |
| `phone` | `String` | Optional | Guest phone |
| `notes` | `String` | Optional | Guest notes |
| `credit_card_type` | `String` | Optional | Credit card type |
| `total` | `Float` | Required | Best available rate (This is the total value that guests will pay, including rate, fees, taxes, and all commissions. ) |

## Example (as JSON)

```json
{
  "reservationId": "107",
  "productId": "1234816374",
  "supplierId": 3731837,
  "channelName": "TestAndrew",
  "confirmationId": "dasdasd",
  "uniqueKey": null,
  "newState": null,
  "customerName": "John Smith",
  "fromDate": null,
  "toDate": null,
  "adult": 2,
  "child": 0,
  "email": "andrewtesttest222@gmail.com",
  "total": null
}
```

