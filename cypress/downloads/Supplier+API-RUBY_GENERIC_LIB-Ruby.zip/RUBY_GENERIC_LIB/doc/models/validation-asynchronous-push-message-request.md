
# Validation Asynchronous Push Message Request

Request for validation messages which BookingPal push asynchronous (webhooks request)

## Structure

`ValidationAsynchronousPushMessageRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `supplier_id` | `Integer` | Required | Id of supplier in BookingPal |
| `type` | `String` | Required | - |
| `validation` | [`Array<AsynchronousValidationModel>`](../../doc/models/asynchronous-validation-model.md) | Required | Validation Model |

## Example (as JSON)

```json
{
  "supplierId": 636753,
  "type": "BP_VALIDATION",
  "validation": [
    {
      "productId": 291358,
      "validationErrors": "null",
      "valid": true
    },
    {
      "productId": 291356,
      "validationErrors": "noPrice;",
      "valid": false
    }
  ]
}
```

