
# Allowed Pets Type Enum

## Enumeration

`AllowedPetsTypeEnum`

## Fields

| Name |
|  --- |
| `ALLOWED` |
| `ALLOWEDONREQUEST` |
| `NOTALLOWED` |

## Example

```
Allowed
```

