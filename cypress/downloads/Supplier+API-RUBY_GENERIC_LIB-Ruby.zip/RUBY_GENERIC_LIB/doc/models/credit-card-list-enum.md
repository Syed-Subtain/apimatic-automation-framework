
# Credit Card List Enum

## Enumeration

`CreditCardListEnum`

## Fields

| Name |
|  --- |
| `MASTER_CARD` |
| `VISA` |
| `AMERICAN_EXPRESS` |
| `DINERS_CLUB` |
| `DISCOVER` |

## Example

```
MASTER_CARD
```

