
# Rates and Availability Mapping Enum

Channel rates And Availability Mapping

## Enumeration

`RatesAndAvailabilityMappingEnum`

## Fields

| Name |
|  --- |
| `MAPTOPROPERTY` |
| `MAPTOROOM` |
| `MAPTORATEPLAN` |

## Example

```
MapToProperty
```

