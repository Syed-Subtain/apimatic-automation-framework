
# Channel Mark up Yield Info

## Structure

`ChannelMarkUpYieldInfo`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `begin_date` | `String` | Required | begin date |
| `end_date` | `String` | Required | end date |
| `amount` | `Float` | Required | the amount |
| `modifier` | `String` | Required | modifier |
| `channel_abbreviation` | `String` | Required | channel abbreviation |

## Example (as JSON)

```json
{
  "beginDate": "beginDate6",
  "endDate": "endDate2",
  "amount": 56.78,
  "modifier": "modifier6",
  "channelAbbreviation": "channelAbbreviation6"
}
```

