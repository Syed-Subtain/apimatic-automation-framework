
# Feesand Taxes

## Structure

`FeesandTaxes`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `product_id` | `Integer` | Required | ID of the product |
| `fees` | [`Array<Fee>`](../../doc/models/fee.md) | Optional | List of models |
| `taxes` | [`Array<Taxes>`](../../doc/models/taxes.md) | Optional | List of models |

## Example (as JSON)

```json
{
  "productId": 98,
  "fees": null,
  "taxes": null
}
```

