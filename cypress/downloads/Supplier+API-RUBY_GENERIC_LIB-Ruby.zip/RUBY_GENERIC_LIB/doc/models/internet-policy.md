
# Internet Policy

## Structure

`InternetPolicy`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `access_internet` | `Boolean` | Required | Access internet into properties |
| `kind_of_internet` | [`KindOfInternetTypeEnum`](../../doc/models/kind-of-internet-type-enum.md) | Optional | - |
| `available_internet` | [`AvailableInternetEnum`](../../doc/models/available-internet-enum.md) | Optional | - |
| `charge_internet` | `String` | Optional | Charge internet. Example: “Free”, “$ 100”. |

## Example (as JSON)

```json
{
  "accessInternet": true,
  "kindOfInternet": "WiFi",
  "availableInternet": "AllAreas",
  "chargeInternet": "Free"
}
```

