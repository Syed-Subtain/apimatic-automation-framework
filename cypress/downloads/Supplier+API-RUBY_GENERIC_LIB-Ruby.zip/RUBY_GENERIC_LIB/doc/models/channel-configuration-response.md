
# Channel Configuration Response

## Structure

`ChannelConfigurationResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `message` | `String` | Required | text info message |
| `error_message` | `Array<String>` | Required | List of error messages |
| `is_error` | `Boolean` | Required | Is error (default = false) |
| `code` | `String` | Required | Code of message |
| `data` | [`Array<ChannelConfigurationDetail>`](../../doc/models/channel-configuration-detail.md) | Required | - |

## Example (as JSON)

```json
{
  "message": "message0",
  "errorMessage": [
    "errorMessage2",
    "errorMessage3",
    "errorMessage4"
  ],
  "is_error": false,
  "code": "code8",
  "data": [
    {
      "name": null,
      "abbreviation": null,
      "logo": null,
      "state": null,
      "supportValidation": null,
      "supportCreate": null,
      "supportConnect": null,
      "supportOpenClose": null,
      "supportStaticUpdate": null,
      "supportDynamicUpdate": null,
      "supportSynchronization": null,
      "supportCreateChannelAccount": null,
      "supportAuthorization": null,
      "supportCancelFormPm": null,
      "supportModificationFromPm": null,
      "supportGather": null,
      "supportChannelCancellationPolicy": null,
      "bookingType": null,
      "ratesAndAvailabilityMapping": null,
      "acceptsPropertyType": null,
      "nativePropertyType": null,
      "minimumProperties": null
    },
    {
      "name": null,
      "abbreviation": null,
      "logo": null,
      "state": null,
      "supportValidation": null,
      "supportCreate": null,
      "supportConnect": null,
      "supportOpenClose": null,
      "supportStaticUpdate": null,
      "supportDynamicUpdate": null,
      "supportSynchronization": null,
      "supportCreateChannelAccount": null,
      "supportAuthorization": null,
      "supportCancelFormPm": null,
      "supportModificationFromPm": null,
      "supportGather": null,
      "supportChannelCancellationPolicy": null,
      "bookingType": null,
      "ratesAndAvailabilityMapping": null,
      "acceptsPropertyType": null,
      "nativePropertyType": null,
      "minimumProperties": null
    }
  ]
}
```

