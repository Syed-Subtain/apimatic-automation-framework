
# Reservation Push Response

This is response which the BookingPal expect to get on from PMS on push POST request for create/cancel reservation

## Structure

`ReservationPushResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `alt_id` | `String` | Required | Id of reservation in your system |
| `is_error` | `Boolean` | Required | Did you have error during processing of request (true) or not (false) |
| `code` | `String` | Required | Code of message |
| `message` | `String` | Required | Text info message. If you have any error please put here detail message. |

## Example (as JSON)

```json
{
  "altId": "45717",
  "is_error": false,
  "code": "",
  "message": "Reservation is processed."
}
```

