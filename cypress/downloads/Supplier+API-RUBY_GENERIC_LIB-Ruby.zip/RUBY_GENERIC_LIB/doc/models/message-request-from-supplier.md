
# Message Request From Supplier

## Structure

`MessageRequestFromSupplier`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `thread_id` | `Integer` | Required | ID of thread |
| `message` | `String` | Required | Message text |

## Example (as JSON)

```json
{
  "threadId": 5656,
  "message": "new message"
}
```

