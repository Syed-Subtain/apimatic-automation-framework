
# Key Collection Checkinmethod Enum

## Enumeration

`KeyCollectionCheckinmethodEnum`

## Fields

| Name |
|  --- |
| `DOORMAN` |
| `LOCK_BOX` |
| `SMART_LOCK` |
| `KEYPAD` |
| `IN_PERSON_MEET` |
| `OTHER` |
| `FRONT_DESK` |
| `SECRET_SPOT` |
| `INSTRUCTION_CONTACT_US` |

## Example

```
doorman
```

