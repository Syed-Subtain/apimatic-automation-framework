
# Reservation Fee Notification Model

Model used for fees in reservation push notification

## Structure

`ReservationFeeNotificationModel`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `String` | Optional | Fee altID (alt ID which PMS sent over API) |
| `name` | `String` | Required | Fee name |
| `value` | `Float` | Required | Fee value |

## Example (as JSON)

```json
{
  "id": "937-4",
  "name": "Cleaning Fee",
  "value": 110
}
```

