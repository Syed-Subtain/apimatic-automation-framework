
# Notes

Model where you can define different kinds of text values. If you need to delete some kind of texts, for example short description, you can do this on Update call (PUT), and you need to pass empty array for texts value, for example :  "shortDescription": {  "texts": [  ] }

## Structure

`Notes`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `description` | [`DescriptionTextModel`](../../doc/models/description-text-model.md) | Required | Model for any kind of description text in Property object |
| `house_rules` | [`DescriptionTextModel`](../../doc/models/description-text-model.md) | Optional | Model for any kind of description text in Property object |
| `fine_print` | [`DescriptionTextModel`](../../doc/models/description-text-model.md) | Optional | Model for any kind of description text in Property object |
| `short_description` | [`DescriptionTextModel`](../../doc/models/description-text-model.md) | Optional | Model for any kind of description text in Property object |
| `name` | [`DescriptionTextModel`](../../doc/models/description-text-model.md) | Optional | Model for any kind of description text in Property object |

## Example (as JSON)

```json
{
  "description": {
    "texts": [
      {
        "language": "EN",
        "value": "Main description on EN!"
      },
      {
        "language": "ES",
        "value": "Main description on ES!"
      }
    ]
  },
  "houseRules": {
    "texts": [
      {
        "language": "EN",
        "value": "House Rules on EN!"
      },
      {
        "language": "SR",
        "value": "House Rules on SR!"
      }
    ]
  },
  "name": {
    "texts": [
      {
        "language": "EN",
        "value": "House Rules on EN!"
      },
      {
        "language": "SR",
        "value": "House Rules on SR!"
      }
    ]
  },
  "shortDescription": {
    "texts": [
      {
        "language": "EN",
        "value": "House Rules on EN!"
      },
      {
        "language": "SR",
        "value": "House Rules on SR!"
      }
    ]
  },
  "finePrint": {
    "texts": [
      {
        "language": "EN",
        "value": "House Rules on EN!"
      },
      {
        "language": "SR",
        "value": "House Rules on SR!"
      }
    ]
  }
}
```

