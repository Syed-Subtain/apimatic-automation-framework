
# Payment Gateways Type Enum

## Enumeration

`PaymentGatewaysTypeEnum`

## Fields

| Name |
|  --- |
| `PAYPAL` |
| `AUTHORIZE_NET` |
| `BRIDGE_PAY` |
| `PAY_BOX` |
| `DIBS` |
| `O_GONE` |
| `DOC_DATA` |
| `PAY_GATE` |

## Example

```
PAYPAL
```

