
# Thread

## Structure

`Thread`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `Integer` | Required | Thread ID |
| `last_message_sent_at` | `String` | Required | Time when last message was sent |
| `last_message_text` | `String` | Required | Last message text |
| `channel_thread_id` | `String` | Optional | Channel thread ID |
| `channel_name` | `String` | Required | Channel from where come reservation |
| `channel_abb` | [`ChannelABBEnum`](../../doc/models/channel-abb-enum.md) | Required | - |
| `guest_name` | `String` | Required | Name of guest |
| `guest_email_address` | `String` | Optional | Email of guest |
| `product_id` | `Integer` | Required | ID of product in BookingPal database |
| `reservation_id` | `Integer` | Optional | ID of reservation |
| `date_from` | `Date` | Required | Start date of reservation. Date is in format "yyyy-MM-dd" |
| `date_to` | `Date` | Required | End date of reservation. Date is in format "yyyy-MM-dd" |

## Example (as JSON)

```json
{
  "id": null,
  "lastMessageSentAt": null,
  "lastMessageText": null,
  "channelName": null,
  "channelABB": "BKG",
  "guestName": null,
  "productId": null,
  "dateFrom": null,
  "dateTo": null
}
```

