
# License Update Response

## Structure

`LicenseUpdateResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `message` | `String` | Optional | text info message |
| `error_message` | `Array<String>` | Optional | List of error messages |
| `is_error` | `Boolean` | Optional | Is error (default = false) |
| `code` | `String` | Optional | Code of message |
| `data` | [`Array<LicenseUpdateResponseData>`](../../doc/models/license-update-response-data.md) | Optional | License Update Response Data |

## Example (as JSON)

```json
{
  "message": null,
  "errorMessage": null,
  "is_error": null,
  "code": null,
  "data": null
}
```

