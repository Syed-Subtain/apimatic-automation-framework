
# License Get Response Data

## Structure

`LicenseGetResponseData`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `product_id` | `String` | Optional | name of the property |
| `level` | `String` | Optional | Level of the property for the name above |
| `license_information_response` | [`Array<LicenseInfoResponse>`](../../doc/models/license-info-response.md) | Optional | - |

## Example (as JSON)

```json
{
  "productId": null,
  "level": null,
  "licenseInformationResponse": null
}
```

