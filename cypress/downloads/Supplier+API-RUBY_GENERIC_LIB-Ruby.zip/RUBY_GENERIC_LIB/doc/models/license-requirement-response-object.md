
# License Requirement Response Object

## Structure

`LicenseRequirementResponseObject`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `data` | [`Array<LicenseRequirementsDataObjectDetail>`](../../doc/models/license-requirements-data-object-detail.md) | Optional | - |
| `meta` | [`Array<LicenseRequirementMeta>`](../../doc/models/license-requirement-meta.md) | Optional | - |
| `warnings` | `Array<String>` | Optional | List of warning messages |
| `errors` | `Array<String>` | Optional | List of error messages |

## Example (as JSON)

```json
{
  "data": null,
  "meta": null,
  "warnings": null,
  "errors": null
}
```

