
# Bedroom Type Enum

## Enumeration

`BedroomTypeEnum`

## Fields

| Name |
|  --- |
| `BEDROOM` |
| `ENUM_LIVING_ROOM` |

## Example

```
Bedroom
```

