
# Functions Request to Book Test

## Structure

`FunctionsRequestToBookTest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `action` | [`RequestToBookTestActionEnum`](../../doc/models/request-to-book-test-action-enum.md) | Required | Allowed values for request to book Test action |
| `product_id` | `Integer` | Required | Product id for test request to book |

## Example (as JSON)

```json
{
  "action": "RESERVATION_REQUEST_VOIDED",
  "productId": 1235124634
}
```

