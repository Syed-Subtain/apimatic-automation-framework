
# Company Address

## Structure

`CompanyAddress`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `country` | `String` | Required | Country of PM. Require 2 letter ISO code |
| `state` | `String` | Required | State (Region) of PM. Required for US properties. |
| `street_address` | `String` | Required | Street address of PM. |
| `city` | `String` | Required | City of PM |
| `zip` | `String` | Required | Zip code (postal code) of PM. |

## Example (as JSON)

```json
{
  "country": "US",
  "state": "Test State",
  "streetAddress": "Test Street",
  "city": "Test City",
  "zip": "13245"
}
```

