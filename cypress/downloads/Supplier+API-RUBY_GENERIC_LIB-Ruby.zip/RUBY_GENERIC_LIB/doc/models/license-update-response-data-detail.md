
# License Update Response Data Detail

## Structure

`LicenseUpdateResponseDataDetail`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `meta` | [`Array<LicenseRequirementMeta>`](../../doc/models/license-requirement-meta.md) | Optional | - |
| `data` | [`Array<LicenseResponseIndicatorData>`](../../doc/models/license-response-indicator-data.md) | Optional | - |
| `warnings` | `Array<String>` | Optional | List of warning messages |
| `errors` | `Array<String>` | Optional | List of error messages |

## Example (as JSON)

```json
{
  "meta": null,
  "data": null,
  "warnings": null,
  "errors": null
}
```

