
# Fee Tax Validation Setting Response

## Structure

`FeeTaxValidationSettingResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `message` | `String` | Required | Text info message |
| `error_message` | `Array<String>` | Required | List of error messages |
| `is_error` | `Boolean` | Required | Is error (default = false) |
| `code` | `String` | Required | Code of message |
| `data` | [`Array<FeeTaxValidationSettings>`](../../doc/models/fee-tax-validation-settings.md) | Required | List of Models |

## Example (as JSON)

```json
{
  "message": "",
  "errorMessage": [],
  "is_error": false,
  "code": "",
  "data": [
    {
      "validationSettings": [
        {
          "productId": 1235124634,
          "isFeeMandatory": false,
          "isTaxMandatory": false
        },
        {
          "productId": 1235124636,
          "isFeeMandatory": true,
          "isTaxMandatory": true
        },
        {
          "productId": 1235124637,
          "isFeeMandatory": true,
          "isTaxMandatory": true
        }
      ]
    }
  ]
}
```

