
# Image

Image response object

## Structure

`Image`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `url` | `String` | Required | URL of the image. Please send normal URL, like https://example.com/image01.jpg, and do not use some GET parameters in URL, otherwise image might not be imported. |
| `tags` | [`Array<ImageTagsEnum>`](../../doc/models/image-tags-enum.md) | Optional | Image tags. Tags codes are given in Appendix. |
| `url_mbp` | `String` | Optional | URL of the image on MyBookingPal. This field will be only in response. You can not send this in request. |
| `sort` | `Integer` | Optional | Sort of the image. Image with the lowest sort number will be set as main. This field will be only in response. You can not send this in request. |

## Example (as JSON)

```json
{
  "url": "http://aff.bstatic.com/images/hotel/max500/110/11069098.jpg",
  "tags": [
    4,
    5,
    6
  ],
  "urlMbp": "https://s3.amazonaws.com/mybookingpal/pictures/n2ujn/n2ujn/1235124634/11069098.jpg",
  "sort": 1
}
```

