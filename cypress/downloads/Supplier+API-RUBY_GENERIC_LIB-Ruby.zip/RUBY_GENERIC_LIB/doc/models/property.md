
# Property

## Structure

`Property`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `name` | `String` | Required | Name of the property to display in the list |
| `id` | `Integer` | Optional | Property ID in BookingPal |
| `alt_id` | `Integer` | Optional | Alternative Id of the property (ID in your PMS system).   Note: this field can not be updated, so this field will not be used during update. |
| `supplier_id` | `Integer` | Optional | Id of the Property Manager (not be used for creating new property. Property will have ID of current authorized user) |
| `rooms` | `Integer` | Required | Number of bedrooms. Number of bedrooms should be > 0. Value 0 is only allowed in case property type  is Studio (PCT46 or PCT110) |
| `bathrooms` | `Integer` | Required | Number of bathrooms |
| `toilets` | `Integer` | Optional | Number of toilets |
| `total_beds` | `Integer` | Optional | Property’s total number of beds |
| `space` | `Float` | Optional | Property size |
| `space_unit` | [`SpaceUnitEnum`](../../doc/models/space-unit-enum.md) | Optional | - |
| `persons` | `Integer` | Required | Maximum number of allowed adults |
| `childs` | `Integer` | Optional | Number of allowed children (from 7 to 12 years) |
| `latitude` | `Float` | Optional | Latitude of the property (Must set field latitude and longitude or location) |
| `longitude` | `Float` | Optional | Longitude of the property (Must set field latitude and longitude or location) |
| `living_room` | `Integer` | Optional | Number of Living rooms |
| `notes` | [`Notes`](../../doc/models/notes.md) | Optional | Model where you can define different kinds of text values. If you need to delete some kind of texts, for example short description, you can do this on Update call (PUT), and you need to pass empty array for texts value, for example :  "shortDescription": {  "texts": [  ] } |
| `attributes_with_quantity` | [`Array<AttributesWithQuantity>`](../../doc/models/attributes-with-quantity.md) | Optional | Use this param instead of previous if you need to set quantity more than 1 of attributes. If use both in POST request this will overwrite the previous list (under param attributes). |
| `nearby_amenities` | [`Array<NearbyAmenity>`](../../doc/models/nearby-amenity.md) | Optional | List of Nearby Attributes models. Check allowed values in Appendix. |
| `property_type` | [`PropertyTypesEnum`](../../doc/models/property-types-enum.md) | Required | - |
| `bedroom_configuration` | [`BedroomConfiguration`](../../doc/models/bedroom-configuration.md) | Optional | - |
| `check_in_time` | `String` | Optional | Time of Check in (HH:MM:SS) |
| `check_in_to_time` | `String` | Optional | Time Check in to (HH:MM:SS) |
| `check_out_time` | `String` | Optional | Time of Check out (HH:MM:SS) |
| `currency` | `String` | Required | Property currency. ISO 4217 code is required. |
| `policy` | [`Policy`](../../doc/models/policy.md) | Optional | - |
| `location` | [`Location`](../../doc/models/location.md) | Optional | - |
| `supported_los_rates` | `Boolean` | Required | If true - means that the property supports only LOS rates. So daily rates can not be sent and updated. Default is false. |
| `tax_number` | `String` | Optional | Tax number for the property |
| `multi_unit` | [`MultiUnitEnum`](../../doc/models/multi-unit-enum.md) | Optional | Enum for product multyunit type. |
| `parent_id` | `Integer` | Optional | This fields should not be used unless your property is not MLT (check field multiunit). In this case you must set owner (parent) id property to which this property will belong. Also you can not update this property. |
| `property_rating` | `Float` | Optional | Property rating. A floating point number representing the aggregate property rating (0-5). |
| `rating_number` | `Integer` | Optional | Rating Number. Number of ratings that the property has (Non-negative integer) |
| `minimum_renting_age` | `Integer` | Optional | Minimum renting age. If you want to remove previously added value - send value 0. |
| `base_price` | `Float` | Optional | Display value that channels use when guests search without dates. Min value = 10 USD; Max value = 25,000 USD |
| `built_date` | `DateTime` | Optional | Date when property were built. Format YYYY-MM-DD HH:MM:SS |
| `renovating_date` | `DateTime` | Optional | Date when property last time were renovated. Format YYYY-MM-DD HH:MM:SS |
| `renting_date` | `DateTime` | Optional | Date from when property is rented. Format YYYY-MM-DD HH:MM:SS |
| `host_location` | `Boolean` | Optional | Indicator, whether the host is living in the property or not. Default is FALSE. |
| `key_collection` | [`KeyCollection`](../../doc/models/key-collection.md) | Optional | - |
| `neighborhood_overview` | [`Text`](../../doc/models/text.md) | Optional | - |
| `about` | [`Text`](../../doc/models/text.md) | Optional | - |

## Example (as JSON)

```json
{
  "name": null,
  "rooms": null,
  "bathrooms": null,
  "persons": null,
  "propertyType": "PCT101",
  "currency": null,
  "supportedLosRates": null
}
```

