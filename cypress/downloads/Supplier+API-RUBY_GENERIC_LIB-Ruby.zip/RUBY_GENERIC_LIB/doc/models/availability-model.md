
# Availability Model

## Structure

`AvailabilityModel`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `begin_date` | `Date` | Required | Beginning date of date range for which availability is applied. Date should be in format "yyyy-MM-dd" |
| `end_date` | `Date` | Required | End date of date range for which availability is applied. Additional clarification: If you have reservation from 2020/08/05 - 2020/08/09, so checkout is on 2020/08/09 - you should send end date 2020/08/08, since 2020/08/09 is actually open for new reservation. Date should be in format "yyyy-MM-dd" |
| `availability` | `Boolean` | Required | Determines if the dates are available or not. Our system saves only not available dates, so it is enough that you sent only not available dates. But if you want to open dates that you previously sent that are not available, you need to send that these dates are available over API. |

## Example (as JSON)

```json
{
  "beginDate": "2016-03-13",
  "endDate": "2016-03-13",
  "availability": false
}
```

