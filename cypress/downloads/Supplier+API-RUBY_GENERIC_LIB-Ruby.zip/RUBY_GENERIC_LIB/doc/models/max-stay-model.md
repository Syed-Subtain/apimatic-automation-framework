
# Max Stay Model

## Structure

`MaxStayModel`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `begin_date` | `Date` | Required | Beginning date of date range for which max stay is applied. Date should be in format "yyyy-MM-dd" |
| `end_date` | `Date` | Required | End date of date range for which max stay is applied. Date should be in format "yyyy-MM-dd" |
| `max_stay` | `Integer` | Required | Number of days that will be applied for max stay |

## Example (as JSON)

```json
{
  "beginDate": "2016-03-13",
  "endDate": "2016-03-13",
  "maxStay": 24
}
```

