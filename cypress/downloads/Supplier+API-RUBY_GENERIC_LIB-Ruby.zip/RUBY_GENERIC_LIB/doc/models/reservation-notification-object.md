
# Reservation Notification Object

## Structure

`ReservationNotificationObject`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `reservation_id` | `String` | Required | Id of the reservation in BookingPal |
| `product_id` | `String` | Required | Id of the product in BookingPal |
| `supplier_id` | `String` | Required | Id of the property manager |
| `agent_name` | `String` | Optional | DEPRECATED - use channelName Agent name/Channel name |
| `channel_name` | `String` | Required | Channel name |
| `confirmation_id` | `String` | Required | Channel confirmation code |
| `unique_key` | `String` | Required | Unique code to identify that the request is from BookingPal. This value is unique for every PMS (and it will be different in different environments). |
| `new_state` | [`ReservationStateEnum`](../../doc/models/reservation-state-enum.md) | Required | Possible Reservation states |
| `customer_name` | `String` | Required | Guest full name (in format firstName lastName) |
| `from_date` | `Date` | Required | Reservation date from. Date is in format "yyyy-MM-dd" |
| `to_date` | `Date` | Required | Reservation date to. Date is in format "yyyy-MM-dd" |
| `adult` | `Integer` | Required | number of adults |
| `child` | `Integer` | Required | number of children |
| `address` | `String` | Optional | Guest address |
| `city` | `String` | Optional | Guest city |
| `zip` | `String` | Optional | Guest zip code |
| `country` | `String` | Optional | Guest country |
| `state` | `String` | Optional | Guest state |
| `email` | `String` | Required | Guest email |
| `phone` | `String` | Optional | Guest phone |
| `notes` | `String` | Optional | Guest notes |
| `credit_card_type` | `String` | Optional | Credit card type |
| `credit_card_number` | `String` | Optional | Credit card number |
| `credit_card_expiration_month` | `String` | Optional | Credit card expiration month |
| `credit_card_expiration_year` | `String` | Optional | Credit card expiration yea |
| `credit_card_cid` | `String` | Optional | Credit card cid |
| `total` | `Float` | Required | Best available rate (This is the total value that guests will pay, including rate, fees, taxes, and all commissions. ) |
| `fees` | [`Array<ReservationFeeNotificationModel>`](../../doc/models/reservation-fee-notification-model.md) | Required | List of models |
| `taxes` | [`Array<ReservationTaxNotificationModel>`](../../doc/models/reservation-tax-notification-model.md) | Required | List of models |
| `commission` | [`ReservationCommissionsNotificationModel`](../../doc/models/reservation-commissions-notification-model.md) | Required | - |
| `rate` | [`ReservationRateNotifcationModel`](../../doc/models/reservation-rate-notifcation-model.md) | Required | - |

## Example (as JSON)

```json
{
  "reservationId": "107",
  "productId": "1234816374",
  "supplierId": "3731837",
  "channelName": "Airbnb",
  "confirmationId": "dasdasd",
  "uniqueKey": null,
  "newState": "Cancelled",
  "customerName": "John Smith",
  "fromDate": null,
  "toDate": null,
  "adult": 2,
  "child": 0,
  "email": "andrewtesttest222@gmail.com",
  "total": null,
  "fees": {
    "id": "937-4",
    "name": "Cleaning Fee",
    "value": 110
  },
  "taxes": {
    "id": "22",
    "name": "State of Florida-Lake County State Tax",
    "value": 5
  },
  "commission": {
    "channelCommission": 10,
    "commission": 12
  },
  "rate": {
    "originalRackRate": 400,
    "netRate": 400,
    "newPublishedRackRate": 422
  }
}
```

