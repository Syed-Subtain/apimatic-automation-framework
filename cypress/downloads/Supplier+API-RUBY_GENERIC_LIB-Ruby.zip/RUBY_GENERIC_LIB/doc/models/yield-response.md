
# Yield Response

## Structure

`YieldResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `message` | `String` | Required | text info message |
| `error_message` | `Array<String>` | Required | List of error messages |
| `is_error` | `Boolean` | Required | Is error (default = false) |
| `code` | `String` | Required | Code of message |
| `data` | [`Array<TransportYield>`](../../doc/models/transport-yield.md) | Required | List of Models |

## Example (as JSON)

```json
{
  "message": "message0",
  "errorMessage": [
    "errorMessage2",
    "errorMessage3",
    "errorMessage4"
  ],
  "is_error": false,
  "code": "code8",
  "data": [
    {
      "productId": 69,
      "weekend": null,
      "lengthOfStay": null,
      "dateRange": null,
      "channelMarkup": null
    },
    {
      "productId": 70,
      "weekend": null,
      "lengthOfStay": null,
      "dateRange": null,
      "channelMarkup": null
    }
  ]
}
```

