
# User Enum

## Enumeration

`UserEnum`

## Fields

| Name |
|  --- |
| `PROPERTY_MANAGER` |
| `GUEST` |

## Example

```
PROPERTY_MANAGER
```

