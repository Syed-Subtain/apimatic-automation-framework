
# Image Push Notification

## Structure

`ImagePushNotification`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `success` | `Boolean` | Required | Processing Image success status |
| `type` | [`TypeEnum`](../../doc/models/type-enum.md) | Required | image type |
| `url` | `String` | Required | image URL |
| `version` | `String` | Required | Versoin for processing image |

## Example (as JSON)

```json
{
  "success": null,
  "type": "IMPORT",
  "url": null,
  "version": null
}
```

