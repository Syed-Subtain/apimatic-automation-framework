
# Create a New Schedule Request

## Structure

`CreateANewScheduleRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Name` | `String` | Required | - | String getName() | setName(String name) |
| `Type` | `String` | Required | - | String getType() | setType(String type) |
| `StartDate` | `String` | Required | - | String getStartDate() | setStartDate(String startDate) |
| `EndDate` | `String` | Required | - | String getEndDate() | setEndDate(String endDate) |
| `PhoneBookId` | `String` | Required | - | String getPhoneBookId() | setPhoneBookId(String phoneBookId) |
| `TemplateId` | `String` | Required | - | String getTemplateId() | setTemplateId(String templateId) |
| `IntervalType` | `String` | Required | - | String getIntervalType() | setIntervalType(String intervalType) |
| `Interval` | `int` | Required | - | int getInterval() | setInterval(int interval) |

## Example (as JSON)

```json
{
  "name": "Soccer Practice Reminder",
  "type": "recurring",
  "start_date": "2015-11-08 14:00",
  "end_date": "2015-11-20 14:00",
  "phone_book_id": "59196",
  "template_id": "8465",
  "interval_type": "days",
  "interval": 30
}
```

