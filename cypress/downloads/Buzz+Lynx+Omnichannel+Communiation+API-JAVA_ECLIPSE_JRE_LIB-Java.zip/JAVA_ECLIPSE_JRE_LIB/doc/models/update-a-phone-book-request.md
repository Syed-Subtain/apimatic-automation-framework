
# Update a Phone Book Request

## Structure

`UpdateAPhoneBookRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Name` | `String` | Required | - | String getName() | setName(String name) |
| `Attribute3` | `String` | Required | - | String getAttribute3() | setAttribute3(String attribute3) |

## Example (as JSON)

```json
{
  "name": "Soccer Moms and Dads",
  "attribute_3": "ID"
}
```

