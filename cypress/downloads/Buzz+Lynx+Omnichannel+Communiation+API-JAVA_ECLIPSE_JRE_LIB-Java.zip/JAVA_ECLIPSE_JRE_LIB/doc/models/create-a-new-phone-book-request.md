
# Create a New Phone Book Request

## Structure

`CreateANewPhoneBookRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Name` | `String` | Required | The name of the phone book (segment) | String getName() | setName(String name) |
| `Attribute1` | `String` | Optional | This specification allows you to specify a name for a first extensible attribute for the segment | String getAttribute1() | setAttribute1(String attribute1) |
| `Attribute2` | `String` | Optional | This specification allows you to specify a name for a second extensible attribute for the segment | String getAttribute2() | setAttribute2(String attribute2) |
| `Attribute3` | `String` | Optional | This specification allows you to specify a name for a third extensible attribute for the segment | String getAttribute3() | setAttribute3(String attribute3) |
| `Attribute4` | `String` | Optional | This specification allows you to specify a name for a fourth extensible attribute for the segment | String getAttribute4() | setAttribute4(String attribute4) |
| `Attribute5` | `String` | Optional | This specification allows you to specify a name for a fifth extensible attribute for the segment | String getAttribute5() | setAttribute5(String attribute5) |

## Example (as JSON)

```json
{
  "name": "Soccer Moms",
  "attribute_1": "ChildName",
  "attribute_2": "Team"
}
```

