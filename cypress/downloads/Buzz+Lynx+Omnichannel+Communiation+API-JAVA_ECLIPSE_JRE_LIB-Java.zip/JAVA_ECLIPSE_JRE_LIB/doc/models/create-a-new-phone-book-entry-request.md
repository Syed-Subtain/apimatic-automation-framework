
# Create a New Phone Book Entry Request

## Structure

`CreateANewPhoneBookEntryRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `MobileNumber` | `String` | Required | - | String getMobileNumber() | setMobileNumber(String mobileNumber) |
| `Title` | `String` | Required | - | String getTitle() | setTitle(String title) |
| `FirstName` | `String` | Required | - | String getFirstName() | setFirstName(String firstName) |
| `LastName` | `String` | Required | - | String getLastName() | setLastName(String lastName) |
| `Attribute1` | `String` | Required | Custom Attribute 1 for phone book entry | String getAttribute1() | setAttribute1(String attribute1) |
| `Attribute2` | `String` | Required | Custom Attribute 2 for phone book entry | String getAttribute2() | setAttribute2(String attribute2) |
| `Attribute3` | `String` | Required | Custom Attribute 3 for phone book entry | String getAttribute3() | setAttribute3(String attribute3) |
| `Attribute4` | `String` | Required | Custom Attribute 4 for phone book entry | String getAttribute4() | setAttribute4(String attribute4) |
| `Attribute5` | `String` | Required | Custom Attribute 5 for phone book entry | String getAttribute5() | setAttribute5(String attribute5) |

## Example (as JSON)

```json
{
  "mobile_number": "mobile_number0",
  "title": "title4",
  "first_name": "first_name0",
  "last_name": "last_name8",
  "attribute_1": "attribute_12",
  "attribute_2": "attribute_22",
  "attribute_3": "attribute_34",
  "attribute_4": "attribute_40",
  "attribute_5": "attribute_54"
}
```

