
# Create Competition Category Request

## Structure

`CreateCompetitionCategoryRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Name` | `String` | Required | - | String getName() | setName(String name) |
| `Text` | `String` | Required | - | String getText() | setText(String text) |
| `CreateDate` | `String` | Required | - | String getCreateDate() | setCreateDate(String createDate) |

## Example (as JSON)

```json
{
  "name": "Soccer Practice Reminder",
  "text": "Reminder: There is soccer practice on Wednesday at 16:00.",
  "create_date": "2015-12-08 16:47:45"
}
```

