
# Update a Template Request

## Structure

`UpdateATemplateRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Name` | `String` | Required | - | String getName() | setName(String name) |
| `Text` | `String` | Required | - | String getText() | setText(String text) |
| `PhoneBookId` | `String` | Required | - | String getPhoneBookId() | setPhoneBookId(String phoneBookId) |

## Example (as JSON)

```json
{
  "name": "Soccer Practice Reminder",
  "text": "Reminder: There is soccer practice on Tuesday at 16:00.",
  "phone_book_id": "123"
}
```

