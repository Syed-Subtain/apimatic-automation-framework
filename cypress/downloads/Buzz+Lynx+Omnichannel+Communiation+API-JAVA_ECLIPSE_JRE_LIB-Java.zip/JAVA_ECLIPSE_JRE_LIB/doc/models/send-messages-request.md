
# Send Messages Request

## Structure

`SendMessagesRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `MobileNumbers` | `String` | Required | - | String getMobileNumbers() | setMobileNumbers(String mobileNumbers) |
| `Message` | `String` | Required | - | String getMessage() | setMessage(String message) |

## Example (as JSON)

```json
{
  "mobile_numbers": "5558328328,55553942432",
  "message": "Soccer practice will be on the 7th at 6."
}
```

