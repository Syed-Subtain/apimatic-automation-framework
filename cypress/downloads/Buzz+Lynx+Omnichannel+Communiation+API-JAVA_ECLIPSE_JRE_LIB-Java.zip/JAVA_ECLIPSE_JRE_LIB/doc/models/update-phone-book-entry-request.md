
# Update Phone Book Entry Request

## Structure

`UpdatePhoneBookEntryRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `MobileNumber` | `String` | Required | - | String getMobileNumber() | setMobileNumber(String mobileNumber) |
| `Title` | `String` | Required | - | String getTitle() | setTitle(String title) |
| `FirstName` | `String` | Required | - | String getFirstName() | setFirstName(String firstName) |
| `LastName` | `String` | Required | - | String getLastName() | setLastName(String lastName) |
| `Attribute1` | `String` | Required | - | String getAttribute1() | setAttribute1(String attribute1) |
| `Attribute2` | `String` | Required | - | String getAttribute2() | setAttribute2(String attribute2) |

## Example (as JSON)

```json
{
  "mobile_number": "821838384234",
  "title": "Mrs",
  "first_name": "Holly",
  "last_name": "Hunter",
  "attribute_1": "Myron",
  "attribute_2": "Team B"
}
```

