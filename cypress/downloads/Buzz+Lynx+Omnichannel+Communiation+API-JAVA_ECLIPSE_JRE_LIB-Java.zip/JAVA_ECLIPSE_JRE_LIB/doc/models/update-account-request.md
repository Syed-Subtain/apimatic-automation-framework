
# Update Account Request

## Structure

`UpdateAccountRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `FirstName` | `String` | Required | - | String getFirstName() | setFirstName(String firstName) |
| `LastName` | `String` | Required | - | String getLastName() | setLastName(String lastName) |
| `Email` | `String` | Required | - | String getEmail() | setEmail(String email) |
| `MobileNumber` | `String` | Required | - | String getMobileNumber() | setMobileNumber(String mobileNumber) |
| `Password` | `String` | Required | - | String getPassword() | setPassword(String password) |

## Example (as JSON)

```json
{
  "first_name": "Holly",
  "last_name": "Soccer practice will be on the 7th at 6.",
  "email": "holly.hunter@company.com",
  "mobile_number": "5557756235",
  "password": "hunter"
}
```

