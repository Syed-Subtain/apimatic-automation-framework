# Sent Schedules

View schedules that have been sent. Each time a schedule is executed, a new sent schedule resource entry is added, which is viewable via the sentschedules resource.

For example, if a schedule is set up to run every 30 days, every 30 days an entry will be added to this resource. This enables you to view schedule that have been executed already.

```java
SentSchedulesController sentSchedulesController = client.getSentSchedulesController();
```

## Class Name

`SentSchedulesController`

## Methods

* [Get All Sent Schedules](../../doc/controllers/sent-schedules.md#get-all-sent-schedules)
* [Get a Sent Schedule](../../doc/controllers/sent-schedules.md#get-a-sent-schedule)


# Get All Sent Schedules

`GET /iwin/api/v1/sentschedules`

Get a list of all the schedules that have been kicked off. The total messages sent by the schedule can be seen.

```java
CompletableFuture<Void> getAllSentSchedulesAsync(
    final String accept)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `accept` | `String` | Header, Required | - |

## Response Type

`void`

## Example Usage

```java
String accept = "application/json";

sentSchedulesController.getAllSentSchedulesAsync(accept).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```


# Get a Sent Schedule

`GET /iwin/api/v1/sentschedules/{id}`

Get a single sent schedule item. Extra information (successful, failed, delivered, pending and reply totals) can be seen from viewing a single sent schedule.

```java
CompletableFuture<Void> getASentScheduleAsync(
    final String accept,
    final String sentScheduleId)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `accept` | `String` | Header, Required | - |
| `sentScheduleId` | `String` | Template, Required | - |

## Response Type

`void`

## Example Usage

```java
String accept = "application/json";
String sentScheduleId = "sentScheduleId8";

sentSchedulesController.getASentScheduleAsync(accept, sentScheduleId).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

