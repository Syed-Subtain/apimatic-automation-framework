# Balance

```java
BalanceController balanceController = client.getBalanceController();
```

## Class Name

`BalanceController`


# Get Balance

`GET /iwin/api/v1/balance`

Get your Iwin balance. Your balance is the number of messages that can be sent until your account balance is depleted.

```java
CompletableFuture<Void> getBalanceAsync(
    final String accept)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `accept` | `String` | Header, Required | - |

## Response Type

`void`

## Example Usage

```java
String accept = "application/json";

balanceController.getBalanceAsync(accept).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

