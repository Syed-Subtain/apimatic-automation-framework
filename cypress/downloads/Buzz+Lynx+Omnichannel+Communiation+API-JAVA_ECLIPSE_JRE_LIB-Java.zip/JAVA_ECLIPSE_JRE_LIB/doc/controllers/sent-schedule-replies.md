# Sent Schedule Replies

A sent schedule can receive replies from message recipients. The replies can be read from this resource.
You can use this resource to act on replies in your application.

```java
SentScheduleRepliesController sentScheduleRepliesController = client.getSentScheduleRepliesController();
```

## Class Name

`SentScheduleRepliesController`


# Get All Sent Schedule Replies

`GET /iwin/api/v1/sentschedules/{id}/replies`

View all the replies that were sent as a response to a scheduled message.

```java
CompletableFuture<Void> getAllSentScheduleRepliesAsync(
    final String accept,
    final String id)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `accept` | `String` | Header, Required | - |
| `id` | `String` | Template, Required | - |

## Response Type

`void`

## Example Usage

```java
String accept = "application/json";
String id = "id0";

sentScheduleRepliesController.getAllSentScheduleRepliesAsync(accept, id).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

