# Phone Books Entries

A phone book has multiple phone book entries containing recipient's details. If you plan on using tokens in your
messages, it is advisable to store the additonal attribute details for each phone book entry.

```java
PhoneBooksEntriesController phoneBooksEntriesController = client.getPhoneBooksEntriesController();
```

## Class Name

`PhoneBooksEntriesController`

## Methods

* [Delete Phone Book Entry](../../doc/controllers/phone-books-entries.md#delete-phone-book-entry)
* [Get a Phone Book Entry](../../doc/controllers/phone-books-entries.md#get-a-phone-book-entry)
* [Create a New Phone Book Entry](../../doc/controllers/phone-books-entries.md#create-a-new-phone-book-entry)
* [Update Phone Book Entry](../../doc/controllers/phone-books-entries.md#update-phone-book-entry)
* [Get Phone Book Entries](../../doc/controllers/phone-books-entries.md#get-phone-book-entries)


# Delete Phone Book Entry

`DELETE /iwin/api/v1/phonebooks/{id}/entries/{entry_id}`

Delete a phone book entry.

```java
CompletableFuture<Void> deletePhoneBookEntryAsync(
    final String accept,
    final String id,
    final String entryId)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `accept` | `String` | Header, Required | - |
| `id` | `String` | Template, Required | - |
| `entryId` | `String` | Template, Required | - |

## Response Type

`void`

## Example Usage

```java
String accept = "application/json";
String id = "id0";
String entryId = "entryId2";

phoneBooksEntriesController.deletePhoneBookEntryAsync(accept, id, entryId).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```


# Get a Phone Book Entry

`GET /iwin/api/v1/phonebooks/{id}/entries/{entry_id}`

Get a single phone book entry.

```java
CompletableFuture<Void> getAPhoneBookEntryAsync(
    final String accept,
    final String id)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `accept` | `String` | Header, Required | - |
| `id` | `String` | Template, Required | - |

## Response Type

`void`

## Example Usage

```java
String accept = "application/json";
String id = "id0";

phoneBooksEntriesController.getAPhoneBookEntryAsync(accept, id).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```


# Create a New Phone Book Entry

`POST /iwin/api/v1/phonebooks/{id}/entries`

Add a new phone book entry.

```java
CompletableFuture<Void> createANewPhoneBookEntryAsync(
    final String contentType,
    final String accept,
    final CreateANewPhoneBookEntryRequest body,
    final String id)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `contentType` | `String` | Header, Required | - |
| `accept` | `String` | Header, Required | - |
| `body` | [`CreateANewPhoneBookEntryRequest`](../../doc/models/create-a-new-phone-book-entry-request.md) | Body, Required | - |
| `id` | `String` | Template, Required | - |

## Response Type

`void`

## Example Usage

```java
String contentType = "application/json";
String accept = "application/json";
CreateANewPhoneBookEntryRequest body = new CreateANewPhoneBookEntryRequest();
body.setMobileNumber("mobile_number4");
body.setTitle("title8");
body.setFirstName("first_name6");
body.setLastName("last_name4");
body.setAttribute1("attribute_18");
body.setAttribute2("attribute_28");
body.setAttribute3("attribute_38");
body.setAttribute4("attribute_46");
body.setAttribute5("attribute_50");
String id = "id0";

phoneBooksEntriesController.createANewPhoneBookEntryAsync(contentType, accept, body, id).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```


# Update Phone Book Entry

`PUT /iwin/api/v1/phonebooks/{id}/entries/{entry_id}`

Update a phone book entry. Only the values present in the request will be updated - the rest will be left unchanged.

```java
CompletableFuture<Void> updatePhoneBookEntryAsync(
    final String contentType,
    final String accept,
    final UpdatePhoneBookEntryRequest body,
    final String id,
    final String entryId)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `contentType` | `String` | Header, Required | - |
| `accept` | `String` | Header, Required | - |
| `body` | [`UpdatePhoneBookEntryRequest`](../../doc/models/update-phone-book-entry-request.md) | Body, Required | - |
| `id` | `String` | Template, Required | - |
| `entryId` | `String` | Template, Required | - |

## Response Type

`void`

## Example Usage

```java
String contentType = "application/json";
String accept = "application/json";
UpdatePhoneBookEntryRequest body = new UpdatePhoneBookEntryRequest();
body.setMobileNumber("821838384234");
body.setTitle("Mrs");
body.setFirstName("Holly");
body.setLastName("Hunter");
body.setAttribute1("Myron");
body.setAttribute2("Team B");
String id = "id0";
String entryId = "entryId2";

phoneBooksEntriesController.updatePhoneBookEntryAsync(contentType, accept, body, id, entryId).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```


# Get Phone Book Entries

`GET /iwin/api/v1/phonebooks/{id}/entries`

Get all the entries in a phone book.

```java
CompletableFuture<Void> getPhoneBookEntriesAsync(
    final String accept,
    final String id)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `accept` | `String` | Header, Required | - |
| `id` | `String` | Template, Required | - |

## Response Type

`void`

## Example Usage

```java
String accept = "application/json";
String id = "id0";

phoneBooksEntriesController.getPhoneBookEntriesAsync(accept, id).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

