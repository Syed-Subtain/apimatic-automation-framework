# Phone Books

Phone books are groups of people that can be messaged at once.

```java
PhoneBooksController phoneBooksController = client.getPhoneBooksController();
```

## Class Name

`PhoneBooksController`

## Methods

* [Update a Phone Book](../../doc/controllers/phone-books.md#update-a-phone-book)
* [Create a New Phone Book](../../doc/controllers/phone-books.md#create-a-new-phone-book)
* [Get a Phone Book](../../doc/controllers/phone-books.md#get-a-phone-book)
* [Get All Phone Books](../../doc/controllers/phone-books.md#get-all-phone-books)
* [Delete a Phone Book](../../doc/controllers/phone-books.md#delete-a-phone-book)


# Update a Phone Book

`PUT /iwin/api/v1/phonebooks/{id}`

Update a phone book. Values not present in the request will not be updated.

```java
CompletableFuture<Void> updateAPhoneBookAsync(
    final String contentType,
    final String accept,
    final UpdateAPhoneBookRequest body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `contentType` | `String` | Header, Required | - |
| `accept` | `String` | Header, Required | - |
| `body` | [`UpdateAPhoneBookRequest`](../../doc/models/update-a-phone-book-request.md) | Body, Required | - |

## Response Type

`void`

## Example Usage

```java
String contentType = "application/json";
String accept = "application/json";
UpdateAPhoneBookRequest body = new UpdateAPhoneBookRequest();
body.setName("Soccer Moms and Dads");
body.setAttribute3("ID");

phoneBooksController.updateAPhoneBookAsync(contentType, accept, body).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```


# Create a New Phone Book

`POST /iwin/api/v1/phonebooks`

Add a new phone book. A phone book and its phone book entries are created separately. The phone book attribute fields are fields
that can be named to send personalized messages. For example, if attribute_1 has a value of "ID", a token
called &lt;ID&gt; can be used in messages, and the phone book entry (recipient) detail will be replaced in the message.

```java
CompletableFuture<Void> createANewPhoneBookAsync(
    final String contentType,
    final String accept,
    final CreateANewPhoneBookRequest body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `contentType` | `String` | Header, Required | - |
| `accept` | `String` | Header, Required | - |
| `body` | [`CreateANewPhoneBookRequest`](../../doc/models/create-a-new-phone-book-request.md) | Body, Required | - |

## Response Type

`void`

## Example Usage

```java
String contentType = "application/json";
String accept = "application/json";
CreateANewPhoneBookRequest body = new CreateANewPhoneBookRequest();
body.setName("Soccer Moms");
body.setAttribute1("ChildName");
body.setAttribute2("Team");
body.setAttribute3("AgeGroup");
body.setAttribute4("Position");
body.setAttribute5("ShirtSize");

phoneBooksController.createANewPhoneBookAsync(contentType, accept, body).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```


# Get a Phone Book

`GET /iwin/api/v1/phonebooks/{id}`

View a single phone book.

```java
CompletableFuture<Void> getAPhoneBookAsync(
    final String accept,
    final String id)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `accept` | `String` | Header, Required | - |
| `id` | `String` | Template, Required | - |

## Response Type

`void`

## Example Usage

```java
String accept = "application/json";
String id = "id0";

phoneBooksController.getAPhoneBookAsync(accept, id).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```


# Get All Phone Books

`GET /iwin/api/v1/phonebooks`

Get a list of all the phone books.

```java
CompletableFuture<Void> getAllPhoneBooksAsync(
    final String accept)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `accept` | `String` | Header, Required | - |

## Response Type

`void`

## Example Usage

```java
String accept = "application/json";

phoneBooksController.getAllPhoneBooksAsync(accept).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```


# Delete a Phone Book

`DELETE /iwin/api/v1/phonebooks/{id}`

Delete a phone book. Phone books already in use by a schedule cannot be deleted unless the schedule is also deleted.

```java
CompletableFuture<Void> deleteAPhoneBookAsync(
    final String accept,
    final String phoneBookId)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `accept` | `String` | Header, Required | - |
| `phoneBookId` | `String` | Template, Required | - |

## Response Type

`void`

## Example Usage

```java
String accept = "application/json";
String phoneBookId = "phoneBookId2";

phoneBooksController.deleteAPhoneBookAsync(accept, phoneBookId).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

