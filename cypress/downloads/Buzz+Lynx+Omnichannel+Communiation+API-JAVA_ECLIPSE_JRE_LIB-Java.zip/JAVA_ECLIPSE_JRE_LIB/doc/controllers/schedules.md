# Schedules

While messages are great for sending out some messages on an ad-hoc basis, schedules are more suited for
sending out messages to regular groups. Schedules are also very useful for personalised messages.
There are two types of schedules:

- `once off` - Once off schedules will be sent only once.

- `recurring` - Recurring schedules will be sent between the start and end date, on the interval specified.

```java
SchedulesController schedulesController = client.getSchedulesController();
```

## Class Name

`SchedulesController`

## Methods

* [Create a New Schedule](../../doc/controllers/schedules.md#create-a-new-schedule)
* [Get a Schedule](../../doc/controllers/schedules.md#get-a-schedule)
* [Update Activate a Schedule](../../doc/controllers/schedules.md#update-activate-a-schedule)
* [Delete a Schedule](../../doc/controllers/schedules.md#delete-a-schedule)
* [Update Suspend a Schedule](../../doc/controllers/schedules.md#update-suspend-a-schedule)
* [Get All Schedules](../../doc/controllers/schedules.md#get-all-schedules)


# Create a New Schedule

`POST /iwin/api/v1/schedules`

Create a new schedule.

```java
CompletableFuture<Void> createANewScheduleAsync(
    final String contentType,
    final String accept,
    final CreateANewScheduleRequest body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `contentType` | `String` | Header, Required | - |
| `accept` | `String` | Header, Required | - |
| `body` | [`CreateANewScheduleRequest`](../../doc/models/create-a-new-schedule-request.md) | Body, Required | - |

## Response Type

`void`

## Example Usage

```java
String contentType = "application/json";
String accept = "application/json";
CreateANewScheduleRequest body = new CreateANewScheduleRequest();
body.setName("Soccer Practice Reminder");
body.setType("recurring");
body.setStartDate("2015-11-08 14:00");
body.setEndDate("2015-11-20 14:00");
body.setPhoneBookId("59196");
body.setTemplateId("8465");
body.setIntervalType("days");
body.setInterval(30);

schedulesController.createANewScheduleAsync(contentType, accept, body).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```


# Get a Schedule

`GET /iwin/api/v1/schedules/{id}`

Get a single schedule.

```java
CompletableFuture<Void> getAScheduleAsync(
    final String accept,
    final String scheduleId)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `accept` | `String` | Header, Required | - |
| `scheduleId` | `String` | Template, Required | - |

## Response Type

`void`

## Example Usage

```java
String accept = "application/json";
String scheduleId = "scheduleId2";

schedulesController.getAScheduleAsync(accept, scheduleId).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```


# Update Activate a Schedule

`PUT /iwin/api/v1/schedules/{id}/activate`

It is only necessary to activate a schedule if it was suspended explicitly. After activation, the schedule status will be "active".

```java
CompletableFuture<Void> updateActivateAScheduleAsync(
    final String accept,
    final String scheduleId)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `accept` | `String` | Header, Required | - |
| `scheduleId` | `String` | Template, Required | - |

## Response Type

`void`

## Example Usage

```java
String accept = "application/json";
String scheduleId = "scheduleId2";

schedulesController.updateActivateAScheduleAsync(accept, scheduleId).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```


# Delete a Schedule

`DELETE /iwin/api/v1/schedules/{id}`

Only schedules in status "suspended" can be deleted. Call `PUT /iwin/api/v1/schedules/{id}/suspend` to suspend a schedule.

```java
CompletableFuture<Void> deleteAScheduleAsync(
    final String accept,
    final String scheduleId)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `accept` | `String` | Header, Required | - |
| `scheduleId` | `String` | Template, Required | - |

## Response Type

`void`

## Example Usage

```java
String accept = "application/json";
String scheduleId = "scheduleId2";

schedulesController.deleteAScheduleAsync(accept, scheduleId).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```


# Update Suspend a Schedule

`PUT /iwin/api/v1/schedules/{id}/suspend`

Suspending a schedule will temporary stop a scedule from running, until it is activated again. After suspending a schedule, the schedule status will be "suspended".

```java
CompletableFuture<Void> updateSuspendAScheduleAsync(
    final String accept,
    final String scheduleId)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `accept` | `String` | Header, Required | - |
| `scheduleId` | `String` | Template, Required | - |

## Response Type

`void`

## Example Usage

```java
String accept = "application/json";
String scheduleId = "scheduleId2";

schedulesController.updateSuspendAScheduleAsync(accept, scheduleId).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```


# Get All Schedules

`GET /iwin/api/v1/schedules`

Get all schedules, both active and suspended.

```java
CompletableFuture<Void> getAllSchedulesAsync(
    final String accept)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `accept` | `String` | Header, Required | - |

## Response Type

`void`

## Example Usage

```java
String accept = "application/json";

schedulesController.getAllSchedulesAsync(accept).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

