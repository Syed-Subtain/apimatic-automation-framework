# Account

The account resource provides an interface to update your Iwin account.

```java
AccountController accountController = client.getAccountController();
```

## Class Name

`AccountController`

## Methods

* [Get Account](../../doc/controllers/account.md#get-account)
* [Update Account](../../doc/controllers/account.md#update-account)


# Get Account

`GET /iwin/api/v1/account`

See your account details.

```java
CompletableFuture<Void> getAccountAsync(
    final String accept)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `accept` | `String` | Header, Required | - |

## Response Type

`void`

## Example Usage

```java
String accept = "application/json";

accountController.getAccountAsync(accept).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```


# Update Account

`PUT /iwin/api/v1/account`

Update your account details.

```java
CompletableFuture<Void> updateAccountAsync(
    final String contentType,
    final String accept,
    final UpdateAccountRequest body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `contentType` | `String` | Header, Required | - |
| `accept` | `String` | Header, Required | - |
| `body` | [`UpdateAccountRequest`](../../doc/models/update-account-request.md) | Body, Required | - |

## Response Type

`void`

## Example Usage

```java
String contentType = "application/json";
String accept = "application/json";
UpdateAccountRequest body = new UpdateAccountRequest();
body.setFirstName("Holly");
body.setLastName("Soccer practice will be on the 7th at 6.");
body.setEmail("holly.hunter@company.com");
body.setMobileNumber("5557756235");
body.setPassword("hunter");

accountController.updateAccountAsync(contentType, accept, body).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

