# Categories

```java
CategoriesController categoriesController = client.getCategoriesController();
```

## Class Name

`CategoriesController`

## Methods

* [Create Competition Category](../../doc/controllers/categories.md#create-competition-category)
* [Delete Competition Category](../../doc/controllers/categories.md#delete-competition-category)
* [Get Competition Categories](../../doc/controllers/categories.md#get-competition-categories)


# Create Competition Category

`POST /iwin-competition/api/v1/competitions/{id}/categories`

Create a new compeition category. Note that you can add the same category to multiple competitions at the same time by comma separating the competition IDs, e.g.
`/iwin-competition/api/v1/competitions/2334,2322/categories`, where `2334` and `2322` are the respective competition IDs.
This is useful for situations where you have more than one short code, e.g. a R2 short code and R30 short code for the same competition, but would like entrants to use either.

Important: Categories refresh every evening at 00:00. If you add a category at 15:00, the category will only be recognised at 00:00.

```java
CompletableFuture<Void> createCompetitionCategoryAsync(
    final String contentType,
    final String accept,
    final CreateCompetitionCategoryRequest body,
    final String id)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `contentType` | `String` | Header, Required | - |
| `accept` | `String` | Header, Required | - |
| `body` | [`CreateCompetitionCategoryRequest`](../../doc/models/create-competition-category-request.md) | Body, Required | - |
| `id` | `String` | Template, Required | - |

## Response Type

`void`

## Example Usage

```java
String contentType = "application/json";
String accept = "application/json";
CreateCompetitionCategoryRequest body = new CreateCompetitionCategoryRequest();
body.setName("Soccer Practice Reminder");
body.setText("Reminder: There is soccer practice on Wednesday at 16:00.");
body.setCreateDate("2015-12-08 16:47:45");
String id = "id0";

categoriesController.createCompetitionCategoryAsync(contentType, accept, body, id).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```


# Delete Competition Category

`DELETE /iwin-competition/api/v1/competitions/{id}/categories/{code}`

Delete a category. You can also delete the same category from different competitions in the same call by comma separating the competition IDs.

Important: Categories refresh every evening at 00:00. If you delete a category at 15:00, the category will only be recognised as deleted at 00:00.

```java
CompletableFuture<Void> deleteCompetitionCategoryAsync(
    final String accept,
    final String id)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `accept` | `String` | Header, Required | - |
| `id` | `String` | Template, Required | - |

## Response Type

`void`

## Example Usage

```java
String accept = "application/json";
String id = "id0";

categoriesController.deleteCompetitionCategoryAsync(accept, id).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```


# Get Competition Categories

`GET /iwin-competition/api/v1/competitions/{id}/categories`

Get all the categories (e.g. entrants) for a competition.

```java
CompletableFuture<Void> getCompetitionCategoriesAsync(
    final String accept,
    final String id)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `accept` | `String` | Header, Required | - |
| `id` | `String` | Template, Required | - |

## Response Type

`void`

## Example Usage

```java
String accept = "application/json";
String id = "id0";

categoriesController.getCompetitionCategoriesAsync(accept, id).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

