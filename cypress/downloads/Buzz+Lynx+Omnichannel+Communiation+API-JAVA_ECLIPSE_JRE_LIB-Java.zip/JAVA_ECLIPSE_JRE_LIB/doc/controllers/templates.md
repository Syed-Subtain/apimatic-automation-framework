# Templates

Message templates are stored messages that can be resent and reused. Tokens can be used to personalize messages. To use a token,
wrap the token name in <>, all uppercase. Tokens must be defined in the associated phone book's attributes 1 to 5.

```java
TemplatesController templatesController = client.getTemplatesController();
```

## Class Name

`TemplatesController`

## Methods

* [Create a New Template](../../doc/controllers/templates.md#create-a-new-template)
* [Delete a Template](../../doc/controllers/templates.md#delete-a-template)
* [Get All Templates](../../doc/controllers/templates.md#get-all-templates)
* [Get a Template](../../doc/controllers/templates.md#get-a-template)
* [Update a Template](../../doc/controllers/templates.md#update-a-template)


# Create a New Template

`POST /iwin/api/v1/templates`

Create a new template. A phone book ID can optionally be passed in, if you would like to use tokens in your messages.

```java
CompletableFuture<Void> createANewTemplateAsync(
    final String contentType,
    final String accept,
    final CreateANewTemplateRequest body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `contentType` | `String` | Header, Required | - |
| `accept` | `String` | Header, Required | - |
| `body` | [`CreateANewTemplateRequest`](../../doc/models/create-a-new-template-request.md) | Body, Required | - |

## Response Type

`void`

## Example Usage

```java
String contentType = "application/json";
String accept = "application/json";
CreateANewTemplateRequest body = new CreateANewTemplateRequest();
body.setName("Soccer Practice Reminder");
body.setText("Reminder: There is soccer practice on Wednesday at 16:00.");
body.setPhoneBookId("123");

templatesController.createANewTemplateAsync(contentType, accept, body).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```


# Delete a Template

`DELETE /iwin/api/v1/templates/{id}`

Delete a template. A template can only be deleted if it does not belong to a schedule.

```java
CompletableFuture<Void> deleteATemplateAsync(
    final String accept,
    final String templateId)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `accept` | `String` | Header, Required | - |
| `templateId` | `String` | Template, Required | - |

## Response Type

`void`

## Example Usage

```java
String accept = "application/json";
String templateId = "templateId0";

templatesController.deleteATemplateAsync(accept, templateId).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```


# Get All Templates

`GET /iwin/api/v1/templates`

Get all your message templates.

```java
CompletableFuture<Void> getAllTemplatesAsync(
    final String accept)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `accept` | `String` | Header, Required | - |

## Response Type

`void`

## Example Usage

```java
String accept = "application/json";

templatesController.getAllTemplatesAsync(accept).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```


# Get a Template

`GET /iwin/api/v1/templates/{id}`

Get a template.

```java
CompletableFuture<Void> getATemplateAsync(
    final String accept,
    final String templateId)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `accept` | `String` | Header, Required | - |
| `templateId` | `String` | Template, Required | - |

## Response Type

`void`

## Example Usage

```java
String accept = "application/json";
String templateId = "templateId0";

templatesController.getATemplateAsync(accept, templateId).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```


# Update a Template

`PUT /iwin/api/v1/templates/{id}`

Update a template.

```java
CompletableFuture<Void> updateATemplateAsync(
    final String contentType,
    final String accept,
    final UpdateATemplateRequest body,
    final String templateId)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `contentType` | `String` | Header, Required | - |
| `accept` | `String` | Header, Required | - |
| `body` | [`UpdateATemplateRequest`](../../doc/models/update-a-template-request.md) | Body, Required | - |
| `templateId` | `String` | Template, Required | - |

## Response Type

`void`

## Example Usage

```java
String contentType = "application/json";
String accept = "application/json";
UpdateATemplateRequest body = new UpdateATemplateRequest();
body.setName("Soccer Practice Reminder");
body.setText("Reminder: There is soccer practice on Tuesday at 16:00.");
body.setPhoneBookId("123");
String templateId = "templateId0";

templatesController.updateATemplateAsync(contentType, accept, body, templateId).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

