# Report Filters

```java
ReportFiltersController reportFiltersController = client.getReportFiltersController();
```

## Class Name

`ReportFiltersController`


# Get a Report S Filters

`GET /iwin/api/v1/reports/{id}/filters`

Get a report's filters.

```java
CompletableFuture<Void> getAReportSFiltersAsync(
    final String accept,
    final String id)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `accept` | `String` | Header, Required | - |
| `id` | `String` | Template, Required | - |

## Response Type

`void`

## Example Usage

```java
String accept = "application/json";
String id = "id0";

reportFiltersController.getAReportSFiltersAsync(accept, id).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

