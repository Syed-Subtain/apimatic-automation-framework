# Sent Messages

View messages that have been sent. Sent messages can be used to monitor delivery status.

```java
SentMessagesController sentMessagesController = client.getSentMessagesController();
```

## Class Name

`SentMessagesController`


# Get View Sent Messages

`GET /iwin/api/v1/sentmessages`

View all the sent messages.

```java
CompletableFuture<Void> getViewSentMessagesAsync(
    final String accept)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `accept` | `String` | Header, Required | - |

## Response Type

`void`

## Example Usage

```java
String accept = "application/json";

sentMessagesController.getViewSentMessagesAsync(accept).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

