# Competitions

```java
CompetitionsController competitionsController = client.getCompetitionsController();
```

## Class Name

`CompetitionsController`


# Get Competitions

`GET /iwin-competition/api/v1/competitions`

Get all your competitions (registered premium rated SMSes). To learn more about our Short Codes, go to http://www.iwin.co.za/shortcodes/.

```java
CompletableFuture<Void> getCompetitionsAsync(
    final String accept)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `accept` | `String` | Header, Required | - |

## Response Type

`void`

## Example Usage

```java
String accept = "application/json";

competitionsController.getCompetitionsAsync(accept).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

