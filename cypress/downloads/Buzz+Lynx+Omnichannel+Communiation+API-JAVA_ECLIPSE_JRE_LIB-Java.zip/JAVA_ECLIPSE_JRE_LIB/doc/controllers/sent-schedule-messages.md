# Sent Schedule Messages

View messages sent as part of a scheduled campaign. This would be all the messages that has been sent out as a sent schedule run.

```java
SentScheduleMessagesController sentScheduleMessagesController = client.getSentScheduleMessagesController();
```

## Class Name

`SentScheduleMessagesController`


# Get All Sent Schedule Messages

`GET /iwin/api/v1/sentschedules/{id}/messages`

View all the messages sent out as part of a scheduled message run.

```java
CompletableFuture<Void> getAllSentScheduleMessagesAsync(
    final String accept,
    final String id)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `accept` | `String` | Header, Required | - |
| `id` | `String` | Template, Required | - |

## Response Type

`void`

## Example Usage

```java
String accept = "application/json";
String id = "id0";

sentScheduleMessagesController.getAllSentScheduleMessagesAsync(accept, id).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

