
# Client Class Documentation

The following parameters are configurable for the API Client:

| Parameter | Type | Description |
|  --- | --- | --- |
| `environment` | Environment | The API environment. <br> **Default: `Environment.PRODUCTION`** |
| `httpClientConfig` | `ReadonlyHttpClientConfiguration` | Http Client Configuration instance. |
| `accessToken` | `String` | The OAuth 2.0 Access Token to use for API requests. |

The API client can be initialized as follows:

```java
BuzzLynxOmnichannelCommuniationAPIClient client = new BuzzLynxOmnichannelCommuniationAPIClient.Builder()
    .httpClientConfig(configBuilder -> configBuilder
            .timeout(0))
    .accessToken("AccessToken")
    .environment(Environment.PRODUCTION)
    .build();
```

## Buzz Lynx Omnichannel Communiation APIClient Class

The gateway for the SDK. This class acts as a factory for the Controllers and also holds the configuration of the SDK.

### Controllers

| Name | Description | Return Type |
|  --- | --- | --- |
| `getSentSchedulesController()` | Provides access to SentSchedules controller. | `SentSchedulesController` |
| `getSchedulesController()` | Provides access to Schedules controller. | `SchedulesController` |
| `getPhoneBooksController()` | Provides access to PhoneBooks controller. | `PhoneBooksController` |
| `getTemplatesController()` | Provides access to Templates controller. | `TemplatesController` |
| `getCategoriesController()` | Provides access to Categories controller. | `CategoriesController` |
| `getPhoneBooksEntriesController()` | Provides access to PhoneBooksEntries controller. | `PhoneBooksEntriesController` |
| `getAccountController()` | Provides access to Account controller. | `AccountController` |
| `getBalanceController()` | Provides access to Balance controller. | `BalanceController` |
| `getSentScheduleRepliesController()` | Provides access to SentScheduleReplies controller. | `SentScheduleRepliesController` |
| `getCompetitionsController()` | Provides access to Competitions controller. | `CompetitionsController` |
| `getMessagesController()` | Provides access to Messages controller. | `MessagesController` |
| `getSentMessagesController()` | Provides access to SentMessages controller. | `SentMessagesController` |
| `getReportFiltersController()` | Provides access to ReportFilters controller. | `ReportFiltersController` |
| `getReportsController()` | Provides access to Reports controller. | `ReportsController` |
| `getSentScheduleMessagesController()` | Provides access to SentScheduleMessages controller. | `SentScheduleMessagesController` |

### Methods

| Name | Description | Return Type |
|  --- | --- | --- |
| `shutdown()` | Shutdown the underlying HttpClient instance. | `void` |
| `getEnvironment()` | Current API environment. | `Environment` |
| `getHttpClient()` | The HTTP Client instance to use for making HTTP requests. | `HttpClient` |
| `getHttpClientConfig()` | Http Client Configuration instance. | `ReadonlyHttpClientConfiguration` |
| `getBearerAuthCredentials()` | The credentials to use with BearerAuth. | `BearerAuthCredentials` |
| `getAccessToken()` | OAuth 2.0 Access Token. | `String` |
| `getBaseUri(Server server)` | Get base URI by current environment | `String` |
| `getBaseUri()` | Get base URI by current environment | `String` |

